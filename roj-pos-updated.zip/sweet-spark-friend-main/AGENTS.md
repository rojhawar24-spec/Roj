<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Rollen- en gebruikersbeheersysteem (bijgewerkt)

Dit project gebruikt 3 rollen: `super_admin` (Baas), `shift_leader`, `cashier`.
- Alle gebruikersbeheer (aanmaken/verwijderen/rol wijzigen) loopt via
  `src/routes/api/admin/users.$action.ts` (service-role, alleen super_admin).
- Client-helper: `src/lib/adminApi.ts`.
- Geen publieke zelfregistratie meer — zie `src/routes/auth.tsx` (alleen login +
  eenmalige bootstrap van de eerste super_admin via `/api/public/init-admin`).
- Camera-barcodescanner: `src/components/BarcodeScanner.tsx` (native
  `BarcodeDetector` API, geen extra dependency).
- Migraties: `20260719131043_role_enum_values.sql` en
  `20260719131044_role_system_and_user_management.sql`.

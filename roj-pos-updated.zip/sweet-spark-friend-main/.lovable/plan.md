# Roj POS — Compleet Kassasysteem

Winkelnaam: **Roj**
Admin login (wordt direct aangemaakt):
- E-mail: `baas@roj.nl`
- Wachtwoord: `Roj12345!`

## Wat wordt gebouwd

### 1. Backend (Lovable Cloud)
Tabellen met RLS + rollen:
- `profiles` — naam, email
- `user_roles` (enum: `owner`, `admin`, `manager`, `cashier`) + `has_role()` security definer
- `products` — naam, barcode, prijs, kostprijs, voorraad, min_voorraad, btw_tarief (0/9/21), categorie
- `sales` — totaal, subtotaal, btw_bedrag, korting, betaalmethode (cash/pin), ontvangen, wisselgeld, kassier_id, klant_id, status
- `sale_items` — sale_id, product_id, naam, prijs, aantal, btw
- `stock_movements` — audit voor voorraad
- `audit_log` — alle admin-acties
- `coupons` — code, type (%/€), waarde, actief
- `store_settings` — naam, adres, btw-nummer, bon-footer

Trigger: auto-create profile + owner-rol bij eerste user. Server function met transactie voor verkoop (voorraad-check + decrement atomair).

### 2. Authentication
- Login-pagina op `/auth` (Lovable Cloud auth, email/wachtwoord)
- Bescherming via `_authenticated` layout
- Sign-out met cache-teardown
- Admin-account wordt direct aangemaakt via server-side seed

### 3. Kassascherm (`/pos`)
- Barcode-input met auto-focus + Enter
- Product-grid met categorieën & zoeken
- Winkelwagen: aantal aanpassen, verwijderen, korting per regel
- Kortingscode (coupon) toepassen
- BTW-berekening (9%/21%)
- Betaling: contant (met wisselgeld) of pin
- Digitale bon met QR-code, winkelnaam, BTW-nr, datum
- Print-vriendelijke bon (58/80mm thermisch formaat)
- Keyboard shortcuts (F2 zoeken, F9 afrekenen, Esc annuleren)

### 4. Admin dashboard (`/admin`)
- **Overzicht**: dagomzet, weekomzet, maandomzet, aantal transacties, top producten (grafieken)
- **Producten**: CRUD, bulk-import CSV, export CSV, barcode-generator, lage-voorraad-waarschuwing
- **Verkopen**: lijst met filters (datum, kassier, betaalmethode), detailweergave, retour-functie
- **Voorraad**: bewegingen, handmatig aanpassen met reden
- **Gebruikers**: uitnodigen, rol wijzigen (owner/admin/manager/cashier)
- **Rapporten**: verkoop per periode, per kassier, per categorie, winst
- **Kortingscodes**: beheer coupons
- **Instellingen**: winkelnaam, adres, BTW-nummer, bon-footer
- **Audit log**: alle acties zichtbaar

### 5. UX
- Responsive (tablet-first voor kassa)
- Dark mode toggle
- Nederlandse UI
- Toast-notificaties
- Snelle zoek

### 6. Design
Modern, professioneel: donkere accent-kleur, ruime typografie, kaart-gebaseerde layout — geen generieke AI-look.

## Technische details

- **Stack**: TanStack Start + Lovable Cloud (Supabase) + Tailwind + shadcn
- **Auth**: Lovable Cloud email/password, `requireSupabaseAuth` op alle server functions, RLS overal
- **Rollen**: `user_roles` tabel met `has_role()` security definer (nooit rol op profile)
- **Verkoop-transactie**: server function met row-level lock om dubbele voorraad-fouten te voorkomen
- **Charts**: `recharts` voor rapporten
- **Barcode**: `@zxing/browser` voor camera-scan (optioneel), handmatige input primair
- **QR op bon**: `qrcode` package
- **CSV**: `papaparse`

## Volgorde van bouwen

1. Lovable Cloud aanzetten
2. Database schema + RLS + triggers (1 migratie)
3. Admin-account seed (server function, éénmalig)
4. Auth-pagina + protected layout
5. Kassascherm
6. Admin dashboard (tabs: overzicht, producten, verkopen, voorraad, gebruikers, rapporten, instellingen)
7. Design polish + dark mode
8. Verificatie: inloggen, product toevoegen, verkoop doen

Na afronden log je in met `baas@roj.nl` / `Roj12345!` en kun je direct beginnen.

import { createFileRoute, Link } from "@tanstack/react-router";
import { ShieldAlert } from "lucide-react";

export const Route = createFileRoute("/access-denied")({
  ssr: false,
  component: AccessDeniedPage,
});

function AccessDeniedPage() {
  return (
    <div className="grid min-h-screen place-items-center bg-background px-4">
      <div className="max-w-md text-center">
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-destructive/15 text-destructive">
          <ShieldAlert className="h-8 w-8" />
        </div>
        <h1 className="mt-4 text-xl font-bold">Geen toegang</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Je account heeft niet de juiste rechten om deze pagina te bekijken. Neem contact op met de baas als je
          denkt dat dit niet klopt.
        </p>
        <div className="mt-6">
          <Link
            to="/pos"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
          >
            Terug naar kassa
          </Link>
        </div>
      </div>
    </div>
  );
}

import { createFileRoute, useNavigate, redirect } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Store, Loader2, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/auth")({
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (data.user) throw redirect({ to: "/pos" });
  },
  component: AuthPage,
});

async function logLoginEvent(event: "login_success" | "login_failed" | "logout", email: string, userId?: string) {
  try {
    await supabase.from("login_events").insert({
      user_id: userId ?? null,
      email,
      event,
      user_agent: typeof navigator !== "undefined" ? navigator.userAgent : null,
    });
  } catch {
    // logging must never block the login flow
  }
}

function AuthPage() {
  const navigate = useNavigate();
  const [showBootstrap, setShowBootstrap] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [bootLoading, setBootLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        await logLoginEvent("login_failed", email);
        throw error;
      }

      const userId = data.user?.id;
      const { data: profile } = userId
        ? await supabase.from("profiles").select("is_active, deleted_at, must_change_password").eq("id", userId).maybeSingle()
        : { data: null };

      if (profile && (!profile.is_active || profile.deleted_at)) {
        await supabase.auth.signOut();
        toast.error("Dit account is gedeactiveerd. Neem contact op met de baas.");
        return;
      }

      await logLoginEvent("login_success", email, userId);
      toast.success("Welkom terug!");
      navigate({ to: profile?.must_change_password ? "/change-password" : "/pos" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Er ging iets mis");
    } finally {
      setLoading(false);
    }
  }

  async function bootstrap() {
    setBootLoading(true);
    try {
      const res = await fetch("/api/public/init-admin", { method: "POST" });
      const json = await res.json();
      if (!res.ok || json.error) throw new Error(json.error || "Kon beheerder niet aanmaken");
      toast.success(json.message || "Beheerder aangemaakt");
      if (json.email) setEmail(json.email);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Er ging iets mis");
    } finally {
      setBootLoading(false);
    }
  }

  return (
    <div className="grid min-h-screen bg-background lg:grid-cols-2">
      <div className="relative hidden overflow-hidden bg-gradient-to-br from-primary/20 via-primary/5 to-background lg:block">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,hsl(var(--primary)/0.3),transparent_60%)]" />
        <div className="relative z-10 flex h-full flex-col justify-between p-12">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-primary text-primary-foreground shadow-lg">
              <Store className="h-6 w-6" />
            </div>
            <div>
              <div className="text-2xl font-bold tracking-tight">Roj</div>
              <div className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Point of Sale</div>
            </div>
          </div>
          <div>
            <h1 className="text-4xl font-bold leading-tight tracking-tight">
              Professioneel<br />kassasysteem.
            </h1>
            <p className="mt-4 max-w-md text-muted-foreground">
              Voorraad, verkoop, rapporten en gebruikers — alles op één plek.
              Werkt op tablet, snel en betrouwbaar.
            </p>
            <div className="mt-8 grid grid-cols-3 gap-4">
              {["Barcode", "Rapporten", "Voorraad"].map((f) => (
                <div key={f} className="rounded-lg border border-border/50 bg-card/50 p-3 text-center text-xs font-medium backdrop-blur">
                  {f}
                </div>
              ))}
            </div>
          </div>
          <div className="text-xs text-muted-foreground">© Roj POS</div>
        </div>
      </div>

      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <div className="mb-8 lg:hidden">
            <div className="flex items-center gap-2">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary text-primary-foreground">
                <Store className="h-5 w-5" />
              </div>
              <div className="text-xl font-bold">Roj POS</div>
            </div>
          </div>

          <h2 className="text-2xl font-bold tracking-tight">Inloggen</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Welkom terug bij Roj POS. Nieuwe medewerkers krijgen hun inloggegevens van de baas.
          </p>

          <form onSubmit={submit} className="mt-8 space-y-4">
            <div>
              <label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">E-mail</label>
              <input
                type="email"
                required
                className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="jij@voorbeeld.nl"
              />
            </div>
            <div>
              <label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Wachtwoord</label>
              <input
                type="password"
                required
                minLength={6}
                className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/20 hover:bg-primary/90 disabled:opacity-50"
            >
              {loading && <Loader2 className="h-4 w-4 animate-spin" />}
              Inloggen
            </button>
          </form>

          <div className="mt-6 border-t border-border pt-4 text-center">
            {!showBootstrap ? (
              <button
                className="text-xs text-muted-foreground hover:text-foreground"
                onClick={() => setShowBootstrap(true)}
              >
                Eerste keer instellen? Beheerder aanmaken
              </button>
            ) : (
              <div className="space-y-2 rounded-lg border border-border bg-card p-4 text-left">
                <div className="flex items-center gap-2 text-xs font-semibold">
                  <ShieldCheck className="h-3.5 w-3.5 text-primary" /> Eerste beheerder (baas)
                </div>
                <p className="text-xs text-muted-foreground">
                  Dit werkt alleen zolang er nog geen enkel account bestaat. Daarna kunnen alleen bestaande
                  beheerders nieuwe accounts aanmaken.
                </p>
                <button
                  onClick={bootstrap}
                  disabled={bootLoading}
                  className="w-full rounded-md border border-primary/40 bg-primary/10 py-2 text-xs font-semibold text-primary hover:bg-primary/20 disabled:opacity-50"
                >
                  {bootLoading ? "Bezig..." : "Maak eerste beheerder aan"}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

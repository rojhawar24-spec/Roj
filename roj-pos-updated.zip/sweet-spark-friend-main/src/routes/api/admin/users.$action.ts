import { createFileRoute } from "@tanstack/react-router";

const VALID_ROLES = ["super_admin", "shift_leader", "cashier"] as const;
type ValidRole = (typeof VALID_ROLES)[number];

function isValidRole(role: unknown): role is ValidRole {
  return typeof role === "string" && (VALID_ROLES as readonly string[]).includes(role);
}

function generatePassword(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%";
  let out = "";
  const bytes = new Uint32Array(14);
  crypto.getRandomValues(bytes);
  for (let i = 0; i < 14; i++) out += chars[bytes[i] % chars.length];
  return out;
}

export const Route = createFileRoute("/api/admin/users/$action")({
  server: {
    handlers: {
      POST: async ({ request, params }) => {
        const { requireCaller, writeAuditLog, authzErrorResponse } = await import(
          "@/integrations/supabase/require-role.server"
        );
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        try {
          // Elke actie hier is uitsluitend voor de baas (super_admin).
          const caller = await requireCaller(request, ["super_admin"]);
          const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
          const action = params.action;

          switch (action) {
            case "create": {
              const email = String(body.email || "").trim().toLowerCase();
              const fullName = String(body.full_name || "").trim() || email;
              const role = body.role;
              if (!email || !email.includes("@")) {
                return Response.json({ error: "Ongeldig e-mailadres." }, { status: 400 });
              }
              if (!isValidRole(role)) {
                return Response.json({ error: "Ongeldige rol." }, { status: 400 });
              }
              const password = typeof body.password === "string" && body.password.length >= 8
                ? body.password
                : generatePassword();

              const { data: created, error: createError } = await supabaseAdmin.auth.admin.createUser({
                email,
                password,
                email_confirm: true,
                user_metadata: { full_name: fullName, must_change_password: true },
              });
              if (createError || !created.user) {
                return Response.json({ error: createError?.message || "Kon gebruiker niet aanmaken." }, { status: 400 });
              }

              // handle_new_user trigger maakt het profiel al aan; alleen de rol toewijzen.
              await supabaseAdmin.from("user_roles").insert({ user_id: created.user.id, role });

              await writeAuditLog({
                userId: caller.userId,
                userEmail: caller.email,
                action: "user_created",
                entity: "profiles",
                entityId: created.user.id,
                details: { email, role, full_name: fullName },
              });

              return Response.json({ ok: true, user_id: created.user.id, email, temporary_password: password });
            }

            case "set-role": {
              const userId = String(body.user_id || "");
              const role = body.role;
              if (!userId || !isValidRole(role)) {
                return Response.json({ error: "Ongeldige aanvraag." }, { status: 400 });
              }
              await supabaseAdmin.from("user_roles").delete().eq("user_id", userId);
              await supabaseAdmin.from("user_roles").insert({ user_id: userId, role });

              await writeAuditLog({
                userId: caller.userId,
                userEmail: caller.email,
                action: "role_changed",
                entity: "user_roles",
                entityId: userId,
                details: { new_role: role },
              });

              return Response.json({ ok: true });
            }

            case "set-active": {
              const userId = String(body.user_id || "");
              const active = Boolean(body.active);
              if (!userId) return Response.json({ error: "Ongeldige aanvraag." }, { status: 400 });

              await supabaseAdmin.from("profiles").update({ is_active: active }).eq("id", userId);
              await writeAuditLog({
                userId: caller.userId,
                userEmail: caller.email,
                action: active ? "user_activated" : "user_deactivated",
                entity: "profiles",
                entityId: userId,
              });
              return Response.json({ ok: true });
            }

            case "delete": {
              const userId = String(body.user_id || "");
              const hard = Boolean(body.hard);
              const confirm = Boolean(body.confirm);
              if (!userId) return Response.json({ error: "Ongeldige aanvraag." }, { status: 400 });
              if (!confirm) {
                return Response.json({ error: "Bevestiging vereist." }, { status: 400 });
              }

              // Backup snapshot vóór verwijdering (belangrijk bij zelfverwijdering).
              const { data: profileSnapshot } = await supabaseAdmin
                .from("profiles")
                .select("*")
                .eq("id", userId)
                .maybeSingle();
              const { data: roleSnapshot } = await supabaseAdmin
                .from("user_roles")
                .select("role")
                .eq("user_id", userId);

              if (hard) {
                const { error: delError } = await supabaseAdmin.auth.admin.deleteUser(userId);
                if (delError) return Response.json({ error: delError.message }, { status: 400 });
              } else {
                await supabaseAdmin
                  .from("profiles")
                  .update({ is_active: false, deleted_at: new Date().toISOString() })
                  .eq("id", userId);
              }

              await writeAuditLog({
                userId: caller.userId,
                userEmail: caller.email,
                action: hard ? "user_hard_deleted" : "user_soft_deleted",
                entity: "profiles",
                entityId: userId,
                details: {
                  self_delete: userId === caller.userId,
                  backup: { profile: profileSnapshot, roles: roleSnapshot },
                },
              });

              return Response.json({ ok: true, self_delete: userId === caller.userId });
            }

            case "restore": {
              const userId = String(body.user_id || "");
              if (!userId) return Response.json({ error: "Ongeldige aanvraag." }, { status: 400 });
              await supabaseAdmin
                .from("profiles")
                .update({ is_active: true, deleted_at: null })
                .eq("id", userId);
              await writeAuditLog({
                userId: caller.userId,
                userEmail: caller.email,
                action: "user_restored",
                entity: "profiles",
                entityId: userId,
              });
              return Response.json({ ok: true });
            }

            default:
              return Response.json({ error: "Onbekende actie." }, { status: 404 });
          }
        } catch (err) {
          return authzErrorResponse(err);
        }
      },
    },
  },
});

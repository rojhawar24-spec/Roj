import { createFileRoute } from "@tanstack/react-router";

const ADMIN_EMAIL = "baas@roj.nl";
const ADMIN_PASSWORD = "Roj12345!";

export const Route = createFileRoute("/api/public/init-admin")({
  server: {
    handlers: {
      POST: async () => {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        // Check if any user_roles rows exist (any staff already?)
        const { count } = await supabaseAdmin
          .from("user_roles")
          .select("id", { count: "exact", head: true });

        if ((count ?? 0) > 0) {
          // Ensure our admin exists too? Just report.
          return Response.json({
            ok: true,
            message: "Er bestaat al een beheerder. Log in met je bestaande account.",
            email: ADMIN_EMAIL,
          });
        }

        const { data, error } = await supabaseAdmin.auth.admin.createUser({
          email: ADMIN_EMAIL,
          password: ADMIN_PASSWORD,
          email_confirm: true,
          user_metadata: { full_name: "Baas", must_change_password: true },
        });

        if (error) {
          return Response.json({ error: error.message }, { status: 400 });
        }

        // handle_new_user trigger maakt automatisch het profiel aan en geeft
        // de allereerste gebruiker de rol 'super_admin'.
        return Response.json({
          ok: true,
          message: `Beheerder aangemaakt: ${ADMIN_EMAIL} / ${ADMIN_PASSWORD} (wachtwoord wijzigen verplicht bij eerste login)`,
          email: ADMIN_EMAIL,
          user_id: data.user?.id,
        });
      },
    },
  },
});

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Search, Trash2, Plus, Minus, CreditCard, Banknote, X, ScanLine, Receipt as ReceiptIcon, Printer, Camera } from "lucide-react";
import QRCode from "qrcode";
import { cn } from "@/lib/utils";
import { BarcodeScanner } from "@/components/BarcodeScanner";

export const Route = createFileRoute("/_authenticated/pos")({
  component: POSPage,
});

type Product = {
  id: string; name: string; barcode: string | null; price: number;
  stock: number; vat_rate: number; category: string | null; active: boolean;
};
type CartItem = { product: Product; qty: number };
type Settings = { name: string; address: string; vat_number: string; receipt_footer: string; phone: string };

function POSPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [search, setSearch] = useState("");
  const [barcode, setBarcode] = useState("");
  const [payment, setPayment] = useState<"cash" | "pin">("cash");
  const [cashReceived, setCashReceived] = useState("");
  const [discount, setDiscount] = useState("");
  const [couponCode, setCouponCode] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [processing, setProcessing] = useState(false);
  const [receipt, setReceipt] = useState<{ id: string; receiptNo: number; items: CartItem[]; subtotal: number; vat: number; discount: number; total: number; payment: string; cashReceived: number | null; change: number | null; date: Date; qr: string } | null>(null);
  const [scannerOpen, setScannerOpen] = useState(false);
  const barcodeRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    supabase.from("products").select("*").eq("active", true).order("name").then(({ data }) => setProducts(data || []));
    supabase.from("store_settings").select("*").eq("id", 1).maybeSingle().then(({ data }) => setSettings(data as Settings));
    const ch = supabase.channel("products-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "products" }, () => {
        supabase.from("products").select("*").eq("active", true).order("name").then(({ data }) => setProducts(data || []));
      }).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "F2") { e.preventDefault(); document.getElementById("pos-search")?.focus(); }
      if (e.key === "F9") { e.preventDefault(); checkout(); }
      if (e.key === "Escape") { setCart([]); }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const categories = useMemo(() => {
    const s = new Set<string>();
    products.forEach((p) => p.category && s.add(p.category));
    return ["all", ...Array.from(s)];
  }, [products]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return products.filter((p) =>
      (category === "all" || p.category === category) &&
      (!q || p.name.toLowerCase().includes(q) || (p.barcode || "").includes(q)),
    );
  }, [products, search, category]);

  function addToCart(product: Product) {
    setCart((prev) => {
      const existing = prev.find((i) => i.product.id === product.id);
      if (existing) {
        if (existing.qty >= product.stock) { toast.error("Onvoldoende voorraad"); return prev; }
        return prev.map((i) => i.product.id === product.id ? { ...i, qty: i.qty + 1 } : i);
      }
      if (product.stock <= 0) { toast.error("Niet op voorraad"); return prev; }
      return [...prev, { product, qty: 1 }];
    });
  }

  function updateQty(id: string, delta: number) {
    setCart((prev) => prev.flatMap((i) => {
      if (i.product.id !== id) return [i];
      const q = i.qty + delta;
      if (q <= 0) return [];
      if (q > i.product.stock) { toast.error("Onvoldoende voorraad"); return [i]; }
      return [{ ...i, qty: q }];
    }));
  }

  function lookupByCode(code: string) {
    const p = products.find((x) => x.barcode === code.trim());
    if (!p) { toast.error(`Product niet gevonden voor barcode ${code}`); }
    else { addToCart(p); toast.success(`${p.name} toegevoegd`); }
  }

  function scanBarcode(e: React.FormEvent) {
    e.preventDefault();
    if (!barcode.trim()) return;
    lookupByCode(barcode);
    setBarcode("");
  }

  const subtotal = cart.reduce((s, i) => s + i.product.price * i.qty, 0);
  const discountNum = Math.max(0, parseFloat(discount) || 0);
  const total = Math.max(subtotal - discountNum, 0);
  const vatAmount = cart.reduce((s, i) => {
    const line = i.product.price * i.qty;
    return s + (line - line / (1 + i.product.vat_rate / 100));
  }, 0);
  const cashNum = parseFloat(cashReceived) || 0;
  const change = payment === "cash" ? cashNum - total : 0;

  async function checkout() {
    if (cart.length === 0) { toast.warning("Winkelwagen is leeg"); return; }
    if (payment === "cash" && cashNum < total) { toast.error("Ontvangen bedrag te laag"); return; }
    setProcessing(true);
    try {
      const items = cart.map((i) => ({ product_id: i.product.id, quantity: i.qty }));
      const { data, error } = await supabase.rpc("process_sale", {
        _items: items,
        _payment_method: payment,
        _cash_received: (payment === "cash" ? cashNum : 0) as number,
        _discount: discountNum,
        _coupon_code: (couponCode || "") as string,
      });
      if (error) throw error;
      const saleId = data as string;
      const { data: sale } = await supabase.from("sales").select("receipt_no").eq("id", saleId).maybeSingle();
      const qr = await QRCode.toDataURL(`ROJ-${sale?.receipt_no}-${saleId}`);
      setReceipt({
        id: saleId,
        receiptNo: sale?.receipt_no || 0,
        items: [...cart],
        subtotal, vat: vatAmount, discount: discountNum, total,
        payment, cashReceived: payment === "cash" ? cashNum : null,
        change: payment === "cash" ? change : null,
        date: new Date(), qr,
      });
      setCart([]); setCashReceived(""); setDiscount(""); setCouponCode("");
      toast.success("Verkoop voltooid");
      barcodeRef.current?.focus();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Fout bij verkoop");
    } finally {
      setProcessing(false);
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_420px]">
      <section className="space-y-3">
        <form onSubmit={scanBarcode} className="flex gap-2">
          <div className="relative flex-1">
            <ScanLine className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              ref={barcodeRef}
              autoFocus
              value={barcode}
              onChange={(e) => setBarcode(e.target.value)}
              placeholder="Scan of typ barcode + Enter"
              className="w-full rounded-md border border-input bg-card py-3 pl-10 pr-4 text-sm font-mono outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <div className="relative w-64">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              id="pos-search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Zoeken (F2)"
              className="w-full rounded-md border border-input bg-card py-3 pl-10 pr-4 text-sm outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <button
            type="button"
            onClick={() => setScannerOpen(true)}
            title="Scan met camera"
            className="flex shrink-0 items-center gap-2 rounded-md border border-primary/40 bg-primary/10 px-4 py-3 text-sm font-medium text-primary hover:bg-primary/20"
          >
            <Camera className="h-4 w-4" /> Camera
          </button>
        </form>

        <div className="flex flex-wrap gap-1.5">
          {categories.map((c) => (
            <button key={c} onClick={() => setCategory(c)}
              className={cn("rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                category === c ? "border-primary bg-primary text-primary-foreground" : "border-border hover:bg-accent")}>
              {c === "all" ? "Alle" : c}
            </button>
          ))}
        </div>

        <div className="grid gap-2 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4">
          {filtered.length === 0 && (
            <div className="col-span-full rounded-lg border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
              Geen producten. Voeg ze toe via Beheer.
            </div>
          )}
          {filtered.map((p) => (
            <button key={p.id} onClick={() => addToCart(p)} disabled={p.stock <= 0}
              className="group relative overflow-hidden rounded-lg border border-border bg-card p-3 text-left transition-all hover:border-primary hover:shadow-lg disabled:opacity-40">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-semibold">{p.name}</div>
                  {p.category && <div className="mt-0.5 text-[10px] uppercase tracking-wider text-muted-foreground">{p.category}</div>}
                </div>
                <div className={cn("shrink-0 rounded-md px-1.5 py-0.5 text-[10px] font-bold",
                  p.stock <= 0 ? "bg-destructive/20 text-destructive" : p.stock < 5 ? "bg-amber-500/20 text-amber-500" : "bg-primary/15 text-primary")}>
                  {p.stock}×
                </div>
              </div>
              <div className="mt-4 text-lg font-bold tracking-tight">€{p.price.toFixed(2)}</div>
            </button>
          ))}
        </div>
      </section>

      <aside className="sticky top-20 h-[calc(100vh-6rem)] rounded-xl border border-border bg-card p-4 flex flex-col">
        <div className="flex items-center justify-between border-b border-border pb-3">
          <div className="flex items-center gap-2">
            <ReceiptIcon className="h-4 w-4 text-primary" />
            <h2 className="text-sm font-bold uppercase tracking-wider">Winkelwagen</h2>
          </div>
          {cart.length > 0 && (
            <button onClick={() => setCart([])} className="text-xs text-muted-foreground hover:text-destructive">Legen</button>
          )}
        </div>

        <div className="flex-1 overflow-y-auto py-3">
          {cart.length === 0 ? (
            <div className="grid h-full place-items-center text-center text-xs text-muted-foreground">
              Winkelwagen is leeg.<br />Scan of tik op producten.
            </div>
          ) : (
            <ul className="space-y-2">
              {cart.map((i) => (
                <li key={i.product.id} className="rounded-md border border-border bg-background/40 p-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium">{i.product.name}</div>
                      <div className="text-xs text-muted-foreground">€{i.product.price.toFixed(2)} × {i.qty}</div>
                    </div>
                    <div className="text-sm font-bold">€{(i.product.price * i.qty).toFixed(2)}</div>
                  </div>
                  <div className="mt-2 flex items-center gap-1.5">
                    <button onClick={() => updateQty(i.product.id, -1)} className="grid h-7 w-7 place-items-center rounded border border-border hover:bg-accent"><Minus className="h-3 w-3" /></button>
                    <div className="w-8 text-center text-sm font-mono">{i.qty}</div>
                    <button onClick={() => updateQty(i.product.id, +1)} className="grid h-7 w-7 place-items-center rounded border border-border hover:bg-accent"><Plus className="h-3 w-3" /></button>
                    <div className="flex-1" />
                    <button onClick={() => setCart((prev) => prev.filter((x) => x.product.id !== i.product.id))} className="grid h-7 w-7 place-items-center rounded border border-border text-destructive hover:bg-destructive/10"><Trash2 className="h-3 w-3" /></button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="space-y-2 border-t border-border pt-3">
          <div className="grid grid-cols-2 gap-2">
            <input value={discount} onChange={(e) => setDiscount(e.target.value)} placeholder="Korting €" className="rounded-md border border-input bg-background px-2 py-1.5 text-xs" />
            <input value={couponCode} onChange={(e) => setCouponCode(e.target.value)} placeholder="Couponcode" className="rounded-md border border-input bg-background px-2 py-1.5 text-xs" />
          </div>

          <div className="space-y-1 text-xs">
            <div className="flex justify-between text-muted-foreground"><span>Subtotaal</span><span>€{subtotal.toFixed(2)}</span></div>
            <div className="flex justify-between text-muted-foreground"><span>BTW (inbegrepen)</span><span>€{vatAmount.toFixed(2)}</span></div>
            {discountNum > 0 && <div className="flex justify-between text-primary"><span>Korting</span><span>-€{discountNum.toFixed(2)}</span></div>}
            <div className="flex justify-between border-t border-border pt-1.5 text-lg font-bold"><span>Totaal</span><span>€{total.toFixed(2)}</span></div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button onClick={() => setPayment("cash")}
              className={cn("flex items-center justify-center gap-1.5 rounded-md border py-2 text-xs font-medium",
                payment === "cash" ? "border-primary bg-primary/10 text-primary" : "border-border hover:bg-accent")}>
              <Banknote className="h-3.5 w-3.5" /> Contant
            </button>
            <button onClick={() => setPayment("pin")}
              className={cn("flex items-center justify-center gap-1.5 rounded-md border py-2 text-xs font-medium",
                payment === "pin" ? "border-primary bg-primary/10 text-primary" : "border-border hover:bg-accent")}>
              <CreditCard className="h-3.5 w-3.5" /> Pin
            </button>
          </div>

          {payment === "cash" && (
            <div>
              <input value={cashReceived} onChange={(e) => setCashReceived(e.target.value)} type="number" step="0.01" placeholder="Ontvangen bedrag" className="w-full rounded-md border border-input bg-background px-2 py-1.5 text-sm" />
              {cashNum >= total && total > 0 && (
                <div className="mt-1 text-xs text-primary">Wisselgeld: <span className="font-bold">€{change.toFixed(2)}</span></div>
              )}
            </div>
          )}

          <button onClick={checkout} disabled={processing || cart.length === 0}
            className="w-full rounded-md bg-primary py-3 text-sm font-bold text-primary-foreground shadow-lg shadow-primary/20 hover:bg-primary/90 disabled:opacity-50">
            {processing ? "Bezig..." : `Afrekenen (F9) — €${total.toFixed(2)}`}
          </button>
        </div>
      </aside>

      {receipt && settings && (
        <ReceiptModal receipt={receipt} settings={settings} onClose={() => setReceipt(null)} />
      )}

      {scannerOpen && (
        <BarcodeScanner
          onDetected={(code) => { lookupByCode(code); setScannerOpen(false); }}
          onClose={() => setScannerOpen(false)}
        />
      )}
    </div>
  );
}

function ReceiptModal({ receipt, settings, onClose }: { receipt: NonNullable<ReturnType<typeof useState<any>>[0]>; settings: Settings; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4" onClick={onClose}>
      <div className="w-full max-w-sm rounded-xl bg-card p-4 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="font-bold">Bon</h3>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded hover:bg-accent"><X className="h-4 w-4" /></button>
        </div>
        <div className="print-receipt mt-3 rounded-lg border border-border bg-background p-4 font-mono text-xs">
          <div className="text-center">
            <div className="text-base font-bold">{settings.name}</div>
            {settings.address && <div>{settings.address}</div>}
            {settings.phone && <div>Tel: {settings.phone}</div>}
            {settings.vat_number && <div>BTW: {settings.vat_number}</div>}
          </div>
          <div className="my-2 border-t border-dashed border-foreground/30" />
          <div className="flex justify-between">
            <span>Bon #{receipt.receiptNo}</span>
            <span>{receipt.date.toLocaleString("nl-NL")}</span>
          </div>
          <div className="my-2 border-t border-dashed border-foreground/30" />
          {receipt.items.map((i: CartItem) => (
            <div key={i.product.id} className="mb-1">
              <div>{i.product.name}</div>
              <div className="flex justify-between"><span>  {i.qty} × €{i.product.price.toFixed(2)}</span><span>€{(i.qty * i.product.price).toFixed(2)}</span></div>
            </div>
          ))}
          <div className="my-2 border-t border-dashed border-foreground/30" />
          <div className="flex justify-between"><span>Subtotaal</span><span>€{receipt.subtotal.toFixed(2)}</span></div>
          <div className="flex justify-between"><span>BTW inbegrepen</span><span>€{receipt.vat.toFixed(2)}</span></div>
          {receipt.discount > 0 && <div className="flex justify-between"><span>Korting</span><span>-€{receipt.discount.toFixed(2)}</span></div>}
          <div className="flex justify-between text-base font-bold"><span>TOTAAL</span><span>€{receipt.total.toFixed(2)}</span></div>
          <div className="mt-1">Betaald: {receipt.payment === "cash" ? "Contant" : "Pin"}</div>
          {receipt.payment === "cash" && receipt.cashReceived != null && (
            <>
              <div>Ontvangen: €{receipt.cashReceived.toFixed(2)}</div>
              <div>Wisselgeld: €{(receipt.change || 0).toFixed(2)}</div>
            </>
          )}
          <div className="mt-3 grid place-items-center">
            <img src={receipt.qr} alt="QR" className="h-24 w-24" />
          </div>
          <div className="mt-2 text-center text-[10px]">{settings.receipt_footer}</div>
        </div>
        <div className="mt-3 flex gap-2">
          <button onClick={() => window.print()} className="flex flex-1 items-center justify-center gap-2 rounded-md bg-primary py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90"><Printer className="h-4 w-4" />Printen</button>
          <button onClick={onClose} className="flex-1 rounded-md border border-border py-2 text-sm hover:bg-accent">Sluiten</button>
        </div>
      </div>
    </div>
  );
}

import { createFileRoute, redirect, Link, useRouterState } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import Papa from "papaparse";
import {
  BarChart3, Package, Receipt, Users2, Settings2, Ticket, Boxes, ScrollText,
  Plus, Pencil, Trash2, Upload, Download, TrendingUp, ShoppingBag, Euro, AlertTriangle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { adminApi, type AppRole } from "@/lib/adminApi";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar,
} from "recharts";

type AdminRole = "super_admin" | "shift_leader";

export const Route = createFileRoute("/_authenticated/admin")({
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/auth" });
    const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", data.user.id);
    const roleNames = (roles || []).map((r) => r.role as string);
    const isSuperAdmin = roleNames.some((r) => r === "super_admin" || r === "owner" || r === "admin");
    const isShiftLeader = roleNames.some((r) => r === "shift_leader" || r === "manager");
    if (!isSuperAdmin && !isShiftLeader) throw redirect({ to: "/access-denied" });
    return { adminRole: (isSuperAdmin ? "super_admin" : "shift_leader") as AdminRole };
  },
  component: AdminLayout,
});

const ALL_TABS = [
  { id: "overview", label: "Overzicht", icon: BarChart3, roles: ["super_admin", "shift_leader"] as AdminRole[] },
  { id: "products", label: "Producten", icon: Package, roles: ["super_admin"] as AdminRole[] },
  { id: "sales", label: "Verkopen", icon: Receipt, roles: ["super_admin", "shift_leader"] as AdminRole[] },
  { id: "stock", label: "Voorraad", icon: Boxes, roles: ["super_admin", "shift_leader"] as AdminRole[] },
  { id: "users", label: "Gebruikers", icon: Users2, roles: ["super_admin"] as AdminRole[] },
  { id: "coupons", label: "Kortingen", icon: Ticket, roles: ["super_admin"] as AdminRole[] },
  { id: "audit", label: "Log", icon: ScrollText, roles: ["super_admin"] as AdminRole[] },
  { id: "settings", label: "Instellingen", icon: Settings2, roles: ["super_admin"] as AdminRole[] },
] as const;

function AdminLayout() {
  const { adminRole } = Route.useRouteContext();
  const search = useRouterState({ select: (s) => s.location.search }) as { tab?: string };
  const tabs = ALL_TABS.filter((t) => (t.roles as string[]).includes(adminRole));
  const [tab, setTab] = useState<string>(
    tabs.some((t) => t.id === search.tab) ? (search.tab as string) : "overview",
  );

  return (
    <div className="grid gap-4 md:grid-cols-[220px_1fr]">
      <aside className="rounded-xl border border-border bg-card p-2">
        <div className="mb-2 px-3 pt-2 text-xs font-bold uppercase tracking-widest text-muted-foreground">Beheer</div>
        {adminRole === "shift_leader" && (
          <div className="mx-2 mb-2 rounded-md bg-amber-500/10 px-2 py-1.5 text-[10px] text-amber-500">
            Beperkte toegang (Shift Leader)
          </div>
        )}
        <nav className="space-y-0.5">
          {tabs.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={cn("flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm transition-colors",
                tab === t.id ? "bg-primary/15 text-primary font-medium" : "text-muted-foreground hover:bg-accent hover:text-foreground")}>
              <t.icon className="h-4 w-4" /> {t.label}
            </button>
          ))}
        </nav>
      </aside>
      <section>
        {tab === "overview" && <Overview limited={adminRole === "shift_leader"} />}
        {tab === "products" && adminRole === "super_admin" && <ProductsPanel />}
        {tab === "sales" && <SalesPanel limited={adminRole === "shift_leader"} />}
        {tab === "stock" && <StockPanel readOnly={adminRole === "shift_leader"} />}
        {tab === "users" && adminRole === "super_admin" && <UsersPanel />}
        {tab === "coupons" && adminRole === "super_admin" && <CouponsPanel />}
        {tab === "audit" && adminRole === "super_admin" && <AuditPanel />}
        {tab === "settings" && adminRole === "super_admin" && <SettingsPanel />}
      </section>
    </div>
  );
}

function Card({ label, value, icon: Icon, hint, tone }: { label: string; value: string; icon: any; hint?: string; tone?: "primary" | "warn" }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <div className="flex items-center justify-between">
        <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className={cn("grid h-8 w-8 place-items-center rounded-md",
          tone === "warn" ? "bg-amber-500/15 text-amber-500" : "bg-primary/15 text-primary")}>
          <Icon className="h-4 w-4" />
        </div>
      </div>
      <div className="mt-3 text-2xl font-bold tracking-tight">{value}</div>
      {hint && <div className="mt-1 text-xs text-muted-foreground">{hint}</div>}
    </div>
  );
}

function Overview({ limited = false }: { limited?: boolean }) {
  const [sales, setSales] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  useEffect(() => {
    supabase.from("sales").select("*").order("created_at", { ascending: false }).limit(500).then(({ data }) => setSales(data || []));
    supabase.from("products").select("*").then(({ data }) => setProducts(data || []));
  }, []);

  const stats = useMemo(() => {
    const now = new Date();
    const today = new Date(now); today.setHours(0, 0, 0, 0);
    const weekAgo = new Date(now); weekAgo.setDate(now.getDate() - 7);
    const monthAgo = new Date(now); monthAgo.setDate(now.getDate() - 30);
    const dayTotal = sales.filter((s) => new Date(s.created_at) >= today).reduce((a, s) => a + Number(s.total), 0);
    const weekTotal = sales.filter((s) => new Date(s.created_at) >= weekAgo).reduce((a, s) => a + Number(s.total), 0);
    const monthTotal = sales.filter((s) => new Date(s.created_at) >= monthAgo).reduce((a, s) => a + Number(s.total), 0);
    const lowStock = products.filter((p) => p.stock <= p.min_stock).length;

    const byDay: Record<string, number> = {};
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now); d.setDate(now.getDate() - i); d.setHours(0, 0, 0, 0);
      byDay[d.toISOString().slice(0, 10)] = 0;
    }
    sales.forEach((s) => {
      const k = new Date(s.created_at).toISOString().slice(0, 10);
      if (k in byDay) byDay[k] += Number(s.total);
    });
    const chart = Object.entries(byDay).map(([date, total]) => ({ date: date.slice(5), total: Math.round(total * 100) / 100 }));

    return { dayTotal, weekTotal, monthTotal, lowStock, count: sales.length, chart };
  }, [sales, products]);

  if (limited) {
    const todaySales = sales.filter((s) => new Date(s.created_at).toDateString() === new Date().toDateString());
    const openSales = sales.filter((s) => s.status === "completed" && new Date(s.created_at).toDateString() === new Date().toDateString());
    return (
      <div className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2">
          <Card label="Omzet vandaag" value={`€${stats.dayTotal.toFixed(2)}`} icon={Euro} />
          <Card label="Bonnen vandaag" value={String(openSales.length)} icon={ShoppingBag} hint={`${todaySales.length} totaal`} />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Card label="Omzet vandaag" value={`€${stats.dayTotal.toFixed(2)}`} icon={Euro} />
        <Card label="Omzet 7 dagen" value={`€${stats.weekTotal.toFixed(2)}`} icon={TrendingUp} />
        <Card label="Transacties" value={String(stats.count)} icon={ShoppingBag} hint="Laatste 500" />
        <Card label="Lage voorraad" value={String(stats.lowStock)} icon={AlertTriangle} tone="warn" />
      </div>
      <div className="rounded-xl border border-border bg-card p-4">
        <div className="mb-3 text-sm font-semibold">Omzet — laatste 7 dagen</div>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={stats.chart}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={11} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} />
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }} />
              <Line type="monotone" dataKey="total" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

// ============ PRODUCTS ============
function ProductsPanel() {
  const [products, setProducts] = useState<any[]>([]);
  const [editing, setEditing] = useState<any | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [q, setQ] = useState("");

  async function load() {
    const { data } = await supabase.from("products").select("*").order("name");
    setProducts(data || []);
  }
  useEffect(() => { load(); }, []);

  async function del(id: string) {
    if (!confirm("Verwijderen?")) return;
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Verwijderd"); load(); }
  }

  async function exportCsv() {
    const csv = Papa.unparse(products);
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "producten.csv"; a.click();
  }

  function importCsv(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]; if (!file) return;
    Papa.parse(file, {
      header: true, dynamicTyping: true, skipEmptyLines: true,
      complete: async (result) => {
        const rows = (result.data as any[]).map((r) => ({
          name: r.name, barcode: r.barcode || null, category: r.category || "",
          price: Number(r.price) || 0, cost_price: Number(r.cost_price) || 0,
          stock: Number(r.stock) || 0, min_stock: Number(r.min_stock) || 5,
          vat_rate: Number(r.vat_rate) || 21,
        })).filter((r) => r.name);
        const { error } = await supabase.from("products").insert(rows);
        if (error) toast.error(error.message); else { toast.success(`${rows.length} producten geïmporteerd`); load(); }
      },
    });
    e.target.value = "";
  }

  const filtered = products.filter((p) => !q || p.name.toLowerCase().includes(q.toLowerCase()) || (p.barcode || "").includes(q));

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Zoeken..." className="w-64 rounded-md border border-input bg-card px-3 py-2 text-sm" />
        <div className="flex gap-2">
          <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-md border border-border bg-card px-3 py-2 text-sm hover:bg-accent">
            <Upload className="h-4 w-4" /> Import CSV
            <input type="file" accept=".csv" onChange={importCsv} className="hidden" />
          </label>
          <button onClick={exportCsv} className="inline-flex items-center gap-1.5 rounded-md border border-border bg-card px-3 py-2 text-sm hover:bg-accent">
            <Download className="h-4 w-4" /> Export CSV
          </button>
          <button onClick={() => { setEditing(null); setShowForm(true); }} className="inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90">
            <Plus className="h-4 w-4" /> Nieuw product
          </button>
        </div>
      </div>

      <div className="overflow-hidden rounded-xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="p-3 text-left">Naam</th>
              <th className="p-3 text-left">Barcode</th>
              <th className="p-3 text-left">Categorie</th>
              <th className="p-3 text-right">Prijs</th>
              <th className="p-3 text-right">Voorraad</th>
              <th className="p-3 text-right">BTW</th>
              <th className="p-3"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((p) => (
              <tr key={p.id} className="border-t border-border">
                <td className="p-3 font-medium">{p.name}</td>
                <td className="p-3 font-mono text-xs text-muted-foreground">{p.barcode || "—"}</td>
                <td className="p-3 text-muted-foreground">{p.category || "—"}</td>
                <td className="p-3 text-right font-mono">€{Number(p.price).toFixed(2)}</td>
                <td className={cn("p-3 text-right font-mono", p.stock <= p.min_stock && "text-amber-500")}>
                  {p.stock}
                </td>
                <td className="p-3 text-right font-mono">{p.vat_rate}%</td>
                <td className="p-3">
                  <div className="flex justify-end gap-1">
                    <button onClick={() => { setEditing(p); setShowForm(true); }} className="grid h-8 w-8 place-items-center rounded hover:bg-accent"><Pencil className="h-3.5 w-3.5" /></button>
                    <button onClick={() => del(p.id)} className="grid h-8 w-8 place-items-center rounded text-destructive hover:bg-destructive/10"><Trash2 className="h-3.5 w-3.5" /></button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">Geen producten.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {showForm && <ProductForm product={editing} onClose={() => setShowForm(false)} onSaved={() => { setShowForm(false); load(); }} />}
    </div>
  );
}

function ProductForm({ product, onClose, onSaved }: { product: any | null; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    name: product?.name || "", barcode: product?.barcode || "", category: product?.category || "",
    price: product?.price ?? 0, cost_price: product?.cost_price ?? 0,
    stock: product?.stock ?? 0, min_stock: product?.min_stock ?? 5, vat_rate: product?.vat_rate ?? 21,
  });
  const [saving, setSaving] = useState(false);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = { ...form, barcode: form.barcode || null };
      const q = product
        ? supabase.from("products").update(payload).eq("id", product.id)
        : supabase.from("products").insert(payload);
      const { error } = await q;
      if (error) throw error;
      toast.success("Opgeslagen"); onSaved();
    } catch (err) { toast.error(err instanceof Error ? err.message : "Fout"); }
    finally { setSaving(false); }
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4" onClick={onClose}>
      <form onSubmit={save} onClick={(e) => e.stopPropagation()} className="w-full max-w-md space-y-3 rounded-xl bg-card p-6">
        <h3 className="text-lg font-bold">{product ? "Product bewerken" : "Nieuw product"}</h3>
        {(["name","barcode","category"] as const).map((k) => (
          <div key={k}>
            <label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{k}</label>
            <input value={(form as any)[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })}
              required={k === "name"} className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm" />
          </div>
        ))}
        <div className="grid grid-cols-2 gap-2">
          {(["price","cost_price","stock","min_stock","vat_rate"] as const).map((k) => (
            <div key={k}>
              <label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{k.replace("_"," ")}</label>
              <input type="number" step="0.01" value={(form as any)[k]} onChange={(e) => setForm({ ...form, [k]: parseFloat(e.target.value) || 0 })}
                className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm" />
            </div>
          ))}
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <button type="button" onClick={onClose} className="rounded-md border border-border px-3 py-2 text-sm">Annuleer</button>
          <button type="submit" disabled={saving} className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
            {saving ? "Bezig..." : "Opslaan"}
          </button>
        </div>
      </form>
    </div>
  );
}

// ============ SALES ============
function SalesPanel({ limited = false }: { limited?: boolean }) {
  const [sales, setSales] = useState<any[]>([]);
  const [selected, setSelected] = useState<any | null>(null);
  const [items, setItems] = useState<any[]>([]);

  async function load() {
    const base = supabase.from("sales").select("*").order("created_at", { ascending: false });
    if (limited) {
      const startOfDay = new Date(); startOfDay.setHours(0, 0, 0, 0);
      const { data } = await base.gte("created_at", startOfDay.toISOString());
      setSales(data || []);
    } else {
      const { data } = await base.limit(200);
      setSales(data || []);
    }
  }
  useEffect(() => { load(); }, []);

  async function openSale(s: any) {
    setSelected(s);
    const { data } = await supabase.from("sale_items").select("*").eq("sale_id", s.id);
    setItems(data || []);
  }

  async function refund(id: string) {
    if (!confirm("Verkoop retourneren?")) return;
    const { error } = await supabase.from("sales").update({ status: "refunded" }).eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Retour geregistreerd"); load(); setSelected(null); }
  }

  return (
    <div className="space-y-3">
      {limited && (
        <div className="rounded-lg bg-amber-500/10 px-3 py-2 text-xs text-amber-500">
          Beperkt overzicht: alleen de verkopen van vandaag.
        </div>
      )}
      <div className="overflow-hidden rounded-xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="p-3 text-left">Bon #</th>
              <th className="p-3 text-left">Datum</th>
              <th className="p-3 text-left">Kassier</th>
              <th className="p-3 text-left">Betaling</th>
              <th className="p-3 text-right">Totaal</th>
              <th className="p-3 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {sales.map((s) => (
              <tr key={s.id} onClick={() => openSale(s)} className="cursor-pointer border-t border-border hover:bg-accent/40">
                <td className="p-3 font-mono">#{s.receipt_no}</td>
                <td className="p-3">{new Date(s.created_at).toLocaleString("nl-NL")}</td>
                <td className="p-3 text-muted-foreground">{s.cashier_email || "—"}</td>
                <td className="p-3">{s.payment_method === "cash" ? "Contant" : "Pin"}</td>
                <td className="p-3 text-right font-mono">€{Number(s.total).toFixed(2)}</td>
                <td className="p-3">
                  <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-medium",
                    s.status === "completed" ? "bg-primary/15 text-primary" : "bg-destructive/15 text-destructive")}>
                    {s.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selected && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4" onClick={() => setSelected(null)}>
          <div className="w-full max-w-md rounded-xl bg-card p-6" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold">Bon #{selected.receipt_no}</h3>
            <div className="mt-2 text-xs text-muted-foreground">{new Date(selected.created_at).toLocaleString("nl-NL")}</div>
            <ul className="mt-4 space-y-1 text-sm">
              {items.map((i) => (
                <li key={i.id} className="flex justify-between">
                  <span>{i.quantity}× {i.name}</span>
                  <span className="font-mono">€{Number(i.line_total).toFixed(2)}</span>
                </li>
              ))}
            </ul>
            <div className="mt-4 space-y-1 border-t border-border pt-3 text-sm">
              <div className="flex justify-between"><span>Subtotaal</span><span>€{Number(selected.subtotal).toFixed(2)}</span></div>
              <div className="flex justify-between"><span>BTW</span><span>€{Number(selected.vat_amount).toFixed(2)}</span></div>
              <div className="flex justify-between text-lg font-bold"><span>Totaal</span><span>€{Number(selected.total).toFixed(2)}</span></div>
            </div>
            <div className="mt-4 flex justify-end gap-2">
              {selected.status === "completed" && (
                <button onClick={() => refund(selected.id)} className="rounded-md border border-destructive/40 px-3 py-2 text-sm text-destructive hover:bg-destructive/10">Retour</button>
              )}
              <button onClick={() => setSelected(null)} className="rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground">Sluiten</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ============ STOCK ============
function StockPanel({ readOnly = false }: { readOnly?: boolean }) {
  const [products, setProducts] = useState<any[]>([]);
  const [movements, setMovements] = useState<any[]>([]);

  async function load() {
    const { data: p } = await supabase.from("products").select("*").order("stock", { ascending: true });
    setProducts(p || []);
    const { data: m } = await supabase.from("stock_movements").select("*, products(name)").order("created_at", { ascending: false }).limit(50);
    setMovements(m || []);
  }
  useEffect(() => { load(); }, []);

  async function adjust(product: any) {
    if (readOnly) return;
    const val = prompt(`Voorraad aanpassen voor ${product.name}\nHuidige: ${product.stock}\nNieuwe waarde:`);
    if (!val) return;
    const newStock = parseInt(val); if (isNaN(newStock)) return;
    const change = newStock - product.stock;
    const { data: user } = await supabase.auth.getUser();
    await supabase.from("products").update({ stock: newStock }).eq("id", product.id);
    await supabase.from("stock_movements").insert({ product_id: product.id, change, reason: "manual", user_id: user.user?.id });
    toast.success("Voorraad aangepast"); load();
  }

  const low = products.filter((p) => p.stock <= p.min_stock);

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <div className="space-y-3">
        <h3 className="text-sm font-bold uppercase tracking-wider">Lage voorraad ({low.length})</h3>
        <div className="rounded-xl border border-border bg-card">
          {low.length === 0 && <div className="p-6 text-center text-sm text-muted-foreground">Alles op peil ✓</div>}
          {low.map((p) => (
            <div key={p.id} className="flex items-center justify-between border-b border-border p-3 last:border-0">
              <div>
                <div className="text-sm font-medium">{p.name}</div>
                <div className="text-xs text-muted-foreground">Min: {p.min_stock}</div>
              </div>
              <div className="flex items-center gap-2">
                <span className="rounded bg-amber-500/15 px-2 py-0.5 text-xs font-bold text-amber-500">{p.stock}</span>
                {!readOnly && (
                  <button onClick={() => adjust(p)} className="rounded-md border border-border px-2 py-1 text-xs hover:bg-accent">Bijvullen</button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="space-y-3">
        <h3 className="text-sm font-bold uppercase tracking-wider">Recente bewegingen</h3>
        <div className="max-h-[500px] overflow-y-auto rounded-xl border border-border bg-card">
          {movements.map((m) => (
            <div key={m.id} className="flex items-center justify-between border-b border-border p-3 last:border-0">
              <div>
                <div className="text-sm font-medium">{m.products?.name}</div>
                <div className="text-xs text-muted-foreground">{m.reason} · {new Date(m.created_at).toLocaleString("nl-NL")}</div>
              </div>
              <div className={cn("font-mono text-sm font-bold", m.change < 0 ? "text-destructive" : "text-primary")}>
                {m.change > 0 ? "+" : ""}{m.change}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============ USERS ============
function UsersPanel() {
  const [users, setUsers] = useState<any[]>([]);
  const [meId, setMeId] = useState<string | null>(null);
  const [superAdminCount, setSuperAdminCount] = useState(0);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<{ email: string; full_name: string; role: AppRole; password: string }>({
    email: "", full_name: "", role: "cashier", password: "",
  });
  const [creating, setCreating] = useState(false);
  const [createdCreds, setCreatedCreds] = useState<{ email: string; temporary_password: string } | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [showDeleted, setShowDeleted] = useState(false);

  async function load() {
    const { data: profs } = await supabase.from("profiles").select("*").order("created_at");
    const { data: roles } = await supabase.from("user_roles").select("*");
    const merged = (profs || []).map((p) => ({
      ...p,
      role: (roles || []).find((r) => r.user_id === p.id)?.role || "cashier",
    }));
    setUsers(merged);
    const { data: userData } = await supabase.auth.getUser();
    setMeId(userData.user?.id || null);
    const { data: count } = await supabase.rpc("super_admin_count");
    setSuperAdminCount(typeof count === "number" ? count : 0);
  }
  useEffect(() => { load(); }, []);

  async function createUser(e: React.FormEvent) {
    e.preventDefault();
    setCreating(true);
    try {
      const res = await adminApi.createUser({
        email: form.email.trim(),
        full_name: form.full_name.trim(),
        role: form.role,
        password: form.password.trim() || undefined,
      });
      setCreatedCreds({ email: res.email, temporary_password: res.temporary_password });
      setForm({ email: "", full_name: "", role: "cashier", password: "" });
      setShowForm(false);
      toast.success("Gebruiker aangemaakt");
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Kon gebruiker niet aanmaken");
    } finally {
      setCreating(false);
    }
  }

  async function changeRole(userId: string, role: AppRole) {
    setBusyId(userId);
    try {
      await adminApi.setRole(userId, role);
      toast.success("Rol bijgewerkt");
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Kon rol niet wijzigen");
    } finally {
      setBusyId(null);
    }
  }

  async function toggleActive(userId: string, active: boolean) {
    setBusyId(userId);
    try {
      await adminApi.setActive(userId, active);
      toast.success(active ? "Account geactiveerd" : "Account gedeactiveerd");
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Actie mislukt");
    } finally {
      setBusyId(null);
    }
  }

  async function deleteUser(u: any) {
    const isSelf = u.id === meId;
    const isLastSuperAdmin = u.role === "super_admin" && superAdminCount <= 1;

    let msg = `Account van ${u.full_name || u.email} verwijderen (kan later hersteld worden)?`;
    if (isSelf) msg = `Je staat op het punt je EIGEN account te verwijderen. Je wordt direct uitgelogd. Weet je het zeker?`;
    if (isLastSuperAdmin) msg += `\n\nLet op: dit is de LAATSTE baas-account. Zorg dat er daarna nog iemand kan inloggen als baas.`;
    if (!confirm(msg)) return;
    if (isSelf && !confirm("Laatste bevestiging: écht je eigen account verwijderen?")) return;

    setBusyId(u.id);
    try {
      const res = await adminApi.deleteUser(u.id, { hard: false });
      toast.success("Account verwijderd (herstelbaar via 'Toon verwijderd').");
      if (res.self_delete) {
        await supabase.auth.signOut();
        window.location.href = "/auth";
        return;
      }
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Kon account niet verwijderen");
    } finally {
      setBusyId(null);
    }
  }

  async function hardDeleteUser(u: any) {
    if (!confirm(`PERMANENT verwijderen van ${u.email}? Dit kan niet ongedaan gemaakt worden.`)) return;
    setBusyId(u.id);
    try {
      await adminApi.deleteUser(u.id, { hard: true });
      toast.success("Account permanent verwijderd");
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Kon account niet verwijderen");
    } finally {
      setBusyId(null);
    }
  }

  async function restoreUser(u: any) {
    setBusyId(u.id);
    try {
      await adminApi.restoreUser(u.id);
      toast.success("Account hersteld");
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Kon account niet herstellen");
    } finally {
      setBusyId(null);
    }
  }

  const visibleUsers = users.filter((u) => showDeleted ? !!u.deleted_at : !u.deleted_at);

  return (
    <div className="space-y-3">
      {createdCreds && (
        <div className="flex items-start justify-between gap-3 rounded-xl border border-primary/40 bg-primary/10 p-4 text-sm">
          <div>
            <div className="font-semibold text-primary">Nieuw account aangemaakt</div>
            <div className="mt-1 font-mono text-xs">
              {createdCreds.email} / {createdCreds.temporary_password}
            </div>
            <div className="mt-1 text-xs text-muted-foreground">
              Geef dit wachtwoord door aan de medewerker. Ze moeten het bij eerste login wijzigen.
            </div>
          </div>
          <button onClick={() => setCreatedCreds(null)} className="text-xs text-muted-foreground hover:text-foreground">✕</button>
        </div>
      )}

      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          <button onClick={() => setShowForm((v) => !v)}
            className="inline-flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90">
            <Plus className="h-4 w-4" /> Nieuwe gebruiker
          </button>
          <button onClick={() => setShowDeleted((v) => !v)}
            className={cn("rounded-md border px-3 py-2 text-sm", showDeleted ? "border-primary bg-primary/10 text-primary" : "border-border hover:bg-accent")}>
            {showDeleted ? "Toon actieve" : "Toon verwijderd"}
          </button>
        </div>
        <div className="text-xs text-muted-foreground">{superAdminCount} baas-account(s) actief</div>
      </div>

      {showForm && (
        <form onSubmit={createUser} className="grid gap-2 rounded-xl border border-border bg-card p-4 md:grid-cols-4">
          <input required type="email" placeholder="E-mail" value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="rounded-md border border-input bg-background px-3 py-2 text-sm" />
          <input required placeholder="Volledige naam" value={form.full_name}
            onChange={(e) => setForm({ ...form, full_name: e.target.value })}
            className="rounded-md border border-input bg-background px-3 py-2 text-sm" />
          <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value as AppRole })}
            className="rounded-md border border-input bg-background px-3 py-2 text-sm">
            <option value="super_admin">Baas (super_admin)</option>
            <option value="shift_leader">Shift Leader</option>
            <option value="cashier">Kassa</option>
          </select>
          <input placeholder="Wachtwoord (leeg = auto)" value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            className="rounded-md border border-input bg-background px-3 py-2 text-sm" />
          <button disabled={creating} className="md:col-span-4 rounded-md bg-primary py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
            {creating ? "Bezig..." : "Account aanmaken"}
          </button>
        </form>
      )}

      <div className="overflow-hidden rounded-xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="p-3 text-left">Naam</th>
              <th className="p-3 text-left">E-mail</th>
              <th className="p-3 text-left">Rol</th>
              <th className="p-3 text-left">Status</th>
              <th className="p-3 text-right">Acties</th>
            </tr>
          </thead>
          <tbody>
            {visibleUsers.length === 0 && (
              <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">Geen gebruikers.</td></tr>
            )}
            {visibleUsers.map((u) => (
              <tr key={u.id} className="border-t border-border">
                <td className="p-3">
                  {u.full_name || "—"} {u.id === meId && <span className="ml-1 text-[10px] text-primary">(jij)</span>}
                </td>
                <td className="p-3 text-muted-foreground">{u.email}</td>
                <td className="p-3">
                  <select
                    value={u.role}
                    disabled={busyId === u.id || !!u.deleted_at}
                    onChange={(e) => changeRole(u.id, e.target.value as AppRole)}
                    className="rounded-md border border-input bg-background px-2 py-1 text-xs disabled:opacity-50"
                  >
                    <option value="super_admin">Baas</option>
                    <option value="shift_leader">Shift Leader</option>
                    <option value="cashier">Kassa</option>
                  </select>
                </td>
                <td className="p-3">
                  {u.deleted_at ? (
                    <span className="rounded-full bg-destructive/15 px-2 py-0.5 text-[10px] font-medium text-destructive">Verwijderd</span>
                  ) : u.is_active ? (
                    <span className="rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-medium text-primary">Actief</span>
                  ) : (
                    <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-medium text-amber-500">Inactief</span>
                  )}
                </td>
                <td className="p-3 text-right">
                  {u.deleted_at ? (
                    <div className="flex justify-end gap-2">
                      <button onClick={() => restoreUser(u)} disabled={busyId === u.id}
                        className="rounded-md border border-primary/40 px-2 py-1 text-xs text-primary hover:bg-primary/10 disabled:opacity-50">
                        Herstellen
                      </button>
                      <button onClick={() => hardDeleteUser(u)} disabled={busyId === u.id}
                        className="rounded-md border border-destructive/40 px-2 py-1 text-xs text-destructive hover:bg-destructive/10 disabled:opacity-50">
                        Permanent
                      </button>
                    </div>
                  ) : (
                    <div className="flex justify-end gap-2">
                      <button onClick={() => toggleActive(u.id, !u.is_active)} disabled={busyId === u.id}
                        className="rounded-md border border-border px-2 py-1 text-xs hover:bg-accent disabled:opacity-50">
                        {u.is_active ? "Deactiveren" : "Activeren"}
                      </button>
                      <button onClick={() => deleteUser(u)} disabled={busyId === u.id}
                        className="rounded-md border border-destructive/40 px-2 py-1 text-xs text-destructive hover:bg-destructive/10 disabled:opacity-50">
                        Verwijderen
                      </button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ============ COUPONS ============
function CouponsPanel() {
  const [coupons, setCoupons] = useState<any[]>([]);
  const [form, setForm] = useState({ code: "", discount_type: "percent", value: 10, active: true });

  async function load() {
    const { data } = await supabase.from("coupons").select("*").order("created_at", { ascending: false });
    setCoupons(data || []);
  }
  useEffect(() => { load(); }, []);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await supabase.from("coupons").insert(form);
    if (error) toast.error(error.message); else { toast.success("Toegevoegd"); setForm({ code: "", discount_type: "percent", value: 10, active: true }); load(); }
  }

  async function del(id: string) {
    await supabase.from("coupons").delete().eq("id", id); load();
  }

  return (
    <div className="space-y-3">
      <form onSubmit={add} className="grid gap-2 rounded-xl border border-border bg-card p-4 md:grid-cols-4">
        <input required value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} placeholder="Code" className="rounded-md border border-input bg-background px-3 py-2 text-sm" />
        <select value={form.discount_type} onChange={(e) => setForm({ ...form, discount_type: e.target.value })} className="rounded-md border border-input bg-background px-3 py-2 text-sm">
          <option value="percent">Percent %</option>
          <option value="amount">Bedrag €</option>
        </select>
        <input type="number" step="0.01" value={form.value} onChange={(e) => setForm({ ...form, value: parseFloat(e.target.value) })} className="rounded-md border border-input bg-background px-3 py-2 text-sm" />
        <button className="rounded-md bg-primary py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90">Toevoegen</button>
      </form>
      <div className="overflow-hidden rounded-xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
            <tr><th className="p-3 text-left">Code</th><th className="p-3">Type</th><th className="p-3 text-right">Waarde</th><th className="p-3"></th></tr>
          </thead>
          <tbody>
            {coupons.map((c) => (
              <tr key={c.id} className="border-t border-border">
                <td className="p-3 font-mono font-medium">{c.code}</td>
                <td className="p-3 text-center">{c.discount_type}</td>
                <td className="p-3 text-right font-mono">{c.discount_type === "percent" ? `${c.value}%` : `€${Number(c.value).toFixed(2)}`}</td>
                <td className="p-3 text-right"><button onClick={() => del(c.id)} className="text-destructive hover:underline text-xs">Verwijder</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ============ AUDIT ============
function AuditPanel() {
  const [log, setLog] = useState<any[]>([]);
  const [logins, setLogins] = useState<any[]>([]);
  useEffect(() => {
    supabase.from("audit_log").select("*").order("created_at", { ascending: false }).limit(200).then(({ data }) => setLog(data || []));
    supabase.from("login_events").select("*").order("created_at", { ascending: false }).limit(100).then(({ data }) => setLogins(data || []));
  }, []);
  return (
    <div className="space-y-4">
      <div>
        <h3 className="mb-2 text-sm font-bold uppercase tracking-wider">Activiteitenlog</h3>
        <div className="overflow-hidden rounded-xl border border-border bg-card">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
              <tr><th className="p-3 text-left">Datum</th><th className="p-3 text-left">Gebruiker</th><th className="p-3 text-left">Actie</th><th className="p-3 text-left">Details</th></tr>
            </thead>
            <tbody>
              {log.length === 0 && <tr><td colSpan={4} className="p-8 text-center text-muted-foreground">Nog geen activiteit.</td></tr>}
              {log.map((l) => (
                <tr key={l.id} className="border-t border-border">
                  <td className="p-3">{new Date(l.created_at).toLocaleString("nl-NL")}</td>
                  <td className="p-3">{l.user_email}</td>
                  <td className="p-3 font-mono text-xs">{l.action}</td>
                  <td className="p-3 text-xs text-muted-foreground">{JSON.stringify(l.details)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div>
        <h3 className="mb-2 text-sm font-bold uppercase tracking-wider">Login-geschiedenis</h3>
        <div className="overflow-hidden rounded-xl border border-border bg-card">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
              <tr><th className="p-3 text-left">Datum</th><th className="p-3 text-left">E-mail</th><th className="p-3 text-left">Gebeurtenis</th><th className="p-3 text-left">Browser</th></tr>
            </thead>
            <tbody>
              {logins.length === 0 && <tr><td colSpan={4} className="p-8 text-center text-muted-foreground">Nog geen logins.</td></tr>}
              {logins.map((l) => (
                <tr key={l.id} className="border-t border-border">
                  <td className="p-3">{new Date(l.created_at).toLocaleString("nl-NL")}</td>
                  <td className="p-3">{l.email}</td>
                  <td className="p-3">
                    <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-medium",
                      l.event === "login_success" ? "bg-primary/15 text-primary" :
                      l.event === "login_failed" ? "bg-destructive/15 text-destructive" : "bg-muted text-muted-foreground")}>
                      {l.event === "login_success" ? "Ingelogd" : l.event === "login_failed" ? "Mislukte poging" : "Uitgelogd"}
                    </span>
                  </td>
                  <td className="p-3 max-w-[280px] truncate text-xs text-muted-foreground">{l.user_agent}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ============ SETTINGS ============
function SettingsPanel() {
  const [settings, setSettings] = useState<any | null>(null);
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    supabase.from("store_settings").select("*").eq("id", 1).maybeSingle().then(({ data }) => setSettings(data));
  }, []);

  async function save(e: React.FormEvent) {
    e.preventDefault(); if (!settings) return;
    setSaving(true);
    const { error } = await supabase.from("store_settings").update(settings).eq("id", 1);
    if (error) toast.error(error.message); else toast.success("Opgeslagen");
    setSaving(false);
  }

  if (!settings) return <div className="text-sm text-muted-foreground">Laden...</div>;
  return (
    <form onSubmit={save} className="max-w-lg space-y-3 rounded-xl border border-border bg-card p-6">
      {([["name","Winkelnaam"],["address","Adres"],["phone","Telefoon"],["vat_number","BTW nummer"],["receipt_footer","Bon-voettekst"]] as const).map(([k, label]) => (
        <div key={k}>
          <label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</label>
          <input value={settings[k] || ""} onChange={(e) => setSettings({ ...settings, [k]: e.target.value })}
            className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm" />
        </div>
      ))}
      <button disabled={saving} className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
        {saving ? "Bezig..." : "Opslaan"}
      </button>
    </form>
  );
}

import { createFileRoute, Outlet, redirect, Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";
import { LayoutDashboard, ShoppingCart, LogOut, Store } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/auth" });
    return { user: data.user };
  },
  component: AuthedLayout,
});

type Role = "super_admin" | "shift_leader" | "cashier" | null;

function AuthedLayout() {
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [role, setRole] = useState<Role>(null);

  useEffect(() => {
    supabase.from("user_roles").select("role").eq("user_id", user.id).then(({ data }) => {
      const roles = (data || []).map((r) => r.role);
      if (roles.includes("super_admin" as any) || roles.includes("owner" as any) || roles.includes("admin" as any)) setRole("super_admin");
      else if (roles.includes("shift_leader" as any) || roles.includes("manager" as any)) setRole("shift_leader");
      else setRole("cashier");
    });
  }, [user.id]);

  async function signOut() {
    await supabase.from("login_events").insert({ user_id: user.id, email: user.email, event: "logout" });
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  const canSeeAdminPanel = role === "super_admin" || role === "shift_leader";
  const roleLabel = role === "super_admin" ? "Baas" : role === "shift_leader" ? "Shift Leader" : "Kassa";

  const nav = [
    { to: "/pos", label: "Kassa", icon: ShoppingCart, show: true },
    { to: "/admin", label: "Beheer", icon: LayoutDashboard, show: canSeeAdminPanel },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-40 border-b border-border/50 bg-card/80 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-[1600px] items-center gap-6 px-4">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-primary to-primary/60 text-primary-foreground">
              <Store className="h-5 w-5" />
            </div>
            <div>
              <div className="text-sm font-bold leading-none tracking-tight">Roj POS</div>
              <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Kassasysteem</div>
            </div>
          </div>
          <nav className="flex flex-1 items-center gap-1">
            {nav.filter((n) => n.show).map((item) => {
              const active = pathname.startsWith(item.to);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                    active ? "bg-primary/15 text-primary" : "text-muted-foreground hover:bg-accent hover:text-foreground",
                  )}
                >
                  <item.icon className="h-4 w-4" /> {item.label}
                </Link>
              );
            })}
          </nav>
          <div className="flex items-center gap-3">
            <div className="hidden text-right sm:block">
              <div className="text-xs font-medium">{user.email}</div>
              <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
                {roleLabel}
              </div>
            </div>
            <button
              onClick={signOut}
              className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm hover:bg-accent"
            >
              <LogOut className="h-4 w-4" /> Uitloggen
            </button>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-[1600px] p-4">
        <Outlet />
      </main>
    </div>
  );
}

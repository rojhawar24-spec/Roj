// Server-only. Verifies the caller's Supabase access token and checks their
// role in `user_roles` before allowing a privileged admin action to proceed.
// Import only from *.server.ts modules or route `server.handlers` — never
// from files that ship to the client bundle.
import { supabaseAdmin } from "./client.server";

export type AppRole = "super_admin" | "shift_leader" | "cashier" | "owner" | "admin" | "manager";

export type CallerContext = {
  userId: string;
  email: string | null;
  roles: AppRole[];
};

export class AuthzError extends Error {
  status: number;
  constructor(message: string, status = 403) {
    super(message);
    this.status = status;
  }
}

function bearerToken(request: Request): string {
  const authHeader = request.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    throw new AuthzError("Niet ingelogd.", 401);
  }
  const token = authHeader.slice("Bearer ".length).trim();
  if (!token) throw new AuthzError("Niet ingelogd.", 401);
  return token;
}

/**
 * Verifies the request's bearer token belongs to a real, active user and
 * returns their current roles. Throws AuthzError (401/403) otherwise.
 */
export async function requireCaller(request: Request, allowedRoles: AppRole[]): Promise<CallerContext> {
  const token = bearerToken(request);

  const { data: userData, error: userError } = await supabaseAdmin.auth.getUser(token);
  if (userError || !userData?.user) {
    throw new AuthzError("Sessie ongeldig of verlopen.", 401);
  }

  const { data: profile } = await supabaseAdmin
    .from("profiles")
    .select("is_active, deleted_at")
    .eq("id", userData.user.id)
    .maybeSingle();
  if (!profile || !profile.is_active || profile.deleted_at) {
    throw new AuthzError("Account is niet actief.", 403);
  }

  const { data: roleRows } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userData.user.id);
  const roles = (roleRows || []).map((r) => r.role as AppRole);

  const ok = roles.some((r) => allowedRoles.includes(r));
  if (!ok) {
    throw new AuthzError("Geen toegang voor deze actie.", 403);
  }

  return { userId: userData.user.id, email: userData.user.email ?? null, roles };
}

export async function writeAuditLog(entry: {
  userId: string | null;
  userEmail: string | null;
  action: string;
  entity?: string;
  entityId?: string;
  details?: Record<string, unknown>;
}) {
  await supabaseAdmin.from("audit_log").insert({
    user_id: entry.userId,
    user_email: entry.userEmail,
    action: entry.action,
    entity: entry.entity ?? null,
    entity_id: entry.entityId ?? null,
    details: entry.details ?? null,
  });
}

export function authzErrorResponse(err: unknown): Response {
  if (err instanceof AuthzError) {
    return Response.json({ error: err.message }, { status: err.status });
  }
  console.error(err);
  return Response.json({ error: "Er ging iets mis." }, { status: 500 });
}

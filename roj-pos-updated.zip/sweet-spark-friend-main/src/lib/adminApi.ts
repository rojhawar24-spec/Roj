import { supabase } from "@/integrations/supabase/client";

async function authedPost<T>(action: string, body: Record<string, unknown>): Promise<T> {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  if (!token) throw new Error("Niet ingelogd.");

  const res = await fetch(`/api/admin/users/${action}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(body),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error || `Actie mislukt (${res.status})`);
  return json as T;
}

export type AppRole = "super_admin" | "shift_leader" | "cashier";

export const adminApi = {
  createUser: (input: { email: string; full_name: string; role: AppRole; password?: string }) =>
    authedPost<{ ok: true; user_id: string; email: string; temporary_password: string }>("create", input),

  setRole: (userId: string, role: AppRole) => authedPost<{ ok: true }>("set-role", { user_id: userId, role }),

  setActive: (userId: string, active: boolean) =>
    authedPost<{ ok: true }>("set-active", { user_id: userId, active }),

  deleteUser: (userId: string, options: { hard?: boolean } = {}) =>
    authedPost<{ ok: true; self_delete: boolean }>("delete", { user_id: userId, hard: !!options.hard, confirm: true }),

  restoreUser: (userId: string) => authedPost<{ ok: true }>("restore", { user_id: userId }),
};

export const ROLE_LABELS: Record<AppRole, string> = {
  super_admin: "Baas",
  shift_leader: "Shift Leader",
  cashier: "Kassa",
};

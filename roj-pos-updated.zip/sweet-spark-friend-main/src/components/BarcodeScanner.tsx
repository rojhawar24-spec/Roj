import { useEffect, useRef, useState } from "react";
import { X, Camera, AlertTriangle, RefreshCw } from "lucide-react";

// Not every browser ships `BarcodeDetector` (Safari/Firefox lack native
// support at the time of writing). We feature-detect and fall back to a
// clear message instead of silently failing.
declare global {
  interface Window {
    BarcodeDetector?: new (options?: { formats?: string[] }) => {
      detect: (source: CanvasImageSource) => Promise<Array<{ rawValue: string }>>;
    };
  }
}

type Props = {
  onDetected: (code: string) => void;
  onClose: () => void;
};

export function BarcodeScanner({ onDetected, onClose }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number>(0);
  const lastCodeRef = useRef<{ code: string; at: number }>({ code: "", at: 0 });
  const [error, setError] = useState<string | null>(null);
  const [supported, setSupported] = useState(true);
  const [torchOn, setTorchOn] = useState(false);
  const [torchAvailable, setTorchAvailable] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined" || !window.BarcodeDetector) {
      setSupported(false);
      return;
    }

    let cancelled = false;
    const detector = new window.BarcodeDetector({
      formats: ["ean_13", "ean_8", "upc_a", "upc_e", "code_128", "code_39", "qr_code", "itf"],
    });

    async function start() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: "environment" } },
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }

        const track = stream.getVideoTracks()[0];
        const caps = track.getCapabilities?.() as (MediaTrackCapabilities & { torch?: boolean }) | undefined;
        setTorchAvailable(!!caps?.torch);

        const loop = async () => {
          if (cancelled || !videoRef.current) return;
          try {
            const codes = await detector.detect(videoRef.current);
            if (codes.length > 0) {
              const value = codes[0].rawValue;
              const now = Date.now();
              // debounce: ignore the same code fired again within 1.5s
              if (value !== lastCodeRef.current.code || now - lastCodeRef.current.at > 1500) {
                lastCodeRef.current = { code: value, at: now };
                onDetected(value);
              }
            }
          } catch {
            // transient decode errors are normal, keep scanning
          }
          rafRef.current = requestAnimationFrame(loop);
        };
        rafRef.current = requestAnimationFrame(loop);
      } catch (err) {
        if (!cancelled) {
          setError(
            err instanceof Error && err.name === "NotAllowedError"
              ? "Camera-toegang geweigerd. Geef toestemming in je browserinstellingen."
              : "Kon camera niet starten. Controleer of een camera beschikbaar is.",
          );
        }
      }
    }

    start();

    return () => {
      cancelled = true;
      cancelAnimationFrame(rafRef.current);
      streamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, [onDetected]);

  async function toggleTorch() {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track) return;
    try {
      const next = !torchOn;
      await track.applyConstraints({ advanced: [{ torch: next } as any] });
      setTorchOn(next);
    } catch {
      // torch toggling isn't universally supported; ignore silently
    }
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/80 p-4" onClick={onClose}>
      <div
        className="relative w-full max-w-md overflow-hidden rounded-xl bg-card shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-border p-3">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <Camera className="h-4 w-4 text-primary" /> Scan barcode
          </div>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded hover:bg-accent">
            <X className="h-4 w-4" />
          </button>
        </div>

        {!supported ? (
          <div className="flex flex-col items-center gap-3 p-8 text-center text-sm text-muted-foreground">
            <AlertTriangle className="h-8 w-8 text-amber-500" />
            <p>
              Camera-scannen wordt niet ondersteund in deze browser. Gebruik Chrome of Edge op Android, of scan met
              een fysieke barcodescanner via het invoerveld.
            </p>
          </div>
        ) : error ? (
          <div className="flex flex-col items-center gap-3 p-8 text-center text-sm text-muted-foreground">
            <AlertTriangle className="h-8 w-8 text-amber-500" />
            <p>{error}</p>
            <button
              onClick={() => setError(null)}
              className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-1.5 text-xs hover:bg-accent"
            >
              <RefreshCw className="h-3.5 w-3.5" /> Opnieuw proberen
            </button>
          </div>
        ) : (
          <div className="relative aspect-square bg-black">
            <video ref={videoRef} muted playsInline className="h-full w-full object-cover" />
            <div className="pointer-events-none absolute inset-8 rounded-lg border-2 border-primary/80" />
            {torchAvailable && (
              <button
                onClick={toggleTorch}
                className="absolute bottom-3 right-3 rounded-full bg-black/60 px-3 py-1.5 text-xs font-medium text-white backdrop-blur"
              >
                {torchOn ? "Lamp uit" : "Lamp aan"}
              </button>
            )}
          </div>
        )}

        <div className="p-3 text-center text-xs text-muted-foreground">Houd de barcode in het kader.</div>
      </div>
    </div>
  );
}

// Simplified chart wrapper — using recharts directly in components instead.
import * as React from "react";
import { cn } from "@/lib/utils";

export type ChartConfig = Record<string, { label?: string; color?: string }>;

export const ChartContainer = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & { config?: ChartConfig }
>(({ className, children, ...props }, ref) => (
  <div ref={ref} className={cn("h-full w-full", className)} {...props}>
    {children}
  </div>
));
ChartContainer.displayName = "ChartContainer";

export const ChartTooltip = ({ children }: { children?: React.ReactNode }) => <>{children}</>;
export const ChartTooltipContent = () => null;
export const ChartLegend = ({ children }: { children?: React.ReactNode }) => <>{children}</>;
export const ChartLegendContent = () => null;
export const ChartStyle = () => null;

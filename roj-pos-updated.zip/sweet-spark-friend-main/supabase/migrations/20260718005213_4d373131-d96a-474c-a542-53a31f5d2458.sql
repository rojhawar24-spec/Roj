-- Enum for roles
CREATE TYPE public.app_role AS ENUM ('owner', 'admin', 'manager', 'cashier');

-- Profiles
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  full_name text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- User roles
CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- has_role security definer
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT EXISTS(SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role) $$;

CREATE OR REPLACE FUNCTION public.is_staff(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT EXISTS(SELECT 1 FROM public.user_roles WHERE user_id = _user_id) $$;

CREATE OR REPLACE FUNCTION public.is_admin(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT EXISTS(SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role IN ('owner','admin')) $$;

-- Profile policies
CREATE POLICY "Users see own profile" ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.is_admin(auth.uid()));
CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE TO authenticated
  USING (id = auth.uid()) WITH CHECK (id = auth.uid());
CREATE POLICY "Admins manage profiles" ON public.profiles FOR ALL TO authenticated
  USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

-- Role policies
CREATE POLICY "Users see own roles" ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin(auth.uid()));

-- Store settings (single row)
CREATE TABLE public.store_settings (
  id int PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  name text NOT NULL DEFAULT 'Roj',
  address text DEFAULT '',
  vat_number text DEFAULT '',
  phone text DEFAULT '',
  receipt_footer text DEFAULT 'Bedankt voor uw bezoek!',
  currency text DEFAULT 'EUR',
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.store_settings TO authenticated;
GRANT ALL ON public.store_settings TO service_role;
ALTER TABLE public.store_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff read settings" ON public.store_settings FOR SELECT TO authenticated
  USING (public.is_staff(auth.uid()));
CREATE POLICY "Admins update settings" ON public.store_settings FOR ALL TO authenticated
  USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));
INSERT INTO public.store_settings (id, name) VALUES (1, 'Roj') ON CONFLICT (id) DO NOTHING;

-- Products
CREATE TABLE public.products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  barcode text UNIQUE,
  category text DEFAULT '',
  price numeric(10,2) NOT NULL DEFAULT 0,
  cost_price numeric(10,2) DEFAULT 0,
  stock int NOT NULL DEFAULT 0,
  min_stock int NOT NULL DEFAULT 5,
  vat_rate numeric(4,2) NOT NULL DEFAULT 21,
  image_url text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.products TO authenticated;
GRANT ALL ON public.products TO service_role;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff read products" ON public.products FOR SELECT TO authenticated
  USING (public.is_staff(auth.uid()));
CREATE POLICY "Admins manage products" ON public.products FOR ALL TO authenticated
  USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));
CREATE INDEX ON public.products(barcode);
CREATE INDEX ON public.products(name);

-- Sales
CREATE TABLE public.sales (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  receipt_no bigserial UNIQUE,
  subtotal numeric(10,2) NOT NULL DEFAULT 0,
  vat_amount numeric(10,2) NOT NULL DEFAULT 0,
  discount numeric(10,2) NOT NULL DEFAULT 0,
  total numeric(10,2) NOT NULL DEFAULT 0,
  payment_method text NOT NULL CHECK (payment_method IN ('cash','pin')),
  cash_received numeric(10,2),
  change_given numeric(10,2),
  coupon_code text,
  cashier_id uuid REFERENCES auth.users(id),
  cashier_email text,
  status text NOT NULL DEFAULT 'completed' CHECK (status IN ('completed','refunded','voided')),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.sales TO authenticated;
GRANT ALL ON public.sales TO service_role;
ALTER TABLE public.sales ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff read sales" ON public.sales FOR SELECT TO authenticated
  USING (public.is_staff(auth.uid()));
CREATE POLICY "Staff insert sales" ON public.sales FOR INSERT TO authenticated
  WITH CHECK (public.is_staff(auth.uid()) AND cashier_id = auth.uid());
CREATE POLICY "Admins update sales" ON public.sales FOR UPDATE TO authenticated
  USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));
CREATE INDEX ON public.sales(created_at DESC);

-- Sale items
CREATE TABLE public.sale_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sale_id uuid NOT NULL REFERENCES public.sales(id) ON DELETE CASCADE,
  product_id uuid REFERENCES public.products(id),
  name text NOT NULL,
  price numeric(10,2) NOT NULL,
  quantity int NOT NULL,
  vat_rate numeric(4,2) NOT NULL DEFAULT 21,
  line_total numeric(10,2) NOT NULL
);
GRANT SELECT, INSERT ON public.sale_items TO authenticated;
GRANT ALL ON public.sale_items TO service_role;
ALTER TABLE public.sale_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff read sale_items" ON public.sale_items FOR SELECT TO authenticated
  USING (public.is_staff(auth.uid()));
CREATE POLICY "Staff insert sale_items" ON public.sale_items FOR INSERT TO authenticated
  WITH CHECK (public.is_staff(auth.uid()));

-- Stock movements
CREATE TABLE public.stock_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  change int NOT NULL,
  reason text NOT NULL,
  reference_id uuid,
  user_id uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.stock_movements TO authenticated;
GRANT ALL ON public.stock_movements TO service_role;
ALTER TABLE public.stock_movements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff read movements" ON public.stock_movements FOR SELECT TO authenticated
  USING (public.is_staff(auth.uid()));
CREATE POLICY "Staff insert movements" ON public.stock_movements FOR INSERT TO authenticated
  WITH CHECK (public.is_staff(auth.uid()));

-- Audit log
CREATE TABLE public.audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  user_email text,
  action text NOT NULL,
  entity text,
  entity_id text,
  details jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.audit_log TO authenticated;
GRANT ALL ON public.audit_log TO service_role;
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins read audit" ON public.audit_log FOR SELECT TO authenticated
  USING (public.is_admin(auth.uid()));
CREATE POLICY "Staff insert audit" ON public.audit_log FOR INSERT TO authenticated
  WITH CHECK (public.is_staff(auth.uid()));

-- Coupons
CREATE TABLE public.coupons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  discount_type text NOT NULL CHECK (discount_type IN ('percent','amount')),
  value numeric(10,2) NOT NULL,
  active boolean NOT NULL DEFAULT true,
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.coupons TO authenticated;
GRANT ALL ON public.coupons TO service_role;
ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff read coupons" ON public.coupons FOR SELECT TO authenticated
  USING (public.is_staff(auth.uid()));
CREATE POLICY "Admins manage coupons" ON public.coupons FOR ALL TO authenticated
  USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

-- Auto-create profile on signup + assign 'owner' to first user, else 'cashier'
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE user_count int;
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email));

  SELECT count(*) INTO user_count FROM public.user_roles;
  IF user_count = 0 THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'owner');
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin');
  ELSE
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'cashier');
  END IF;
  RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- updated_at trigger
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
DROP TRIGGER IF EXISTS products_touch ON public.products;
CREATE TRIGGER products_touch BEFORE UPDATE ON public.products
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
DROP TRIGGER IF EXISTS settings_touch ON public.store_settings;
CREATE TRIGGER settings_touch BEFORE UPDATE ON public.store_settings
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Atomic sale processing
CREATE OR REPLACE FUNCTION public.process_sale(
  _items jsonb,
  _payment_method text,
  _cash_received numeric,
  _discount numeric,
  _coupon_code text
) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _sale_id uuid;
  _subtotal numeric := 0;
  _vat_amount numeric := 0;
  _total numeric;
  _change numeric;
  _item jsonb;
  _prod public.products%ROWTYPE;
  _qty int;
  _line_total numeric;
  _uid uuid := auth.uid();
  _email text;
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'Niet ingelogd'; END IF;
  IF NOT public.is_staff(_uid) THEN RAISE EXCEPTION 'Geen toegang'; END IF;

  SELECT email INTO _email FROM auth.users WHERE id = _uid;

  -- Lock and validate products, compute totals
  FOR _item IN SELECT * FROM jsonb_array_elements(_items) LOOP
    _qty := (_item->>'quantity')::int;
    SELECT * INTO _prod FROM public.products WHERE id = (_item->>'product_id')::uuid FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Product niet gevonden'; END IF;
    IF _prod.stock < _qty THEN RAISE EXCEPTION 'Onvoldoende voorraad voor %', _prod.name; END IF;
    _line_total := _prod.price * _qty;
    _subtotal := _subtotal + _line_total;
    _vat_amount := _vat_amount + (_line_total - (_line_total / (1 + _prod.vat_rate/100)));
  END LOOP;

  _total := GREATEST(_subtotal - COALESCE(_discount, 0), 0);
  _change := CASE WHEN _payment_method = 'cash' THEN COALESCE(_cash_received,0) - _total ELSE NULL END;

  INSERT INTO public.sales (subtotal, vat_amount, discount, total, payment_method,
    cash_received, change_given, coupon_code, cashier_id, cashier_email)
  VALUES (_subtotal, _vat_amount, COALESCE(_discount,0), _total, _payment_method,
    CASE WHEN _payment_method='cash' THEN _cash_received END,
    _change, _coupon_code, _uid, _email)
  RETURNING id INTO _sale_id;

  -- Insert items + decrement stock
  FOR _item IN SELECT * FROM jsonb_array_elements(_items) LOOP
    _qty := (_item->>'quantity')::int;
    SELECT * INTO _prod FROM public.products WHERE id = (_item->>'product_id')::uuid;
    _line_total := _prod.price * _qty;
    INSERT INTO public.sale_items (sale_id, product_id, name, price, quantity, vat_rate, line_total)
    VALUES (_sale_id, _prod.id, _prod.name, _prod.price, _qty, _prod.vat_rate, _line_total);
    UPDATE public.products SET stock = stock - _qty WHERE id = _prod.id;
    INSERT INTO public.stock_movements (product_id, change, reason, reference_id, user_id)
    VALUES (_prod.id, -_qty, 'sale', _sale_id, _uid);
  END LOOP;

  RETURN _sale_id;
END; $$;

GRANT EXECUTE ON FUNCTION public.process_sale(jsonb, text, numeric, numeric, text) TO authenticated;

-- ==========================================
-- ACCOUNTS AANMAKEN (BAAS, ADMIN1, ADMIN2)
-- ==========================================
DO $$
DECLARE
    baas_id UUID := gen_random_uuid();
    admin1_id UUID := gen_random_uuid();
    admin2_id UUID := gen_random_uuid();
BEGIN
    -- 1. Baas Account aanmaken
    INSERT INTO auth.users (id, aud, role, email, encrypted_password, email_confirmed_at, confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
    VALUES (baas_id, 'authenticated', 'authenticated', 'Baas@winkel.co', extensions.crypt('Welkom2026!', extensions.gen_salt('bf', 10)), now(), now(), '{"provider":"email","providers":["email"]}', '{}', now(), now());

    -- 2. Admin1 Account aanmaken
    INSERT INTO auth.users (id, aud, role, email, encrypted_password, email_confirmed_at, confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
    VALUES (admin1_id, 'authenticated', 'authenticated', 'Admin1@winkel.co', extensions.crypt('Welkom2026!', extensions.gen_salt('bf', 10)), now(), now(), '{"provider":"email","providers":["email"]}', '{}', now(), now());

    -- 3. Admin2 Account aanmaken
    INSERT INTO auth.users (id, aud, role, email, encrypted_password, email_confirmed_at, confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
    VALUES (admin2_id, 'authenticated', 'authenticated', 'Admin2@winkel.co', extensions.crypt('Welkom2026!', extensions.gen_salt('bf', 10)), now(), now(), '{"provider":"email","providers":["email"]}', '{}', now(), now());

    -- Even wachten zodat de database trigger (handle_new_user) de accounts kan verwerken
    PERFORM pg_sleep(0.5);

    -- Verwijder eventuele standaard rollen die de trigger heeft toegewezen om fouten te voorkomen
    DELETE FROM public.user_roles WHERE user_id IN (baas_id, admin1_id, admin2_id);

    -- Wijs handmatig de juiste rollen toe volgens het app_role type
    -- Baas krijgt 'owner' en 'admin'
    INSERT INTO public.user_roles (user_id, role) VALUES (baas_id, 'owner'), (baas_id, 'admin');

    -- Admin 1 en 2 krijgen de 'admin' rol
    INSERT INTO public.user_roles (user_id, role) VALUES (admin1_id, 'admin'), (admin2_id, 'admin');

END $$;

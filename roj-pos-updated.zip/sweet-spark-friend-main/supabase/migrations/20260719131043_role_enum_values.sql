-- Add the new role names used by the POS role/permission system.
-- Kept in its own migration because PostgreSQL will not let a newly added
-- enum value be *used* (in an UPDATE, function body, etc.) inside the same
-- transaction it was added in.
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'super_admin';
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'shift_leader';

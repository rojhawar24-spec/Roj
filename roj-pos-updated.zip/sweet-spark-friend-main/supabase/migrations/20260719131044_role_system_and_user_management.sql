-- ==========================================================
-- ROLLEN- EN PERMISSIESYSTEEM
-- 3 rollen: super_admin (baas), shift_leader, cashier
-- ==========================================================

-- ---------- 1. Migreer bestaande rollen naar het nieuwe model ----------
-- owner + admin -> super_admin (dedupe eerst zodat de UNIQUE(user_id, role)
-- constraint niet knapt wanneer iemand beide had)
DELETE FROM public.user_roles a
USING public.user_roles b
WHERE a.user_id = b.user_id
  AND a.role IN ('owner', 'admin')
  AND b.role IN ('owner', 'admin')
  AND a.ctid > b.ctid;

UPDATE public.user_roles SET role = 'super_admin' WHERE role IN ('owner', 'admin');
UPDATE public.user_roles SET role = 'shift_leader' WHERE role = 'manager';

-- De seed-accounts Admin1/Admin2 waren bedoeld als "shift_leader" (verantwoordelijke
-- op de vloer), niet als super_admin. Zet ze goed; alleen Baas blijft super_admin.
UPDATE public.user_roles ur
SET role = 'shift_leader'
FROM auth.users u
WHERE ur.user_id = u.id
  AND ur.role = 'super_admin'
  AND lower(u.email) IN ('admin1@winkel.co', 'admin2@winkel.co');

-- ---------- 2. profiles: levenscyclus-kolommen (soft-delete, actief/inactief) ----------
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS deleted_at timestamptz,
  ADD COLUMN IF NOT EXISTS must_change_password boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

DROP TRIGGER IF EXISTS profiles_touch ON public.profiles;
CREATE TRIGGER profiles_touch BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ---------- 3. Helper functies bijwerken naar het nieuwe rolmodel ----------
CREATE OR REPLACE FUNCTION public.is_admin(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT EXISTS(SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = 'super_admin') $$;

CREATE OR REPLACE FUNCTION public.is_super_admin(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT public.is_admin(_user_id) $$;

CREATE OR REPLACE FUNCTION public.is_shift_leader_or_above(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT EXISTS(SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role IN ('super_admin','shift_leader')) $$;

CREATE OR REPLACE FUNCTION public.current_role_name(_user_id uuid)
RETURNS public.app_role LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT role FROM public.user_roles WHERE user_id = _user_id
      ORDER BY CASE role WHEN 'super_admin' THEN 1 WHEN 'shift_leader' THEN 2 ELSE 3 END LIMIT 1 $$;

-- Count how many active super_admins exist (used client-side to warn before
-- someone removes the last one; intentionally NOT enforced server-side
-- because the owner explicitly wants to always be able to delete their own
-- account).
CREATE OR REPLACE FUNCTION public.super_admin_count()
RETURNS int LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT count(*)::int FROM public.user_roles ur
      JOIN public.profiles p ON p.id = ur.user_id
      WHERE ur.role = 'super_admin' AND p.deleted_at IS NULL AND p.is_active $$;

GRANT EXECUTE ON FUNCTION public.super_admin_count() TO authenticated;
GRANT EXECUTE ON FUNCTION public.current_role_name(uuid) TO authenticated;

-- ---------- 4. Alleen actieve, niet-verwijderde profielen mogen zichzelf zien/inloggen ----------
DROP POLICY IF EXISTS "Users see own profile" ON public.profiles;
CREATE POLICY "Users see own profile" ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.is_admin(auth.uid()) OR public.is_shift_leader_or_above(auth.uid()));

-- ---------- 5. Granulaire permissions + role_permissions (voor auditing/uitbreidbaarheid) ----------
CREATE TABLE IF NOT EXISTS public.permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  resource text NOT NULL,
  action text NOT NULL,
  description text
);
GRANT SELECT ON public.permissions TO authenticated;
GRANT ALL ON public.permissions TO service_role;
ALTER TABLE public.permissions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Staff read permissions" ON public.permissions;
CREATE POLICY "Staff read permissions" ON public.permissions FOR SELECT TO authenticated
  USING (public.is_shift_leader_or_above(auth.uid()));

CREATE TABLE IF NOT EXISTS public.role_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role public.app_role NOT NULL,
  permission_id uuid NOT NULL REFERENCES public.permissions(id) ON DELETE CASCADE,
  assigned_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(role, permission_id)
);
GRANT SELECT ON public.role_permissions TO authenticated;
GRANT ALL ON public.role_permissions TO service_role;
ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Staff read role_permissions" ON public.role_permissions;
CREATE POLICY "Staff read role_permissions" ON public.role_permissions FOR SELECT TO authenticated
  USING (public.is_shift_leader_or_above(auth.uid()));

INSERT INTO public.permissions (name, resource, action, description) VALUES
  ('users.create', 'users', 'create', 'Nieuwe gebruikers aanmaken'),
  ('users.update', 'users', 'update', 'Gebruikers wijzigen'),
  ('users.delete', 'users', 'delete', 'Gebruikers verwijderen'),
  ('roles.update', 'roles', 'update', 'Rollen aanpassen'),
  ('products.create', 'products', 'create', 'Producten aanmaken'),
  ('products.update', 'products', 'update', 'Producten wijzigen'),
  ('products.delete', 'products', 'delete', 'Producten verwijderen'),
  ('products.read', 'products', 'read', 'Producten bekijken'),
  ('sales.create', 'sales', 'create', 'Verkopen afronden'),
  ('sales.refund', 'sales', 'refund', 'Retour verwerken'),
  ('reports.full', 'reports', 'read', 'Volledige rapporten inzien'),
  ('reports.limited', 'reports', 'read', 'Beperkte dagrapporten inzien'),
  ('settings.manage', 'settings', 'update', 'Instellingen beheren'),
  ('backups.manage', 'backups', 'create', 'Back-ups maken'),
  ('audit.read', 'audit', 'read', 'Auditlog inzien')
ON CONFLICT (name) DO NOTHING;

INSERT INTO public.role_permissions (role, permission_id)
SELECT 'super_admin', id FROM public.permissions
ON CONFLICT DO NOTHING;

INSERT INTO public.role_permissions (role, permission_id)
SELECT 'shift_leader', id FROM public.permissions
WHERE name IN ('products.read','sales.create','sales.refund','reports.limited')
ON CONFLICT DO NOTHING;

INSERT INTO public.role_permissions (role, permission_id)
SELECT 'cashier', id FROM public.permissions
WHERE name IN ('products.read','sales.create')
ON CONFLICT DO NOTHING;

-- ---------- 6. Login/logout audit trail (sessions) ----------
CREATE TABLE IF NOT EXISTS public.login_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  email text,
  event text NOT NULL CHECK (event IN ('login_success','login_failed','logout')),
  ip_address text,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.login_events TO authenticated;
GRANT ALL ON public.login_events TO service_role;
ALTER TABLE public.login_events ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Admins read login events" ON public.login_events;
CREATE POLICY "Admins read login events" ON public.login_events FOR SELECT TO authenticated
  USING (public.is_admin(auth.uid()));
DROP POLICY IF EXISTS "Anyone inserts own login event" ON public.login_events;
CREATE POLICY "Anyone inserts own login event" ON public.login_events FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() OR user_id IS NULL);
CREATE INDEX IF NOT EXISTS login_events_created_idx ON public.login_events(created_at DESC);

-- ---------- 7. handle_new_user: alleen de allereerste gebruiker wordt automatisch super_admin ----------
-- Alle andere accounts worden voortaan expliciet aangemaakt door een super_admin
-- (zie /api/admin/users/create), die daarna zelf de rol toewijst. Zelfregistratie
-- via de publieke auth-pagina kent daardoor geen rol meer toe.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE user_count int;
BEGIN
  INSERT INTO public.profiles (id, email, full_name, must_change_password)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
          COALESCE((NEW.raw_user_meta_data->>'must_change_password')::boolean, false));

  SELECT count(*) INTO user_count FROM public.user_roles;
  IF user_count = 0 THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'super_admin');
  END IF;
  RETURN NEW;
END; $$;

-- ---------- 8. Voorkom dat een niet-super_admin zichzelf rollen toekent ----------
DROP POLICY IF EXISTS "Users see own roles" ON public.user_roles;
CREATE POLICY "Users see own roles" ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin(auth.uid()) OR public.is_shift_leader_or_above(auth.uid()));
-- (Geen INSERT/UPDATE/DELETE policy voor authenticated -> rolwijzigingen lopen
-- uitsluitend via de server-route met de service-role sleutel.)

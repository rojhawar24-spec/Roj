# ShopEasy 2.8.95 — start here

Read [README](README.md), [current QA](QA-REPORT-2.8.95.md), [known limits](FEATURES-AND-LIMITATIONS.md), [release checks](RELEASE-VERIFICATION.md) and [rights clearance](RIGHTS-CLEARANCE-REGISTER.md).

Use a new source extraction for checks. Install the declared Node24 runtime and locked dependencies. Run `npm test` through its isolated launcher; do not select a live database. Windows commands are in [QA setup](qa/README.md). Use [DEPLOYMENT.md](DEPLOYMENT.md) for the persistent Node host and [ADMIN-GUIDE.md](ADMIN-GUIDE.md) for operation. The old REPAIR12/13 installers target earlier existing installations; they are not the R28 buyer installation workflow and are NOT TESTED here.

UNKNOWN — Final source/asset ownership and effective buyer grant. This technical candidate must not be sold as rights-cleared without the required evidence.

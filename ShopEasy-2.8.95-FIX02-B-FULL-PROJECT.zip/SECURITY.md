## Current R5 Multer status — 2026-10-28

- `package.json` and the lock entry target `multer@2.5.0`, the upstream fixed version for [GHSA-q7qp-rjg7-q26m / CVE-2026-113872](https://github.com/expressjs/multer/security/advisories/GHSA-q7qp-rjg7-q26m). The synchronous `fileFilter` remains as additional defence.
- **Candidate blocker:** the current offline archive does not yet carry the registry-generated SHA-512 `integrity` for the 2.5.0 tarball. Do not infer integrity from an older version. `FINALIZE-AND-VERIFY-WINDOWS.ps1` must run on Node 24 with working registry access, install the exact package through npm, validate the 64-byte digest and pass tests/audit before final-verified packaging.

# Security notes

- Express 5 uses Helmet security headers and a strict Content Security Policy; templates should not introduce inline scripts or styles.
- State-changing forms are CSRF-protected. Redirect targets are restricted to safe local paths.
- Login, password-reset, checkout, search and other sensitive routes use rate limits. MFA attempts are persisted per Manager and source address, capped at five attempts per 15-minute window. Other application rate limiting is per process unless the deployment replaces the default store with shared storage.
- Manager login requires TOTP. Enrollment requires a password-authenticated five-minute challenge, a verified six-digit code, encrypted AES-256-GCM TOTP seed storage and eight one-time SHA-256-hashed recovery codes. Successful enrollment revokes all existing Manager sessions. Keep `MFA_ENCRYPTION_KEY` stable and private; without it MFA fails closed.
- Password recovery tokens are random, single-use, stored hashed, expire after 10 minutes and reset all sessions for the user. Unknown-email requests produce the same visible result.
- Only the manager role can access or change store-management routes, including global settings and audit-log screens. Admin is limited to the read-only overview and account security. Validate roles for every new route before adding it.
- Checkout recalculates price/discount/shipping server-side and reserves inventory transactionally. COD orders must not be treated as paid until delivery cash has actually been collected.
- Uploads enforce size, MIME and signature checks and use generated storage paths. Multipart parsing also caps file count, total parts, text-field count/size, field-name length, nesting depth and header pairs. Hosted persistent storage for uploaded files must be verified on the chosen host.
- Production secrets belong in the hosting provider’s secret manager, not source code, GitHub, logs or client JavaScript. Never ship `.env`, a local database, live tokens or customer exports in a release ZIP.
- Transactional email now supports password-reset codes, registration email verification and return-request/decision notifications. In production, set `BASE_URL` to the exact public HTTPS origin; verification links are not minted from request Host headers. Test Resend delivery and sender-domain verification in staging.

## Dependency advisory follow-up — 2026-10-23

- `package.json` and `package-lock.json` in this delivered candidate still pin Multer 2.4.0. The Multer maintainers published [GHSA-q7qp-rjg7-q26m / CVE-2026-113872](https://github.com/expressjs/multer/security/advisories/GHSA-q7qp-rjg7-q26m) on 2026-10-22; it affects versions below 2.5.0 when an asynchronous `fileFilter` is configured. ShopEasy currently uses a synchronous `fileFilter`, which is the advisory-listed workaround, and a regression test guards this. The user supplied a Windows log saying they upgraded their local checkout to Multer 2.5.0 and `npm audit` reported zero vulnerabilities, but that exact updated package lock was not included with the upload. Do not assume the ZIP is upgraded: merge the actual integrity-verified 2.5.0 lock, regenerate `THIRD-PARTY-NOTICES.md`, and rerun the full test suite and `npm audit` on the final archive.

## Limitations to verify before production

Application-level rate limits are process-local and need a shared store or verified edge/WAF rules for multiple instances. The app does not ship a cross-instance rate-limit store. Backup retention, restore point objectives, data archiving, data residency, privacy obligations, availability targets and load capacity depend on the selected host/database and require real deployment tests. This file is not a guarantee that the application has zero vulnerabilities.

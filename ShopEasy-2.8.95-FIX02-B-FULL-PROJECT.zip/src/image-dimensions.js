// Parse image dimensions without decoding untrusted pixels or installing native codecs.
// This is a bounded upload sanity check, not a replacement for a full image decoder.
const MAX_SIDE = 10000;
const MAX_PIXELS = 40_000_000;

export function readImageDimensions(bytes, mime) {
  if (!bytes || typeof bytes.length !== 'number') return null;
  const b = Buffer.isBuffer(bytes) ? bytes : Buffer.from(bytes);
  let width = 0;
  let height = 0;
  if (mime === 'image/png') {
    if (b.length < 33 || b.toString('hex', 0, 8) !== '89504e470d0a1a0a' || b.toString('ascii', 12, 16) !== 'IHDR' || b.readUInt32BE(8) !== 13) return null;
    width = b.readUInt32BE(16);
    height = b.readUInt32BE(20);
  } else if (mime === 'image/jpeg') {
    if (b.length < 4 || b[0] !== 0xff || b[1] !== 0xd8) return null;
    let pos = 2;
    while (pos + 3 < b.length) {
      if (b[pos] !== 0xff) return null;
      while (pos < b.length && b[pos] === 0xff) pos++;
      if (pos + 2 >= b.length) return null;
      const marker = b[pos++];
      if (marker === 0xd9 || marker === 0xda) break;
      if (marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) continue;
      if (pos + 2 > b.length) return null;
      const blockLength = b.readUInt16BE(pos);
      if (blockLength < 2 || pos + blockLength > b.length) return null;
      if ([0xc0,0xc1,0xc2,0xc3,0xc5,0xc6,0xc7,0xc9,0xca,0xcb,0xcd,0xce,0xcf].includes(marker)) {
        if (blockLength < 7) return null;
        height = b.readUInt16BE(pos + 3);
        width = b.readUInt16BE(pos + 5);
        break;
      }
      pos += blockLength;
    }
  } else if (mime === 'image/webp') {
    if (b.length < 30 || b.toString('ascii', 0, 4) !== 'RIFF' || b.toString('ascii', 8, 12) !== 'WEBP') return null;
    const declaredFileSize = b.readUInt32LE(4) + 8;
    const firstChunkSize = b.readUInt32LE(16);
    if (declaredFileSize > b.length || firstChunkSize + 20 > declaredFileSize) return null;
    const kind = b.toString('ascii', 12, 16);
    if (kind === 'VP8X') {
      width = 1 + b.readUIntLE(24, 3);
      height = 1 + b.readUIntLE(27, 3);
    } else if (kind === 'VP8L') {
      if (b[20] !== 0x2f) return null;
      width = 1 + (b[21] | (b[22] & 0x3f) << 8);
      height = 1 + ((b[22] >> 6) | (b[23] << 2) | ((b[24] & 0x0f) << 10));
    } else if (kind === 'VP8 ') {
      if (b[23] !== 0x9d || b[24] !== 0x01 || b[25] !== 0x2a) return null;
      width = b.readUInt16LE(26) & 0x3fff;
      height = b.readUInt16LE(28) & 0x3fff;
    } else return null;
  } else return null;
  if (!Number.isSafeInteger(width) || !Number.isSafeInteger(height) || width < 1 || height < 1 || width > MAX_SIDE || height > MAX_SIDE || width * height > MAX_PIXELS) return null;
  return {width, height};
}

export function imageQualityNotes(dimensions) {
  if (!dimensions) return ['Image dimensions could not be verified.'];
  const notes = [];
  if (dimensions.width < 500 || dimensions.height < 500) notes.push('Use a photo at least 500 × 500 pixels for Google Merchant listings from 31 January 2027.');
  if (Math.abs(dimensions.width / dimensions.height - 1) > 0.10) notes.push('This image is not square; product cards crop the edges. Keep the entire product safely inside the centre.');
  return notes;
}

# Manager guide — ShopEasy R27 / 2.8.95

This guide describes included shop workflows. **Manager** has full management access; **Admin** has a restricted read-only overview. Use the [buyer Admin guide](ADMIN-GUIDE.md) for installation, rights, staging and production handover. Market setup/launch checks do not certify legal, tax, privacy or accessibility compliance.

## Sign in and manage staff

Sign in with the intended Manager account and complete TOTP verification/setup before opening management screens. Save recovery codes privately. **Staff & account** (`/admin/staff`) creates restricted Admin accounts, removes an Admin after current-password confirmation, and changes the Manager email/password. `.env` creates only the first Manager; it never resets existing credentials or creates restricted Admins. Follow [Staff accounts](STAFF-ACCOUNTS.md) for legacy migration and recovery.

New/set/reset passwords require at least 15 trimmed Unicode characters (maximum 200 UTF-16 code units) and reject a small offline list of obvious examples/repetitions. Existing valid passwords still work at login. Use a unique private passphrase; the blocklist is not a complete breached-password check. Do not edit database roles or password hashes by hand.

## Change the store name, appearance and homepage

Open **Storefront** (`/admin/branding`) to set the store name and homepage eyebrow, headline, accent and description. Review separate **English, Sorani Kurdish, Arabic, Dutch and French** fields. Seller-written text is shown as entered, not automatically translated. Use **Preview store** on desktop/phone in every enabled language. Changes preserve products, orders, prices and stock.

An optional dedicated JPG/PNG/WebP hero image (up to 2 MiB) is independent of the first product; removing it returns to the catalogue fallback. The bundled illustrations are examples, not product photography or established commercial-rights evidence. **Appearance** controls the logo, supported visual settings and feature switches. Use only branding/assets the operator has permission to use. Keep API tokens, tax IDs and legal text out of homepage fields; use the appropriate private configuration/Settings fields instead.

## Save setup drafts and review launch readiness

**Settings** can save incomplete business identity, empty delivery coverage and unfinished policies while preparing the store; checkout stays closed until required launch fields are ready. Set the real company/contact details, phone, registration number, prices, time zone and applicable policies. Refresh a long-open settings form after an update. Missing controls preserve their saved values; explicitly clearing countries is allowed but closes checkout. Invalid non-empty inputs are rejected.

The launch gate is a configuration check, not a decision that your business may lawfully accept orders. Check actual market obligations with the responsible operator/advisers.

## Choose currency and time zone

**Settings → Currency & delivery** selects one store currency and an IANA time zone such as `Europe/Brussels`; language, currency and delivery country are separate. ShopEasy does not apply exchange rates or customer currency conversion.

Before the first order, changing currency adjusts product prices/costs/sales, fixed coupons and monetary coupon minimums to the new minor-unit precision in one transaction. For example, a numerical value of 89 is precision-rescaled, not converted to the target currency's market value. Delivery fee resets to zero. Set correct target-market amounts and confirm the separate price-review control before checkout reopens. After the first order exists, the store currency is locked to its historical order currency; a mismatched change is blocked. Existing orders are never converted and aggregate reports assume one currency.

## Configure delivery and tax rules

Enter only **Countries where you actually deliver**. The server rejects checkout destinations outside that allow-list. Set the default **Delivery fee per order** (`0` for free delivery), charged once per order in the store currency.

Optional regional delivery overrides use one rule per line:

```text
Country | City or * | Postal prefix or * | Fee
```

Optional tax rules use:

```text
Country | City or * | Postal prefix or * | Rate % | Tax shipping (yes/no)
```

More-specific city/postal-prefix rules take precedence. When tax rules exist, a destination without a match is blocked. Verify the actual coverage, fee, rate and shipping-tax treatment. These are operator-entered arithmetic rules: no carrier rates/booking/tracking, statutory-rate lookup, product exemptions, thresholds, multiple tax layers, registrations or filings are implemented.

## Enter policy text per language

**Settings → Policy text** has separate English, Sorani Kurdish, Arabic, Dutch and French fields. The basic launch gate requires English policies; missing translations show a notice that English is displayed. Policies are not machine-translated. Have applicable privacy, terms, delivery and return text reviewed for the actual market. Orders snapshot accepted terms locale, timestamp and hash. Policy templates do not establish consent-law, consumer-law or privacy compliance.

## Add products, option combinations and images

Open **Products → Add product**. Enter name, SKU, category, regular price, purchase cost and image. For a simple product, leave **This product has options** off and enter its stock. For options, enable it and set one or two option names, such as `Colour` and `Size`. Add a row for each sellable combination (`Blue / M`, `Blue / L`, etc.), with its own stock, SKU and optional image. One-dimensional options remain supported. Up to **50 unique combination rows** are accepted; this is not an arbitrary multi-dimensional configurator.

Add gallery images and associate a row with the appropriate image. Customers must select an available combination; stock is revalidated server-side. Existing ordered option snapshots remain in order history. Removing a combination makes the stored row inactive; reserved combinations cannot be removed or have stock reduced below reservations. Use clear seller-written names/descriptions and review all language needs yourself.

Price fields:

- **Regular price** is the per-unit price before discounts.
- **Purchase cost per unit** is private Manager input for a gross-profit estimate; it is not full accounting profit.
- **Sale price** is optional, greater than zero and below regular price; optional start/end dates schedule it.
- **Automatic discount %** (0–90%) applies to that product; `0` disables it. The server calculates it separately from coupon discounts.

Comma/point decimals and correctly grouped thousands separators are accepted according to the selected currency's precision; there is no exchange-rate conversion. Check scheduled dates in the configured time zone. SQL catalogue filters/sorts and displayed sale prices use consistent timestamp interpretation.

## Restock and read inventory

Use **Products → Edit → Quick restock / Add stock** for arriving quantities. Enter the **additional** units only; for option products choose the exact row. This changes quantity without rewriting SKU, price, cost, image or order history. The main product form edits the intended stock level and protects reserved stock.

The dashboard counts active products/combinations where available stock is at/below the reorder threshold. It does not email the Manager a low-stock alert. Optional opt-in customer restock emails are separate and require actual email configuration/testing.

## Archive, restore and delete products

Use the **Product status** filter for live/archived items. **Archive** hides a product while retaining history; it refuses active reserved stock. **Restore** republishes an archived product without automatically featuring it. **Delete permanently** is allowed for an active or archived product with no order-item history and no reserved stock. Keep historically ordered products archived rather than deleting financial/support references.

## Discounts, bundles and stories

**Discounts** creates percentage/fixed coupons, optional minimum subtotal and expiry. Product automatic discounts are shown separately in the cart; coupon calculations use the eligible discounted subtotal. Optional **Bundles** rules apply the configured combination discount. Review real cart/checkout totals before enabling any promotion.

**Stories → Create story** accepts title, text, image, publication/expiry dates and optional product/link. Story text is seller-authored. Use only permitted content and verify dates/visibility in the storefront.

## Choose payment methods

**Settings → Payment methods and provider setup** defaults to COD. Enable methods the actual business can operate.

- **Manual bank transfer** saves instructions with the order. Verify the actual bank statement, exact amount/currency and unique transaction reference before using **Confirm bank transfer**. There is no bank API or automatic receipt check.
- **Mollie hosted card checkout** is the implemented card adapter. It needs merchant-country/currency eligibility, private `MOLLIE_API_KEY`, public HTTPS `BASE_URL` and environment gates. Production requires `NODE_ENV=production`, a live key and `MOLLIE_LIVE_CHECKOUT_APPROVED=true`. A dedicated non-production staging host permits a test key only with `MOLLIE_TEST_CHECKOUT_ENABLED=true`. The provider hosts card entry; ShopEasy does not store PAN/CVV. Server API verification binds payment to the order/reference/amount/currency/mode; a browser success page is not payment proof.
- PayTabs, FIB, iyzico, ZainCash and Stripe are **directory/onboarding entries**, not implemented transaction methods. Private representative notes must not contain API keys, bank passwords or card details.

Check eligibility/KYC/payout restrictions with the actual provider using the correct legal country. Do not enter a false country to pass a form. Built-in adapter support does not prove live settlement, refund behavior or onboarding; validate these using controlled staging/provider accounts. Configure keys in the private server environment, never a browser field.

## Manage orders and held stock

**Orders → Open order** shows customer/contact/destination data, item snapshots, verified totals, payment/reference data, notes and status history. Protect this personal information. COD normally moves **pending → processing → shipped → completed**. Completion means cash was actually collected/delivery completed; it consumes stock and records the cash-received reference. Verified card/bank/gift-card payments use **paid → processing → shipped → completed**. Use only actions currently allowed by the server.

New pending orders have **no automatic reservation timeout**. Reserved stock remains held through active fulfilment; completion consumes it, and supported cancellation releases it once. A paid marker alone does not remove physical on-hand stock. Check stale pending orders manually. The order list shows age with exact time available; it is not an expiry countdown.

For a Mollie attempt with an uncertain/missing local reference, reconcile the exact payment ID from the provider dashboard. ShopEasy fetches/validates it; entering an ID alone does not mark the order paid. **Refresh financial status** records provider-reported refunded/charged-back totals and does not send money. Legacy pending orders can be confirmed as COD only through the guarded action when no online-payment details exist and stock reservations are intact.

## Customer access and cancellation

Registered order access requires the authenticated owner. Guest lookup/actions require the valid bearer through the protected HttpOnly cookie or explicit private-code POST field; email plus order number is insufficient and URL bearers are rejected. Lost guest access needs the operator's identity-checked support process.

- Pending COD customers can cancel through the supported form; inventory is released once transactionally.
- Processing COD customers can submit a reasoned cancellation request; cancellation waits for Manager acceptance.
- Pending bank-transfer cancellation is request-only so the Manager can check actual receipt first.
- Paid card/bank/gift-card orders do not offer a general pre-shipment provider refund workflow; resolve payment and customer support before any permitted action.
- Shipped/completed orders use contact/returns handling instead of ordinary pre-delivery cancellation.

Do not force a rejected action with manual database edits. Refresh the order, reconcile payment/reservations and record what actually happened.

## Returns, exchanges and refunds

Open **Returns** to approve/reject a request, record arrival, inspect and optionally restock. Record a refund only after money was sent using the real method; record exchange shipment/reference and close after confirmed delivery. The return tool records events; it does not contact a bank, execute a Mollie refund or book/track a courier. Gift-card credit is a separate internal ledger action. Verify exact quantities/amounts and avoid duplicate external/internal refunds.

## Gift cards, customer engagement and invoices

**Gift cards** can enable the feature, issue a currency-bound card and inspect balances/ledger. Keep a new code private; stored codes are hashed. A gift card must cover the complete order; split tender is not implemented. Use the guarded credit/refund action with actual order context.

**Reviews** moderates verified-purchase reviews. **Newsletter** creates campaigns and sends bounded batches to eligible confirmed subscribers. Stock alerts also require confirmation. Check consent/retention and actual email delivery. Order-confirmation/status email is separately opt-in and off by default; there is no general carrier-tracking or Manager order-notification integration.

**E-invoicing** provides the configured Recommand/Peppol submission path and tracking; recipient acceptance and legal/tax correctness must be verified for the actual market. A generated record/PDF is not proof of structured-invoice delivery or full accounting compliance.

## Optional AI

**Settings → Optional AI** controls the feature when a private server-side endpoint/key/model are configured. The key is never shown in the browser. AI expands bounded search phrases and can answer shopping questions using up to 12 public catalogue entries. Search results still come from active real products; AI cannot set authoritative price/stock, and model instructions do not guarantee answer accuracy. Disable the setting/environment flag to turn it off; follow [AI integration](AI-INTEGRATION.md) when changing/removing the module. Review external data/costs and provider configuration; pattern redaction is not a guarantee that every identifier is removed.

## Privacy, audits and recovery

Use **GDPR** only after verifying the requester and reviewing the operator's documented retention/legal-hold policy. Choose export, eligible deletion or explicit financial-record minimization. Minimization requires the policy reference and acknowledgement and retains financial references/ledger; it is pseudonymous retained data, not certified legal erasure/anonymity. Read the complete [privacy procedure in the Admin guide](ADMIN-GUIDE.md#5-use-privacy-actions-under-a-documented-policy) before acting. Account roles, backups and records held by outside services require separate processes.

**Audit** shows application events; protect logs and investigate failed or inconsistent changes before retrying. [Backup and restore](DATABASE-BACKUP-RESTORE.md) covers encrypted DB/media backups and restore into a separate empty target. Secure keys separately and rehearse recovery. [Deployment](DEPLOYMENT.md) code rollback does not restore database state. Actual host/provider delivery/settlement, Windows/macOS and complete accessibility/security coverage remain separate validation work described in [Features and limitations](FEATURES-AND-LIMITATIONS.md).

#!/usr/bin/env node
import dotenv from 'dotenv';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
dotenv.config({ path: path.join(root, '.env'), quiet: true, debug: false });
const defaultBackupDir = path.resolve(root) === '/opt/shopeasy' ? '/opt/shopeasy/backups' : path.join(root, '..', 'ShopEasy-backups');
const outputDir = path.resolve(String(process.env.OFFSITE_BACKUP_DIR || defaultBackupDir).trim());
const host = String(process.env.OFFSITE_SSH_HOST || 'ubuntu@JOUW_PUBLIEKE_IP').trim();
const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
const filename = `shopeasy-offsite-${timestamp}.jsonl.gz.enc`;
const outputPath = path.join(outputDir, filename);
const checksumPath = `${outputPath}.sha256`;

function sha256File(file) {
  return new Promise((resolve, reject) => {
    const hash = createHash('sha256');
    const stream = createReadStream(file);
    stream.on('data', chunk => hash.update(chunk));
    stream.on('error', reject);
    stream.on('end', () => resolve(hash.digest('hex')));
  });
}

function runBackup() {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [path.join(root, 'scripts', 'backup-database.mjs'), '--output', outputPath], {
      cwd: root,
      env: process.env,
      stdio: 'inherit'
    });
    child.once('error', reject);
    child.once('close', code => code === 0 ? resolve() : reject(new Error(`backup-database.mjs exited with code ${code}`)));
  });
}

try {
  if (!String(process.env.BACKUP_ENCRYPTION_KEY || '').trim()) {
    throw new Error('BACKUP_ENCRYPTION_KEY ontbreekt. Bewaar een willekeurige 32-byte sleutel apart van de back-up.');
  }
  fs.mkdirSync(outputDir, { recursive: true, mode: 0o700 });
  await runBackup();
  const stat = fs.lstatSync(outputPath);
  if (stat.isSymbolicLink() || !stat.isFile() || stat.size < 32) throw new Error('Encrypted backup output is not a valid regular file.');
  fs.chmodSync(outputPath, 0o600);
  const digest = await sha256File(outputPath);
  fs.writeFileSync(checksumPath, `${digest}  ${filename}\n`, { mode: 0o600 });
  fs.chmodSync(checksumPath, 0o600);

  console.log('Versleutelde SQLite/logische back-up klaar.');
  console.log(`Bestand: ${outputPath}`);
  console.log(`SHA-256: ${digest}`);
  console.log('Download in Windows PowerShell:');
  console.log(`scp -i "$env:USERPROFILE\\.ssh\\id_ed25519" ${host}:/opt/shopeasy/backups/${filename} .`);
  console.log(`scp -i "$env:USERPROFILE\\.ssh\\id_ed25519" ${host}:/opt/shopeasy/backups/${filename}.sha256 .`);
  console.log('Bewaar BACKUP_ENCRYPTION_KEY apart van beide gedownloade bestanden.');
} catch (error) {
  console.error(`Offsite-back-up mislukt: ${String(error?.message || 'onbekende fout').slice(0, 300)}`);
  process.exitCode = 1;
}

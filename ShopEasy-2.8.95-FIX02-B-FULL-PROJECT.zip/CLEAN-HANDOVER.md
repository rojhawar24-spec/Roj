# ShopEasy 2.8.95 — R28 technical release candidate

> **REMEDIATION CANDIDATE FIX02-B — 24 November 2026.** Not release-certified. See [REMEDIATION-FIX02-B.md](REMEDIATION-FIX02-B.md) for current evidence and [REMEDIATION-FIX02-A.md](REMEDIATION-FIX02-A.md) and [REMEDIATION-FIX01.md](REMEDIATION-FIX01.md) for prior work. All historical R28 evidence is baseline only.


VERIFIED — The R28 implementation changes, current acceptance status and remaining limits are recorded in [the cleanup report](R28-CLEANUP-REPORT.md) and [QA report](QA-REPORT-2.8.95.md). Earlier cleanup evidence remains historical, not proof about this source. Product features are retained; deliberate behavior changes are listed in the change record.

The source package retains application code/assets, generated runtime templates, tests, operational scripts, documentation, required preview fixtures, exact package lock, third-party notices and legal drafts. Installed dependencies, private environments, databases, uploads, backups and QA interpreter/tool installations are excluded. Synthetic test databases and random test credentials are disposable and are not buyer demo accounts.

VERIFIED — In the delivered ZIP, `SHA256SUMS.txt` covers every other regular file. Run `npm run verify:package` in a fresh extraction before installation. The external `CONTENTS.json` enumerates the actual ZIP members and digest. [Release verification](RELEASE-VERIFICATION.md) describes the final re-extraction checks. A digest verifies consistency; obtain it through a trusted channel to establish sender authenticity.

UNKNOWN — Source/asset ownership, effective commercial transfer/rebranding/sublicensing grant and nine native component review gates remain open. This is NOT CLEARED FOR COMMERCIAL RESALE. Read [rights clearance](RIGHTS-CLEARANCE-REGISTER.md). Technical cleanup cannot supply missing rights.

NOT TESTED — Actual Windows PowerShell5.1/macOS operation, live providers, deployed TLS/CDN/load, offsite production recovery, complete manual WCAG2.2AA/ASVS assessment and every-file manual semantic review. Read [limits](FEATURES-AND-LIMITATIONS.md) and [browser setup](qa/README.md).

# ShopEasy 2.8.95 / R28 actual local QA

> **REMEDIATION CANDIDATE FIX01 — 24 November 2026.** This derivative of R28 is not release-certified. All R28 test results and fingerprints below refer to the unchanged baseline, not this modified source. See [REMEDIATION-FIX01.md](REMEDIATION-FIX01.md) for current evidence and limitations.


NOT TESTED — This release is **NOT production-certified**. Local automated observations do not establish live deployment, complete security/accessibility or commercial rights.

VERIFIED — Executed on Linux, 22 November 2026, Node 24.22.2 and Python 3.13.5. Browser: Playwright 1.62.0 with selected Node 24.22.2 driver, Chromium 156.0.8078.79, axe-core 4.11.0. Lighthouse 13.6.0. [Commands and full Node output](docs/qa/r28/final/checks/group-c-summary.json), [test output](docs/qa/r28/final/checks/group-c-tests.txt).

| Execution | Actual result | Evidence |
| --- | --- | --- |
| Full integration suite | 1205 tests/pass1205/fail0/cancelled0/skipped0/todo0 | [Output](docs/qa/r28/final/checks/group-c-tests.txt) |
| Build/syntax/lint/core types/static/preflight/templates/notices/all+production advisory commands | All eleven group-C commands exit0; advisory queries 0 known advisories | [Commands](docs/qa/r28/final/checks/group-c-summary.json) |
| Five-locale browser at 320/390/768/1440 | 201 checks,0 failed/not run,43 strict axe scans,0 violations | [Summary](docs/qa/r28/final/browser-final-01/final-browser-summary.json) |
| Drawer variant | 10/10 focused keyboard groups | [Results](docs/qa/r28/final/browser-drawer-final-01/browser-results.json) |
| Fresh 320px Shop/Contact | 28/28 checks,12 strict scans,0 violations,24 incomplete rule items | [Results](docs/qa/r28/final/browser-fresh-mobile-02/browser-results.json) |
| Private-CA real loopback HTTPS | 18/18 | [Results](docs/qa/r28/final/tls-final-01.json) |
| Synthetic sitemap crawl | 115 URLs,3 sitemaps,all200,0 reported page problems | [Results](docs/qa/r28/final/seo-final-01.json) |
| Current-source encrypted backup/restore CLI | 20/20,exact schema/rows/BLOB/filesystem comparison and negative refusals | [Results](docs/qa/r28/final/backup-final-01/r28-results.json) |
| Final Docker build/runtime | Build0,1205 tests inside build,uid1000,readiness/Login200 | [Results](docs/qa/r28/final/container-final-01/results.json) |
| Frozen runtime Lighthouse | 3 Home mobile runs:99/100/100/100;3 Shop desktop:100/100/100/100 | [Measurements and limits](docs/qa/r28/final/lighthouse-frozen-01/README.md) |

NOT TESTED — Full manual resolution of **84 main axe incomplete rule items**:41 contrast/421 node occurrences and43 hidden-content/670 occurrences. The mobile supplement's24 are additional scan observations, not necessarily distinct defects. Scores of100 in selected Lighthouse categories are automated category results, not a whole-site/security/WCAG score.

SOURCE-CHECKED — Core typecheck covers four modules only. The exact lock inventory has107 node_modules rows (106 external,one local),114 notice texts,0 collector gaps and nine native gates UNKNOWN. [Dependency decision](docs/qa/r28/dependencies/DEPENDENCY-UPGRADE-REPORT.md).

VERIFIED — Earlier group-A and group-B failures are retained under [checks](docs/qa/r28/final/checks/group-a-summary.json). They led to actual fixes or correction of obsolete source-contract expectations; group C is the later complete successful run. The fresh-mobile first attempt used an incorrect theme oracle and failed before scans; its corrected run uses unchanged application bytes. The Lighthouse blocked-startup record is retained and excluded from the six measurements.

VERIFIED — Final packaging attempt01 completed1205 tests with1203 passing and2 documentation failures: a missing current-QA link and missing explicit production-certification disclaimer. Both document omissions were corrected without changing tests or runtime. Its output is retained under `docs/qa/r28/final/package-attempt01/`; the accepted final external verification log records the subsequent complete rerun.

VERIFIED — Attempt02 completed1205 tests with1204 passing and1 remaining documentation failure: the historical October-audit link was also required by the documentation test. That link was restored and both complete documentation test files were checked before the next full fresh packaging run. Its actual output is retained under `docs/qa/r28/final/package-attempt02/`.

NOT TESTED — Actual Windows, physical/assistive-device matrix, public hosting, provider flows, remote-database faults, offsite recovery and a full manual every-file/WCAG/ASVS audit. UNKNOWN — Ownership, sale authority, actual private credential/history facts and native composition. See [audit](AUDIT-REPORT.md), [buyer commands/checklist](docs/qa/r28/BUYER-RERUN-CHECKLIST.txt) and [release verification](RELEASE-VERIFICATION.md).

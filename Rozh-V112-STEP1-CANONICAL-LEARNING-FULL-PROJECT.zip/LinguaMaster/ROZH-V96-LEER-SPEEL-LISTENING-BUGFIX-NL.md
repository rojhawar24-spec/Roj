# Rozh V96 — Leer & Speel: blanco pagina bij /lessons/3/

## Aangetoonde oorzaak
De startercurriculum-seed publiceerde luisterlessen zonder gecontroleerde opnames. `academy/static/academy/audio-v78/catalog.json` heeft op dit moment 0 goedgekeurde clips. De leerlingroute maakte alsnog een link naar de gepubliceerde luisterles. Het Django-view gaf dan op GET een kale HTTP 409 (`Listening lesson has no approved recording.`), waardoor een witte pagina zonder Rozh-navigatie verscheen.

## Reparatie in deze VOLLEDIGE project-ZIP
- Een gedeelde read-only beschikbaarheidscontrole voor audio en andere begeleide activiteiten.
- Leerpad, dashboard, eenheidspagina en `Volgende les` linken niet meer naar onbeschikbare luisterlessen.
- Rechtstreeks bezoeken van een nog-gepubliceerde luisterles zonder goedgekeurde audio geeft een vormgegeven, Nederlandstalige/Sorani/Engelstalige/Arabische HTTP 409-pagina met veilige terugknoppen, geen witte foutpagina.
- Mixed/structured lesson krijgt dezelfde veilige en duidelijke foutpagina.
- Nieuw gezaaide luisterlessen zonder goedgekeurde opname worden **concept** in plaats van gepubliceerd. Bestaande lesrecords worden nooit automatisch bijgewerkt of verwijderd.
- Read-only inspectie van oudere lokaal gepubliceerde luisterlessen met `repair_listening_publication`; optioneel expliciet conceptstatus toepassen met `--apply` en verhoogde `content_version`. Geen wijzigingen aan resultaten, XP, accounts of harten.

## Test in Windows zonder je echte installatie te raken
1. Download de nieuwe volledige ZIP en pak deze uit in een **nieuwe lege map**. Gebruik geen echte `.env` of `db.sqlite3`.
2. Open PowerShell in `LinguaMaster` en voer uit:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\START-ROZH-TEST.ps1
```

3. Open `http://127.0.0.1:3000/login/` en test `Leer & Speel`. De ongeautoriseerde audio wordt niet afgespeeld of nagemaakt.
4. Voor een **bestaande, geïsoleerde QA-database binnen die nieuwe codekopie**, sluit eerst de lokale server met Ctrl+C en voer een **read-only audit** uit:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\CHECK-ROZH-V96-LISTENING-QA.ps1
```

5. Alleen indien je een lijst met onbeschikbare gepubliceerd luisterlessen hebt beoordeeld, voer de optionele reparatie uit. De PowerShell-runner maakt vooraf een nieuwe SQLite backup in `.rozh-local-test` en weigert externe databases:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\CHECK-ROZH-V96-LISTENING-QA.ps1 -Apply
```

De voorgaande commando's zijn voor **lokale QA** en niet voor productie. Haal je oude ontwikkel-DB niet automatisch over naar een nieuwe ZIP, en overschrijf geen echte projectinstallatie. Voor migratie van eigen gegevens is een afzonderlijk, getest migratieplan nodig.

## Nog expliciet open
De volledige Django HTTP-tests, echte databasemigratie, PostgreSQL, Windows-ACL’s en de complete production/staging-browser- en toegankelijkheidstesten zijn in de bouwomgeving niet uitgevoerd: Django ontbreekt. Chromium op een **geïsoleerde HTML/CSS-testpagina** is wél uitgevoerd. Dus deze release is een geteste bugfixkandidaat, **niet 100% productiegoedgekeurd**.

Om echt audio te tonen moet een editor een opname aanleveren, controleren, hash-verifiëren en in het goedgekeurde audiocatalogusproces publiceren. Het is onveilig om een bestand of browser-TTS automatisch als goedgekeurde opname te markeren.

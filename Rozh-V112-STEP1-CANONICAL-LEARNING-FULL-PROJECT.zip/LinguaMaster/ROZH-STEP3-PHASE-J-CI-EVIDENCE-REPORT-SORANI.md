# Rozh V95 — هەنگاوی ٣، بەشی J: دەروازەی بەڵگەی CI

**دۆخ: J هێشتا بە فەرمی داخراو نییە.** ئەم وەشانە تەنها کۆکردنەوەی بەڵگەی جێبەجێکردنی ڕاستەقینەی سێ ژینگەی تاقیکردنەوە زیاد دەکات. ئەو تاقیکردنەوانە لەم ژینگەیەدا ڕانەکراون.

## چی نوێیە؟

١. `scripts/phase_j_runtime_evidence.py` — هەر runtime job ـێک دەتوانێت تەنها لە GitHub Actions و لە ژینگەی پەیوەندی خۆیدا `receipt.json` بە `GITHUB_SHA`، `GITHUB_RUN_ID`، `GITHUB_RUN_ATTEMPT`، ناوی job و سیستەمی کارپێکردن دروست بکات. ئەم تۆمارانە دوای سەرکەوتنی تاقیکردنەوە ڕاستەقینەکان دروست دەکرێن.
٢. `.github/workflows/rozh-step2-qa.yml` — Ubuntu Django/SQLite، PostgreSQL 17 و Windows 2022 هەر یەک بەڵگەی جیاواز بار دەکەن. `phase-j-gate` دەبێت سێ بەڵگەکە دابگرێت و پشکنیانی هەمان commit، run و retry بکات. بەڵگەی ون، هەڵە یان تێکەڵکراو ڕەت دەکرێتەوە.
٣. `scripts/test_step3j_runtime_receipt_gate_offline.py` — **١٠ تاقیکردنەوەی نوێ** بۆ بەڵگەی ون، SHA ـی هەڵە، retry ـی جیاواز، OS ـی هەڵە، status ـی ناپەسەند، symlink و دۆخی سەرکەوتوو.
٤. `ROZH-STEP3-FIXED-REMAINING-STEPS.json` نوێکراوەتەوە؛ هێشتا **٥ پشکنینی ڕاستەقینە** لە J ماون و پڕۆژەکە بەرهەمهێنانی گشتی/قوتابخانە پەسەند نەکراوە.

## ئەنجامەکانی ئەم ژینگەیە

- ٣٠/٣٠ سکریپتی offline/browser سەرکەوتوون؛ ٣١٠/٣١٠ تاقیکردنەوەی ژمێردراو سەرکەوتوون. دوو smoke script ـیش سەرکەوتوون بەبێ ژمارەی unittest.
- پشکنینی Python AST، Node JavaScript syntax، GitHub Actions YAML و هاشەکانی ZIP جێبەجێ کراون.
- Django و psycopg لەم ژینگەیەدا دانەمەزراون و دامەزراندنی package لە سەرچاوەی دەرەکی سەرنەکەوت؛ بۆیە HTTP/Django/SQLite، migration 0019، PostgreSQL و Windows runtime لێرە **نەکراون**.
- ئەم receipt ـانە **بەڵگەی CI** ـن، نەک واژۆی کریپتۆگرافی؛ ئەگەر ئەکاونتی repository بە خراپی دەستکاری کرابێت، جێگری security audit نین.

## بۆ داخستنی J

لە GitHub repository ـی تایبەتی پڕۆژەکەدا، ناوەڕۆکی `LinguaMaster/` دەبێت لە ڕیشەی repository ـدا بێت؛ واتە `manage.py` لە ڕیشەدا بێت. پاشان Actions → **Rozh Step 2 + 3 - isolated Django/SQLite QA** → **Run workflow** جێبەجێ بکە.

پێویستە `django-integration`، `django-postgres-concurrency` و `windows-acl-and-sqlite` هەموویان PASS بن و `phase-j-gate` بەڵگەی `phase-j-runtime-summary` بڵاو بکاتەوە. لەو کاتەدا دەکرێت بەڵگەی ئەو ٥ runtime check ـە هەڵبسەنگێندرێت؛ **ناتوانرێت تەنها بە بوونی ئەم فایلانە J بە داخراو هەژمار بکرێت.**

## ژمارەی ماوەکان

- J: **٥** پشکنینی runtime هێشتا بەڵگەی ڕاستەقینەیان نییە.
- هەنگاوی ٣: **٣ بەش J، K، L**؛ دوای J **٢ بەش** ماون.
- لە ١٠ هەنگاوی سەرەکی: ئێستا هەنگاوی **٣**؛ لەگەڵ ئێستا **٨** هەنگاو ماون، دوای ئەمە **٧**.
- Production/School: **پەسەند نەکراوە**.

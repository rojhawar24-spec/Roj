# Rozh — هەنگاوی ٣، بەشی H — Durable Round Receipts

**دۆخ: تەنها Offline/Browser پشکنراوە؛ Django HTTP، Migration و Database ڕانەکراون. بۆ قوتابخانە/production پەسەند نییە.**

## کێشەی بنەڕەتی Phase G

هەڵگرتنی کاناڵی AJAX/SSR و وەڵامی نێردراو تەنها لە Session دەتوانێت لە دوو داواکاریی هاوکاتدا شێوازی کۆن بەکاربهێنێت؛ بە تایبەتی وەڵامی ڕاست HeartEvent نییە و بە تەنها تۆماری دڵ ناکرێت دووبارە ناردنەوە بگرێت. Phase G لە Session پاراستنی هەبوو، بەڵام جێگری پاراستنی Database نەبوو.

## گۆڕانکارییەکانی Phase H

١. `academy/lesson_round_models_step3h.py` و migration ـی نوێی `academy/migrations/0019_lesson_round_receipt_step3h.py` تۆماری ناوخۆیی `LessonRoundReceipt` زیاد دەکەن. بۆ هەر `(user, lesson, round_key)` یەک تۆمار هەیە، و کاناڵی گریندینگ، boolean ـی ئەنجامی پرسیارەکان، و دۆخی تەواوبوون هەڵدەگیرێت. وەڵامی دەقی فێرخواز لەو تۆمارەدا هەڵناگیرێت.
٢. `academy/lesson_round_receipts_step3h.py`: پاراستنی کاراکردنی کاناڵ، دووبارە ناردنی پرسیار و Round ـی تەواوبوو بە یەک ریزبەندیی کۆدی داتابەیسی قوفڵکراو.
٣. `academy/views.py`: AJAX لە پێش `spend_for_answer` و `record_exercise_result` ـدا تۆماری داتابەیسی دەپشکنێت. SSR لە ناو transaction/savepoint ـی batch ـدا هەمان یاسا بەکار دەهێنێت. ناردنی SSR ـی ناتەواو بەهۆی کەمی دڵ دەبێت هەموو گۆڕانەکان هەڵبوەشێنێتەوە. Legacy MCQ/short ـی نەدەرچوو دەتوانێت لە هەمان کاناڵ دووبارە هەوڵ بدات؛ Round ـی تەواو قوفڵ دەکرێت.
٤. `scripts/test_step3h_durable_round_offline.py`: ٢٢ تاقیکردنەوەی policy/AST، کە هەمان policy فانکشنەکانی کۆدی production دەخوێننەوە.
٥. `academy/test_step3h_durable_round_receipts_http.py`: ٩ تاقیکردنەوەی نوێی HTTP/SQLite بۆ دووبارە ناردن، گومانی Session ـی کۆن، یەکتایی، XP، دڵ و rollback. **ئەم ٩ تاقیکردنەوەیە لەم ژینگەیەدا ڕانەکراون.**
٦. Runner ـی Windows و GitHub Actions ـی هەبوو نوێکرانەوە تا `makemigrations --check --dry-run`، test ـی Step 3H، و هەموو academy Django regression لە ژینگەی تاقیکردنەوە ڕابکەن. **هیچ workflow ـێک لەم ژینگەیەدا ڕانەکراوە.**

## پشکنینی بەڵگەدار

- Phase 3: ٢٠/٢٠ کۆمەڵەی Offline/Chromium = **٢٠٣/٢٠٣ تاقیکردنەوە PASS**.
- Step 2: ١٠/١٠ کۆمەڵەی Offline = **١٥٠/١٥٠ تاقیکردنەوە PASS**.
- پشکنینی syntax، ZIP و SHA-256 لە کۆپییەکی تازە دوبارە دەپشکنرێن.
- ئەنجامی Django HTTP و SQLite: **NOT EXECUTED**؛ پەکیجی Django لەم ژینگەیەدا نییە. ئەنجامی Migration ـی 0019 لە داتابەیسی ڕاستەقینە **پشتڕاست نەکراوەتەوە**.

## سنووردارییە گرنگەکان

- `select_for_update` لە PostgreSQLدا row lock بەکار دەهێنێت؛ SQLite هەمان ڕەفتاری نییە. دەبێت تاقیکردنەوەی دوو داواکاریی هاوکات لە PostgreSQL staging، دوای migrations، ئەنجام بدرێت.
- تۆماری نوێ بۆ Round ـەکان پێویستی بە پلانێکی retention/cleanup هەیە پێش production؛ سڕینەوەی بێ‌پلان دەتوانێت پاراستنی replay لاواز بکات.
- بۆ پڕۆژەی هەبووی production، migration ـی نوێ دەبێت پێش start ـی کۆدی نوێ و دوای backup لە ژینگەی تاقیکردنەوەدا بپشکنرێت؛ هیچ دیتابەیسی بەکارهێنەر لێرە دەستکاری نەکراوە.
- هەنگاوی ٢ و ٣ هێشتا پشکنینی تەواوی ڕاستەقینەی Django، داتابەیس، مۆبایل، WCAG و فێرکارییان ماوە؛ هیچ ئەنجامێکی ١٠٠٪ بانگەشە ناکرێت.

## ڕێگای تاقیکردنەوەی ڕاستەقینە

لە کۆپییەکی پاکی ZIP لە Windows و لە فۆڵدەری `LinguaMaster` ڕابکە:

```powershell
cmd /c .\RUN-ROZH-V95-STEP2-QA.cmd
```

ئەم runner ـە بە شێوەی جیاکراوە پەکیجەکان، migration parity، تاقیکردنەوەی Step 2 + 3، و هەموو Django academy تاقی دەکاتەوە؛ **لێرە ڕانەکراوە**.

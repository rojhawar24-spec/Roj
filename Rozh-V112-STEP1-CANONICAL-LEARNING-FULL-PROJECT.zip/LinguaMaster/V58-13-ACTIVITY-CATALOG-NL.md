# Rozh V58 — Catalogus van de 13 Leer & Speel-activiteiten

**Doel:** verschillende, echte lesoefeningen toevoegen aan de bestaande Django-cursussen, zonder betaalde AI- of spraak-API. Alle activiteiten worden handmatig door een bevoegde beheerder geschreven, gecontroleerd en aan een bestaande les gekoppeld. Een nieuw activiteitstype maakt zelf geen les aan en publiceert niets automatisch.

| Nr. | Manager `kind` | Leeractiviteit | Invoer voor de beheerder |
|---:|---|---|---|
| 1 | `mcq` | Multiple Choice | Vraag, 2–6 antwoordopties, correct antwoord, feedback |
| 2 | `sentence_builder` | Sentence Builder | Woordtegels, volledig correct geordende zin |
| 3 | `picture_match` | Picture Match | Een lokale foto, beschrijvende `image_alt`, 2–6 woorden, juist woord |
| 4 | `fill_blank` | Fill in the Blank | Zin met exact één `___`, ontbrekend woord |
| 5 | `word_matching` | Word Matching | 2–8 verschillende linker/rechter woordparen |
| 6 | `listening` | Listening Challenge | Zelfgeschreven `audio_text`, 2–6 keuzes, juist antwoord |
| 7 | `true_false` | True or False | Bewering en exact `True` of `False` als antwoord |
| 8 | `spelling` | Spelling Challenge | Gevraagde schrijfwijze en correct gespeld antwoord |
| 9 | `word_order` | Word Order | Woordtegels, volledige juiste zin |
| 10 | `find_mistake` | Find the Mistake | Foutieve zin, 2–6 selecteerbare delen, fout deel |
| 11 | `memory_match` | Memory Match | 2–8 linker/rechter kaartparen |
| 12 | `choose_image` | Choose the Image | 2–6 lokale foto's met unieke labels, juist label |
| 13 | `complete_conversation` | Complete the Conversation | 1–5 korte dialoogzinnen, 2–6 antwoorden, juiste vervolgregel; geen vertakkende chat |

## Beheerder: stappen om veel lessen te maken

1. Maak of kies een bestaande gepubliceerde cursus, CEFR-niveau, unit en les. Bewaar desgewenst de nieuwe les eerst als concept.
2. Ga naar **Manager > Content > Exercises** en maak een nieuwe oefening bij precies die les.
3. Kies de `kind`. Vul `prompt`, `explanation`, `options`, `answer` en indien nodig `activity_data` in. De Manager toont per type een aanwijzing met voorbeeldvelden; dit is **nog geen drag-and-drop-editor**.
4. Gebruik voor `options` een JSON-lijst, zoals `["is","am","are"]`. `activity_data` is een JSON-object, zoals `{}` wanneer extra velden niet nodig zijn.
5. Voor matching: `activity_data` bevat `{"pairs":[{"left":"apple","right":"fruit"},{"left":"chair","right":"furniture"}]}`. Laat `options` en `answer` leeg. De server bepaalt zelf de juiste matches.
6. Voor een afbeelding: `{"image":"academy/photos/books.jpg","image_alt":"Een stapel boeken op tafel"}`. Upload alleen beelden waarvoor je toestemming of een passende licentie hebt. Beschikbare bestandsformaten: PNG, WEBP, JPG/JPEG. Alleen vooraf toegestane lokale paden zijn geldig.
7. Voor Choose Image: `{"images":[{"label":"books","path":"academy/photos/books.jpg"},{"label":"train","path":"academy/photos/train.jpg"}]}`. Het antwoord is exact één label; de alt-tekst bij de keuze is het label.
8. Voor luisteren: `{"audio_text":"I am happy."}`. Browser/OS-tekst-naar-spraak is gratis, maar stemkwaliteit en beschikbaarheid verschillen per apparaat en taal; de leerling kan een transcript bekijken.
9. Controleer het resultaat in **beide** lesroutes waar relevant: `/lessons/<id>/` en `/journey/levels/<id>/`. Publiceer uitsluitend geteste, inhoudelijk correcte lessen. Bij het aanpassen van een oefening kan een lopende leerbeurt ongeldig worden en opnieuw moeten starten.

## Beperkingen en veiligheid

- De bestaande `short`-opgave is behouden voor oudere lessen; er zijn **13 geplande types**, niet 14 nieuwe types.
- Nieuw `Speaking Practice` en `Translation Challenge` zijn uitgesloten. Bestaande historische zelfbeoordelingsopgaven uit oude releases zijn niet gewist.
- Servercontrole van antwoorden, sessierondecontrole en bestaande leer-/XP-/hartjesregels zijn bedoeld om vervalste client-antwoorden te beperken. Bevestig dit nog met live Django-integratietests.
- Er worden **geen** antwoorden of nieuwe demo-oefeningen aan leerlingaccounts toegevoegd.
- De databankmigratie `0014_exercise_activities_v58` moet op een **back-up van de testdatabase** worden uitgevoerd, alvorens productie bij te werken.
- V58 is offline met statische browserfixtures en geselecteerde Python-contracttests getest. Er is **geen** live Django/DB-integratietest uitgevoerd in deze werkomgeving; dit is geen bewijs van productiegereedheid.

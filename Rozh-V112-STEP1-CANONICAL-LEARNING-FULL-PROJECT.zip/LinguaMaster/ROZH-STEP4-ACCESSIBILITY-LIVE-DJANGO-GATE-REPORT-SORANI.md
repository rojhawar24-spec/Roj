# Rozh V95 — هەنگاوی ٤: فۆکەسی My Season، Chromium Accessibility و دەروازەی Django

**دۆخ: هەنگاوی ٤ `IN_PROGRESS`، نەک ١٠٠٪.** هەنگاوەکانی ٢ و ٣ هێشتا ناتەواون؛ `production_approved=false`.

## چاکسازییەکانی ئەم وەشانە

١. **چاکسازیی ڕاستەقینەی کیبۆرد:** کاتێک بەکارهێنەر لە وەرزێکی تر «My Season» دەکات، دوگمەکە لەسەر وەرزی خۆی ناچالاک دەبێت و لە کۆدی پێشوو فۆکەس بۆ `BODY` دەچوو. پێش چاکسازی ئەمە لە Chromium و Node دووبارە دروست کرایەوە (Red)، دوای چاکسازی تاقیکردنەوەکان سەرکەوتن (Green). هیچ ڕێگای unlock ـی وانە، XP، داتابەیس یان مۆڵەت نەگۆڕاوە.
٢. **Chromium Accessibility Tree:** ناوی سۆرانی هەڵبژێری وەرز، دوگمەکانی Previous/Next و role=status لە ڕووکارە جیاکراوەکەدا لە ڕێی CDP پشکنران.
٣. **خێرایی synthetic ـی browser:** ٢٠ گۆڕینی وەرز لە ١٠٠ وەرزدا لە Chromium ـی ڕاستەقینە، بە CSS/JS ـی پڕۆژە، تاقی کرانەوە. ئەمە تەنها smoke test ـە؛ بەڵگەی Performance لە ئامێری واقعی نییە.
٤. **دەروازەی Django LiveServer:** `scripts/step4_live_learning_path_browser_qa.py` زیاد کرا. لە disposable Django test DB دا ١٠٠ وەرز و ١٠٠ وانە دەنێت، هەژماری تاقیکردنەوە دروست دەکات، Chromium بە session ـی تاقیکردنەوە دێنێتە وێبسایتی واقعی و 360px/RTL/کیبۆرد/Locked/deep link/Light-Dark دەپشکنێت. ئەم فایلە بە GitHub Actions `django-integration` پەیوەست کرا **دوای دامەزراندنی Chromium** و پێش CI receipt.
٥. **لیستی وەرگرتن:** `ROZH-STEP4-ACCEPTANCE-CHECKLIST-SORANI.md` دەروازەکانی ٤ گرووپ و بەڵگەی داواکراو دیاری دەکات.

## ئەنجامی ڕاستەقینەی ئەم ژینگەیە

- **٤١ لە ٤١** سکریپتی offline/fixture سەرکەوتوون.
- **٤٢٩** تاقیکردنەوەی ژمێردراو، لەوانە **١٧** تاقیکردنەوەی Node.js و **١٦** Chromium لەسەر HTML fixture ـی جیاکراوە.
- **٦٥٧** فایلی Python بە AST، **٤٤** فایلی JavaScript بە `node --check` پشکنراون.
- Workflow ـی GitHub Actions و پەیوەستبوونی تاقیکردنەوە نوێیەکە پشکنراوە.
- تاقیکردنەوەی Chromium پشکنینی browser ـی ڕاستەقینەیە، بەڵام **پەڕەی Django ـی ڕاستەقینە نییە**.
- **Django لەم ژینگەیەدا دامەزراو نییە.** هەوڵی داگرتنی `Django==6.1.3` سەرنەکەوت؛ `manage.py`، browser LiveServer، دەستی Screen Reader و تاقیکردنەوەی Performance ـی ئامێری واقعی جێبەجێ **نەکراون**.

## چوار گرووپی ماوە بۆ «١٠٠٪»

١. Django HTTP / migrations و ١٠٠ وەرز لە داتابەیسی جیاکراوە.
٢. Chromium لەسەر **وێبسایتی ڕاستەقینەی Django**، نەک fixture.
٣. پشکنینی دەستی NVDA/VoiceOver و WCAG 2.2 AA لە ڕووکارە واقعییەکە.
٤. Performance و resource profiling لەسەر ئامێری واقعی/نوێنەرایەتی.

ئەم چوارە هێشتا **٠ لە ٤ بەڵگەی داخستنی کۆتایی** هەن، هەرچەند زۆر تاقیکردنەوەی پێشوەخت سەرکەوتووە. هەنگاوە سەرەکییەکان دوای ٤: **٦** (٥–١٠). فایلەکانی هەنگاوەکانی ٢ و ٣ پارێزراون.

### فرمانی CI (لە checkout ـی جیاکراوە)

```bash
python -m pip install -r requirements.txt
python -m pip install playwright==1.57.0
python -m playwright install --with-deps chromium
python manage.py check --settings=config.settings_local_qa
python manage.py test academy.test_step4_learning_path_100_seasons_http --settings=config.settings_local_qa --verbosity 2
python manage.py test scripts.step4_live_learning_path_browser_qa --settings=config.settings_local_qa --verbosity 2
```

پێویستە پارامەتەرەکانی ژینگەی جیاکراوە لە `.github/workflows/rozh-step2-qa.yml` وەربگیرێن؛ بەبێ `ROZH_LOCAL_QA_ONLY=1` کارەکە دەبێت شکست بهێنێت. هیچ داتابەیسی بەکارهێنەر بەکارمەهێنە.

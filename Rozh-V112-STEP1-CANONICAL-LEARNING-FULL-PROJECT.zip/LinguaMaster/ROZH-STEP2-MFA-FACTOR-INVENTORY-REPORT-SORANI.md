# Rozh V95 — هەنگاوی ٢: بەستنەوەی دۆخی کلیلی MFA و Recovery Code

**دۆخ: STEP 2 = OPEN؛ STEP 3/J = OPEN؛ Production = NOT APPROVED.**

## ئەم جارە بەڕاستی چی چاک کرا؟

پێشتر، داواکارییەکی MFA کە دوای پشتڕاستکردنەوەی وشەی نهێنی چاوەڕوان بوو،
گۆڕینی کلیلی TOTP یان نوێکردنەوە/بەکارهێنانی Recovery Code ـەکانی نەدەناسێت.
ئێستا `academy/pending_mfa_binding_step2.py` هەموو ئەمانە بەیەکەوە دەبەستێتەوە:

- دۆخی password-auth ـی پارێزراوی Django.
- وەشانی دۆخی هەژمار و دەسەڵاتەکانی بەکارهێنەر.
- کلیلی TOTP ـی هەمان ساتی چوونە هەنگاوی دووەم.
- لیستی هاشکراوی Recovery Code ـە بەردەستەکان.

Proof ـەکە `HMAC-SHA256` ـە و بە session-auth hash ـی کلیددار پشکنراوە.
هیچ کلیلی TOTP، وشەی نهێنی یان Recovery Code ـێکی ئاشکرا لە session ناخرێت.
گۆڕینی ڕیزبەندی Recovery Hash ـەکان بەخۆی challenge هەڵناوەشێنێتەوە.
دۆخی دووەم-فاکتەر ئەگەر تێکچوو بێت، fail-closed ڕەت دەکرێتەوە.

### چۆن هەڵەکە دۆزرایەوە؟

پێش چاکسازی، ٤ لە تاقیکردنەوە نوێیەکان شکستیان هێنا: گۆڕینی کلیلی TOTP،
نوێکردنەوە/کەمکردنەوەی Recovery Code و دۆخی نادروستی MFA.
دوای چاکسازی هەموو ١٦ تاقیکردنەوەی فاکتەری MFA سەرکەوتن.

## تاقیکردنەوەکان

- **٣٥/٣٥ سکریپتی offline/browser سەرکەوتوو**.
- **٣٦٦ تاقیکردنەوەی ژمێردراو، ٠ شکست**.
- **٥ تاقیکردنەوەی offline نوێ** و **٣ تاقیکردنەوەی Django HTTP نوێ** زیاد کراون.
- HTTP/SQLite ـی Django، PostgreSQL 17 و Windows QA **لەم ژینگەیەدا نەکراون**.
- تاقیکردنەوەی کۆد بە مانای بەڵگەی سەرکەوتنی runtime یان Production نییە.

## بەڵگەی پێویست بۆ تەواوکردنی هەنگاوی ٢

١. `manage.py check` و migration parity لە Django ـی دامەزراو.
٢. Login/MFA/Manager HTTP/SQLite، لەگەڵ ٨ تاقیکردنەوەی `academy.test_step2_pending_mfa_binding_http`.
٣. هەموو `academy` Django regression.
٤. Browser ـی ڕاستەقینە: 360px، Sorani RTL، keyboard و accessibility.
٥. Windows ACL، PostgreSQL و ڕاپۆرتی پشکنینی کۆتایی.

**کۆی بەشە ماوەکانی پشکنینی واقعی: ٥.**
هیچ داتابەیس یان نهێنییەکی Production دەستکاری نەکراوە.

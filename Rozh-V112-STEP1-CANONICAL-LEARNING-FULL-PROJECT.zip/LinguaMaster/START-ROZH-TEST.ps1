# ROZH isolated LOCAL QA starter, compatible with Windows PowerShell 5.1+.
# Use ONLY the fresh extracted ZIP; never run on your real Rozh install.
param([switch]$InstallDependencies)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

# Refuse any folder that may already contain personal accounts/configuration.
foreach ($blocked in @('.env', '.env.local', 'db.sqlite3', 'db.sqlite3-wal', 'db.sqlite3-shm', '.env.production')) {
    if (Test-Path -LiteralPath (Join-Path $PSScriptRoot $blocked)) {
        throw "REFUSED: $blocked exists in this project folder. Extract the test ZIP to a NEW empty folder."
    }
}
if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'manage.py'))) {
    throw 'manage.py missing. Open PowerShell INSIDE the LinguaMaster folder.'
}

# Process-local settings: no changes to system/user environment variables.
$env:ROZH_LOCAL_QA_ONLY = '1'
$env:DJANGO_SETTINGS_MODULE = 'config.settings_local_qa'
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:DJANGO_DEBUG = '1'
$env:USE_SQLITE = '1'
$env:REQUIRE_EMAIL_VERIFICATION = '0'
$env:SITE_URL = 'http://127.0.0.1:3000'
$env:DJANGO_ALLOWED_HOSTS = '127.0.0.1,localhost,testserver'
$env:EMAIL_BACKEND = 'django.core.mail.backends.filebased.EmailBackend'
# Never call real paid/external services from a disposable QA installation.
foreach ($key in @('DATABASE_URL', 'POSTGRES_URL', 'POSTGRES_DB', 'POSTGRES_USER', 'POSTGRES_PASSWORD', 'POSTGRES_HOST', 'POSTGRES_PORT',
                   'PGHOST', 'PGPORT', 'PGUSER', 'PGPASSWORD', 'PGDATABASE',
                   'AI_API_KEY', 'OPENAI_API_KEY', 'STRIPE_SECRET_KEY', 'STRIPE_WEBHOOK_SECRET',
                   'BUILD_STATIC_MANIFEST', 'TRUST_PROXY', 'EMAIL_HOST', 'EMAIL_HOST_PASSWORD', 'EMAIL_HOST_USER',
                   'EMAIL_PORT', 'EMAIL_USE_SSL', 'EMAIL_USE_TLS', 'REDIS_URL', 'REDIS_CACHE_URL', 'REDIS_BROKER_URL')) {
    Remove-Item -Path ("Env:" + $key) -ErrorAction SilentlyContinue
}

$python = Join-Path $PSScriptRoot '.venv-qa\Scripts\python.exe'
$pythonCheck = Join-Path $PSScriptRoot 'scripts\check_python_version_v46.py'
$needsInstall = $InstallDependencies.IsPresent
if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
    $chosenExecutable = $null
    $chosenArgs = @()
    $py = Get-Command 'py.exe' -ErrorAction SilentlyContinue
    if ($py) {
        foreach ($version in @('-3.13', '-3.14', '-3.12', '-3.15')) {
            # Windows PowerShell 5.1 can promote a missing py runtime's stderr
            # into a terminating NativeCommandError under Stop. A missing 3.13
            # must not prevent checking an installed 3.15 (or another version).
            $candidateOk = $false
            $savedPreference = $ErrorActionPreference
            try {
                $ErrorActionPreference = 'Continue'
                & $py.Source $version $pythonCheck 2>$null | Out-Null
                $candidateOk = ($LASTEXITCODE -eq 0)
            } catch {
                $candidateOk = $false
            } finally {
                $ErrorActionPreference = $savedPreference
            }
            if ($candidateOk) {
                $chosenExecutable = $py.Source
                $chosenArgs = @($version)
                break
            }
        }
    }
    if (-not $chosenExecutable) {
        foreach ($alias in @('python.exe', 'python3.exe')) {
            $candidate = Get-Command $alias -ErrorAction SilentlyContinue
            if (-not $candidate) { continue }
            $candidateOk = $false
            $savedPreference = $ErrorActionPreference
            try {
                $ErrorActionPreference = 'Continue'
                & $candidate.Source $pythonCheck 2>$null | Out-Null
                $candidateOk = ($LASTEXITCODE -eq 0)
            } catch {
                $candidateOk = $false
            } finally {
                $ErrorActionPreference = $savedPreference
            }
            if ($candidateOk) { $chosenExecutable = $candidate.Source; break }
        }
    }
    if (-not $chosenExecutable) { throw 'Python 3.12-3.15 is required. Verify your installation using py -3.15 --version or install a supported version.' }
    Write-Host '[1/6] Creating a separate QA Python environment...'
    & $chosenExecutable @chosenArgs -m venv (Join-Path $PSScriptRoot '.venv-qa')
    if ($LASTEXITCODE -ne 0) { throw 'Python virtual environment creation failed.' }
    $needsInstall = $true
}

function Run-Python([string[]]$Arguments) {
    & $python @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Python failed with exit code $LASTEXITCODE. Stop; see the error above." }
}
if (-not $needsInstall) {
    & $python (Join-Path $PSScriptRoot 'scripts\check_django_runtime_v44.py')
    if ($LASTEXITCODE -ne 0) { $needsInstall = $true }
}
if ($needsInstall) {
    Write-Host '[2/6] Installing dependencies (internet required for FIRST run)...'
    Run-Python -Arguments @('-m', 'pip', 'install', '-r', 'requirements.txt')
}
Write-Host '[3/6] Django config check (isolated QA settings)...'
Run-Python -Arguments @('manage.py', 'check')
Run-Python -Arguments @('manage.py', 'makemigrations', '--check', '--dry-run')
Write-Host '[4/6] Creating/updating ONLY .rozh-local-test\rozh-test.sqlite3 ...'
Run-Python -Arguments @('manage.py', 'migrate', '--noinput')
Write-Host '[5/6] Adding lessons and test users to the QA database...'
Run-Python -Arguments @('manage.py', 'seed_curriculum')
Run-Python -Arguments @('manage.py', 'seed_languages_v10')
Run-Python -Arguments @('-m', 'scripts.qa_local_setup')
Write-Host '[6/6] Browser URL: http://127.0.0.1:3000/login/'
Write-Host 'Credentials: .rozh-local-test\TEST-LOGINS-LOCAL-ONLY.txt'
Write-Host 'MFA codes: run TOON-TEST-MFA.ps1 in a new PowerShell window.'
Write-Host 'Press Ctrl+C to stop. This server MUST remain bound to 127.0.0.1.'
Run-Python -Arguments @('manage.py', 'runserver', '127.0.0.1:3000', '--noreload')

> Historical release checklist. For the V9 implementation and executed checks, see [V9_TEST_STATUS.md](V9_TEST_STATUS.md).

# LinguaMaster — professional launch gates

Status date: 6 November 2026. "Pass" below only means a reported test actually ran; everything else is **unverified**.

| Gate | Local/offline status | Before public launch |
|---|---|---|
| Source syntax and reference integrity | PASS | rerun in CI on each change |
| Public demo full Chromium interaction | PASS | repeat on real phones & screen readers |
| New mobile dashboard component | PASS in static browser fixture | verify after actual Django rendering |
| Signup → email verification → login → optional MFA → logout | not end-to-end verified this release | stage real SMTP and test delivery, redirects, expiry, MFA and recovery |
| Django migration state and 80+ integration tests | NOT RUN here | execute on Windows/CI and attach logs |
| Grammar and skill pedagogy, Dutch/Flemish quality A0–C1 | NOT independently audited | instructor review, content QA strict, real learner pilot |
| Database backup / disaster restore | isolated offline integrity tests only | restore production-like backup to separate database and verify accounts/progress |
| Dependency vulnerabilities / OWASP ASVS 5.0 | NOT audited | external scanning, remediation and penetration test |
| GDPR compliance / privacy language | NOT legally audited | GDPR legal and data-flow review |
| WCAG 2.2 AA | static/browser spot-checks only | screen reader, keyboard, zoom, contrasts, cognitive-accessibility audit |
| HTTPS, reverse proxy, headers, cookies | development configuration inspected | real `check --deploy`, domain/TLS and monitoring review |
| Monitoring and load testing | NOT VERIFIED | stage realistic traffic, test recovery, logging, alerts and rate limits |

## Windows development smoke test

1. Stop the old server. Extract the release ZIP in a new folder.
2. Run `Install-LinguaMaster-V8-PRO-QUALITY.ps1 -Test`. The installer must preserve the SQLite DB, `.env` and virtualenv and verify all copied source files via SHA-256.
3. Before relying on the platform, open `/`, `/try/`, `/register/`, `/login/`, `/dashboard/`, `/learn/`, `/profile/` and test account/session flows.
4. As owner, run `python manage.py audit_learning_content --strict` and review warnings with a language teacher.
5. For launch, use a proper production deployment: PostgreSQL, HTTPS, production email, backups and a WSGI/ASGI server. **Never use `runserver` in public production.**

No passwords, database dumps, secret keys or API tokens are included in the release ZIP.

# Four learning languages: authored starter scope

LinguaMaster V10 offers Dutch, English, German and French as **languages to learn**.
The app's interface language is a separate preference. The new English, German and
French lessons explain grammar in English and use their target language for
examples, vocabulary and device speech. Changing the interface to Dutch, Sorani
or Arabic does not translate the authored course explanations.

This release does **not** contain a complete A0–C1 grammar curriculum or a validated
CEFR placement exam. A0 means introductory Pre-A1 material. A2, B1, B2 and C1 level
records reserve the course structure for future authoring; new EN/DE/FR content
for those levels is not yet published. Dutch retains the existing original seed,
which is itself starter material rather than a complete syllabus.

## New original course material

Each new course has two A0 units and one A1 unit. Each unit provides grammar,
reading, transcript-supported listening, speaking and writing activities. Three
questions in each grammar, reading and listening lesson give 27 graded questions
per course, with a mixture of multiple choice and precisely requested short
answers. Speaking and writing in these lesson units use honest self-review and
do not claim an independently assessed pronunciation or writing score.

| Course | A0 | A1 | Published starter scope |
| --- | --- | --- | --- |
| English | Introductions with *be*; a/an and plural objects | Simple-present routines | 3 units, 15 lessons, 27 questions, 18 contextual vocabulary entries |
| German | Introductions with *sein*; nominative articles | Regular present-tense verbs and word order | 3 units, 15 lessons, 27 questions, 18 contextual vocabulary entries |
| French | Introductions with *être*; gender and articles | Regular -er present-tense verbs | 3 units, 15 lessons, 27 questions, 18 contextual vocabulary entries |

Rich companion articles add explanatory sections, tables, sentence patterns,
examples and common traps for English *be*, German nominative articles, French
*être* and existing Dutch main-clause word order. The Dutch article attaches to
the original topic without replacing its explanation, examples or quick check.
These are original authored starter examples, requiring further pedagogical and
native-speaker review before claims of comprehensive curriculum coverage.

English vocabulary uses simple English definitions rather than translating an
English word into itself. German and French vocabulary use English glosses.
Pronunciation fields contain IPA practice guidance; accent variation is normal.
Device voices depend on the browser and installed target-language voices. A
visible listening transcript supports accessibility, so the task is guided
practice rather than an independent listening examination.

## Seed and preserve editorial work

After database migrations, run:

```bash
python manage.py seed_curriculum
python manage.py seed_languages_v10
```

The first command creates the existing Dutch starter topics. The second adds
English, German and French and attaches the four rich articles when their topics
are available. If the Dutch main-clause topic does not exist, it reports a skipped
article and leaves Dutch records untouched. Re-running after the Dutch seed adds
that missing article.

The V10 seeder uses `get_or_create` with stable natural keys. Existing language,
level, unit, lesson, exercise, word, grammar topic and rich article values are
never replaced. Existing publication decisions and author changes remain intact.
The command adds missing starter records, so it is additive rather than a
curriculum synchronization or deletion tool. It adds prerequisite relations only
when first creating a unit, preserving later editorial prerequisite changes.
The second A0 unit requires the first A0 unit; the first unit of each level is a
placement entry point, matching the existing platform behavior.

To supply the full future curriculum, use the grammar import documentation and
author new validated topics with original explanations, examples and checks.
Complete coverage requires a scope map, substantially more practice per topic,
reviewed listening materials, productive-skill evaluation and appropriately
validated assessments; creating empty level records does not establish any of
these.

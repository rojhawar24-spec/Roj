# Architecture & data model

The Django server renders public and authenticated HTML pages; public JSON catalogue endpoints are read-only. PostgreSQL is the sole production relational store. Redis provides caching, distributed best-effort rate limiting and a Celery broker. Two Celery processes cover task execution and scheduled email/log cleanup. Caddy terminates TLS in the illustrated EU VPS topology. Tailwind is not fetched at runtime: custom responsive CSS is shipped as a first-party static asset to avoid a frontend build service, tracking scripts or CDN dependency.

## Domain models

- **Language, Level, Unit, Lesson, Exercise, GrammarTopic, Vocabulary**: published, versioned educational content. Unit prerequisites are directed unit-to-unit links. Only an editorially approved published record appears in the catalogue.
- **Profile, LessonProgress, Assessment, ReviewCard**: preferences, opt-ins, streaks, XP, completed activities, test results, and modified SM-2 intervals.
- **Friendship**: requested/accepted/blocked connections; the UI only displays active friend learning activity when both users consent.
- **Badge, BadgeAward, Certificate**: controlled achievements. A certificate is an internal learning credential with a random UUID and revocation state; no accrediting-body claims.
- **PlatformSettings**: owner singleton. Defaults make AI unavailable. `AIUsage` tracks request reservation, moderation status and conservative costs without storing prompts. `AuditEvent` captures manager actions. `ContentRevision` records versioned content snapshots after admin form saves.

## Teaching and evaluation rules

1. Registration email confirmation activates an account; a short starting-level quiz estimates the learning stage.
2. A unit is available only after recorded passing results for prerequisite units.
3. A lesson with objective checks requires at least 70% before it is marked complete. Speaking/writing without automatic grading require the learner to affirm self-review. Completion awards 20 XP once, guarded by a database uniqueness constraint.
4. The unit assessment requires all published unit lessons completed. It selects up to 12 multiple-choice questions and requires 80%.
5. The level assessment requires passed tests for every published unit and requires 80%. A passing level result causes creation of one active internal certificate if none exists.
6. The adaptive practice page uses recent attempt accuracy to raise or lower eligible question difficulty. Adaptive scores are stored separately; repeat practice grants no XP.
7. Review cards use modified SM-2 scheduling. A weekly weak-item view allows more review, even for cards not yet due.
8. The owner can revoke certificates and badges and control staff roles; content remains managed via Django permissions.

## AI safety pipeline

1. User sends a valid question to a server endpoint through POST + CSRF. Both owner feature flags and learner consent are checked.
2. A transaction locks the platform-settings singleton, checks per-user limits, computes a conservative EUR reserve and rejects when combined monthly reservations + charges exceed the cap.
3. The request is screened for email-address patterns and passed to an external moderation endpoint. Flagged input is not sent to generation.
4. A bounded generation request is made from the server using a fixed system prompt and configured model. Result is passed to moderation again. Flagged output is not shown to the user.
5. Token counts, status and estimated financial charge are stored, not the raw text. Errors reserve charges conservatively to avoid budget underestimation.

Provider-specific billing, evolving moderation categories, and the actual external-cost ceiling **must** be verified before enabling AI. The regulator/hosting/provider may require further safeguards and a DPIA.

## Boundaries

- No external advertising, analytics tracker, or user-uploaded files.
- Public visitor views do not show unpublished lessons or private progress.
- The official Django admin is gated by a middleware session 2FA proof, not merely Django's `is_staff` flag.
- A staff role gives no permissions automatically; the owner must assign narrowly scoped Django model permissions in the secure admin.
- Run Celery beat as one instance only. Review database index and query plans before high-volume deployment.
- Python model migrations are checked in, but they have not been executed in the offline build environment. Verify them on a test database before production.

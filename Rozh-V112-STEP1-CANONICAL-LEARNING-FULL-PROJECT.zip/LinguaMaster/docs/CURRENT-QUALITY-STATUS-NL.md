# Rozh — actuele kwaliteitsstatus (V84 / QA stap 1)

**NIET PRODUCTIEKLAAR.** Dit document is een kwaliteitsbarrière, geen certificaat.

## Uitgevoerd
- ZIP, manifest, Python AST en JavaScript-syntax worden opnieuw gecontroleerd.
- Publicatiebeleid voor `/api/lessons/`: openbare catalogus heeft uitsluitend metadata, geen volledig `content` of `audio_text`.
- Er is een zelfstandige offline AST-regressietest en een **nog uit te voeren** Django HTTP-integratietest toegevoegd.
- Bestaande V83-tests worden afzonderlijk herhaald; resultaten staan in het V84-verificatierapport.

## NIET UITGEVOERD (productieblokkerend)
- Live Django HTTP-integratietest en `manage.py check --deploy`; Django is niet geïnstalleerd in de beschikbare auditomgeving.
- Echte PostgreSQL-/Redis-/Celery-/MFA-/accountautorisatietesten in staging.
- Geauthenticeerde pentest van alle routes, API's en bedrijfsprocessen.
- Complete beoordeling van 13 oefenvormen, 100 grammatica-componenttypes en 900 lesdoelen.
- 8 interfacetalen en 4 cursustalen: native-speaker review en volledige visuele RTL/browser-QA.
- **0 goedgekeurde nieuwe audio-opnames**: offline stemmodellen en licentiecontrole blijven open.
- Toegankelijkheidsaudit volgens WCAG 2.2 AA voor het gehele product.

## Releasevoorwaarden
Geen school-, veiligheids- of productieclaim zonder bewijs uit een echte, geïsoleerde stagingomgeving; tests mogen geen productiegegevens aanraken.

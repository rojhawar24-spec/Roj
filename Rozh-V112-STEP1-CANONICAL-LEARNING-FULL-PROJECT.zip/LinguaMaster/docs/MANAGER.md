# Manager handbook

## Initial access

Create the Django superuser using the project installation procedure. Sign in via `/login/`, not the Django admin login. On `/mfa/setup/`, copy the private TOTP enrollment secret into a trusted authenticator and verify a valid six-digit code. After this, `/manager/` and `/secure-admin/` become accessible. Back up your recovery and account administration plan; this codebase does not include backup TOTP recovery codes.

## AI control

The owner dashboard shows two separate AI controls:

1. **AI enabled**: whether the tutoring feature may exist for customers.
2. **AI emergency stop**: independent global block, initially on.

Even if enabled, AI remains inaccessible to a customer who did not opt in. Set daily and monthly request limits, positive monthly EUR budget, and realistic rates for provider input/output tokens and moderation. Provider moderation is fail-closed. To turn off AI for everyone, set `AI emergency stop` to **on** and save. The public navigation and endpoint are both then disabled. Never place `AI_API_KEY` in JavaScript or course content.

## Curriculum and editorial workflow

Go to **Edit courses and content** in secure Django admin. Create a language, levels, units with prerequisites, five kinds of lesson where appropriate, exercises, grammar topics and vocabulary. Set a clear description and examples and verify the answer is one of the listed choices. Review written content before setting `published` true. Language and unit publication are separate gates. Changes to versioned models create an editor, timestamp and snapshot entry under `ContentRevision`; inlines and bulk management actions should be audited before use in a strict editorial environment.

The starter data can be seeded using `python manage.py seed_curriculum`. Running it again preserves existing editorial changes because the seed operation only creates missing unique records. Remember: published content includes examples for all A0–C1 headings, **not** a complete course required to genuinely certify each stage of competence.

## Users and recognition

`Manager users` offers search, block/reactivate, staff promotion/revocation, deletion, badge and certificate granting/revocation. Staff promotion requires the person to enable TOTP. Superuser accounts cannot be changed through this user list. Staff receive no permissions by promotion alone; grant explicit model permissions after reviewing job responsibilities. Avoid granting user-permission management to editors.

Badges and certificates are separate: badges may be awarded automatically by XP thresholds or manually by the owner. Only active, unrevoked awards appear on the learner dashboard. Certificates from passed level assessments have public UUID verification pages; revocation changes those pages to an invalid status.

## Reports and audit

The dashboard shows user counts, recent distinct learners, most-completed lessons, AI request statuses, cost estimates and recent actions. Moderation totals can be inferred from `blocked` statuses, but must not be described as a complete classifier of all undesirable content. Security and usage logs require periodic archival and retention review. For high-stakes actions require managerial double approval outside the current application, as the implementation uses single-owner authorization.

## Essential operational checks

Use unique credentials; never expose `/secure-admin/` without HTTPS. Keep backups and restore exercises. Rotate compromised secrets promptly. Check Celery worker and beat, outbound mail, privacy contacts, readiness, admin audit entries and AI provider invoices. If 2FA is lost, use a documented, authenticated server-side recovery procedure; do not bypass 2FA by changing a cookie or URL.

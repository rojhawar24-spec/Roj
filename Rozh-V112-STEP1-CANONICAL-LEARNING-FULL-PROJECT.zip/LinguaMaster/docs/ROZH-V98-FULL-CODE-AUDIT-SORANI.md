# Rozh V98 — پشکنینی تەواوی فایلەکان، کۆد و کێشە ماوەکان

**بنەما:** ZIP ـی ڕاستەقینەی `Rozh-V97-SELF-REVIEW-CHECK-ANSWER-FULL-PROJECT.zip`، نەک وەشانێکی پێشبینیکراو یان پرۆژەی نوێ. V98 تەنها گۆڕانکارییەکی بەڵگەدار بۆ Fill in the Blank و فایلەکانی پشکنین زیاد دەکات. هەموو فایلی V97 هەڵگیراوە.

**بەڵێ، هەر فایلێک لە ZIP ـی بنەڕەتدا خوێندرایەوە بۆ integrity و syntax/format بە پێی جۆری فایل. بەڵام ئەمە واتای ئەوە نییە کە هەموو ڕێڕەوی business logic بە Django/Browser/DB بەڕاستی ئەنجام دراوە.** ئەوەی نەتوانرا بە تاقیکردنەوەی ڕاستەقینە پشتڕاست بکرێتەوە، بە ڕوونی کراوەیە.

## ١. پشکنینی فایل بە فایل — V97

- **١٬٠٥٢** فایلی ZIP بە تەواوی خوێندرانەوە بۆ checksum و ناوی ڕێڕەو؛ `zipfile.testzip()` بەبێ هەڵە.
- **١٬٠٥١** SHA-256 لە manifest هاوتان؛ **٠ جیاوازی**؛ هەموو ڕێڕەوەکان پارێزراون، نەک traversal/symlink/دووبارە.
- **٦٦٥** Python AST سەرکەوتوو؛ **٤٤** JavaScript بە `node --check` سەرکەوتوو؛ **٣٦** JSON/webmanifest و **٢** YAML parse سەرکەوتوو؛ **٢٩٠** فایلی دەقیی دیکە بە UTF-8 خوێندرانەوە.
- **٨٣** template ی HTML و **٣٦٧** ئاماژەی literal static/extends/include پشکنران؛ هیچ فایلی ون و هیچ کۆتایی `{% if %}` / `{% block %}` ـی ون نەدۆزرایەوە. ئەم پشکنینە ناتوانێت جای Django template rendering بگرێتەوە.
- فایلەکان لە CSV ـی `docs/ROZH-V97-EVERY-FILE-AUDIT-1052.csv` تۆمارکراون: ڕێڕەو، قەبارە، SHA-256، جۆری پشکنین و هاوتایی manifest.
- `db.sqlite3` و `.env` ـی واقعی لە ZIP ـدا نییە؛ نهێنییەکانی production و بنکەداتای بەکارهێنەر ناخرێنە ZIP.

## ٢. تاقیکردنەوەکان — بەڕاستی جێبەجێکراوەکان

- **٤٤/٤٤** سکریپتی regression ـی فەرمی V97 دووبارە سەرکەوتن. ئەمانە offline و Chromium isolated tests ـن، نەک full Django HTTP.
- **٦/٦** تاقیکردنەوەی نوێ بۆ `accepted_answers` پێش چاکسازی شکستیان هێنا؛ دوای چاکسازی سەرکەوتن.
- **٢١/٢١** تاقیکردنەوەی legacy V58 و **٥/٥** تاقیکردنەوەی V81 بۆ ئەو جۆرە ڕاهێنانانە سەرکەوتن.
- هەوڵی تاقیکردنەوەی هەموو سکریپتە مێژووییەکانی لە سنووری کاتی ژینگەکە وەستا. ئەو هەوڵە **نەک PASS نەک FAIL** هەژمار نەکرا.
- Django لەم ژینگەیەدا دامەزراو نییە؛ بە پێی هەوڵی دۆزینەوە/داگرتن، پەکێجی پێویست بەردەست نەبوو. `manage.py check`، migration و PostgreSQL بە ڕاستەقینە پشتڕاست نەکراونەتەوە.

## ٣. چاکسازیی نوێی V98 — بەڵگەدار

**F01 — Fill in the Blank تەنها یەک وەڵامی ڕاستی دەناسی (چاککرا).**

- `academy/lesson_activities_v58.py`: یەک وەڵامی `answer` قبوڵ دەکرا؛ وەڵامە جیاوازە دروستەکان ڕەت دەکرانەوە.
- ئێستا Manager دەتوانێت لە `activity_data` ـدا بنووسێت: `{"accepted_answers":["verblijf","...different teacher-approved alternative..."]}`. تا **١٠** جێگرەوەی جیاواز قبوڵ دەکرێت.
- بەکارهێنەر ناتوانێت وەڵامەکان لە JSON ـی frontend ببینێت؛ تەنها سێرڤەر نمرە دەدات. ڕێکخستنی Unicode NFC و casefold کار دەکات؛ جێگرەوەیەکی نەنووسراو بە خۆکار قبوڵ ناکرێت.
- validation بەڕوونی دووبارە، وەڵامی سەرەکی دووبارەکراوە، جۆری نادروست، و وەڵامی زۆر درێژ ڕەت دەکاتەوە.
- هیچ migration و دەستکارییەک لە بەکارهێنەر، XP، دڵەکان یان وەڵامە پێشووییەکان کراوە نییە.

## ٤. کێشەکانی هێشتا کراوە — **ئەمە بەڵگەی ١٠٠٪ نییە**

### P1 — یەکگرتوویی سیستەمی فێربوون

**F02 — ١٣ جۆر لە V58 هێشتا هەن؛ بڕیاری تۆ ٥ جۆرە.** `academy/lesson_activities_v58.py` هێشتا KINDS = 13 هەیە. ئەوەی تۆ پەسەندت کردووە Multiple Choice، Fill in the Blank، Matching، Word Order و Listening بە وەڵامی دیاریکراوە. لابردنی ٨ جۆری دیکە لە Student، Manager و داتای کۆن پێویستی بە migration/compatibility و Django HTTP tests هەیە. **لە V98 دا ئەوان بە زۆر ناسڕدرێن.**

**F03 — Speaking / Free Writing هێشتا بە Self-review بەکاردەهێنرێن.** `academy/journey_v11.py` لە هەندێک mixed round ـدا قۆناغی `speaking/reflection` دروست دەکات؛ `seed_curriculum.py` ـیش وانەی `speaking/writing` دادەنێت. ئەمە لەگەڵ بڕیاری هەڵسەنگاندنی خۆکار ناگونجێت. ئەم بەشانە نابێت وەک وەڵامی ئۆتۆماتیکی نمرەدار پیشان بدرێن.

**F04 — کاتالۆگی دەنگی پەسەندکراو ٠ کلیپە.** `academy/static/academy/audio-v78/catalog.json` کلیپی پەسەندکراوی تێدا نییە. V96 لە سپیبوونی پەڕە و لینکە شکێنراوەکان پاراستنی زیاد کردووە، بەڵام بۆ گەڕاندنی وانەی Listening پێویستە دەنگی ڕاستەقینە و مۆڵەتی بەکارهێنان بخرێتە کاتالۆگەکە.

### P1 — runtime و ئاسایش / production gate

**F05 — Django و migration لە runtime ـی واقعی تاقی نەکراونەتەوە.** `requirements.txt` Django 6.1.3 داوا دەکات؛ لەم ژینگەیەدا نییە. `manage.py check`, `makemigrations --check`, `migrate 0019`, HTTP, session/CSRF, full database regression **نەکراون**.

**F06 — PostgreSQL/Windows/staging ڕاپۆرتی سەرکەوتنی واقعی نییە.** کارەکانی GitHub Actions و دەروازەکانی J کۆدن، بەڵام بەڵگەی ئەنجامی واقعی PostgreSQL 17 concurrency و Windows ACL تێدا نییە. بۆ production هێشتا ڕێگرییە.

### P2 — UX/quality

**F07 — سنووری ٧٠٪ و ٨٠٪ لە دوو ڕێڕەوی جیاوازدا هەن.** وانە/round ـی فێربوون ٧٠٪، بەڵام تاقیکردنەوەی یەکە/ئاست ٨٠٪ داوا دەکات (`academy/views.py` و `academy/journey_v11.py`). ئەمە لە خۆیدا هەڵەی computational نییە، بەڵام UI دەبێت دوو مەرجەکە بە ڕوونی جیا بکاتەوە.

**F08 — RTL / Screen Reader / ئامێری واقعی و native-speaker QA ناتەواوە.** تاقیکردنەوەی Chromium ـی جیاکراوە هەیە؛ گەڕان بە کل و ڕێڕەوی کۆدی واقعی هێشتا تاقی نەکراوە. ناتوانرێت WCAG 2.2 AA ـی تەواو پەسەند بکرێت.

**F09 — ناوەڕۆک وەک ٩٠٠ وانە / ٢٠٬٠٠٠ وشە و دەستەواژە هێشتا پلانن، نەک بەڵگەی ئەوەی لە ZIP دا بە تەواوی ئامادەن.** کۆدی seed starter دەنووسێت، نەک هەموو پلانەکە. تاقیکردنەوەی editorial بە هەموو وانەکان پێویستە.

### Security-specific observations

- یەک `@csrf_exempt` لە Stripe webhook دۆزرایەوە؛ لە هەمان handler ـدا HMAC signature/٥ خولەک age check هەیە. ئەوە بە تەنها بەڵگەی کەلێنی CSRF نییە؛ payment flow ـی واقعی تاقی نەکراوە.
- `mark_safe()` ـی public schema JSON پێش نیشاندانی HTML هەندێک character ـی مەترسیدار escape دەکات. ئەمە بەڵگەی تەواوی XSS audit نییە.
- Static scan هیچ کەلێنی exploit ـی پشتڕاست نەکرد؛ ئەمە **نەک واتای تەواوی security / pentest** ـە.

## ٥. هەنگاوەکانی پێویست بۆ دابەستن

١. Django 6.1.3 و هەموو dependencies لە ژینگەی test ـی جیاواز جێبەجێ بکە؛ Python `manage.py check`, migration 0019 و HTTP tests بەڕاستی ران بکە. ٢. بە migration و plan بڕیاری ٥ جۆر لە Student/Manager/dataset جێبەجێ بکە، بەبێ سڕینەوەی XP. ٣. دەنگی پەسەندکراو بۆ Listening زیاد بکە؛ هیچ تۆماری ساختە وەک دەنگی پەسەندکراو دانەنێ. ٤. لە Windows + PostgreSQL + screen-reader و شاشەی 360px جێبەجێ بکە؛ ڕاپۆرتی CI هەڵبگرە. ٥. بە داتای پاک و تستی ڕاستەقینە grading/progress/heart/session لەسەر هەموو ڕاهێنانە بەکارهاتووەکان تاقی بکەوە.

**ئەنجام:** V98 پشکنینی file/syntax/integrity تەواو دەکات و چاکسازیی Fill in the Blank زیاد دەکات. **Production ready = NO؛ Full functional 100/100 = NOT VERIFIED.**

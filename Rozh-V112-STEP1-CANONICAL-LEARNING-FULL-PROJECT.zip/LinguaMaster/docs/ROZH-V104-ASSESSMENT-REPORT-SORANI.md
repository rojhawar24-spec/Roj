# Rozh V104 — هەڵسەنگاندنی پێنج جۆری ڕاهێنان

## بنەما و گۆڕانکاری
- V103، بە SHA-256 ـی `5b2dae9c319fdc49d076e85d81e6986c1ae3f31de4a27d431c805a4b59a1dabd`.
- Unit/Level Assessment ئێستا MCQ، Fill in the Blank، Word Matching، Word Order و Listening (تەنها بە دەنگی پەسەندکراو) دەپەسەندێت. Placement و Practice بە مەبەست نەگۆڕدراون.
- Matching و Word Order بە select ـی native و کیبۆرد، لەگەڵ پشکنینی تەواوی permutation لە backend؛ وەڵامی دووبارە، ون، زیادە، ناسازگار یان ساختە ڕەت دەکرێتەوە. JS هەمان index ـی بەکارهاتوو لە هەڵبژێری تر ناچالاک دەکات. بەبێ JS ـیش backend پشکنینی هەمان مەرجەکان دەکات.
- fingerprint ـی HMAC لە پرسیار، ناوەڕۆک، بەکارهێنەر و scope بەستراوەتەوە. بۆ سێ جۆری نوێ پێویستە؛ بۆ POST ـی سادەی مێژوویی MCQ/Fill blank بەبێ token سازگاری پارێزراوە. ئەم compatibility ـە بە مانای پاراستنی هەموو POST ـی کۆن لە گۆڕانکاریی نێوان GET/POST نییە. پشکنینی transaction ـی پێشوو دەمێنێتەوە.
- Content Audit تەنها ڕاهێنانی ready دەژمێرێت؛ Listening بە approved_audio_url پشکنراوە. هیچ دەنگێک دروست/پەسەند نەکراوە، catalog ـی ئێستا سفر clip ـە.
- CSS/JS cache version نوێ کراوە. هیچ migration ـێک یان داتای بەکارهێنەر دەستکاری نەکراوە.

## پشکنین
- 7 تاقیکردنەوەی نوێی pure policy: matching، ڕیزبەندی بە وشەی دووبارە، POST ـی ناسازگار، snapshot ـی keyed (HMAC mock)، دەنگی پەسەندکراو (lookup mock).
- Chromium واقعی: 3 viewport ـەکە (320، 360 RTL، 1280)، native select، تەواوکردنی پرسیار، قەدەغەکردنی index ـی دووبارە، form payload، نەبوونی overflow و page error. HTML fixture ـە؛ Django واقعی و audio playback تاقی نەکراونەتەوە.
- تاقیکردنەوەی نوێی Django لە مۆدیولی V26 بۆ missing/stale snapshot، duplicate matching و success نووسراوە؛ نەڕاوە.
- Django دامەزراو نییە لە ژینگەی authoring؛ PostgreSQL، Windows، screen reader، وێبسایتی تەواو و دەنگی واقعی پشتڕاست نەکراونەتەوە. نمرەی 100/100 یان production approval نادرێت.
- هەموو ڕێڕەوەکانی legacy single lesson و ناوەڕۆکی کۆن هێشتا بە تەواوی بۆ پێنج جۆرەکە migrate نەکراون.
- ئەنجامی regression لە فایلی JSON ـی دەرەوەی ZIP هەیە. SHA-256 و manifest فایلەکان بۆ integrity ـن، نەک بەڵگەی نەبوونی bug.

# API reference

REST Framework routes are intentionally read-only for the public catalogue. Content changes use the permission-checked owner/admin server UI. All API routes use JSON.

| Method | Endpoint | Access | Result |
| --- | --- | --- | --- |
| GET | `/api/languages/` | Public | Published languages: id, name, code, slug, description |
| GET | `/api/levels/` | Public | Levels for published languages |
| GET | `/api/units/` | Public | Published units with outcomes and level identifiers |
| GET | `/api/lessons/` | Public | Published lesson text and audio-text fields |
| GET | `/api/me/progress/` | Session login | Own XP, streak, completed lessons and lesson IDs |

API authentication uses the Django session cookie, HTTPOnly, same-site protection and CSRF for future state-changing requests. Throttling uses DRF's standard rate classes as a best-effort layer. There is no public AI API or token issuance endpoint. JSON responses must not expose hidden correct answers, draft curricula, private friend details or other users' records.

## Content administration (HTML, not REST)

- `GET/POST /secure-admin/`: Django admin, staff model permissions and mandatory completed TOTP session.
- `GET/POST /manager/`: superuser with verified TOTP only. Server-validates form inputs; logs settings changes.
- `GET /manager/users/`: owner-only search, capped to 100 visible rows per request.
- `POST /manager/users/<id>/<action>/`: block, unblock, promote, demote, delete (CSRF and 2FA required).
- `POST /manager/award/`: issue/revoke controlled achievements; an action requires a validated `badge:<id>` or `certificate:<id>` selection.

## Learning endpoints

- `POST /lessons/<id>/`: answers keyed by server-side exercise IDs, never trusts user-supplied correct answers.
- `POST /assessment/unit/<id>/`: gates on prerequisites and completed unit lessons; 80% pass threshold.
- `POST /assessment/level/<id>/`: gates on every unit assessment; awards platform certificate on pass.
- `POST /practice/<id>/`: adaptively selects level questions; recorded separately and not awarded XP.
- `POST /review/` and `POST /weekly-review/`: quality 0–5, valid only for cards belonging to the current user.
- `POST /ai-tutor/`: only when owner and learner opt-in, with moderation and transactional budget checks.

**API errors:** 400 invalid input, 403 unauthorised learning action, 404 unpublished/not found, 429 throttled, 503 missing assessment/content. Do not expose stack traces or server secrets in production.

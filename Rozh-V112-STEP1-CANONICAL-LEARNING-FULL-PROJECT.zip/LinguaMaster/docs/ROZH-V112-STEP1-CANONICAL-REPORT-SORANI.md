# Rozh V112 — هەنگاوی ١: سیاسەتی یەکگرتووی ڕاهێنان

- Classic GET, SSR POST (under locked admission), AJAX, mixed rounds and navigation use the canonical readiness rule. Empty, invalid and unsupported exercise sets cannot create new credit. Audio approval remains required.
- Manager and Admin validate published lessons and unsupported exercise edits. Historical kinds remain stored for repair. Audit reports unsupported and empty published lessons as errors.
- Existing progress and authored data retained; no live database opened or changed. V109 conversion and original-seed retirement remain opt-in. Published legacy lessons may be unavailable until reviewed and converted or unpublished. Backup-based upgrade is a release gate.
- Live HTTP tests updated to reject self-review credit and preserve history; not executed (Django missing). Eight new offline admission tests include synthetic audio and AST checks. Workspace 69/69 selected scripts passed, not the entire historical test collection or real Django rendering.

## Six-stage plan
1. Five-kind source implementation and selected offline checks: complete. Real data remediation and runtime acceptance remain mandatory under steps 5–6.
2. Listening/content: next. 27 starter clips and 45 review questions, zero approved recordings.
3. Assessment/XP/progress: verify existing implementation and remaining integrity issues.
4. Real design/mobile/RTL/dark/accessibility.
5. Backend/frontend/database/security; real backup-based upgrade and Django/PostgreSQL tests.
6. Final release acceptance, including production DEBUG=0 and no exposed diagnostic pages.

Five numbered stages remain after source implementation of step 1. No claim of production acceptance, zero bugs, approved audio, live database, Windows or full screen-reader verification.

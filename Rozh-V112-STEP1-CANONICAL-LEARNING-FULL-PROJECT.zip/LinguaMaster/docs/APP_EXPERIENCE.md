# LinguaMaster 0.2.0 — app experience and PWA

**Scope:** This release transforms the existing Django learning platform into an installable, app-like Progressive Web App. This is **not** a native Android APK or iOS IPA. A network connection is required for all authenticated lesson and assessment activities.

## Screens and real behavior

1. **Public start screen (`/`)**: original app preview, course discovery, registration/login. SEO content pages are still SSR and publicly crawlable.
2. **Home (`/dashboard/`)**: pulls authenticated user XP, streak, completed lessons, due reviews, preferred/first published language, next available lesson and genuine course completion percentage from database records.
3. **Learning path (`/learn/`)**: one stage per A0, A1, A2, B1, B2 and C1; draws units, earned completions, unlocked unit tests and locked nodes based on prerequisites. The user's placement starting level informs the recommended next activity.
4. **Interactive lesson (`/lessons/{id}/`)**: concept explanation, optional text-to-speech, one question at a time and immediate feedback via a Django POST endpoint `/lessons/{id}/answer/`. The server validates answer options, scores the attempt, awards 20 XP once and builds spaced-repetition cards. With JavaScript disabled, the preexisting HTML form still works.
5. **Speaking and writing lessons**: transparent self-check with a local scratchpad (nothing is sent or stored from that scratchpad), not automatic speech scoring. Self-check completion awards no performance XP.
6. **Assessments**: placement, unit and level tests show one question at a time with JavaScript; answers are submitted to Django as a normal authenticated POST. Existing 80% pass threshold and prerequisites still apply.
7. **Practice (`/review/`)**: flashcards hide the meaning until tapped. Review quality 0–5 updates the existing modified SM-2 schedule in the database.
8. **Grammar (`/grammar/`)**: responsive lesson cards and clear grammar explanations with original examples, exceptions, common mistakes, speech synthesis and a server-checked mini-test.
9. **Daily word**: current published vocabulary with pronunciation, example and word quiz; the grammar of the day remains linked.
10. **Profiles, friends, leaderboard, badges, certificates**: existing server-side functionality preserved within the app shell, with consent controls and privately scoped access.
11. **AI tutor**: remains owner-controlled, off by default, invisible when disabled; the server retains moderation and budget checks.
12. **Manager and editorial content**: access still requires superuser and completed TOTP; admin/editor pages and audit history are preserved.
13. **Appearance**: responsive desktop sidebar, mobile fixed bottom navigation, reduced-motion support, dark/light/system preference saved in localStorage.

## PWA technical rules

- Manifest: `/static/academy/manifest.webmanifest` with 192px and 512px icons.
- Root-scope service worker: `/service-worker.js`, with cache versioning and automatic cleanup.
- **Only public static app assets** (CSS, JS, icons and a generic offline screen) are cached.
- All navigations, authenticated HTML pages, CSRF-token responses, private API responses, AI conversations and quiz answers remain network-only; no account records are cached for offline use.
- Installation works in supporting browsers on `localhost`/`127.0.0.1` or HTTPS origins; actual install controls are browser-specific. On Android/desktop supported browsers may show Install; iOS uses Safari's Add to Home Screen.
- A real network connection is required for all lesson scoring and account services.
- Users who cannot run JavaScript retain HTML lesson/assessment forms and navigation; the app will be less interactive.

## Owner and safety notes

- Do not treat XP or a self-checked speaking/writing completion as independently validated CEFR proficiency.
- The 18-unit seed is a compact original demonstration curriculum, **not** a comprehensive, pedagogically validated A0–C1 language course.
- No claim is made that this codebase has completed a security audit, browser-device coverage, production penetration test or live email/AI provider verification.
- This build has no dependency downloads in the packaging environment, so Django test suite and full HTTP runtime were **not run in this environment**. On a configured Windows or Docker installation run:
  - `python manage.py check`
  - `python manage.py test academy --verbosity 2`
  - `python manage.py makemigrations --check --dry-run`
  - `python manage.py check --deploy` with production environment values.
- Review `docs/SECURITY_GDPR.md` and `docs/RELEASE_STATUS.md` before public deployment.

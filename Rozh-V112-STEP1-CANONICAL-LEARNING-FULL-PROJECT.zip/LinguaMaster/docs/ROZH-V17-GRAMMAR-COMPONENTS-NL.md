# Rozh V17 — visuele grammatica (stap 4)

## Ontwerp
- 42 daadwerkelijk geregistreerde bloktypes met acht gecontroleerde presentatielayouts: note, tokens, table, compare, steps, fill, choice, builder.
- De 42 types zijn **varianten** op herbruikbare componenten; geen 42 los ontwikkelde interactieve widgets. Alleen fill, choice en builder zijn lokaal interactief.
- De oude uitgebreide grammatica, Quick Check, mastery en backend-grading blijven intact. De nieuwe drie oefenvormen geven **geen XP** en wijzigen **geen voortgang**.
- Grammatica toont geen geluid of video. Bestaande gegevens voor audio zijn niet verwijderd uit de database; alleen de afspeelknop op de grammaticapagina is weggelaten.
- Alle docenttekst blijft pure tekst, door Django automatisch ge-escaped. Geen `|safe`, HTML-editor, third-party scripts, fetch, cloud API of migration.
- Manager voegt optioneel `visual_blocks` toe met de JSON-editor en typekiezer in Django Admin. Alleen gepubliceerde GrammarTopics zijn zichtbaar voor leerlingen, zoals voorheen.
- Limiet: 24 visuele blokken per artikel. Elk type is begrensd op velden, lengtes en arrays. Een onbekend type wordt geweigerd.

## Voorbeeld
Zie `docs/ROZH-V17-GRAMMAR-SAMPLE.json`. Plak de inhoud (als JSON) in het bestaande GrammarArticle-contentveld van een eigen testonderwerp. Sla daarna op en publiceer pas na controle.

## Lokale test in Windows PowerShell
Open de map `LinguaMaster` in de uitgepakte ZIP:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\START-ROZH-TEST.ps1
```

In een tweede PowerShell venster, voor testaccounts (pas na geslaagde eerste start):

```powershell
notepad .\.rozh-local-test\TEST-LOGINS-LOCAL-ONLY.txt
```

Ga naar `/grammar/` vanuit het leerlingmenu. Open de Django-admin als testbeheerder om een visueel artikel aan een bestaand testonderwerp toe te voegen.

## Acceptatiecriteria
- Light/Dark, mobiel 320/375/768/1280 px; Sorani RTL en NL/EN; alle labels leesbaar.
- Toetsenbord: navigeren met Tab; Enter activeert controle; de zinsbouwer is zonder drag & drop bedienbaar.
- Correcte antwoordcontrole is **uitsluitend client-side oefening**; nooit inzetten voor badges, XP, certificaten of ontgrendeling.
- Live Django-render, database, MFA, echte Windows PowerShell en Screen Reader zijn NIET getest in deze uitvoeromgeving; lokaal accepteren vereist aanvullende tests.
- Productie: NO-GO totdat de volledige acceptatie is uitgevoerd.

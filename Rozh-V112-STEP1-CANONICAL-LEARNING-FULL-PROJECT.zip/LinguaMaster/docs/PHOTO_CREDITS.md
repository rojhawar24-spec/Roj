# Bundled learning photographs

The four photographs are downloaded locally so the application does not send a learner's browser to an image CDN. They are used for vocabulary practice and were visually checked against their prompts. No learner photographs are uploaded.

| Local asset | Source |
| --- | --- |
| `coffee.jpg` | https://images.unsplash.com/photo-1509042239860-f550ce710b93 |
| `books.jpg` | https://images.unsplash.com/photo-1491841550275-ad7854e35ca6 |
| `train.jpg` | https://images.unsplash.com/photo-1474487548417-781cb71495f3 |
| `forest.jpg` | https://images.unsplash.com/photo-1473448912268-2022ce9509d8 |

Source platform: [Unsplash](https://unsplash.com). Platform license information: [Unsplash License](https://unsplash.com/license). Original source URLs are retained here for attribution and replacement. `books.jpg` shows one person reading one book; its vocabulary prompt uses the singular noun.

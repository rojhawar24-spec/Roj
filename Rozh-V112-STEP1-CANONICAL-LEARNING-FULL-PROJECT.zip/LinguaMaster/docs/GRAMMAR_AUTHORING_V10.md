# Grammatica toevoegen met uitleg, tabellen en zinsbouw

De gewone `GrammarTopic` blijft de basis: taal, niveau, titel, uitleg, voorbeelden en de korte oefening. De optionele **GrammarArticle** voegt langere uitleg en visuele onderdelen toe. Bestaande onderwerpen blijven werken zonder zo'n artikel. Het toevoegen van een artikel verandert geen antwoordmodel of voortgang van leerlingen.

Alle tekst is gewone tekst. HTML en JavaScript worden nooit als vormgeving uitgevoerd. Gebruik lege regels om alinea's te scheiden. Gebruik de gestructureerde velden voor tabellen en gekleurde zinsdelen.

## Via het beheerpaneel

1. Open het beveiligde Django-beheerpaneel en kies **Grammar topics**.
2. Maak een onderwerp of open een bestaand onderwerp. Kies de juiste taal en het juiste niveau.
3. Vul de gewone uitleg, voorbeelden, uitzonderingen, veelgemaakte fouten en korte oefening in.
4. Voeg onder **Visual grammar article (optional)** één artikel toe. Plak bij **content** alleen het object onder `article` uit het voorbeeld hieronder.
5. Sla het onderwerp eerst als concept op (`published` uit), controleer de inhoud en publiceer wanneer het klaar is. Concepten verschijnen niet op de publieke website.

Bewaar je originele JSON-bestanden apart. De importeur bewaart bestaande onderwerpen standaard en overschrijft ze alleen met een expliciete `--update`.

## Via een JSON-bestand

De taal en het niveau moeten al bestaan. Onderwerpen worden herkend aan **taal + niveau + slug**. Gebruik een vaste slug, bijvoorbeeld `present-tense-basics`.

```sh
python manage.py import_grammar mijn-grammatica.json --dry-run
python manage.py import_grammar mijn-grammatica.json
```

Een bestaand onderwerp aanpassen is een aparte, bewuste stap:

```sh
python manage.py import_grammar mijn-grammatica.json --update --dry-run
python manage.py import_grammar mijn-grammatica.json --update
```

De import is één transactie: als een onderwerp ongeldig is, wordt niets uit het bestand opgeslagen. `--dry-run` voert dezelfde controles uit en draait alle wijzigingen terug. Per bestand zijn maximaal 100 onderwerpen en 2 MiB toegestaan.

Bij een **nieuw** onderwerp vul je ook de gewone verplichte GrammarTopic-velden in, zoals in dit complete voorbeeld. `published` is standaard `false`: publiceer pas na inhoudelijke controle. Voor een **bestaand** onderwerp mag je met `--update` alleen `level`, `slug` en `article` meesturen; de weggelaten gewone velden blijven dan behouden. Het meegestuurde artikel wordt wel volledig vervangen.

```json
{
  "schema_version": 1,
  "language": "nl",
  "topics": [
    {
      "level": "A1",
      "slug": "present-tense-basics",
      "title": "De tegenwoordige tijd: ik werk, jij werkt",
      "explanation": "In de tegenwoordige tijd verandert het werkwoord met het onderwerp. Begin bij de infinitief: werken. De stam is werk.\n\nBij ik gebruik je meestal de stam: ik werk. Bij jij, hij en zij gebruik je in een gewone mededelende zin meestal stam + t: jij werkt. Bij wij, jullie en zij gebruik je de infinitief: wij werken.",
      "examples": ["Ik werk vandaag.", "Jij werkt morgen.", "Wij werken samen."],
      "exceptions": "Zijn en hebben zijn onregelmatig. Bij inversie met jij vervalt de extra t: Werk jij vandaag? Het behoud van de stam-t blijft belangrijk: antwoord jij?",
      "common_mistakes": "Schrijf niet hij werken. Kies hij werkt. Na het werkwoord gebruik je met jij de stam: werk jij?",
      "audio_text": "Ik werk vandaag. Jij werkt morgen. Wij werken samen.",
      "check_question": "Welke zin is correct?",
      "check_options": ["Hij werkt vandaag.", "Hij werken vandaag.", "Hij werk vandaag."],
      "check_answer": "Hij werkt vandaag.",
      "published": false,
      "article": {
        "intro": "Leer hoe je een regelmatige werkwoordsvorm kiest en zie meteen wat er in een vraag verandert.",
        "learning_goals": [
          "De stam van een regelmatig werkwoord herkennen.",
          "Kiezen tussen werk, werkt en werken.",
          "Het verschil tussen jij werkt en werk jij uitleggen."
        ],
        "sections": [
          {
            "title": "Begin bij de persoon",
            "body": "Zoek eerst wie de handeling uitvoert. In Ik werk vandaag is ik het onderwerp. Daarom gebruik je de stam werk.\n\nMet één andere persoon gebruik je in de gewone woordvolgorde meestal stam + t. Vergelijk ik werk met hij werkt."
          },
          {
            "title": "Een vraag met jij",
            "body": "In een ja-neevraag staat het werkwoord vooraan. Komt jij na het werkwoord, dan vervalt de toegevoegde t: Jij werkt vandaag wordt Werk jij vandaag?\n\nVergelijk dit met hij: Werkt hij vandaag? Daar blijft de t staan."
          }
        ],
        "rule_tables": [
          {
            "title": "Werken in de tegenwoordige tijd",
            "columns": ["Onderwerp", "Vorm", "Voorbeeld"],
            "rows": [
              ["ik", "stam", "Ik werk."],
              ["jij / hij / zij", "stam + t", "Jij werkt."],
              ["wij / jullie / zij", "infinitief", "Wij werken."]
            ],
            "note": "Dit overzicht gaat over gewone mededelende zinnen met regelmatige werkwoorden. Leer zijn en hebben apart."
          }
        ],
        "sentence_patterns": [
          {
            "label": "Een gewone zin",
            "tokens": [
              {"text": "Jij", "role": "subject"},
              {"text": "werkt", "role": "verb"},
              {"text": "vandaag.", "role": "time"}
            ]
          },
          {
            "label": "Een vraag met jij",
            "tokens": [
              {"text": "Werk", "role": "verb"},
              {"text": "jij", "role": "subject"},
              {"text": "vandaag?", "role": "time"}
            ]
          }
        ],
        "example_pairs": [
          {
            "original": "Ik werk vandaag thuis.",
            "translation": "I am working at home today.",
            "note": "Ik hoort bij de stam werk."
          },
          {
            "original": "Werk jij morgen?",
            "translation": "Are you working tomorrow?",
            "note": "Jij staat na het werkwoord: de extra t vervalt."
          }
        ],
        "common_traps": [
          {
            "wrong": "Hij werken vandaag.",
            "correct": "Hij werkt vandaag.",
            "why": "Hij is enkelvoud. Gebruik in deze zin stam + t."
          },
          {
            "wrong": "Werkt jij morgen?",
            "correct": "Werk jij morgen?",
            "why": "Als jij na het werkwoord staat, vervalt de extra t."
          }
        ]
      }
    }
  ]
}
```

## Beschikbare onderdelen

Je hoeft niet ieder onderdeel te gebruiken. Weggelaten onderdelen worden leeg gelaten. Onbekende veldnamen worden afgewezen, zodat typefouten geen inhoud laten verdwijnen.

| Veld in `article` | Vorm | Limiet |
|---|---|---|
| `intro` | Korte inleiding als tekst | 3.000 tekens |
| `learning_goals` | Lijst van leerdoelen | 8, elk 250 tekens |
| `sections` | Lijst van `title`, `body` | 12; titel 160, uitleg 8.000 tekens |
| `rule_tables` | `title`, `columns`, `rows`, optionele `note` | 8 tabellen; 1–6 kolommen, 1–30 rijen |
| `sentence_patterns` | `label`, `tokens` | 10 patronen; maximaal 20 zinsdelen per patroon |
| `example_pairs` | `original`, `translation`, optionele `note` | 20 voorbeelden |
| `common_traps` | `wrong`, `correct`, `why` | 12 vergelijkingen |

Iedere tabelrij moet precies evenveel cellen hebben als er kolommen zijn. De eerste cel wordt als rijkop weergegeven. Schrijf de gegevens zo dat die cel beschrijft waar de rij over gaat.

Een zinsdeel heeft `text` en `role`. De toegestane rollen zijn `subject`, `verb`, `object`, `time`, `place`, `connector` en `other`. De website gebruikt veilige vaste kleuren én vertaalde rolbenamingen. De betekenis hangt dus niet alleen van kleur af.

Alle artikeltekst samen mag maximaal 90.000 tekens bevatten. Voorbeelden en tabelcellen hebben aanvullende tekstlimieten. De importeur noemt het veld dat verbeterd moet worden.

## Inhoud en vertaling

De interface ondersteunt Nederlands, Engels, Sorani en Arabisch. **De geschreven cursusinhoud wordt niet automatisch vertaald.** Kies zelf de taal van de uitleg en de vertalingen bij voorbeelden. Nederlandse, Engelse, Duitse en Franse zinsdiagrammen behouden hun leesrichting, ook als de interface rechts naar links staat.

Een goede uitleg bevat het gebruik, de vorm, de woordvolgorde, natuurlijke voorbeelden en een duidelijke reden waarom een veelgemaakte fout onjuist is. De korte oefening is een geheugensteun; drie geslaagde herhaaldagen zijn geen bewijs van een officieel taalniveau. Laat uitgebreide A0–C1-inhoud door een docent controleren voordat je volledigheid of niveaubeheersing belooft.

## V15 — Extra kaarten en auteurstools

Naast de bestaande artikelen kun je **optioneel** drie nieuwe velden toevoegen in hetzelfde `article`-object:

```json
{
  "quick_rules": [
    {"kind":"rule", "title":"Korte regel", "body":"De hoofdregel in één of twee zinnen."},
    {"kind":"tip", "title":"Handig ezelsbruggetje", "body":"Een onthoudtip."},
    {"kind":"warning", "title":"Veelgemaakte fout", "body":"Een fout die je wilt vermijden."},
    {"kind":"remember", "title":"Belangrijk", "body":"Iets om te onthouden."}
  ],
  "checklist": ["Controleer het onderwerp.", "Controleer de persoonsvorm."],
  "faq": [{"question":"Waarom verandert dit?", "answer":"Omdat het onderwerp de vorm bepaalt."}]
}
```

**Gebruik dit object alleen als voorbeeld van de nieuwe velden**. Combineer het in je echte artikel met de bestaande `intro`, `sections`, `rule_tables`, `sentence_patterns`, `example_pairs` en `common_traps`. Maximaal 16 kaarten, 20 checklistregels en 20 vragen. Alles is gewone tekst, nooit HTML. Django weigert onbekende velden en ongeldige bloktypes.

In de beveiligde admin bij een grammaticaonderwerp kun je via **Grammar block builder** blokken toevoegen. Er zijn knoppen voor kaarten, FAQ, voorbeelden, uitlegsecties, vergelijkende tabellen en **rij/kolom toevoegen** aan de laatste tabel. Je kunt de JSON eronder nauwkeurig aanpassen. De preview gebruikt `textContent` en voert ingevoerde HTML niet uit. Het formulier wordt pas opgeslagen als je op de normale Django-knop *Save* klikt; er is geen automatische publicatie.

Dit is **geen complete Tiptap- of CKEditor-implementatie** en heeft nog geen afbeelding-/audio-upload of automatische server-autosave. Die functies vergen afzonderlijke uploadvalidatie, preview en autorisatie. Bewaar voorlopig versies met de bestaande Django-admin- en contentrevisiefuncties.

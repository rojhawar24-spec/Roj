# Rozh V109 — گواستنەوەی پرسیارە کۆنەکان

- بنەما V108. 27 پرسیاری سنوورداری کۆنی EN/DE/FR لە seed ـدا هەن. پێشتر تەنها کۆرسی نوێ چاک دەکرا؛ ئێستا فرمانی upgrade_starter_short بۆ داتای کۆن زیاد کرا.
- dry-run: `python manage.py upgrade_starter_short --settings=config.settings_local_qa`؛ هیچ نووسینێک ناکات. eligible_ids و blocked_ids دەدات.
- Apply: تەنها دوای backup، داخستنی سێرڤەر/worker و هەموو نووسەرەکانی DB، و پشکنینی ID ـەکان، `python manage.py upgrade_starter_short --apply --id ID --settings=config.settings_local_qa`. ID جێگۆڕکێیە و نابێت بە شێوەی literal جێبەجێ بکرێت. بۆ چەند ID، --id دووبارە بکەوە. هیچ apply ـێک بەبێ ID نییە. هەر ID ـێکی ناسازگار هەموو داواکارییەکە ڕەت دەکاتەوە.
- هەمان exercise ID، answer، explanation، difficulty و order پارێزراون؛ kind/prompt/content_version گۆڕانکارییان تێدا دەبێت، ContentRevision و AuditEvent زیاد دەکرێن. هیچ تۆماری فێرخواز، XP یان progress ناسڕدرێتەوە. ئەمە بڕیاری دیزاینە؛ پشکنینی ڕاستەقینەی DB هێشتا نەکراوە. هەموو نووسەرەکانی DB دەبێت لە کاتی apply وەستێنرابن.
- 5 تاقیکردنەوەی offline نوێ، هەموو 27 نموونە و دەستکاریی Manager پشکنران. 3 تاقیکردنەوەی Django نووسراون و نەڕاون. نەبوونی Django و شکستی دابەزاندن ڕێگرن.
- 4 کارە کۆتاییە دیاریکراوەکان لە V108: (1) گواستنەوەی داتای کۆن: فرمانی پرسیاری short ئامادە، بەڵام داتای واقعی و هەموو جۆرە کۆنەکان پشکنینیان ماوە؛ (2) دەنگی پەسەندکراو؛ (3) Django/PostgreSQL واقعی؛ (4) Design/Accessibility واقعی. هیچ یەک بە تەواوی داخراو نییە. ئەمە ژمارەی bug نییە. Production approved=false.

# Rozh release status — Clean V7 Debug

**Status: NO-GO for public production deployment.**

- Python offline regression: 868/868 PASS (does not require Django).
- Static template/routes/assets source validation: PASS (not rendered Django E2E).
- Chromium responsive fixtures: 96/96 PASS (synthetic shells, not live routes).
- Django integration and real authentication: BLOCKED — Django/DRF unavailable in the current audit environment.
- Live PostgreSQL, Redis, SMTP, MFA/browser acceptance, full accessibility review: NOT VERIFIED.
- Course content: starter material; not verified as complete A0–C1.

A dedicated isolated Windows test runner is available at `scripts/Run-DebugV7-Isolated-Django.ps1`.
Run on a copy, preserving live `.env`, local user database, and historical backup.
Do not present offline/static test counts as real production readiness.

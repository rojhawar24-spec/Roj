# Rozh V101 — Leer & Speel: توێژینەوە، پلان و یەکەم چاکسازی

## ١. بنەما و سەرچاوەکان
- بنەما: Rozh V100 (1072 entries; SHA-256 4d103f3f4b60d64947c3aed95a7e7df2191d8b03b7003fdc14c333ac8016289a). CRC و 1071 file hashes پشتڕاست کرانەوە.
- سەرچاوە فەرمییەکانی Duolingo (پشکنینی بەڵگە و وێنەی گشتی؛ نەک دەستگەیشتن بە کۆدی ناوخۆیی یان تاقیکردنەوەی هەموو ئەپ):
  - https://blog.duolingo.com/duolingo-teaching-method/
  - https://blog.duolingo.com/new-duolingo-home-screen-design/
  - https://blog.duolingo.com/right-level-of-difficulty/
  - https://blog.duolingo.com/how-user-reports-improve-course-content/
  - https://blog.duolingo.com/is-google-translate-wrong/
  - https://blog.duolingo.com/covering-all-the-bases-duolingos-approach-to-listening-skills/
  - https://blog.duolingo.com/covering-all-the-bases-duolingos-approach-to-reading-skills/
  - https://blog.duolingo.com/covering-all-the-bases-duolingos-approach-to-writing-skills/
  - https://blog.duolingo.com/explain-my-answer-now-free/
  - https://blog.duolingo.com/guide-to-duolingo-practice-hub/
  - https://design.duolingo.com/identity/typography
- بڕیار: ناسنامە، لۆگۆ، ڕەنگ و دیزاینی Solar Atlas ـی Rozh بمێنێتەوە. تەنها ئەو پرەنسیپانەی فێرکردن و ڕوونی ڕێڕەو وەربگیرێن؛ هیچ کۆد یان دەقی تایبەتی Duolingo کۆپی نەکراوە.

## ٢. پشکنینی کۆدی V100
- academy/views.py: lesson_detail, lesson_answer, _assessment_questions. AJAX/SSR feedback explanation هەبوو، بەڵام solution ـی ڕوون نەبوو. Unit/level assessment MCQ-only.
- academy/lesson_activities_v58.py: 13 canonical historical activity keys + short; server-side deterministic grading; fill_blank variants; word_order token multiplicity; matching permutation. Public payload answer/accepted_answers نادات.
- academy/journey_v11.py: mixed round still generates derived dictation, picture, wordbank, speaking/reflection and accepts legacy kinds. Removing them safely needs progression/old-round checks.
- academy/lesson_flow_v63.py, lesson_readiness_v96.py: next lesson admission and approved audio. Missing approved recording blocks lesson, not a feature to bypass.
- academy/templates/academy/lesson.html, academy/templates/academy/lesson_activity_v58.html: prompts, answer controls, feedback, next; redundant generic motivational heading on every scored question.
- academy/static/academy/app-experience.js: checked question could still appear editable; keyboard shortcuts could change selection during request.
- academy/static/academy/rozh-activities-v82.js and lesson-activities-v58.js: tile and matching controls. Existing accessible dropdown/arrow controls retained, not replaced by untested drag and drop.
- academy/curriculum_policy_v99.py, learning_content_policy_v100.py: five-kind policy currently audit, not universal enforcement. Existing legacy authored and progress data must be preserved.
- academy/manager_content_v48.py and admin.py: publishing/editor paths need coordinated policy in next phase.

## ٣. پلان — پێنج گرووپی کار
1. Feedback and simple question UI: one question, Check, server-owned solution/explanation, explicit Continue; lock accepted answer, allow retry after failed request; 320/360/desktop and RTL. **Implementation delivered in V101; actual Django verification pending.**
2. Canonical five-type policy: MCQ, fill_blank, word_matching, word_order, listening (fixed choice). No speaking, microphone, free writing, free translation or mandatory self-review. Inspect new authoring, mixed rounds, legacy mapping, content audit, versioned migration and preservation of existing progress. Do not silently drop required content or mark it completed. **Open.**
3. Unit/level assessment: same deterministic grading contract for eligible types, or explicit authored MCQ assessment until safe generalization. Retain server admission, heart/XP/round replay protection and 70% lesson vs 80% assessment distinction. **Open.**
4. Content and audio: clear age-neutral instructions, reviewed alternative answers and explanations, progressive difficulty, short lessons, reviewed licensed/self-hosted audio. No AI grading, no unapproved audio and no fabricated success. **Open.**
5. End-to-end acceptance: fresh and upgraded DB; Django HTTP and migrations; PostgreSQL concurrency, all five types, missing audio, stale and duplicate submit, failed and passed round, mobile RTL/dark/keyboard/screen reader; verify actual Windows deployment. **Open.**

## ٤. V101 implementation
- `academy/lesson_feedback_v101.py`: plain-text canonical solution from authored answer or matching pairs, only for wrong answers after grading. Accepted variant remains correct.
- `academy/views.py`, `lesson_batch_step3f.py`: AJAX and SSR return solution after accepted server grading; no public question payload changes, no schema/XP or reward changes.
- `lesson.html`, `app-experience.js`, `rozh-lesson-flow-v63.css`: compact scored question header, solution separate from explanation, accepted fieldset locked; failed request restores editing; keyboard shortcut blocked during pending; clear solution before next question; focus on Continue; mobile target sizing and CSS logical spacing.
- `ui.py`: 8 locale solution labels (not independent professional translation review). Cache versions bumped for JS/CSS and worker. No logo/theme replacement.
- Test scripts: 6 deterministic unit tests covering the five supported types, accepted variants, repeated tokens, matching solution and plain-text rendering. Chromium test: 3 scenarios, desktop/light, 360px Sorani/dark, 320px Dutch/light; mocked response sequence 500→wrong accepted→correct, checks input locking/unlocking, literal HTML-shaped solution as text, focus, cleanup and finish state. 48 existing regression scripts + 2 new scripts passed (50/50). Actual Chromium on isolated fixture; not live Django.
- `academy/test_v101_feedback_http.py`: four live HTTP tests written and CI command extended, not executed here (Django unavailable). No real PostgreSQL/Windows/Screen Reader validation performed.

## ٥. Scope / blockers
- The public Duolingo reference material is not a complete exhaustive inspection of every version/platform/feature of Duolingo.
- V101 is a focused first implementation of the plan, not a complete redesign or a fully certified five-type release. Mixed rounds, all old activities, unit assessment, missing audio and complete runtime acceptance remain open. No progress data or actual user database modified.
- The 50 scripts passed before packaging. Further archive integrity and targeted post-extraction checks are recorded in the release verification JSON. Production approval remains false.

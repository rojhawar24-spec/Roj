# Security, privacy and accessibility checklist

These items separate code controls from operational/legal evidence. GDPR and WCAG conformity cannot be guaranteed by a ZIP file.

## Implemented code controls

- HTTPS redirect/HSTS in production, secure HTTPOnly session cookies, SameSite=Lax, trusted host allowlist, content-type sniff protection, frame denial, security/referrer/permissions policies and restrictive first-party CSP.
- Django default escaping and CSRF; Argon2 preference and length/common-password validators; email verification and password reset tokens; default-private social visibility and AI consent switches.
- Owner-only settings and user changes protected by superuser + TOTP proof; staff admin requires TOTP and model permissions; access to other learners' submitted answers and internal AI logs is restricted.
- Cache-backed login, registration, MFA, assessment and AI endpoint throttling; DRF read-rate limiting. Rate limiting is not a substitute for provider-side DDoS mitigation and reverse-proxy rules. With `TRUST_PROXY=1`, request source IPs are taken from the last `X-Forwarded-For` hop, so only the trusted private Caddy path should reach Django.
- Input/output AI moderation, a fixed provider endpoint, user/global limits, fail-closed behavior, no raw AI prompt logging, and a global budget reserve.
- Private profile export; deletion requiring password re-entry; log deletion after configurable 90/365 days when Celery Beat is running.
- Semantic HTML, labels, tab focus, skip to content, visible focus, reduced motion preferences, responsive layouts and tested color tokens by design intent (not audited against every WCAG criterion).

## Operations REQUIRED before launch

- [ ] Deploy to a real EU location and sign a data processing agreement with the host, SMTP service, AI provider, and any other processors. Confirm subprocessors and international transfers.
- [ ] Identify real controller/operator, registered address, privacy email, support contact, jurisdiction, lawful bases, consumer terms and complaint contact. Obtain legal review for a commercial service.
- [ ] Determine the users' countries and age rules. This version blocks under-16 registration via **self-declaration only**, without robust age assurance or parent authorisation. Do not market to children or claim sufficient child safeguards until professionally reviewed.
- [ ] Confirm whether Article 35 DPIA applies (profiling, AI, children, large-scale monitoring, sensitive prompts) and complete any required assessment and risk mitigations.
- [ ] Create a record of processing activities, data inventory, access model, retention schedule and response workflow for access/erasure/correction/objection/portability requests. The in-app export is not a substitute for a complete rights-request process.
- [ ] Verify privacy text and all service emails against actual processor data flows. Test unsubscribe/withdraw-consent changes. Do not enable third-party analytics or ads without a separate consent/legal assessment.
- [ ] Use the new V5 AES-256-GCM encrypted backup/verify/restore tool, configure retention periods and restricted access, test staged restoration; enforce encrypted at-rest storage for database and TOTP secrets through host/disk and a dedicated field-encryption strategy if threat model requires it.
- [ ] Establish a 72-hour breach-notification assessment and incident response/escalation process; maintain incident records; train administrators on incident handling.
- [ ] Add automated dependency scanning, secrets scanning, SAST/DAST, penetration testing, log-alerting, WAF/rate limits and access/recovery reviews. Pin and promptly patch dependencies.
- [ ] Run Django tests and `check --deploy` on target stack, measure real CLS/LCP/INP on mobile, run WCAG 2.2 AA manual/automated audit and keyboard/screen-reader testing.
- [ ] Verify all email workflows, DNS SPF/DKIM/DMARC, Celery beat/worker schedule, SMTP failures, password recovery, account export/deletion, HTTP security headers and certificate revocation in staging.
- [ ] Review Google Search Essentials and structured data validity; submit sitemap through Search Console; independently test indexing. Google acceptance, rich results and advertising approval cannot be guaranteed.

## Privacy observations

Account and progress records are personally identifiable. When deleting an account, Django cascade removes related learning and social records, while audit events may remain with their actor set to NULL for the declared retention period. Scheduled cleanup is needed to enforce expiry. Public certificate verification reveals a level and issue date but not an email address. Friend activity is opt-in and basic. The local theme preference is stored in localStorage without a tracking identifier.

## Explicit gaps

- No professional accessibility certification (8 one-time TOTP recovery codes now exist), no verified device/session administration, no account lockout service, no real age verification, no documented international AI data transfer agreement, no server-side AI prompt DLP beyond a simple email-address check, no external provider billing reconciliation or invoice-based circuit breaker.
- No full consent management platform for future trackers because this build contains no trackers; any analytics/marketing addition requires reassessment.
- No automated data subject request verification or backup deletion workflow. The operator must handle those separately.
- Browser-assisted transcript comparison and limited writing-form checks exist in V5, but there is no reliable pronunciation evaluation, independently verified writing assessment or human examiner workflow; some browsers may transmit speech to their recognition provider.
- No accreditation or externally validated CEFR examination.

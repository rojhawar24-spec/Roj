# Rozh V95 — Step 3 Phase E · ڕاپۆرتی تاقیکردنەوە

**دۆخ:** Phase E لە تاقیکردنەوەی offline/Chromium سەرکەوتووە. هەنگاوی ٣ بە تەواوی داخراو نییە. هەنگاوی ٢یش Django/Database QA ـی تەواوی نییە.

## دوو کێشەی پشتڕاستکراو

1. **Sentence Builder / Word Order**: وەڵامی ڕاستی فێرخواز بەهۆی جیاوازیی پیتی گەورە/بچووک یان بۆشاییە زیادەکان دەتوانی بە هەڵە ڕەت بکرێتەوە. لە حالەتی spelling ـیش Unicode ـی یەکسان لە شێوەی NFC و NFD بە هەڵە جیا دەپشکنرا. چارەسەر: پێش پشکنینی inventory و order، `NFC` و `casefold()`؛ بۆ چالاکییەکانی tile جیاکردنەوەی وشە لەسەر whitespace، بەڵام پاراستنی ژمارەی وشە و ڕیزبەندیی ڕاست. پیتی ئاکسەنت‌دار لابراو هێشتا نادروستە.
2. **Keyboard focus لە Word Order**: کاتێک وشە بۆ لێواری لیست دەچوو دوگمەی arrow ناچالاک دەبوو و keyboard focus لەدەست دەچوو. چارەسەر: focus بگوازەوە بۆ arrow ـی چالاکی هەمان وشە، نەک دوگمەی disabled.

## شواهد

- **پێش چاککردنەوە**: ٦ لە ٩ تاقیکردنەوەی نوێ لە Phase D شکستیان هێنا.
- **دوای چاککردنەوە**: هەمان ٩ تاقیکردنەوە سەرکەوتوون.
- **Regression**: ١٧/١٧ کۆمەڵەی offline/Chromium، ١٥٦/١٥٦ تاقیکردنەوە.
- **Syntax**: ٦١٧ Python AST و ٤٣ JavaScript Node ـی پاک.
- **Django HTTP/Database**: نەکراوە. هەوڵی `python manage.py check --settings=config.settings_local_qa` بە `ModuleNotFoundError: No module named 'django'` وەستا. نەکرایە PASS.

## سنوور و داواکارییە ماوەکان

- تاقیکردنەوەی ڕاستەقینەی HTTP، PostgreSQL/SQLite، مۆدێل، session و score persistence ئەنجام نەدراوە.
- پشکنینی بەکارهێنەری ڕاستەقینە، ترجومەی ٩ زمان، WCAG تەواو و ١٣ جۆری چالاکی بە هەموو دۆخەکان ماون.
- هیچ داتابەیسی ڕاستەقینە، .env، فایلە پەنهانەکان یان ZIP ـی release ـی کۆن لەم ZIP ـەدا دانەنراون.
- ئەم Phase ـە بۆ قوتابخانە یان production ڕێپێدراو نییە.

## فایلە گۆڕاوەکان

- `academy/lesson_activities_v58.py`
- `academy/static/academy/rozh-activities-v82.js`
- `scripts/test_step3e_grading_keyboard.py` (نوێ)
- ئەم ڕاپۆرت و manifest ـی فازەکە (نوێ)

from django.shortcuts import redirect
from django.urls import reverse
from django.contrib.auth import logout
from django.http import JsonResponse, HttpResponse
from .models import Profile
from .account_signin_policy_v27 import account_signin_permitted
from .manager_roles_v48 import privileged_account_eligible
from .session_revocation_v91 import session_matches_account
from .privilege_session_v93 import session_matches_privilege

class AccountStateMiddleware:
    """Fail closed for authenticated learning routes with revoked account state.

    Session auth alone is not proof that an imported Profile is still eligible.
    Existing login/MFA/Manager gates remain the authority for their own flows.
    On private routes return 403 consistently (including repeated requests).
    Public pages revoke the stale session and remain accessible anonymously.
    """
    PUBLIC_PAGES = frozenset({
        '/', '/en/', '/ckb/', '/ar/', '/kmr/', '/ku/', '/uk/', '/fr/',
        '/try/', '/privacy/', '/terms/', '/how-it-works/', '/health/',
        '/ready/', '/robots.txt', '/sitemap.xml', '/service-worker.js',
    })
    PUBLIC_PREFIXES = (
        '/languages/', '/register/', '/resend-verification/', '/verify/',
        '/password-reset/', '/reset/',
    )

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        user = getattr(request, 'user', None)
        if user is not None and getattr(user, 'is_authenticated', False):
            profile = Profile.objects.filter(user_id=user.pk).first()
            eligible = account_signin_permitted(user, profile)
            # Even an account suspended and reinstated *between* requests
            # invalidates every older login: its manager action increments
            # email_verification_version. Fail closed for pre-V91 sessions
            # with no binding, requiring a new password/MFA login.
            # Fail closed for sessions whose permissions/groups changed after
            # login, even if an unmanaged SQL edit skipped revision bumping.
            # Older pre-V93 sessions are intentionally required to re-login.
            if eligible and (not session_matches_account(request.session, profile)
                             or not session_matches_privilege(request.session, user)):
                logout(request)
                if request.path.startswith('/api/'):
                    response = JsonResponse({'detail': 'Authentication required.'}, status=401)
                    response['Cache-Control'] = 'no-store'
                    return response
                if request.path in self.PUBLIC_PAGES or request.path.startswith(self.PUBLIC_PREFIXES):
                    return self.get_response(request)
                return redirect('login')
            # If this session actually encountered a revoked account before,
            # restoring the Profile is NOT permission to reuse its old login.
            # Require a new password/MFA sign-in after reinstatement.
            if eligible and request.session.get('rozh_revocation_seen'):
                logout(request)
                if request.path.startswith('/api/'):
                    response = JsonResponse({'detail': 'Authentication required.'}, status=401)
                    response['Cache-Control'] = 'no-store'
                    return response
                return redirect('login')
            if not eligible:
                path = request.path
                if path in self.PUBLIC_PAGES or path.startswith(self.PUBLIC_PREFIXES):
                    logout(request)
                    return self.get_response(request)
                # These flows have existing dedicated fail-closed handling.
                # Preserve their documented redirect/403 behavior.
                if path == '/login/' or path.startswith(('/mfa/', '/secure-admin/')):
                    return self.get_response(request)
                # Preserve a fail-closed marker. A later unsuspension must
                # never silently reactivate this already-denied session.
                request.session['rozh_revocation_seen'] = True
                if path.startswith('/api/'):
                    response = JsonResponse({'detail': 'Access denied.'}, status=403)
                else:
                    response = HttpResponse('Account access unavailable.', status=403)
                response['Cache-Control'] = 'no-store'
                return response
        return self.get_response(request)

class AdminMFAMiddleware:
    """No access to Django admin without authenticated user + completed TOTP."""
    def __init__(self,get_response): self.get_response=get_response
    def __call__(self,request):
        if request.path.startswith('/secure-admin/'):
            user = request.user
            # A legacy/staff account may not yet have a Profile row. Do not
            # raise RelatedObjectDoesNotExist (HTTP 500) or bypass MFA.
            # Re-evaluate ownership and revocation at EACH request: a valid
            # MFA session alone cannot preserve Django Admin privileges after
            # a suspension, email-verification revocation or quarantine.
            permitted = bool(
                getattr(user, 'is_authenticated', False)
                and getattr(user, 'is_staff', False)
                and privileged_account_eligible(user)
                and request.session.get('mfa_verified_id') == user.pk
            )
            if not permitted:
                return redirect(reverse('login'))
        return self.get_response(request)

class SecurityHeadersMiddleware:
    def __init__(self,get_response):self.get_response=get_response
    def __call__(self,request):
        response=self.get_response(request)
        response['Content-Security-Policy']=("default-src 'self'; script-src 'self'; style-src 'self'; "
            "img-src 'self' data:; font-src 'self'; connect-src 'self'; media-src 'self'; "
            "frame-ancestors 'none'; form-action 'self' https://checkout.stripe.com; base-uri 'self'; object-src 'none'")
        response['Permissions-Policy']='camera=(), microphone=(self), geolocation=()'
        # Never allow a shared browser or reverse proxy to retain private
        # learning data, account forms, verification tokens or MFA screens.
        sensitive_prefixes=('/login/', '/register/', '/resend-verification/',
                            '/verify/', '/mfa/', '/password-reset/', '/reset/')
        # The inner account guard can log out a revoked user BEFORE this
        # response reaches us. Do not infer public cacheability just because
        # request.user is now anonymous; denial/redirect responses on private
        # routes still need no-store and noindex.
        private_prefixes=('/secure-admin/', '/api/', '/certificate/', '/dashboard/',
                          '/onboarding/', '/skills/', '/account/', '/profile/',
                          '/manager/', '/play/', '/lessons/', '/friends/')
        if request.user.is_authenticated or request.path.startswith(sensitive_prefixes + private_prefixes):
            response['Cache-Control']='private, no-store, max-age=0'
            response['Pragma']='no-cache'
            response['X-Robots-Tag']='noindex, nofollow, noarchive'
        return response

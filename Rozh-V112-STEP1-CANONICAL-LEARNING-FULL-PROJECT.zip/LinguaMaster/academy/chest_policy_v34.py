"""Single fail-closed admission policy for Daily Chest XP rewards.

This pure policy can be exercised without Django. The views also lock the live
Profile/Language rows inside the payout transaction. A prior XP balance alone
is not proof that a learner may claim an award right now.
"""


def chest_claim_allowed(profile, *, user_active, course_published):
    return bool(
        profile is not None
        and user_active
        and course_published
        and profile.placement_completed
        and profile.preferred_language_id is not None
        and (not profile.onboarding_required or profile.onboarding_completed)
        and profile.suspended_at is None
        and not profile.legacy_review_required
    )

"""Live Django contracts, not counted as passed until run with Django."""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse
from .models import Language, Level, Unit, Lesson, Exercise, Profile

class FeedbackHttpTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user=get_user_model().objects.create_user('v101-feedback',password='SyntheticFeedbackTest!2026')
        lang=Language.objects.create(code='nl',name='Dutch',slug='v101-nl',description='QA',is_published=True)
        level=Level.objects.create(language=lang,code='A0',description='QA')
        unit=Unit.objects.create(level=level,slug='v101-unit',title='QA',summary='QA',published=True)
        cls.lesson=Lesson.objects.create(unit=unit,slug='v101-lesson',title='QA',skill='grammar',content='Synthetic text only',published=True)
        cls.question=Exercise.objects.create(lesson=cls.lesson,kind='fill_blank',prompt='Ik ___ hier.',options=[],answer='woon',explanation='Example explanation',activity_data={'accepted_answers':['verblijf']})
        Profile.objects.filter(user=cls.user).update(preferred_language=lang,placement_completed=True,onboarding_required=False,onboarding_completed=True,suspended_at=None,legacy_review_required=False)

    def setUp(self):
        cache.clear()
        self.client.force_login(self.user)
        self.url=reverse('lesson',args=[self.lesson.pk])
        self.answer_url=reverse('lesson_answer',args=[self.lesson.pk])
        page=self.client.get(self.url)
        self.assertEqual(page.status_code,200)
        self.round=page.context['lesson_round_key']

    def submit(self,answer,round_key=None):
        return self.client.post(self.answer_url,{'exercise_id':self.question.pk,'answer':answer,'round_key':round_key or self.round})

    def test_solution_only_after_accepted_wrong_answer(self):
        wrong=self.submit('fiets')
        self.assertEqual(wrong.status_code,200)
        self.assertFalse(wrong.json()['correct'])
        self.assertEqual(wrong.json()['solution'],'woon')
        self.assertEqual(wrong.json()['explanation'],'Example explanation')
        replay=self.submit('woon')
        self.assertEqual(replay.status_code,409)
        self.assertNotIn('solution',replay.json())

    def test_valid_variant_not_corrected(self):
        result=self.submit('Verblijf')
        self.assertEqual(result.status_code,200)
        self.assertTrue(result.json()['correct'])
        self.assertEqual(result.json()['solution'],'')

    def test_expired_round_does_not_reveal_solution(self):
        denied=self.submit('fiets','0'*32)
        self.assertEqual(denied.status_code,409)
        self.assertNotIn('solution',denied.json())

    def test_ssr_wrong_answer_contains_canonical_solution(self):
        result=self.client.post(self.url,{'round_key':self.round,f'answer_{self.question.pk}':'fiets'})
        self.assertEqual(result.status_code,200)
        self.assertEqual(result.context['feedback'][0]['solution'],'woon')

"""V77: separately approved assessment content and interruption-safe quiz state."""
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone

BANDS = [('A0', 'A0 · Pre-A1'), ('A1', 'A1'), ('A2', 'A2'),
         ('B1', 'B1'), ('B2', 'B2'), ('C1', 'C1')]
PLACEMENT_SKILLS = [('reading', 'Reading comprehension'),
                    ('listening', 'Listening comprehension'),
                    ('grammar', 'Grammar in context'),
                    ('vocabulary', 'Vocabulary in context'),
                    ('writing', 'Controlled short written answer')]


class PlacementBankItem(models.Model):
    """Manually authored/reviewed course item, never auto-generated for a learner.

    Stage is a provisional editorial difficulty label; NOT calibrated CEFR
    measurement. Writing is controlled short-answer, not free composition.
    """
    course = models.ForeignKey('academy.Language', on_delete=models.CASCADE,
                               related_name='placement_bank_items')
    stage = models.CharField(max_length=2, choices=BANDS)
    skill = models.CharField(max_length=12, choices=PLACEMENT_SKILLS)
    prompt = models.TextField()
    stimulus = models.TextField(blank=True, default='')
    audio_path = models.CharField(max_length=180, blank=True, default='',
                                  help_text='Listening only: academy/placement-audio/example.mp3 (self-hosted static file).')
    options = models.JSONField(default=list, blank=True)
    answer = models.CharField(max_length=300, blank=True, default='')
    accepted_answers = models.JSONField(default=list, blank=True,
                                        help_text='Only controlled writing; a list of reviewed exact acceptable answers.')
    source_reference = models.CharField(max_length=250, blank=True, default='',
                                       help_text='Educator/copyright-safe source and objective.')
    educator_reviewed = models.BooleanField(default=False)
    published = models.BooleanField(default=False)
    content_version = models.PositiveIntegerField(default=1)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ('course_id', 'stage', 'skill', 'pk')
        indexes = [models.Index(fields=['course', 'published', 'stage', 'skill'],
                                name='placement_bank_filter_v77')]

    def clean(self):
        super().clean()
        from .placement_adaptive_v77 import item_usable, valid_audio_path
        if self.published and not self.educator_reviewed:
            raise ValidationError({'published': 'Educator approval is required before publication.'})
        if self.published and not self.source_reference.strip():
            raise ValidationError({'source_reference': 'Supply the content source and teaching objective.'})
        if self.published and self.skill == 'listening' and not valid_audio_path(self.audio_path):
            raise ValidationError({'audio_path': 'A real self-hosted MP3/OGG/WAV asset is required.'})
        if self.published and not item_usable(self):
            raise ValidationError('A published placement item must have a real valid answer and teaching context.')

    def __str__(self):
        return f'{self.course.code} {self.stage} {self.skill} #{self.pk}'


class PlacementRun(models.Model):
    """One private run per learner+course; never independently mints XP or levels."""
    STATUSES = [('active', 'In progress'), ('ready', 'Awaiting learner choice'),
                ('confirmed', 'Confirmed')]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                             related_name='smart_placement_runs')
    course = models.ForeignKey('academy.Language', on_delete=models.CASCADE,
                               related_name='smart_placement_runs')
    status = models.CharField(max_length=10, choices=STATUSES, default='active')
    history = models.JSONField(default=list)
    current_item_id = models.PositiveIntegerField(null=True, blank=True)
    current_version = models.PositiveIntegerField(default=0)
    current_digest = models.CharField(max_length=64, blank=True, default='')
    result = models.JSONField(default=dict)
    chosen_level = models.CharField(max_length=2, blank=True, default='', choices=BANDS)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['user', 'course'],
                        name='one_smart_placement_run_v77')]
        indexes = [models.Index(fields=['user', 'status'], name='placement_run_user_v77')]

    def __str__(self):
        return f'{self.user_id} / {self.course_id}: {self.status}'

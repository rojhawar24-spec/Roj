"""Django integration regressions for the V8 professional quality release.

These tests must run with the real Django environment on Windows/CI.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.utils import timezone
from django.urls import reverse

from .models import Language, Level, Unit, Lesson, Exercise, LessonProgress, Vocabulary, ReviewCard, MistakeRecord
from .content_audit import audit_published_content

User = get_user_model()


class ProfessionalLearningIntegrityTests(TestCase):
    def setUp(self):
        self.user=User.objects.create_user('prolearner', 'prolearner@example.org', 'StrongPassword!987')
        self.language=Language.objects.create(code='nl', name='Dutch', slug='dutch', description='Starter', is_published=True)
        profile=self.user.learning_profile
        profile.preferred_language=self.language
        profile.placement_completed=True
        profile.save(update_fields=['preferred_language','placement_completed'])
        self.level=Level.objects.create(language=self.language, code='A0', description='Start', order=0)
        self.unit=Unit.objects.create(level=self.level, slug='first', title='Start here', summary='Learn greetings', published=True)
        self.lesson=Lesson.objects.create(unit=self.unit, slug='hello', title='Say hello', skill='grammar',content='Say Hallo.',published=True)
        self.a=Exercise.objects.create(lesson=self.lesson, kind='mcq', prompt='Hello?', options=['Hallo','Nee'], answer='Hallo', explanation='Hallo means hello.')
        self.b=Exercise.objects.create(lesson=self.lesson, kind='mcq', prompt='No?', options=['Nee','Hallo'], answer='Nee', explanation='Nee means no.')
        self.client.force_login(self.user)

    def test_checked_answer_cannot_be_overwritten_within_same_round(self):
        url=reverse('lesson_answer',args=[self.lesson.pk])
        first=self.client.post(url,{'exercise_id':self.a.pk,'answer':'Nee'})
        self.assertEqual(first.status_code,200)
        duplicate=self.client.post(url,{'exercise_id':self.a.pk,'answer':'Hallo'})
        self.assertEqual(duplicate.status_code,409)
        self.assertEqual(MistakeRecord.objects.get(user=self.user,exercise=self.a).corrected_at,None)
        finish=self.client.post(url,{'exercise_id':self.b.pk,'answer':'Nee'})
        self.assertEqual(finish.status_code,200)
        self.assertEqual(finish.json()['score'],50)
        self.assertFalse(finish.json()['completed'])
        self.assertFalse(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())
        # A real new round is allowed; the first successful completion earns XP once.
        self.assertEqual(self.client.post(url,{'exercise_id':self.a.pk,'answer':'Hallo'}).status_code,200)
        good=self.client.post(url,{'exercise_id':self.b.pk,'answer':'Nee'})
        self.assertTrue(good.json()['completed'])
        self.assertEqual(good.json()['xp_awarded'],20)

    def test_returning_to_lesson_starts_a_fresh_round(self):
        url=reverse('lesson_answer',args=[self.lesson.pk])
        self.assertEqual(self.client.post(url,{'exercise_id':self.a.pk,'answer':'Nee'}).status_code,200)
        self.assertEqual(self.client.post(url,{'exercise_id':self.a.pk,'answer':'Hallo'}).status_code,409)
        # Navigating back to the lesson page must let learners restart cleanly.
        self.assertEqual(self.client.get(self.lesson.get_absolute_url()).status_code,200)
        self.assertEqual(self.client.post(url,{'exercise_id':self.a.pk,'answer':'Hallo'}).status_code,200)

    def test_dashboard_does_not_show_private_or_withdrawn_content_counts(self):
        profile=self.user.learning_profile
        profile.placement_completed=True
        profile.preferred_language=self.language
        profile.save(update_fields=['placement_completed','preferred_language'])
        hidden=Unit.objects.create(level=self.level, slug='hidden', title='Not published', summary='Private unit', published=False)
        hidden_lesson=Lesson.objects.create(unit=hidden, slug='draft', title='Draft', skill='grammar', content='Draft content',published=True)
        LessonProgress.objects.create(user=self.user, lesson=hidden_lesson, score=100)
        word=Vocabulary.objects.create(level=self.level,word='geheim',translation='secret',pronunciation='guh-KHIME',example='Een geheim.',published=False)
        ReviewCard.objects.create(user=self.user,vocabulary=word,due=timezone.now())
        exercise=Exercise.objects.create(lesson=hidden_lesson,kind='mcq',prompt='Private?',options=['Yes','No'],answer='Yes',explanation='Private')
        MistakeRecord.objects.create(user=self.user,exercise=exercise)
        response=self.client.get('/dashboard/')
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.context['completed_count'],0)
        self.assertEqual(response.context['due'],0)
        self.assertEqual(response.context['mistakes_count'],0)

    def test_owner_content_health_detects_invalid_quiz(self):
        self.a.options=['Hallo','HALLO']
        self.a.answer='Invalid'
        self.a.save(update_fields=['options','answer'])
        report=audit_published_content()
        self.assertGreater(report['errors'],0)
        self.assertIn('choices-duplicate',{item['code'] for item in report['issues']})
        self.assertIn('answer-not-in-options',{item['code'] for item in report['issues']})

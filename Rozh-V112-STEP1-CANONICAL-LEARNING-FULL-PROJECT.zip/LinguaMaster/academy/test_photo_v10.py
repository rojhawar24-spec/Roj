"""Trust-boundary regressions for private, server-graded visual vocabulary."""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import Client, TestCase
from django.urls import reverse
from django.utils import timezone

from .heart_models import HeartBalance, HeartEvent
from .models import Language, Profile, XPEvent
from .photo_v10 import WORDS, TEXT
from .visual_models import PhotoAttempt


class PhotoPracticeV10Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user('photo-learner')
        cls.other = get_user_model().objects.create_user('other-photo-learner')
        cls.languages = {}
        for code, name in [('en','English'),('nl','Dutch'),('de','German'),('fr','French'),('es','Spanish')]:
            cls.languages[code] = Language.objects.create(code=code, name=name, slug=f'photo-{code}',
                                              description=name, is_published=True)
        for user in (cls.user, cls.other):
            Profile.objects.filter(user=user).update(preferred_language=cls.languages['nl'], ui_language='en', placement_completed=True)

    def setUp(self):
        cache.clear()
        self.client.force_login(self.user)
        self.url = reverse('photo_practice')

    def choose_course(self, code, locale=None):
        fields = {'preferred_language':self.languages[code] if code else None}
        if locale:
            fields['ui_language'] = locale
        Profile.objects.filter(user=self.user).update(**fields)

    def round(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        return response.context['round']

    def answer(self, nonce, choice, **extra):
        return self.client.post(self.url, {'round':nonce, 'answer':choice, **extra})

    def test_login_required_and_route_selects_photo_quiz(self):
        self.assertEqual(self.url, '/skills/photos/')
        anonymous = Client()
        self.assertEqual(anonymous.get(self.url).status_code,302)
        response = self.client.get(self.url)
        self.assertTemplateUsed(response, 'academy/photos.html')
        self.assertContains(response, 'academy/photos/coffee.jpg')
        self.assertNotContains(response, 'koffie</strong>')

    def test_only_supported_published_active_course_can_be_graded(self):
        for code in (None,'es'):
            with self.subTest(course=code):
                self.choose_course(code)
                response = self.client.get(self.url)
                self.assertNotIn('round', response.context)
                self.assertContains(response, TEXT['en']['missing'])
                self.client.post(self.url, {'round':'invented','answer':'coffee','language_id':self.languages['en'].pk})
        self.choose_course('nl')
        Language.objects.filter(pk=self.languages['nl'].pk).update(is_published=False)
        response = self.client.get(self.url)
        self.assertNotIn('round', response.context)
        self.client.post(self.url, {'round':'invented','answer':'koffie'})
        self.assertEqual(PhotoAttempt.objects.count(),0)

    def test_each_supported_course_has_its_own_target_words(self):
        for code in ('en','nl','de','fr'):
            with self.subTest(course=code):
                self.choose_course(code)
                response = self.client.get(self.url)
                self.assertEqual(response.context['options'], list(WORDS[code].values()))
                self.assertEqual(response.context['language'].pk, self.languages[code].pk)
                nonce = response.context['round']
                self.assertEqual(self.answer(nonce, WORDS[code]['coffee']).status_code,302)
                attempt = PhotoAttempt.objects.get(user=self.user, language=self.languages[code])
                self.assertEqual(attempt.image_key,'coffee')
                self.assertTrue(attempt.correct)

    def test_missing_or_forged_nonce_cannot_grade(self):
        nonce = self.round()
        for submitted in ('','not-the-server-round'):
            with self.subTest(nonce=submitted):
                self.assertEqual(self.answer(submitted, 'koffie').status_code,400)
        self.assertEqual(PhotoAttempt.objects.count(),0)
        self.assertEqual(self.client.get(self.url).context['round'],nonce)

    def test_choice_must_belong_to_active_course_not_posted_course(self):
        nonce = self.round()
        for choice in ('','not-a-choice','coffee'):
            with self.subTest(choice=choice):
                response = self.answer(nonce,choice,language_id=self.languages['en'].pk,correct='true')
                self.assertEqual(response.status_code,400)
        self.assertEqual(PhotoAttempt.objects.count(),0)

    def test_grade_uses_server_image_and_not_claimed_result(self):
        nonce = self.round()
        response = self.answer(nonce,'een boek',image_key='books',correct='true')
        self.assertEqual(response.status_code,302)
        attempt = PhotoAttempt.objects.get(user=self.user)
        self.assertEqual(attempt.image_key,'coffee')
        self.assertFalse(attempt.correct)
        result = self.client.get(self.url)
        self.assertFalse(result.context['result']['correct'])
        self.assertEqual(result.context['answer_word'],'koffie')

    def test_repeated_answer_cannot_change_first_grade(self):
        nonce = self.round()
        self.answer(nonce,'een boek')
        self.answer(nonce,'koffie')
        self.assertEqual(PhotoAttempt.objects.filter(user=self.user).count(),1)
        self.assertFalse(PhotoAttempt.objects.get(user=self.user).correct)
        self.assertFalse(self.client.get(self.url).context['result']['correct'])

    def test_database_first_grade_survives_lost_session_result(self):
        nonce = self.round()
        self.answer(nonce,'een boek')
        # A concurrent/stale session writer may restore an unanswered round.
        session = self.client.session
        session.pop(f'photo_result_{self.languages["nl"].pk}',None)
        session.save()
        self.answer(nonce,'koffie')
        self.assertEqual(PhotoAttempt.objects.filter(user=self.user).count(),1)
        self.assertFalse(PhotoAttempt.objects.get(user=self.user).correct)
        self.assertFalse(self.client.get(self.url).context['result']['correct'])

    def test_next_rotates_picture_and_old_answer_nonce_expires(self):
        first_nonce = self.round()
        self.answer(first_nonce,'koffie')
        self.assertEqual(self.client.post(self.url,{'action':'next'}).status_code,302)
        second = self.client.get(self.url)
        self.assertContains(second,'academy/photos/books.jpg')
        self.assertNotEqual(first_nonce,second.context['round'])
        self.assertIsNone(second.context['result'])
        self.assertEqual(self.answer(first_nonce,'een boek').status_code,400)
        self.assertEqual(PhotoAttempt.objects.count(),1)
        self.assertEqual(self.answer(second.context['round'],'een boek').status_code,302)
        self.assertEqual(PhotoAttempt.objects.count(),2)

    def test_replayed_next_does_not_invalidate_unanswered_round(self):
        nonce = self.round()
        self.assertEqual(self.client.post(self.url,{'action':'next'}).status_code,400)
        self.assertEqual(self.client.get(self.url).context['round'],nonce)
        self.answer(nonce,'koffie')
        self.client.post(self.url,{'action':'next'})
        fresh_nonce = self.round()
        self.assertEqual(self.client.post(self.url,{'action':'next'}).status_code,400)
        self.assertEqual(self.client.get(self.url).context['round'],fresh_nonce)

    def test_course_switch_scopes_nonce_result_and_attempt_count(self):
        nl_nonce = self.round()
        self.choose_course('de')
        de_nonce = self.round()
        self.assertNotEqual(nl_nonce,de_nonce)
        self.assertEqual(self.answer(nl_nonce,'Kaffee',language_id=self.languages['nl'].pk).status_code,400)
        self.answer(de_nonce,'Kaffee')
        self.choose_course('nl')
        nl = self.client.get(self.url)
        self.assertIsNone(nl.context['result'])
        self.assertEqual(nl.context['round'],nl_nonce)
        self.assertEqual(nl.context['attempts'],0)
        self.answer(nl_nonce,'een boek')
        self.choose_course('de')
        de = self.client.get(self.url)
        self.assertTrue(de.context['result']['correct'])
        self.assertEqual(de.context['answer_word'],'Kaffee')
        self.assertEqual(de.context['attempts'],1)

    def test_other_users_history_never_changes_my_photo_or_stats(self):
        PhotoAttempt.objects.create(user=self.other, language=self.languages['nl'], image_key='coffee',
                                    correct=True, round_key='other-user-checked')
        nonce = self.round()
        response = self.client.get(self.url)
        self.assertEqual(response.context['attempts'],0)
        self.assertContains(response,'academy/photos/coffee.jpg')
        other_client = Client()
        other_client.force_login(self.other)
        other_response = other_client.get(self.url)
        self.assertEqual(other_response.context['attempts'],1)
        self.assertContains(other_response,'academy/photos/books.jpg')
        self.assertEqual(other_client.post(self.url,{'round':nonce,'answer':'een boek'}).status_code,400)
        self.assertEqual(PhotoAttempt.objects.filter(user=self.user).count(),0)

    def test_free_practice_at_zero_hearts_neither_spends_nor_farms_hearts_or_xp(self):
        HeartBalance.objects.create(user=self.user,remaining=0,regenerated_at=timezone.now())
        before = Profile.objects.get(user=self.user)
        before_stats = (before.xp,before.streak,before.last_active_day)
        for choice in ('koffie','koffie','een trein','een bos'):
            nonce = self.round()
            self.assertEqual(self.answer(nonce,choice).status_code,302)
            self.answer(nonce,choice)
            self.assertEqual(self.client.post(self.url,{'action':'next'}).status_code,302)
        balance = HeartBalance.objects.get(user=self.user)
        after = Profile.objects.get(user=self.user)
        self.assertEqual(balance.remaining,0)
        self.assertEqual(HeartEvent.objects.filter(user=self.user).count(),0)
        self.assertEqual(XPEvent.objects.filter(user=self.user).count(),0)
        self.assertEqual((after.xp,after.streak,after.last_active_day),before_stats)
        self.assertEqual(PhotoAttempt.objects.filter(user=self.user).count(),4)
        wrapped = self.client.get(self.url)
        self.assertContains(wrapped,'academy/photos/coffee.jpg')

    def test_locales_render_their_own_labels_and_direction(self):
        for locale in ('en','nl','ckb','ar'):
            with self.subTest(locale=locale):
                self.choose_course('nl',locale=locale)
                response = self.client.get(self.url)
                self.assertContains(response,TEXT[locale]['title'])
                self.assertContains(response,TEXT[locale]['note'])
                self.assertContains(response,'dir="rtl"' if locale in ('ckb','ar') else 'dir="ltr"')
                self.assertContains(response,'name="csrfmiddlewaretoken"')
                self.assertTrue(response.context['noindex'])

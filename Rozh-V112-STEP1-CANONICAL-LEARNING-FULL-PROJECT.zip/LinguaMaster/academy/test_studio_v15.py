"""Django integration checks: run with manage.py test academy.test_studio_v15."""
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.test import SimpleTestCase, TestCase
from django.urls import reverse
from .models import Language, Level, GrammarTopic
from .grammar_rich_models import GrammarArticle
from .rich_schema import normalize_article


class ExpandedGrammarSchemaTests(SimpleTestCase):
    def test_new_optional_blocks_and_original_schema(self):
        self.assertEqual(normalize_article({'intro':'Hello'})['intro'],'Hello')
        rich = normalize_article({
            'quick_rules':[
                {'kind':'rule','title':'Short rule','body':'Remember this'},
                {'kind':'warning','title':'Common mistake','body':'Avoid it'}],
            'checklist':['Remember verbs','Check article'],
            'faq':[{'question':'Why?','answer':'Because of the verb.'}],
        })
        self.assertEqual(len(rich['quick_rules']),2)
        self.assertEqual(len(rich['checklist']),2)
        self.assertEqual(len(rich['faq']),1)

    def test_invalid_kinds_html_objects_and_column_shapes_rejected(self):
        for item in (
            {'quick_rules':[{'kind':'script','title':'Hello','body':'World'}]},
            {'quick_rules':[{'kind':'tip','title':'Hello','body':{'html':'<script>'}}]},
            {'checklist':['x']*21},
            {'faq':[{'question':'Why?'}]},
            {'quick_rules':[{'kind':'rule','title':'','body':'yes'}]},
        ):
            with self.subTest(item=item), self.assertRaises(ValidationError):
                normalize_article(item)


class V15WebsiteSmoke(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.lang=Language.objects.create(code='nl',name='Dutch',slug='dutch',description='Dutch',is_published=True)
        cls.level=Level.objects.create(language=cls.lang,code='A0',order=0,description='Starter')
        cls.topic=GrammarTopic.objects.create(level=cls.level,slug='v15-test-topic',title='Test grammar',explanation='A basic explanation',
            examples=['A'],exceptions='None',common_mistakes='Check it',check_question='Choose A',
            check_options=['A','B'],check_answer='A',published=True)
        GrammarArticle.objects.create(topic=cls.topic,content={
            'quick_rules':[{'kind':'warning','title':'No HTML','body':'<script>alert(1)</script>'}],
            'checklist':['Compare carefully'], 'faq':[{'question':'Why?','answer':'Because.'}]})
        cls.user=get_user_model().objects.create_user('studio_v15_learner',password='ValidSecurePass!246')
        profile=cls.user.learning_profile
        profile.preferred_language=cls.lang
        profile.placement_completed=True
        profile.onboarding_completed=True
        profile.save()

    def test_public_home_and_protected_dashboard(self):
        response=self.client.get(reverse('home'))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'v15-home-hero')
        self.assertEqual(self.client.get(reverse('dashboard')).status_code,302)
        self.client.force_login(self.user)
        response=self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'v15-studio')

    def test_play_hub_show_modes_only_if_authenticated(self):
        self.assertEqual(self.client.get(reverse('play_hub')).status_code,302)
        self.client.force_login(self.user)
        response=self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'v15-play-modes')

    def test_structured_grammar_is_escaped_and_no_xss(self):
        self.client.force_login(self.user)
        response=self.client.get(reverse('grammar',args=[self.topic.pk]))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'v15-rule-warning')
        self.assertContains(response,'v15-memory-box')
        self.assertContains(response,'v15-faq-item')
        self.assertNotContains(response,'<script>alert(1)</script>')
        self.assertContains(response,'&lt;script&gt;alert(1)&lt;/script&gt;')

    def test_owner_manager_remains_superuser_only(self):
        self.client.force_login(self.user)
        response=self.client.get(reverse('manager'))
        self.assertNotEqual(response.status_code,200)

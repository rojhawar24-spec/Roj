"""Safe, explicit navigation preservation for student UI-language changes.

The language switch is a POST: its destination is always reconstructed from a
known GET page, not accepted as an arbitrary user-provided URL. No external
redirects, POST actions, manager views or login/logout bypasses are possible.
"""
from urllib.parse import parse_qs, urlencode, urlsplit

from django.urls import Resolver404, resolve

# Named routes whose GET pages may be resumed after an interface-language POST.
# Explicitly exclude action endpoints, account writes, MFA, authentication,
# manager administration and session-changing GET candidates.
SAFE_STUDENT_PAGES = frozenset({
    'play_hub', 'learn_path', 'journey_play', 'unit', 'lesson',
    'grammar_library', 'grammar', 'vocabulary', 'word', 'mistakes',
    'friends', 'leaderboard', 'profile', 'avatar_studio', 'ai_tutor',
    'hearts', 'heart_spelling', 'review', 'weekly_review', 'courses', 'assessment_unit',
    'assessment_level', 'practice_hub', 'skill_practice', 'photo_practice',
    'tests_hub_v16', 'notifications', 'dashboard', 'arena',
    'arena_run', 'arena_result', 'chest',
})

VALID_LEVELS = frozenset({'A0', 'A1', 'A2', 'B1', 'B2', 'C1'})


def safe_student_return_path(raw):
    """Return a local, allowed GET page URL or None; never honor arbitrary URLs."""
    if not isinstance(raw, str) or not raw or len(raw) > 1024:
        return None
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in raw) or '\\' in raw:
        return None
    if not raw.startswith('/') or raw.startswith('//'):
        return None
    parts = urlsplit(raw)
    if parts.scheme or parts.netloc or parts.fragment or not parts.path:
        return None
    # Percent-escaped path components and repeated slashes are not needed for
    # these fixed internal page routes. Reject rather than normalize ambiguity.
    if '%' in parts.path or '//' in parts.path or '/./' in parts.path or '/../' in parts.path:
        return None
    try:
        match = resolve(parts.path)
    except Resolver404:
        return None
    if match.url_name not in SAFE_STUDENT_PAGES:
        return None
    if not parts.query:
        return parts.path

    query_fields = {
        'vocabulary': frozenset({'q', 'level', 'page'}),
        'grammar_library': frozenset({'q', 'level', 'page', 'status'}),
        'leaderboard': frozenset({'period'}),
        'skill_practice': frozenset({'level'}),
    }.get(match.url_name)
    if not query_fields or len(parts.query) > 280:
        return parts.path
    try:
        values = parse_qs(parts.query, keep_blank_values=False, strict_parsing=True, max_num_fields=5)
    except ValueError:
        return parts.path
    params = {}
    for key, value in values.items():
        if key not in query_fields or len(value) != 1:
            continue
        item = value[0].strip()
        if key == 'q' and 0 < len(item) <= 100:
            params[key] = item
        elif key == 'level' and item.upper() in VALID_LEVELS:
            params[key] = item.upper()
        elif key == 'page' and item.isascii() and item.isdecimal() and 0 < int(item) <= 99999:
            params[key] = item
        elif key == 'status' and item in ('new', 'practising', 'mastered', 'due'):
            params[key] = item
        elif key == 'period' and item in ('week', 'all'):
            params[key] = item
    return parts.path + ('?' + urlencode(params) if params else '')

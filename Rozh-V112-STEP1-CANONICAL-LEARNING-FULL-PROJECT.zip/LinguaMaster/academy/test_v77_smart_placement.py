"""Live Django tests, intentionally synthetic QA content, NOT a real CEFR test."""
from unittest.mock import patch
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse

from .models import Language, Level, Unit, Lesson, Profile, XPEvent, Assessment
from .placement_models_v77 import PlacementBankItem, PlacementRun
from .placement_adaptive_v77 import STAGES, SKILLS, bank_status


@patch('academy.placement_adaptive_v77.finders.find', return_value='/qa/fixture-only.mp3')
class SmartPlacementHTTPTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = get_user_model().objects.create_user('placement-test-v77')
        self.course = Language.objects.create(code='nl',name='Dutch',slug='placement-v77',is_published=True)
        self.other = Language.objects.create(code='en',name='English',slug='other-v77',is_published=True)
        self.levels={}
        for n,band in enumerate(STAGES):
            self.levels[band] = Level.objects.create(language=self.course,code=band,order=n,description='')
            if band == 'B2':
                unit = Unit.objects.create(level=self.levels[band], slug='test-v77',
                                           title='An actually published lesson',published=True)
                Lesson.objects.create(unit=unit,slug='intro',title='Intro',skill='reading',published=True)
        Profile.objects.filter(user=self.user).update(preferred_language=self.course,
                            placement_completed=False,onboarding_required=False,onboarding_completed=True)
        self.client.force_login(self.user)
        self.url=reverse('smart_placement_v77')

    def make_bank(self):
        items=[]
        for stage in STAGES:
            for skill in SKILLS:
                for repeat in range(2):
                    items.append(PlacementBankItem(
                        course=self.course,stage=stage,skill=skill,
                        prompt=f'QA-only synthetic {stage} {skill} {repeat}',
                        stimulus='Synthetic text' if skill=='reading' else '',
                        audio_path='academy/placement-audio/fixture.mp3' if skill=='listening' else '',
                        options=[] if skill=='writing' else ['Correct','Wrong','Other'],
                        answer='Correct' if skill!='writing' else '',
                        accepted_answers=['sample answer'] if skill=='writing' else [],
                        source_reference='QA fixture – NOT production content',
                        educator_reviewed=True,published=True))
        PlacementBankItem.objects.bulk_create(items)

    def test_no_question_bank_shows_truthful_unavailable_and_a0(self, _finder):
        response=self.client.get(self.url)
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'geen voldoende' if False else 'voldoende door een docent')
        self.assertFalse(PlacementRun.objects.filter(user=self.user).exists())
        response=self.client.post(self.url,{'action':'a0'})
        self.assertRedirects(response,reverse('play_hub'),fetch_redirect_response=False)
        self.assertEqual(Profile.objects.get(user=self.user).placement_level,'A0')

    def test_fifteen_real_server_step_posts_and_explicit_choice(self, _finder):
        self.make_bank()
        response=self.client.get(self.url)
        self.assertEqual(response.status_code,200)
        all_ids=[]
        for i in range(15):
            run=PlacementRun.objects.get(user=self.user,course=self.course)
            self.assertIsNotNone(run.current_item_id)
            item=PlacementBankItem.objects.get(pk=run.current_item_id)
            all_ids.append(item.pk)
            answer='sample answer' if item.skill=='writing' else 'Correct'
            response=self.client.post(self.url,{'action':'answer','question_id':item.pk,'answer':answer})
            self.assertEqual(response.status_code,200)
            self.assertFalse(Profile.objects.get(user=self.user).placement_completed)
        self.assertEqual(len(set(all_ids)),15)
        run=PlacementRun.objects.get(user=self.user)
        self.assertEqual(run.status,'ready')
        self.assertEqual(len(run.history),15)
        self.assertEqual(run.result['score'],100)
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())
        self.assertFalse(Assessment.objects.filter(user=self.user).exists())
        response=self.client.post(self.url,{'action':'use_a0'})
        self.assertRedirects(response,reverse('play_hub'),fetch_redirect_response=False)
        profile=Profile.objects.get(user=self.user)
        self.assertTrue(profile.placement_completed)
        self.assertEqual(profile.placement_level,'A0')
        self.assertEqual(Assessment.objects.filter(user=self.user,kind='placement').count(),1)
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())
        response=self.client.post(self.url,{'action':'use_a0'})
        self.assertRedirects(response,reverse('play_hub'),fetch_redirect_response=False)
        self.assertEqual(Assessment.objects.filter(user=self.user,kind='placement').count(),1)

    def test_forged_question_duplicate_and_invalid_option_do_not_advance(self, _finder):
        self.make_bank()
        self.client.get(self.url)
        run=PlacementRun.objects.get(user=self.user)
        pk=run.current_item_id
        for data in [
            {'action':'answer','question_id':pk+99999,'answer':'Correct'},
            {'action':'answer','question_id':pk,'answer':'Unexpected option'},
            {'action':'use_level'},
        ]:
            response=self.client.post(self.url,data)
            self.assertIn(response.status_code,(400,409))
            self.assertEqual(len(PlacementRun.objects.get(user=self.user).history),0)
        from django.http import QueryDict
        post=QueryDict('',mutable=True);post.update({'action':'answer','question_id':str(pk)})
        post.setlist('answer',['Correct','Wrong'])
        response=self.client.post(self.url,post.urlencode(),content_type='application/x-www-form-urlencoded')
        self.assertEqual(response.status_code,400)
        self.assertEqual(len(PlacementRun.objects.get(user=self.user).history),0)

    def test_unpublished_bank_item_invalidates_run_without_reward(self, _finder):
        self.make_bank()
        self.client.get(self.url)
        pk=PlacementRun.objects.get(user=self.user).current_item_id
        PlacementBankItem.objects.filter(pk=pk).update(published=False)
        response=self.client.post(self.url,{'action':'answer','question_id':pk,'answer':'Correct'})
        self.assertEqual(response.status_code,409)
        self.assertFalse(Profile.objects.get(user=self.user).placement_completed)

    def test_other_course_and_nonapproved_items_are_not_valid(self, _finder):
        self.make_bank()
        item=PlacementBankItem.objects.filter(course=self.course).first()
        item.educator_reviewed=False;item.save(update_fields=['educator_reviewed'])
        self.assertFalse(bank_status(self.course)[0])
        self.assertEqual(self.client.get(self.url).status_code,200)
        self.assertFalse(PlacementRun.objects.filter(user=self.user).exists())

    def test_publication_requires_real_audio_and_vetted_source(self, _finder):
        item=PlacementBankItem(course=self.course,stage='B2',skill='listening',
            prompt='A QA-only question',audio_path='https://evil.invalid/a.mp3',
            options=['A','B','C'],answer='A',educator_reviewed=True,published=True,
            source_reference='QA synthetic')
        from django.core.exceptions import ValidationError
        with self.assertRaises(ValidationError):
            item.full_clean()

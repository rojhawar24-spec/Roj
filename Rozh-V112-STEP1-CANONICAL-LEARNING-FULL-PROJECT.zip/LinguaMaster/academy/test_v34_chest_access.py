"""Real Django integration tests. Must run with isolated SQLite DB on Windows QA."""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse

from .models import DailyChest, Language, XPEvent
from .services import award_xp, user_localdate


class ChestClaimV34DjangoTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = get_user_model().objects.create_user(
            'v34-chest-learner', 'v34-chest@example.invalid', 'StrongTestPassword!2026',
        )
        self.language = Language.objects.create(
            name='Dutch', code='nl', slug='v34-chest-course', description='Dutch', is_published=True,
        )
        profile = self.user.learning_profile
        profile.preferred_language = self.language
        profile.placement_completed = True
        profile.onboarding_required = True
        profile.onboarding_completed = True
        profile.save(update_fields=[
            'preferred_language', 'placement_completed',
            'onboarding_required', 'onboarding_completed',
        ])
        self.client.force_login(self.user)
        self.assertTrue(award_xp(self.user, 20, reason='lesson', event_key='v34-earned-today'))

    def assert_no_chest(self):
        self.assertEqual(DailyChest.objects.filter(user=self.user).count(), 0)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='chest').count(), 0)

    def test_can_claim_once_and_never_extend_streak(self):
        url = reverse('chest_open')
        self.assertEqual(self.client.post(url).status_code, 302)
        self.assertEqual(self.client.post(url).status_code, 302)
        self.assertEqual(DailyChest.objects.filter(user=self.user).count(), 1)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='chest').count(), 1)
        self.user.learning_profile.refresh_from_db()
        self.assertEqual(self.user.learning_profile.xp, 30)
        self.assertEqual(self.user.learning_profile.streak, 1)

    def test_unfinished_onboarding_denied_without_record(self):
        self.user.learning_profile.onboarding_completed = False
        self.user.learning_profile.save(update_fields=['onboarding_completed'])
        self.assertEqual(self.client.post(reverse('chest_open')).status_code, 403)
        self.assert_no_chest()
        self.assertFalse(self.client.get(reverse('chest')).context['ready'])

    def test_revoked_placement_denied(self):
        self.user.learning_profile.placement_completed = False
        self.user.learning_profile.save(update_fields=['placement_completed'])
        self.assertEqual(self.client.post(reverse('chest_open')).status_code, 403)
        self.assert_no_chest()

    def test_archived_course_denied(self):
        self.language.is_published = False
        self.language.save(update_fields=['is_published'])
        self.assertEqual(self.client.post(reverse('chest_open')).status_code, 403)
        self.assert_no_chest()

    def test_course_removed_denied(self):
        self.user.learning_profile.preferred_language = None
        self.user.learning_profile.save(update_fields=['preferred_language'])
        self.assertEqual(self.client.post(reverse('chest_open')).status_code, 403)
        self.assert_no_chest()

    def test_suspended_account_denied(self):
        from django.utils import timezone
        self.user.learning_profile.suspended_at = timezone.now()
        self.user.learning_profile.save(update_fields=['suspended_at'])
        self.assertEqual(self.client.post(reverse('chest_open')).status_code, 403)
        self.assert_no_chest()

    def test_legacy_review_denied(self):
        self.user.learning_profile.legacy_review_required = True
        self.user.learning_profile.save(update_fields=['legacy_review_required'])
        self.assertEqual(self.client.post(reverse('chest_open')).status_code, 403)
        self.assert_no_chest()

    def test_conflicting_xp_event_does_not_commit_phantom_chest(self):
        today = user_localdate(self.user)
        XPEvent.objects.create(user=self.user, reason='chest', amount=10,
                               event_key=f'user:{self.user.pk}:chest:{today}')
        self.assertEqual(self.client.post(reverse('chest_open')).status_code, 409)
        self.assert_no_chest_row_only()

    def assert_no_chest_row_only(self):
        self.assertFalse(DailyChest.objects.filter(user=self.user).exists())
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='chest').count(), 1)

    def test_chest_is_post_only(self):
        self.assertEqual(self.client.get(reverse('chest_open')).status_code, 405)

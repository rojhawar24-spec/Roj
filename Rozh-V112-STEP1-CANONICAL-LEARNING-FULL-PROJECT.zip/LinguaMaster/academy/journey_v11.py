"""Mixed, server-graded level rounds using the existing published V10 curriculum.

No new tables and no client-owned answers. A unit is one playable level; its
existing Lessons supply the authored exercises and completion/XP identities.
Optional speaking/writing reflections remain explicitly ungraded.
"""
import hashlib
import json
import random
import re
import secrets
import time
from collections import Counter

from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db import transaction
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import path, reverse
from django.views.decorators.http import require_GET, require_POST

from .hearts import HeartEmpty, snapshot, spend_for_answer
from .photo_v10 import WORDS, SCENES
from .models import Exercise, Lesson, LessonProgress, Profile, ReviewCard, Unit, Vocabulary
from .services import allowed_unit, award_xp, grade, rate_limit, record_exercise_result, unit_lessons_done
from .journey_policy_v39 import journey_round_allowed
from .lesson_activities_v58 import (student_ready as v58_student_ready, public_activity, validate_answer as v58_answer_valid,
                                    is_correct as v58_grade, KIND_KEYS as V58_KINDS, MATCHING as V58_MATCHING,
                                    title_for as v58_title)

LOCALES = {
 'nl': {'section':'Sectie','level':'Level','round':'Gemengde les','question':'Opdracht','of':'van','extra':'Extra oefeningen per vaardigheid','result':'Bekijk je resultaat',
        'choose':'Kies het juiste antwoord','listen':'Luister en kies','picture':'Wat betekent dit symbool?',
        'wordbank':'Zet de woorden in de juiste volgorde','dictation':'Luister en schrijf wat je hoort',
        'writing':'Schrijf het antwoord','speaking':'Oefen hardop','reflection':'Zelf oefenen: schrijven',
        'check':'Controleer','next':'Verder','replay':'Opnieuw luisteren','slow':'Langzaam',
        'hint':'Toon tekst als hulp','ready':'Ik heb hardop geoefend','written':'Ik heb mijn tekst nagekeken',
        'correct':'Goed gedaan!','incorrect':'Nog niet helemaal','review':'Uitleg',
        'passed':'Level afgerond!','failed':'Oefen dit level opnieuw','score':'Je resultaat',
        'xp':'Verdiende XP','retry':'Opnieuw proberen','path':'Terug naar het leerpad',
        'test':'Doe nu de unittestoefening','nextlevel':'Verder leren','error':'Controleer je antwoord.',
        'empty':'Nog geen oefeningen voor dit level.','restricted':'Maak eerst het vorige level af.',
        'ungraded':'Dit is een zelfoefening, geen uitspraak- of schrijfexamen.',
        'ungraded_write':'Schrijf ten minste één zin, lees die na en bevestig zelf. Je tekst wordt niet opgeslagen.',
        'ungraded_speak':'Luister naar het voorbeeld, zeg het na en bevestig zelf. We beoordelen je uitspraak niet.',
        'listen_help':'Je kunt opnieuw luisteren of de tekst als ondersteuning tonen.',
        'audio_unavailable':'Geen spraakfunctie beschikbaar. Gebruik de tekst als hulp.',
        'answer_required':'Kies of schrijf eerst een antwoord.','hearts':'Je hebt geen harten meer. Herstel ze om verder te oefenen.',
        'audio':'Luister','undo':'Verwijder laatste woord','no_audio':'Spraakherkenning is niet vereist.',
        'saved':'Je behaalde punten en voltooide lessen zijn op je account opgeslagen.',
        'no_xp':'Je had deze lessen al voltooid; er is geen dubbele XP toegekend.',
        'grade_note':'Automatisch nagekeken antwoorden zijn oefenfeedback, geen officieel taalexamen.',
        'unit_pitch':'Luisteren, kiezen, zinnen maken, schrijven en spreken in één ronde.', 'unit_play':'Speel dit level', 'unit_start':'Start gemengde les'},
 'en': {'section':'Section','level':'Level','round':'Mixed lesson','question':'Question','of':'of','extra':'Extra exercises by skill','result':'See your result',
        'choose':'Choose the correct answer','listen':'Listen and choose','picture':'What does this symbol mean?',
        'wordbank':'Put the words in the correct order','dictation':'Listen and type what you hear',
        'writing':'Type your answer','speaking':'Practise speaking','reflection':'Self-guided writing',
        'check':'Check','next':'Continue','replay':'Listen again','slow':'Slow audio',
        'hint':'Show supportive transcript','ready':'I practised speaking','written':'I reviewed my writing',
        'correct':'Well done!','incorrect':'Not quite yet','review':'Explanation',
        'passed':'Level complete!','failed':'Try this level again','score':'Your score',
        'xp':'XP earned','retry':'Try again','path':'Back to the path',
        'test':'Take the unit check','nextlevel':'Keep learning','error':'Check your answer.',
        'empty':'No exercises published for this level yet.','restricted':'Finish the previous level first.',
        'ungraded':'Self-reviewed activity, not a speaking or writing qualification.',
        'ungraded_write':'Write at least one sentence, review it and confirm. Your text is not stored.',
        'ungraded_speak':'Listen, repeat aloud and confirm. Pronunciation is not automatically scored.',
        'listen_help':'Replay the audio or reveal the transcript if you need support.',
        'audio_unavailable':'Speech is unavailable. Use the transcript instead.',
        'answer_required':'Choose or enter an answer first.','hearts':'Your hearts are empty. Recover them to continue.',
        'audio':'Listen','undo':'Remove last word','no_audio':'Speech recognition is not required.',
        'saved':'Earned XP and completed lessons have been saved to your account.',
        'no_xp':'Those lessons were already complete, so no repeat XP was awarded.',
        'grade_note':'Automated practice feedback is not an official language certification.',
        'unit_pitch':'Listen, choose, build sentences, write and speak in one round.', 'unit_play':'Play this level', 'unit_start':'Start mixed lesson'},
 'ckb': {'section':'بەش','level':'ئاست','round':'وانەی تێکەڵ','question':'پرسیار','of':'لە','extra':'ڕاهێنانی زیاتر بۆ هەر توانایەک','result':'ئەنجامەکەت ببینە',
        'choose':'وەڵامی ڕاست هەڵبژێرە','listen':'گوێ بگرە و هەڵبژێرە','picture':'ئەم وێنۆچکەیە واتای چییە؟',
        'wordbank':'وشەکان بە ڕیزێکی ڕاست دابنێ','dictation':'گوێ بگرە و ئەوەی دەیبیستیت بنووسە',
        'writing':'وەڵامەکەت بنووسە','speaking':'قسەکردن ڕاهێنان بکە','reflection':'ڕاهێنانی نووسین',
        'check':'پشکنین','next':'بەردەوام بە','replay':'دووبارە گوێ بگرە','slow':'بە هێواشی',
        'hint':'دەقەکە وەک یارمەتی پیشان بدە','ready':'بە دەنگ ڕاهێنانم کرد','written':'نووسینەکەم پشکنیمەوە',
        'correct':'زۆر باشە!','incorrect':'هێشتا تەواو نییە','review':'ڕوونکردنەوە',
        'passed':'ئاستەکەت تەواو کرد!','failed':'ئەم ئاستە دووبارە ڕاهێنان بکە','score':'ئەنجامەکەت',
        'xp':'XP ی بەدەستهێنراو','retry':'دووبارە هەوڵ بدە','path':'گەڕانەوە بۆ ڕێڕەو',
        'test':'تاقیکردنەوەی یەکەکە بکە','nextlevel':'بەردەوام بە لە فێربوون',
        'error':'وەڵامەکەت بپشکنە.','empty':'هێشتا پرسیار بۆ ئەم ئاستە بڵاو نەکراوەتەوە.',
        'restricted':'سەرەتا ئاستی پێشوو تەواو بکە.','ungraded':'ڕاهێنانی خۆهەڵسەنگاندنە؛ تاقیکردنەوەی فەرمی نییە.',
        'ungraded_write':'لانیکەم ڕستەیەک بنووسە، بیپشکنەوە و پشتڕاستی بکە. دەقەکەت ناپارێزرێت.',
        'ungraded_speak':'گوێ بگرە، بە دەنگ دووبارەی بکەرەوە و پشتڕاستی بکە. دەنگت نمرە ناکرێت.',
        'listen_help':'دەتوانیت دووبارە گوێ بگریت یان دەقەکە پیشان بدەیت.',
        'audio_unavailable':'دەنگ لەم ئامێرەدا بەردەست نییە. دەقەکە بخوێنەوە.',
        'answer_required':'سەرەتا وەڵامێک هەڵبژێرە یان بنووسە.','hearts':'دڵەکانت تەواو بوون. دووبارە پڕیان بکەرەوە.',
        'audio':'گوێ بگرە','undo':'وشەی دوایی بسڕەوە','no_audio':'ناسینەوەی دەنگ پێویست نییە.',
        'saved':'XP و وانە تەواوکراوەکان لە هەژمارەکەت پارێزراون.',
        'no_xp':'ئەم وانانەت پێشتر تەواو کردووە؛ XP ی دووبارە نادرێت.',
        'grade_note':'ئەم هەڵسەنگاندنە بۆ ڕاهێنانە، بڕوانامەی فەرمی نییە.',
        'unit_pitch':'گوێگرتن، هەڵبژاردن، ڕیزکردنی وشە، نووسین و قسەکردن لە یەک یاری.', 'unit_play':'ئەم ئاستە یاری بکە', 'unit_start':'وانەی تێکەڵ دەست پێ بکە'},
 'ar': {'section':'القسم','level':'المستوى','round':'درس متنوع','question':'السؤال','of':'من','extra':'تمارين إضافية لكل مهارة','result':'اعرض نتيجتك',
        'choose':'اختر الإجابة الصحيحة','listen':'استمع واختر','picture':'ماذا يعني هذا الرمز؟',
        'wordbank':'رتّب الكلمات ترتيباً صحيحاً','dictation':'استمع واكتب ما تسمع',
        'writing':'اكتب إجابتك','speaking':'تدرب على التحدث','reflection':'تدرب على الكتابة',
        'check':'تحقق','next':'متابعة','replay':'استمع مجدداً','slow':'استماع بطيء',
        'hint':'أظهر النص للمساعدة','ready':'تدربت على النطق','written':'راجعت كتابتي',
        'correct':'أحسنت!','incorrect':'ليس تماماً','review':'الشرح',
        'passed':'أكملت المستوى!','failed':'حاول هذا المستوى مجدداً','score':'نتيجتك',
        'xp':'نقاط XP المكتسبة','retry':'حاول مجدداً','path':'العودة للمسار',
        'test':'ابدأ اختبار الوحدة','nextlevel':'تابع التعلم','error':'تحقق من إجابتك.',
        'empty':'لا توجد تمارين منشورة لهذا المستوى بعد.','restricted':'أكمل المستوى السابق أولاً.',
        'ungraded':'تقييم ذاتي، وليس اختباراً معتمداً للنطق أو الكتابة.',
        'ungraded_write':'اكتب جملة واحدة على الأقل وراجعها ثم أكد. لا نحفظ النص.',
        'ungraded_speak':'استمع وكرر بصوت عالٍ ثم أكد. لا يتم تقييم نطقك تلقائياً.',
        'listen_help':'يمكنك إعادة الاستماع أو عرض النص للمساعدة.',
        'audio_unavailable':'ميزة النطق غير متاحة؛ اقرأ النص للمساعدة.',
        'answer_required':'اختر أو اكتب إجابة أولاً.','hearts':'نفدت القلوب. استعدها للمتابعة.',
        'audio':'استمع','undo':'إزالة آخر كلمة','no_audio':'التعرف على الكلام ليس مطلوباً.',
        'saved':'تم حفظ النقاط والدروس المكتملة في حسابك.',
        'no_xp':'لقد أكملت هذه الدروس سابقاً؛ لا تتكرر النقاط.',
        'grade_note':'تصحيح التمارين تلقائياً ليس شهادة لغة معتمدة.',
        'unit_pitch':'الاستماع والاختيار وترتيب الكلمات والكتابة والمحادثة في جولة واحدة.', 'unit_play':'العب هذا المستوى', 'unit_start':'ابدأ الدرس المتنوع'},
}


# Readable, locale-specific name for a dynamic link that otherwise exposes only a number.
for _locale, _hearts_count in {
    'nl': 'Resterende hartjes:', 'en': 'Hearts remaining:',
    'ckb': 'دڵە ماوەکان:', 'ar': 'القلوب المتبقية:',
}.items():
    LOCALES[_locale]['hearts_count'] = _hearts_count


for _locale, _pitch in {
    'nl': 'Kies antwoorden, vul woorden in, verbind paren, orden woorden en luister wanneer audio beschikbaar is.',
    'en': 'Choose answers, fill gaps, match pairs, order words and listen when audio is available.',
    'ckb': 'وەڵام هەڵبژێرە، بۆشایی پڕ بکەوە، وشەکان ببەستەوە و ڕیزیان بکە؛ ئەگەر دەنگ ئامادە بێت گوێ بگرە.',
    'ar': 'اختر الإجابات وأكمل الفراغات وطابق الكلمات ورتّبها واستمع عند توفر التسجيل.',
}.items():
    LOCALES[_locale]['unit_pitch'] = _pitch


def labels_for(user):
    return LOCALES.get(getattr(user.learning_profile, 'ui_language', 'en'), LOCALES['en'])


def _first_sentence(text):
    """A short complete sentence for audio dictation or tile ordering."""
    text = (text or '').strip().replace('\n', ' ')
    sentence = re.split(r'(?<=[.!?])\s+', text, maxsplit=1)[0][:290].strip()
    if not sentence.endswith(('.', '?', '!')):
        sentence = sentence.rstrip('.,!?') + '.'
    words = sentence.split()
    return sentence if 3 <= len(words) <= 15 else None


def _shuffled(items, seed):
    items = list(items)
    random.Random(int.from_bytes(hashlib.sha256(seed.encode('utf-8')).digest()[:8], 'big')).shuffle(items)
    return items


def _mixed_source(unit):
    lessons = list(Lesson.objects.filter(unit=unit, published=True).order_by('order', 'pk'))
    exercises = list(Exercise.objects.filter(lesson__in=lessons).select_related('lesson')
                     .order_by('lesson__order', 'order', 'pk'))
    from .mixed_policy_v102 import mixed_block_reason
    from .audio_v78 import approved_audio_url
    reason = mixed_block_reason(lessons, exercises, unit.level.language.code,
                                audio_lookup=approved_audio_url)
    return lessons, exercises, reason


def mixed_unit_block_reason(unit):
    return _mixed_source(unit)[2]


def _challenges(unit, round_token, ui_locale='en'):
    """Only authored, approved questions; no generated dictation or self-review."""
    lessons, exercises, reason = _mixed_source(unit)
    if reason:
        return []
    groups = {}
    for row in exercises:
        presented = public_activity(row, round_token)
        # Old listening lessons contain MCQs plus approved lesson-level audio.
        # Keep that audio, without requiring a second derived recording.
        legacy_listen = row.kind == 'mcq' and row.lesson.skill == 'listening'
        kind = 'listening-choice' if legacy_listen else row.kind
        item = dict(presented, id=f'e{row.pk}', type=kind,
                    lesson_id=row.lesson_id, prompt=row.prompt,
                    answer=row.answer, explanation=row.explanation,
                    exercise=row, graded=True, skill=row.lesson.skill,
                    round_seed=round_token,
                    activity_title='' if legacy_listen else v58_title(row.kind, ui_locale))
        if legacy_listen:
            item['audio'] = row.lesson.audio_text
        elif row.lesson.skill == 'listening' and row.kind != 'listening':
            item['lesson_audio'] = row.lesson.audio_text
        if row.kind == 'mcq':
            item['options'] = _shuffled(row.options, f'{round_token}:e{row.pk}')
        groups.setdefault(kind, []).append(item)
    arranged = []
    # Round-robin across actual types, preserving authored ordering per type.
    # Iterating existing group keys cannot hang on an unfamiliar skill label.
    while any(groups.values()):
        for kind in groups:
            if groups[kind]:
                arranged.append(groups[kind].pop(0))
    return arranged


def _fingerprint(items):
    """Invalidates active rounds when an editor updates/unpublishes a question."""
    # A learner's open round must be invalidated by *any* relevant editorial
    # change, even one made through a separate admin/import workflow that did
    # not increment Exercise.content_version. Otherwise the next POST could
    # grade a different exercise from the one the learner saw. All source
    # content stays server-side: only this SHA-256 digest enters the session.
    data = [dict(
        id=q['id'], type=q['type'], lesson_id=q.get('lesson_id'),
        prompt=q.get('prompt', ''), explanation=q.get('explanation', ''),
        answer=q.get('answer'), options=q.get('options', []),
        audio=q.get('audio', ''), lesson_audio=q.get('lesson_audio', ''), guidance=q.get('guidance', ''),
        image=q.get('image', ''), image_alt=q.get('image_alt', ''),
        images=q.get('images', []), dialogue=q.get('dialogue', []),
        matches=q.get('matches', []), match_options=q.get('match_options', []),
        tokens=q.get('tokens', []), skill=q.get('skill'), graded=q.get('graded'),
        scene=q.get('scene'),
        activity_data=getattr(q.get('exercise'), 'activity_data', None),
        content_version=getattr(q.get('exercise'), 'content_version', None),
    ) for q in items]
    raw = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


def _get_unit(request, pk):
    return get_object_or_404(Unit.objects.select_related('level__language'),pk=pk,published=True,
                            level__language__is_published=True)



def _unapproved_structured_listening(unit):
    """Compatibility name: the actual mixed readiness gate is more complete."""
    return mixed_unit_block_reason(unit) == 'audio'


def _key(unit_id): return f'journey_v11_{unit_id}'


def _current(request, unit, *, restart=False, ui_language=None):
    key = _key(unit.pk)
    ui_language = ui_language or request.user.learning_profile.ui_language
    state = request.session.get(key)
    valid = (isinstance(state,dict) and state.get('user') == request.user.pk
             and state.get('unit') == unit.pk and isinstance(state.get('token'),str)
             and len(state.get('token','')) == 32
             and isinstance(state.get('position'),int) and state['position'] >= 0
             and 0 <= time.time()-state.get('started',0) <= 7200)
    if restart or not valid:
        token = secrets.token_hex(16)
        items = _challenges(unit, token, ui_language)
        state={'user':request.user.pk, 'unit':unit.pk,'token':token,'position':0,
               'started':time.time(), 'fingerprint':_fingerprint(items),
               'results':{},'done':False}
        request.session[key] = state
        return state,items
    items = _challenges(unit,state['token'], ui_language)
    if state.get('fingerprint') != _fingerprint(items) or state['position'] > len(items):
        return _current(request,unit,restart=True,ui_language=ui_language)
    return state,items


@login_required
@require_GET
def play_level(request, pk):
    unit=_get_unit(request,pk)
    # Read the live Profile, not a previously cached reverse-one-to-one relation.
    # A suspended or quarantined learner must not keep using an old session.
    profile = Profile.objects.filter(user=request.user).first()
    if (profile is None or not request.user.is_active
            or profile.suspended_at is not None or profile.legacy_review_required):
        return HttpResponse('This learning account is unavailable.', status=403)
    if profile.onboarding_required and not profile.onboarding_completed:
        return redirect('onboarding')
    if not profile.placement_completed: return redirect('placement')
    if not journey_round_allowed(profile, unit, user_active=request.user.is_active):
        return HttpResponse('This learning account or course is unavailable.', status=403)
    if not allowed_unit(request.user,unit,profile=profile):
        return HttpResponse('Complete the prerequisite level first.',status=403)
    block_reason = mixed_unit_block_reason(unit)
    if block_reason:
        from .lesson_unavailable_v96 import for_locale
        response = render(request, 'academy/lesson_unavailable_v96.html', {
            'unit': unit, 'unavailable_reason': block_reason,
            'R96': for_locale(profile.ui_language), 'noindex': True,
        }, status=409)
        response['Cache-Control'] = 'no-store, private'
        return response
    state, items = _current(request,unit,restart=request.GET.get('restart')=='1',ui_language=profile.ui_language)
    done = bool(items) and (state.get('done') or state['position'] >= len(items))
    question = items[state['position']] if not done and items else None
    hearts = snapshot(request.user)
    section_order = list(unit.level.language.levels.order_by('order','pk').values_list('pk',flat=True)).index(unit.level_id)+1
    lesson_number = unit.level.units.filter(published=True,order__lte=unit.order).count()
    answer_url = reverse('journey_answer',args=[unit.pk])
    from .assessment_availability_v105 import has_ready_assessment
    return render(request,'academy/journey_v11.html',{
        'unit':unit,'state':state,'question':question,'total':len(items),
        'position':state['position']+1, 'percent':round(100*state['position']/len(items)) if items else 0,
        'done':done,'heart_state':hearts,'section_number':section_order,'level_number':lesson_number,
        'answer_url':answer_url,'L':labels_for(request.user),'noindex':True,
        'unit_test_ready':bool(done and state.get('passed') and unit_lessons_done(request.user,unit)
                                and has_ready_assessment(unit=unit)),
        'seo_title':f'{unit.title} | Rozh',
    })


def _validate(q, answer):
    if q['type'] in V58_KINDS and q.get('exercise') is not None:
        return v58_answer_valid(q['exercise'], answer, q.get('round_seed',''))
    if q['type'] in ('choice','listening-choice','picture','photo'):
        return answer in q['options']
    if q['type'] == 'wordbank':
        # Equivalent Unicode/casing must not be rejected before grading.
        # Token multiplicities still have to match exactly.
        import unicodedata
        norm = lambda word: unicodedata.normalize('NFC', word).casefold()
        return Counter(map(norm, answer.split())) == Counter(map(norm, q['answer'].split()))
    if q['type'] in ('speaking','reflection'):
        return answer == 'practised'
    return bool(answer.strip()) and len(answer) <= 300


def _evaluate(q,answer):
    if not q['graded']: return True
    if q['type'] in V58_KINDS and q.get('exercise') is not None:
        return v58_grade(q['exercise'], answer, q.get('round_seed',''))
    if q['type'] == 'wordbank':
        # Correct *order* is required; tolerate only whitespace/case/NFC differences.
        import unicodedata
        norm = lambda word: unicodedata.normalize('NFC', word).casefold()
        return list(map(norm, answer.split())) == list(map(norm, q['answer'].split()))
    if q['type'] in ('picture','photo','dictation'): return answer.strip().rstrip('.!?。؟').strip().casefold() == q['answer'].strip().rstrip('.!?。؟').strip().casefold()
    return grade(q['exercise'],answer)


def _authored_lesson_scores(items, results):
    """Grade each authored lesson separately so visual bonus questions cannot mask errors."""
    grouped = {}
    for item in items:
        if item.get('exercise') is not None:
            grouped.setdefault(item['lesson_id'], []).append(item['id'])
    return {lesson_id: round(100 * sum(bool(results.get(key)) for key in keys) / len(keys))
            for lesson_id, keys in grouped.items()
            if all(key in results for key in keys)}


def _grant_completed_lessons(user, unit, items, results, score):
    """Credit previously-existing lessons only, with XP keys used by old lessons.

    Called only for a passed COMPLETE run. Never grant XP for self-review only.
    """
    awarded=0
    per_lesson=_authored_lesson_scores(items,results)
    # Only published lessons whose authored question set was in the round.
    for lesson in Lesson.objects.filter(unit=unit,published=True):
        original=list(lesson.exercises.filter(kind__in=('mcq','short') + V58_KINDS).values_list('pk',flat=True))
        if original:
            if any(f'e{pk}' not in results for pk in original) or per_lesson.get(lesson.pk,0) < 70:
                continue
        else:
            continue
        _,created=LessonProgress.objects.get_or_create(user=user,lesson=lesson,
                         defaults={'score':per_lesson[lesson.pk],'content_version':lesson.content_version})
        if created and original:
            if award_xp(user,20,reason='lesson',event_key=f'lesson:{lesson.pk}'):
                awarded+=20
    if awarded:
        for word in Vocabulary.objects.filter(level=unit.level,published=True):
            ReviewCard.objects.get_or_create(user=user,vocabulary=word)
    return awarded


@login_required
@require_POST
@transaction.atomic
def answer_level(request,pk):
    # Serialize admissions with course switches and account suspension. Lock
    # Profile FIRST (the same order used by XP awards), then check CURRENT
    # state in this transaction before spending hearts or saving progress.
    profile = Profile.objects.select_for_update().filter(user=request.user).first()
    if profile is None:
        return JsonResponse({'error':'This learning account is unavailable.'},status=403)
    unit=_get_unit(request,pk)
    if (not journey_round_allowed(profile, unit, user_active=request.user.is_active)
            or not allowed_unit(request.user,unit,profile=profile)):
        return JsonResponse({'error':'This course level is locked.'},status=403)
    block_reason = mixed_unit_block_reason(unit)
    if block_reason:
        from .lesson_unavailable_v96 import for_locale
        return JsonResponse({'error':for_locale(profile.ui_language)[block_reason],
                             'error_code':'audio_not_ready' if block_reason == 'audio' else 'activity_not_ready'},status=409)
    if rate_limit(request,'journey-v11',240,3600,True):
        return JsonResponse({'error':'Too many answers. Please try later.'},status=429)
    state,items=_current(request,unit,ui_language=profile.ui_language)
    if not items or state.get('done') or state['position'] >= len(items):
        return JsonResponse({'error':'This round is already finished.'},status=409)
    q=items[state['position']]
    if request.POST.get('round_token') != state['token'] or request.POST.get('challenge_id') != q['id']:
        return JsonResponse({'error':'This question has expired. Reload the level.'},status=409)
    answer=request.POST.get('answer','')
    if not isinstance(answer,str) or len(answer)>300 or not _validate(q,answer):
        return JsonResponse({'error':'Choose or enter a valid answer.'},status=400)
    if q['graded']:
        hearts=snapshot(request.user)
        if hearts['empty']:
            return JsonResponse({'error':'No hearts remain.','error_code':'hearts_empty','hearts':hearts},status=402)
    else: hearts=snapshot(request.user)
    success=_evaluate(q,answer)
    if q['graded'] and not success:
        try:
            hearts=spend_for_answer(request.user,f'journey:{unit.pk}:run:{state["token"]}:q:{q["id"]}')
        except HeartEmpty as error:
            return JsonResponse({'error':'No hearts remain.','error_code':'hearts_empty','hearts':error.state},status=402)
        if not hearts.get('spent'):
            return JsonResponse({'error':'This answer was already checked.'},status=409)
    if q['graded'] and q.get('exercise') is not None:
        record_exercise_result(request.user,q['exercise'],success)
    state['results'][q['id']]=bool(success)
    state['position']+=1
    finished=state['position']>=len(items)
    from .lesson_feedback_v101 import graded_solution
    result={'correct':success,'ungraded':not q['graded'],
            'solution':graded_solution(q['exercise'], success) if q.get('exercise') is not None else '',
            'explanation':q.get('explanation','') if q['graded'] else '',
            'finished':finished,'hearts':hearts,
            'next_url':reverse('journey_play',args=[unit.pk])}
    if finished:
        graded=[q for q in items if q['graded']]
        score=round(100*sum(bool(state['results'].get(q['id'])) for q in graded)/len(graded)) if graded else 0
        # Supplemental audio/photo exercises alone cannot certify an empty unit.
        authored_scores=_authored_lesson_scores(items,state['results'])
        authored_count=len({q['lesson_id'] for q in items if q.get('exercise') is not None})
        # All authored lessons must reach their own pass mark. Correct supplementary
        # photos/word-bank questions cannot cover up failures in real course work.
        passed=(bool(graded) and authored_count>0 and score>=70 and
                len(authored_scores)==authored_count and all(value>=70 for value in authored_scores.values()))
        earned=0
        if passed:
            with transaction.atomic(): earned=_grant_completed_lessons(request.user,unit,items,state['results'],score)
        state.update(done=True,score=score,passed=passed,earned_xp=earned)
        result.update(score=score,passed=passed,xp_awarded=earned)
    request.session[_key(unit.pk)]=state
    request.session.modified=True
    # Progressive enhancement: with JavaScript disabled, proceed to the next
    # server-rendered question rather than displaying raw JSON to the student.
    if request.headers.get('X-Requested-With') != 'XMLHttpRequest':
        caption=labels_for(request.user)
        messages.info(request, caption['correct'] if success else caption['incorrect'])
        return redirect('journey_play', pk=unit.pk)
    return JsonResponse(result)


urlpatterns = [
 path('journey/levels/<int:pk>/',play_level,name='journey_play'),
 path('journey/levels/<int:pk>/answer/',answer_level,name='journey_answer'),
]


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'journey_v11', ['LOCALES'])

"""Rozh V58: 13 explicit, editor-authored, deterministic free learning activities.

No paid AI/API, no implicit publishing, no browser-owned correct answers. All
activity data is JSON only and is validated before Manager saves or production
lessons use it. Old `mcq` and `short` exercises stay binary-compatible.
"""
import hashlib
import json
import random
import re
import unicodedata
from collections import Counter
from pathlib import Path

KINDS = (
    ('mcq', 'Multiple Choice'),
    ('sentence_builder', 'Sentence Builder'),
    ('picture_match', 'Picture Match'),
    ('fill_blank', 'Fill in the Blank'),
    ('word_matching', 'Word Matching'),
    ('listening', 'Listening Challenge'),
    ('true_false', 'True or False'),
    ('spelling', 'Spelling Challenge'),
    ('word_order', 'Word Order'),
    ('find_mistake', 'Find the Mistake'),
    ('memory_match', 'Memory Match'),
    ('choose_image', 'Choose the Image'),
    ('complete_conversation', 'Complete the Conversation'),
)
KIND_KEYS = tuple(key for key, _ in KINDS)
LEGACY_KIND = ('short', 'Short answer')
ALL_KIND_CHOICES = (KINDS[0], LEGACY_KIND) + KINDS[1:]
MATCHING = ('word_matching', 'memory_match')
CHOICE = ('mcq', 'picture_match', 'listening', 'true_false', 'find_mistake',
          'choose_image', 'complete_conversation')
TILES = ('sentence_builder', 'word_order')
# Stable per-round shuffling for multiple-choice activities where author order
# has no pedagogical meaning. Never shuffle Find the Mistake's sentence parts.
ROUND_SHUFFLED_CHOICES = ('picture_match', 'listening', 'complete_conversation')
TYPED = ('short', 'fill_blank', 'spelling')
IMAGE_DIRECTORY = Path(__file__).resolve().parent / 'static' / 'academy'
IMAGE_PATH_RE = re.compile(r'^academy/(?:photos|activity-media)/[a-z0-9][a-z0-9_-]{0,90}\.(?:png|webp|jpg|jpeg)$')

AUTHOR_GUIDANCE = {
  'mcq': 'Options: ["red", "blue", "green"]. Answer: one exact option.',
  'short': 'No options. Answer: expected short text (legacy type).',
  'sentence_builder': 'Options: separate word tiles in the answer sentence, including repeated words. Answer: full correctly ordered sentence.',
  'picture_match': 'Options: 2–6 words. Answer: one option. Activity data: {"image":"academy/photos/books.jpg","image_alt":"A photograph showing a stack of books"}. Only locally licensed images.',
  'fill_blank': 'Prompt contains exactly one ___ blank. Answer: canonical missing word. Optional activity data: {"accepted_answers":["editor-approved alternative"]} (max 10 distinct alternatives). No options.',
  'word_matching': 'Activity data: {"pairs":[{"left":"apple","right":"fruit"},{"left":"chair","right":"furniture"}]}. No options or answer required.',
  'listening': 'Options: 2–6 answers. Answer: one option. Activity data: {"audio_text":"The spoken sentence."}. Device TTS only.',
  'true_false': 'No options required. Answer must be True or False.',
  'spelling': 'No options. Answer: exact correct spelling.',
  'word_order': 'Options: all separate tokens of the answer, including repeated words. Answer: full correctly ordered sentence.',
  'find_mistake': 'Prompt: sentence with a mistake. Options: 2–6 selectable words or phrases. Answer: the erroneous part.',
  'memory_match': 'Activity data: {"pairs":[{"left":"dog","right":"animal"},{"left":"red","right":"colour"}]}. Flip-to-reveal cards, server-checked matches.',
  'choose_image': 'Activity data: {"images":[{"label":"books","path":"academy/photos/books.jpg"},{"label":"train","path":"academy/photos/train.jpg"}]}. Answer: correct label.',
  'complete_conversation': 'Activity data: {"dialogue":["Hello!", "What is your name?"]}. Options: 2–6 replies. Answer: one reply. One-step completion, no branching.',
}


def _filled(value, limit=300):
    return isinstance(value, str) and bool(value.strip()) and len(value) <= limit


def _unique(values):
    if not isinstance(values, (list, tuple)) or any(not isinstance(s, str) for s in values):
        return False
    folded = [s.strip().casefold() for s in values]
    return len(folded) == len(set(folded))


def _local_image(path):
    if not isinstance(path, str) or not IMAGE_PATH_RE.fullmatch(path):
        return False
    # Only packaged assets under an allowed directory; no URLs/data URI/traversal.
    file = IMAGE_DIRECTORY / path.removeprefix('academy/')
    return file.is_file()


def validate_activity(kind, prompt, options, answer, explanation, data=None):
    """Return human-readable errors. No lesson is made up or saved here."""
    errors = []
    data = {} if data is None else data
    if kind not in KIND_KEYS and kind != 'short':
        return ['Unsupported activity type.']
    if not _filled(prompt, 1000):
        errors.append('Enter a question prompt (at most 1000 characters).')
    if not _filled(explanation, 2000):
        errors.append('Write a useful explanation for feedback (at most 2000 characters).')
    if not isinstance(data, dict) or len(json.dumps(data, ensure_ascii=False)) > 5000:
        return errors + ['Activity data must be a small JSON object (maximum 5,000 characters).']
    if not isinstance(options, list):
        return errors + ['Options must be a JSON list.']
    if len(options) > 20 or any(not _filled(x, 200) for x in options):
        errors.append('Options must contain at most 20 nonempty strings of 200 characters.')
    if kind in CHOICE and kind != 'true_false':
        available = [image['label'] for image in data.get('images', []) if isinstance(image, dict) and isinstance(image.get('label'), str)] if kind == 'choose_image' and isinstance(data.get('images'), list) else options
        if not 2 <= len(available) <= 6 or not _unique(available):
            errors.append('Provide 2–6 distinct answer choices.')
        if not _filled(answer) or answer not in available:
            errors.append('The correct answer must exactly match a provided choice.')
    elif kind == 'true_false':
        if answer not in ('True', 'False'):
            errors.append('True or False must be answered with exactly True or False.')
        if options and options != ['True', 'False']:
            errors.append('True/False options must be empty or ["True", "False"].')
    elif kind in TILES:
        if not 2 <= len(options) <= 20 or not _filled(answer):
            errors.append('Provide 2–20 word tiles and a full answer sentence.')
        elif not all(_filled(tile, 200) for tile in options):
            # Earlier validation already reports invalid JSON options. Guard
            # Counter below too: malicious/mistaken nested lists or objects
            # are unhashable and must never crash a Manager POST with 500.
            errors.append('Each word tile must be a nonempty text value.')
        elif Counter(options) != Counter(answer.split()):
            errors.append('Every answer token must appear in the tiles with the same repetition count.')
        elif len(answer) > 300:
            errors.append('The completed sentence must fit 300 characters.')
    elif kind in MATCHING:
        pairs = data.get('pairs')
        if not isinstance(pairs, list) or not 2 <= len(pairs) <= 8:
            errors.append('Provide 2–8 word/meaning pairs in activity data.')
        else:
            for p in pairs:
                if not isinstance(p, dict) or not _filled(p.get('left'), 120) or not _filled(p.get('right'), 120):
                    errors.append('Each pair needs a short left and right label.'); break
            if not errors and (not _unique([p['left'] for p in pairs]) or not _unique([p['right'] for p in pairs])):
                errors.append('Left and right match labels must be unique.')
        if options or (answer or '').strip():
            errors.append('Matching activities store pairs in activity data; leave Options and Answer empty.')
    else:
        if not _filled(answer):
            errors.append('Provide a correct answer (maximum 300 characters).')
        if options:
            errors.append('This activity uses a text answer; leave Options empty.')
    if kind == 'picture_match':
        if not _local_image(data.get('image')):
            errors.append('Select an existing local image from academy/photos or academy/activity-media.')
        if not _filled(data.get('image_alt'), 180):
            errors.append('Add a concise image_alt description so screen-reader learners can understand the photograph.')
    if kind == 'choose_image':
        if options:
            errors.append('Choose the Image uses images; leave Options empty.')
        images = data.get('images')
        if not isinstance(images, list) or not 2 <= len(images) <= 6:
            errors.append('Provide 2–6 local images with distinct labels.')
        else:
            if any(not isinstance(i, dict) or not _filled(i.get('label'), 100) or not _local_image(i.get('path')) for i in images):
                errors.append('Each image must have a short label and a licensed local file path.')
            # Two differently named answers with the *same actual picture*
            # make a visual question impossible to answer fairly.
            paths = [i.get('path') for i in images if isinstance(i, dict)]
            if len(paths) == len(images) and any(not isinstance(path, str) for path in paths):
                errors.append('Every image needs a valid path.')
            elif len(paths) == len(images) and len(set(paths)) != len(paths):
                errors.append('Choose the Image requires a different local image for every option.')
    if kind == 'listening' and not _filled(data.get('audio_text'), 500):
        errors.append('Listening requires authored audio_text for browser speech playback (no paid API).')
    if kind == 'complete_conversation':
        lines = data.get('dialogue')
        if not isinstance(lines, list) or not 1 <= len(lines) <= 5 or any(not _filled(x, 240) for x in lines):
            errors.append('Provide 1–5 short dialogue lines in activity data.')
    if kind == 'fill_blank':
        if prompt.count('___') != 1:
            errors.append('Fill in the Blank needs exactly one ___ in its prompt.')
        # Alternative correct answers are editorial decisions, never AI or
        # browser guesses. Reject malformed/duplicate values on publication.
        variants = data.get('accepted_answers', [])
        if (not isinstance(variants, list) or len(variants) > 10
                or any(not _filled(value, 300) for value in variants)):
            errors.append('accepted_answers must contain at most 10 nonempty text alternatives.')
        else:
            normalized = [_normalized_word(value.strip()) for value in variants]
            if (len(set(normalized)) != len(normalized)
                    or _normalized_word((answer or '').strip()) in normalized):
                errors.append('accepted_answers must be distinct from the main answer and each other.')
    return errors


def ready(exercise):
    return not validate_activity(exercise.kind, exercise.prompt, exercise.options,
                                 exercise.answer, exercise.explanation,
                                 getattr(exercise, 'activity_data', {}))



def student_ready(exercise, course_code):
    """Strict student/published-content gate; unlike ready(), requires real audio.

    Keep the structural validator usable by Manager for draft authoring.
    Student play/grade is denied when an approved byte-verified clip is absent.
    """
    if not ready(exercise):
        return False
    if exercise.kind != 'listening':
        return True
    data = getattr(exercise, 'activity_data', None)
    if not isinstance(data, dict):
        return False
    from .audio_v78 import approved_audio_url
    return bool(approved_audio_url(data.get('audio_text'), course_code))

def published_lesson_activity_errors(exercises, course_code):
    """Explain authored activity blockers *before* a lesson is published.

    Called by both Manager and Django Admin. Existing mcq/short teaching paths
    retain their established legacy contract. Student views always recheck the
    published activity rather than trusting this editorial preflight.
    """
    issues = []
    for exercise in exercises:
        if exercise.kind in ('mcq', 'short'):
            continue
        name = f'Exercise #{exercise.pk}'
        problems = validate_activity(
            exercise.kind, exercise.prompt, exercise.options, exercise.answer,
            exercise.explanation, getattr(exercise, 'activity_data', {}),
        )
        if problems:
            issues.append(f'{name}: {problems[0]}')
        elif exercise.kind == 'listening' and not student_ready(exercise, course_code):
            issues.append(f'{name}: teacher-approved audio is missing for this course.')
    return issues


def _shuffled(values, seed):
    values = list(values)
    numeric_seed = int.from_bytes(hashlib.sha256(str(seed).encode()).digest()[:8], 'big')
    random.Random(numeric_seed).shuffle(values)
    return values


def public_activity(exercise, round_seed=''):
    """Only fields intended for the learner; never expose match keys or answer."""
    kind = exercise.kind
    data = exercise.activity_data or {}
    result = {'type':kind,'options':list(exercise.options or []), 'images':[],
              'matches':[], 'audio':'', 'dialogue':[], 'image':''}
    if kind in ROUND_SHUFFLED_CHOICES:
        result['options'] = _shuffled(result['options'], f'{round_seed}:choices:{exercise.pk}')
    if kind == 'true_false': result['options'] = ['True','False']
    if kind == 'choose_image':
        result['images'] = _shuffled([{'label':i['label'],'path':i['path']} for i in data['images']],
                                     f'{round_seed}:images:{exercise.pk}')
        result['options'] = [i['label'] for i in result['images']]
    if kind == 'picture_match':
        result['image'] = data['image']
        result['image_alt'] = data['image_alt']
    if kind == 'listening': result['audio'] = data['audio_text']
    if kind == 'complete_conversation': result['dialogue'] = data['dialogue'][:]
    if kind in MATCHING:
        pairs = data['pairs']
        order = _shuffled(list(range(len(pairs))), f'{round_seed}:match:{exercise.pk}')
        result['matches'] = [{'left':p['left']} for p in pairs]
        result['match_options'] = [pairs[i]['right'] for i in order]
        # Secret order deliberately remains server-side, never in HTML.
    if kind in TILES:
        result['tokens'] = [{'id':n, 'text':value} for n,value in
                            enumerate(_shuffled(exercise.options, f'{round_seed}:tiles:{exercise.pk}'))]
    return result


def _normalized_word(value):
    # Unicode NFC keeps visually identical composed/decomposed accents equivalent
    # without removing meaningful accents, Kurdish characters, or punctuation.
    return unicodedata.normalize('NFC', value).casefold()


def validate_answer(exercise, answer, round_seed=''):
    if not isinstance(answer, str) or not answer.strip() or len(answer) > 300:
        return False
    kind = exercise.kind
    if kind in CHOICE:
        opts = (['True','False'] if kind == 'true_false' else
                [item['label'] for item in exercise.activity_data['images']] if kind == 'choose_image'
                else exercise.options)
        return answer in opts
    if kind in MATCHING:
        try:
            values = json.loads(answer)
        except (ValueError, TypeError):
            return False
        n = len(exercise.activity_data['pairs'])
        return (isinstance(values, list) and len(values) == n and
                all(type(i) is int and 0 <= i < n for i in values) and
                len(set(values)) == n)
    if kind in TILES:
        # The tile UI also provides a typed fallback for keyboard/screen-reader
        # users. Capitalization and whitespace do not change word identity;
        # repetition and the complete authored token inventory still do.
        return Counter(map(_normalized_word, answer.split())) == Counter(
            map(_normalized_word, exercise.options))
    return kind in TYPED and bool(answer.strip())


def is_correct(exercise, answer, round_seed=''):
    if not validate_answer(exercise, answer, round_seed):
        return False
    if exercise.kind in MATCHING:
        n = len(exercise.activity_data['pairs'])
        order = _shuffled(list(range(n)), f'{round_seed}:match:{exercise.pk}')
        chosen = json.loads(answer)
        return all(order[selected_index] == left_index for left_index, selected_index in enumerate(chosen))
    if exercise.kind in TILES:
        # Compare token *order* after validating the full multiset above.
        # Unlike the old literal-string comparison, harmless extra spaces and
        # alternative capitalization cannot incorrectly fail a correct answer.
        return ([_normalized_word(s) for s in answer.split()] ==
                [_normalized_word(s) for s in exercise.answer.split()])
    if exercise.kind == 'fill_blank':
        # Only the Manager-authored canonical answer and vetted synonyms count.
        # Preserve Unicode accents and punctuation, while ignoring case and
        # surrounding whitespace. Do not infer semantic equivalence.
        allowed = [exercise.answer]
        data = exercise.activity_data if isinstance(exercise.activity_data, dict) else {}
        alternatives = data.get('accepted_answers', [])
        if isinstance(alternatives, list):
            allowed.extend(x for x in alternatives if isinstance(x, str))
        return _normalized_word(answer.strip()) in {_normalized_word(x.strip()) for x in allowed}
    return _normalized_word(answer.strip()) == _normalized_word(exercise.answer.strip())


ACTIVITY_TITLES = {
 'nl': {'mcq':'Kies het juiste antwoord','sentence_builder':'Bouw de zin','picture_match':'Welk woord hoort bij de afbeelding?',
        'fill_blank':'Vul het ontbrekende woord in','word_matching':'Verbind de woorden','listening':'Luister en kies',
        'true_false':'Waar of niet waar?','spelling':'Schrijf het woord correct','word_order':'Zet de woorden in volgorde',
        'find_mistake':'Zoek de fout','memory_match':'Onthoud en koppel','choose_image':'Kies de juiste afbeelding',
        'complete_conversation':'Maak het gesprek af'},
 'en': {'mcq':'Choose the correct answer','sentence_builder':'Build the sentence','picture_match':'Match the picture',
        'fill_blank':'Fill in the blank','word_matching':'Match the words','listening':'Listen and choose',
        'true_false':'True or false?','spelling':'Spell the word','word_order':'Put the words in order',
        'find_mistake':'Find the mistake','memory_match':'Remember and match','choose_image':'Choose the picture',
        'complete_conversation':'Complete the conversation'},
 'ckb': {'mcq':'وەڵامی ڕاست هەڵبژێرە','sentence_builder':'ڕستەکە دروست بکە','picture_match':'وشەی گونجاو بۆ وێنەکە هەڵبژێرە',
        'fill_blank':'بۆشاییەکە پڕ بکەوە','word_matching':'وشەکان بەیەکەوە ببەستەوە','listening':'گوێ بگرە و هەڵبژێرە',
        'true_false':'ڕاستە یان هەڵە؟','spelling':'وشەکە بە دروستی بنووسە','word_order':'وشەکان ڕێک بخە',
        'find_mistake':'هەڵەکە بدۆزەوە','memory_match':'بیرت بێت و بەیەکەوەیان ببەستەوە',
        'choose_image':'وێنەی ڕاست هەڵبژێرە','complete_conversation':'گفتوگۆکە تەواو بکە'},
 'ar': {'mcq':'اختر الإجابة الصحيحة','sentence_builder':'كوّن الجملة','picture_match':'طابق الصورة',
        'fill_blank':'أكمل الفراغ','word_matching':'طابق الكلمات','listening':'استمع واختر',
        'true_false':'صح أم خطأ؟','spelling':'اكتب الكلمة بشكل صحيح','word_order':'رتّب الكلمات',
        'find_mistake':'اكتشف الخطأ','memory_match':'تذكّر وطابق','choose_image':'اختر الصورة الصحيحة',
        'complete_conversation':'أكمل المحادثة'},
}


def title_for(kind, locale):
    return ACTIVITY_TITLES.get(locale, ACTIVITY_TITLES['en']).get(kind, kind)


def lesson_content_fingerprint(exercises, *, lesson=None):
    """Bind questions and, for classic rounds, the authored lesson itself."""
    rows = [dict(pk=e.pk, version=e.content_version, kind=e.kind, prompt=e.prompt,
                 answer=e.answer, options=e.options, activity_data=getattr(e,'activity_data',{}),
                 explanation=e.explanation, difficulty=getattr(e,'difficulty', None),
                 order=getattr(e,'order', None), lesson_id=getattr(e,'lesson_id', None))
            for e in exercises]
    # Preserve the exercise-only API used by older callers and test suites.
    payload = rows if lesson is None else {
        'lesson': {name: getattr(lesson, name) for name in (
            'pk', 'unit_id', 'skill', 'title', 'content', 'audio_text',
            'content_version', 'order', 'slug')},
        'exercises': rows,
    }
    raw=json.dumps(payload,sort_keys=True,ensure_ascii=False,separators=(',',':'))
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'lesson_activities_v58', ['ACTIVITY_TITLES'])

"""Four-language, consent-respecting leaderboard read model. No writes or migrations."""
from datetime import timedelta
from django.db.models import Q, Sum
from django.utils import timezone
from .models import XPEvent, Profile
from .rozh2027 import student_shell_context
LEARNING_REASONS=('lesson','assessment','review','mistake','arena')
COPY={
 'nl':dict(title='Ranglijst',intro='Alleen leerlingen die zelf toestemming geven verschijnen hier.',all='Alle XP',week='Laatste 7 dagen',empty='Nog geen deelnemers.',privacy='Deelname beheren',you='Jij',info='De weekscore telt alleen leer-XP.'),
 'en':dict(title='Leaderboard',intro='Only learners who opt in appear here.',all='All XP',week='Last 7 days',empty='No participants yet.',privacy='Manage participation',you='You',info='The weekly score counts learning XP only.'),
 'ckb':dict(title='پلەبەندی',intro='تەنها ئەو فێرخوازانە دەردەکەون کە خۆیان ڕازی بوون.',all='هەموو XP',week='٧ ڕۆژی ڕابردوو',empty='هێشتا بەشداربوو نییە.',privacy='ڕێکخستنی بەشداری',you='تۆ',info='پلەبەندی هەفتانە تەنها XPی فێربوون هەژمار دەکات.'),
 'ar':dict(title='لوحة المتصدرين',intro='يظهر فقط من يختار المشاركة.',all='كل نقاط XP',week='آخر ٧ أيام',empty='لا يوجد مشاركون بعد.',privacy='إدارة المشاركة',you='أنت',info='الترتيب الأسبوعي يحسب نقاط التعلم فقط.'),
}
def context(request):
  mode='week' if request.GET.get('period')=='week' else 'all'
  from .safe_profile_context_v46 import visible_learning_profile
  profile=visible_learning_profile(request.user)
  lang=profile.ui_language if profile is not None else 'en'
  L=COPY.get(lang,COPY['en'])
  # An earlier ranking opt-in does not override a later account suspension,
  # historical review hold or mandatory onboarding. Apply the same eligible
  # profile set to BOTH leaderboards before sorting and selecting the top 30.
  allowed=(Profile.objects.filter(
      leaderboard_opt_in=True,
      user__is_active=True,
      suspended_at__isnull=True,
      legacy_review_required=False,
  ).filter(Q(onboarding_required=False) | Q(onboarding_completed=True)))
  rows=[]
  if mode=='week':
    winners=list(XPEvent.objects.filter(user_id__in=allowed.values('user_id'),
       reason__in=LEARNING_REASONS,
       created_at__gte=timezone.now()-timedelta(days=7))
       .values('user_id').annotate(points=Sum('amount'))
       .order_by('-points','user_id')[:30])
    profiles={p.user_id:p for p in allowed.filter(user_id__in=[x['user_id'] for x in winners]).select_related('user')}
    for x in winners:
      p=profiles.get(x['user_id'])
      if p: rows.append((p,int(x['points'])))
  else:
    rows=[(p,p.xp) for p in allowed.select_related('user').order_by('-xp','user_id')[:30]]
  leaders=[{'rank':i,'username':p.user.get_username(),'avatar':p.avatar,'xp':points,
     'me':request.user.is_authenticated and request.user.pk==p.user_id}
     for i,(p,points) in enumerate(rows,1)]
  data={'S6':L,'leaders':leaders,'period':mode,'page_title':L['title'],
        'noindex':True, 'shell_template':'academy/base.html'}
  if profile is not None:
    data.update(student_shell_context(request))
    data['shell_template']='academy/rozh2027_student_shell.html'
  return data


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'rozh_social_ui', ['COPY'])

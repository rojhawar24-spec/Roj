"""Real-Django V63 checks. Run only against an isolated test database.

The offline release build does not claim these are executed unless Django is
available in the QA container.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .lesson_flow_v63 import next_step
from .models import Assessment, Exercise, Language, Lesson, LessonProgress, Level, Profile, Unit, XPEvent


class LinearLessonFlowV63Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.student = get_user_model().objects.create_user(
            username='v63-student', password='V63FakeTestPassword!111')
        cls.course = Language.objects.create(
            code='nl', name='Dutch V63', slug='v63-dutch',
            description='QA-only course', is_published=True)
        cls.level = Level.objects.create(language=cls.course, code='A0',
                                         order=0, description='QA A0')
        cls.unit = Unit.objects.create(level=cls.level, slug='v63-one',
                                       title='Unit 1', summary='QA', order=1, published=True)
        cls.second_unit = Unit.objects.create(level=cls.level, slug='v63-two',
                                              title='Unit 2', summary='QA', order=2, published=True)
        cls.second_unit.prerequisites.add(cls.unit)
        cls.first = Lesson.objects.create(unit=cls.unit, slug='v63-a', title='First',
                                          skill='grammar', order=1, content='Info', published=True)
        cls.second = Lesson.objects.create(unit=cls.unit, slug='v63-b', title='Second',
                                           skill='reading', order=2, content='Info', published=True)
        cls.third = Lesson.objects.create(unit=cls.second_unit, slug='v63-c', title='Third',
                                          skill='grammar', order=1, content='Info', published=True)
        cls.first_question = Exercise.objects.create(lesson=cls.first, kind='mcq',
                                    prompt='Question 1?', options=['Yes','No'], answer='Yes',
                                    explanation='Yes', order=1)
        cls.second_question = Exercise.objects.create(lesson=cls.second, kind='mcq',
                                    prompt='Question 2?', options=['Yes','No'], answer='Yes',
                                    explanation='Yes', order=1)
        Profile.objects.filter(user=cls.student).update(
            preferred_language=cls.course, placement_completed=True,
            onboarding_required=False, onboarding_completed=True,
            suspended_at=None, legacy_review_required=False)

    def setUp(self):
        self.client.force_login(self.student)

    def test_first_lesson_starts_with_single_question_and_author_control(self):
        response = self.client.get(reverse('lesson', args=[self.first.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'data-lesson-root')
        self.assertContains(response, 'id="lessonPractice"')
        self.assertContains(response, 'id="lessonFinishPrimary"')
        self.assertContains(response, 'id="lessonFinishSecondary"')
        self.assertContains(response, 'rozh-lesson-flow-v63.css')

    def test_next_real_lesson_is_selected_in_course_order(self):
        action = next_step(self.student, self.first)
        self.assertEqual(action['kind'], 'lesson')
        self.assertEqual(action['url'], reverse('lesson', args=[self.second.pk]))

    def test_last_lesson_needs_verified_completion_then_unit_test(self):
        self.assertIsNone(next_step(self.student, self.second))
        for lesson in (self.first, self.second):
            LessonProgress.objects.create(user=self.student, lesson=lesson,
                                          score=100, content_version=lesson.content_version)
        action = next_step(self.student, self.second)
        self.assertEqual(action['kind'], 'unit_test')
        self.assertEqual(action['url'], reverse('assessment_unit', args=[self.unit.pk]))

    def test_unavailable_unit_test_not_offered_without_mcq(self):
        Exercise.objects.filter(lesson__unit=self.unit).delete()
        for lesson in (self.first, self.second):
            LessonProgress.objects.create(user=self.student, lesson=lesson,
                                          score=100, content_version=lesson.content_version)
        self.assertIsNone(next_step(self.student, self.second))

    def test_unlocked_next_unit_after_passed_test(self):
        for lesson in (self.first, self.second):
            LessonProgress.objects.create(user=self.student, lesson=lesson,
                                          score=100, content_version=lesson.content_version)
        Assessment.objects.create(user=self.student,kind='unit',unit=self.unit,
                                  score=100,passed=True,responses={})
        action = next_step(self.student, self.second)
        self.assertEqual(action['kind'], 'lesson')
        self.assertEqual(action['url'], reverse('lesson', args=[self.third.pk]))

    def test_server_completion_returns_next_action_without_second_xp(self):
        response = self.client.get(reverse('lesson', args=[self.first.pk]))
        self.assertEqual(response.status_code, 200)
        token = response.context['lesson_round_key']
        answer = self.client.post(reverse('lesson_answer', args=[self.first.pk]), {
            'exercise_id': self.first_question.pk, 'answer': 'Yes', 'round_key': token})
        self.assertEqual(answer.status_code, 200)
        self.assertTrue(answer.json()['completed'])
        self.assertEqual(answer.json()['next_action']['url'],
                         reverse('lesson', args=[self.second.pk]))
        credit_count = XPEvent.objects.filter(user=self.student, reason='lesson').count()
        replay = self.client.post(reverse('lesson_answer', args=[self.first.pk]), {
            'exercise_id': self.first_question.pk, 'answer': 'Yes', 'round_key': token})
        self.assertEqual(replay.status_code, 409)
        self.assertEqual(XPEvent.objects.filter(user=self.student, reason='lesson').count(), credit_count)

    def test_play_hub_primary_target_is_lesson_not_old_unit(self):
        response = self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context['route']['next_url'],
                         reverse('lesson', args=[self.first.pk]))

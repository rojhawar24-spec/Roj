"""V75 Django HTTP/ORM tests. Run only on disposable Django SQLite test DB."""
import json
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .models import Language, Level, GrammarTopic, ContentRevision, AuditEvent
from .grammar_rich_models import GrammarArticle
from .manager_roles_v48 import MANAGER_GROUP

VALID_ARTICLE = {
    'intro':'Why the verb follows the subject.',
    'visual_blocks': [
        {'type':'rule_card','title':'Position','body':'Subject + verb.'},
        {'type':'color_coded_sentence','title':'Parts of a sentence',
         'tokens':[{'role':'subject','text':'Ik'},{'role':'verb','text':'loop'}]},
    ],
}

class ManagerVisualGrammarHTTPTests(TestCase):
    def setUp(self):
        User=get_user_model()
        self.manager=User.objects.create_user('v75manager', 'v75manager@example.invalid', 'TEST-V75-Only!')
        self.student=User.objects.create_user('v75learner', 'v75learner@example.invalid', 'TEST-V75-Only!')
        self.manager.groups.add(Group.objects.get_or_create(name=MANAGER_GROUP)[0])
        p=self.manager.learning_profile
        p.email_verified_at=timezone.now();p.totp_secret='JBSWY3DPEHPK3PXP'
        p.save(update_fields=['email_verified_at','totp_secret'])
        self.language=Language.objects.create(code='nl',name='Dutch',slug='nl-v75',description='Test',is_published=True)
        self.level=Level.objects.create(language=self.language,code='A0',description='Starter',order=0)
        self.topic=GrammarTopic.objects.create(level=self.level,slug='v75-demo',title='Word order',
            explanation='Simple grammar.',examples=['Ik loop.'],exceptions='',common_mistakes='',
            check_question='',check_options=[],check_answer='',published=False)
        self.url=reverse('manager_grammar_article_v75',args=[self.topic.pk])

    def authenticate_manager(self, mfa=True):
        self.client.force_login(self.manager)
        if mfa:
            session=self.client.session;session['mfa_verified_id']=self.manager.pk;session.save()

    def payload(self, article, action='preview', version=None):
        return {'article_json':json.dumps(article),'action':action,
                'version':self.topic.content_version if version is None else version}

    def test_ordinary_learner_denied_and_no_write(self):
        self.client.force_login(self.student)
        self.assertEqual(self.client.get(self.url).status_code,403)
        self.assertEqual(self.client.post(self.url,self.payload(VALID_ARTICLE,'save')).status_code,403)
        self.assertFalse(GrammarArticle.objects.filter(topic=self.topic).exists())

    def test_manager_without_mfa_denied(self):
        self.authenticate_manager(mfa=False)
        self.assertEqual(self.client.get(self.url).status_code,403)
        self.assertEqual(self.client.post(self.url,self.payload(VALID_ARTICLE,'save')).status_code,403)

    def test_preview_never_persists_or_audits(self):
        self.authenticate_manager()
        r=self.client.post(self.url,self.payload(VALID_ARTICLE,'preview'))
        self.assertEqual(r.status_code,200)
        self.assertContains(r,'Subject + verb.')
        self.assertContains(r,'Ik')
        self.assertContains(r,'Word order')
        self.assertFalse(GrammarArticle.objects.filter(topic=self.topic).exists())
        self.assertFalse(AuditEvent.objects.filter(action='manager_grammar_article_saved').exists())
        self.topic.refresh_from_db();self.assertEqual(self.topic.content_version,1)

    def test_valid_save_audit_revision_and_student_visibility_only_after_publication(self):
        self.authenticate_manager()
        r=self.client.post(self.url,self.payload(VALID_ARTICLE,'save'))
        self.assertEqual(r.status_code,302)
        article=GrammarArticle.objects.get(topic=self.topic)
        self.assertEqual(article.content['visual_blocks'][0]['title'],'Position')
        self.topic.refresh_from_db();self.assertEqual(self.topic.content_version,2)
        self.assertTrue(ContentRevision.objects.filter(model_label=article._meta.label,object_pk=article.pk,version=2).exists())
        self.assertTrue(AuditEvent.objects.filter(action='manager_grammar_article_saved',actor=self.manager).exists())
        self.client.logout()
        self.assertEqual(self.client.get(reverse('grammar',args=[self.topic.pk])).status_code,404)
        self.topic.published=True;self.topic.save(update_fields=['published'])
        self.assertEqual(self.client.get(reverse('grammar',args=[self.topic.pk])).status_code,200)

    def test_invalid_markup_and_schema_not_saved(self):
        self.authenticate_manager()
        bad={'visual_blocks':[{'type':'invented_visual','title':'No','body':'x'}]}
        r=self.client.post(self.url,self.payload(bad,'save'))
        self.assertEqual(r.status_code,200)
        self.assertFalse(GrammarArticle.objects.filter(topic=self.topic).exists())
        self.assertFalse(AuditEvent.objects.filter(action='manager_grammar_article_saved').exists())

    def test_stale_manager_edit_cannot_clobber(self):
        self.authenticate_manager()
        self.assertEqual(self.client.post(self.url,self.payload(VALID_ARTICLE,'save')).status_code,302)
        self.topic.refresh_from_db()
        r=self.client.post(self.url,self.payload({'intro':'Malicious stale edit'},'save',version=1))
        self.assertEqual(r.status_code,200)
        self.assertEqual(GrammarArticle.objects.get(topic=self.topic).content['intro'],VALID_ARTICLE['intro'])
        self.assertEqual(AuditEvent.objects.filter(action='manager_grammar_article_saved').count(),1)

    def test_unknown_actions_do_not_write(self):
        self.authenticate_manager()
        self.assertEqual(self.client.post(self.url,self.payload(VALID_ARTICLE,'delete')).status_code,400)
        self.assertFalse(GrammarArticle.objects.filter(topic=self.topic).exists())

    def test_manager_topic_editor_links_to_visual_editor(self):
        self.authenticate_manager()
        r=self.client.get(reverse('manager_content_edit',args=['grammar',self.topic.pk]))
        self.assertEqual(r.status_code,200)
        self.assertContains(r,self.url)

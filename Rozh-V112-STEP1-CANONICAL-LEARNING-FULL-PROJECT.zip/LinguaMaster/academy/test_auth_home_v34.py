"""V34 real Django integration tests; run on isolated TEST database only.

These are not marked as passed during offline release packaging. They require
Django 6.1.3, project dependencies, and working database migrations.
"""
from unittest.mock import patch

import pyotp
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase, override_settings
from django.urls import reverse

User = get_user_model()

@override_settings(MAILERS={'default':{'BACKEND':'django.core.mail.backends.locmem.EmailBackend'}})
class AuthHomeV34IntegrationTests(TestCase):
    PASSWORD = 'Test-Password-Does-Not-Exist-In-Production-2026!'

    def setUp(self):
        cache.clear()
        self.user = User.objects.create_user('qa_v34_member', 'qa-v34@example.test', self.PASSWORD)
        self.profile = self.user.learning_profile
        self.profile.onboarding_completed = True
        self.profile.placement_completed = True
        self.profile.save(update_fields=['onboarding_completed', 'placement_completed'])

    def test_twelve_correct_mfa_signins_in_15_minutes_do_not_lock_valid_user(self):
        self.profile.totp_secret = pyotp.random_base32()
        self.profile.save(update_fields=['totp_secret'])
        totp = pyotp.TOTP(self.profile.totp_secret)
        origin = 1_800_000_000
        for number in range(12):
            with self.subTest(successful_login=number + 1), patch('time.time', return_value=origin + number * 35):
                start = self.client.post(reverse('login'), {'email': self.user.username, 'password': self.PASSWORD})
                self.assertRedirects(start, reverse('mfa_verify'), fetch_redirect_response=False)
                response = self.client.post(reverse('mfa_verify'), {'code': totp.at(origin + number * 35)})
                self.assertRedirects(response, reverse('play_hub'), fetch_redirect_response=False)
                self.assertEqual(self.client.session.get('mfa_verified_id'), self.user.pk)
                self.assertEqual(self.client.post(reverse('logout')).status_code, 302)
        # Correct tokens did not consume either failed-MFA bucket.
        from .services import _rate_bucket_key
        from types import SimpleNamespace
        request = SimpleNamespace(META={'REMOTE_ADDR': '127.0.0.1'}, user=self.user)
        ip_key = _rate_bucket_key(request, 'mfa')
        account_key = _rate_bucket_key(request, 'mfa-account', account_identifier=f'user:{self.user.pk}')
        self.assertEqual(cache.get(ip_key, 0), 0)
        self.assertEqual(cache.get(account_key, 0), 0)

    def test_eight_wrong_mfa_attempts_lock_ninth_even_with_correct_code(self):
        self.profile.totp_secret = pyotp.random_base32()
        self.profile.save(update_fields=['totp_secret'])
        first = self.client.post(reverse('login'), {'email': self.user.email, 'password': self.PASSWORD})
        self.assertRedirects(first, reverse('mfa_verify'), fetch_redirect_response=False)
        for n in range(8):
            with self.subTest(attempt=n + 1):
                failed = self.client.post(reverse('mfa_verify'), {'code': '000000'})
                self.assertEqual(failed.status_code, 200)
        blocked = self.client.post(reverse('mfa_verify'), {'code': pyotp.TOTP(self.profile.totp_secret).now()})
        self.assertEqual(blocked.status_code, 429)
        self.assertEqual(blocked['Retry-After'], '900')
        self.assertContains(blocked, 'name="csrfmiddlewaretoken"', status_code=429)
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_correct_mfa_must_fail_closed_if_rate_limit_cache_unavailable(self):
        self.profile.totp_secret = pyotp.random_base32()
        self.profile.save(update_fields=['totp_secret'])
        self.client.post(reverse('login'), {'email': self.user.email, 'password': self.PASSWORD})
        with patch('academy.views.rate_limit_exceeded', return_value=True):
            page = self.client.post(reverse('mfa_verify'), {'code': pyotp.TOTP(self.profile.totp_secret).now()})
        self.assertEqual(page.status_code, 429)
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_home_to_login_local_destination_and_private_response(self):
        for locale_url, locale in (('/', 'nl'), ('/en/', 'en'), ('/ckb/', 'ckb'), ('/ar/', 'ar')):
            with self.subTest(locale=locale):
                public = self.client.get(locale_url)
                self.assertEqual(public.status_code, 200)
                self.assertContains(public, 'href="/try/"')
                self.assertContains(public, 'href="/login/?next=/play/"')
                self.assertContains(public, f'lang="{locale}"')
                self.assertContains(public, f'href="{locale_url}"')
                signin = self.client.get(reverse('login'), {'next': '/play/'})
                self.assertEqual(signin.status_code, 200)
                self.assertIn('no-store', signin['Cache-Control'])
                self.assertContains(signin, 'name="next" value="/play/"')
                self.assertContains(signin, f'lang="{locale}"')

    def test_invalid_next_never_redirects_to_another_origin(self):
        for destination in ('//attacker.example/', '/\\attacker.example/', 'https://attacker.example/', '/mfa/verify/'):
            with self.subTest(destination=destination):
                response = self.client.get(reverse('login'), {'next': destination})
                self.assertEqual(response.status_code, 200)
                self.assertNotContains(response, 'name="next" value="' + destination + '"')

"""V59 runtime-checkable contracts (requires a locally installed Django)."""
from copy import deepcopy
from types import SimpleNamespace
from django.test import SimpleTestCase
from .journey_v11 import _fingerprint
from .rozh_v53_ui import LABELS


class V59RoundIntegrity(SimpleTestCase):
    def test_stale_question_content_restarts_round(self):
        row=SimpleNamespace(content_version=1,activity_data={'pairs':[{'left':'dog','right':'animal'}]})
        original={'id':'e1','type':'word_matching','exercise':row,'prompt':'Match the words',
                  'explanation':'A language learning rule.', 'answer':'', 'matches':[{'left':'dog'}],
                  'match_options':['animal']}
        for mutation in ('prompt','explanation','activity_data'):
            other=deepcopy(original)
            if mutation=='activity_data':
                other['exercise'].activity_data['pairs'][0]['right']='pet'
            else:
                other[mutation]='Changed by another editor'
            with self.subTest(mutation=mutation):
                self.assertNotEqual(_fingerprint([original]),_fingerprint([other]))

    def test_all_learning_path_locale_keys_match(self):
        expected=set(LABELS['nl'])
        for locale in ('en','ckb','ar'):
            with self.subTest(locale=locale):
                self.assertEqual(set(LABELS[locale]),expected)

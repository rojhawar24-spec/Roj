"""Database tests; require Django and isolated QA settings."""
from io import StringIO
import json
from django.core.management import call_command, CommandError
from django.test import TestCase
from django.contrib.auth import get_user_model
from academy.models import Exercise, LessonProgress, MistakeRecord, ContentRevision, AuditEvent
from academy.curriculum_policy_v99 import _source_course


class LegacyShortUpgradeTests(TestCase):
    def setUp(self):
        call_command('seed_languages_v10', stdout=StringIO())
        u = _source_course('en')['units'][0]
        lesson = u['lessons'][0]
        self.row = Exercise.objects.get(lesson__unit__level__language__code='en',
            lesson__unit__slug=u['slug'], lesson__slug=lesson['skill'], order=2)
        source = lesson['exercises'][1]
        self.row.kind = source['kind']
        self.row.prompt = source['prompt']
        self.row.save(update_fields=['kind','prompt'])
        self.user = get_user_model().objects.create_user(username='v109-legacy',password='Test-Only-Password-2026!')
        self.progress = LessonProgress.objects.create(user=self.user, lesson=self.row.lesson, score=85)
        self.mistake = MistakeRecord.objects.create(user=self.user, exercise=self.row)

    def test_dry_run_and_apply_preserve_links_and_record_revision(self):
        output=StringIO(); call_command('upgrade_starter_short',stdout=output)
        self.assertIn(self.row.pk,json.loads(output.getvalue())['eligible_ids'])
        self.row.refresh_from_db(); self.assertEqual(self.row.kind,'short')
        answer=self.row.answer
        call_command('upgrade_starter_short','--apply','--id',str(self.row.pk),stdout=StringIO())
        self.row.refresh_from_db(); self.assertEqual(self.row.kind,'fill_blank'); self.assertEqual(self.row.answer,answer)
        self.assertEqual(self.row.content_version,2)
        self.progress.refresh_from_db(); self.assertEqual(self.progress.score,85)
        self.mistake.refresh_from_db(); self.assertEqual(self.mistake.exercise_id,self.row.pk)
        self.assertTrue(ContentRevision.objects.filter(object_pk=self.row.pk,model_label=self.row._meta.label,version=2).exists())
        self.assertTrue(AuditEvent.objects.filter(action='starter_short_upgraded',target=f'{self.row._meta.label}:{self.row.pk}').exists())
        with self.assertRaises(CommandError):
            call_command('upgrade_starter_short','--apply','--id',str(self.row.pk),stdout=StringIO())

    def test_invalid_selection_rolls_back_all(self):
        with self.assertRaises(CommandError):
            call_command('upgrade_starter_short','--apply','--id',str(self.row.pk),'--id','999999999',stdout=StringIO())
        self.row.refresh_from_db(); self.assertEqual(self.row.kind,'short')

    def test_editor_changes_refuse_apply(self):
        self.row.explanation='New manager explanation'; self.row.save(update_fields=['explanation'])
        with self.assertRaises(CommandError):
            call_command('upgrade_starter_short','--apply','--id',str(self.row.pk),stdout=StringIO())
        self.row.refresh_from_db(); self.assertEqual(self.row.explanation,'New manager explanation')

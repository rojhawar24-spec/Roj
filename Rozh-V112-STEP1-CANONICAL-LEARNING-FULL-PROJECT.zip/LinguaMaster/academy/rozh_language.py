"""Safe UI-language switch, independent from the course language and learning progress."""
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from django.db import transaction
from django.http import HttpResponse
from .models import Profile
from .account_signin_policy_v27 import account_signin_permitted
from django.http import HttpResponseBadRequest
from django.shortcuts import redirect
from django.urls import reverse
from urllib.parse import urlencode
from django.views.decorators.http import require_POST

from .ui_languages_v74 import SUPPORTED_UI_LANGUAGES as _V74_LANGUAGES
SUPPORTED_UI_LANGUAGES = frozenset(_V74_LANGUAGES)


@login_required
@require_POST
def switch_ui_language(request):
    language = request.POST.get('ui_language', '')
    if language not in SUPPORTED_UI_LANGUAGES:
        return HttpResponseBadRequest('Unsupported interface language.')
    # Re-read and lock the Profile before mutating the language. A stale
    # authenticated session must not overwrite settings after revocation.
    with transaction.atomic():
        profile = Profile.objects.select_for_update().filter(user_id=request.user.pk).first()
        current_user = get_user_model().objects.filter(pk=request.user.pk).first()
        if not account_signin_permitted(current_user, profile):
            return HttpResponse('Account unavailable.', status=403)
        if profile.onboarding_required and not profile.onboarding_completed:
            return redirect('onboarding')
        if profile.ui_language != language:
            profile.ui_language = language
            profile.save(update_fields=['ui_language'])
    # Preserve the current learner page, including a validated search filter.
    # Never trust user-supplied redirect URLs: only explicitly allowlisted GET
    # routes survive. Older forms without this field use the legacy map below.
    from .navigation_v67 import safe_student_return_path
    current_page = safe_student_return_path(request.POST.get('return_path', ''))
    if current_page:
        return redirect(current_page)
    # Accept only a named internal destination: no arbitrary URL or host redirect.
    # Vocabulary filters are rebuilt from validated values, not a request-supplied URL.
    if request.POST.get('return_to') == 'vocabulary':
        from .app_features import LEVEL_ORDER
        query = request.POST.get('vocab_query', '').strip()[:80]
        level = request.POST.get('vocab_level', '').upper()[:2]
        page = request.POST.get('vocab_page', '')
        params = {}
        if query:
            params['q'] = query
        if level in LEVEL_ORDER:
            params['level'] = level
        if len(page) <= 5 and page.isascii() and page.isdecimal() and 0 < int(page) <= 99999:
            params['page'] = page
        url = reverse('vocabulary')
        return redirect(url + ('?' + urlencode(params) if params else ''))
    destination = request.POST.get('return_to')
    if destination == 'grammar_library':
        from .grammar_v9 import LEVELS
        query = request.POST.get('grammar_query', '').strip()[:100]
        level = request.POST.get('grammar_level', '').upper()[:2]
        status = request.POST.get('grammar_status', '')
        page = request.POST.get('grammar_page', '')
        params = {}
        if query:
            params['q'] = query
        if level in LEVELS:
            params['level'] = level
        if status in ('new', 'practising', 'mastered', 'due'):
            params['status'] = status
        if len(page) <= 5 and page.isascii() and page.isdecimal() and 0 < int(page) <= 99999:
            params['page'] = page
        url = reverse('grammar_library')
        return redirect(url + ('?' + urlencode(params) if params else ''))
    if destination == 'grammar':
        topic_id = request.POST.get('grammar_topic_id', '')
        if len(topic_id) <= 10 and topic_id.isascii() and topic_id.isdecimal() and 0 < int(topic_id) <= 2147483647:
            return redirect('grammar', pk=int(topic_id))
    if destination in ('mistakes', 'word'):
        return redirect(destination)
    if destination == 'ai_tutor':
        return redirect('ai_tutor')
    if destination in ('friends', 'leaderboard', 'profile', 'avatar_studio'):
        return redirect(destination)
    if destination == 'manager':
        # The protected manager view independently enforces role and MFA.
        return redirect('manager')
    if destination == 'leaderboard_week':
        return redirect(reverse('leaderboard') + '?period=week')
    # Deliberately redirect to a fixed internal route; never trust POST redirect URLs.
    return redirect('play_hub')

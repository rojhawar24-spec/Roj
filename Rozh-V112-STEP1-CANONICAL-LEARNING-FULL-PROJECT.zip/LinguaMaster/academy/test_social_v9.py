"""Social privacy, gift idempotency and cosmetic entitlement regressions."""
from datetime import timedelta
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import Client, TestCase
from django.urls import reverse
from django.utils import timezone
from .models import AppNotification, Friendship, XPEvent
from .social_models import AvatarStyle, SocialGift


class SocialV9Tests(TestCase):
    def setUp(self):
        cache.clear()
        User=get_user_model()
        self.alice=User.objects.create_user(username='alice',email='private-alice@example.org')
        self.bob=User.objects.create_user(username='bob',email='private-bob@example.org')
        self.eve=User.objects.create_user(username='eve',email='private-eve@example.org')
        for user in [self.alice,self.bob,self.eve]:
            profile=user.learning_profile
            profile.social_opt_in=True
            profile.ui_language='en'
            profile.save(update_fields=['social_opt_in','ui_language'])
        self.client.force_login(self.alice)
        XPEvent.objects.create(user=self.alice,event_key='alice-earned',amount=20,reason='lesson')

    def connect(self,first=None,second=None):
        return Friendship.objects.create(from_user=first or self.alice,to_user=second or self.bob,status='accepted')

    def test_username_invite_and_friend_page_never_reveal_email(self):
        response=self.client.post(reverse('friends'),{'username':'@BOB'})
        self.assertEqual(response.status_code,302)
        relation=Friendship.objects.get(from_user=self.alice,to_user=self.bob)
        self.assertEqual(relation.status,'pending')
        self.client.force_login(self.bob)
        response=self.client.get(reverse('friends'))
        self.assertContains(response,'alice')
        self.assertNotContains(response,'private-alice@example.org')
        self.client.post(reverse('friend_action',args=[relation.pk,'accept']))
        relation.refresh_from_db()
        self.assertEqual(relation.status,'accepted')

    def test_reciprocal_invitation_does_not_create_duplicate_relationship(self):
        relation=Friendship.objects.create(from_user=self.bob,to_user=self.alice)
        self.client.post(reverse('friends'),{'username':'bob'})
        self.assertEqual(Friendship.objects.count(),1)
        self.assertEqual(Friendship.objects.get().pk,relation.pk)

    def test_gift_is_once_per_friend_daily_and_does_not_award_xp(self):
        self.connect()
        self.assertContains(self.client.get(reverse('friends')),'bob')
        before=XPEvent.objects.count()
        for kind in ['star','forest']:
            response=self.client.post(reverse('gifts_send',args=[self.bob.pk]),{'kind':kind})
            self.assertEqual(response.status_code,302)
        gift=SocialGift.objects.get()
        self.assertEqual(gift.kind,'star')
        self.assertEqual(AppNotification.objects.filter(user=self.bob).count(),1)
        self.assertEqual(XPEvent.objects.count(),before)
        self.assertEqual(self.bob.learning_profile.xp,0)

    def test_gift_to_stranger_or_self_is_forbidden(self):
        for target in [self.eve,self.alice]:
            response=self.client.post(reverse('gifts_send',args=[target.pk]),{'kind':'star'})
            self.assertEqual(response.status_code,403)
        self.assertFalse(SocialGift.objects.exists())

    def test_gifts_respect_opt_in_and_blocks(self):
        self.connect()
        profile=self.bob.learning_profile
        profile.social_opt_in=False
        profile.save(update_fields=['social_opt_in'])
        self.assertEqual(self.client.post(reverse('gifts_send',args=[self.bob.pk]),{'kind':'star'}).status_code,403)
        profile.social_opt_in=True
        profile.save(update_fields=['social_opt_in'])
        Friendship.objects.create(from_user=self.bob,to_user=self.alice,status='blocked')
        self.assertEqual(self.client.post(reverse('gifts_send',args=[self.bob.pk]),{'kind':'star'}).status_code,403)
        self.assertFalse(SocialGift.objects.exists())

    def test_chest_xp_is_not_eligible_for_gifting(self):
        self.connect()
        XPEvent.objects.filter(user=self.alice).update(reason='chest')
        self.client.post(reverse('gifts_send',args=[self.bob.pk]),{'kind':'star'})
        self.assertFalse(SocialGift.objects.exists())

    def test_five_gifts_daily_limit(self):
        User=get_user_model()
        for index in range(6):
            user=User.objects.create_user(username=f'friend{index}')
            profile=user.learning_profile
            profile.social_opt_in=True
            profile.save(update_fields=['social_opt_in'])
            self.connect(second=user)
            self.client.post(reverse('gifts_send',args=[user.pk]),{'kind':'forest'})
        self.assertEqual(SocialGift.objects.count(),5)

    def test_user_cannot_remove_or_replace_someone_elses_block(self):
        relation=Friendship.objects.create(from_user=self.bob,to_user=self.alice,status='blocked')
        self.assertEqual(self.client.post(reverse('friend_action',args=[relation.pk,'remove'])).status_code,403)
        self.client.post(reverse('friend_action',args=[relation.pk,'block']))
        relation.refresh_from_db()
        self.assertEqual(relation.status,'blocked')
        own=Friendship.objects.get(from_user=self.alice,to_user=self.bob)
        self.client.post(reverse('friend_action',args=[own.pk,'unblock']))
        self.client.post(reverse('friends'),{'username':'bob'})
        self.assertEqual(Friendship.objects.count(),1)
        self.assertEqual(Friendship.objects.get().pk,relation.pk)

    def test_foreign_user_cannot_accept_request(self):
        relation=Friendship.objects.create(from_user=self.bob,to_user=self.eve)
        self.assertEqual(self.client.post(reverse('friend_action',args=[relation.pk,'accept'])).status_code,403)
        relation.refresh_from_db()
        self.assertEqual(relation.status,'pending')

    def test_unknown_gift_and_get_requests_cannot_mutate(self):
        self.connect()
        route=reverse('gifts_send',args=[self.bob.pk])
        self.assertEqual(self.client.get(route).status_code,405)
        self.assertEqual(self.client.post(route,{'kind':'xp'}).status_code,400)
        self.assertFalse(SocialGift.objects.exists())

    def test_cosmetic_unlock_is_enforced_on_server(self):
        route=reverse('avatar_studio')
        self.client.post(route,{'avatar':'🚀','palette':'forest','accessory':'star'})
        style=AvatarStyle.objects.get(user=self.alice)
        self.assertEqual(style.palette,'sky')
        self.assertEqual(style.accessory,'none')
        SocialGift.objects.create(sender=self.bob,recipient=self.alice,kind='star')
        SocialGift.objects.create(sender=self.bob,recipient=self.alice,kind='forest',sent_day=timezone.localdate()-timedelta(days=1))
        self.client.post(route,{'avatar':'🚀','palette':'forest','accessory':'star'})
        style.refresh_from_db()
        self.alice.learning_profile.refresh_from_db()
        self.assertEqual((style.palette,style.accessory),('forest','star'))
        self.assertEqual(self.alice.learning_profile.avatar,'🚀')

    def test_sorani_ui_and_rtl(self):
        profile=self.alice.learning_profile
        profile.ui_language='ckb'
        profile.save(update_fields=['ui_language'])
        response=self.client.get(reverse('friends'))
        self.assertContains(response,'پێکەوە زیاتر فێر دەبین')
        self.assertContains(response,'dir="rtl"')
        self.assertEqual(self.client.get(reverse('avatar_studio')).status_code,200)

    def test_gift_requires_csrf(self):
        self.connect()
        client=Client(enforce_csrf_checks=True)
        client.force_login(self.alice)
        self.assertEqual(client.post(reverse('gifts_send',args=[self.bob.pk]),{'kind':'star'}).status_code,403)

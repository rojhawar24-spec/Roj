"""Complete, localized copy for the four-step Rozh onboarding experience."""

COPY = {
    'en': {
        'lang': 'en', 'direction': 'ltr', 'tagline': 'Your journey starts here',
        'step_label': 'Step {step} of 4', 'progress_label': 'Setup progress',
        'back': 'Back', 'continue': 'Continue', 'finish': 'Start learning',
        'skip': 'Use default', 'selected': 'Selected', 'choice_required': 'Choose an option to continue.',
        'course_unavailable': 'This course is no longer available. Choose an available course.',
        'placement_unavailable': 'The placement quiz is not available yet. You can start from the beginning.',
        'no_quiz': 'This course has no published entry quiz. Start at A0 and learn step by step.',
        'incomplete': 'Complete the previous questions first.',
        'subhead': 'A few simple choices. A path that feels like yours.',
        'questions': (
            ('What language should Rozh use?', 'Choose the language for Rozh menus and buttons. You will choose your learning language next.'),
            ('What would you like to learn?', 'This is the language you want to learn, not the language of the Rozh menus. Only published courses appear.'),
            ('Where would you like to begin?', 'Start at A0, or try a short quiz if this course has published questions.'),
            ('How much would you like to learn each day?', 'Choose a real daily XP target. Rozh saves it to your account and tracks your earned XP.'),
        ),
        'beginner': 'Start from the beginning', 'beginner_detail': 'Begin at A0 and learn step by step',
        'placement': 'Find my starting level', 'placement_detail': 'Optional estimate using published course questions (not a certified CEFR test)',
        'goals': (('Casual · 10 XP', 'Per day'), ('Regular · 20 XP', 'Per day'),
                  ('Serious · 35 XP', 'Per day'), ('Intense · 50 XP', 'Per day')),
        'ready_kicker': 'READY TO LEARN', 'ready_title': 'Your learning journey begins now.',
        'ready_body': 'Your choices are saved to your account. You can change them later in Settings.',
        'ready_level': 'First step', 'ready_goal': 'Daily goal', 'ready_course': 'Your course',
        'ready_placement': 'Start the entry quiz', 'ready_beginner': 'Go to Learn & Play',
        'no_courses': 'There are no published courses yet. Ask the manager to publish a course before continuing.',
        'learning_language': 'Language to learn',
    },
    'nl': {
        'lang': 'nl', 'direction': 'ltr', 'tagline': 'Hier begint jouw leerreis',
        'step_label': 'Stap {step} van 4', 'progress_label': 'Voortgang van je start',
        'back': 'Terug', 'continue': 'Verder', 'finish': 'Begin met leren',
        'skip': 'Standaard gebruiken', 'selected': 'Geselecteerd', 'choice_required': 'Kies een optie om verder te gaan.',
        'course_unavailable': 'Deze cursus is niet meer beschikbaar. Kies een andere cursus.',
        'placement_unavailable': 'De niveautest is nog niet beschikbaar. Je kunt bij het begin starten.',
        'no_quiz': 'Voor deze cursus is geen instapquiz gepubliceerd. Begin bij A0 en leer stap voor stap.',
        'incomplete': 'Beantwoord eerst de vorige vragen.',
        'subhead': 'Een paar eenvoudige keuzes. Een leerpad dat bij jou past.',
        'questions': (
            ('Welke taal moet Rozh gebruiken?', 'Kies de taal voor de menu’s en knoppen van Rozh. De taal die je leert kies je hierna.'),
            ('Welke taal wil je leren?', 'Dit is de taal die je wilt leren, niet de menutaal. Alleen gepubliceerde cursussen verschijnen.'),
            ('Waar wil je beginnen?', 'Begin bij A0 of doe een korte instapquiz als deze cursus vragen heeft.'),
            ('Hoeveel wil je elke dag leren?', 'Kies je echte dagelijkse XP-doel. Het wordt opgeslagen en telt verdiende XP mee.'),
        ),
        'beginner': 'Begin bij het begin', 'beginner_detail': 'Start op A0 en leer stap voor stap',
        'placement': 'Bepaal mijn startniveau', 'placement_detail': 'Korte inschatting met gepubliceerde vragen (geen erkende CEFR-test)',
        'goals': (('Rustig · 10 XP', 'Per dag'), ('Regelmatig · 20 XP', 'Per dag'),
                  ('Serieus · 35 XP', 'Per dag'), ('Intensief · 50 XP', 'Per dag')),
        'ready_kicker': 'KLAAR OM TE LEREN', 'ready_title': 'Jouw leerreis begint nu.',
        'ready_body': 'Je keuzes zijn opgeslagen in je account. Je kunt ze later wijzigen bij Instellingen.',
        'ready_level': 'Startniveau', 'ready_goal': 'Dagdoel', 'ready_course': 'Jouw cursus',
        'ready_placement': 'Start de instapquiz', 'ready_beginner': 'Ga naar Leer & Speel',
        'no_courses': 'Er zijn nog geen gepubliceerde cursussen. Vraag de manager een cursus te publiceren.',
        'learning_language': 'Leertaal',
    },
    'ckb': {
        'lang': 'ckb', 'direction': 'rtl', 'tagline': 'گەشتی فێربوونت لێرە دەست پێ دەکات',
        'step_label': 'هەنگاوی {step} لە ٤', 'progress_label': 'پێشکەوتنی دەستپێکردن',
        'back': 'گەڕانەوە', 'continue': 'بەردەوام بە', 'finish': 'دەست بە فێربوون بکە',
        'skip': 'هەڵبژاردەی بنەڕەتی', 'selected': 'هەڵبژێردراوە', 'choice_required': 'بۆ بەردەوامبوون هەڵبژاردەیەک دیاری بکە.',
        'course_unavailable': 'ئەم کۆرسە چیتر بەردەست نییە. کۆرسێکی تر هەڵبژێرە.',
        'placement_unavailable': 'تاقیکردنەوەی ئاست هێشتا بەردەست نییە. دەتوانیت لە سەرەتاوە دەست پێ بکەیت.',
        'no_quiz': 'بۆ ئەم کۆرسە تاقیکردنەوەی بڵاوکراوە نییە. لە A0 دەست پێ بکە.',
        'incomplete': 'سەرەتا وەڵامی پرسیارە پێشووترەکان بدەوە.',
        'subhead': 'چەند هەڵبژاردەیەکی ئاسان، گەشتێکی تایبەت بە تۆ.',
        'questions': (
            ('Rozh بە کام زمان بێت؟', 'زمانی مێنیو و دوگمەکانی Rozh هەڵبژێرە؛ زمانی فێربوون لە هەنگاوی داهاتوودا هەڵدەبژێریت.'),
            ('دەتەوێت کام زمان فێربیت؟', 'ئەمە زمانی فێربوونتە، نەک زمانی مێنیو. تەنها کۆرسە بڵاوکراوەکان نیشان دەدرێن.'),
            ('دەتەوێت لە کوێوە دەست پێ بکەیت؟', 'لە A0 دەست پێ بکە، یان ئەگەر پرسیاری بڵاوکراوە هەبوو تاقیکردنەوەی سەرەتایی بکە.'),
            ('هەموو ڕۆژێک چەند دەتەوێت فێربیت؟', 'ئامانجی XP ـی ڕۆژانە هەڵبژێرە؛ لە هەژمارەکەت پاشەکەوت دەبێت و XP ـی بەدەستهاتوو دەژمێرێت.'),
        ),
        'beginner': 'لە سەرەتاوە دەست پێ بکە', 'beginner_detail': 'لە A0 دەست پێ بکە و هەنگاو بە هەنگاو فێربە',
        'placement': 'ئاستی دەستپێکم بدۆزەوە', 'placement_detail': 'هەڵسەنگاندنێکی کورت بە پرسیاری بڵاوکراوە (نەک بڕوانامەی CEFR)',
        'goals': (('ئاسان · 10 XP', 'ڕۆژانە'), ('ئاسایی · 20 XP', 'ڕۆژانە'),
                  ('جدی · 35 XP', 'ڕۆژانە'), ('چڕ · 50 XP', 'ڕۆژانە')),
        'ready_kicker': 'ئامادەی فێربوونیت', 'ready_title': 'گەشتی فێربوونت ئێستا دەست پێ دەکات.',
        'ready_body': 'هەڵبژاردەکانت لە هەژمارەکەت پاشەکەوت کراون. دواتر دەتوانیت لە ڕێکخستنەکان بیگۆڕیت.',
        'ready_level': 'ئاستی دەستپێک', 'ready_goal': 'ئامانجی ڕۆژانە', 'ready_course': 'کۆرسەکەت',
        'ready_placement': 'تاقیکردنەوەی سەرەتایی دەست پێ بکە', 'ready_beginner': 'بڕۆ بۆ فێربە و یاری بکە',
        'no_courses': 'هێشتا هیچ کۆرسێکی بڵاوکراوە نییە. داوا لە بەڕێوەبەر بکە کۆرسێک بڵاو بکاتەوە.',
        'learning_language': 'زمانی فێربوون',
    },
    'ar': {
        'lang': 'ar', 'direction': 'rtl', 'tagline': 'رحلتك في التعلم تبدأ هنا',
        'step_label': 'الخطوة {step} من ٤', 'progress_label': 'تقدم الإعداد',
        'back': 'رجوع', 'continue': 'متابعة', 'finish': 'ابدأ التعلم',
        'skip': 'استخدم الخيار الافتراضي', 'selected': 'محدد', 'choice_required': 'اختر خيارًا للمتابعة.',
        'course_unavailable': 'هذه الدورة لم تعد متاحة. اختر دورة متاحة.',
        'placement_unavailable': 'اختبار المستوى غير متاح بعد. يمكنك البدء من البداية.',
        'no_quiz': 'لا توجد أسئلة اختبار تمهيدي منشورة لهذه الدورة. ابدأ من A0 خطوة بخطوة.',
        'incomplete': 'أكمل الأسئلة السابقة أولاً.',
        'subhead': 'بعض الخيارات البسيطة. مسار تعلم يناسبك.',
        'questions': (
            ('بأي لغة تريد استخدام Rozh؟', 'اختر لغة قوائم Rozh وأزراره. ستختار لغة التعلّم في الخطوة التالية.'),
            ('ما اللغة التي تريد تعلمها؟', 'هذه لغة التعلّم وليست لغة القوائم. تظهر الدورات المنشورة فقط.'),
            ('من أين تريد أن تبدأ؟', 'ابدأ من A0 أو جرّب اختبارًا تمهيديًا إذا كانت لهذه الدورة أسئلة منشورة.'),
            ('كم تريد أن تتعلم يوميًا؟', 'اختر هدف XP يوميًا حقيقيًا؛ يُحفظ في حسابك ويعتمد على النقاط المكتسبة.'),
        ),
        'beginner': 'ابدأ من البداية', 'beginner_detail': 'ابدأ من A0 وتعلم خطوة بخطوة',
        'placement': 'اعرف مستواي', 'placement_detail': 'تقدير أولي بأسئلة منشورة (ليس اختبار CEFR معتمدًا)',
        'goals': (('خفيف · 10 XP', 'يوميًا'), ('منتظم · 20 XP', 'يوميًا'),
                  ('جدي · 35 XP', 'يوميًا'), ('مكثف · 50 XP', 'يوميًا')),
        'ready_kicker': 'جاهز للتعلم', 'ready_title': 'رحلة التعلم تبدأ الآن.',
        'ready_body': 'حفظنا اختياراتك في حسابك. يمكنك تغييرها لاحقًا في الإعدادات.',
        'ready_level': 'نقطة البداية', 'ready_goal': 'الهدف اليومي', 'ready_course': 'دورتك',
        'ready_placement': 'ابدأ الاختبار التمهيدي', 'ready_beginner': 'انتقل إلى تعلم والعب',
        'no_courses': 'لا توجد دورات منشورة بعد. اطلب من المدير نشر دورة أولاً.',
        'learning_language': 'لغة التعلم',
    },
}

# Complete names for every app locale. Course codes are preserved from the database.
LANGUAGE_NAMES = {
    'en': {'nl': 'Dutch', 'en': 'English', 'de': 'German', 'fr': 'French'},
    'nl': {'nl': 'Nederlands', 'en': 'Engels', 'de': 'Duits', 'fr': 'Frans'},
    'ckb': {'nl': 'هۆڵەندی', 'en': 'ئینگلیزی', 'de': 'ئەڵمانی', 'fr': 'فەرەنسی'},
    'ar': {'nl': 'الهولندية', 'en': 'الإنجليزية', 'de': 'الألمانية', 'fr': 'الفرنسية'},
}

APP_LANGUAGES = [
    ('nl', 'Nederlands', 'NL'),
    ('en', 'English', 'EN'),
    ('ckb', 'کوردی (سۆرانی)', 'CKB'),
    ('ar', 'العربية', 'AR'),
]


def localized_copy(code):
    return COPY.get(code, COPY['en'])


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'onboarding_copy_v52', ['COPY'])


# V74: additive locale options. Course codes stay separate from app locale codes.
from .ui_languages_v74 import LANGUAGE_OPTIONS as _V74_OPTIONS
APP_LANGUAGES[:] = [(code, label + (' · Beta' if code in ('kmr','uk','fr','ku') else ''), short)
                   for code, label, short, direction, html in _V74_OPTIONS]
LANGUAGE_NAMES['fr']={'nl':'néerlandais','en':'anglais','de':'allemand','fr':'français'}
LANGUAGE_NAMES['uk']={'nl':'нідерландська','en':'англійська','de':'німецька','fr':'французька'}
LANGUAGE_NAMES['kmr']={'nl':'هۆڵەندی','en':'ئینگلیزی','de':'ئەڵمانی','fr':'فەڕەنسی'}
# The new onboarding copy is complete for the four-step wizard; deeper course content is separate.
COPY['fr'].update(dict(lang='fr',direction='ltr',tagline='Votre parcours commence ici',step_label='Étape {step} sur 4',progress_label='Progression de la configuration',back='Retour',continue_='Continuer',finish='Commencer à apprendre',skip='Utiliser le choix par défaut',selected='Sélectionné',choice_required='Choisissez une option pour continuer.',course_unavailable='Ce cours n’est plus disponible. Choisissez-en un autre.',placement_unavailable='Le test de niveau n’est pas encore disponible. Commencez au début.',no_quiz='Aucun test d’entrée publié. Commencez à A0 et progressez pas à pas.',incomplete='Terminez d’abord les questions précédentes.',subhead='Quelques choix simples pour un parcours personnalisé.',questions=(('Dans quelle langue utiliser Rozh ?', 'Choisissez la langue des menus et des boutons. La langue étudiée vient ensuite.'),('Quelle langue voulez-vous apprendre ?', 'Choisissez la langue à apprendre. Seuls les cours publiés sont affichés.'),('Où voulez-vous commencer ?', 'Commencez en A0 ou passez un court test si disponible.'),('Combien voulez-vous apprendre chaque jour ?', 'Choisissez un objectif quotidien en XP.')),beginner='Commencer au début',beginner_detail='Commencer en A0, étape par étape',placement='Trouver mon niveau',placement_detail='Estimation facultative, pas un test CEFR certifié',goals=(('Facile · 10 XP','par jour'),('Normal · 20 XP','par jour'),('Sérieux · 35 XP','par jour'),('Intensif · 50 XP','par jour')),ready_kicker='PRÊT À APPRENDRE',ready_title='Votre parcours commence maintenant.',ready_body='Vos choix sont enregistrés dans votre compte.',ready_level='Premier niveau',ready_goal='Objectif quotidien',ready_course='Votre cours',ready_placement='Passer le test d’entrée',ready_beginner='Aller à Apprendre et jouer',no_courses='Aucun cours publié. Demandez au gestionnaire de publier un cours.',learning_language="Langue d’apprentissage"))
COPY['uk'].update(dict(lang='uk',direction='ltr',tagline='Твій шлях починається тут',step_label='Крок {step} з 4',progress_label='Прогрес налаштування',back='Назад',continue_='Продовжити',finish='Почати навчання',skip='Використати типовий вибір',selected='Вибрано',choice_required='Вибери варіант для продовження.',course_unavailable='Цей курс недоступний. Вибери інший.',placement_unavailable='Тест рівня поки недоступний. Почни з початку.',no_quiz='Вступний тест не опубліковано. Почни з A0.',incomplete='Спочатку заверши попередні питання.',subhead='Кілька простих виборів — і твій шлях готовий.',questions=(('Якою мовою має бути Rozh?', 'Вибери мову меню й кнопок. Мову навчання обереш далі.'),('Яку мову хочеш вивчати?', 'Вибери мову для навчання. Доступні лише опубліковані курси.'),('З чого хочеш почати?', 'Почни з A0 або пройди короткий тест, якщо він є.'),('Скільки хочеш навчатися щодня?', 'Обери справжню щоденну мету в XP.')),beginner='Почати з початку',beginner_detail='Почати з A0 крок за кроком',placement='Визначити мій рівень',placement_detail='Необов’язкова оцінка, не офіційний тест CEFR',goals=(('Легко · 10 XP','щодня'),('Звично · 20 XP','щодня'),('Серйозно · 35 XP','щодня'),('Інтенсивно · 50 XP','щодня')),ready_kicker='ГОТОВИЙ НАВЧАТИСЯ',ready_title='Твоя подорож починається зараз.',ready_body='Вибір збережено у твоєму акаунті.',ready_level='Перший крок',ready_goal='Щоденна мета',ready_course='Твій курс',ready_placement='Пройти вступний тест',ready_beginner='До навчання',no_courses='Опублікованих курсів немає. Попроси менеджера додати курс.',learning_language='Мова навчання'))
COPY['kmr'].update(dict(lang='kmr',direction='rtl',tagline='گەشتا فێربوونا تە ل ڤێرێ دەست پێ دکەت',step_label='هەنگاڤ {step} ژ 4',progress_label='پێشکەڤتنا ڕێکخستنێ',back='زڤڕین',continue_='بەردەوام بە',finish='دەست ب فێربوونێ بکە',skip='هەلبژاردنا بنەڕەتی',selected='هەلبژارتی',choice_required='بۆ بەردەوامبوونێ هەلبژاردەکێ هەلبژێرە.',course_unavailable='ئەڤ کۆرس نەما. کۆرسەکێ دی هەلبژێرە.',placement_unavailable='تاقیکرنا ئاستێ هێشتا نیە. ژ دەستپێکێ دەست پێ بکە.',no_quiz='تاقیکرنا دەستپێکێ بڵاو نەبوویە. ژ A0 دەست پێ بکە.',incomplete='سەرەتا پرسیارێن پێشووتر تەواو بکە.',subhead='هەندەک هەلبژاردنێن سادە بۆ ڕێکا فێربوونا تە.',questions=(('Rozh ب کام زمانێ بیت؟','زمانێ مێنیو و دوگمەیان هەلبژێرە. زمانی فێربوونێ پاشتر هەلدبژێری.'),('تۆ دڤێت کام زمانێ فێربی؟','زمانێ کۆرسێ هەلبژێرە. تەنها کۆرسێن بڵاوکری دیار دبن.'),('دڤێت ژ کیرێ دەست پێ بکەی؟','ژ A0 دەست پێ بکە یان تاقیکرنا کورت بکە.'),('هەر ڕۆژ چەند دڤێت فێربی؟','ئارمانجا XP یا ڕۆژانە هەلبژێرە.')),beginner='ژ دەستپێکێ دەست پێ بکە',beginner_detail='ژ A0 هەنگاڤ ب هەنگاڤ',placement='ئاستێ من بدۆزە',placement_detail='هەلسەنگاندنا ئارەزوومەندانە، نەک تاقیکرنا فەرمی یا CEFR',goals=(('کێم · 10 XP','هەر ڕۆژ'),('ئاسایی · 20 XP','هەر ڕۆژ'),('جدی · 35 XP','هەر ڕۆژ'),('زۆر · 50 XP','هەر ڕۆژ')),ready_kicker='ئامادەی فێربوونێ',ready_title='گەشتا فێربوونا تە نوکە دەست پێ دکەت.',ready_body='هەلبژاردنێن تە ل ئەکاونتێ هاتنە پاراستن.',ready_level='ئاستا دەستپێکێ',ready_goal='ئارمانجا ڕۆژانە',ready_course='کۆرسا تە',ready_placement='تاقیکرنا دەستپێکێ',ready_beginner='بڕۆ بۆ فێربە و یاری بکە',no_courses='هێشتا کۆرسێن بڵاوکری نینن. ژ بەڕێڤەبەری بخوازە کۆرس بڵاو بکەت.',learning_language='زمانێ فێربوونێ'))

for _v74_code in ("fr", "uk", "kmr"):
    COPY[_v74_code]["continue"] = COPY[_v74_code].pop("continue_")

# V76: three Kurdish writing/variety options; new Latin Kurmanji beta interface.
LANGUAGE_NAMES['ku'] = {'nl':'Holandî','en':'Îngilîzî','de':'Almanî','fr':'Fransî'}
COPY['ku'].update(dict(
    lang='ku', direction='ltr', tagline='Rêwîtiya fêrbûnê li vir dest pê dike',
    step_label='Gav {step} ji 4', progress_label='Pêşveçûna sazkirinê', back='Vegere',
    continue_='Bidomîne', finish='Dest bi fêrbûnê bike', skip='Vebijarka bingehîn',
    selected='Hilbijartî', choice_required='Ji bo berdewamkirinê vebijarkek hilbijêre.',
    course_unavailable='Ev kurs êdî tune ye. Kursekî din hilbijêre.',
    placement_unavailable='Testa destpêkê niha amade nîne. Ji A0 dest pê bike.',
    no_quiz='Testa asta destpêkê nehatiye weşandin. Ji A0 dest pê bike.',
    incomplete='Pêşî gavên berê biqedîne.', subhead='Çend hilbijartin ji bo rêya te.',
    questions=(('Rozh bi kîjan zimanî be?', 'Zimanê menû û bişkokan hilbijêre. Zimanê fêrbûnê paşê hilbijêrî.'),
               ('Tu dixwazî kîjan zimanî fêr bibî?', 'Kursa xwe hilbijêre; tenê kursên weşandî xuya dibin.'),
               ('Tu dixwazî ji ku dest pê bikî?', 'Ji A0 dest pê bike an testa asta destpêkê bike, heke hebe.'),
               ('Tu her roj çiqas dixwazî fêr bibî?', 'Armanca XP ya rojane hilbijêre.')),
    beginner='Ji destpêkê dest pê bike', beginner_detail='Ji A0, gav bi gav',
    placement='Asta min bibîne', placement_detail='Texmîna dilxwaz, ne testa fermî ya CEFR',
    goals=(('Hêsan · 10 XP','Her roj'),('Normal · 20 XP','Her roj'),('Zêde · 35 XP','Her roj'),('Berfireh · 50 XP','Her roj')),
    ready_kicker='AMADÊ FÊRBÛNÊ', ready_title='Rêwîtiya te niha dest pê dike.',
    ready_body='Hilbijartinên te di hesabê te de hatin tomarkirin.',
    ready_level='Asta destpêkê', ready_goal='Armanca rojane', ready_course='Kursa te',
    ready_placement='Testa destpêkê bike', ready_beginner='Biçe Fêr bibe û bilîze',
    no_courses='Hêj kursên weşandî tune ne. Ji rêveber bixwaze ku kursek weşîne.',
    learning_language='Zimanê fêrbûnê'
))
COPY['ku']['continue'] = COPY['ku'].pop('continue_')

# Labels for the grouping are localized independently of the stored locale code.
KURDISH_SELECTOR_LABELS = {
 'en':('Kurdish', 'Choose Sorani, Badini or Kurmanji', 'Choose a Kurdish variety', 'Beta'),
 'nl':('Koerdisch', 'Kies Sorani, Badini of Kurmanji', 'Kies een Koerdische variant', 'Beta'),
 'ckb':('کوردی', 'سۆرانی، بادینی یان کورمانجی هەڵبژێرە', 'شێوەزارێکی کوردی هەڵبژێرە', 'تاقیکردنەوە'),
 'kmr':('کوردی', 'سۆرانی، بادینی یان کورمانجی هەلبژێرە', 'شێوازێ کوردی هەلبژێرە', 'Beta'),
 'ar':('الكردية', 'اختر السورانية أو البادينية أو الكرمانجية', 'اختر نوع اللغة الكردية', 'تجريبي'),
 'fr':('Kurde', 'Choisissez sorani, badini ou kurmanji', 'Choisissez une variété du kurde', 'Bêta'),
 'uk':('Курдська', 'Оберіть сорані, бадіні або курманджі', 'Оберіть різновид курдської', 'Бета'),
 'ku':('Kurdî', 'Soranî, Badînî an Kurmancî hilbijêre', 'Zaraveyekî Kurdî hilbijêre', 'Beta'),
}


# V77: onboarding only offers the 15-question assessment when a truly vetted
# bank with all skills, levels and listening audio exists. Never suggest that
# an old collection of 2 MCQs per level meets this requirement.
PLACEMENT_LABELS_V77 = {
 'en': '15 adaptive questions with teacher-reviewed reading, listening, grammar, vocabulary and controlled writing. Indicative only, not a CEFR certificate.',
 'nl': '15 adaptieve vragen over lezen, luisteren, grammatica, woordenschat en kort schrijven, gecontroleerd door docenten. Indicatief, geen ERK-certificaat.',
 'ckb': '١٥ پرسیاری گۆڕاو لە خوێندنەوە، گوێگرتن، گرامەر، وشە و نووسینی کورت؛ پشکنراو لەلایەن مامۆستا. تەنها پێشبینییە، نە بڕوانامە.',
 'ar': '١٥ سؤالاً متكيفاً في القراءة والاستماع والقواعد والمفردات والكتابة القصيرة، يراجعها مدرسون. تقدير غير معتمد.',
 'fr': '15 questions adaptatives révisées par des enseignants, sur cinq compétences. Estimation indicative, non certifiée.',
 'uk': '15 адаптивних завдань, перевірених викладачами, з п’яти навичок. Орієнтовна оцінка, не сертифікат.',
 'kmr': '١٥ پرسیارێن گۆڕاو بۆ پێشبینیکرنا ئاستێ، پشکنین ژ لایێ مامۆستایان. نە بڕوانامەیا فەرمی.',
 'ku': '15 pirsên adapteyî yên ji aliyê mamosteyan ve hatine kontrolkirin. Tenê texmîn, ne sertîfîkayek fermî.',
}
for _code, _label in PLACEMENT_LABELS_V77.items():
    COPY[_code]['placement_detail'] = _label

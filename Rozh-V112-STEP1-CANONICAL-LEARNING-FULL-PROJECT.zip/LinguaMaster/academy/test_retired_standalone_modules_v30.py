"""Contract: stand-alone speaking, writing and vocabulary are retired.

We keep Vocabulary records and legacy Lesson data for daily words, mistakes,
progress and account exports. No schema migration or data deletion is needed.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse


class StandaloneModulesRetirementTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username='retirement-regression', password='A-secure-test-password-2026!'
        )
        self.user.learning_profile.placement_completed = True
        self.user.learning_profile.save(update_fields=['placement_completed'])
        self.client.force_login(self.user)

    def test_old_vocab_library_bookmarks_go_to_practice(self):
        response = self.client.get(reverse('vocabulary'))
        self.assertRedirects(response, reverse('practice_hub'))

    def test_old_vocab_save_cannot_mutate_review_cards(self):
        response = self.client.post(reverse('vocabulary_save', args=(1,)))
        self.assertEqual(response.status_code, 410)

    def test_removed_skill_pages_are_not_exposed(self):
        for skill in ('speaking', 'writing'):
            with self.subTest(skill=skill):
                self.assertEqual(self.client.get(reverse('skill_practice', args=(skill,))).status_code, 404)
                self.assertEqual(self.client.post(reverse('skill_practice', args=(skill,)), {'answer':'sample'}).status_code, 404)

    def test_listening_route_kept(self):
        self.assertEqual(self.client.get(reverse('skill_practice', args=('listening',))).status_code, 200)

"""V23 integration tests for direct lesson and level-exam URLs.

Django TestCase uses an isolated TEST database; run using TEST-ROZH-STAP10.ps1.
These tests are not asserted to pass until they have been run with Django.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Assessment, Certificate, Exercise, Language, Lesson, LessonProgress, Level, Unit, XPEvent
from .services import allowed_unit


class DirectRouteCourseGateV23Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            'v23_direct_learner', 'v23-user@example.invalid', 'V23-Local-Test-Only-2026!')
        cls.dutch = Language.objects.create(code='nl', name='Dutch', slug='v23-dutch', is_published=True)
        cls.english = Language.objects.create(code='en', name='English', slug='v23-english', is_published=True)
        cls.nl_level = Level.objects.create(language=cls.dutch, code='A0', order=0)
        cls.en_level = Level.objects.create(language=cls.english, code='A0', order=0)
        cls.nl_unit = Unit.objects.create(level=cls.nl_level, slug='v23-intro', title='V23 Dutch unit',
                                          summary='V23', order=1, published=True)
        cls.en_unit = Unit.objects.create(level=cls.en_level, slug='v23-intro', title='V23 English unit',
                                          summary='V23', order=1, published=True)
        cls.lesson = Lesson.objects.create(unit=cls.nl_unit, slug='v23-lesson', title='V23 Dutch lesson',
                                           skill='grammar', content='V23 text', order=1, published=True)
        cls.question = Exercise.objects.create(lesson=cls.lesson, kind='mcq', prompt='A question',
                                               options=['Yes', 'No'], answer='Yes', explanation='Yes')
        profile = cls.user.learning_profile
        profile.preferred_language = cls.dutch
        profile.placement_completed = True
        profile.onboarding_required = False
        profile.onboarding_completed = True
        profile.save(update_fields=['preferred_language', 'placement_completed',
                                    'onboarding_required', 'onboarding_completed'])

    def setUp(self):
        self.client.force_login(self.user)

    def _update_profile(self, **kwargs):
        profile = self.user.learning_profile
        for name, value in kwargs.items():
            setattr(profile, name, value)
        profile.save(update_fields=list(kwargs))

    def _counts(self):
        return (XPEvent.objects.count(), LessonProgress.objects.count(),
                Assessment.objects.count(), Certificate.objects.count())

    def test_unfinished_onboarding_denies_direct_lesson_and_unit_gets(self):
        self._update_profile(onboarding_required=True, onboarding_completed=False)
        before = self._counts()
        for route, pk in [('unit', self.nl_unit.pk), ('lesson', self.lesson.pk),
                          ('journey_play', self.nl_unit.pk)]:
            with self.subTest(route=route):
                self.assertRedirects(self.client.get(reverse(route, args=[pk])),
                                     reverse('onboarding'), fetch_redirect_response=False)
        self.assertFalse(allowed_unit(self.user, self.nl_unit))
        self.assertEqual(self._counts(), before)

    def test_unfinished_onboarding_denies_api_answer_and_both_assessments(self):
        self._update_profile(onboarding_required=True, onboarding_completed=False)
        before = self._counts()
        self.assertEqual(self.client.post(reverse('lesson_answer', args=[self.lesson.pk]), {
            'exercise_id': self.question.pk, 'answer': 'Yes',
        }).status_code, 403)
        self.assertEqual(self.client.post(reverse('assessment_unit', args=[self.nl_unit.pk]), {
            f'q_{self.question.pk}': 'Yes',
        }).status_code, 403)
        self.assertEqual(self.client.post(reverse('assessment_level', args=[self.nl_level.pk]), {
            f'q_{self.question.pk}': 'Yes',
        }).status_code, 403)
        self.assertEqual(self.client.post(reverse('journey_answer', args=[self.nl_unit.pk]), {
            'answer': 'Yes',
        }).status_code, 403)
        self.assertEqual(self._counts(), before)

    def test_past_unit_pass_cannot_issue_certificate_in_another_course(self):
        Assessment.objects.create(user=self.user, kind='unit', unit=self.nl_unit,
                                  passed=True, score=100)
        self._update_profile(preferred_language=self.english)
        before = self._counts()
        self.assertEqual(self.client.get(reverse('assessment_level', args=[self.nl_level.pk])).status_code, 403)
        self.assertEqual(self.client.post(reverse('assessment_level', args=[self.nl_level.pk]), {
            f'q_{self.question.pk}': 'Yes',
        }).status_code, 403)
        self.assertEqual(self._counts(), before)

    def test_placement_must_be_done_for_a_level_certificate(self):
        Assessment.objects.create(user=self.user, kind='unit', unit=self.nl_unit,
                                  passed=True, score=100)
        self._update_profile(placement_completed=False)
        before = self._counts()
        self.assertEqual(self.client.post(reverse('assessment_level', args=[self.nl_level.pk]), {
            f'q_{self.question.pk}': 'Yes',
        }).status_code, 403)
        self.assertEqual(self._counts(), before)

    def test_completed_onboarding_does_not_block_active_course(self):
        self.assertTrue(allowed_unit(self.user, self.nl_unit))
        self.assertEqual(self.client.get(reverse('unit', args=[self.nl_unit.pk])).status_code, 200)
        self.assertEqual(self.client.get(reverse('lesson', args=[self.lesson.pk])).status_code, 200)
        self.assertEqual(self.client.get(reverse('journey_play', args=[self.nl_unit.pk])).status_code, 200)

    def test_legacy_account_without_required_flag_is_not_reonboarded(self):
        self._update_profile(onboarding_required=False, onboarding_completed=False)
        self.assertTrue(allowed_unit(self.user, self.nl_unit))
        self.assertEqual(self.client.get(reverse('unit', args=[self.nl_unit.pk])).status_code, 200)
        self.assertEqual(self.client.get(reverse('lesson', args=[self.lesson.pk])).status_code, 200)

    def test_selected_course_with_passed_unit_still_opens_level_exam(self):
        Assessment.objects.create(user=self.user, kind='unit', unit=self.nl_unit,
                                  passed=True, score=100)
        self.assertEqual(self.client.get(reverse('assessment_level', args=[self.nl_level.pk])).status_code, 200)

    def test_anonymous_direct_lesson_still_redirects_to_login(self):
        self.client.logout()
        for route, pk in [('unit', self.nl_unit.pk), ('lesson', self.lesson.pk),
                          ('assessment_level', self.nl_level.pk)]:
            with self.subTest(route=route):
                response = self.client.get(reverse(route, args=[pk]))
                self.assertEqual(response.status_code, 302)
                self.assertTrue(response['Location'].startswith(reverse('login')))

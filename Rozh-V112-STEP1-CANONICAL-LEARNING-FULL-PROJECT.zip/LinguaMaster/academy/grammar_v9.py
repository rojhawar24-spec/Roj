"""Course-aware grammar discovery, spaced quick checks and useful mistake feedback."""
from datetime import timedelta

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from django.db import transaction
from django.db.models import Q
from django.core.paginator import Paginator
from django.core.exceptions import ObjectDoesNotExist, ValidationError
from django.http import HttpResponse, HttpResponseBadRequest
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import path
from django.utils import timezone

from .grammar_models import GrammarMastery
from .rich_schema import normalize_article
from .grammar_visual_labels_v17 import VISUAL_LABELS
from .grammar_components_v57 import VISUAL_COMPONENT_TYPES, COMPONENT_LABELS, COMPONENT_CATEGORIES
from .models import GrammarTopic, Language, MistakeRecord, Profile
from .mistake_policy_v35 import mistake_retry_allowed
from .account_signin_policy_v27 import account_signin_permitted
from .services import award_xp, grade, rate_limit, record_exercise_result, user_localdate

LEVELS = ['A0', 'A1', 'A2', 'B1', 'B2', 'C1']

LABELS = {
 'en': dict(kicker='YOUR LANGUAGE TOOLBOX', title='Understand the rule. Find your voice.', intro='Clear explanations, real examples and a little practice every day.', search='Find a grammar topic', all_levels='All levels', all_status='All progress', filter='Find topics', reset='Reset', topics='Topics', remembered='Remembered', review_due='Due for review', new='New', practising='Practising', mastered='Remembered', no_topics='No topics match your filters.', no_topics_help='Try another word or level. New content appears when your teacher publishes it.', open='Explore the rule', back='Grammar library', explanation='The idea', examples='See it in action', exceptions='Exceptions & special cases', common_mistakes='Watch out for these mistakes', check='Your quick check', check_intro='Try to recall the rule before looking back at the examples.', check_answer='Check my answer', correct='Correct. Well done!', incorrect='Not quite. Here is why:', correct_answer='The correct answer', progress='Your recall', progress_note='Recall this quick check correctly on three different days. This tracks practice, not your CEFR level.', successful_days='successful review days', sign_in='Sign in to save your progress', repeat='Practice again', listen='Listen to an example', scheduled='Next review', no_check='Your teacher is preparing this quick check.', mistakes_title='Every mistake is a next step.', mistakes_intro='Understand what happened, then try again. Your active course only.', pending='To practise', resolved='Corrected', attempts='Times missed', why='Why this answer works', related='Review the related grammar', lesson='Back to the lesson', all_repaired='A fresh start!', all_repaired_help='No open mistakes in this course. Continue your learning path.', continue_learning='Continue learning', repaired='Mistake corrected! Your first correction earns 5 XP.', retry='Try again. Read the explanation below.', saved='Your practice was saved.', practice='MISTAKE PRACTICE', course='Course', content_note='Published learning material · A0–C1 content is still growing.', due='Review now', no_course='Choose a published course to start.', summary='Quick check progress', same_day='One successful review day is counted per day.'),
 'nl': dict(kicker='JOUW TAALGEREEDSCHAP', title='Begrijp de regel. Vind je woorden.', intro='Heldere uitleg, echte voorbeelden en elke dag een beetje oefenen.', search='Zoek een grammaticaonderwerp', all_levels='Alle niveaus', all_status='Alle voortgang', filter='Zoek onderwerpen', reset='Wissen', topics='Onderwerpen', remembered='Onthouden', review_due='Tijd om te herhalen', new='Nieuw', practising='Aan het oefenen', mastered='Onthouden', no_topics='Geen onderwerpen met deze filters.', no_topics_help='Probeer een ander woord of niveau. Nieuwe inhoud verschijnt na publicatie.', open='Ontdek de regel', back='Grammaticabibliotheek', explanation='De uitleg', examples='Zo gebruik je het', exceptions='Uitzonderingen en bijzondere gevallen', common_mistakes='Let op deze fouten', check='Jouw korte oefening', check_intro='Probeer de regel te herinneren voordat je de voorbeelden terugleest.', check_answer='Controleer mijn antwoord', correct='Goed! Mooi gedaan.', incorrect='Nog niet helemaal. Dit is waarom:', correct_answer='Het juiste antwoord', progress='Wat je onthoudt', progress_note='Beantwoord deze korte oefening goed op drie verschillende dagen. Dit meet oefening, niet je ERK-niveau.', successful_days='geslaagde herhaaldagen', sign_in='Log in om je voortgang te bewaren', repeat='Opnieuw oefenen', listen='Luister naar een voorbeeld', scheduled='Volgende herhaling', no_check='Je docent bereidt deze oefening voor.', mistakes_title='Elke fout is een volgende stap.', mistakes_intro='Begrijp wat er gebeurde en probeer opnieuw. Alleen je actieve cursus.', pending='Om te oefenen', resolved='Verbeterd', attempts='Keer gemist', why='Waarom dit antwoord klopt', related='Bekijk de bijbehorende grammatica', lesson='Terug naar de les', all_repaired='Een frisse start!', all_repaired_help='Geen openstaande fouten in deze cursus. Ga verder met je leerpad.', continue_learning='Verder leren', repaired='Fout verbeterd! De eerste verbetering levert 5 XP op.', retry='Probeer opnieuw. Lees hieronder de uitleg.', saved='Je oefening is opgeslagen.', practice='FOUTEN OEFENEN', course='Cursus', content_note='Gepubliceerde leerstof · De inhoud voor A0–C1 groeit nog.', due='Nu herhalen', no_course='Kies een gepubliceerde cursus om te beginnen.', summary='Voortgang korte oefeningen', same_day='Per dag telt maximaal één geslaagde herhaaldag.'),
 'ckb': dict(kicker='ئامرازەکانی فێربوونی زمان', title='ڕێساکە تێبگە. بە دڵنیایی قسە بکە.', intro='ڕوونکردنەوەی ئاسان، نموونەی ڕاستەقینە و ڕاهێنانی ڕۆژانە.', search='گەڕان بۆ بابەتی ڕێزمان', all_levels='هەموو ئاستەکان', all_status='هەموو پێشکەوتنەکان', filter='بابەت بدۆزەوە', reset='پاککردنەوە', topics='بابەتەکان', remembered='لەبیرماو', review_due='کاتی پێداچوونەوە', new='نوێ', practising='لە ڕاهێناندایە', mastered='لەبیرماو', no_topics='هیچ بابەتێک لەگەڵ فلتەرەکان ناگونجێت.', no_topics_help='وشە یان ئاستێکی تر تاقی بکەوە. ناوەڕۆکی نوێ دوای بڵاوکردنەوە دەردەکەوێت.', open='ڕێساکە ببینە', back='کتێبخانەی ڕێزمان', explanation='ڕوونکردنەوە', examples='نموونەی بەکارهێنان', exceptions='حاڵەتە تایبەتەکان', common_mistakes='ئاگاداری ئەم هەڵانە بە', check='ڕاهێنانی کورت', check_intro='پێش گەڕانەوە بۆ نموونەکان، هەوڵ بدە ڕێساکە لەبیر بهێنیتەوە.', check_answer='وەڵامەکەم بپشکنە', correct='دروستە، ئافەرین!', incorrect='هێشتا دروست نییە. ئەمە هۆکارەکەیە:', correct_answer='وەڵامی دروست', progress='ئەوەی لەبیرت ماوە', progress_note='لەم ڕاهێنانە لە سێ ڕۆژی جیاواز وەڵامی دروست بدەوە. ئەمە ڕاهێنان دەپێوێت، نە ئاستی CEFR.', successful_days='ڕۆژی پێداچوونەوەی سەرکەوتوو', sign_in='بچۆ ژوورەوە بۆ پاشەکەوتکردنی پێشکەوتنت', repeat='دووبارە ڕاهێنان بکە', listen='گوێ لە نموونەیەک بگرە', scheduled='پێداچوونەوەی داهاتوو', no_check='مامۆستاکەت ئەم ڕاهێنانە ئامادە دەکات.', mistakes_title='هەر هەڵەیەک هەنگاوێکە بۆ پێشەوە.', mistakes_intro='هۆکارەکە تێبگە و دووبارە هەوڵ بدە. تەنها کۆرسی چالاکت.', pending='بۆ ڕاهێنان', resolved='چاککراوە', attempts='ژمارەی هەڵەکان', why='بۆچی ئەم وەڵامە دروستە', related='ڕێزمانی پەیوەندیدار ببینە', lesson='گەڕانەوە بۆ وانە', all_repaired='دەستپێکردنەوەیەکی نوێ!', all_repaired_help='هیچ هەڵەیەکی چاکنەکراو لەم کۆرسە نییە. فێربوون بەردەوام بکە.', continue_learning='بەردەوام بە لە فێربوون', repaired='هەڵەکە چاککرایەوە! یەکەم چاککردنەوە ٥ XP دەبەخشێت.', retry='دووبارە هەوڵ بدە. ڕوونکردنەوەکەی خوارەوە بخوێنەوە.', saved='ڕاهێنانەکەت پاشەکەوت کرا.', practice='ڕاهێنان لەسەر هەڵەکان', course='کۆرس', content_note='ناوەڕۆکی بڵاوکراوە · ناوەڕۆکی A0–C1 هێشتا پەرە دەسێنێت.', due='ئێستا پێداچوونەوە بکە', no_course='کۆرسێکی بڵاوکراوە هەڵبژێرە بۆ دەستپێکردن.', summary='پێشکەوتنی ڕاهێنانە کورتەکان', same_day='لە هەر ڕۆژێکدا تەنها یەک ڕۆژی سەرکەوتوو هەژمار دەکرێت.'),
 'ar': dict(kicker='أدواتك اللغوية', title='افهم القاعدة. عبّر بثقة.', intro='شرح واضح وأمثلة واقعية وقليل من التدريب كل يوم.', search='ابحث عن موضوع في القواعد', all_levels='جميع المستويات', all_status='كل التقدم', filter='ابحث عن المواضيع', reset='مسح', topics='المواضيع', remembered='متذكّر', review_due='حان وقت المراجعة', new='جديد', practising='قيد التدريب', mastered='متذكّر', no_topics='لا توجد مواضيع تطابق البحث.', no_topics_help='جرّب كلمة أو مستوى آخر. تظهر مواد جديدة بعد نشرها.', open='اكتشف القاعدة', back='مكتبة القواعد', explanation='الفكرة', examples='أمثلة عملية', exceptions='الاستثناءات والحالات الخاصة', common_mistakes='انتبه لهذه الأخطاء', check='تدريبك القصير', check_intro='حاول تذكّر القاعدة قبل العودة إلى الأمثلة.', check_answer='تحقق من إجابتي', correct='صحيح، أحسنت!', incorrect='ليست صحيحة بعد. إليك السبب:', correct_answer='الإجابة الصحيحة', progress='ما تتذكره', progress_note='أجب بشكل صحيح في ثلاثة أيام مختلفة. هذا يتتبع التدريب وليس مستوى CEFR.', successful_days='أيام مراجعة ناجحة', sign_in='سجّل الدخول لحفظ تقدمك', repeat='تدرّب مجددًا', listen='استمع إلى مثال', scheduled='المراجعة التالية', no_check='يعدّ معلمك هذا التدريب.', mistakes_title='كل خطأ خطوة إلى الأمام.', mistakes_intro='افهم السبب ثم حاول مجددًا. لدورتك الحالية فقط.', pending='للتدريب', resolved='تم التصحيح', attempts='مرات الخطأ', why='لماذا هذه الإجابة صحيحة', related='راجع القاعدة المرتبطة', lesson='العودة إلى الدرس', all_repaired='بداية جديدة!', all_repaired_help='لا توجد أخطاء مفتوحة في هذه الدورة. تابع مسار التعلم.', continue_learning='تابع التعلم', repaired='تم التصحيح! أول تصحيح يمنحك 5 XP.', retry='حاول مجددًا. اقرأ الشرح أدناه.', saved='تم حفظ التدريب.', practice='التدريب على الأخطاء', course='الدورة', content_note='مواد تعليمية منشورة · محتوى A0–C1 ما زال يتوسع.', due='راجع الآن', no_course='اختر دورة منشورة للبدء.', summary='تقدم التدريبات القصيرة', same_day='يُحتسب يوم مراجعة ناجح واحد فقط يوميًا.'),
}

RICH_LABELS = {
 'en': {'contents': 'IN THIS GUIDE', 'goals': 'After this guide, you can…', 'deep_dive': 'Understand it step by step', 'rule_tables': 'The rule at a glance', 'patterns': 'Build the sentence', 'patterns_note': 'Each part has a job. The labels explain the colours.', 'worked_examples': 'From rule to real life', 'traps': 'Small changes. Clearer sentences.', 'wrong': 'Instead of', 'right': 'Say', 'translation': 'Meaning', 'table_hint': 'Scroll the table horizontally on smaller screens.', 'rich_guide': 'Visual guide', 'read_guide': 'Read the guide', 'role_subject': 'Subject', 'role_verb': 'Verb', 'role_object': 'Object', 'role_time': 'Time', 'role_place': 'Place', 'role_connector': 'Connector', 'role_other': 'Other', 'jump_check': 'Try the quick check'},
 'nl': {'contents': 'IN DEZE UITLEG', 'goals': 'Na deze uitleg kun je…', 'deep_dive': 'Stap voor stap begrijpen', 'rule_tables': 'De regel in één overzicht', 'patterns': 'Bouw de zin', 'patterns_note': 'Elk deel heeft een taak. De labels leggen de kleuren uit.', 'worked_examples': 'Van regel naar dagelijks gebruik', 'traps': 'Kleine wijzigingen. Duidelijkere zinnen.', 'wrong': 'In plaats van', 'right': 'Zeg', 'translation': 'Betekenis', 'table_hint': 'Schuif de tabel op een klein scherm horizontaal.', 'rich_guide': 'Visuele uitleg', 'read_guide': 'Lees de uitleg', 'role_subject': 'Onderwerp', 'role_verb': 'Werkwoord', 'role_object': 'Voorwerp', 'role_time': 'Tijd', 'role_place': 'Plaats', 'role_connector': 'Verbindingswoord', 'role_other': 'Overig', 'jump_check': 'Maak de korte oefening'},
 'ckb': {'contents': 'لە ناو ئەم ڕێنماییەدا', 'goals': 'دوای ئەم ڕێنماییە دەتوانیت…', 'deep_dive': 'هەنگاو بە هەنگاو تێبگە', 'rule_tables': 'ڕێساکە لە خشتەیەکدا', 'patterns': 'ڕستەکە پێک بهێنە', 'patterns_note': 'هەر بەشێک ئەرکێکی هەیە. ناونیشانەکان ڕەنگەکان ڕوون دەکەنەوە.', 'worked_examples': 'لە ڕێساوە بۆ ژیانی ڕۆژانە', 'traps': 'گۆڕانی بچووک، ڕستەی ڕوونتر.', 'wrong': 'لەبری', 'right': 'بڵێ', 'translation': 'واتا', 'table_hint': 'لە شاشەی بچووکدا خشتەکە بە ئاسۆیی بجوڵێنە.', 'rich_guide': 'ڕێنمایی وێنەیی', 'read_guide': 'ڕێنماییەکە بخوێنەوە', 'role_subject': 'بکەر', 'role_verb': 'کردار', 'role_object': 'بەرکار', 'role_time': 'کات', 'role_place': 'شوێن', 'role_connector': 'بەستەر', 'role_other': 'هی تر', 'jump_check': 'ڕاهێنانە کورتەکە تاقی بکەوە'},
 'ar': {'contents': 'في هذا الدليل', 'goals': 'بعد هذا الدليل يمكنك…', 'deep_dive': 'افهم خطوة بخطوة', 'rule_tables': 'القاعدة في لمحة', 'patterns': 'ابنِ الجملة', 'patterns_note': 'لكل جزء دور. توضّح التسميات معنى الألوان.', 'worked_examples': 'من القاعدة إلى الحياة اليومية', 'traps': 'تغييرات صغيرة وجمل أوضح.', 'wrong': 'بدلًا من', 'right': 'قل', 'translation': 'المعنى', 'table_hint': 'مرّر الجدول أفقيًا على الشاشات الصغيرة.', 'rich_guide': 'دليل بصري', 'read_guide': 'اقرأ الدليل', 'role_subject': 'الفاعل', 'role_verb': 'الفعل', 'role_object': 'المفعول', 'role_time': 'الزمن', 'role_place': 'المكان', 'role_connector': 'أداة الربط', 'role_other': 'آخر', 'jump_check': 'جرّب التدريب القصير'},
}
for _locale, _rich_labels in RICH_LABELS.items():
    LABELS[_locale].update(_rich_labels)

for _locale, _featured_labels in {
    'en': {'featured': 'START WITH A VISUAL GUIDE', 'table_count': 'rule tables', 'pattern_count': 'sentence patterns', 'section_count': 'explanations'},
    'nl': {'featured': 'BEGIN MET VISUELE UITLEG', 'table_count': 'regeltabellen', 'pattern_count': 'zinspatronen', 'section_count': 'uitlegonderdelen'},
    'ckb': {'featured': 'بە ڕێنماییەکی وێنەیی دەست پێ بکە', 'table_count': 'خشتەی ڕێسا', 'pattern_count': 'شێوەی ڕستە', 'section_count': 'بەشی ڕوونکردنەوە'},
    'ar': {'featured': 'ابدأ بدليل بصري', 'table_count': 'جداول القواعد', 'pattern_count': 'أنماط الجمل', 'section_count': 'أقسام الشرح'},
}.items():
    LABELS[_locale].update(_featured_labels)


# V56: compact grammar overview-only labels; detail pages keep their original copy.
for _locale, _library_copy in {
    'en': dict(library_title='Grammar', library_intro='Learn grammar step by step.', level_all='All', available='available', in_preparation='Content in preparation', in_preparation_help='No published grammar topics for this level yet.'),
    'nl': dict(library_title='Grammatica', library_intro='Leer grammatica stap voor stap.', level_all='Alle', available='beschikbaar', in_preparation='Inhoud in voorbereiding', in_preparation_help='Voor dit niveau zijn nog geen grammaticaonderwerpen gepubliceerd.'),
    'ckb': dict(library_title='ڕێزمان', library_intro='ڕێزمان هەنگاو بە هەنگاو فێر ببە.', level_all='هەموو', available='بەردەست', in_preparation='ناوەڕۆک لە ئامادەکردندایە', in_preparation_help='هێشتا هیچ بابەتێکی ڕێزمانی بڵاوکراوە بۆ ئەم ئاستە نییە.'),
    'ar': dict(library_title='القواعد', library_intro='تعلّم القواعد خطوة بخطوة.', level_all='الكل', available='متاح', in_preparation='المحتوى قيد الإعداد', in_preparation_help='لا توجد مواضيع قواعد منشورة لهذا المستوى بعد.'),
}.items():
    LABELS[_locale].update(_library_copy)


# Route-neutral labels used by the 24-item accessible grammar pagination.
for _lang, _page_copy in {
    'en': ('Page', 'of', 'Grammar pages', 'Previous', 'Next'),
    'nl': ('Pagina', 'van', 'Grammaticapagina’s', 'Vorige', 'Volgende'),
    'ckb': ('پەڕە', 'لە', 'پەڕەکانی ڕێزمان', 'پێشوو', 'دواتر'),
    'ar': ('صفحة', 'من', 'صفحات القواعد', 'السابق', 'التالي'),
}.items():
    LABELS[_lang].update(zip(('page', 'of', 'pagination', 'previous', 'next'), _page_copy))


def _student_page(request, title, description):
    """Reuse the existing Rozh student navigation without exposing it publicly."""
    if not request.user.is_authenticated:
        return {'shell_template': 'academy/base.html'}
    from .rozh2027 import student_shell_context
    return {
        **student_shell_context(request),
        'shell_template': 'academy/rozh2027_student_shell.html',
        'page_title': title,
        'page_description': description,
    }


def labels(request):
    locale = request.user.learning_profile.ui_language if request.user.is_authenticated else 'en'
    return LABELS.get(locale, LABELS['en'])


def _language(request):
    if request.user.is_authenticated:
        course = request.user.learning_profile.preferred_language
        if course and course.is_published:
            return course
        return None
    courses = Language.objects.filter(is_published=True).order_by('name')
    code = request.GET.get('language', '')[:8]
    return courses.filter(code=code).first() if code else courses.first()


def _topic_query(request):
    topics = GrammarTopic.objects.filter(published=True, level__language__is_published=True).select_related('level__language', 'article')
    if request.user.is_authenticated:
        language = _language(request)
        return topics.filter(level__language=language) if language else topics.none()
    return topics


def _article(topic):
    try:
        content = normalize_article(topic.article.content)
        return content if any(content.values()) else None
    except (ObjectDoesNotExist, ValidationError):
        # Invalid content imported outside the validated model never becomes markup.
        return None


def _has_check(topic):
    """A draft or malformed answer key must never produce a graded attempt."""
    options = topic.check_options
    return (isinstance(options, list) and len(options) >= 2
            and all(isinstance(option, str) and option.strip() for option in options)
            and len({option.strip().casefold() for option in options}) == len(options)
            and topic.check_answer in options and bool(topic.check_question.strip()))


def _grammar_library_card(topic, row, translations, now, rich=None):
    """Create only the card requested for display, never the entire course."""
    rich = _article(topic) if rich is None else rich
    status = row.status if row else 'new'
    due = bool(row and row.due_at and row.due_at <= now)
    return {'topic': topic, 'status': status, 'status_label': translations[status], 'due': due,
            'rich': bool(rich), 'summary': rich['intro'] if rich and rich['intro'] else topic.explanation,
            'table_count': len(rich['rule_tables']) if rich else 0,
            'pattern_count': len(rich['sentence_patterns']) if rich else 0,
            'section_count': len(rich['sections']) if rich else 0,
            'successful_days': min(row.successful_days, 3) if row else 0}


def grammar_library(request):
    """SQL-filter + SQL-page grammar; retain course-scoped progress and featured guide."""
    if request.user.is_authenticated:
        # Never load private course mastery for a revoked or unmigrated session.
        profile = Profile.objects.filter(user_id=request.user.pk).first()
        if not account_signin_permitted(request.user, profile):
            return HttpResponse('Account unavailable.', status=403)
    language = _language(request)
    topics = _topic_query(request)
    if language:
        topics = topics.filter(level__language=language)
    elif not request.user.is_authenticated:
        topics = topics.none()
    selected_level = request.GET.get('level', '').upper()
    selected_level = selected_level if selected_level in LEVELS else ''
    query = request.GET.get('q', '').strip()[:100]
    selected_status = request.GET.get('status', '')
    selected_status = selected_status if selected_status in ('new', 'practising', 'mastered', 'due') else ''
    now = timezone.now()
    translations = labels(request)

    # These course-wide statistics deliberately ignore the current search, level
    # and status filters, exactly as the V11 interface did. No full topic list.
    topic_total = topics.count()
    remembered_total = due_total = 0
    mastery = None
    if request.user.is_authenticated:
        mastery = GrammarMastery.objects.filter(user=request.user, topic__in=topics)
        remembered_total = mastery.filter(successful_days__gte=3).count()
        due_total = mastery.filter(due_at__lte=now).count()

    if selected_level:
        topics = topics.filter(level__code=selected_level)
    if query:
        topics = topics.filter(Q(title__icontains=query) | Q(explanation__icontains=query))

    # The original status function is: mastered if successful_days>=3,
    # practising if attempts>0, else new. Due takes precedence in the UI.
    # Use SQL subqueries, not a Python list of all published topics.
    if selected_status and mastery is not None:
        if selected_status == 'due':
            matching = mastery.filter(due_at__lte=now).values('topic_id')
            topics = topics.filter(pk__in=matching)
        elif selected_status == 'mastered':
            matching = mastery.filter(successful_days__gte=3).values('topic_id')
            topics = topics.filter(pk__in=matching)
        elif selected_status == 'practising':
            matching = mastery.filter(attempts__gt=0, successful_days__lt=3).values('topic_id')
            topics = topics.filter(pk__in=matching)
        else:  # new includes no progress row and progress with zero attempts
            progressed = mastery.filter(Q(attempts__gt=0) | Q(successful_days__gte=3)).values('topic_id')
            topics = topics.exclude(pk__in=progressed)
    elif selected_status and selected_status != 'new':
        # Guest users have no saved progress: all topics are new.
        topics = topics.none()

    # LIMIT/OFFSET happens inside the database. pk stabilises ties between
    # topics with the same level order and title (including across page loads).
    ordered = topics.order_by('level__order', 'title', 'pk')
    page = Paginator(ordered, 24).get_page(request.GET.get('page'))
    page_topics = list(page.object_list)
    progress = {}
    if mastery is not None and page_topics:
        progress = {row.topic_id: row for row in GrammarMastery.objects.filter(
            user=request.user, topic_id__in=[topic.pk for topic in page_topics])}

    cards = [_grammar_library_card(topic, progress.get(topic.pk), translations, now)
             for topic in page_topics]
    # Preserve the Page object contract expected by templates and test clients.
    page.object_list = cards

    # The highlighted guide must be the FIRST valid rich article in the entire
    # filtered result, not merely on the currently visible page. Stream it and
    # stop at the first valid entry; avoid rendering every normal topic.
    featured_guide = None
    for topic in topics.filter(article__isnull=False).order_by(
            'level__order', 'title', 'pk').iterator(chunk_size=64):
        rich = _article(topic)
        if rich:
            row = progress.get(topic.pk)
            if row is None and mastery is not None:
                row = GrammarMastery.objects.filter(user=request.user, topic=topic).first()
            featured_guide = _grammar_library_card(topic, row, translations, now, rich=rich)
            break

    return render(request, 'academy/grammar_library.html', {
        **_student_page(request, translations['back'], translations['intro']),
        'G': translations, 'topics': page_topics, 'cards': page,
        'grammar_page': page, 'grammar_query': query,
        'grammar_level': selected_level, 'grammar_status': selected_status,
        'featured_guide': featured_guide,
        'language': language, 'languages': Language.objects.filter(is_published=True), 'levels': LEVELS,
        'selected_level': selected_level, 'selected_status': selected_status, 'query': query,
        'topic_total': topic_total, 'remembered_total': remembered_total, 'due_total': due_total,
        'seo_title': translations['back'], 'seo_description': translations['intro'],
    })


def grammar_detail(request, pk):
    if request.user.is_authenticated:
        profile = Profile.objects.filter(user_id=request.user.pk).first()
        if not account_signin_permitted(request.user, profile):
            return HttpResponse('Account unavailable.', status=403)
    topic = get_object_or_404(_topic_query(request), pk=pk)
    feedback = None
    selected_answer = ''
    progress = GrammarMastery.objects.filter(user=request.user, topic=topic).first() if request.user.is_authenticated else None
    if request.method == 'POST':
        if rate_limit(request, 'grammar-check', 60, 3600, request.user.is_authenticated):
            return HttpResponse('Too many attempts.', status=429)
        selected_answer = request.POST.get('answer', '')[:300]
        if not _has_check(topic) or selected_answer not in topic.check_options:
            return HttpResponseBadRequest('Choose one of the published answers.')
        feedback = selected_answer.strip().casefold() == topic.check_answer.strip().casefold()
        if request.user.is_authenticated:
            now = timezone.now()
            today = user_localdate(request.user)
            with transaction.atomic():
                # Serialize with course switches and account suspension, then
                # validate current published question before recording mastery.
                locked_profile = Profile.objects.select_for_update().filter(user_id=request.user.pk).first()
                current_user = get_user_model().objects.filter(pk=request.user.pk).first()
                if not account_signin_permitted(current_user, locked_profile):
                    return HttpResponse('Account unavailable.', status=403)
                if locked_profile.preferred_language_id != topic.level.language_id:
                    return HttpResponse('Course changed.', status=403)
                current_topic = (GrammarTopic.objects.select_for_update()
                    .filter(pk=topic.pk, published=True, level__language__is_published=True).first())
                if current_topic is None or not _has_check(current_topic):
                    return HttpResponse('Grammar check unavailable.', status=409)
                if selected_answer not in current_topic.check_options:
                    return HttpResponseBadRequest('Choose one of the published answers.')
                feedback = (selected_answer.strip().casefold()
                            == current_topic.check_answer.strip().casefold())
                progress, _ = GrammarMastery.objects.select_for_update().get_or_create(user=request.user, topic=current_topic)
                progress.attempts += 1
                progress.correct += int(feedback)
                if feedback and progress.last_correct_day != today:
                    progress.successful_days = min(3, progress.successful_days + 1)
                    progress.last_correct_day = today
                elif not feedback:
                    progress.successful_days = max(0, progress.successful_days - 1)
                progress.reviewed_at = now
                days = (1, 1, 3, 7)[min(progress.successful_days, 3)] if feedback else 1
                progress.due_at = now + timedelta(days=days)
                progress.save()
            # Post/redirect/get prevents refreshing an answer from creating attempts.
            request.session[f'grammar_feedback_{topic.pk}'] = {'correct': feedback, 'answer': selected_answer}
            return redirect('grammar', pk=topic.pk)
    if request.method == 'GET':
        result = request.session.pop(f'grammar_feedback_{topic.pk}', None)
        if isinstance(result, dict):
            feedback = result.get('correct')
            selected_answer = result.get('answer', '')
    rich = _article(topic)
    if rich:
        for block in rich.get('visual_blocks', []):
            block['layout'] = VISUAL_COMPONENT_TYPES[block['type']]
            block['component_label'] = COMPONENT_LABELS.get(block['type'], block['title'])
            block['is_v57'] = block['type'] in COMPONENT_LABELS
            block['category_key'] = COMPONENT_CATEGORIES.get(block['type'], 'Legacy').lower().split(' & ')[0].split(' ')[0]
            if block['layout'] == 'compare':
                simple_labels = {
                    'correct_vs_incorrect': {'en': ('Incorrect', 'Correct'), 'nl': ('Fout', 'Goed'), 'ckb': ('هەڵە', 'ڕاست'), 'ar': ('خطأ', 'صحيح')},
                    'before_after': {'en': ('Before', 'After'), 'nl': ('Voor', 'Na'), 'ckb': ('پێش', 'دوای'), 'ar': ('قبل', 'بعد')},
                    'formal_informal': {'en': ('Formal', 'Informal'), 'nl': ('Formeel', 'Informeel'), 'ckb': ('فەرمی', 'نافەرمی'), 'ar': ('رسمي', 'غير رسمي')},
                    'singular_vs_plural': {'en': ('Singular', 'Plural'), 'nl': ('Enkelvoud', 'Meervoud'), 'ckb': ('تاک', 'کۆ'), 'ar': ('مفرد', 'جمع')},
                }
                locale = getattr(getattr(request.user, 'learning_profile', None), 'ui_language', 'en') if request.user.is_authenticated else 'en'
                pair = simple_labels.get(block['type'], {}).get(locale)
                if pair:
                    block['left_label'], block['right_label'] = pair
            if block['layout'] == 'tokens':
                for token in block['tokens']:
                    token['role_label'] = labels(request)['role_' + token['role']]
        for pattern in rich['sentence_patterns']:
            for token in pattern['tokens']:
                token['role_label'] = labels(request)['role_' + token['role']]
    return render(request, 'academy/grammar.html', {
        **_student_page(request, topic.title, topic.explanation[:160]),
        'G': labels(request), 'GV': VISUAL_LABELS.get(getattr(getattr(request.user, 'learning_profile', None), 'ui_language', 'en') if request.user.is_authenticated else request.GET.get('ui', 'en'), VISUAL_LABELS['en']), 'topic': topic, 'feedback': feedback, 'selected_answer': selected_answer,
        'article': rich,
        'content_dir': 'rtl' if topic.level.language.code in ('ar', 'ckb', 'fa', 'he') else 'ltr',
        'mastery': progress, 'recall_days': min(progress.successful_days, 3) if progress else 0,
        'has_check': _has_check(topic),
        'canonical_path': topic.get_absolute_url(), 'seo_title': topic.title,
        'seo_description': topic.explanation[:160],
    })


@login_required
def mistakes(request):
    # POST has its own locked admission check; GET must also reject revoked or
    # missing Profiles before accessing the student shell or private mistakes.
    profile = Profile.objects.filter(user_id=request.user.pk).first()
    if not account_signin_permitted(request.user, profile):
        return HttpResponse('Account unavailable.', status=403)
    G = labels(request)
    if request.method == 'POST':
        if rate_limit(request, 'mistake-review', 40, 3600, True):
            return HttpResponse('Too many answers.', status=429)
        answer = request.POST.get('answer', '')[:300]
        # Serialize with course switching, account review and XP grants.
        # Do not trust the Profile/course cached before acquiring the lock.
        with transaction.atomic():
            profile = Profile.objects.select_for_update().filter(user=request.user).first()
            if profile is None or not profile.preferred_language_id:
                return HttpResponse('Complete your course setup before reviewing mistakes.', status=403)
            language = (Language.objects.select_for_update()
                        .filter(pk=profile.preferred_language_id).first())
            if not mistake_retry_allowed(
                profile, user_active=request.user.is_active,
                course_published=bool(language and language.is_published),
            ):
                return HttpResponse('Mistake practice is unavailable for this account or course.', status=403)
            # Evaluate course ownership only AFTER the live Profile lock. Old
            # mistake IDs remain history, never authority to use an old course.
            active_records = MistakeRecord.objects.filter(
                user=request.user,
                exercise__lesson__unit__level__language_id=profile.preferred_language_id,
                exercise__lesson__published=True,
                exercise__lesson__unit__published=True,
                exercise__lesson__unit__level__language__is_published=True,
            ).select_related('exercise__lesson__unit__level')
            mistake = get_object_or_404(active_records.select_for_update(),
                pk=request.POST.get('mistake_id'), corrected_at__isnull=True)
            # Rich interactive V58 exercises must be replayed in their real
            # lesson player. The old text-only mistakes form cannot grade
            # multi-part matches or images accurately or credit fake repairs.
            if mistake.exercise.kind not in ('mcq', 'short'):
                return HttpResponseBadRequest('Review this exercise in its original lesson.')
            if not answer.strip() or (mistake.exercise.kind == 'mcq' and answer not in mistake.exercise.options):
                return HttpResponseBadRequest('Choose one of the provided answers.')
            correct = grade(mistake.exercise, answer)
            record_exercise_result(request.user, mistake.exercise, correct)
            rewarded = False
            if correct:
                from .hearts import recover_for_mistake
                recover_for_mistake(request.user, mistake)
                rewarded = award_xp(request.user, 5, reason='mistake', event_key=f'mistake:{mistake.pk}')
        if correct:
            messages.success(request, G['repaired'] if rewarded else G['saved'])
        else:
            messages.error(request, G['retry'])
        # Only IDs/outcome in session; never store a submitted answer.
        request.session['mistake_feedback'] = {'id': mistake.pk, 'correct': correct}
        return redirect('mistakes')

    # GET remains read-only. Show only current published-course errors.
    course = _language(request)
    records = MistakeRecord.objects.filter(user=request.user,
        exercise__lesson__published=True, exercise__lesson__unit__published=True,
        exercise__lesson__unit__level__language__is_published=True,
        exercise__lesson__unit__level__language=course).select_related('exercise__lesson__unit__level')
    result = request.session.pop('mistake_feedback', None)
    feedback_record = records.filter(pk=result.get('id')).first() if isinstance(result, dict) else None
    pending = records.filter(corrected_at__isnull=True).order_by('-wrong_count', 'last_wrong_at')
    current = feedback_record if feedback_record and feedback_record.corrected_at is None else pending.first()
    explained = feedback_record
    related = None
    if explained:
        unit = explained.exercise.lesson.unit
        related = GrammarTopic.objects.filter(level=unit.level, slug=unit.slug, published=True).first()
    return render(request, 'academy/mistakes.html', {
        **_student_page(request, G['mistakes_title'], G['mistakes_intro']),
        'G': G, 'pending': pending.count(), 'resolved': records.filter(corrected_at__isnull=False).count(),
        'current': current, 'explanation_record': explained, 'related_topic': related,
        'answer_correct': result.get('correct') if feedback_record else None, 'noindex': True,
    })


urlpatterns = [
    path('grammar/', grammar_library, name='grammar_library'),
    path('grammar/<int:pk>/', grammar_detail, name='grammar'),
    path('mistakes/', mistakes, name='mistakes'),
]


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'grammar_v9', ['LABELS', 'RICH_LABELS'])

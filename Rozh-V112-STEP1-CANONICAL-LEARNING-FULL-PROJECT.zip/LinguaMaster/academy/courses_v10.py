"""Published course chooser and durable, course-specific starting points."""
from django.contrib import messages
from django.core.exceptions import PermissionDenied
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Count
from django.http import HttpResponse, HttpResponseBadRequest
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import path
from django.views.decorators.http import require_GET, require_POST
from .course_models import CourseEnrollment
from .account_signin_policy_v27 import account_signin_permitted
from .models import Language, Level, Unit, Lesson, Exercise, LessonProgress, Profile
from .services import rate_limit

STAGES = ('A0', 'A1', 'A2', 'B1', 'B2', 'C1')
ORDER = ('nl', 'en', 'de', 'fr')
NATIVE_NAMES = {'nl':'Nederlands', 'en':'English', 'de':'Deutsch', 'fr':'Français'}
# Flag SVGs are presentation assets, not a source of course counts or identity.
COURSE_FLAGS = {
    'nl':'academy/flags/nl.svg', 'en':'academy/flags/en.svg',
    'de':'academy/flags/de.svg', 'fr':'academy/flags/fr.svg',
}
NAMES = {
    'en':{'nl':'Dutch', 'en':'English', 'de':'German', 'fr':'French'},
    'nl':{'nl':'Nederlands', 'en':'Engels', 'de':'Duits', 'fr':'Frans'},
    'ckb':{'nl':'هۆڵەندی', 'en':'ئینگلیزی', 'de':'ئەڵمانی', 'fr':'فەڕەنسی'},
    'ar':{'nl':'الهولندية', 'en':'الإنجليزية', 'de':'الألمانية', 'fr':'الفرنسية'},
}
TEXT = {
    'en':{
        'kicker':'MAKE WORDS YOUR WORLD', 'title':'Where will your words take you?',
        'intro':'Choose a language, take a small step, and return to any course whenever you like.',
        'current':'Your current course', 'available':'Available now', 'resume':'Continue this course',
        'start':'Start at A0', 'placement':'Find my starting point', 'starting':'Starting point',
        'lessons':'lessons', 'units':'units', 'questions':'practice questions', 'done':'lessons completed',
        'progress':'Your progress', 'stages':'Course stages', 'soon':'Content in preparation',
        'empty':'Your next course is on its way', 'empty_note':'No published courses are available yet. Please check back later.',
        'note':'Only published learning material is counted. A0–C1 is the course structure; the available material is still growing.',
        'preserved':'Your progress stays with each course. Your XP, streak and friends stay with your account.',
        'switched':'You are ready to learn {name}.', 'choose':'Courses', 'back':'Back to learning',
        'beginner':'New to this language? Start at A0. You can explore the available course at your own pace.',
        'active':'Active', 'ready':'Ready to learn', 'enrolled':'Your learning journey',
        'not_started':'A fresh start', 'course_count':'languages to explore', 'native':'Native name',
    },
    'nl':{
        'kicker':'MAAK TAAL JOUW WERELD', 'title':'Waar brengt taal jou naartoe?',
        'intro':'Kies een taal, zet een kleine stap en ga verder met iedere cursus wanneer je wilt.',
        'current':'Jouw huidige cursus', 'available':'Nu beschikbaar', 'resume':'Verder met deze cursus',
        'start':'Begin bij A0', 'placement':'Vind mijn startniveau', 'starting':'Startniveau',
        'lessons':'lessen', 'units':'units', 'questions':'oefenvragen', 'done':'lessen afgerond',
        'progress':'Jouw voortgang', 'stages':'Cursusfases', 'soon':'Inhoud wordt voorbereid',
        'empty':'Je volgende cursus komt eraan', 'empty_note':'Er zijn nog geen gepubliceerde cursussen. Kijk later opnieuw.',
        'note':'We tellen alleen gepubliceerd lesmateriaal. A0–C1 is de cursusstructuur; het beschikbare materiaal groeit nog.',
        'preserved':'Je voortgang blijft per cursus bewaard. Je XP, streak en vrienden horen bij je account.',
        'switched':'Je kunt verder met {name}.', 'choose':'Cursussen', 'back':'Terug naar leren',
        'beginner':'Is deze taal nieuw voor je? Begin bij A0 en volg het beschikbare materiaal op jouw tempo.',
        'active':'Actief', 'ready':'Klaar om te leren', 'enrolled':'Jouw leerreis',
        'not_started':'Een nieuw begin', 'course_count':'talen om te ontdekken', 'native':'Eigen taalnaam',
    },
    'ckb':{
        'kicker':'زمان بکە بە جیهانی خۆت', 'title':'زمان بۆ کوێت دەبات؟',
        'intro':'زمانێک هەڵبژێرە، هەنگاوێکی بچووک بنێ و هەرکاتێک بتەوێت بگەڕێوە بۆ کۆرسەکانت.',
        'current':'کۆرسی ئێستات', 'available':'ئێستا بەردەستە', 'resume':'لەم کۆرسە بەردەوام بە',
        'start':'لە A0 دەست پێ بکە', 'placement':'ئاستی دەستپێکم بدۆزەوە', 'starting':'ئاستی دەستپێک',
        'lessons':'وانە', 'units':'یەکە', 'questions':'پرسیاری ڕاهێنان', 'done':'وانە تەواوکراوە',
        'progress':'پێشکەوتنت', 'stages':'قۆناغەکانی کۆرس', 'soon':'ناوەڕۆک ئامادە دەکرێت',
        'empty':'کۆرسی داهاتووت بەڕێوەیە', 'empty_note':'هێشتا هیچ کۆرسێک بڵاو نەکراوەتەوە. دواتر سەردان بکەوە.',
        'note':'تەنها ناوەڕۆکی بڵاوکراوە هەژمار دەکرێت. A0–C1 پێکهاتەی کۆرسە؛ ناوەڕۆکی بەردەست هێشتا پەرە دەسێنێت.',
        'preserved':'پێشکەوتنت بۆ هەر کۆرسێک دەپارێزرێت. XP، ستریک و هاوڕێکانت لەگەڵ هەژمارەکەت دەمێننەوە.',
        'switched':'ئامادەیت بۆ فێربوونی {name}.', 'choose':'کۆرسەکان', 'back':'بگەڕێوە بۆ فێربوون',
        'beginner':'ئەم زمانە بۆت نوێیە؟ لە A0 دەست پێ بکە و بە پێی توانای خۆت ناوەڕۆکە بەردەستەکان بخوێنە.',
        'active':'چالاکە', 'ready':'ئامادەی فێربوون', 'enrolled':'گەشتی فێربوونت',
        'not_started':'دەستپێکێکی نوێ', 'course_count':'زمان بۆ دۆزینەوە', 'native':'ناوی ڕەسەنی زمان',
    },
    'ar':{
        'kicker':'اجعل اللغة عالمك', 'title':'إلى أين تأخذك كلماتك؟',
        'intro':'اختر لغة وخذ خطوة صغيرة، وعد إلى أي دورة متى شئت.',
        'current':'دورتك الحالية', 'available':'متاح الآن', 'resume':'متابعة هذه الدورة',
        'start':'ابدأ من A0', 'placement':'حدد نقطة بدايتي', 'starting':'نقطة البداية',
        'lessons':'دروس', 'units':'وحدات', 'questions':'أسئلة تدريب', 'done':'دروس مكتملة',
        'progress':'تقدمك', 'stages':'مراحل الدورة', 'soon':'المحتوى قيد الإعداد',
        'empty':'دورتك القادمة في الطريق', 'empty_note':'لا توجد دورات منشورة بعد. تحقق مرة أخرى لاحقًا.',
        'note':'نحسب المواد المنشورة فقط. A0–C1 هي بنية الدورة؛ المواد المتاحة ما زالت تتوسع.',
        'preserved':'يُحفظ تقدمك لكل دورة. تبقى نقاطك وسلسلتك وأصدقاؤك مع حسابك.',
        'switched':'أنت جاهز لتعلم {name}.', 'choose':'الدورات', 'back':'العودة إلى التعلم',
        'beginner':'هذه اللغة جديدة عليك؟ ابدأ من A0 وتقدم في المواد المتاحة بالوتيرة المناسبة لك.',
        'active':'نشطة', 'ready':'جاهز للتعلم', 'enrolled':'رحلتك التعليمية',
        'not_started':'بداية جديدة', 'course_count':'لغات لتكتشفها', 'native':'اسم اللغة الأصلي',
    },
}


def locale_for(user):
    from .safe_profile_context_v46 import visible_learning_profile
    profile = visible_learning_profile(user)
    return profile.ui_language if profile is not None else 'en'


def course_name(language, locale='en'):
    return NAMES.get(locale,NAMES['en']).get(language.code,language.name) if language else ''


def course_labels(user):
    return TEXT.get(locale_for(user),TEXT['en'])


def course_context(request):
    """Optional context processor for the account's course chip and navigation."""
    from .safe_profile_context_v46 import visible_learning_profile
    profile = visible_learning_profile(request.user)
    language = profile.preferred_language if profile is not None else None
    return {'COURSE_TEXT':course_labels(request.user),
            'CURRENT_COURSE_NAME':course_name(language,locale_for(request.user)),
            'CURRENT_COURSE_NATIVE':NATIVE_NAMES.get(language.code,language.name) if language else ''}


def _snapshot(profile):
    if not profile.preferred_language_id:
        return None
    stage=profile.placement_level if profile.placement_level in STAGES else 'A0'
    enrollment,_=CourseEnrollment.objects.update_or_create(user=profile.user,language_id=profile.preferred_language_id,
        defaults={'placement_completed':profile.placement_completed,'placement_level':stage})
    return enrollment


@transaction.atomic
def record_current_course(profile):
    """Read the persisted Profile: bound ModelForms may have mutated their instance."""
    current=Profile.objects.select_for_update().get(pk=profile.pk)
    return _snapshot(current)


@transaction.atomic
def switch_course(user,language,*,start_at_a0=False):
    """Keep each course's starting point without changing learning activity records."""
    profile=Profile.objects.select_for_update().get(user=user)
    # Course switches share the same Profile lock as XP and review transactions.
    # A suspended/quarantined account cannot change course through a stale POST.
    current_user=get_user_model().objects.filter(pk=user.pk).first()
    if not account_signin_permitted(current_user,profile):
        raise PermissionDenied('Account access is currently restricted.')
    language=Language.objects.get(pk=language.pk,is_published=True)
    same=profile.preferred_language_id==language.pk
    saved=_snapshot(profile)
    enrollment=saved if same else None
    if enrollment is None:
        enrollment,_=CourseEnrollment.objects.get_or_create(user=user,language=language)
    if start_at_a0 and not enrollment.placement_completed:
        enrollment.placement_level='A0'
        enrollment.placement_completed=True
        enrollment.save(update_fields=['placement_level','placement_completed','updated_at'])
    profile.preferred_language=language
    profile.placement_level=enrollment.placement_level
    profile.placement_completed=enrollment.placement_completed
    profile.save(update_fields=['preferred_language','placement_level','placement_completed'])
    return profile


def export_enrollments(user):
    """Export snapshots plus the latest active state without mutating an account."""
    profile=Profile.objects.get(user=user)
    result={}
    for row in CourseEnrollment.objects.filter(user=user).select_related('language'):
        result[row.language_id]={'language':row.language.code,'placement_completed':row.placement_completed,
            'placement_level':row.placement_level,'joined_at':row.joined_at.isoformat(),
            'updated_at':row.updated_at.isoformat(),'active':row.language_id==profile.preferred_language_id}
    if profile.preferred_language_id:
        active=result.setdefault(profile.preferred_language_id,{'language':profile.preferred_language.code,
            'joined_at':None,'updated_at':None,'active':True})
        active.update(placement_completed=profile.placement_completed,placement_level=profile.placement_level)
    return list(result.values())


@login_required
@require_GET
def courses(request):
    current_user=get_user_model().objects.filter(pk=request.user.pk).first()
    current_profile=Profile.objects.filter(user_id=request.user.pk).first()
    if not account_signin_permitted(current_user,current_profile):
        return HttpResponse(status=403)
    C=course_labels(request.user)
    locale=locale_for(request.user)
    profile=request.user.learning_profile
    enrollments={row.language_id:row for row in CourseEnrollment.objects.filter(user=request.user)}
    languages=list(Language.objects.filter(is_published=True))
    languages.sort(key=lambda item:(ORDER.index(item.code) if item.code in ORDER else len(ORDER),item.name))
    cards=[]
    for language in languages:
        units=Unit.objects.filter(level__language=language,published=True)
        lessons=Lesson.objects.filter(unit__in=units,published=True)
        done=LessonProgress.objects.filter(user=request.user,lesson__in=lessons).count()
        stage_totals=dict(lessons.values('unit__level__code').annotate(total=Count('pk')).values_list('unit__level__code','total'))
        total=sum(stage_totals.values())
        enrollment=enrollments.get(language.pk)
        active=profile.preferred_language_id==language.pk
        ready=profile.placement_completed if active else bool(enrollment and enrollment.placement_completed)
        starting=profile.placement_level if active else enrollment.placement_level if enrollment else 'A0'
        stages=[]
        levels={level.code:level for level in Level.objects.filter(language=language)}
        for code in STAGES:
            level=levels.get(code)
            count=stage_totals.get(code,0)
            stages.append({'code':code,'lessons':count,'level':level})
        cards.append({'language':language,'name':course_name(language,locale),
            'native_name':NATIVE_NAMES.get(language.code,language.name),
            'flag_path':COURSE_FLAGS.get(language.code), 'active':active,'enrolled':bool(enrollment) or active,
            'ready':ready,'starting':starting,'lessons':total,'units':units.count(),
            'questions':Exercise.objects.filter(lesson__in=lessons).count(),'completed':done,
            'percent':min(100,round(100*done/total)) if total else 0,'stages':stages})
    return render(request,'academy/courses.html',{'C':C,'cards':cards,'noindex':True})


@login_required
@require_POST
def course_switch(request,code):
    if (request.user.learning_profile.onboarding_required and
            not request.user.learning_profile.onboarding_completed):
        return redirect('onboarding')
    if rate_limit(request,'course-switch-v10',40,3600,True):
        return HttpResponse('Too many course changes.',status=429)
    start=request.POST.get('start','A0')
    if start not in ('A0','resume','placement'):
        return HttpResponseBadRequest('Choose a valid starting point.')
    language=get_object_or_404(Language,code=code,is_published=True)
    try:
        profile=switch_course(request.user,language,start_at_a0=start=='A0')
    except Language.DoesNotExist:
        # Publication can change between the initial lookup and transaction.
        return HttpResponse(status=404)
    if not profile.onboarding_completed:
        Profile.objects.filter(pk=profile.pk).update(onboarding_completed=True)
    messages.success(request,course_labels(request.user)['switched'].format(name=course_name(language,locale_for(request.user))))
    if profile.placement_completed:
        return redirect('play_hub')
    from .placement_adaptive_v77 import smart_placement_available
    return redirect('smart_placement_v77' if smart_placement_available(language) else 'placement')


urlpatterns=[
    path('courses/',courses,name='courses'),
    path('courses/<slug:code>/switch/',course_switch,name='course_switch'),
]


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'courses_v10', ['NAMES', 'TEXT'])

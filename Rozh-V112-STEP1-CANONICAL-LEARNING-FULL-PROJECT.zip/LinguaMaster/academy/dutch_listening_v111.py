"""Original closed-answer listening questions keyed by the exact spoken Dutch text.

These are draft editorial content, not evidence that recordings were reviewed.
The choices are deliberately different in meaning; no AI grading is needed.
"""

ITEMS = {
    'Dank u wel voor uw hulp.': ('What is the speaker doing?', ['Greeting someone', 'Thanking someone', 'Saying goodbye'], 'Thanking someone', 'Dank u wel expresses thanks; voor uw hulp means for your help.'),
    'een boek': ('Which object do you hear?', ['een boek', 'een huis', 'een tafel'], 'een boek', 'The recording says een boek (a book).'),
    'Spreekt u Nederlands?': ('Which language does the speaker mention?', ['Engels', 'Nederlands', 'Frans'], 'Nederlands', 'The speaker asks whether someone speaks Dutch.'),
    'Werken jullie hier?': ('What does the speaker ask?', ['Do you live here?', 'Are you learning here?', 'Do you work here?'], 'Do you work here?', 'Werken means to work; hier means here.'),
    'Morgen gaan we naar de stad.': ('When are they going to the city?', ['Morgen', 'Vandaag', 'Gisteren'], 'Morgen', 'Morgen means tomorrow.'),
    'Het is niet duur.': ('What does the speaker say about the price?', ['It is not expensive', 'It is very expensive', 'It is free'], 'It is not expensive', 'Niet duur means not expensive; it does not necessarily mean free.'),
    'Zij heeft een boek gelezen.': ('What has she done?', ['Bought a book', 'Written a book', 'Read a book'], 'Read a book', 'Gelezen is the past participle of lezen (to read).'),
    'Wij moeten vroeg vertrekken.': ('What must they do?', ['Leave early', 'Arrive late', 'Stay here'], 'Leave early', 'Moeten expresses obligation; vroeg vertrekken means leave early.'),
    'Dat is het mooiste uitzicht.': ('How does the speaker describe the view?', ['Het slechtste uitzicht', 'Het mooiste uitzicht', 'Een gewoon uitzicht'], 'Het mooiste uitzicht', 'Mooiste is the superlative of mooi.'),
    'Omdat ik ziek ben, blijf ik thuis.': ('Why is the speaker staying home?', ['Omdat het regent', 'Omdat ik vakantie heb', 'Omdat ik ziek ben'], 'Omdat ik ziek ben', 'Omdat introduces the reason: the speaker is ill.'),
    'De kinderen die spelen, zijn blij.': ('Which children are happy?', ['De kinderen die slapen', 'De kinderen die spelen', 'De kinderen die leren'], 'De kinderen die spelen', 'The relative clause die spelen identifies the children.'),
    'Wij speelden elke dag buiten.': ('How often did they play outside?', ['Elke dag', 'Een keer per week', 'Alleen in het weekend'], 'Elke dag', 'Elke dag means every day; speelden describes the past.'),
    'De documenten zijn ondertekend.': ('Wat is er met de documenten gebeurd?', ['Ze zijn verloren', 'Ze zijn afgedrukt', 'Ze zijn ondertekend'], 'Ze zijn ondertekend', 'Ondertekend means signed; the passive construction describes the result.'),
    'Ik denk eraan.': ('Welke zin hoor je?', ['Ik denk eraan.', 'Ik wacht erop.', 'Ik praat erover.'], 'Ik denk eraan.', 'Eraan combines er and aan in the construction denken aan.'),
    'Doordat het stormde, vertrok de trein later.': ('Waarom vertrok de trein later?', ['Omdat er een staking was', 'Omdat het stormde', 'Omdat de trein te vroeg was'], 'Omdat het stormde', 'Doordat introduces the cause: the storm.'),
    'Een zorgvuldige afweging is noodzakelijk.': ('Wat is volgens de spreker noodzakelijk?', ['Een zorgvuldige afweging', 'Een snelle beslissing', 'Een definitieve afwijzing'], 'Een zorgvuldige afweging', 'De spreker benadrukt dat een zorgvuldige afweging nodig is.'),
    'Wellicht is nader onderzoek nodig.': ('Hoe zeker is de spreker dat verder onderzoek nodig is?', ['Volledig zeker', 'Zeker dat het niet nodig is', 'Het is mogelijk nodig'], 'Het is mogelijk nodig', 'Wellicht drukt onzekerheid of mogelijkheid uit.'),
    'Pas later werd de oorzaak duidelijk.': ('Wanneer werd de oorzaak duidelijk?', ['Meteen', 'Pas later', 'Helemaal niet'], 'Pas later', 'Pas later benadrukt dat de oorzaak niet onmiddellijk duidelijk werd.'),
}


def listening_quiz(audio_text):
    """Exact lookup; changed or unknown text must get a new authored question."""
    prompt, options, answer, explanation = ITEMS[audio_text]
    return {'kind': 'mcq', 'prompt': prompt, 'options': list(options), 'answer': answer, 'explanation': explanation}

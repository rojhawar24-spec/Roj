"""Actual Django HTTP assertions: run on an isolated Django test environment."""
from django.test import SimpleTestCase
from django.urls import reverse

class Phase12PWAHttpTests(SimpleTestCase):
    def test_public_service_worker_is_accessible(self):
        result=self.client.get(reverse('service_worker'))
        self.assertEqual(result.status_code,200)
        self.assertIn('javascript',result['Content-Type'])
        self.assertIn('no-cache',result['Cache-Control'])
        self.assertIn(b'const PRECACHE = [',result.content)

    def test_http_worker_keeps_private_navigation_network_first(self):
        result=self.client.get('/service-worker.js')
        source=result.content.decode('utf8')
        self.assertIn("if (request.mode === 'navigate')",source)
        self.assertIn('event.respondWith(fetch(request).catch',source)
        self.assertIn('if (!ASSETS.includes(url.pathname)) return',source)

    def test_http_worker_contains_student_performance_release_marker(self):
        result=self.client.get('/service-worker.js')
        self.assertIn('phase12-lean-pwa-20261114',result.content.decode('utf8'))

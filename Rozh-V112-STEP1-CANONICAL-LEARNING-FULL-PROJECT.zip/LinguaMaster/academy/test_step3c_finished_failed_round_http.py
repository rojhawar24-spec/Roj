"""Django HTTP+SQLite acceptance tests for Step 3C. NOT executed offline.
Run only on isolated Django test database with proper Step 2 QA config.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Exercise, Language, Lesson, LessonProgress, Level, Profile, Unit, XPEvent


class AuthoredFailedRoundHttpTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user=get_user_model().objects.create_user(
            username='step3c-disposable-student',password='OnlyForQA-2026!')
        cls.language=Language.objects.create(code='nl',name='Dutch Step 3C QA',
                                             slug='step3c-test-dutch',description='Disposable',is_published=True)
        cls.level=Level.objects.create(language=cls.language,code='A0',description='QA level',order=0)
        cls.unit=Unit.objects.create(level=cls.level,slug='step3c-test-unit',
                                     title='QA unit',summary='Disposable',published=True,order=1)
        cls.lesson=Lesson.objects.create(unit=cls.unit,slug='step3c-test-lesson',
                                         title='QA lesson',skill='grammar',content='QA only',published=True)
        cls.exercise=Exercise.objects.create(lesson=cls.lesson,kind='fill_blank',
                                            prompt='Ik ___ blij.',options=[],answer='ben',
                                            explanation='Ik ben blij.',difficulty=1)
        Profile.objects.filter(user=cls.user).update(preferred_language=cls.language,
            placement_completed=True,onboarding_required=False,onboarding_completed=True,
            suspended_at=None,legacy_review_required=False)

    def setUp(self):
        self.client.force_login(self.user)
        self.lesson_url=reverse('lesson',args=[self.lesson.pk])
        self.api_url=reverse('lesson_answer',args=[self.lesson.pk])

    def open_round(self):
        r=self.client.get(self.lesson_url)
        self.assertEqual(r.status_code,200)
        return r.context['lesson_round_key']

    def no_xp(self):
        self.assertFalse(XPEvent.objects.filter(user=self.user,reason='lesson').exists())
        self.assertFalse(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())

    def test_failed_ajax_authored_round_is_terminal_and_fresh_get_can_retry(self):
        token=self.open_round()
        failed=self.client.post(self.api_url,{'exercise_id':self.exercise.pk,'answer':'was','round_key':token})
        self.assertEqual(failed.status_code,200)
        self.assertTrue(failed.json()['finished'])
        self.assertFalse(failed.json()['completed'])
        self.no_xp()
        denial=self.client.post(self.api_url,{'exercise_id':self.exercise.pk,'answer':'ben','round_key':token})
        self.assertEqual(denial.status_code,409)
        self.assertEqual(denial.json()['error_code'],'round_finished')
        self.no_xp()
        fresh=self.open_round()
        self.assertNotEqual(fresh,token)
        passed=self.client.post(self.api_url,{'exercise_id':self.exercise.pk,'answer':'ben','round_key':fresh})
        self.assertEqual(passed.status_code,200)
        self.assertTrue(passed.json()['completed'])

    def test_failed_ssr_authored_round_cannot_change_grade_without_fresh_get(self):
        token=self.open_round()
        wrong={'round_key':token,f'answer_{self.exercise.pk}':'was'}
        self.assertEqual(self.client.post(self.lesson_url,wrong).status_code,200)
        self.no_xp()
        retry={'round_key':token,f'answer_{self.exercise.pk}':'ben'}
        self.assertEqual(self.client.post(self.lesson_url,retry).status_code,409)
        self.no_xp()
        fresh=self.open_round()
        retry['round_key']=fresh
        self.assertEqual(self.client.post(self.lesson_url,retry).status_code,200)
        self.assertTrue(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())

"""Visitor language & sign-in intent for the Rozh public experience.

No unvalidated redirect is created here; views._safe_after_login handles that.
Anonymous locale preferences are stored only after an explicit language selection.
"""
from urllib.parse import urlsplit
from django.urls import reverse
from .home_v23 import copy_for

from .ui_languages_v74 import SUPPORTED_UI_LANGUAGES
PUBLIC_LOCALES = SUPPORTED_UI_LANGUAGES
COPY = {'nl': {'signin': 'Inloggen',
        'signup': 'Account maken',
        'welcome': 'Welkom terug',
        'start': 'Start je leeravontuur',
        'signin_desc': 'Log in en ga verder waar je gebleven bent.',
        'signup_desc': 'Maak een account om je lessen en voortgang te bewaren.',
        'choose': 'Kies hoe je verder wilt gaan',
        'continue': 'Je wilt verder met',
        'safe': 'Na het inloggen ga je naar de gekozen functie.',
        'email_or_username': 'E-mailadres of gebruikersnaam',
        'email': 'E-mailadres',
        'password': 'Wachtwoord',
        'password1': 'Wachtwoord',
        'password_guidance': 'Minimaal 8 tekens. Kies een uniek wachtwoord; 15 of meer tekens is veiliger.',
        'password2': 'Herhaal wachtwoord',
        'username': 'Gebruikersnaam',
        'age_confirmed': 'Ik bevestig dat ik minstens 16 jaar ben',
        'username_help': '3–30 tekens; begin met een letter.',
        'forgot': 'Wachtwoord vergeten?',
        'recover_prompt': 'Hulp bij inloggen:',
        'recover_steps': 'Wachtwoord vergeten? Gebruik herstel met een bevestigd e-mailadres.',
        'show': 'Tonen',
        'hide': 'Verbergen',
        'submit_login': 'Inloggen en verdergaan',
        'submit_register': 'Account maken en starten',
        'verify': 'Je kunt direct beginnen. E-mailbevestiging is later optioneel voor wachtwoordherstel.',
        'have_account': 'Heb je al een account?',
        'new': 'Nog geen account?',
        'resend': 'E-mailadres bevestigen',
        'privacy_intro': 'Je gegevens zijn privé.',
        'privacy': 'Privacyverklaring',
        'preview_title': 'Kleine lessen. Grote vooruitgang.',
        'preview_desc': 'Oefen stap voor stap en bewaar je voortgang in je eigen account.',
        'point1': 'Gestructureerde lessen',
        'point2': 'Je voortgang bewaren',
        'point3': 'Oefenen en herhalen',
        'home': 'Terug naar start',
        'language': 'Taal',
        'terms': 'Voorwaarden',
        'eyebrow': 'JOUW PLEK OM TE LEREN',
        'eyebrow_register': 'EEN NIEUW BEGIN',
        'journey_label': 'JOUW VOLGENDE HOOFDSTUK',
        'journey_title': 'Elke stap brengt je verder.',
        'journey_desc': 'Ontdek nieuwe woorden, oefen in kleine stappen en zie je eigen vooruitgang groeien.',
        'journey_one': 'Jouw eigen leerroute',
        'journey_two': 'Oefen wanneer het jou past',
        'journey_three': 'Verder waar je gebleven bent',
        'illustration': 'Illustratie van de leerroute. Je echte voortgang verschijnt na het inloggen.',
        'action_hint': 'Je kunt na het inloggen meteen verder leren.',
        'local_help_title': 'Lokaal inloggen lukt niet?',
        'local_help_body': 'Na een upgrade kan een bestaand account nog op controle wachten. Maak niet steeds een nieuw account: controleer eerst veilig de accountstatus op je eigen Windows-computer.',
        'local_help_command': 'Voer in de geïnstalleerde LinguaMaster-map het read-only diagnosescript uit:',
        'registration_hint': 'Je kunt meteen leren. Bevestig je e-mailadres later als je wachtwoordherstel wilt '
                             'gebruiken.',
        'private_note': 'Je wachtwoord blijft geheim; we tonen het nooit in de leerroute.',
        'form_error_summary': 'Controleer de gemarkeerde velden en probeer opnieuw.'},
 'en': {'signin': 'Sign in',
        'signup': 'Create account',
        'welcome': 'Welcome back',
        'start': 'Start your learning journey',
        'signin_desc': 'Sign in and pick up where you left off.',
        'signup_desc': 'Create an account to save your lessons and progress.',
        'choose': 'Choose how to continue',
        'continue': 'You are heading to',
        'safe': 'After signing in, you will return to your chosen feature.',
        'email_or_username': 'Email or username',
        'email': 'Email address',
        'password': 'Password',
        'password1': 'Password',
        'password_guidance': 'Minimum 8 characters. Use a unique password; 15 or more is safer.',
        'password2': 'Confirm password',
        'username': 'Username',
        'age_confirmed': 'I confirm that I am at least 16 years old',
        'username_help': '3–30 characters, start with a letter.',
        'forgot': 'Forgot password?',
        'recover_prompt': 'Need help signing in?',
        'recover_steps': 'Forgot your password? Recovery requires a verified email address.',
        'show': 'Show',
        'hide': 'Hide',
        'submit_login': 'Sign in and continue',
        'submit_register': 'Create account and start',
        'verify': 'Start learning right away. Confirm your email later if you want password recovery.',
        'have_account': 'Already have an account?',
        'new': 'New here?',
        'resend': 'Verify email address',
        'privacy_intro': 'Your account details stay private.',
        'privacy': 'Privacy policy',
        'preview_title': 'Small lessons. Big progress.',
        'preview_desc': 'Learn step by step, and keep your progress in your own account.',
        'point1': 'Guided lessons',
        'point2': 'Saved progress',
        'point3': 'Practice and review',
        'home': 'Back to start',
        'language': 'Language',
        'terms': 'Terms',
        'eyebrow': 'YOUR SPACE TO LEARN',
        'eyebrow_register': 'A NEW BEGINNING',
        'journey_label': 'YOUR NEXT CHAPTER',
        'journey_title': 'Every step takes you further.',
        'journey_desc': 'Discover new words, practise in small steps and watch your progress grow.',
        'journey_one': 'Your own learning path',
        'journey_two': 'Learn when it suits you',
        'journey_three': 'Resume where you left off',
        'illustration': 'Learning path illustration. Your real progress appears once you sign in.',
        'action_hint': 'After signing in, you can continue learning right away.',
        'local_help_title': 'Cannot sign in on localhost?',
        'local_help_body': 'An account from an older release may require an owner review. Do not repeatedly create new accounts: first check your existing account status on your own Windows computer.',
        'local_help_command': 'In your installed LinguaMaster directory, run the read-only diagnostic:',
        'registration_hint': 'Start learning now. You can verify your email later to enable password recovery.',
        'private_note': 'Keep your password private; it never appears in your learning path.',
        'form_error_summary': 'Check the highlighted fields and try again.'},
 'ckb': {'signin': 'چوونەژوورەوە',
         'signup': 'دروستکردنی ئەکاونت',
         'welcome': 'بەخێربێیتەوە',
         'start': 'گەشتی فێربوونت دەست پێ بکە',
         'signin_desc': 'بچۆ ژوورەوە و لەو شوێنەوە بەردەوام بە کە ماویتەوە.',
         'signup_desc': 'ئەکاونتێک دروست بکە بۆ پاراستنی وانە و پێشکەوتنەکەت.',
         'choose': 'هەڵبژێرە چۆن بەردەوام دەبیت',
         'continue': 'دەتەوێت بچیتە',
         'safe': 'دوای چوونەژوورەوە دەگەڕێیتەوە بۆ هەمان بەش.',
         'email_or_username': 'ئیمەیڵ یان ناوی بەکارهێنەر',
         'email': 'ناونیشانی ئیمەیڵ',
         'password': 'وشەی نهێنی',
         'password1': 'وشەی نهێنی',
         'password_guidance': 'لانیکەم ٨ پیت. وشەی نهێنی تایبەت هەڵبژێرە؛ ١٥ پیت یان زیاتر پارێزراوترە.',
         'password2': 'دووبارەکردنەوەی وشەی نهێنی',
         'username': 'ناوی بەکارهێنەر',
         'age_confirmed': 'پشتڕاست دەکەمەوە کە تەمەنم بەلایەنی کەمەوە ١٦ ساڵە',
         'username_help': '٣–٣٠ پیت؛ بە پیت دەست پێ بکە.',
         'forgot': 'وشەی نهێنیت لەبیرچووە؟',
         'recover_prompt': 'یارمەتی بۆ چوونەژوورەوە:',
         'recover_steps': 'وشەی نهێنیت لەبیرچووە؟ پێویستە ئیمەیڵەکەت پشتڕاستکراوبێتەوە.',
         'show': 'پیشاندان',
         'hide': 'شاردنەوە',
         'submit_login': 'چوونەژوورەوە و بەردەوامبوون',
         'submit_register': 'دروستکردنی هەژمار و دەستپێکردن',
         'verify': 'دەتوانیت دەستبەجێ فێربوون دەست پێ بکەیت. پشتڕاستکردنەوەی ئیمەیڵ بۆ گەڕاندنەوەی وشەی نهێنی '
                   'دواتر ئیختیارییە.',
         'have_account': 'ئەکاونتت هەیە؟',
         'new': 'ئەکاونتت نییە؟',
         'resend': 'پشتڕاستکردنەوەی ئیمەیڵ',
         'privacy_intro': 'زانیارییەکانت بە نهێنی دەپارێزرێن.',
         'privacy': 'سیاسەتی تایبەتمەندی',
         'preview_title': 'وانەی بچووک، پێشکەوتنی گەورە.',
         'preview_desc': 'هەنگاو بە هەنگاو فێربە و پێشکەوتنەکەت لە ئەکاونتەکەتدا بپارێزە.',
         'point1': 'وانەی ڕێکخراو',
         'point2': 'پاراستنی پێشکەوتن',
         'point3': 'ڕاهێنان و دووبارەکردنەوە',
         'home': 'گەڕانەوە بۆ سەرەتا',
         'language': 'زمان',
         'terms': 'مەرجەکان',
         'eyebrow': 'شوێنی تایبەتی فێربوونت',
         'eyebrow_register': 'دەستپێکێکی نوێ',
         'journey_label': 'بەشی دواتری گەشتەکەت',
         'journey_title': 'هەر هەنگاوێک دەتباتە پێشەوە.',
         'journey_desc': 'وشەی نوێ بدۆزەوە، هەنگاو بە هەنگاو ڕاهێنان بکە و پێشکەوتنت ببینە.',
         'journey_one': 'ڕێڕەوی فێربوونی تایبەت بە خۆت',
         'journey_two': 'لە کاتی گونجاودا ڕاهێنان بکە',
         'journey_three': 'لەو شوێنە بەردەوام بە کە ماویتەوە',
         'illustration': 'ئەمە وێنەی ڕێڕەوە؛ پێشکەوتنی ڕاستەقینەت دوای چوونەژوورەوە دەردەکەوێت.',
         'action_hint': 'دوای چوونەژوورەوە دەتوانیت دەستبەجێ بەردەوام بیت.',
        'local_help_title': 'ناتوانیت لە لوکاڵ بچیتە ژوورەوە؟',
        'local_help_body': 'لەوانەیە هەژماری کۆنت پێویستی بە پشکنینی خاوەن وێبسایتەکە هەبێت. هەژماری نوێ دووبارە دروست مەکە؛ سەرەتا دۆخی هەژماری کۆنت لە Windows بپشکنە.',
        'local_help_command': 'لە فۆڵدەری دامەزراوی LinguaMaster ئەم فەرمانەی تەنها خوێندنەوە جێبەجێ بکە:',
         'registration_hint': 'دەستبەجێ دەست پێ بکە. بۆ گەڕاندنەوەی وشەی نهێنی دەتوانیت دواتر ئیمەیڵەکەت پشتڕاست '
                              'بکەیتەوە.',
         'private_note': 'وشەی نهێنیت بە نهێنی بهێڵەوە؛ لە ڕێڕەوی فێربووندا پیشان نادرێت.',
         'form_error_summary': 'خانە هەڵەدارەکان ڕاست بکەرەوە و دووبارە هەوڵ بدە.'},
 'ar': {'signin': 'تسجيل الدخول',
        'signup': 'إنشاء حساب',
        'welcome': 'مرحبًا بعودتك',
        'start': 'ابدأ رحلتك التعليمية',
        'signin_desc': 'سجّل دخولك وأكمل من حيث توقفت.',
        'signup_desc': 'أنشئ حسابًا لحفظ دروسك وتقدمك.',
        'choose': 'اختر كيف تريد المتابعة',
        'continue': 'ستنتقل إلى',
        'safe': 'بعد تسجيل الدخول ستعود إلى القسم الذي اخترته.',
        'email_or_username': 'البريد الإلكتروني أو اسم المستخدم',
        'email': 'البريد الإلكتروني',
        'password': 'كلمة المرور',
        'password1': 'كلمة المرور',
        'password_guidance': '٨ أحرف على الأقل. اختر كلمة مرور فريدة؛ ١٥ حرفًا أو أكثر أكثر أمانًا.',
        'password2': 'تأكيد كلمة المرور',
        'username': 'اسم المستخدم',
        'age_confirmed': 'أؤكد أن عمري 16 عامًا على الأقل',
        'username_help': 'من ٣ إلى ٣٠ حرفًا؛ ابدأ بحرف.',
        'forgot': 'هل نسيت كلمة المرور؟',
        'recover_prompt': 'هل تحتاج مساعدة في تسجيل الدخول؟',
        'recover_steps': 'نسيت كلمة المرور؟ الاستعادة تتطلب بريدًا مؤكدًا.',
        'show': 'إظهار',
        'hide': 'إخفاء',
        'submit_login': 'تسجيل الدخول والمتابعة',
        'submit_register': 'إنشاء الحساب والبدء',
        'verify': 'ابدأ التعلم فورًا. يمكنك تأكيد البريد لاحقًا لتفعيل استعادة كلمة المرور.',
        'have_account': 'لديك حساب بالفعل؟',
        'new': 'ليس لديك حساب؟',
        'resend': 'تأكيد البريد الإلكتروني',
        'privacy_intro': 'نحافظ على خصوصية بيانات حسابك.',
        'privacy': 'سياسة الخصوصية',
        'preview_title': 'دروس صغيرة. تقدم كبير.',
        'preview_desc': 'تعلم خطوة بخطوة واحتفظ بتقدمك في حسابك.',
        'point1': 'دروس منظمة',
        'point2': 'تقدم محفوظ',
        'point3': 'تدريب ومراجعة',
        'home': 'العودة للبداية',
        'language': 'اللغة',
        'terms': 'الشروط',
        'eyebrow': 'مساحتك الخاصة للتعلم',
        'eyebrow_register': 'بداية جديدة',
        'journey_label': 'فصلك التالي',
        'journey_title': 'كل خطوة تقرّبك من هدفك.',
        'journey_desc': 'اكتشف كلمات جديدة وتدرّب بخطوات صغيرة وشاهد تقدمك ينمو.',
        'journey_one': 'مسارك التعليمي الخاص',
        'journey_two': 'تدرّب في الوقت المناسب لك',
        'journey_three': 'واصل من حيث توقفت',
        'illustration': 'هذا رسم توضيحي للمسار. يظهر تقدمك الحقيقي بعد تسجيل الدخول.',
        'action_hint': 'بعد تسجيل الدخول يمكنك متابعة التعلم مباشرة.',
        'local_help_title': 'هل تعذّر تسجيل الدخول محليًا؟',
        'local_help_body': 'قد يتطلب حساب قديم مراجعة من مالك التطبيق. لا تكرر إنشاء الحساب؛ افحص حالة الحساب القديم على جهاز Windows الخاص بك أولًا.',
        'local_help_command': 'من مجلد LinguaMaster المثبت، شغّل أداة التشخيص للقراءة فقط:',
        'registration_hint': 'ابدأ التعلم مباشرة. يمكنك تأكيد البريد لاحقًا لتفعيل استعادة كلمة المرور.',
        'private_note': 'حافظ على سرية كلمة مرورك؛ لن تظهر في مسار تعلمك.',
        'form_error_summary': 'راجع الحقول المميزة وحاول مرة أخرى.'}}
AUTH_SECURITY_COPY = {'nl': {'auth_failed': 'Inloggen is niet gelukt. Controleer je gegevens of probeer wachtwoordherstel.',
        'rate_limited': 'Te veel pogingen. Probeer het over 15 minuten opnieuw.',
        'mfa_heading': 'Beveilig je aanmelding',
        'mfa_desc': 'Vul de code uit je authenticator-app in. Je kunt ook een ongebruikte herstelcode invoeren.',
        'mfa_code_label': 'Verificatie- of herstelcode',
        'mfa_code_help': '6 cijfers uit je app of een herstelcode van 16 tekens.',
        'mfa_submit': 'Controleer en ga verder',
        'mfa_failed': 'Ongeldige of al gebruikte code. Probeer een nieuwe code of herstelcode.',
        'form_error_summary': 'Controleer de gemarkeerde velden en probeer opnieuw.',
        'required': 'Vul dit veld in.',
        'invalid_email': 'Vul een geldig e-mailadres in.',
        'generic_registration': 'Als er al een account is, gebruik dan Inloggen of accountherstel. Probeer anders een andere gebruikersnaam of e-mailadres.'},
 'en': {'auth_failed': 'Sign-in failed. Check your details or use password recovery.',
        'rate_limited': 'Too many attempts. Try again in 15 minutes.',
        'mfa_heading': 'Secure your sign-in',
        'mfa_desc': 'Enter the code from your authenticator app, or use an unused recovery code.',
        'mfa_code_label': 'Verification or recovery code',
        'mfa_code_help': '6 digits from your app, or a 16-character recovery code.',
        'mfa_submit': 'Verify and continue',
        'mfa_failed': 'Invalid or already used code. Try a fresh code or a recovery code.',
        'form_error_summary': 'Check the highlighted fields and try again.',
        'required': 'This field is required.',
        'invalid_email': 'Enter a valid email address.',
        'generic_registration': 'If an account already exists, use Sign in or account recovery. Otherwise try a different username or email.'},
 'ckb': {'auth_failed': 'چوونەژوورەوە سەرکەوتوو نەبوو. زانیارییەکان بپشکنە یان گەڕاندنەوەی وشەی نهێنی تاقی بکەوە.',
         'rate_limited': 'هەوڵی زۆرت داوە. دوای ١٥ خولەک دووبارە هەوڵ بدە.',
         'mfa_heading': 'چوونەژوورەوەکەت بپارێزە',
         'mfa_desc': 'کۆدی ئەپی پشتڕاستکردنەوە بنووسە، یان کۆدی گەڕاندنەوەی بەکارنەهاتوو بەکاربهێنە.',
         'mfa_code_label': 'کۆدی پشتڕاستکردنەوە یان گەڕاندنەوە',
         'mfa_code_help': '٦ ژمارەی ئەپەکەت یان کۆدی گەڕاندنەوەی ١٦ پیت.',
         'mfa_submit': 'پشتڕاستکردنەوە و بەردەوامبوون',
         'mfa_failed': 'کۆدەکە هەڵەیە یان پێشتر بەکارهاتووە. کۆدێکی نوێ تاقی بکەرەوە.',
         'form_error_summary': 'خانە هەڵەدارەکان ڕاست بکەرەوە و دووبارە هەوڵ بدە.',
         'required': 'ئەم خانەیە پێویستە.',
         'invalid_email': 'ناونیشانی ئیمەیڵێکی دروست بنووسە.',
         'generic_registration': 'ئەگەر هەژمارەکە پێشتر هەیە، Login یان Recovery بەکاربهێنە؛ ئەگەرنا ناوی بەکارهێنەر یان ئیمەیڵێکی تر تاقی بکەرەوە.'},
 'ar': {'auth_failed': 'تعذر تسجيل الدخول. تحقق من بياناتك أو استخدم استعادة كلمة المرور.',
        'rate_limited': 'محاولات كثيرة جدًا. حاول مجددًا بعد 15 دقيقة.',
        'mfa_heading': 'أمّن تسجيل دخولك',
        'mfa_desc': 'أدخل رمز تطبيق المصادقة أو استخدم أحد رموز الاسترداد غير المستخدمة.',
        'mfa_code_label': 'رمز التحقق أو الاسترداد',
        'mfa_code_help': '6 أرقام من التطبيق أو رمز استرداد من 16 حرفًا.',
        'mfa_submit': 'تحقق وتابع',
        'mfa_failed': 'الرمز غير صالح أو سبق استخدامه. جرّب رمزًا جديدًا أو رمز استرداد.',
        'form_error_summary': 'راجع الحقول المميزة وحاول مرة أخرى.',
        'required': 'هذا الحقل مطلوب.',
        'invalid_email': 'أدخل عنوان بريد إلكتروني صالحًا.',
        'generic_registration': 'إذا كان لديك حساب بالفعل فاستخدم تسجيل الدخول أو استعادة الحساب؛ وإلا فجرب اسم مستخدم أو بريدًا آخر.'}}



# Pure UX labels; server-side POST validation does not depend on JavaScript.
SUBMIT_PROGRESS = {
    'nl': {'login': 'Bezig met inloggen…', 'register': 'Account maken…', 'verify': 'Code controleren…'},
    'en': {'login': 'Signing you in…', 'register': 'Creating your account…', 'verify': 'Checking code…'},
    'ckb': {'login': 'چوونەژوورەوە…', 'register': 'دروستکردنی هەژمار…', 'verify': 'پشکنینی کۆد…'},
    'ar': {'login': 'جارٍ تسجيل الدخول…', 'register': 'جارٍ إنشاء الحساب…', 'verify': 'جارٍ التحقق من الرمز…'},
}

def apply_form_accessibility(form):
    """Associate server-rendered help/error IDs without relying on JavaScript."""
    for name, field in form.fields.items():
        descriptions = []
        if field.help_text:
            descriptions.append('help-' + name)
        errors = form.errors.get(name, ())
        if errors:
            field.widget.attrs['aria-invalid'] = 'true'
            descriptions.extend('error-' + name + '-' + str(i) for i in range(len(errors)))
        if descriptions:
            field.widget.attrs['aria-describedby'] = ' '.join(descriptions)
    return form

FIELD_LABELS = {'email':'email_or_username', 'username':'username', 'password':'password', 'password1':'password1', 'password2':'password2', 'age_confirmed':'age_confirmed'}

def visitor_language(request, default='en'):
    selected = request.GET.get('ui', '')
    if selected in PUBLIC_LOCALES:
        if request.session.get('public_ui_language') != selected:
            request.session['public_ui_language'] = selected
        return selected
    stored = request.session.get('public_ui_language')
    if stored in PUBLIC_LOCALES:
        return stored
    # Homepage intentionally opens in Dutch. A direct login URL uses the
    # legacy English default for users with no public language preference.
    if default == 'nl':
        request.session['public_ui_language'] = 'nl'
    return default if default in PUBLIC_LOCALES else 'en'

def auth_context(request, form, destination, is_register):
    code=visitor_language(request)
    labels={**COPY[code], **AUTH_SECURITY_COPY[code]}
    from django.conf import settings
    # Registration copy must describe the *actual* server policy. Production
    # requires email verification, while local DEBUG defaults to immediate login.
    if settings.REQUIRE_EMAIL_VERIFICATION:
        labels['registration_hint'] = {
            'nl': 'Controleer na registratie je e-mail. Verifieer het adres voordat je kunt inloggen.',
            'en': 'After registration, check your email. Verify your address before signing in.',
            'ckb': 'دوای تۆمارکردن، ئیمەیڵەکەت بپشکنە. پێش چوونەژوورەوە ناونیشانەکەت پشتڕاست بکەرەوە.',
            'fr': 'Après inscription, vérifiez votre adresse e-mail avant de vous connecter.',
            'uk': 'Після реєстрації підтвердьте адресу електронної пошти перед входом.',
            'kmr': 'پشتی تۆمارکرنێ ئیمەیلا خۆ پشتڕاست بکە بەری کو بچیە ژوورێ.',
            'ar': 'بعد التسجيل، تحقق من بريدك الإلكتروني. أكّد عنوانك قبل تسجيل الدخول.',
        }.get(code, 'After registration, verify your email address before signing in.')
    for field in form.fields.values():
        field.error_messages['required']=labels['required']
        if hasattr(field, 'email') or field.__class__.__name__ == 'EmailField':
            field.error_messages['invalid']=labels['invalid_email']
    for name, key in FIELD_LABELS.items():
        if name in form.fields:
            form.fields[name].label=labels['email'] if name=='email' and is_register else labels[key]
    if 'username' in form.fields:
        form.fields['username'].help_text=labels['username_help']
    if 'password1' in form.fields:
        form.fields['password1'].help_text=labels['password_guidance']
    path=urlsplit(destination).path if destination else ''
    targets={
        reverse('play_hub'):'play', reverse('grammar_library'):'grammar',
        reverse('skill_practice', args=['listening']):'sounds',
        reverse('mistakes'):'mistakes', reverse('friends'):'friends',
        reverse('leaderboard'):'leaderboard', reverse('word'):'word',
        reverse('ai_tutor'):'ai',
    }
    key=targets.get(path)
    feature=copy_for(code).get(key, '') if key else ''
    return {'A26': labels, 'AUTH_DEST_LABEL':feature, 'UI_LANG':code,
            'UI_DIR':'rtl' if code in ('ckb','kmr','ar') else 'ltr',
            'AUTH_LOCALE':code, 'AUTH_PENDING_LABEL': SUBMIT_PROGRESS[code]['register' if is_register else 'login'], 'AUTH_MFA_PENDING_LABEL': SUBMIT_PROGRESS[code]['verify']}


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'auth_experience_v26', ['AUTH_SECURITY_COPY', 'COPY', 'SUBMIT_PROGRESS'])


SUBMIT_PROGRESS['fr'].update(login='Connexion…',register='Création du compte…',verify='Vérification du code…')
SUBMIT_PROGRESS['uk'].update(login='Вхід…',register='Створення акаунта…',verify='Перевірка коду…')
SUBMIT_PROGRESS['kmr'].update(login='چوونا ژوورێ…',register='دروستکرنا ئەکاونتێ…',verify='پشکنینا کۆدێ…')

# V76 Kurmanji Latin: temporary BETA copy for submitting authentication.
SUBMIT_PROGRESS['ku'].update(login='Têketin…',register='Hesab tê çêkirin…',verify='Piştrastkirin…')

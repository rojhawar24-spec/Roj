"""V41 Django integration regression tests (isolated test database and locmem mail).

Not end-to-end on a live SMTP server or a real browser. No existing user data touched.
"""
import re
from smtplib import SMTPException
from unittest.mock import patch
from urllib.parse import urlsplit

from django.contrib.auth import get_user_model
from django.core import mail
from django.core.cache import cache
from django.test import Client, TestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from academy.forms import RegisterForm
from academy.models import PlatformSettings

User = get_user_model()


@override_settings(MAILERS={'default': {'BACKEND': 'django.core.mail.backends.locmem.EmailBackend'}},
                   SITE_URL='http://testserver')
class V41AccountJourneyTests(TestCase):
    PASS = 'Unique-Strong-Passphrase-2026!'

    def setUp(self):
        cache.clear()
        config = PlatformSettings.load()
        config.public_registration_enabled = True
        config.save(update_fields=['public_registration_enabled'])

    def register(self, name='fresh41', email='fresh41@example.test', password=None):
        pw = password or self.PASS
        return self.client.post(reverse('register'), {
            'username': name, 'email': email, 'password1': pw,
            'password2': pw, 'age_confirmed': 'on', 'next': '/play/',
        })

    def verify_url(self, index=-1):
        match = re.search(r'https?://[^\s]+/verify/[^\s]+', mail.outbox[index].body)
        self.assertIsNotNone(match, 'Verification message was not queued')
        return urlsplit(match.group()).path

    def test_real_view_register_play_logout_login_again_without_email(self):
        self.assertEqual(self.register().status_code, 302)
        learner = User.objects.get(username='fresh41')
        self.assertTrue(learner.is_active)
        self.assertIsNone(learner.learning_profile.email_verified_at)
        self.assertEqual(len(mail.outbox), 0)
        self.assertEqual(int(self.client.session['_auth_user_id']), learner.pk)
        profile = learner.learning_profile
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.save(update_fields=['onboarding_completed', 'placement_completed'])
        self.assertEqual(self.client.get(reverse('play_hub')).status_code, 200)
        self.assertEqual(self.client.post(reverse('logout')).status_code, 302)
        self.assertNotIn('_auth_user_id', self.client.session)
        login_again = self.client.post(reverse('login'), {'email': learner.email, 'password': self.PASS})
        self.assertEqual(login_again['Location'], reverse('play_hub'))
        self.assertEqual(int(self.client.session['_auth_user_id']), learner.pk)

    def test_new_password_policy_accepts_eight_but_rejects_seven(self):
        eight = 'R7!pQ2z@'
        seven = 'R7!pQ2z'
        self.assertEqual(len(eight), 8)
        self.assertEqual(len(seven), 7)
        accepted = self.register(name='allowed_8_41', email='allowed8@example.test', password=eight)
        self.assertEqual(accepted.status_code, 302)
        self.assertTrue(User.objects.filter(username='allowed_8_41').exists())
        self.client.post(reverse('logout'))
        rejected = self.register(name='denied_7_41', email='denied7@example.test', password=seven)
        self.assertEqual(rejected.status_code, 200)
        self.assertFalse(User.objects.filter(username='denied_7_41').exists())
        self.assertIn('minlength="8"', rejected.content.decode())
        self.assertTrue(RegisterForm(data={
            'username': 'strong41', 'email':'strong41@example.test',
            'password1': self.PASS, 'password2': self.PASS, 'age_confirmed': True,
        }).is_valid())

    def test_existing_legacy_8_character_password_still_signs_in(self):
        user = User.objects.create_user('legacy41', 'legacy41@example.test', '8uniQ!23')
        profile = user.learning_profile
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.save(update_fields=['onboarding_completed','placement_completed'])
        self.assertTrue(user.check_password('8uniQ!23'))
        response = self.client.post(reverse('login'), {'email':user.username,'password':'8uniQ!23'})
        self.assertEqual(response.status_code, 302)
        self.assertEqual(int(self.client.session['_auth_user_id']), user.pk)

    def test_signup_does_not_contact_mailer(self):
        with patch('academy.views.send_mail', side_effect=SMTPException('synthetic-gateway-failure')):
            response = self.register()
        self.assertEqual(response.status_code, 302)
        learner = User.objects.get(username='fresh41')
        self.assertTrue(learner.is_active)
        self.assertEqual(self.client.get(reverse('resend_verification')).status_code, 200)

    def test_duplicate_registration_does_not_change_existing_account(self):
        registered = User.objects.create_user('registered41','registered41@example.test',self.PASS)
        result = self.register(name='new41',email=registered.email)
        self.assertEqual(result['Location'], reverse('login'))
        self.assertFalse(User.objects.filter(username='new41').exists())
        self.assertEqual(mail.outbox, [])

    def test_suspended_account_cannot_verify_email_even_with_valid_token(self):
        self.register()
        user = User.objects.get(username='fresh41')
        self.client.post(reverse('resend_verification'), {'email':user.email})
        link = self.verify_url()
        profile = user.learning_profile
        profile.suspended_at = timezone.now()
        profile.save(update_fields=['suspended_at'])
        self.assertEqual(self.client.post(link).status_code, 302)
        profile.refresh_from_db()
        self.assertIsNone(profile.email_verified_at)

    def test_private_auth_pages_stay_noncached_and_localized(self):
        for language in ('nl','en','ckb','ar'):
            response=self.client.get(reverse('register'), {'ui': language})
            self.assertEqual(response.status_code,200)
            self.assertIn('no-store',response['Cache-Control'])
            self.assertContains(response,'csrfmiddlewaretoken')
            self.assertContains(response,'autocomplete="new-password"')
            self.assertContains(response, 'dir="rtl"' if language in ('ckb','ar') else 'dir="ltr"')

    def test_invalid_password_no_mail_or_account(self):
        invalid = self.register(password='Tiny123!')
        self.assertEqual(invalid.status_code, 200)
        self.assertFalse(User.objects.filter(username='fresh41').exists())
        self.assertEqual(len(mail.outbox), 0)

    def test_unknown_address_resend_and_reset_are_generic(self):
        resend=self.client.post(reverse('resend_verification'),{'email':'unknown41@example.test'})
        self.assertEqual(resend.status_code,302)
        reset=self.client.post(reverse('password_reset'),{'email':'unknown41@example.test'})
        self.assertEqual(reset.status_code,302)
        self.assertEqual(len(mail.outbox),0)

"""Non-admin, allowlisted content workspace for authorized Rozh Managers.

No GET writes, no delete endpoint, no role/permission models, and no user
supplied model names/field lists. Existing progression remains server owned.
"""
import json
from django import forms
from django.core.exceptions import ValidationError
from .quality_rules import check_exercise
from django.core.paginator import Paginator
from django.contrib import messages
from django.core.serializers.json import DjangoJSONEncoder
from django.db import transaction
from django.forms.models import model_to_dict, modelform_factory
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods, require_GET
from .manager_roles_v48 import manager_only
from .models import (Language, Level, LearningSeason, Unit, Lesson, Exercise,
                     GrammarTopic, Vocabulary, ContentRevision, AuditEvent, PlatformSettings)
from .manager_i18n_v47 import for_user

# Allowlisted fields only: no user, credential, privilege, reward or progress editing.
EDITORS = {
 'language': (Language, ('code','name','slug','description','is_published')),
 'level': (Level, ('language','code','description','order')),
 'season': (LearningSeason, ('level','slug','title','description','order','theme','published')),
 'unit': (Unit, ('level','season','slug','title','summary','order','published')),
 'lesson': (Lesson, ('unit','slug','title','skill','content','audio_text','order','published')),
 'exercise': (Exercise, ('lesson','kind','prompt','options','answer','activity_data','explanation','difficulty','order')),
 'grammar': (GrammarTopic, ('level','slug','title','explanation','examples','exceptions','common_mistakes','audio_text','check_question','check_options','check_answer','published')),
 'vocabulary': (Vocabulary, ('level','word','translation','pronunciation','example','word_family','usage_notes','emoji','published')),
}

class ManagerAIToggleForm(forms.ModelForm):
    class Meta:
        model = PlatformSettings
        fields = ('ai_enabled','ai_emergency_stop')
    def clean(self):
        data = super().clean()
        if (data.get('ai_enabled') and not data.get('ai_emergency_stop')
                and self.instance.ai_monthly_budget_eur <= 0):
            self.add_error('ai_enabled', 'The owner must configure a positive AI budget before live AI can be enabled.')
        return data


# Editing relational identity after students complete lessons may orphan progress
# and invalidate previously issued links. Managers can change content, not IDs.
IMMUTABLE_ON_EDIT = {
 'language': ('code','slug'), 'level': ('language','code'),
 'season': ('level','slug'), 'unit': ('level','slug'),
 'lesson': ('unit','slug'), 'exercise': ('lesson',),
 'grammar': ('level','slug'), 'vocabulary': ('level','word'),
}

def _editor(kind, existing=False):
    try:
        model, fields = EDITORS[kind]
    except KeyError:
        raise Http404('Unknown content area')
    if existing:
        immutable = IMMUTABLE_ON_EDIT[kind]
        fields = tuple(field for field in fields if field not in immutable)
    # Django must construct ModelForm fields at class creation, not after it.
    return model, modelform_factory(model, fields=fields)


CONTENT_COPY = {
 'en': dict(new='Create new', edit='Edit', save='Save changes', saved='Content saved.', back='Back to content', latest='30 records per page', empty='No records yet.', note='Updates are validated server-side and recorded in the audit log.', records='records', identity_locked='{content}'),
 'nl': dict(new='Nieuw toevoegen', edit='Bewerken', save='Wijzigingen opslaan', saved='Inhoud opgeslagen.', back='Terug naar inhoud', latest='30 resultaten per pagina', empty='Er zijn nog geen items.', note='Wijzigingen worden op de server gecontroleerd en vastgelegd in het auditlogboek.', records='items', identity_locked='{content}'),
 'ckb': dict(new='زیادکردنی نوێ', edit='دەستکاریکردن', save='پاشەکەوتکردنی گۆڕانکاری', saved='ناوەڕۆک پاشەکەوت کرا.', back='گەڕانەوە بۆ ناوەڕۆک', latest='٣٠ تۆمار لە هەر لاپەڕەیەکدا', empty='هێشتا هیچ تۆمارێک نییە.', note='گۆڕانکارییەکان لە سێرڤەر دەپشکنرێن و لە تۆماری چاودێریدا تۆمار دەکرێن.', records='تۆمار', identity_locked='{content}'),
 'ar': dict(new='إضافة جديد', edit='تعديل', save='حفظ التغييرات', saved='تم حفظ المحتوى.', back='العودة للمحتوى', latest='٣٠ سجلًا في كل صفحة', empty='لا توجد سجلات بعد.', note='يتم التحقق من التغييرات على الخادم وتسجيلها في سجل التدقيق.', records='سجل', identity_locked='{content}'),
}
CONTENT_LABELS = {
 'en':dict(language='Languages',level='CEFR levels',season='Seasons',unit='Units',lesson='Lessons',exercise='Exercises',grammar='Grammar',vocabulary='Vocabulary'),
 'nl':dict(language='Talen',level='CEFR-niveaus',season='Seizoenen',unit='Units',lesson='Lessen',exercise='Oefeningen',grammar='Grammatica',vocabulary='Vocabulaire'),
 'ckb':dict(language='زمانەکان',level='ئاستەکانی CEFR',season='وەرزەکان',unit='یەکەکان',lesson='وانەکان',exercise='ڕاهێنانەکان',grammar='ڕێزمان',vocabulary='وشەکان'),
 'ar':dict(language='اللغات',level='مستويات CEFR',season='المواسم',unit='الوحدات',lesson='الدروس',exercise='التمارين',grammar='القواعد',vocabulary='المفردات'),
}

def _base(request, kind):
    lang=request.user.learning_profile.ui_language
    if lang not in CONTENT_COPY:lang='en'
    return {**for_user(request.user), 'R48_OWNER':request.user.is_superuser,
            'C48':CONTENT_COPY[lang], 'C48_TITLE':CONTENT_LABELS[lang][kind]}


@never_cache
@manager_only
@require_GET
def content_list(request, kind):
    model, _ = _editor(kind)
    term=request.GET.get('q','').strip()[:100]
    search_field = {'language':'name','level':'description','season':'title',
                    'unit':'title','lesson':'title','exercise':'prompt',
                    'grammar':'title','vocabulary':'word'}[kind]
    qs=model.objects.all().order_by('-pk')
    if term:
        qs=qs.filter(**{search_field+'__icontains':term})
    page=Paginator(qs, 30).get_page(request.GET.get('page', 1))
    return render(request, 'academy/manager_content_list_v48.html', {
        **_base(request, kind), 'kind':kind, 'records':page.object_list,'page':page,'search':term,
        'total':qs.count(), 'model_name':model._meta.verbose_name_plural,
    })


@never_cache
@manager_only
@require_http_methods(['GET','POST'])
@transaction.atomic
def content_edit(request, kind, pk=None):
    model, Form = _editor(kind, existing=pk is not None)
    # Row-level lock prevents two editors silently clobbering each other.
    instance = get_object_or_404(model.objects.select_for_update(), pk=pk) if pk is not None else None
    publication_flag = 'is_published' if kind == 'language' else ('published' if kind in ('season', 'unit', 'lesson', 'grammar', 'vocabulary') else None)
    # Capture the saved state before ModelForm validation mutates instance.
    was_published = bool(getattr(instance, publication_flag, False)) if publication_flag else False
    form = Form(request.POST or None, instance=instance)
    if kind == 'exercise':
        from .mixed_policy_v102 import editorial_kind_choices
        field = form.fields['kind']
        field.choices = editorial_kind_choices(field.choices, getattr(instance, 'kind', None))
    if request.method == 'POST' and form.is_valid():
        obj = form.save(commit=False)
        # Never publish content that fails the actual learner-quality rules.
        # Model clean() alone cannot validate MCQ keys against their options.
        if kind == 'exercise':
            for severity, code, detail in check_exercise(obj.kind, obj.prompt,
                    obj.options, obj.answer, obj.explanation, obj.activity_data):
                if severity == 'error':
                    form.add_error('prompt', detail)
        if kind == 'exercise' and obj.kind == 'mcq':
            from .mixed_policy_v102 import canonical_mcq_errors
            for detail in canonical_mcq_errors(obj.prompt, obj.options, obj.answer, obj.explanation, obj.activity_data):
                form.add_error('prompt', detail)
        if kind == 'exercise' and obj.lesson.published:
            from .mixed_policy_v102 import canonical_exercise_block_reason
            if canonical_exercise_block_reason(obj, obj.lesson.unit.level.language.code):
                form.add_error('kind', 'Convert to a valid supported exercise or unpublish the lesson.')
        if kind == 'exercise' and obj.kind == 'listening' and obj.lesson.published:
            # Exercises have no own publication flag; a save to a live lesson
            # becomes immediately visible. Require approved licensed audio.
            from .lesson_activities_v58 import student_ready
            if not student_ready(obj, obj.lesson.unit.level.language.code):
                form.add_error('activity_data',
                    'Published listening exercises require a verified, teacher-approved recording. Unpublish the lesson to continue drafting.')
        if kind == 'lesson' and obj.published:
            from .mixed_policy_v102 import publication_has_canonical_exercises
            kinds = obj.exercises.values_list('kind', flat=True) if obj.pk else ()
            if not publication_has_canonical_exercises(kinds):
                form.add_error('published', 'Save a draft first, then add at least one of the five supported exercises before publishing.')
        if kind == 'lesson' and obj.published and instance is not None:
            # An unpublished draft may contain incomplete authored activities.
            # Publishing a lesson containing those activities used to succeed
            # here, then fail for every learner with HTTP 409 on opening it.
            from .lesson_activities_v58 import published_lesson_activity_errors
            issues = published_lesson_activity_errors(
                obj.exercises.all(), obj.unit.level.language.code)
            if issues:
                form.add_error('published',
                    'Fix the authored exercises before publishing: ' + '; '.join(issues[:3]))
        if kind == 'lesson' and obj.published and obj.pk:
            from .lesson_readiness_v96 import lesson_block_reason
            if lesson_block_reason(obj, exercises=obj.exercises.all()):
                form.add_error('published', 'The lesson must contain only valid, ready supported questions.')
        if kind == 'lesson' and obj.published and obj.skill == 'listening':
            from .audio_v78 import approved_audio_url
            if not approved_audio_url(obj.audio_text, obj.unit.level.language.code):
                form.add_error('audio_text',
                    'A published listening lesson requires a verified, teacher-approved recording.')
        if kind == 'lesson' and obj.published and not obj.content.strip():
            form.add_error('content', 'A published lesson needs teaching content.')
        if kind == 'vocabulary' and obj.published and not obj.translation.strip():
            form.add_error('translation', 'Published vocabulary needs a translation.')
        if kind == 'grammar' and obj.published and obj.check_options and obj.check_answer not in obj.check_options:
            form.add_error('check_answer', 'The correct answer must appear in the options.')
        if not form.errors:
            if instance is not None and hasattr(obj, 'content_version'):
                obj.content_version = instance.content_version + 1
            try:
                obj.full_clean()
            except ValidationError as exc:
                # Some ModelForm edit views deliberately omit immutable fields.
                # Surface cross-field errors without trying to attach them to
                # excluded fields, which would otherwise cause a server error.
                form.add_error(None, '; '.join(str(message) for message in exc.messages)[:400])
        if not form.errors:
            obj.save()
            form.save_m2m()
            if hasattr(obj, 'content_version'):
                snapshot = json.loads(json.dumps(model_to_dict(obj), cls=DjangoJSONEncoder))
                ContentRevision.objects.create(model_label=obj._meta.label, object_pk=obj.pk,
                    version=obj.content_version, editor=request.user, snapshot=snapshot)
            AuditEvent.objects.create(actor=request.user, action='manager_content_saved',
                                      target=f'{obj._meta.label}:{obj.pk}')
            if publication_flag and was_published != bool(getattr(obj, publication_flag)):
                AuditEvent.objects.create(
                    actor=request.user,
                    action=('manager_content_published' if getattr(obj, publication_flag)
                            else 'manager_content_unpublished'),
                    target=f'{obj._meta.label}:{obj.pk}',
                )
            messages.success(request, CONTENT_COPY.get(request.user.learning_profile.ui_language, CONTENT_COPY['en'])['saved'])
            return redirect(reverse('manager_content_edit', args=[kind, obj.pk]))
    return render(request, 'academy/manager_content_edit_v48.html', {
        **_base(request, kind), 'kind':kind, 'form':form, 'record':instance,
        'model_name':model._meta.verbose_name,
    }, status=200)


@never_cache
@manager_only
@require_GET
def audit_log_page(request):
    """Actual paginated audit history, no secrets or free-form metadata."""
    events = (AuditEvent.objects.select_related('actor').defer('metadata')
              .order_by('-created_at', '-pk'))
    page = Paginator(events, 30).get_page(request.GET.get('page', '1'))
    return render(request, 'academy/manager_audit_v49.html', {
        **for_user(request.user), 'page': page, 'events': page.object_list,
        'R48_OWNER': request.user.is_superuser,
    })


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'manager_content_v48', ['CONTENT_COPY', 'CONTENT_LABELS'])

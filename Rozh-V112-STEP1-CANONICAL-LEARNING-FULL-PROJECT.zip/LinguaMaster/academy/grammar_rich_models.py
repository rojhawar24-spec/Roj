"""Optional rich content adds presentation without changing existing answer keys."""
from django.db import models
from .rich_schema import normalize_article, validate_article


class GrammarArticle(models.Model):
    topic = models.OneToOneField('academy.GrammarTopic', on_delete=models.CASCADE, related_name='article')
    content = models.JSONField(default=dict, blank=True, validators=[validate_article],
        help_text='Plain-text structured article. See docs/GRAMMAR_AUTHORING_V10.md for the JSON format.')
    updated_at = models.DateTimeField(auto_now=True)

    def clean(self):
        super().clean()
        self.content = normalize_article(self.content)

    def save(self, *args, **kwargs):
        self.full_clean()
        return super().save(*args, **kwargs)

    def __str__(self):
        return str(self.topic)

"""Static presentation text for the Solar Atlas profile and avatar screens.

No external services, database writes, third-party assets, or changed permissions.
"""

COPY = {
 'nl': {
  'eyebrow':'JOUW LEERWERELD', 'subtitle':'Een plek om te groeien, op jouw ritme.',
  'today':'Vandaag', 'total':'Totale XP', 'course_stage':'Cursusniveau', 'daily_goal':'Dagdoel',
  'progress':'Jouw voortgang', 'identity':'Jouw identiteit', 'identity_note':'Kies een avatar en vertel iets over jezelf.',
  'learning':'Jouw leerplan', 'learning_note':'Pas je taal en je dagelijkse doel aan. Je voortgang blijft van jou.',
  'privacy_choices':'Privacy & toestemming', 'privacy_note':'Deze keuzes blijven uit totdat je ze inschakelt.',
  'appearance':'Weergave & tijdzone', 'appearance_note':'Licht, donker of automatisch. Minder beweging is altijd mogelijk.',
  'security':'Beveiliging', 'verified':'E-mailadres bevestigd', 'not_verified':'E-mailadres nog niet bevestigd',
  'account_tools':'Account en gegevens', 'account_tools_note':'Download je eigen gegevens of beheer je account.',
  'go_to_learning':'Verder leren', 'profile_settings':'Instellingen', 'avatar_cta':'Open avatarstudio',
  'password':'Wachtwoord herstellen', 'delete_warning':'Account verwijderen is een aparte beveiligde stap.',
  'save_hint':'Wijzigingen worden pas bewaard wanneer je op Opslaan klikt.',
  'week':'Afgelopen zeven dagen', 'xp_day':'XP vandaag', 'xp_total':'Totale XP',
  'save_error':'Controleer de gemarkeerde invoervelden en probeer opnieuw.',
  'back_profile':'Terug naar profiel', 'avatar_title':'Jouw avatar, jouw verhaal',
  'avatar_note':'Maak je karakter uniek. Vergrendelde decoraties blijven beschermd.',
  'avatar_safe':'Alleen je gekozen avatar verandert. Je XP, lessen en vrienden blijven bewaard.',
  'current_choice':'Huidige avatar', 'account_email':'E-mailadres', 'role_status':'Persoonlijke leeromgeving',
 },
 'en': {
  'eyebrow':'YOUR LEARNING WORLD', 'subtitle':'A place to grow, at your own pace.',
  'today':'Today', 'total':'Total XP', 'course_stage':'Course level', 'daily_goal':'Daily goal',
  'progress':'Your progress', 'identity':'Your identity', 'identity_note':'Choose an avatar and introduce yourself.',
  'learning':'Your learning plan', 'learning_note':'Change your language and daily goal. Your progress remains yours.',
  'privacy_choices':'Privacy & consent', 'privacy_note':'These options stay off until you enable them.',
  'appearance':'Appearance & timezone', 'appearance_note':'Light, dark or automatic. Reduce motion whenever you wish.',
  'security':'Security', 'verified':'Email verified', 'not_verified':'Email not yet verified',
  'account_tools':'Account & data', 'account_tools_note':'Export your data or manage your account.',
  'go_to_learning':'Keep learning', 'profile_settings':'Settings', 'avatar_cta':'Open avatar studio',
  'password':'Reset password', 'delete_warning':'Deleting your account is a separate protected step.',
  'save_hint':'Changes are only stored after you press Save.',
  'week':'Last seven days', 'xp_day':'XP today', 'xp_total':'Total XP',
  'save_error':'Review the highlighted fields and try again.',
  'back_profile':'Back to profile', 'avatar_title':'Your avatar, your story',
  'avatar_note':'Make your character yours. Locked decorations remain protected.',
  'avatar_safe':'Only your chosen avatar changes. XP, lessons and friends stay intact.',
  'current_choice':'Current avatar', 'account_email':'Email address', 'role_status':'Personal learning space',
 },
 'ckb': {
  'eyebrow':'جیهانی فێربوونی تۆ', 'subtitle':'شوێنێک بۆ گەشەکردن، بە خێرایی خۆت.',
  'today':'ئەمڕۆ', 'total':'کۆی XP', 'course_stage':'ئاستی کۆرس', 'daily_goal':'ئامانجی ڕۆژانە',
  'progress':'پێشکەوتنی تۆ', 'identity':'ناسنامەی تۆ', 'identity_note':'ئەڤاتارێک هەڵبژێرە و کەمێک دەربارەی خۆت بنووسە.',
  'learning':'پلانی فێربوونت', 'learning_note':'زمان و ئامانجی ڕۆژانەت بگۆڕە. پێشکەوتنەکەت دەپارێزرێت.',
  'privacy_choices':'تایبەتمەندی و ڕەزامەندی', 'privacy_note':'ئەم هەڵبژاردنانە تا چالاکیان نەکەیت ناچالاک دەمێنن.',
  'appearance':'ڕووکار و ناوچەی کاتی', 'appearance_note':'ڕوون، تاریک یان خۆکار. دەتوانیت جووڵە کەم بکەیتەوە.',
  'security':'پاراستنی هەژمار', 'verified':'ئیمەیڵ پشتڕاستکراوەتەوە', 'not_verified':'ئیمەیڵ هێشتا پشتڕاست نەکراوەتەوە',
  'account_tools':'هەژمار و داتا', 'account_tools_note':'داتاکانت دابگرە یان هەژمارەکەت بەڕێوەببە.',
  'go_to_learning':'بەردەوام بە لە فێربوون', 'profile_settings':'ڕێکخستنەکان', 'avatar_cta':'ستۆدیۆی ئەڤاتار بکەرەوە',
  'password':'گۆڕینی وشەی نهێنی', 'delete_warning':'سڕینەوەی هەژمار هەنگاوێکی جیاواز و پارێزراوە.',
  'save_hint':'گۆڕانکارییەکان تەنها دوای کرتەکردن لەسەر پاشەکەوت دەنووسرێن.',
  'week':'حەوت ڕۆژی ڕابردوو', 'xp_day':'XPی ئەمڕۆ', 'xp_total':'کۆی XP',
  'save_error':'خانە نادروستەکان بپشکنە و دووبارە هەوڵ بدە.',
  'back_profile':'گەڕانەوە بۆ پرۆفایل', 'avatar_title':'ئەڤاتاری تۆ، چیرۆکی تۆ',
  'avatar_note':'کاراکتەرەکەت تایبەت بکە. جوانکارییە قوفڵکراوەکان پارێزراون.',
  'avatar_safe':'تەنها ئەڤاتارەکەت دەگۆڕێت. XP و وانە و هاوڕێکانت دەپارێزرێن.',
  'current_choice':'ئەڤاتاری ئێستا', 'account_email':'ناونیشانی ئیمەیڵ', 'role_status':'شوێنی تایبەتی فێربوون',
 },
 'ar': {
  'eyebrow':'عالم تعلمك', 'subtitle':'مكان لتنمو فيه وفق وتيرتك.',
  'today':'اليوم', 'total':'إجمالي XP', 'course_stage':'مستوى الدورة', 'daily_goal':'الهدف اليومي',
  'progress':'تقدمك', 'identity':'هويتك', 'identity_note':'اختر صورة رمزية وعرّف بنفسك.',
  'learning':'خطة التعلم', 'learning_note':'غيّر اللغة والهدف اليومي دون فقدان تقدمك.',
  'privacy_choices':'الخصوصية والموافقة', 'privacy_note':'تبقى هذه الخيارات معطلة حتى تفعّلها.',
  'appearance':'المظهر والمنطقة الزمنية', 'appearance_note':'فاتح أو داكن أو تلقائي. يمكنك تقليل الحركة.',
  'security':'أمان الحساب', 'verified':'تم تأكيد البريد الإلكتروني', 'not_verified':'لم يتم تأكيد البريد بعد',
  'account_tools':'الحساب والبيانات', 'account_tools_note':'صدّر بياناتك أو أدر حسابك.',
  'go_to_learning':'تابع التعلم', 'profile_settings':'الإعدادات', 'avatar_cta':'افتح استوديو الشخصية',
  'password':'إعادة تعيين كلمة المرور', 'delete_warning':'حذف الحساب إجراء محمي منفصل.',
  'save_hint':'لن تُحفظ التغييرات حتى تضغط على زر الحفظ.',
  'week':'آخر سبعة أيام', 'xp_day':'نقاط اليوم', 'xp_total':'مجموع XP',
  'save_error':'راجع الحقول التي تحتوي أخطاء وحاول مجددًا.',
  'back_profile':'العودة إلى الملف', 'avatar_title':'صورتك، قصتك',
  'avatar_note':'خصص شخصيتك. تظل الزينة المقفلة محمية.',
  'avatar_safe':'تتغير الصورة فقط. تبقى نقاطك ودروسك وأصدقاؤك.',
  'current_choice':'الصورة الحالية', 'account_email':'البريد الإلكتروني', 'role_status':'مساحة التعلم الشخصية',
 },
}


def for_language(language):
    """Return only vetted static UI strings, with English fallback."""
    return COPY.get(language, COPY['en'])


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'solar_profile_copy', ['COPY'])

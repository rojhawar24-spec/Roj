"""Minimal, deterministic practice feedback. NOT CEFR assessment or pronunciation scoring.

This module deliberately has no Django dependency, so it can be tested offline.
"""
import re
import unicodedata
from difflib import SequenceMatcher


def normalize(value):
    if not isinstance(value, str):
        return ''
    value = unicodedata.normalize('NFKC', value).casefold()
    value = ''.join(ch for ch in value if not unicodedata.category(ch).startswith('P'))
    return ' '.join(value.split())


def evaluate_speaking(transcript, reference):
    """Text-transcript similarity only; cannot evaluate pronunciation or accent."""
    spoken = normalize(transcript)
    target = normalize(reference)
    if not spoken or not target:
        return 0, 'Say the example or enter what you said to get a transcript comparison.'
    if len(spoken) > 800:
        return 0, 'Your transcript is too long for this short exercise.'
    ratio = SequenceMatcher(None, spoken, target, autojunk=False).ratio()
    score = round(ratio * 100)
    if score >= 85:
        return score, 'Your transcript is close to the example. This is not a pronunciation assessment.'
    if score >= 60:
        return score, 'Some words differ. Listen again and compare your word order.'
    return score, 'Try the example again. Compare the words and their order.'


def evaluate_writing(text, target_word):
    """Basic form and vocabulary cues, not grammar correctness or CEFR proficiency."""
    if not isinstance(text, str) or len(text) > 2000:
        return 0, 'Use at most 2,000 characters.'
    words = re.findall(r"\b[\wÀ-ÿ]+(?:['’-][\wÀ-ÿ]+)*\b", text, flags=re.UNICODE)
    normalized_target = normalize(target_word)
    target_found = bool(normalized_target) and any(normalize(word) == normalized_target for word in words)
    if not text.strip():
        return 0, 'Write one complete sentence before checking.'
    parts = [
        (40 if len(words) >= 6 else 0, 'Use at least six words in your sentence.'),
        (35 if target_found else 0, f'Use the target word “{target_word}”.'),
        (15 if text.rstrip().endswith(('.', '!', '?')) else 0, 'End your sentence with punctuation.'),
        (10 if text.lstrip()[:1].isupper() else 0, 'Start your sentence with a capital letter.'),
    ]
    score = sum(points for points, _ in parts)
    suggestions = [suggestion for points, suggestion in parts if not points]
    if not suggestions:
        return score, 'Form check passed. Your grammar and meaning have NOT been independently verified.'
    return score, ' '.join(suggestions) + ' Grammar and meaning have NOT been independently verified.'

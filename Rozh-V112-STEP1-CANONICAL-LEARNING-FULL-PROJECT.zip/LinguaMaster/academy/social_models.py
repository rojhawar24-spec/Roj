"""Cosmetic-only gifts: learning XP never changes hands."""
from django.conf import settings
from django.db import models
from django.utils import timezone


class SocialGift(models.Model):
    KINDS = [('star', 'Star frame'), ('forest', 'Forest background'), ('confetti', 'Celebration badge')]
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='gifts_sent')
    recipient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='gifts_received')
    kind = models.CharField(max_length=12, choices=KINDS)
    sent_day = models.DateField(default=timezone.localdate)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ['-created_at', '-pk']
        constraints = [
            models.UniqueConstraint(fields=['sender', 'recipient', 'sent_day'], name='one_friend_gift_per_day'),
            models.CheckConstraint(condition=~models.Q(sender=models.F('recipient')), name='no_gift_to_self'),
        ]


class AvatarStyle(models.Model):
    PALETTES = [('sky', 'Sky'), ('lavender', 'Lavender'), ('sand', 'Sand'), ('forest', 'Forest')]
    ACCESSORIES = [('none', 'None'), ('star', 'Star frame'), ('confetti', 'Celebration badge')]
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='avatar_style')
    palette = models.CharField(max_length=12, choices=PALETTES, default='sky')
    accessory = models.CharField(max_length=12, choices=ACCESSORIES, default='none')
    updated_at = models.DateTimeField(auto_now=True)

"""Purpose-specific, state-bound email activation tokens.

Unlike Django's generic password-reset tokens, verification URLs include the
account-state generation. They cannot be replayed after a manager action.
The generic token generator remains unchanged for Django Password Reset.
"""
from django.contrib.auth.tokens import PasswordResetTokenGenerator
from django.core.exceptions import ObjectDoesNotExist


class EmailVerificationTokenGenerator(PasswordResetTokenGenerator):
    key_salt = 'linguamaster.email-activation.v36'

    def _make_hash_value(self, user, timestamp):
        base = super()._make_hash_value(user, timestamp)
        try:
            profile = user.learning_profile
        except ObjectDoesNotExist:
            # The verification endpoint requires a profile, so this token alone
            # cannot activate an account without one.
            return f'{base}|missing-profile'
        verified = profile.email_verified_at.isoformat() if profile.email_verified_at else ''
        suspended = profile.suspended_at.isoformat() if profile.suspended_at else ''
        return (f'{base}|active:{int(user.is_active)}|verified:{verified}'
                f'|suspended:{suspended}|review:{int(profile.legacy_review_required)}'
                f'|generation:{profile.email_verification_version}')


email_verification_token_generator = EmailVerificationTokenGenerator()

"""Django integration tests; isolated test DB, no real user records."""
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.management import call_command
from django.core.management.base import CommandError
from django.test import TestCase, RequestFactory
from django.urls import reverse
from django.utils import timezone
from .models import Profile, Language, AuditEvent, PlatformSettings
from .manager_roles_v48 import MANAGER_GROUP, is_delegated_manager
from .views import _after_sign_in

class ManagerRoleTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.manager = get_user_model().objects.create_user('v48manager', 'v48manager@example.invalid', 'OnlyForDjangoTest_48!')
        cls.learner = get_user_model().objects.create_user('v48learner', 'v48learner@example.invalid', 'OnlyForDjangoTest_48!')
        cls.staff = get_user_model().objects.create_user('v48staff', 'v48staff@example.invalid', 'OnlyForDjangoTest_48!', is_staff=True)
        for user in (cls.manager, cls.learner, cls.staff):
            profile, _ = Profile.objects.get_or_create(user=user)
            profile.email_verified_at = timezone.now()
            profile.totp_secret = 'JBSWY3DPEHPK3PXP'
            profile.save(update_fields=['email_verified_at', 'totp_secret'])

    def verify_manager(self):
        self.client.force_login(self.manager)
        session = self.client.session
        session['mfa_verified_id'] = self.manager.pk
        session.save()

    def test_role_assignment_does_not_grant_django_admin(self):
        call_command('grant_rozh_manager','--username=v48manager','--grant',verbosity=0)
        self.manager.refresh_from_db()
        self.assertTrue(is_delegated_manager(self.manager))
        self.assertFalse(self.manager.is_staff)
        self.assertFalse(self.manager.is_superuser)
        self.verify_manager()
        self.assertEqual(self.client.get(reverse('manager')).status_code,200)
        self.assertEqual(self.client.get('/secure-admin/').status_code,302)

    def test_without_mfa_manager_denied(self):
        Group.objects.get_or_create(name=MANAGER_GROUP)[0].user_set.add(self.manager)
        self.client.force_login(self.manager)
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)
        self.assertEqual(self.client.get(reverse('manager_content_list',args=['season'])).status_code,403)

    def test_staff_cannot_use_manager_group(self):
        group, _ = Group.objects.get_or_create(name=MANAGER_GROUP)
        group.user_set.add(self.staff)
        self.client.force_login(self.staff)
        session=self.client.session;session['mfa_verified_id']=self.staff.pk;session.save()
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)

    def test_manager_cannot_promote_delete_or_change_privileged_accounts(self):
        Group.objects.get_or_create(name=MANAGER_GROUP)[0].user_set.add(self.manager)
        self.verify_manager()
        for action in ('promote','demote','delete','approve_legacy'):
            self.assertEqual(self.client.post(reverse('manager_user_action',args=[self.learner.pk,action])).status_code,403)
        self.assertEqual(self.client.post(reverse('manager_user_action',args=[self.staff.pk,'block'])).status_code,403)
        self.assertEqual(self.client.post(reverse('manager_award')).status_code,403)
        self.learner.refresh_from_db()
        self.assertTrue(self.learner.is_active)

    def test_manager_can_suspend_and_restore_only_verified_learner(self):
        Group.objects.get_or_create(name=MANAGER_GROUP)[0].user_set.add(self.manager)
        self.verify_manager()
        self.assertEqual(self.client.post(reverse('manager_user_action',args=[self.learner.pk,'block'])).status_code,302)
        self.learner.refresh_from_db();self.assertFalse(self.learner.is_active)
        self.assertEqual(self.client.post(reverse('manager_user_action',args=[self.learner.pk,'unblock'])).status_code,302)
        self.learner.refresh_from_db();self.assertTrue(self.learner.is_active)

    def test_manager_editor_is_real_and_private(self):
        Group.objects.get_or_create(name=MANAGER_GROUP)[0].user_set.add(self.manager)
        self.verify_manager()
        list_url=reverse('manager_content_list',args=['language'])
        self.assertEqual(self.client.get(list_url).status_code,200)
        self.assertEqual(self.client.get(reverse('manager_content_list',args=['not-a-model'])).status_code,404)
        add=reverse('manager_content_new',args=['language'])
        self.assertEqual(self.client.post(add, {'code':'v48','slug':'v48-language','name':'V48 language','description':'testing','is_published':'on'}).status_code,302)
        record=Language.objects.get(code='v48')
        self.assertTrue(record.is_published)
        self.assertTrue(AuditEvent.objects.filter(actor=self.manager,action='manager_content_saved').exists())
        self.assertEqual(self.client.get(reverse('manager_content_edit',args=['language',record.pk])).status_code,200)
        # A forged POST cannot silently rewrite the language URL identity.
        edit_url=reverse('manager_content_edit', args=['language',record.pk])
        self.assertEqual(self.client.post(edit_url, {'code':'hijack','slug':'hijack',
            'name':'Updated label','description':'testing','is_published':'on'}).status_code,302)
        record.refresh_from_db()
        self.assertEqual(record.code,'v48')
        self.assertEqual(record.slug,'v48-language')
        self.assertEqual(record.name,'Updated label')
        self.assertEqual(self.client.post(list_url).status_code,405)

    def test_manager_ai_post_cannot_change_owner_budget(self):
        Group.objects.get_or_create(name=MANAGER_GROUP)[0].user_set.add(self.manager)
        self.verify_manager()
        config=PlatformSettings.load()
        previous_budget=config.ai_monthly_budget_eur
        resp=self.client.post(reverse('manager'),{'ai_enabled':'','ai_emergency_stop':'on', 'ai_monthly_budget_eur':'999999999'})
        self.assertEqual(resp.status_code,302)
        config.refresh_from_db()
        self.assertEqual(config.ai_monthly_budget_eur, previous_budget)
        self.assertTrue(config.ai_emergency_stop)

    def test_unverified_account_cannot_be_assigned_manager(self):
        profile=self.learner.learning_profile
        profile.email_verified_at=None;profile.save(update_fields=['email_verified_at'])
        with self.assertRaises(CommandError):
            call_command('grant_rozh_manager','--username=v48learner','--grant',verbosity=0)
        self.assertFalse(self.learner.groups.filter(name=MANAGER_GROUP).exists())

    def test_login_routes_manager_without_student_placement(self):
        Group.objects.get_or_create(name=MANAGER_GROUP)[0].user_set.add(self.manager)
        req = RequestFactory().get('/login/')
        req.session = {}
        # Profile is auto-created by the post_save signal. setUpTestData updated
        # its MFA seed through a separate ORM instance. Refresh the cached
        # reverse OneToOne relation before checking the real login decision.
        self.manager.refresh_from_db()
        self.assertTrue(self.manager.learning_profile.totp_secret)
        self.assertEqual(_after_sign_in(req, self.manager), reverse('manager'))
        # Keep the required MFA-onboarding branch covered as well: a delegated
        # Manager without an enrolled authenticator must NEVER skip MFA setup.
        self.manager.learning_profile.totp_secret = ''
        self.assertEqual(_after_sign_in(req, self.manager), 'mfa_setup')

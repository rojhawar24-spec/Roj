"""Deterministic grading, spaced repetition, safe rate limits and learning progress."""
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from uuid import uuid4
from django.core.cache import cache
from django.conf import settings
from django.db import transaction
from django.db.models import Sum
from django.utils import timezone
from .models import ReviewCard, Badge, BadgeAward, Profile, LessonProgress, Assessment, Certificate, XPEvent, AppNotification, MistakeRecord, Level, LEVELS
from .progress_models import LearningPreferences


def _rate_bucket_key(request, name, user_scoped=False, account_identifier=None):
    """Derive opaque rate-limit keys without storing raw user identifiers."""
    remote_ip=request.META.get('REMOTE_ADDR','unknown')
    # Only trust proxy headers when the deployment explicitly operates behind the isolated Caddy proxy.
    if settings.SECURE_PROXY_SSL_HEADER and request.META.get('HTTP_X_FORWARDED_FOR'):
        remote_ip=request.META['HTTP_X_FORWARDED_FOR'].split(',')[-1].strip() or remote_ip
    # Account identifiers are normalized and hashed; never store raw email or username in cache keys.
    if account_identifier is not None:
        ident = 'account:' + str(account_identifier).strip().casefold()
    else:
        ident = f'u:{request.user.pk}' if user_scoped and request.user.is_authenticated else f'ip:{remote_ip}'
    import hashlib
    return 'rate:'+hashlib.sha256(f'{name}:{ident}'.encode()).hexdigest()


def rate_limit_exceeded(request, name, limit, period_seconds, user_scoped=False, account_identifier=None):
    """Read the failure counter without consuming an attempt on valid login.

    Called before password verification, while rate_limit() is called only
    after a *failed* authentication attempt. A Redis outage fails closed.
    """
    key = _rate_bucket_key(request, name, user_scoped, account_identifier)
    try:
        return int(cache.get(key, 0) or 0) >= limit
    except Exception:
        from logging import getLogger
        getLogger(__name__).warning('Rate-limit status unavailable for %s', name)
        return True


def rate_limit(request, name, limit, period_seconds, user_scoped=False, account_identifier=None):
    """Atomic fixed-window increments; fail closed if the throttle backend fails."""
    key = _rate_bucket_key(request, name, user_scoped, account_identifier)
    try:
        if cache.add(key, 1, timeout=period_seconds):
            return False
        return cache.incr(key) > limit
    except Exception:
        # Rate-limited views are POST/grade/billing or other sensitive
        # mutations. Never allow unlimited XP, checkout or social calls when
        # the shared backend is unavailable (including 'delete-account').
        # A proxy throttle remains useful.
        from logging import getLogger
        getLogger(__name__).warning('Rate-limit backend failure for %s', name)
        return True


def grade(exercise, answer):
    # Old grading unchanged; the V58 authored family uses a server-side key.
    if exercise.kind not in ('mcq', 'short'):
        from .lesson_activities_v58 import is_correct
        return is_correct(exercise, answer)
    return str(answer or '').strip().casefold() == exercise.answer.strip().casefold()


def allowed_unit(user, unit, *, passed_unit_ids=None, passed_level_ids=None,
                 published_levels=None, profile=None, season_access=None):
    """Placement opens its CEFR band; higher bands require the preceding level test.

    Only published bands containing published units participate. This preserves
    editable courses and legacy installations that contain a single level.
    Within-band prerequisite unit tests remain required, even after placement.
    """
    if not user.is_authenticated:
        return False
    # Never allow the classic lesson/API route to bypass the same mandatory
    # placement and selected-course gates enforced by the mixed game player.
    profile = profile if profile is not None else user.learning_profile
    # Mandatory onboarding remains a server-side prerequisite even if a
    # partially migrated profile already has placement_completed=True. Legacy
    # learners with onboarding_required=False retain their normal access.
    if (getattr(profile, 'onboarding_required', False)
            and not getattr(profile, 'onboarding_completed', False)):
        return False
    if not profile.placement_completed or profile.preferred_language_id != unit.level.language_id:
        return False
    # V70: a published authored season after the current one cannot be entered
    # through a direct URL. Only completed real units in the previous season
    # grant access; legacy unassigned units keep their existing access policy.
    if unit.season_id:
        if season_access is None:
            from .season_unlock_v70 import access_for_user
            season_access = access_for_user(user, unit.level.language_id)
        if (unit.season_id in season_access and
                not season_access[unit.season_id]['open']):
            return False
    required = list(unit.prerequisites.all())
    if passed_unit_ids is None:
        if not all(Assessment.objects.filter(user=user, kind='unit', unit=previous, passed=True).exists()
                   for previous in required):
            return False
    elif not {previous.pk for previous in required}.issubset(passed_unit_ids):
        return False
    codes = [code for code, _ in LEVELS]
    if unit.level.code not in codes:
        return True
    target_index = codes.index(unit.level.code)
    placement_index = 0
    if (profile.placement_completed and profile.preferred_language_id == unit.level.language_id
            and profile.placement_level in codes):
        placement_index = codes.index(profile.placement_level)
    if target_index <= placement_index:
        return True
    if published_levels is None:
        published_lower = Level.objects.filter(
            language_id=unit.level.language_id,
            code__in=codes[:target_index], units__published=True,
        ).distinct()
    else:
        published_lower = (level for level in published_levels
                           if level.code in codes[:target_index])
    previous = max(published_lower, key=lambda level: codes.index(level.code), default=None)
    if previous is None:
        return True
    if passed_level_ids is not None:
        return previous.pk in passed_level_ids
    return Assessment.objects.filter(user=user, kind='level', level=previous, passed=True).exists()


def unit_lessons_done(user, unit):
    required = set(unit.lessons.filter(published=True).values_list('pk', flat=True))
    if not required:
        return False
    completed = set(LessonProgress.objects.filter(
        user=user, lesson_id__in=required).values_list('lesson_id', flat=True))
    return required.issubset(completed)


def level_units_passed(user, level):
    required = set(level.units.filter(published=True).values_list('pk', flat=True))
    if not required:
        return False
    passed = set(Assessment.objects.filter(
        user=user, kind='unit', unit_id__in=required, passed=True
    ).values_list('unit_id', flat=True))
    return required.issubset(passed)


def user_timezone(user):
    """Return the learner's validated calendar zone, with a safe legacy fallback."""
    name = LearningPreferences.objects.filter(user=user).values_list('timezone_name', flat=True).first()
    try:
        return ZoneInfo(name or settings.TIME_ZONE)
    except (ZoneInfoNotFoundError, ValueError, TypeError):
        return ZoneInfo(settings.TIME_ZONE)


def user_localdate(user, now=None):
    return timezone.localdate(now or timezone.now(), timezone=user_timezone(user))


def learning_day_bounds(user, day):
    """Calendar-midnight bounds handle 23/25-hour days without losing XP."""
    zone = user_timezone(user)
    return (datetime.combine(day, time.min, tzinfo=zone),
            datetime.combine(day + timedelta(days=1), time.min, tzinfo=zone))


def current_streak(profile, today=None):
    """A stored historical streak is not a current streak after a missed day."""
    today = today or user_localdate(profile.user)
    if profile.last_active_day in (today, today - timedelta(days=1)):
        return profile.streak
    return 0


@transaction.atomic
def update_streak(profile, now=None):
    today = user_localdate(profile.user, now=now)
    preferences, _ = LearningPreferences.objects.get_or_create(user=profile.user)
    preferences = LearningPreferences.objects.select_for_update().get(pk=preferences.pk)
    longest = max(preferences.longest_streak, profile.streak)
    # Clock/timezone changes must not increment a streak twice for an older date.
    if profile.last_active_day and profile.last_active_day >= today:
        if longest != preferences.longest_streak:
            preferences.longest_streak = longest
            preferences.save(update_fields=['longest_streak'])
        return False
    if profile.last_active_day == today - timedelta(days=1):
        profile.streak += 1
    else:
        profile.streak = 1
    profile.last_active_day = today
    profile.save(update_fields=['streak', 'last_active_day'])
    preferences.longest_streak = max(longest, profile.streak)
    preferences.save(update_fields=['longest_streak'])
    return True


def notify(user, key, title, message):
    return AppNotification.objects.get_or_create(
        event_key=f'u{user.pk}:{key}'[:120],
        defaults={'user':user,'title':title[:100],'message':message[:260]}
    )[0]


def daily_xp(user, day=None):
    day = day or user_localdate(user)
    start, end = learning_day_bounds(user, day)
    return XPEvent.objects.filter(
        user=user, created_at__gte=start, created_at__lt=end,
        reason__in=('lesson', 'assessment', 'arena', 'review', 'mistake', 'daily_word')
    ).aggregate(total=Sum('amount'))['total'] or 0


def learning_level(xp):
    return 1 + int(xp)//200


def award_xp(user, amount, *, reason='lesson', event_key=None, learning=True):
    """Award real, persistent XP at most once per event key; chest never extends a streak."""
    if not 1 <= amount <= 250:
        if amount == 0: return False
        raise ValueError('XP award must be 1–250')
    key = f'user:{user.pk}:{event_key}' if event_key else f'user:{user.pk}:auto:{uuid4().hex}'
    now = timezone.now()
    with transaction.atomic():
        # Use one global lock order for all XP awards: learner Profile first,
        # then the immutable XPEvent. Season gifts and lessons already lock
        # Profile before asking for XP, so reversing this order can deadlock
        # under concurrent PostgreSQL requests.
        profile=Profile.objects.select_for_update().get(user=user)
        event, created = XPEvent.objects.get_or_create(
            event_key=key[:100], defaults={'user':user,'reason':reason,'amount':amount,'created_at':now}
        )
        if not created: return False
        old_level=learning_level(profile.xp)
        profile.xp+=amount
        profile.save(update_fields=['xp'])
        if learning: update_streak(profile, now=now)
        new_level=learning_level(profile.xp)
        if new_level>old_level: notify(user,f'level:{new_level}','Level up! 🎉',f'You reached learning level {new_level}.')
        for badge in Badge.objects.filter(xp_threshold__gt=0,xp_threshold__lte=profile.xp):
            award,created_badge=BadgeAward.objects.get_or_create(user=user,badge=badge,defaults={'granted_at':timezone.now()})
            if created_badge: notify(user,f'badge:{badge.pk}','New badge 🏅',f'You earned {badge.name}.')
        if learning and daily_xp(user)>=profile.daily_goal_xp:
            notify(user,f'goal:{user_localdate(user, now=now).isoformat()}','Daily goal achieved 🎯',
                   f'You reached today’s {profile.daily_goal_xp} XP learning goal.')
    return True


def record_exercise_result(user,exercise,correct):
    """Remember a missed question. A later correct answer resolves the same item."""
    with transaction.atomic():
        if correct:
            MistakeRecord.objects.filter(user=user,exercise=exercise,corrected_at__isnull=True).update(corrected_at=timezone.now())
            return
        mistake,created=MistakeRecord.objects.select_for_update().get_or_create(
            user=user,exercise=exercise,defaults={'wrong_count':1,'last_wrong_at':timezone.now()})
        if not created:
            mistake.wrong_count+=1
            mistake.last_wrong_at=timezone.now()
            mistake.corrected_at=None
            mistake.save(update_fields=['wrong_count','last_wrong_at','corrected_at'])


def save_review(card, quality):
    """Modified SM-2: 0-5 recall rating, 0-2 resets interval."""
    quality = int(quality)
    if not 0 <= quality <= 5: raise ValueError('Quality must be 0 to 5')
    if quality < 3:
        card.repetitions = 0
        card.interval_days = 1
    else:
        card.repetitions += 1
        if card.repetitions == 1: card.interval_days = 1
        elif card.repetitions == 2: card.interval_days = 6
        else: card.interval_days = max(1, round(card.interval_days * card.ease))
    card.ease = max(1.3,card.ease + (0.1-(5-quality)*(0.08+(5-quality)*0.02)))
    card.last_quality = quality
    card.due = timezone.now()+timedelta(days=card.interval_days)
    card.save()
    return card


def issue_certificate(user,level,issuer=None):
    if issuer is None and not Assessment.objects.filter(user=user,level=level,kind='level',passed=True).exists():
        raise ValueError('Level test must be passed first')
    evidence=Assessment.objects.filter(user=user,level=level,kind='level',passed=True).exists()
    return Certificate.objects.create(user=user,level=level,issued_by=issuer,verified_learning=evidence)

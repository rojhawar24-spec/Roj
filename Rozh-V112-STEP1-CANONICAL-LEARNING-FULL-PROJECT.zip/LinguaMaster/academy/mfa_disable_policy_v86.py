"""V86 security rule: disabling MFA requires password and one unused OTP.

This standalone policy intentionally has no Django imports, so its decision
flow can be tested offline. The actual password and OTP checks run against
Django's locked User and Profile rows in views.mfa_disable.
"""

_LABELS = {
    'nl': 'Huidig wachtwoord',
    'en': 'Current password',
    'ckb': 'وشەی نهێنیی ئێستا',
    'kmr': 'وشەیا نهێنی یا نوکە',
    'ku': 'Şîfreya niha',
    'uk': 'Поточний пароль',
    'ar': 'كلمة المرور الحالية',
    'fr': 'Mot de passe actuel',
}

def password_label(locale):
    """Text label for the MFA-disable form in each registered UI locale."""
    return _LABELS.get(locale, _LABELS['en'])

def verify_disable_credentials(user, password, profile, code, otp_validator):
    """Do not attempt/consume OTP if the account password does not match.

    The caller is responsible for rate limits, database locks, revocation
    and privilege rules. It must only clear the MFA seed on True.
    """
    if not isinstance(password, str) or not password or len(password) > 1024:
        return False
    if not user.check_password(password):
        return False
    return bool(otp_validator(profile, code))

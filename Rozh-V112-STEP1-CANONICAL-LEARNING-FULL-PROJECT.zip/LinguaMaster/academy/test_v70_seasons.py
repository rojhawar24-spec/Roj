"""Run on disposable Django test DB only; NEVER on a learner's live database."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Language, Level, LearningSeason, Unit, Lesson, LessonProgress, Exercise, Assessment
from .services import allowed_unit


class SeasonProgressionIntegrationTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user('v70', 'v70@example.invalid', 'V70_Safe_Test_2026!')
        self.lang = Language.objects.create(code='en', name='English', slug='v70-english', is_published=True)
        self.level = Level.objects.create(language=self.lang, code='A0', order=0, description='A0')
        self.seasons = [LearningSeason.objects.create(level=self.level, slug=f's{i}',
                          title=f'Season {i}', order=i, published=True) for i in range(1,7)]
        self.units=[]
        self.lessons=[]
        for i, season in enumerate(self.seasons,1):
            unit=Unit.objects.create(level=self.level,season=season,slug=f'unit-{i}',
                                     title=f'Unit {i}',summary='Test unit',published=True,order=i)
            lesson=Lesson.objects.create(unit=unit,slug='first',title=f'Lesson {i}',
                                skill='reading',content='Test',published=True)
            self.units.append(unit);self.lessons.append(lesson)
        profile=self.user.learning_profile
        profile.preferred_language=self.lang
        profile.onboarding_completed=True
        profile.placement_completed=True
        profile.save()
        self.client.force_login(self.user)

    def test_season_five_auto_selected_and_current_when_seasons_one_to_four_done(self):
        for lesson in self.lessons[:4]:
            LessonProgress.objects.create(user=self.user,lesson=lesson,score=100)
        response=self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'data-r70-focused-season')
        self.assertContains(response,'value="r27-season-s%s" selected' % self.seasons[4].pk)
        self.assertTrue(allowed_unit(self.user,self.units[4]))
        self.assertFalse(allowed_unit(self.user,self.units[5]))
        self.assertNotContains(response, self.lessons[5].get_absolute_url())

    def test_direct_lesson_page_denied_until_previous_season_completed(self):
        self.assertFalse(allowed_unit(self.user,self.units[1]))
        response=self.client.get(self.lessons[1].get_absolute_url())
        self.assertNotEqual(response.status_code,200)
        LessonProgress.objects.create(user=self.user,lesson=self.lessons[0],score=100)
        self.assertTrue(allowed_unit(self.user,self.units[1]))

    def test_unit_test_is_required_when_mcq_exists(self):
        Exercise.objects.create(lesson=self.lessons[0],kind='mcq',prompt='1?',options=['1','2'],
                                answer='1',explanation='yes')
        LessonProgress.objects.create(user=self.user,lesson=self.lessons[0],score=100)
        self.assertFalse(allowed_unit(self.user,self.units[1]))
        Assessment.objects.create(user=self.user,kind='unit',unit=self.units[0],passed=True,score=100)
        self.assertTrue(allowed_unit(self.user,self.units[1]))

    def test_locked_season_cannot_be_opened_by_direct_url_or_old_game(self):
        self.assertFalse(allowed_unit(self.user,self.units[5]))
        self.assertNotEqual(self.client.get(self.lessons[5].get_absolute_url()).status_code,200)
        page=self.client.get(reverse('play_hub'))
        self.assertContains(page,'data-r70-season-locked="true"')
        self.assertNotContains(page,self.lessons[5].get_absolute_url())

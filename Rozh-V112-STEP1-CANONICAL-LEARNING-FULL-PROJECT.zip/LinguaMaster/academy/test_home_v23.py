"""Homepage V23 Django integration regression tests. Run in a disposable test DB."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from academy.email_verification_tokens import email_verification_token_generator
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from unittest.mock import patch
from .home_v23 import LABELS


class HomepageV23Tests(TestCase):
    def test_homepage_is_clarity_first_and_features_require_signin(self):
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'lm23-hero')
        self.assertContains(response, 'Start Leer &amp; Speel')
        self.assertContains(response, 'Grammatica')
        self.assertContains(response, '/login/?next=/play/')
        self.assertContains(response, 'href="/grammar/"')
        self.assertContains(response, '/login/?next=/skills/listening/')
        self.assertNotContains(response, 'id="features"')
        self.assertContains(response, 'id="how"')
        self.assertNotContains(response, '100,000 students')

    def test_four_homepage_languages_and_rtl(self):
        self.assertEqual(len({tuple(d) for d in LABELS.values()}), 1)
        for code, direction in [('nl', 'ltr'), ('en', 'ltr'), ('ckb', 'rtl'), ('ar', 'rtl')]:
            with self.subTest(code=code):
                response = self.client.get(reverse('home') + '?ui=' + code, follow=True)
                self.assertEqual(response.status_code, 200)
                self.assertContains(response, 'lang="' + code + '"')
                self.assertContains(response, 'dir="' + direction + '"')
                self.assertContains(response, 'lm23-hero')

    def test_selected_feature_remains_across_auth_tabs(self):
        destination = '/grammar/'
        login_page = self.client.get(reverse('login') + '?next=' + destination)
        self.assertEqual(login_page.status_code, 200)
        self.assertContains(login_page, 'name="next" value="/grammar/"')
        self.assertTrue('/register/?next=%2Fgrammar%2F' in login_page.content.decode() or '/register/?next=/grammar/' in login_page.content.decode())
        register_page = self.client.get(reverse('register') + '?next=' + destination)
        self.assertEqual(register_page.status_code, 200)
        self.assertContains(register_page, 'name="next" value="/grammar/"')
        self.assertTrue('/login/?next=%2Fgrammar%2F' in register_page.content.decode() or '/login/?next=/grammar/' in register_page.content.decode())

    def test_rejects_external_or_protocol_relative_redirects(self):
        for destination in ('https://outside.example/evil', '//outside.example', '/login/', '/mfa/verify/'):
            with self.subTest(destination=destination):
                login_page = self.client.get(reverse('login'), {'next': destination})
                self.assertEqual(login_page.status_code, 200)
                self.assertContains(login_page, 'name="next" value=""')
                register_page = self.client.get(reverse('register'), {'next': destination})
                self.assertContains(register_page, 'name="next" value=""')

    def test_existing_learner_returns_to_chosen_feature_after_login(self):
        user = get_user_model().objects.create_user('homepage_v23_user', 'homepage-v23@example.com', 'AUniquePassword!2026')
        profile = user.learning_profile
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.save(update_fields=['onboarding_completed', 'placement_completed'])
        response = self.client.post(reverse('login') + '?next=/grammar/', {
            'email': user.email, 'password': 'AUniquePassword!2026', 'next': '/grammar/',
        })
        self.assertRedirects(response, '/grammar/', fetch_redirect_response=False)

    def test_onboarding_does_not_lose_saved_destination(self):
        user = get_user_model().objects.create_user('homepage_v23_new', 'new-homepage-v23@example.com', 'AUniquePassword!2026')
        request = self.client
        response = request.post(reverse('login'), {
            'email': user.email, 'password': 'AUniquePassword!2026', 'next': '/skills/listening/',
        })
        self.assertRedirects(response, reverse('onboarding'), fetch_redirect_response=False)
        self.assertEqual(self.client.session.get('post_auth_next'), '/skills/listening/')

    @patch('academy.views.send_mail')
    def test_verification_link_retains_selected_feature(self, mail):
        from urllib.parse import quote
        user = get_user_model().objects.create_user(
            'homepage_v23_verify', 'verified-v23@example.com', 'AUniquePassword!2026', is_active=False
        )
        uid = urlsafe_base64_encode(force_bytes(user.pk))
        token = email_verification_token_generator.make_token(user)
        verify_url = reverse('verify_email', args=[uid, token])
        preview = self.client.get(verify_url, {'next': '/grammar/'})
        self.assertEqual(preview.status_code, 200)
        user.refresh_from_db()
        self.assertFalse(user.is_active)
        response = self.client.post(verify_url, {'next': '/grammar/'})
        self.assertRedirects(response, reverse('login') + '?next=%2Fgrammar%2F', fetch_redirect_response=False)
        user.refresh_from_db()
        self.assertTrue(user.is_active)

    def test_authenticated_home_goes_to_real_learning_path(self):
        user = get_user_model().objects.create_user(
            'homepage_v23_path', 'path-v23@example.com', 'AUniquePassword!2026'
        )
        profile = user.learning_profile
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.save(update_fields=['onboarding_completed', 'placement_completed'])
        self.client.force_login(user)
        self.assertRedirects(self.client.get(reverse('home')), reverse('play_hub'), fetch_redirect_response=False)

    def test_other_public_pages_keep_working_site_navigation(self):
        response = self.client.get(reverse('try_lesson'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'aria-label="Site navigation"')
        self.assertNotContains(response, 'class="header lm23-public-header"')

"""Django integration tests for release audit (not run without Django)."""
from django.test import TestCase

from academy.models import Language, Level, Unit, Lesson, Exercise
from academy.content_audit import audit_published_content


class V100PublishedContentGateTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        lang = Language.objects.create(code='nl', slug='v100-dutch', name='Dutch',
                                       description='Test language', is_published=True)
        level = Level.objects.create(language=lang, code='A0', order=0, description='Test')
        unit = Unit.objects.create(level=level, slug='v100-test', title='V100 Test',
                                   summary='A test unit', outcomes=['Answer questions'],
                                   order=1, published=True)
        listening = Lesson.objects.create(unit=unit, slug='listening', title='Unready listening',
                                           skill='listening', content='Listen and learn',
                                           audio_text='Unapproved recording', order=1, published=True)
        Exercise.objects.create(lesson=listening, kind='mcq', order=1,
                                prompt='Which word?', options=['one','two'], answer='one',
                                explanation='One is correct.')
        legacy = Lesson.objects.create(unit=unit, slug='speaking', title='Legacy speaking',
                                        skill='speaking', content='Self-review content',
                                        order=2, published=True)
        cls.legacy_id = legacy.pk

    def test_unapproved_audio_and_ungraded_legacy_are_visible(self):
        report = audit_published_content(max_issues=10000)
        codes = [entry['code'] for entry in report['issues']]
        self.assertIn('published-listening-missing-audio', codes)
        self.assertIn('ungraded-self-review', codes)
        self.assertGreater(report['errors'], 0)
        self.assertTrue(report['editorial_review_required'])

    def test_unit_assessment_with_valid_fill_blank_is_ready(self):
        level = Level.objects.get(code='A0')
        unit = Unit.objects.create(level=level, slug='without-test', title='No MCQ',
                                   summary='Needs assessment', outcomes=['Complete unit'],
                                   order=2, published=True)
        lesson = Lesson.objects.create(unit=unit,slug='grammar',title='Fill only',
                                        skill='grammar',content='Fill the blank',
                                        order=1,published=True)
        Exercise.objects.create(lesson=lesson,kind='fill_blank',order=1,
                                prompt='Ik ___ hier.',options=[],answer='woon',
                                explanation='Woon is correct.')
        report = audit_published_content(max_issues=10000)
        self.assertFalse(any(issue['code'] == 'unit-assessment-no-ready-question' and issue['message'].startswith('No MCQ:') for issue in report['issues']))

    def test_audit_does_not_unpublish_or_delete_lessons(self):
        before = list(Lesson.objects.order_by('pk').values_list('pk','published'))
        audit_published_content(max_issues=10000)
        after = list(Lesson.objects.order_by('pk').values_list('pk','published'))
        self.assertEqual(before, after)

"""Privacy-minimal authentication events, retained by the existing AuditEvent policy.

Do not record credentials, passwords, reset links, TOTP codes, IPs or usernames.
An unavailable audit table must not lock out a user whose authentication succeeded.
"""
import logging

from django.db import DatabaseError

from .models import AuditEvent

logger = logging.getLogger(__name__)
_ALLOWED_ACTIONS = frozenset({'login_success', 'login_failure', 'mfa_failure'})


def record_auth_event(action, *, user=None):
    """Record an allowlisted event with a fixed non-identifying target.

    Successful events associate the existing user via actor; failures from
    unknown login identifiers remain anonymous (no account enumeration).
    """
    if action not in _ALLOWED_ACTIONS:
        raise ValueError('Unsupported authentication audit action')
    actor = user if action != 'login_failure' else None
    try:
        AuditEvent.objects.create(actor=actor, action=action, target='authentication', metadata={})
    except DatabaseError:
        # Never place exception text, identifiers or credentials in logs.
        # Sign-in must not depend on an ancillary audit insert succeeding.
        logger.warning('Authentication audit storage unavailable for %s', action)

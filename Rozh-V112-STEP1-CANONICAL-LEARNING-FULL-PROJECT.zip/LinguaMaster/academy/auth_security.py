"""Login/MFA primitives. Keep secrets out of logs, form responses, and audit events.

Existing plaintext MFA secrets are accepted during a controlled migration and are
written back encrypted; new database values are authenticated ciphertext.
Rotating DJANGO_SECRET_KEY requires preserving the previous TOTP key via
LINGUAMASTER_TOTP_KEY (or re-provisioning MFA for affected users).
"""
import base64
import hashlib

import pyotp
from cryptography.fernet import Fernet, InvalidToken
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured
from django.db import models

PREFIX = 'enc:v1:'


def _fernet():
    # Dedicated stable key allows independent key rotation. Existing deployments
    # use the application's stable Django secret; never use a hardcoded key.
    source = getattr(settings, 'LINGUAMASTER_TOTP_KEY', '') or settings.SECRET_KEY
    if not source:
        raise ImproperlyConfigured('Set a secret key for TOTP encryption')
    material = hashlib.sha256(('LinguaMaster:TOTP:v1:' + source).encode('utf-8')).digest()
    return Fernet(base64.urlsafe_b64encode(material))


def encrypt_totp(value):
    if not value or value.startswith(PREFIX):
        return value
    return PREFIX + _fernet().encrypt(value.encode('ascii')).decode('ascii')


def decrypt_totp(value):
    if not value or not value.startswith(PREFIX):
        return value
    try:
        return _fernet().decrypt(value[len(PREFIX):].encode('ascii')).decode('ascii')
    except (InvalidToken, UnicodeDecodeError, ValueError) as exc:
        # Fail closed: do NOT silently turn a protected account into no-MFA.
        raise ImproperlyConfigured('TOTP secret cannot be decrypted; check TOTP key configuration') from exc


class EncryptedTOTPField(models.CharField):
    """Transparent encrypted-at-rest CharField, backwards-readable during migration."""
    def from_db_value(self, value, expression, connection):
        return decrypt_totp(value)

    def get_prep_value(self, value):
        return encrypt_totp(super().get_prep_value(value))


def verify_totp_step(profile, code):
    """Accept a real 6-digit TOTP only once across an accepted ±1 time window.

    Caller MUST hold a Profile.select_for_update row lock in transaction.atomic.
    The updated step is saved in the same transaction as the login decision.
    """
    if not isinstance(code, str) or len(code) != 6 or not code.isascii() or not code.isdigit():
        return False
    if not profile.totp_secret:
        return False
    from .mfa_enroll_step_v88 import matched_enrollment_step
    token = pyotp.TOTP(profile.totp_secret)
    # A six-digit TOTP can (rarely) collide across adjacent 30-second steps.
    # Consume the LATEST matching step, rather than the first accepted one:
    # otherwise a code matching both current and future steps could be used
    # again when the clock moves forward. Share the enrollment verifier to
    # ensure consistent exact-step and malformed-input handling.
    step = matched_enrollment_step(token, code)
    if step is None or step <= profile.mfa_last_totp_step:
        return False
    profile.mfa_last_totp_step = step
    profile.save(update_fields=['mfa_last_totp_step'])
    return True

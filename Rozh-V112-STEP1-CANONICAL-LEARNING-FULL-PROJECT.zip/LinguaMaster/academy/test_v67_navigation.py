"""Real Django URL resolving + navigation policy tests; run on isolated QA DB."""
from django.test import SimpleTestCase
from django.urls import resolve, reverse

from .navigation_v67 import safe_student_return_path


class NavigationRoutingV67Tests(SimpleTestCase):
    def test_named_core_user_destinations(self):
        for name in ('play_hub','grammar_library','vocabulary','profile',
                     'manager','login','courses','leaderboard','switch_ui_language'):
            path=reverse(name)
            self.assertEqual(resolve(path).url_name,name)

    def test_named_dynamic_lesson_and_manager_paths(self):
        for name,args in [('lesson',[13]),('unit',[9]),('grammar',[5]),
                          ('assessment_unit',[5]),('journey_play',[8]),
                          ('manager_content_edit',['lesson',3])]:
            self.assertEqual(resolve(reverse(name,args=args)).url_name,name)

    def test_same_page_resume_and_filtered_sections(self):
        self.assertEqual(safe_student_return_path(reverse('lesson',args=[7])),reverse('lesson',args=[7]))
        self.assertEqual(safe_student_return_path(reverse('grammar_library')+'?level=a0&q=zijn'),
                         reverse('grammar_library')+'?level=A0&q=zijn')

    def test_no_privileged_or_external_language_switch(self):
        for source in ('//evil.example/','https://evil.example/',reverse('logout'),
                       reverse('manager'),reverse('lesson_answer',args=[7]),
                       reverse('manager_content_edit',args=['lesson',7]),
                       '/some-missing-route/'):
            self.assertIsNone(safe_student_return_path(source))

    def test_unknown_query_not_open_redirect(self):
        self.assertEqual(safe_student_return_path(reverse('lesson',args=[9])+'?next=//evil.example/'),
                         reverse('lesson',args=[9]))

"""V77: evidence-gated, 15-step adaptive *starting-point estimate*.

This is deliberately NOT a CEFR certificate or psychometrically calibrated CAT.
Without a professionally reviewed audio-backed question bank, the feature is
unavailable; no synthetic items or made-up levels are returned to learners.
"""
import hashlib
import json
import math
import re
import unicodedata
from collections import Counter
from pathlib import PurePosixPath

from django.contrib.auth.decorators import login_required
from django.contrib.staticfiles import finders
from django.contrib.staticfiles.storage import staticfiles_storage
from django.db import transaction
from django.http import HttpResponse, HttpResponseNotAllowed
from django.shortcuts import redirect, render
from django.urls import path, reverse
from django.utils import timezone
from django.views.decorators.http import require_http_methods

from .account_signin_policy_v27 import account_signin_permitted
from .courses_v10 import record_current_course
from .models import Language, Level, Profile, Lesson, Unit, Assessment
from .placement_models_v77 import PlacementBankItem, PlacementRun
from .services import rate_limit

STAGES = ('A0', 'A1', 'A2', 'B1', 'B2', 'C1')
SKILLS = ('reading', 'listening', 'grammar', 'vocabulary', 'writing')
# Exact coverage: reading=4, listening=3, grammar=3, vocabulary=3, controlled writing=2.
SKILL_SCHEDULE = (
    'vocabulary', 'grammar', 'reading', 'listening', 'writing',
    'reading', 'grammar', 'vocabulary', 'listening', 'reading',
    'writing', 'grammar', 'vocabulary', 'listening', 'reading',
)
QUESTION_COUNT = 15
MIN_PER_STAGE_SKILL = 2
AUDIO_PREFIX = 'academy/placement-audio/'


def normalize_answer(value):
    """Only trim/Unicode-normalize + casefold: no permissive fuzzy grading."""
    return ' '.join(unicodedata.normalize('NFKC', value).casefold().split())


def valid_audio_path(value, check_exists=True):
    if not isinstance(value, str) or len(value) > 180:
        return False
    if not re.fullmatch(r'academy/placement-audio/[a-zA-Z0-9_/-]+\.(?:mp3|ogg|wav)', value):
        return False
    if '..' in PurePosixPath(value).parts or '//' in value:
        return False
    return not check_exists or bool(finders.find(value))


def item_usable(item, check_audio=True):
    """Recheck publication and edited fields even if created via bulk SQL."""
    if not (item.published and item.educator_reviewed and item.source_reference.strip()
            and item.course_id and item.stage in STAGES and item.skill in SKILLS
            and item.prompt.strip()):
        return False
    if item.skill == 'listening' and not valid_audio_path(item.audio_path, check_exists=check_audio):
        return False
    if item.skill == 'reading' and not item.stimulus.strip():
        return False
    if item.skill == 'writing':
        answers = item.accepted_answers
        return (isinstance(answers, list) and bool(answers) and len(answers) <= 12
                and all(isinstance(answer, str) and 0 < len(answer.strip()) <= 300 for answer in answers)
                and not item.options and len({normalize_answer(a) for a in answers}) == len(answers))
    options = item.options
    return (isinstance(options, list) and 3 <= len(options) <= 5
            and all(isinstance(o, str) and 0 < len(o.strip()) <= 300 for o in options)
            and len({normalize_answer(o) for o in options}) == len(options)
            and normalize_answer(item.answer) in {normalize_answer(o) for o in options})


def item_fingerprint(item):
    """Tamper-evident content fingerprint for a displayed question."""
    evidence = [item.course_id, item.stage, item.skill, item.prompt,
                item.stimulus, item.audio_path, item.options, item.answer,
                item.accepted_answers, item.educator_reviewed, item.published,
                item.content_version]
    return hashlib.sha256(json.dumps(evidence, ensure_ascii=False,
                                     sort_keys=True).encode('utf-8')).hexdigest()


def history_still_valid(history, items_by_id):
    """Do not finalize an estimate based on subsequently edited/withdrawn items."""
    for event in history:
        item = items_by_id.get(event.get('item_id'))
        if not item or item.content_version != event.get('version'):
            return False
        if item_fingerprint(item) != event.get('digest'):
            return False
    return True


def published_bank(course):
    if course is None or not course.is_published:
        return []
    return [item for item in PlacementBankItem.objects.filter(
        course=course, published=True, educator_reviewed=True,
    ).order_by('pk') if item_usable(item)]


def bank_status(course, items=None):
    """Require multiple vetted items in every CEFR band/skill combination.

    This is *readiness*, not proof that CEFR cut scores are validated. Item
    calibration and criterion validation must still be performed in a study.
    """
    if course is None or not course.is_published:
        return False, 'No published course is selected.'
    if items is None:
        items = published_bank(course)
    counts = Counter((q.stage, q.skill) for q in items)
    missing = [(stage, skill) for stage in STAGES for skill in SKILLS
               if counts[(stage, skill)] < MIN_PER_STAGE_SKILL]
    if missing:
        return False, 'An educator-reviewed question bank is not ready for this course.'
    if not set(Level.objects.filter(language=course).values_list('code', flat=True)).issuperset(STAGES):
        return False, 'The course does not yet have every A0–C1 learning level.'
    return True, ''


def smart_placement_available(course):
    return bank_status(course)[0]


def ability_after(history):
    """Conservative heuristic, NOT fitted IRT, trained CAT, or certification.

    Difficulty uses editor-assigned bands. A correct answer raises the next
    challenge; an incorrect answer lowers it. There is no AI level guessing.
    """
    theta = 0.0
    for event in history:
        stage_index = STAGES.index(event['stage'])
        delta = max(-15.0, min(15.0, 1.2 * (theta - stage_index)))
        probability = 1 / (1 + math.exp(-delta))
        theta = max(0.0, min(5.0, theta + 1.05 * (float(event['correct']) - probability)))
    return theta


def choose_item(items, history):
    if len(history) >= QUESTION_COUNT:
        return None
    skill = SKILL_SCHEDULE[len(history)]
    current = max(0, min(5, round(ability_after(history))))
    seen = {event['item_id'] for event in history}
    candidates = [item for item in items if item.skill == skill and item.pk not in seen]
    if not candidates:
        return None
    # Order is deterministic across page refreshes, never random on each GET.
    return min(candidates, key=lambda q: (abs(STAGES.index(q.stage) - current), q.pk))


def estimate_start(history):
    if len(history) != QUESTION_COUNT:
        raise ValueError('15 completed answers are required')
    theta = ability_after(history)
    proposed = min(5, int(math.floor(theta + 1e-9)))
    correct_by_stage = Counter(event['stage'] for event in history if event['correct'])
    confirmed = [index for index, stage in enumerate(STAGES) if correct_by_stage[stage] >= 2]
    # Without two correct responses *at* a band, never advance to it.
    proposed = min(proposed, max(confirmed) if confirmed else 0)
    lower = min(proposed, max(0, int(math.floor(theta - 0.8))))
    upper = max(proposed, min(5, int(math.ceil(theta + 0.8))))
    score = round(100 * sum(1 for event in history if event['correct']) / QUESTION_COUNT)
    return {'band': STAGES[proposed], 'range_low': STAGES[lower],
            'range_high': STAGES[upper], 'score': score,
            'uncertain': upper > lower, 'method': 'unvalidated adaptive estimate'}


COPY = {
    'en': ('Find your starting point', '15 questions · adaptive practice',
           'This estimates a course starting point. It is NOT a certified or validated CEFR exam.',
           'This course does not yet have 15-question, educator-reviewed assessment coverage. Start at A0 instead.',
           'Start at A0', 'Question', 'of', 'Check answer', 'Continue', 'Write your answer',
           'Estimated starting level', 'Uncertain range', 'Start at the suggested level',
           'Begin again at A0', 'Your result is only an estimate; speaking and spontaneous writing are not fully assessed.',
           'Correct answer', 'Try again after refreshing; the assessment content changed.', 'Read the text',
           'Play the listening audio', 'Your course has no published lessons at that suggested level yet.'),
    'nl': ('Vind je startniveau', '15 vragen · adaptieve toets',
           'Dit schat je startniveau. Dit is GEEN erkende of gevalideerde ERK-toets.',
           'Voor deze cursus ontbreken nog voldoende door een docent gecontroleerde toetsvragen. Begin bij A0.',
           'Begin bij A0', 'Vraag', 'van', 'Controleer antwoord', 'Verder', 'Schrijf je antwoord',
           'Geschat startniveau', 'Onzekerheidsgebied', 'Start op dit niveau',
           'Begin opnieuw vanaf A0', 'Dit is een schatting; spreken en vrij schrijven worden niet volledig beoordeeld.',
           'Antwoord gecontroleerd', 'De toetsinhoud is veranderd. Ververs de pagina.', 'Lees de tekst',
           'Luister naar de opname', 'Voor dit niveau zijn nog geen gepubliceerde lessen.'),
    'ckb': ('ئاستی دەستپێکت بدۆزەوە', '١٥ پرسیار · تاقیکردنەوەی گۆڕاو',
            'ئەمە پێشبینیی ئاستی دەستپێکە؛ تاقیکردنەوەی فەرمی یان پشتڕاستکراوی CEFR نییە.',
            'هێشتا پرسیاری پشکنراوی پێویست بۆ ئەم کۆرسە بەردەست نییە. دەتوانیت لە A0 دەست پێ بکەیت.',
            'لە A0 دەست پێ بکە', 'پرسیار', 'لە', 'وەڵام بپشکنە', 'بەردەوام بە', 'وەڵامەکەت بنووسە',
            'ئاستی دەستپێکی پێشبینیکراو', 'مەودای نادڵنیایی', 'لە ئاستی پێشنیارکراو دەست پێ بکە',
            'لە A0 دەست پێ بکە', 'ئەمە تەنها پێشبینییە؛ قسەکردن و نووسینی ئازاد بە تەواوی نەپێوراون.',
            'وەڵام پشکنرا', 'ناوەڕۆکی تاقیکردنەوە گۆڕاوە. پەڕەکە نوێ بکەرەوە.', 'دەقەکە بخوێنەوە',
            'گوێ لە تۆماری دەنگ بگرە', 'هێشتا وانەی بڵاوکراوە لەم ئاستەدا نییە.'),
    'ar': ('اكتشف مستوى بدايتك', '١٥ سؤالاً · اختبار متكيف',
           'هذا تقدير لنقطة البداية، وليس اختبار CEFR معتمداً أو مثبت الصلاحية.',
           'لا تتوفر أسئلة كافية راجعها مدرس لهذه الدورة. يمكنك البدء من A0.',
           'ابدأ من A0', 'السؤال', 'من', 'تحقق من الإجابة', 'متابعة', 'اكتب إجابتك',
           'مستوى البداية التقديري', 'نطاق عدم اليقين', 'ابدأ من المستوى المقترح',
           'ابدأ مجدداً من A0', 'هذه نتيجة تقديرية؛ لم تُقَيَّم المحادثة والكتابة الحرة بالكامل.',
           'تم التحقق من الإجابة', 'تغير محتوى الاختبار، أعد تحميل الصفحة.', 'اقرأ النص',
           'استمع إلى التسجيل', 'لا توجد دروس منشورة لهذا المستوى بعد.'),
}


# Additional UI locales use reviewed application-style labels but remain BETA
# until a native reviewer checks the full question/assessment experience.
COPY['fr'] = (
    'Découvrez votre niveau de départ', '15 questions · test adaptatif',
    'Estimation indicative du niveau. Ce test n’est ni certifié ni validé selon le CECR.',
    'Cette formation ne dispose pas encore de suffisamment de questions validées par des enseignants.',
    'Commencer en A0', 'Question', 'sur', 'Vérifier la réponse', 'Continuer', 'Écrivez votre réponse',
    'Niveau de départ estimé', 'Intervalle d’incertitude', 'Commencer à ce niveau',
    'Recommencer en A0', 'Estimation uniquement ; l’expression orale et la rédaction libre ne sont pas entièrement évaluées.',
    'Réponse vérifiée', 'Le contenu a changé. Actualisez la page.', 'Lisez le texte',
    'Écoutez l’enregistrement', 'Aucune leçon publiée à ce niveau pour le moment.',
)
COPY['uk'] = (
    'Визначте свій початковий рівень', '15 запитань · адаптивний тест',
    'Це приблизна оцінка рівня, а не сертифікований або валідований іспит CEFR.',
    'Для цього курсу ще недостатньо завдань, перевірених викладачами.',
    'Почати з A0', 'Запитання', 'із', 'Перевірити відповідь', 'Далі', 'Введіть відповідь',
    'Орієнтовний початковий рівень', 'Діапазон невизначеності', 'Почати з рекомендованого рівня',
    'Почати знову з A0', 'Це лише оцінка; усне мовлення та вільне письмо не перевірено повністю.',
    'Відповідь перевірено', 'Вміст тесту змінено. Оновіть сторінку.', 'Прочитайте текст',
    'Прослухайте аудіо', 'На цьому рівні ще немає опублікованих уроків.',
)


RESTART_COPY = {
 'en': ('Assessment content changed during your attempt. You can restart safely.', 'Restart this assessment'),
 'nl': ('De inhoud van de toets is gewijzigd. Je kunt de toets veilig opnieuw beginnen.', 'Start de toets opnieuw'),
 'ckb': ('ناوەڕۆکی تاقیکردنەوە لە کاتی وەڵامدانەوە گۆڕاوە. دەتوانیت دووبارە دەست پێ بکەیت.', 'دووبارە دەست پێ بکە'),
 'ar': ('تغير محتوى الاختبار أثناء المحاولة. يمكنك بدء الاختبار من جديد.', 'أعد بدء الاختبار'),
 'fr': ('Le contenu du test a changé. Vous pouvez recommencer en toute sécurité.', 'Recommencer le test'),
 'uk': ('Вміст тесту змінено. Ви можете безпечно почати знову.', 'Почати тест заново'),
}


def ui_copy(locale):
    # Incomplete locales are intentionally labelled as translated via English
    # fallback elsewhere, never advertised as complete here.
    return COPY.get(locale, COPY['en'])


def _a0(request):
    """Explicit opt-in to A0, never automatic from an uncertain estimate."""
    from .courses_v10 import switch_course
    profile = request.user.learning_profile
    if not profile.preferred_language_id:
        return redirect('courses')
    switch_course(request.user, profile.preferred_language, start_at_a0=True)
    return redirect('play_hub')


@login_required
@require_http_methods(['GET', 'POST'])
def smart_placement(request):
    """One question per request; DB-locked, server-graded, resume-safe."""
    if not account_signin_permitted(request.user, request.user.learning_profile):
        return HttpResponse(status=403)
    profile = request.user.learning_profile
    if profile.onboarding_required and not profile.onboarding_completed:
        return redirect('onboarding')
    if profile.placement_completed:
        return redirect('play_hub')
    if not profile.preferred_language_id or not profile.preferred_language.is_published:
        return redirect('courses')
    locale = profile.ui_language
    texts = ui_copy(locale)
    if request.method == 'POST' and rate_limit(request, 'smart-placement-v77', 90, 3600, True):
        return HttpResponse('Too many assessment requests.', status=429)
    if request.method == 'POST' and request.POST.get('action') == 'a0':
        return _a0(request)
    course = profile.preferred_language
    items = published_bank(course)
    ready, reason = bank_status(course, items)
    if not ready:
        if request.method == 'POST':
            return HttpResponse('Assessment no longer available.', status=409)
        return render(request, 'academy/placement_smart_v77.html', {
            'T': texts, 'locale': locale, 'unavailable': True,
            'unavailable_reason': reason, 'kind': 'smart_placement', 'noindex': True,
        })
    items_by_id = {q.pk: q for q in items}
    with transaction.atomic():
        # This lock serializes the placement run with any course switch.
        current = Profile.objects.select_for_update().get(pk=profile.pk)
        if current.preferred_language_id != course.pk or current.placement_completed:
            return redirect('courses' if current.preferred_language_id != course.pk else 'play_hub')
        run, created = PlacementRun.objects.select_for_update().get_or_create(
            user=request.user, course=course,
        )
        previous_valid = history_still_valid(run.history, items_by_id)
        current_item = items_by_id.get(run.current_item_id) if run.current_item_id else None
        current_valid = (not run.current_item_id or
                         (current_item is not None and
                          item_fingerprint(current_item) == run.current_digest and
                          current_item.content_version == run.current_version))
        needs_restart = not (previous_valid and current_valid)
        if needs_restart:
            if request.method == 'POST' and request.POST.get('action') == 'restart':
                run.history = []
                run.current_item_id = None
                run.current_version = 0
                run.current_digest = ''
                run.result = {}
                run.status = 'active'
                run.save(update_fields=['history','current_item_id','current_version',
                                        'current_digest','result','status','updated_at'])
            else:
                restart_text = RESTART_COPY.get(locale, RESTART_COPY['en'])
                return render(request, 'academy/placement_smart_v77.html', {
                    'T': texts, 'locale': locale, 'stale': True,
                    'restart_text': restart_text, 'kind': 'smart_placement',
                    'noindex': True,
                })
        elif request.method == 'POST' and request.POST.get('action') == 'restart':
            return HttpResponse('Restart only allowed when the content changed.', status=409)
        if request.method == 'POST' and request.POST.get('action') != 'restart':
            action = request.POST.get('action')
            if action == 'answer':
                if run.status != 'active' or run.current_item_id is None:
                    return HttpResponse('Assessment step not open.', status=409)
                try:
                    sent_item = int(request.POST.get('question_id', ''))
                except (TypeError, ValueError):
                    return HttpResponse('Invalid question identifier.', status=400)
                if sent_item != run.current_item_id:
                    return HttpResponse('Stale question. Reload.', status=409)
                item = items_by_id.get(run.current_item_id)
                if (item is None or item.content_version != run.current_version
                        or item_fingerprint(item) != run.current_digest):
                    return HttpResponse(texts[16], status=409)
                values = request.POST.getlist('answer')
                if len(values) != 1 or not isinstance(values[0], str) or not (0 < len(values[0].strip()) <= 300):
                    return HttpResponse('Provide exactly one valid answer.', status=400)
                submitted = values[0]
                if item.skill != 'writing' and submitted not in item.options:
                    return HttpResponse('Answer must be a displayed option.', status=400)
                is_correct = (normalize_answer(submitted) in {
                    normalize_answer(v) for v in item.accepted_answers}
                    if item.skill == 'writing' else normalize_answer(submitted) == normalize_answer(item.answer))
                history = list(run.history)
                history.append({'item_id': item.pk, 'stage': item.stage,
                                'skill': item.skill, 'correct': bool(is_correct),
                                'version': item.content_version, 'digest': run.current_digest})
                run.history = history
                run.current_item_id = None
                run.current_version = 0
                run.current_digest = ''
                if len(history) == QUESTION_COUNT:
                    run.result = estimate_start(history)
                    run.status = 'ready'
                run.save(update_fields=['history', 'current_item_id', 'current_version',
                                        'current_digest', 'result', 'status', 'updated_at'])
            elif action in ('use_level', 'use_a0'):
                if run.status != 'ready' or len(run.history) != QUESTION_COUNT:
                    return HttpResponse('Finish all 15 questions first.', status=409)
                result = run.result
                chosen = result['band'] if action == 'use_level' else 'A0'
                live_course = Language.objects.select_for_update().filter(pk=course.pk, is_published=True).first()
                if not live_course:
                    return HttpResponse('Course publication changed.', status=409)
                if chosen != 'A0' and not Lesson.objects.filter(
                    unit__level__language=course, unit__level__code=chosen,
                    unit__published=True, published=True,
                ).exists():
                    return HttpResponse(texts[19], status=409)
                level = Level.objects.filter(language=course, code=chosen).first()
                if level is None:
                    return HttpResponse('The selected level no longer exists.', status=409)
                # Persist only after the learner chooses. No XP, fake passed
                # lessons, auto-completed seasons or certificates.
                current.placement_level = chosen
                current.placement_completed = True
                current.save(update_fields=['placement_level', 'placement_completed'])
                record_current_course(current)
                Assessment.objects.create(
                    user=request.user, kind='placement', level=level,
                    score=result['score'], passed=True,
                    responses={'method': 'smart_v77_unvalidated', 'chosen': chosen,
                               'estimate': result, 'evidence': run.history},
                )
                run.status = 'confirmed'
                run.chosen_level = chosen
                run.save(update_fields=['status', 'chosen_level', 'updated_at'])
                return redirect('play_hub')
            else:
                return HttpResponse('Invalid placement action.', status=400)
        if run.status == 'active':
            item = items_by_id.get(run.current_item_id) if run.current_item_id else None
            if item is not None and (item.content_version != run.current_version
                                         or item_fingerprint(item) != run.current_digest):
                return HttpResponse(texts[16], status=409)
            if item is None:
                item = choose_item(items, run.history)
                if not item:
                    return HttpResponse('Assessment item pool changed; ask a teacher.', status=409)
                run.current_item_id = item.pk
                run.current_version = item.content_version
                run.current_digest = item_fingerprint(item)
                run.save(update_fields=['current_item_id', 'current_version', 'current_digest', 'updated_at'])
        else:
            item = None
        result = run.result if run.status == 'ready' else None
    audio_src = staticfiles_storage.url(item.audio_path) if item and item.skill == 'listening' else ''
    can_start_suggested = bool(result and (result['band'] == 'A0' or Lesson.objects.filter(
        unit__level__language=course, unit__level__code=result['band'],
        unit__published=True, published=True,
    ).exists()))
    return render(request, 'academy/placement_smart_v77.html', {
        'T': texts, 'locale': locale, 'kind': 'smart_placement', 'noindex': True,
        'item': item, 'audio_src': audio_src, 'run': run,
        'number': len(run.history) + 1, 'total': QUESTION_COUNT,
        'percent': round(100 * len(run.history) / QUESTION_COUNT),
        'result': result, 'can_start_suggested': can_start_suggested,
    })

urlpatterns = [path('placement/smart/', smart_placement, name='smart_placement_v77')]

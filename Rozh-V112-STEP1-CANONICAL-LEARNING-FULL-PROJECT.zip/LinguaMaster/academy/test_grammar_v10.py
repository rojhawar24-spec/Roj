"""Rich grammar is safe content, with opt-in imports and unchanged learning rules."""
from copy import deepcopy
from io import StringIO
import json
from pathlib import Path
from tempfile import TemporaryDirectory

from django.contrib import admin
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.core.management import call_command, CommandError
from django.test import SimpleTestCase, TestCase
from django.urls import reverse

from .grammar_rich_models import GrammarArticle
from .grammar_models import GrammarMastery
from .grammar_v9 import LABELS, RICH_LABELS
from .management.commands.import_grammar import import_document
from .models import AuditEvent, GrammarTopic, Language, Level
from .rich_schema import normalize_article


ARTICLE = {
    'intro': 'Learn how the subject changes a regular verb.',
    'learning_goals': ['Choose the correct verb ending.'],
    'sections': [{'title': 'Find the stem first', 'body': 'Remove -en from werken to find werk.\n\nThen choose the ending.'}],
    'rule_tables': [{'title': 'A regular present tense', 'columns': ['Subject', 'Verb'],
                     'rows': [['ik', 'werk'], ['jij', 'werkt']], 'note': 'Inversion with jij changes the ending.'}],
    'sentence_patterns': [{'label': 'A statement', 'tokens': [
        {'text': 'Jij', 'role': 'subject'}, {'text': 'werkt', 'role': 'verb'}, {'text': 'vandaag.', 'role': 'time'}]}],
    'example_pairs': [{'original': 'Jij werkt vandaag.', 'translation': 'You are working today.', 'note': 'Use stem + t.'}],
    'common_traps': [{'wrong': 'Hij werken.', 'correct': 'Hij werkt.', 'why': 'Hij needs a singular verb form.'}],
}


class RichSchemaTests(SimpleTestCase):
    def test_optional_defaults_and_input_are_not_mutated(self):
        source = {'intro': 'A short introduction.'}
        result = normalize_article(source)
        self.assertEqual(result['sections'], [])
        self.assertEqual(source, {'intro': 'A short introduction.'})
        self.assertEqual(normalize_article(ARTICLE), ARTICLE)

    def test_wrong_types_unknown_fields_roles_and_non_rectangular_tables_rejected(self):
        bad_articles = [
            {'intro': 123}, {'html': '<h1>No markup</h1>'}, {'sections': 'a section'},
            {'sections': [{'title': 'Title', 'body': ['not text']}]},
            {'rule_tables': [{'title': 'Bad table', 'columns': ['A', 'B'], 'rows': [['only one cell']]}]},
            {'sentence_patterns': [{'label': 'Bad role', 'tokens': [{'text': 'hello', 'role': 'style=unsafe'}]}]},
            {'common_traps': [{'wrong': 'X', 'correct': 'Y'}]},
            {'example_pairs': [{'original': 'X', 'translation': True}]},
            {'learning_goals': ['x'] * 9},
            {'intro': 'x' * 3001},
        ]
        for article in bad_articles:
            with self.subTest(article=article):
                with self.assertRaises(ValidationError):
                    normalize_article(article)

    def test_all_rich_interface_locales_have_the_same_keys(self):
        for locale in ('nl', 'en', 'ckb', 'ar'):
            self.assertEqual(set(RICH_LABELS[locale]), set(RICH_LABELS['en']))


class GrammarRichTests(TestCase):
    def setUp(self):
        self.language = Language.objects.create(code='nl', name='Dutch', slug='dutch', description='Dutch', is_published=True)
        self.level = Level.objects.create(language=self.language, code='A1', description='Basics', order=1)
        self.topic = GrammarTopic.objects.create(level=self.level, slug='present', title='Present tense',
            explanation='Use a regular verb ending.', examples=['Ik werk.'], exceptions='Some verbs are irregular.',
            common_mistakes='Do not use a plural verb with hij.', check_question='Which form?',
            check_options=['Hij werkt.', 'Hij werken.'], check_answer='Hij werkt.', published=True)
        self.user = get_user_model().objects.create_user('richlearner', password='ExamplePass!234')
        profile = self.user.learning_profile
        profile.preferred_language = self.language
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.save()
        self.client.force_login(self.user)

    def document(self, entries=None):
        return {'schema_version': 1, 'language': 'nl', 'topics': entries or [
            {'level': 'A1', 'slug': 'present', 'article': deepcopy(ARTICLE)}]}

    def new_topic_entry(self, slug='new-grammar'):
        return {'level': 'A1', 'slug': slug, 'title': 'A new grammar topic',
            'explanation': 'Use a regular verb ending.', 'examples': ['Ik werk.'],
            'exceptions': 'Some verbs are irregular.', 'common_mistakes': 'Check the subject.',
            'check_question': 'Which form?', 'check_options': ['Hij werkt.', 'Hij werken.'],
            'check_answer': 'Hij werkt.', 'article': deepcopy(ARTICLE)}

    def test_rich_article_renders_real_tables_diagrams_examples_and_contents(self):
        GrammarArticle.objects.create(topic=self.topic, content=deepcopy(ARTICLE))
        response = self.client.get(reverse('grammar', args=[self.topic.pk]))
        for text in ('<table dir="ltr">', '<caption>A regular present tense</caption>', 'scope="col"',
                     'g10-role-subject', 'Subject', 'You are working today.', 'Hij needs a singular verb form.',
                     'href="#sentence-patterns"', 'grammar-v10.css'):
            self.assertContains(response, text)
        self.assertNotContains(response, '<main class="g10-reading"')

    def test_all_author_text_is_escaped(self):
        article = deepcopy(ARTICLE)
        article['sections'][0]['body'] = '<script>alert(1)</script>'
        article['rule_tables'][0]['rows'][0][0] = '<img src=x onerror=alert(1)>'
        GrammarArticle.objects.create(topic=self.topic, content=article)
        response = self.client.get(reverse('grammar', args=[self.topic.pk]))
        self.assertContains(response, '&lt;script&gt;alert(1)&lt;/script&gt;')
        self.assertNotContains(response, '<script>alert(1)</script>')
        self.assertNotContains(response, '<img src=x onerror=alert(1)>')

    def test_invalid_direct_save_is_rejected_and_bypassed_invalid_data_falls_back(self):
        with self.assertRaises(ValidationError):
            GrammarArticle.objects.create(topic=self.topic, content={'intro': 123})
        article = GrammarArticle.objects.create(topic=self.topic, content=deepcopy(ARTICLE))
        GrammarArticle.objects.filter(pk=article.pk).update(content={'unknown': '<script>bad</script>'})
        response = self.client.get(reverse('grammar', args=[self.topic.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertIsNone(response.context['article'])
        self.assertContains(response, 'Use a regular verb ending.')

    def test_rich_articles_preserve_server_grading_and_spaced_progress(self):
        GrammarArticle.objects.create(topic=self.topic, content=deepcopy(ARTICLE))
        url = reverse('grammar', args=[self.topic.pk])
        self.client.post(url, {'answer': 'Hij werken.'})
        self.client.post(url, {'answer': 'Hij werkt.'})
        row = GrammarMastery.objects.get(user=self.user, topic=self.topic)
        self.assertEqual((row.attempts, row.correct, row.successful_days), (2, 1, 1))
        self.topic.refresh_from_db()
        self.assertEqual(self.topic.check_answer, 'Hij werkt.')

    def test_rtl_interface_keeps_dutch_sentence_direction_and_local_role_labels(self):
        GrammarArticle.objects.create(topic=self.topic, content=deepcopy(ARTICLE))
        for locale, direction in [('en', 'ltr'), ('nl', 'ltr'), ('ckb', 'rtl'), ('ar', 'rtl')]:
            profile = self.user.learning_profile
            profile.ui_language = locale
            profile.save()
            response = self.client.get(reverse('grammar', args=[self.topic.pk]))
            self.assertContains(response, f'lang="{locale}" dir="{direction}"')
            self.assertContains(response, 'class="g10-tokens" dir="ltr"')
            self.assertContains(response, LABELS[locale]['role_subject'])

    def test_library_marks_rich_guides_and_uses_article_summary(self):
        GrammarArticle.objects.create(topic=self.topic, content=deepcopy(ARTICLE))
        response = self.client.get(reverse('grammar_library'))
        self.assertContains(response, ARTICLE['intro'])
        self.assertContains(response, 'Visual guide')
        self.assertTrue(response.context['cards'][0]['rich'])

    def test_featured_guide_uses_only_actual_articles_in_active_course_and_filters(self):
        article = GrammarArticle.objects.create(topic=self.topic, content=deepcopy(ARTICLE))
        starter_level = Level.objects.create(language=self.language, code='A0', order=0, description='Start')
        plain = GrammarTopic.objects.create(level=starter_level, slug='first', title='First words',
            explanation='Start here.', examples=['Hallo.'], exceptions='None.', common_mistakes='None.',
            check_question='Hello?', check_options=['Hallo', 'Nee'], check_answer='Hallo', published=True)
        foreign_language = Language.objects.create(code='fr', name='French', slug='french', description='French', is_published=True)
        foreign_level = Level.objects.create(language=foreign_language, code='A1', order=1, description='French basics')
        foreign = GrammarTopic.objects.create(level=foreign_level, slug='foreign', title='Foreign rich guide',
            explanation='French guide.', examples=['Bonjour.'], exceptions='None.', common_mistakes='None.',
            check_question='Hello?', check_options=['Bonjour', 'Non'], check_answer='Bonjour', published=True)
        GrammarArticle.objects.create(topic=foreign, content=deepcopy(ARTICLE))
        url = reverse('grammar_library')
        response = self.client.get(url)
        featured = response.context['featured_guide']
        self.assertEqual(featured['topic'], self.topic)
        self.assertEqual((featured['table_count'], featured['pattern_count'], featured['section_count']), (1, 1, 1))
        self.assertEqual([card['topic'] for card in response.context['cards']], [plain, self.topic])
        self.assertContains(response, 'g10-featured-guide')
        for filters in ({'level': 'A0'}, {'q': 'First words'}, {'status': 'mastered'}):
            self.assertIsNone(self.client.get(url, filters).context['featured_guide'])
        self.assertEqual(self.client.get(url, {'q': 'Present'}).context['featured_guide']['topic'], self.topic)
        article.delete()
        self.assertIsNone(self.client.get(url).context['featured_guide'])

    def test_default_import_preserves_authored_topic_and_article(self):
        original = GrammarArticle.objects.create(topic=self.topic, content={'intro': 'Teacher authored.'})
        document = self.document()
        document['topics'][0]['title'] = 'Overwrite attempt'
        counts = import_document(document)
        self.assertEqual(counts, {'created': 0, 'updated': 0, 'skipped': 1})
        self.topic.refresh_from_db()
        original.refresh_from_db()
        self.assertEqual(self.topic.title, 'Present tense')
        self.assertEqual(original.content['intro'], 'Teacher authored.')

    def test_explicit_update_changes_only_supplied_base_fields_and_article(self):
        counts = import_document(self.document(), update=True)
        self.assertEqual(counts['updated'], 1)
        self.topic.refresh_from_db()
        self.assertEqual(self.topic.explanation, 'Use a regular verb ending.')
        self.assertEqual(self.topic.content_version, 2)
        self.assertEqual(self.topic.article.content, ARTICLE)
        self.assertTrue(AuditEvent.objects.filter(action='grammar_import').exists())

    def test_new_import_is_draft_and_dry_run_is_a_true_rollback(self):
        document = self.document([self.new_topic_entry()])
        counts = import_document(document, dry_run=True)
        self.assertEqual(counts['created'], 1)
        self.assertFalse(GrammarTopic.objects.filter(slug='new-grammar').exists())
        self.assertFalse(AuditEvent.objects.filter(action='grammar_import').exists())
        import_document(document)
        topic = GrammarTopic.objects.get(slug='new-grammar')
        self.assertFalse(topic.published)
        self.assertEqual(topic.article.content, ARTICLE)

    def test_one_invalid_topic_rolls_back_the_whole_file(self):
        document = self.document([self.new_topic_entry(), {'level': 'A1', 'slug': 'incomplete', 'article': {}}])
        with self.assertRaises(ValidationError):
            import_document(document)
        self.assertFalse(GrammarTopic.objects.filter(slug='new-grammar').exists())
        self.assertFalse(GrammarArticle.objects.exists())

    def test_command_validates_json_and_dry_run_reports_counts(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / 'grammar.json'
            path.write_text(json.dumps(self.document([self.new_topic_entry()])))
            output = StringIO()
            call_command('import_grammar', str(path), dry_run=True, stdout=output)
            self.assertIn('DRY RUN', output.getvalue())
            self.assertFalse(GrammarTopic.objects.filter(slug='new-grammar').exists())
            path.write_text('{broken')
            with self.assertRaises(CommandError):
                call_command('import_grammar', str(path))

    def test_editor_has_one_optional_article_inline(self):
        registered = admin.site._registry[GrammarTopic]
        self.assertEqual(registered.inlines[0].model, GrammarArticle)
        self.assertEqual(registered.inlines[0].max_num, 1)

"""V75: MFA-gated, audit-logged visual GrammarArticle authoring and no-write preview.

A GrammarTopic controls student publication. This editor can only change its
related plain-text, bounded structured article; it cannot change the topic,
course, progression, permissions, grades or XP. Never store preview submissions.
"""
import json
from django import forms
from django.contrib import messages
from django.core.exceptions import ValidationError
from django.db import transaction
from django.http import HttpResponse, HttpResponseBadRequest
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods
from .grammar_components_v57 import VISUAL_COMPONENT_TYPES, COMPONENT_LABELS, COMPONENT_CATEGORIES
from .grammar_rich_models import GrammarArticle
from .grammar_visual_labels_v17 import VISUAL_LABELS
from .manager_i18n_v47 import for_user
from .manager_roles_v48 import manager_only
from .models import GrammarTopic, ContentRevision, AuditEvent
from .rich_schema import normalize_article

MAX_ARTICLE_JSON_CHARS = 100000

COPY = {
    'nl': {'title':'Visuele grammatica bewerken', 'back':'Terug naar onderwerp', 'preview':'Voorbeeld bekijken', 'save':'Visuele uitleg opslaan', 'note':'Een voorbeeld slaat niets op. Bij een gepubliceerd onderwerp worden opgeslagen wijzigingen direct zichtbaar voor leerlingen.', 'status':'Zichtbaarheid', 'published':'Gepubliceerd', 'draft':'Concept', 'json':'Gestructureerd artikel (JSON)', 'syntax':'Alleen begrensde platte tekst, geen HTML. Gebruik het bestaande schemasjabloon.', 'preview_title':'Voorbeeld · niet opgeslagen', 'saved':'Visuele grammatica opgeslagen.', 'conflict':'De inhoud is inmiddels gewijzigd. Vernieuw de pagina voordat je opslaat.', 'empty':'Dit artikel heeft nog geen visuele blokken.'},
    'en': {'title':'Edit visual grammar', 'back':'Back to topic', 'preview':'Preview without saving', 'save':'Save visual guide', 'note':'Preview never saves. Saving a guide for a published topic makes changes visible to learners immediately.', 'status':'Visibility', 'published':'Published', 'draft':'Draft', 'json':'Structured article (JSON)', 'syntax':'Bounded plain text only, no HTML. Follow the existing schema.', 'preview_title':'Preview · not saved', 'saved':'Visual grammar saved.', 'conflict':'This content changed in another editor. Refresh before saving.', 'empty':'No visual blocks in this article yet.'},
    'ckb': {'title':'دەستکاریکردنی ڕێزمانی بینراو', 'back':'گەڕانەوە بۆ بابەت', 'preview':'پێشبینین بەبێ پاشەکەوتکردن', 'save':'پاشەکەوتکردنی ڕێنمایی بینراو', 'note':'پێشبینین هیچ شتێک پاشەکەوت ناکات. گۆڕانکاریی بابەتی بڵاوکراوە دوای پاشەکەوتکردن دیار دەبێت.', 'status':'دۆخ', 'published':'بڵاوکراوە', 'draft':'ڕەشنووس', 'json':'بابەتی ڕێکخراو (JSON)', 'syntax':'تەنها دەقی سادە و سنووردار، بەبێ HTML.', 'preview_title':'پێشبینین · پاشەکەوت نەکراوە', 'saved':'ڕێزمانی بینراو پاشەکەوت کرا.', 'conflict':'ناوەڕۆک لەلایەن دەستکاریکەرێکی تر گۆڕاوە. پەڕە نوێ بکەرەوە.', 'empty':'هێشتا بلۆکی بینراو نییە.'},
    'ar': {'title':'تحرير القواعد المرئية', 'back':'العودة للموضوع', 'preview':'معاينة بدون حفظ', 'save':'حفظ الدليل المرئي', 'note':'المعاينة لا تحفظ شيئًا. تظهر التغييرات المحفوظة فورًا في الموضوع المنشور.', 'status':'الحالة', 'published':'منشور', 'draft':'مسودة', 'json':'مقال منظم (JSON)', 'syntax':'نص عادي محدود فقط، بدون HTML.', 'preview_title':'معاينة · غير محفوظة', 'saved':'تم حفظ الدليل المرئي.', 'conflict':'تغيّر المحتوى في محرر آخر. حدّث الصفحة قبل الحفظ.', 'empty':'لا توجد كتل مرئية بعد.'},
    'fr': {'title':'Modifier la grammaire visuelle', 'back':'Retour au sujet', 'preview':'Aperçu sans enregistrer', 'save':'Enregistrer le guide visuel', 'note':'L’aperçu ne sauvegarde rien. Les modifications d’un sujet publié sont visibles après enregistrement.', 'status':'Statut', 'published':'Publié', 'draft':'Brouillon', 'json':'Article structuré (JSON)', 'syntax':'Texte brut limité, sans HTML.', 'preview_title':'Aperçu · non enregistré', 'saved':'Guide visuel enregistré.', 'conflict':'Contenu modifié ailleurs. Actualisez avant d’enregistrer.', 'empty':'Aucun bloc visuel pour le moment.'},
    'uk': {'title':'Редагування візуальної граматики', 'back':'Назад до теми', 'preview':'Перегляд без збереження', 'save':'Зберегти візуальний посібник', 'note':'Перегляд нічого не зберігає. Зміни опублікованої теми після збереження стають видимими учням.', 'status':'Статус', 'published':'Опубліковано', 'draft':'Чернетка', 'json':'Структурована стаття (JSON)', 'syntax':'Лише обмежений звичайний текст, без HTML.', 'preview_title':'Перегляд · не збережено', 'saved':'Візуальну граматику збережено.', 'conflict':'Вміст змінено іншим редактором. Оновіть сторінку.', 'empty':'Візуальних блоків ще немає.'},
    'kmr': {'title':'دەستکاریکرنا گرامەرا دیتنەیی', 'back':'ڤەگەڕیان بۆ بابەتێ', 'preview':'پێشاندانا بەری پاشەکەوتکرنێ', 'save':'پاشەکەوتکرنا ڕێبەرا دیتنەیی', 'note':'پێشاندان چ تشتان پاشەکەوت ناکەت. گۆهۆڕین ل بابەتێ بڵاوکری دێ پشتی پاشەکەوتکرنێ دیار بن.', 'status':'دۆخ', 'published':'بڵاوکری', 'draft':'ڕەشنووس', 'json':'بابەتا ڕێکخستی (JSON)', 'syntax':'ب تنێ تێکستا سادە، بێ HTML.', 'preview_title':'پێشاندان · پاشەکەوت نەکری', 'saved':'ڕێبەرا دیتنەیی پاشەکەوت کرا.', 'conflict':'ناڤەڕۆک هاتە گۆهۆڕین. پەڕێ نوو بکە.', 'empty':'هێشتا بلۆکێن دیتنەیی نینە.'},
    'ku': {'title':'Rêzimana dîtbarî biguherîne', 'back':'Vegere mijarê', 'preview':'Pêşdîtin bê tomarkirin', 'save':'Rêberê dîtbarî tomar bike', 'note':'Pêşdîtin tiştekî tomar nake. Guhertinên mijara weşandî piştî tomarkirinê xuya dibin.', 'status':'Rewş', 'published':'Weşandî', 'draft':'Reşnivîs', 'json':'Gotara rêkûpêk (JSON)', 'syntax':'Tenê nivîsa asayî ya sînordar, bê HTML.', 'preview_title':'Pêşdîtin · nehatî tomarkirin', 'saved':'Rêzimana dîtbarî hat tomar kirin.', 'conflict':'Naverok li cihekî din hatiye guhartin. Rûpelê nû bike.', 'empty':'Hêj blokên dîtbarî tune ne.'},
}

class VisualArticleForm(forms.Form):
    article_json = forms.CharField(max_length=MAX_ARTICLE_JSON_CHARS,
        widget=forms.Textarea(attrs={'rows':21, 'spellcheck':'false', 'class':'v75-json-editor v15-grammar-json', 'dir':'ltr'}))
    version = forms.IntegerField(min_value=1, widget=forms.HiddenInput)

    def clean_article_json(self):
        raw = self.cleaned_data['article_json']
        try:
            value = json.loads(raw)
        except (ValueError, TypeError, RecursionError) as exc:
            raise forms.ValidationError('Invalid JSON: ' + str(exc)[:160]) from exc
        try:
            self.normalized = normalize_article(value)
        except ValidationError as exc:
            raise forms.ValidationError('; '.join(exc.messages)[:500]) from exc
        return raw


def preview_article(normalized, locale):
    """Share the actual student visual block renderer; all content auto-escapes."""
    import copy
    article = copy.deepcopy(normalized)
    translated = labels_for_locale(locale)
    for block in article.get('visual_blocks', []):
        block['layout'] = VISUAL_COMPONENT_TYPES[block['type']]
        block['component_label'] = COMPONENT_LABELS.get(block['type'], block['title'])
        block['is_v57'] = block['type'] in COMPONENT_LABELS
        block['category_key'] = COMPONENT_CATEGORIES.get(block['type'], 'Legacy').lower().split(' & ')[0].split(' ')[0]
        if block['layout'] == 'tokens':
            for token in block['tokens']:
                token['role_label'] = translated.get('role_' + token['role'], token['role'])
    for pattern in article['sentence_patterns']:
        for token in pattern['tokens']:
            token['role_label'] = translated.get('role_' + token['role'], token['role'])
    return article


def labels_for_locale(locale):
    from .grammar_v9 import LABELS
    return LABELS.get(locale, LABELS['en'])


@never_cache
@manager_only
@require_http_methods(['GET', 'POST'])
def grammar_article_editor(request, pk):
    topic = get_object_or_404(GrammarTopic.objects.select_related('level__language'), pk=pk)
    try:
        locale = request.user.learning_profile.ui_language
    except AttributeError:
        locale = 'en'
    copy = COPY.get(locale, COPY['en'])
    existing = GrammarArticle.objects.filter(topic_id=pk).first()
    preview = None
    if request.method == 'POST':
        form = VisualArticleForm(request.POST)
        action = request.POST.get('action')
        if action not in ('preview', 'save'):
            return HttpResponseBadRequest('Invalid editor action.')
        if form.is_valid():
            if action == 'preview':
                # This branch MUST have no write or audit side effect.
                preview = preview_article(form.normalized, locale)
            else:
                with transaction.atomic():
                    locked = get_object_or_404(GrammarTopic.objects.select_for_update(), pk=pk)
                    if locked.content_version != form.cleaned_data['version']:
                        form.add_error(None, copy['conflict'])
                    else:
                        article, _ = GrammarArticle.objects.select_for_update().get_or_create(
                            topic=locked, defaults={'content':{}})
                        article.content = form.normalized
                        article.save()  # full_clean / bounded schema again
                        locked.content_version += 1
                        locked.save(update_fields=['content_version'])
                        ContentRevision.objects.create(model_label=article._meta.label,
                            object_pk=article.pk, version=locked.content_version,
                            editor=request.user, snapshot={'topic_id':locked.pk, 'content':form.normalized})
                        AuditEvent.objects.create(actor=request.user, action='manager_grammar_article_saved',
                            target=f'{article._meta.label}:{article.pk}')
                if not form.errors:
                    messages.success(request, copy['saved'])
                    return redirect(reverse('manager_grammar_article_v75', args=[pk]))
    else:
        content = existing.content if existing else {}
        form = VisualArticleForm(initial={
            'article_json': json.dumps(content, ensure_ascii=False, indent=2),
            'version': topic.content_version})
    return render(request, 'academy/manager_grammar_article_v75.html', {
        **for_user(request.user), 'topic':topic, 'form':form, 'V75':copy,
        'preview':preview, 'article':preview,
        'GV':VISUAL_LABELS.get(locale, VISUAL_LABELS['en']),
        'content_dir':'rtl' if topic.level.language.code in ('ar','ckb','kmr','fa','he') else 'ltr',
        'schema_doc':'docs/GRAMMAR_AUTHORING_V10.md',
        'published':topic.published,
    })

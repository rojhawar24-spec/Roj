"""Real Django/DRF integration cases — must run in disposable QA database.

Not yet executed in this environment: Django dependency unavailable.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.utils import timezone
from .models import Profile

class V43ProgressAPIRevocationTests(TestCase):
    URL='/api/me/progress/'
    def setUp(self):
        User=get_user_model()
        self.learner=User.objects.create_user('v43_learner', 'v43-learner@example.invalid', 'StrongLocal-Only-2026!')
        self.other=User.objects.create_user('v43_other', 'v43-other@example.invalid', 'StrongLocal-Only-2026!')
        Profile.objects.filter(user=self.learner).update(xp=67,streak=3)
        Profile.objects.filter(user=self.other).update(xp=28,streak=1)
        self.client.force_login(self.learner)

    def test_active_learner_still_sees_only_own_progress(self):
        response=self.client.get(self.URL)
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.json()['xp'],67)
        self.assertEqual(response.json()['streak'],3)
        self.assertEqual(response.json()['completed_lessons'],0)
        self.assertIn('no-store',response['Cache-Control'])

    def test_suspended_session_cannot_read_progress(self):
        Profile.objects.filter(user=self.learner).update(suspended_at=timezone.now())
        response=self.client.get(self.URL)
        self.assertEqual(response.status_code,403)
        self.assertNotIn('lesson_ids',response.content.decode())
        self.assertIn('no-store',response['Cache-Control'])

    def test_required_review_cannot_read_progress(self):
        Profile.objects.filter(user=self.learner).update(legacy_review_required=True)
        response=self.client.get(self.URL)
        self.assertEqual(response.status_code,403)
        self.assertNotIn('completed_lessons',response.content.decode())

    def test_missing_profile_fails_closed_without_creating_data(self):
        Profile.objects.filter(user=self.learner).delete()
        count=Profile.objects.count()
        response=self.client.get(self.URL)
        self.assertEqual(response.status_code,403)
        self.assertEqual(Profile.objects.count(),count)

    def test_inactive_user_cannot_read_with_old_session(self):
        get_user_model().objects.filter(pk=self.learner.pk).update(is_active=False)
        response=self.client.get(self.URL)
        self.assertIn(response.status_code,(401,403))
        self.assertNotIn('lesson_ids',response.content.decode())

    def test_review_denied_even_with_invalid_query(self):
        Profile.objects.filter(user=self.learner).update(legacy_review_required=True)
        self.assertEqual(self.client.get(self.URL,{'limit':'5000'}).status_code,403)

    def test_eligible_other_user_not_blocked_by_first_users_revocation(self):
        Profile.objects.filter(user=self.learner).update(suspended_at=timezone.now())
        self.client.force_login(self.other)
        response=self.client.get(self.URL)
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.json()['xp'],28)

    def test_active_invalid_pagination_remains_400(self):
        self.assertEqual(self.client.get(self.URL,{'offset':'-1'}).status_code,400)

    def test_anonymous_cannot_read_progress(self):
        self.client.logout()
        response=self.client.get(self.URL)
        self.assertIn(response.status_code,(401,403))
        self.assertNotIn('lesson_ids',response.content.decode())

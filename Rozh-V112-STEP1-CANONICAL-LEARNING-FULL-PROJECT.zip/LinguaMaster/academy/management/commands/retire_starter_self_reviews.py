"""V99: report old four-language self-review starter lessons; optional conservative retire.

DRY RUN is the default. --apply only unpublishes unmodified auto-seeded
speaking/writing lessons with zero exercises. No deletion or user-data updates.
Review a DB backup before using --apply on any existing database.
"""
from contextlib import nullcontext

from django.core.management.base import BaseCommand
from django.db import transaction

from academy.curriculum_policy_v99 import is_original_ungraded_seed_lesson
from academy.models import Lesson


class Command(BaseCommand):
    help = 'Audit original four-language starter self-review lessons; use --apply after backup to unpublish.'

    def add_arguments(self, parser):
        parser.add_argument('--apply', action='store_true',
                            help='Explicitly unpublish eligible untouched self-review starter lessons.')

    def handle(self, *args, **options):
        apply = bool(options['apply'])
        count = 0
        with (transaction.atomic() if apply else nullcontext()):
            rows = (Lesson.objects.select_related('unit__level__language')
                    .filter(unit__level__language__code__in=('nl','en','de','fr'), published=True,
                            slug__in=('speaking', 'writing'))
                    .order_by('pk'))
            if apply:
                rows = rows.select_for_update()
            for lesson in rows:
                if not is_original_ungraded_seed_lesson(
                        lesson, has_exercises=lesson.exercises.exists(),
                        course_code=lesson.unit.level.language.code,
                        unit_slug=lesson.unit.slug):
                    continue
                count += 1
                self.stdout.write(f'UNSCORED_SEEDED_LESSON id={lesson.pk} '
                                  f'unit={lesson.unit_id} skill={lesson.skill} '
                                  f'course={lesson.unit.level.language.code}')
                if apply:
                    lesson.published = False
                    lesson.content_version += 1
                    lesson.save(update_fields=['published', 'content_version'])
        state = 'UNPUBLISHED' if apply else 'DRY RUN; NO DATABASE CHANGES'
        self.stdout.write(f'{state}: {count} eligible lessons. No records deleted or learner XP edited.')
        if count and not apply:
            self.stdout.write('Back up the database and review Manager edits before running --apply.')

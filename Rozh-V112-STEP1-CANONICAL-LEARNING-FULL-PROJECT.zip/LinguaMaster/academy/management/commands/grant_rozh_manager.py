"""Safely grant/revoke the non-admin Rozh Manager role from a local shell.

Does not change passwords, email verification, TOTP, accounts unless the
operator explicitly asks to convert an already-verified superuser.
"""
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from academy.models import Profile, AuditEvent
from academy.manager_roles_v48 import MANAGER_GROUP
from academy.privilege_revocation_v92 import revoke_user_sessions

class Command(BaseCommand):
    help = 'Assign a separate Manager role (not Django Admin). Local console only.'

    def add_arguments(self, parser):
        parser.add_argument('--username', required=True)
        operation = parser.add_mutually_exclusive_group(required=True)
        operation.add_argument('--grant', action='store_true')
        operation.add_argument('--revoke', action='store_true')
        parser.add_argument('--convert-superuser', action='store_true',
            help='Explicitly demote a verified superuser to Manager only.')
        parser.add_argument('--confirm-owner-demotion', action='store_true',
            help='Required together with --convert-superuser; removes Django Admin access.')

    @transaction.atomic
    def handle(self, *args, **options):
        if options['convert_superuser'] and not (options['grant'] and options['confirm_owner_demotion']):
            raise CommandError('--convert-superuser requires --grant and --confirm-owner-demotion.')
        if options['confirm_owner_demotion'] and not options['convert_superuser']:
            raise CommandError('--confirm-owner-demotion is only valid with --convert-superuser.')
        User = get_user_model()
        try:
            user = User.objects.select_for_update().get(username=options['username'])
            profile = Profile.objects.select_for_update().get(user=user)
        except (User.DoesNotExist, Profile.DoesNotExist):
            raise CommandError('Account/Profile not found. No changes made.')
        if options['grant']:
            if (not user.is_active or profile.email_verified_at is None
                    or profile.suspended_at is not None or profile.legacy_review_required
                    or not profile.totp_secret):
                raise CommandError('Manager role requires active, verified, non-quarantined account and enrolled MFA. No changes made.')
            if user.is_staff or user.is_superuser:
                if not (options['convert_superuser'] and user.is_superuser):
                    raise CommandError('This user already has privileged Django rights. Use explicit conversion only for an authorized superuser.')
            elif options['convert_superuser']:
                raise CommandError('Account is not a superuser; conversion is not applicable.')
            if (user.user_permissions.exists() or
                    user.groups.exclude(name=MANAGER_GROUP).filter(permissions__isnull=False).exists()):
                raise CommandError('Account has direct or inherited Django permissions. Review them manually before assigning Manager-only; no changes made.')
            group, _ = Group.objects.get_or_create(name=MANAGER_GROUP)
            # This group has NO Django permissions and cannot use /secure-admin/.
            if group.permissions.exists():
                raise CommandError('Unsafe Manager group: Django permissions already assigned. No changes made.')
            user.groups.add(group)
            if options['convert_superuser']:
                user.is_staff = False
                user.is_superuser = False
                user.save(update_fields=['is_staff', 'is_superuser'])
            if revoke_user_sessions(user.pk) != 1:
                raise CommandError('Manager role change rolled back: Profile missing.')
            AuditEvent.objects.create(actor=user, action='manager_role_granted', target=str(user.pk))
            self.stdout.write(self.style.SUCCESS('[PASS] Manager role granted; Django Admin/Superuser privileges not granted.'))
        else:
            user.groups.remove(*Group.objects.filter(name=MANAGER_GROUP))
            if revoke_user_sessions(user.pk) != 1:
                raise CommandError('Manager role revocation rolled back: Profile missing.')
            AuditEvent.objects.create(actor=user, action='manager_role_revoked', target=str(user.pk))
            self.stdout.write(self.style.SUCCESS('[PASS] Manager group membership revoked; other account attributes unchanged.'))

"""Build migration from model definitions; only needed if the checked-in migration is updated."""
from django.core.management import call_command
from django.core.management.base import BaseCommand
class Command(BaseCommand):
    help='Generate migration after editing models, review before applying'
    def handle(self,*args,**options):
        call_command('makemigrations','academy')

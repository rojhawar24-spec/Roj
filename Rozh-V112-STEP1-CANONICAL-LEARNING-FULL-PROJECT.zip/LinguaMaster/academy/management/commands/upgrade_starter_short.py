"""Explicit, conservative upgrade of original bounded short exercises."""
import json
from contextlib import nullcontext
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.forms.models import model_to_dict
from academy.models import Exercise, ContentRevision, AuditEvent
from academy.legacy_short_upgrade_v109 import conversion_for


class Command(BaseCommand):
    help = 'Audit original EN/DE/FR starter short exercises. Apply only to reviewed IDs during maintenance after backup.'

    def add_arguments(self, parser):
        parser.add_argument('--apply', action='store_true')
        parser.add_argument('--id', action='append', type=int, dest='ids', default=[])

    def handle(self, *args, **options):
        apply = options['apply']
        ids = options['ids']
        if apply and (not ids or len(set(ids)) != len(ids) or any(pk <= 0 for pk in ids)):
            raise CommandError('Apply requires distinct positive --id values from a reviewed dry run; stop all writers and back up first.')
        with (transaction.atomic() if apply else nullcontext()):
            rows = Exercise.objects.filter(kind='short').select_related(
                'lesson__unit__level__language').order_by('pk')
            if ids:
                rows = rows.filter(pk__in=ids)
            if apply:
                rows = rows.select_for_update()
            eligible = []
            blocked = []
            for row in rows:
                label = row._meta.label
                has_revision = ContentRevision.objects.filter(model_label__iexact=label, object_pk=row.pk).exists()
                unique = not Exercise.objects.filter(lesson_id=row.lesson_id, order=row.order).exclude(pk=row.pk).exists()
                changes = conversion_for(row, unique_order=unique, has_revision=has_revision)
                if changes is None:
                    blocked.append(row.pk)
                else:
                    eligible.append((row, changes))
            eligible_ids = [row.pk for row, _ in eligible]
            if apply and set(eligible_ids) != set(ids):
                raise CommandError('At least one selected ID is absent, changed, ambiguous or ineligible; no changes made.')
            if apply:
                for row, changes in eligible:
                    before = model_to_dict(row)
                    changed = Exercise.objects.filter(pk=row.pk, content_version=1, kind=row.kind,
                        prompt=row.prompt, options=row.options, answer=row.answer, explanation=row.explanation,
                        activity_data=row.activity_data, difficulty=row.difficulty, order=row.order,
                        lesson_id=row.lesson_id).update(**changes, content_version=2)
                    if changed != 1:
                        raise CommandError('Concurrent exercise change; entire upgrade rolled back.')
                    row.refresh_from_db()
                    ContentRevision.objects.create(model_label=row._meta.label, object_pk=row.pk,
                        version=2, snapshot=model_to_dict(row))
                    AuditEvent.objects.create(action='starter_short_upgraded', target=f'{row._meta.label}:{row.pk}',
                        metadata={'previous_kind': before['kind'], 'previous_prompt': before['prompt'], 'previous_version': 1})
        self.stdout.write(json.dumps({'mode': 'applied' if apply else 'dry-run',
            'eligible_ids': eligible_ids, 'blocked_ids': blocked, 'changed': len(eligible_ids) if apply else 0}))

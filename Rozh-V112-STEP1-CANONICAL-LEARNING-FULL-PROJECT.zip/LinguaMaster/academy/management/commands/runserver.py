"""Local devserver: redact verification/reset URL credentials from access logs.

Django runserver logs request paths by default, including token-bearing URL paths.
Production proxies MUST also disable or redact access logs for such paths.
"""
import re
from django.contrib.staticfiles.management.commands.runserver import Command as StaticRunserverCommand
from django.core.servers import basehttp

_TOKEN_PATH = re.compile(r'/(verify|reset)/[^/\s?]+/[^/\s?]+', re.I)

class Command(StaticRunserverCommand):
    def inner_run(self, *args, **options):
        original = basehttp.WSGIRequestHandler.log_message
        if not getattr(original, '_lm_redacted', False):
            def secure_log(handler, fmt, *values):
                clean = tuple(_TOKEN_PATH.sub(r'/\1/[REDACTED]/[REDACTED]', str(v)) for v in values)
                return original(handler, fmt, *clean)
            secure_log._lm_redacted = True
            basehttp.WSGIRequestHandler.log_message = secure_log
        return super().inner_run(*args, **options)

"""Explicit review of ambiguous legacy accounts by the *local machine operator*.

This is NOT a web endpoint or a password/verification bypass. It cannot
unblock suspended accounts or grant privileges, and it is disabled outside
isolated DEBUG+SQLite+loopback environments. The operator must confirm
the registered email and type an exact approval phrase on a real terminal.
After approval the account stays inactive until verified by a *new* email
confirmation token and the original password authentication succeeds.
"""
import sys
from pathlib import Path
from urllib.parse import urlsplit
from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from academy.models import AuditEvent, Profile


def _require_local_operator_context():
    cfg = settings.DATABASES['default']
    parsed = urlsplit(settings.SITE_URL)
    if not settings.DEBUG or cfg.get('ENGINE') != 'django.db.backends.sqlite3':
        raise CommandError('Refused: this command runs only with DEBUG=1 and local SQLite.')
    if parsed.scheme != 'http' or parsed.hostname not in ('localhost', '127.0.0.1') or parsed.username or parsed.password:
        raise CommandError('Refused: SITE_URL must be an isolated localhost HTTP URL.')
    db = Path(cfg['NAME']).resolve()
    if db != (Path(settings.BASE_DIR) / 'db.sqlite3').resolve() or not db.is_file():
        raise CommandError('Refused: database must be the existing db.sqlite3 inside this local project.')
    return db


class Command(BaseCommand):
    help = 'LOCAL ONLY: review one ambiguous historical learner account without activating it.'

    def add_arguments(self, parser):
        parser.add_argument('--username', required=True)
        parser.add_argument('--check-only', action='store_true')
        parser.add_argument('--approve-legacy', action='store_true')

    def handle(self, *args, **options):
        _require_local_operator_context()
        if options['check_only'] and options['approve_legacy']:
            raise CommandError('Choose check-only OR approve-legacy, not both.')
        identifier = options['username'].strip()
        if not identifier or len(identifier) > 150:
            raise CommandError('Specify one existing username.')
        User = get_user_model()
        user = User.objects.filter(username__iexact=identifier).first()
        if user is None:
            raise CommandError('Username was not found in this local database.')
        try:
            profile = user.learning_profile
        except Profile.DoesNotExist:
            raise CommandError('Account profile is missing. Repair the schema before recovery.')
        # Do not use this local utility on privileged accounts or genuine
        # manager suspensions; those need their normal authorised process.
        if user.is_staff or user.is_superuser:
            raise CommandError('Privileged accounts require normal owner/MFA administration.')
        if profile.suspended_at is not None:
            raise CommandError('Manager suspension present: local recovery cannot unblock this account.')
        if user.is_active and profile.legacy_review_required:
            raise CommandError('Inconsistent account state: active and under legacy review. Stop and audit.')
        if not user.is_active and profile.email_verified_at is not None:
            raise CommandError('Inactive but previously verified account: requires manager review, not local activation.')
        self.stdout.write('LOCAL account: ' + user.username)
        self.stdout.write('Active: ' + ('YES' if user.is_active else 'NO'))
        self.stdout.write('Email verified: ' + ('YES' if profile.email_verified_at else 'NO'))
        self.stdout.write('Historical review required: ' + ('YES' if profile.legacy_review_required else 'NO'))
        if options['check_only']:
            self.stdout.write('Read-only preflight passed. No account changes made.')
            return
        if not options['approve_legacy']:
            self.stdout.write('No changes. To explicitly release a historical review in LOCAL DEVELOPMENT, use --approve-legacy.')
            return
        if not profile.legacy_review_required:
            self.stdout.write('No historical review hold. No account changes made.')
            return
        if user.is_active:
            raise CommandError('Refused: historical review may only be released on inactive accounts.')
        if not sys.stdin.isatty():
            raise CommandError('Interactive local terminal required; noninteractive approvals are forbidden.')
        self.stdout.write(self.style.WARNING(
            'Caution: historical records cannot prove whether this learner was blocked before V35.'))
        self.stdout.write('ONLY approve if you are the authorised local owner and have reviewed the account.')
        self.stdout.write('This will NOT verify email, enable login, change password, or grant privileges.')
        email = input('Enter the account registered email to confirm your review: ').strip()
        phrase = input('Type exactly REVIEW ' + user.username + ' to confirm: ').strip()
        if email.casefold() != user.email.casefold() or phrase != 'REVIEW ' + user.username:
            raise CommandError('Review not confirmed; account remains unchanged.')
        with transaction.atomic():
            locked_user = User.objects.select_for_update().get(pk=user.pk)
            locked_profile = Profile.objects.select_for_update().get(user_id=user.pk)
            if (locked_user.is_active or locked_user.is_staff or locked_user.is_superuser
                    or locked_profile.suspended_at is not None
                    or locked_profile.email_verified_at is not None
                    or not locked_profile.legacy_review_required):
                raise CommandError('State changed or review not eligible; no changes made.')
            locked_profile.legacy_review_required = False
            locked_profile.email_verification_version += 1
            locked_profile.save(update_fields=['legacy_review_required', 'email_verification_version'])
            AuditEvent.objects.create(actor=None, action='local_legacy_review_approved',
                                      target=str(locked_user.pk),
                                      metadata={'source':'interactive_local_operator',
                                                'verified_email':False, 'activated':False})
        self.stdout.write(self.style.SUCCESS('Review hold released; account remains INACTIVE and UNVERIFIED.'))
        self.stdout.write('Next: change password if needed, then request a NEW email verification link.')

"""Add authored starter courses without overwriting an editor's existing work."""
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from academy.models import Language, Level, Unit, Lesson, Exercise, GrammarTopic, Vocabulary
from academy.grammar_rich_models import GrammarArticle
from academy.rich_schema import normalize_article
from academy.quality_rules import check_exercise
from academy.starter_activity_v106 import starter_activity
from academy.starter_v10 import COURSE as ENGLISH, DUTCH_WORD_ORDER_RICH
from academy.starter_de_v10 import COURSE as GERMAN
from academy.starter_fr_v10 import COURSE as FRENCH


COURSES = (ENGLISH, GERMAN, FRENCH)
LEVEL_CODES = ('A0', 'A1', 'A2', 'B1', 'B2', 'C1')


def validate_course(course):
    """Reject malformed bundled data before writing any part of the course."""
    for unit in course['units']:
        if unit['level'] not in ('A0', 'A1'):
            raise CommandError('This starter release only publishes authored A0/A1 units.')
        # Speaking/free-writing self-review was removed from scored Learn & Play.
        # Historical bundled sources may still contain those optional entries,
        # but new three-skill datasets must not have to manufacture them.
        skills = [lesson['skill'] for lesson in unit['lessons']]
        required = {'grammar', 'reading', 'listening'}
        allowed = required | {'speaking', 'writing'}
        if not required.issubset(skills) or any(skill not in allowed for skill in skills):
            raise CommandError(f"{course['code']}/{unit['slug']}: grammar, reading and listening are required")
        if len(skills) != len(set(skills)):
            raise CommandError(f"{course['code']}/{unit['slug']}: duplicate lesson skills are not allowed")
        if not unit['vocabulary'] or not unit['outcomes']:
            raise CommandError(f"{unit['slug']}: vocabulary and learning outcomes are required")
        for lesson in unit['lessons']:
            if not lesson['content'].strip():
                raise CommandError(f"{lesson['title']}: missing lesson content")
            for exercise in lesson.get('exercises', []):
                errors = [issue for issue in check_exercise(exercise['kind'], exercise['prompt'],
                          exercise.get('options', []), exercise['answer'], exercise['explanation'])
                          if issue[0] == 'error']
                if errors:
                    raise CommandError(f"{lesson['title']}: {errors[0][2]}")
        checks = [q for lesson in unit['lessons'] if lesson['skill'] == 'grammar'
                  for q in lesson.get('exercises', []) if q['kind'] == 'mcq']
        if not checks:
            raise CommandError(f"{unit['slug']}: a grammar multiple-choice check is required")
        if unit.get('rich'):
            normalize_article(unit['rich'])


class Command(BaseCommand):
    help = ('Add original English, German and French A0/A1 starter courses; '
            'add rich companion articles without replacing editorial edits. '
            'A2–C1 level records are a future content structure, not a complete syllabus.')

    def handle(self, *args, **options):
        for course in COURSES:
            validate_course(course)
        normalize_article(DUTCH_WORD_ORDER_RICH)
        created = {name: 0 for name in ('languages', 'levels', 'units', 'lessons',
                                       'questions', 'words', 'topics', 'articles')}
        with transaction.atomic():
            for course in COURSES:
                self.seed_course(course, created)
            # Existing Dutch authoring remains authoritative. Attach only a missing
            # companion article; never create or rewrite a Dutch GrammarTopic here.
            dutch_topic = GrammarTopic.objects.filter(
                level__language__code='nl', level__code='A1', slug='main-clause-word-order'
            ).first()
            if dutch_topic:
                _, added = GrammarArticle.objects.get_or_create(
                    topic=dutch_topic, defaults={'content': DUTCH_WORD_ORDER_RICH})
                created['articles'] += int(added)
        self.stdout.write(self.style.SUCCESS(
            'Starter courses seeded: ' + ', '.join(f'{count} new {name}' for name, count in created.items()) + '.'))
        self.stdout.write('English, German and French contain authored A0/A1 starter units only. '
                          'A2–C1 content is still in development. Existing editorial values were preserved.')
        if not dutch_topic:
            self.stdout.write('Dutch companion article skipped: run seed_curriculum first to create its original topic.')

    def seed_course(self, course, created):
        language, added = Language.objects.get_or_create(code=course['code'], defaults={
            'name': course['name'], 'slug': course['slug'], 'description': course['description'],
            'is_published': True})
        created['languages'] += int(added)
        levels = {}
        for order, code in enumerate(LEVEL_CODES):
            description = (
                f'{course["name"]} {code}: authored starter activities; more material is being developed.'
                if code in ('A0', 'A1') else
                f'{course["name"]} {code}: content is being developed. No complete syllabus is published for this level.')
            levels[code], added = Level.objects.get_or_create(language=language, code=code,
                defaults={'order': order, 'description': description})
            created['levels'] += int(added)
        previous_by_level = {}
        position_by_level = {}
        for data in course['units']:
            level = levels[data['level']]
            position_by_level[data['level']] = position_by_level.get(data['level'], 0) + 1
            unit, unit_added = Unit.objects.get_or_create(level=level, slug=data['slug'], defaults={
                'title': data['title'], 'summary': data['summary'], 'outcomes': data['outcomes'],
                'order': position_by_level[data['level']], 'published': True})
            created['units'] += int(unit_added)
            if unit_added and data['level'] in previous_by_level:
                unit.prerequisites.add(previous_by_level[data['level']])
            previous_by_level[data['level']] = unit
            grammar_check = next(q for item in data['lessons'] if item['skill'] == 'grammar'
                                 for q in item.get('exercises', []) if q['kind'] == 'mcq')
            topic, added = GrammarTopic.objects.get_or_create(level=level, slug=data['slug'], defaults={
                'title': data['title'], 'explanation': data['explanation'], 'examples': data['examples'],
                'exceptions': data['exceptions'], 'common_mistakes': data['common_mistakes'],
                'audio_text': data['examples'][0], 'check_question': grammar_check['prompt'],
                'check_options': grammar_check['options'], 'check_answer': grammar_check['answer'], 'published': True})
            created['topics'] += int(added)
            if data.get('rich'):
                _, added = GrammarArticle.objects.get_or_create(topic=topic, defaults={'content': data['rich']})
                created['articles'] += int(added)
            for order, item in enumerate(data['lessons'], 1):
                # V99: future starter seeding contains no ungraded free-writing /
                # speaking self-review in the required Learn & Play progression.
                # Do not touch existing Manager-authored or historical records.
                if item['skill'] in ('speaking', 'writing') and not item.get('exercises'):
                    continue
                from academy.audio_v78 import approved_audio_url
                playable_seed = item['skill'] != 'listening' or bool(
                    approved_audio_url(item['audio_text'], course['code']))
                lesson, added = Lesson.objects.get_or_create(unit=unit, slug=item['skill'], defaults={
                    'skill': item['skill'], 'title': item['title'], 'content': item['content'],
                    'audio_text': item['audio_text'], 'order': order, 'published': playable_seed})
                created['lessons'] += int(added)
                for number, source in enumerate(item.get('exercises', []), 1):
                    exercise = starter_activity(source)
                    _, added = Exercise.objects.get_or_create(lesson=lesson, order=number, defaults={
                        'kind': exercise['kind'], 'prompt': exercise['prompt'],
                        'options': exercise.get('options', []), 'answer': exercise['answer'],
                        'explanation': exercise['explanation'], 'activity_data': exercise.get('activity_data', {}), 'difficulty': 1 if data['level'] == 'A0' else 2})
                    created['questions'] += int(added)
            for item in data['vocabulary']:
                defaults = {key: item[key] for key in ('translation', 'pronunciation', 'example', 'emoji')}
                defaults['published'] = True
                _, added = Vocabulary.objects.get_or_create(level=level, word=item['word'], defaults=defaults)
                created['words'] += int(added)

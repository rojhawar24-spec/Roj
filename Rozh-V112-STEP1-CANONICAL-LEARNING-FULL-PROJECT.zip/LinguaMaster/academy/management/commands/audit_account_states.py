"""Read-only review of account state after migration 0009.

Prints aggregate counts without personal identifiers or secrets. No writes.
"""
from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from academy.models import Profile


class Command(BaseCommand):
    help = 'Read-only summary of account activation, verification and manager suspension.'

    def handle(self, *args, **options):
        User = get_user_model()
        counts = {
            'total': User.objects.count(),
            'active': User.objects.filter(is_active=True).count(),
            'manager_suspended': Profile.objects.filter(suspended_at__isnull=False).count(),
            'historical_review_required': Profile.objects.filter(legacy_review_required=True).count(),
            'pending_email': Profile.objects.filter(user__is_active=False,
                suspended_at__isnull=True, email_verified_at__isnull=True,
                legacy_review_required=False).count(),
            'inactive_verified_unclassified': Profile.objects.filter(user__is_active=False,
                suspended_at__isnull=True, email_verified_at__isnull=False).count(),
            'suspended_but_active_anomaly': Profile.objects.filter(user__is_active=True,
                suspended_at__isnull=False).count(),
        }
        self.stdout.write('LinguaMaster account status audit — read-only; no identifiers printed.')
        for key, value in counts.items():
            self.stdout.write(f'{key}: {value}')
        if (counts['inactive_verified_unclassified'] or counts['suspended_but_active_anomaly']
                or counts['historical_review_required']):
            self.stdout.write(self.style.WARNING(
                'Manual owner review required. Do NOT mass-activate accounts.'))
        self.stdout.write('Legacy pending accounts are held for owner review until explicitly released.')

"""Read-only publication QA: python manage.py audit_learning_content [--strict] [--json]."""
import json
from django.core.management.base import BaseCommand, CommandError
from academy.content_audit import audit_published_content


class Command(BaseCommand):
    help = 'Review published language content for missing lessons, broken answer keys and weak explanations.'

    def add_arguments(self, parser):
        parser.add_argument('--strict', action='store_true', help='Fail if published content contains consistency errors.')
        parser.add_argument('--json', action='store_true', help='Print machine-readable JSON.')

    def handle(self, *args, **options):
        # Retain all issues for the command; the private manager UI is capped.
        report = audit_published_content(max_issues=100000)
        if options['json']:
            self.stdout.write(json.dumps(report, ensure_ascii=False))
        else:
            self.stdout.write(f"Published: {report['totals']} | Errors: {report['errors']} | Warnings: {report['warnings']}")
            for issue in report['issues']:
                self.stdout.write(f"[{issue['severity'].upper()}] {issue['code']} — {issue['message']}")
            self.stdout.write('Educational accuracy, pronunciation, WCAG, GDPR, and external security are NOT certified by this check.')
        if options['strict'] and report['errors']:
            raise CommandError(f"Content QA failed with {report['errors']} consistency error(s).")

"""Audit legacy published listening lessons without approved audio; opt-in unpublish.

Read-only by default. Never delete authored content, attempts, XP or user data.
Does not claim to create audio, complete a learner round, or approve a recording.
"""
from contextlib import nullcontext
from django.core.management.base import BaseCommand
from django.db import transaction

from academy.audio_v78 import approved_audio_url
from academy.models import Lesson


class Command(BaseCommand):
    help = 'Audit published lessons with missing approved audio (dry run by default).'

    def add_arguments(self, parser):
        parser.add_argument('--apply', action='store_true',
                            help='Explicitly unpublish only affected listening lessons after reviewing the dry run.')

    def handle(self, *args, **options):
        affected = []
        with (transaction.atomic() if options['apply'] else nullcontext()):
            rows = (Lesson.objects.select_related('unit__level__language')
                    .filter(published=True, skill='listening').order_by('pk'))
            if options['apply']:
                rows = rows.select_for_update()
            for lesson in rows:
                if approved_audio_url(lesson.audio_text, lesson.unit.level.language.code):
                    continue
                affected.append(lesson.pk)
                self.stdout.write(f'UNREADY lesson_id={lesson.pk} course={lesson.unit.level.language.code} '
                                  f'unit_id={lesson.unit_id} title={lesson.title!r}')
                if options['apply']:
                    lesson.published = False
                    # Invalidate stale completion signatures if editors later republish.
                    lesson.content_version += 1
                    lesson.save(update_fields=['published', 'content_version'])
        mode = 'UNPUBLISHED' if options['apply'] else 'DRY RUN; NOTHING CHANGED'
        self.stdout.write(f'{mode}: {len(affected)} affected listening lessons.')
        if not options['apply'] and affected:
            self.stdout.write('After database backup and Manager review, rerun with --apply if appropriate.')

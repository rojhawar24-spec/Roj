"""Read-only audit of non-onboarded users with no recorded core learning activity.

This private operator command outputs account IDs/usernames, never email or
secrets. Run on a restored database COPY, not an unreviewed production shell.
"""
from django.core.management.base import BaseCommand, CommandError
from django.db.models import Exists, OuterRef
from academy.models import (
    Profile, LessonProgress, Assessment, ReviewCard, MistakeRecord,
    SkillPracticeAttempt, CoinEvent,
)
from academy.course_models import CourseEnrollment
from academy.grammar_models import GrammarMastery


class Command(BaseCommand):
    help = 'Read-only list of accounts with onboarding_completed=False and no recorded core learning activity.'

    def add_arguments(self, parser):
        parser.add_argument('--limit', type=int, default=100, help='Maximum rows to print (1..1000)')

    def handle(self, *args, **options):
        limit = options['limit']
        if not 1 <= limit <= 1000:
            raise CommandError('Limit must be between 1 and 1000')
        # Only load the projected safe fields. In particular, avoid loading
        # stored encrypted MFA seeds using a potentially different test key.
        rows = (Profile.objects.filter(
            onboarding_completed=False, xp=0, streak=0, coins=0,
            last_active_day__isnull=True,
        ).annotate(
            has_lesson=Exists(LessonProgress.objects.filter(user_id=OuterRef('user_id'))),
            has_assessment=Exists(Assessment.objects.filter(user_id=OuterRef('user_id'))),
            has_course=Exists(CourseEnrollment.objects.filter(user_id=OuterRef('user_id'))),
            has_review=Exists(ReviewCard.objects.filter(user_id=OuterRef('user_id'))),
            has_mistake=Exists(MistakeRecord.objects.filter(user_id=OuterRef('user_id'))),
            has_skill=Exists(SkillPracticeAttempt.objects.filter(user_id=OuterRef('user_id'))),
            has_coin=Exists(CoinEvent.objects.filter(user_id=OuterRef('user_id'))),
            has_grammar=Exists(GrammarMastery.objects.filter(user_id=OuterRef('user_id'))),
        ).filter(
            has_lesson=False, has_assessment=False, has_course=False,
            has_review=False, has_mistake=False, has_skill=False,
            has_coin=False, has_grammar=False,
        ).select_related('user').only(
            'user_id','onboarding_required',
            'user__id','user__username','user__is_staff','user__is_superuser',
            'user__is_active',
        ).order_by('user_id'))
        n = rows.count()
        self.stdout.write('READ ONLY: private onboarding review; never publish this output.')
        self.stdout.write('Matching accounts: %d' % n)
        for profile in rows[:limit]:
            user = profile.user
            role = 'manager' if user.is_staff or user.is_superuser else 'learner'
            self.stdout.write('id=%s username=%s role=%s required=%s active=%s' %
                (user.pk, user.get_username(), role,
                 profile.onboarding_required, user.is_active))
        if n > limit:
            self.stdout.write('Only first %d accounts printed; rerun with --limit.' % limit)
        self.stdout.write('No fields were modified. Some older learning data may exist outside these activity models.')

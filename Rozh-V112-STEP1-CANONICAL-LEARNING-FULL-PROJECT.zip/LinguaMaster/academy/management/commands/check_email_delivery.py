"""Report mailer readiness, optionally send a real opt-in SMTP probe."""
from django.conf import settings
from django.core.mail import EmailMessage
from django.core.management.base import BaseCommand, CommandError

class Command(BaseCommand):
    help = 'Inspect transactional mail; --send --to is required for an external SMTP probe.'
    def add_arguments(self, parser):
        parser.add_argument('--to', help='An email inbox you own')
        parser.add_argument('--send', action='store_true')
    def handle(self, *args, **options):
        configured = settings.MAILERS['default']
        backend = configured['BACKEND']
        kind = ('SMTP' if backend.endswith('.smtp.EmailBackend') else
                'PRIVATE_FILE' if backend.endswith('.filebased.EmailBackend') else 'MEMORY')
        self.stdout.write('Mail mode: ' + kind)
        if kind == 'PRIVATE_FILE':
            self.stdout.write('Local development: open .private-email-outbox as an email inbox; no links are printed in logs.')
        if not options['send']:
            self.stdout.write('No message sent. Optional: --send --to you@example.org')
            return
        recipient = options.get('to')
        if not recipient or '@' not in recipient or len(recipient) > 254:
            raise CommandError('Valid --to address required when using --send')
        if kind != 'SMTP':
            raise CommandError('SMTP is not configured; a local file is not inbox delivery')
        cfg = configured['OPTIONS']
        if not cfg.get('host') or not settings.DEFAULT_FROM_EMAIL:
            raise CommandError('Missing SMTP host or sender')
        try:
            count = EmailMessage('LinguaMaster SMTP check',
                'The SMTP gateway accepted this message. Check your inbox for delivery.',
                settings.DEFAULT_FROM_EMAIL, [recipient]).send()
        except Exception:
            raise CommandError('SMTP transport failed; review configuration privately, no secrets logged') from None
        if count != 1:
            raise CommandError('SMTP gateway did not accept the message')
        self.stdout.write(self.style.SUCCESS('SMTP gateway accepted one test message. Inbox receipt unverified.'))

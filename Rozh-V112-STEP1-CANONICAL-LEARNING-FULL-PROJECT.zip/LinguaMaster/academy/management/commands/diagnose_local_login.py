"""Read-only, local-only authentication diagnosis; never prints passwords or secrets.

Run through Diagnose-LinguaMaster-Login.ps1 inside the installed project.
No user is changed, activated, unlocked, or granted access by this command.
"""
from getpass import getpass
from pathlib import Path

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.exceptions import ImproperlyConfigured, ObjectDoesNotExist
from django.core.management.base import BaseCommand, CommandError
from django.db.models import Q


class Command(BaseCommand):
    help = "Diagnose a local learner sign-in without changing any account or secret."

    def add_arguments(self, parser):
        parser.add_argument('--verify-password', action='store_true', help='Interactively check a password without showing it')

    def handle(self, *args, **options):
        if not settings.DEBUG or settings.DATABASES['default']['ENGINE'] != 'django.db.backends.sqlite3':
            raise CommandError('This command works only in local DEBUG=1 SQLite mode.')
        db_path = Path(settings.DATABASES['default']['NAME'])
        if not db_path.is_file():
            raise CommandError('Local database file does not exist. Check the installed project folder.')
        self.stdout.write('LinguaMaster local login diagnosis — read-only')
        self.stdout.write('Database location: ' + str(db_path))
        User = get_user_model()
        self.stdout.write('Total accounts in this local database: ' + str(User.objects.count()))
        identifier = input('Enter username or email (NOT password): ').strip()
        if not identifier:
            raise CommandError('Enter a username or email to check.')
        user = User.objects.filter(Q(username__iexact=identifier) | Q(email__iexact=identifier)).first()
        if user is None:
            self.stdout.write('RESULT: No matching account in THIS database.')
            self.stdout.write('Confirm you installed into the same folder as your original database.')
            return
        self.stdout.write('RESULT: Account exists in this database (identifier hidden).')
        self.stdout.write('Account active: ' + ('YES' if user.is_active else 'NO'))
        self.stdout.write('Role: ' + ('manager (superuser)' if user.is_superuser else 'staff' if user.is_staff else 'learner'))
        try:
            profile = user.learning_profile
            self.stdout.write('Profile exists: YES')
            self.stdout.write('Email verified: ' + ('YES' if profile.email_verified_at is not None else 'NO'))
            self.stdout.write('Manager suspension: ' + ('YES' if profile.suspended_at is not None else 'NO'))
            self.stdout.write('Historical account review required: ' + ('YES' if profile.legacy_review_required else 'NO'))
            if profile.suspended_at is not None:
                self.stdout.write('Action: contact the authorised manager; verification cannot lift a suspension.')
            elif profile.legacy_review_required:
                self.stdout.write('Action: authorised owner review is required. For your OWN isolated local machine, run Recover-LinguaMaster-Local-Account.ps1 -Username <username> -ChangePassword; suspended accounts remain forbidden.')
            elif not user.is_active:
                self.stdout.write('Action: complete normal email verification before signing in.')
            self.stdout.write('MFA enabled: ' + ('YES' if profile.totp_secret else 'NO'))
        except (ImproperlyConfigured, ValueError) as exc:
            self.stdout.write(self.style.ERROR('MFA secret cannot be decrypted. The local server may be using a different key. Restore the original DJANGO_SECRET_KEY / LINGUAMASTER_TOTP_KEY; do not reset or bypass MFA.'))
            return
        except ObjectDoesNotExist:
            self.stdout.write(self.style.ERROR('Profile missing. Inspect signals/migrations before continuing.'))
            return
        if options['verify_password']:
            secret = getpass('Enter password to check (not displayed): ')
            if not secret:
                self.stdout.write('Password check skipped.')
            else:
                self.stdout.write('Password correct: ' + ('YES' if user.check_password(secret) else 'NO'))
        self.stdout.write('If credentials and verification are valid but Login displays HTTP 429, wait for the rate-limit window (15 minutes). Do not disable throttling.')
        self.stdout.write('No account data, MFA state, or passwords were modified.')

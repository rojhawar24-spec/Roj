"""Atomic, opt-in updates for structured grammar authoring files."""
import json
from pathlib import Path

from django.core.exceptions import ValidationError
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from academy.grammar_rich_models import GrammarArticle
from academy.models import AuditEvent, GrammarTopic, Language, Level
from academy.rich_schema import _list, _object, _text, normalize_article


TOPIC_TEXT = {'title': 140, 'explanation': 16000, 'exceptions': 8000,
              'common_mistakes': 8000, 'audio_text': 4000,
              'check_question': 2000, 'check_answer': 180}
TOPIC_KEYS = ('level', 'slug', 'article', 'examples', 'check_options', 'published', *TOPIC_TEXT)


def import_document(document, *, update=False, dry_run=False):
    """Validate the entire file and commit all topics together, or none of them."""
    _object(document, 'document', ('schema_version', 'language', 'topics'),
            ('schema_version', 'language', 'topics'))
    if type(document['schema_version']) is not int or document['schema_version'] != 1:
        raise ValidationError('schema_version must be 1.')
    language_code = _text(document['language'], 'language', 8)
    language = Language.objects.filter(code=language_code).first()
    if language is None:
        raise ValidationError(f'Language {language_code!r} does not exist. Create the course first.')
    entries = _list(document['topics'], 'topics', 100, 1)
    prepared, seen = [], set()
    for index, item in enumerate(entries):
        path = f'topics[{index}]'
        _object(item, path, TOPIC_KEYS, ('level', 'slug', 'article'))
        code = _text(item['level'], path + '.level', 2)
        if code not in ('A0', 'A1', 'A2', 'B1', 'B2', 'C1'):
            raise ValidationError(path + '.level: choose A0, A1, A2, B1, B2 or C1.')
        level = Level.objects.filter(language=language, code=code).first()
        if level is None:
            raise ValidationError(f'{path}: level {code} does not exist in {language_code}.')
        slug = _text(item['slug'], path + '.slug', 100)
        identity = (code, slug)
        if identity in seen:
            raise ValidationError(f'{path}: duplicate topic identity {code}/{slug}.')
        seen.add(identity)
        values = {}
        for key, limit in TOPIC_TEXT.items():
            if key in item:
                values[key] = _text(item[key], path + '.' + key, limit, key in ('title', 'explanation'))
        for key, limit in (('examples', 20), ('check_options', 8)):
            if key in item:
                values[key] = [_text(value, path + '.' + key, 500)
                    for value in _list(item[key], path + '.' + key, limit)]
        if 'published' in item:
            if type(item['published']) is not bool:
                raise ValidationError(path + '.published: must be true or false.')
            values['published'] = item['published']
        prepared.append((level, slug, values, normalize_article(item['article'])))
    counts = {'created': 0, 'updated': 0, 'skipped': 0}
    with transaction.atomic():
        for level, slug, values, article in prepared:
            topic = GrammarTopic.objects.filter(level=level, slug=slug).first()
            if topic is not None and not update:
                counts['skipped'] += 1
                continue
            creating = topic is None
            if creating:
                required = ('title', 'explanation', 'examples', 'exceptions', 'common_mistakes',
                            'check_question', 'check_options', 'check_answer')
                missing = [field for field in required if not values.get(field)]
                if missing:
                    raise ValidationError(f'{level.code}/{slug}: new topics need ' + ', '.join(missing) + '.')
                topic = GrammarTopic(level=level, slug=slug)
            for field, value in values.items():
                setattr(topic, field, value)
            if topic.check_options:
                if (len(topic.check_options) < 2 or topic.check_answer not in topic.check_options
                        or len({value.casefold() for value in topic.check_options}) != len(topic.check_options)):
                    raise ValidationError(f'{level.code}/{slug}: check_options need distinct choices and the correct answer.')
            elif topic.published and topic.check_answer.strip():
                raise ValidationError(f'{level.code}/{slug}: published check needs answer choices.')
            if not creating:
                topic.content_version += 1
            topic.full_clean()
            topic.save()
            GrammarArticle.objects.update_or_create(topic=topic, defaults={'content': article})
            counts['created' if creating else 'updated'] += 1
            AuditEvent.objects.create(action='grammar_import', target=f'academy.GrammarTopic:{topic.pk}',
                                      metadata={'created': creating, 'content_version': topic.content_version})
        if dry_run:
            transaction.set_rollback(True)
    return counts


class Command(BaseCommand):
    help = 'Import text-only rich grammar JSON. Existing topics are preserved unless --update is specified.'

    def add_arguments(self, parser):
        parser.add_argument('file', help='Path to the UTF-8 JSON authoring file.')
        parser.add_argument('--dry-run', action='store_true', help='Validate and report without saving any change.')
        parser.add_argument('--update', action='store_true', help='Explicitly replace matching topic fields and rich articles.')

    def handle(self, *args, **options):
        try:
            with Path(options['file']).open('rb') as stream:
                raw = stream.read(2 * 1024 * 1024 + 1)
            if len(raw) > 2 * 1024 * 1024:
                raise CommandError('Authoring files must be no larger than 2 MiB.')
            document = json.loads(raw.decode('utf-8-sig'))
            counts = import_document(document, update=options['update'], dry_run=options['dry_run'])
        except (OSError, UnicodeError, json.JSONDecodeError, ValidationError) as exc:
            message = '; '.join(exc.messages) if isinstance(exc, ValidationError) else str(exc)
            raise CommandError(message) from exc
        prefix = 'DRY RUN — nothing saved. ' if options['dry_run'] else ''
        self.stdout.write(self.style.SUCCESS(prefix + ', '.join(f'{key}: {value}' for key, value in counts.items())))

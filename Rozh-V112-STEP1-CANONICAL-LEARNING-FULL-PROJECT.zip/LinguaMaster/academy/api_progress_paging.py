"""Bound the per-user progress feed without importing Django or DRF.

A large completion history must never produce an unbounded HTTP response.
The default page covers existing small accounts unchanged; older callers with
more completions can follow ``next_offset``. This is a response-contract change
for large accounts and must be tested with real Django clients before launch.
"""

DEFAULT_LIMIT = 100
MAX_LIMIT = 100
MAX_OFFSET = 100_000


class InvalidProgressPage(ValueError):
    """An invalid or excessively expensive pagination request."""


def _decimal_parameter(params, key, *, default, minimum, maximum):
    raw = params.get(key)
    if raw is None:
        return default
    # Query strings should have only unsigned ASCII decimal digits: no +, -,
    # whitespace, scientific notation, Python booleans or huge integer strings.
    if not isinstance(raw, str) or not raw or len(raw) > len(str(maximum)) or not all(
        '0' <= char <= '9' for char in raw
    ):
        raise InvalidProgressPage(f'{key} must be a decimal integer')
    value = int(raw)
    if value < minimum or value > maximum:
        raise InvalidProgressPage(f'{key} must be between {minimum} and {maximum}')
    return value


def parse_progress_page(query_params):
    """Return (limit, offset); fail safely on malformed or excessive requests."""
    limit = _decimal_parameter(query_params, 'limit', default=DEFAULT_LIMIT,
                               minimum=1, maximum=MAX_LIMIT)
    offset = _decimal_parameter(query_params, 'offset', default=0,
                                minimum=0, maximum=MAX_OFFSET)
    return limit, offset

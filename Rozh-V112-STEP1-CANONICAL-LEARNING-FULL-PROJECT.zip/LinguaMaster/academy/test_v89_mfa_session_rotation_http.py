"""V89 security HTTP regression tests (Django REQUIRED; NOT run offline).

These tests must run ONLY with config.settings_local_qa on a disposable test
SQLite database. They explicitly verify that old session keys are invalidated
when authentication assurance changes after MFA verification/enrollment/removal.
"""
import pyotp
from django.contrib.auth import get_user_model
from django.contrib.sessions.models import Session
from django.test import TestCase
from django.urls import reverse

from .models import Profile


class MFASessionIdentifierRotationHTTP(TestCase):
    PASSWORD = 'V89-Disposable-QA-Only-Password!'
    SECRET = 'JBSWY3DPEHPK3PXP'

    def setUp(self):
        self.user = get_user_model().objects.create_user(
            'v89learner', 'v89@example.invalid', self.PASSWORD)
        self.client.force_login(self.user)
        self.old_session_key = self.client.session.session_key
        self.assertTrue(self.old_session_key)

    def assert_rotated(self):
        new_key = self.client.session.session_key
        self.assertNotEqual(new_key, self.old_session_key)
        self.assertFalse(Session.objects.filter(session_key=self.old_session_key).exists())
        self.assertEqual(int(self.client.session['_auth_user_id']), self.user.pk)

    def test_enrollment_rotates_session_and_retains_recovery_codes(self):
        self.assertEqual(self.client.get(reverse('mfa_setup')).status_code, 200)
        secret = self.client.session['mfa_setup_secret']
        response = self.client.post(reverse('mfa_setup'), {
            'password': self.PASSWORD, 'code': pyotp.TOTP(secret).now()})
        self.assertEqual(response.status_code, 302)
        self.assert_rotated()
        self.assertEqual(Profile.objects.get(user=self.user).totp_secret, secret)
        self.assertEqual(self.client.session.get('mfa_verified_id'), self.user.pk)
        self.assertEqual(len(self.client.session['mfa_recovery_codes_once']), 8)
        self.assertNotIn('mfa_setup_secret', self.client.session)

    def test_failed_enrollment_does_not_rotate_or_enroll(self):
        self.client.get(reverse('mfa_setup'))
        secret = self.client.session['mfa_setup_secret']
        response = self.client.post(reverse('mfa_setup'), {
            'password': 'wrong', 'code': pyotp.TOTP(secret).now()})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.client.session.session_key, self.old_session_key)
        self.assertFalse(Profile.objects.get(user=self.user).totp_secret)

    def test_verified_mfa_rotates_even_with_existing_authenticated_session(self):
        profile = Profile.objects.get(user=self.user)
        profile.totp_secret = self.SECRET
        profile.save(update_fields=['totp_secret'])
        session = self.client.session
        from .pending_mfa_binding_step2 import start_pending_mfa
        start_pending_mfa(session, self.user, self.user.learning_profile)
        session.save()
        response = self.client.post(reverse('mfa_verify'), {
            'code': pyotp.TOTP(self.SECRET).now()})
        self.assertEqual(response.status_code, 302)
        self.assert_rotated()
        self.assertEqual(self.client.session.get('mfa_verified_id'), self.user.pk)
        self.assertNotIn('pending_mfa_user_id', self.client.session)

    def test_failed_verification_does_not_rotate(self):
        profile = Profile.objects.get(user=self.user)
        profile.totp_secret = self.SECRET
        profile.save(update_fields=['totp_secret'])
        session = self.client.session
        from .pending_mfa_binding_step2 import start_pending_mfa
        start_pending_mfa(session, self.user, self.user.learning_profile)
        session.save()
        response = self.client.post(reverse('mfa_verify'), {'code': 'invalid'})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.client.session.session_key, self.old_session_key)
        self.assertNotEqual(self.client.session.get('mfa_verified_id'), self.user.pk)

    def test_successful_disable_rotates_and_clears_mfa_assurance(self):
        profile = Profile.objects.get(user=self.user)
        profile.totp_secret = self.SECRET
        profile.save(update_fields=['totp_secret'])
        response = self.client.post(reverse('mfa_disable'), {
            'password': self.PASSWORD, 'code': pyotp.TOTP(self.SECRET).now()})
        self.assertEqual(response.status_code, 302)
        self.assert_rotated()
        self.assertFalse(Profile.objects.get(user=self.user).totp_secret)
        self.assertIsNone(self.client.session.get('mfa_verified_id'))

    def test_failed_disable_does_not_rotate_or_clear_factor(self):
        profile = Profile.objects.get(user=self.user)
        profile.totp_secret = self.SECRET
        profile.save(update_fields=['totp_secret'])
        response = self.client.post(reverse('mfa_disable'), {
            'password': 'wrong', 'code': pyotp.TOTP(self.SECRET).now()})
        self.assertEqual(response.status_code, 403)
        self.assertEqual(self.client.session.session_key, self.old_session_key)
        self.assertTrue(Profile.objects.get(user=self.user).totp_secret)

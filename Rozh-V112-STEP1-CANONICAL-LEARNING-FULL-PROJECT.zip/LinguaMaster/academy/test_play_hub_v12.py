"""Django integration regressions for Play as ONE optional website feature.
Run `python manage.py test academy.test_play_hub_v12` on the installed Django environment.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Language, Level, Unit, Lesson, Exercise, XPEvent, LessonProgress
from .play_center_v12 import COPY


class PlayFeatureTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user=get_user_model().objects.create_user(username='optional-play-student',email='optional@example.org',password='StrongPassword!2026')
        lang=Language.objects.create(name='Dutch',code='nl',slug='optional-dutch',description='Dutch',is_published=True)
        level=Level.objects.create(language=lang,code='A0',order=0,description='Start')
        cls.unit=Unit.objects.create(level=level,slug='optional-hello',title='Groeten',summary='Greeting',order=1,published=True)
        cls.lesson=Lesson.objects.create(unit=cls.unit,slug='hello',title='Hello',skill='grammar',content='Learn hello.',order=1,published=True)
        Exercise.objects.create(lesson=cls.lesson,kind='mcq',prompt='Greeting?',options=['Hallo','Nee'],answer='Hallo',explanation='Hallo is a greeting.')
        profile=cls.user.learning_profile
        profile.placement_completed=True
        profile.preferred_language=lang
        profile.ui_language='nl'
        profile.save()

    def setUp(self):
        self.client.force_login(self.user)

    def test_game_is_an_independent_navigation_destination(self):
        self.assertEqual(reverse('play_hub'),'/play/')
        response=self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'Leer &amp; Speel')  # HTML-escaped text renders as 'Leer & Speel'
        self.assertContains(response,reverse('journey_play',args=[self.unit.pk]))
        self.assertContains(response, '<meta name="robots" content="noindex,nofollow">')

    def test_classic_course_and_game_have_different_paths(self):
        course=self.client.get(reverse('learn_path'))
        game=self.client.get(reverse('play_hub'))
        self.assertEqual(course.status_code,200)
        self.assertEqual(game.status_code,200)
        self.assertContains(course,reverse('lesson',args=[self.lesson.pk]))
        self.assertNotContains(course,reverse('journey_play',args=[self.unit.pk]))
        self.assertContains(game,reverse('journey_play',args=[self.unit.pk]))
        self.assertContains(game,reverse('learn_path'))
        self.assertContains(game,reverse('practice_hub'))
        self.assertContains(self.client.get(reverse('dashboard')),reverse('play_hub'))

    def test_game_menu_does_not_remove_other_features(self):
        response=self.client.get(reverse('dashboard'))
        for name in ('play_hub','learn_path','practice_hub','grammar_library','courses','profile','friends','arena'):
            self.assertContains(response,reverse(name))

    def test_game_get_does_not_award_xp_or_complete_lessons(self):
        self.client.get(reverse('play_hub'))
        self.assertEqual(LessonProgress.objects.filter(user=self.user).count(),0)
        self.assertEqual(XPEvent.objects.filter(user=self.user).count(),0)

    def test_locked_levels_do_not_offer_play_links(self):
        second=Unit.objects.create(level=self.unit.level,slug='locked-v12',title='Next level',summary='Locked',order=2,published=True)
        Lesson.objects.create(unit=second,slug='locked-lesson',title='Locked lesson',skill='grammar',content='Later.',order=1,published=True)
        second.prerequisites.add(self.unit)
        result=self.client.get(reverse('play_hub'))
        self.assertEqual(result.status_code,200)
        self.assertNotContains(result,reverse('journey_play',args=[second.pk]))
        self.assertContains(result,'Eerst vorige level afronden')

    def test_no_course_does_not_offer_an_unplayable_level(self):
        profile=self.user.learning_profile
        profile.preferred_language=None
        profile.save(update_fields=['preferred_language'])
        result=self.client.get(reverse('play_hub'))
        self.assertEqual(result.status_code,200)
        self.assertContains(result,reverse('courses'))
        self.assertNotContains(result,reverse('journey_play',args=[self.unit.pk]))

    def test_game_access_requires_login(self):
        self.client.logout()
        response=self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code,302)
        self.assertIn(reverse('login'),response['Location'])

    def test_translations_complete(self):
        base=set(COPY['nl'])
        for language in ('en','ckb','ar'):
            self.assertEqual(set(COPY[language]),base)
            self.assertTrue(all(COPY[language].values()))

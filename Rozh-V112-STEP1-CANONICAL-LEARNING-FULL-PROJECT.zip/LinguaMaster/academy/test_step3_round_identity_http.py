"""Step 3 real HTTP/SQLite tests, run ONLY in an installed Django QA runtime.

These are not offline-test results. They assert session round identity for both
classic lesson entry points and safe progression after a valid submission.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Exercise, Language, Lesson, LessonProgress, Level, Profile, Unit, XPEvent


class Step3AuthoredRoundIdentityHttpTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user=get_user_model().objects.create_user(
            username='step3-qa-learner',password='SyntheticStep3Password!404')
        cls.language=Language.objects.create(
            code='nl',name='Dutch Stage 3 QA',slug='step3-nl',
            description='Disposable Step 3 test course',is_published=True)
        cls.level=Level.objects.create(language=cls.language,code='A0',
                                       order=0,description='Stage 3 QA')
        cls.unit=Unit.objects.create(level=cls.level,slug='step3-unit',
                                     title='QA only unit',summary='Disposable',published=True,order=1)
        cls.lesson=Lesson.objects.create(unit=cls.unit,slug='step3-lesson',
                                         title='QA only lesson',skill='grammar',
                                         content='Synthetic example only',published=True)
        cls.question=Exercise.objects.create(lesson=cls.lesson,kind='fill_blank',
                                            prompt='Ik ___ thuis.',options=[],answer='ben',
                                            explanation='Ik ben thuis.',difficulty=1)
        Profile.objects.filter(user=cls.user).update(
            preferred_language=cls.language,placement_completed=True,
            onboarding_required=False,onboarding_completed=True,
            suspended_at=None,legacy_review_required=False)

    def setUp(self):
        self.client.force_login(self.user)
        self.lesson_url=reverse('lesson',args=[self.lesson.pk])
        self.answer_url=reverse('lesson_answer',args=[self.lesson.pk])

    def opened_round(self):
        page=self.client.get(self.lesson_url)
        self.assertEqual(page.status_code,200)
        return page.context['lesson_round_key']

    def no_rewards(self):
        self.assertFalse(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user,reason='lesson').exists())

    def test_ajax_missing_round_rejected_before_credit(self):
        self.opened_round()
        response=self.client.post(self.answer_url,{
            'exercise_id':self.question.pk,'answer':'ben'})
        self.assertEqual(response.status_code,409)
        self.assertEqual(response.json()['error_code'],'round_expired')
        self.no_rewards()

    def test_ajax_wrong_round_rejected_before_credit(self):
        self.opened_round()
        response=self.client.post(self.answer_url,{
            'exercise_id':self.question.pk,'answer':'ben','round_key':'0'*32})
        self.assertEqual(response.status_code,409)
        self.assertEqual(response.json()['error_code'],'round_expired')
        self.no_rewards()

    def test_ssr_missing_round_rejected_before_credit(self):
        self.opened_round()
        response=self.client.post(self.lesson_url,{f'answer_{self.question.pk}':'ben'})
        self.assertEqual(response.status_code,409)
        self.no_rewards()

    def test_ssr_wrong_round_rejected_before_credit(self):
        self.opened_round()
        response=self.client.post(self.lesson_url,{
            f'answer_{self.question.pk}':'ben','round_key':'0'*32})
        self.assertEqual(response.status_code,409)
        self.no_rewards()

    def test_ajax_current_round_can_pass_and_old_round_cannot_replay(self):
        round_key=self.opened_round()
        response=self.client.post(self.answer_url,{
            'exercise_id':self.question.pk,'answer':'ben','round_key':round_key})
        self.assertEqual(response.status_code,200)
        self.assertTrue(response.json()['correct'])
        self.assertTrue(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())
        denied=self.client.post(self.answer_url,{
            'exercise_id':self.question.pk,'answer':'ben','round_key':round_key})
        self.assertEqual(denied.status_code,409)

    def test_ssr_current_round_can_pass(self):
        round_key=self.opened_round()
        response=self.client.post(self.lesson_url,{
            f'answer_{self.question.pk}':'ben','round_key':round_key})
        self.assertEqual(response.status_code,200)
        self.assertTrue(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())

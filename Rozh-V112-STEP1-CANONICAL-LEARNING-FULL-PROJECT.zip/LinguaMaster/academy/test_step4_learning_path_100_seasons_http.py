"""Step 4: 100-season server rendering/access checks on disposable Django test DB.

These tests are defined but NOT verified until Django runs in QA CI.
Never run on the user's actual database.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Language, Level, LearningSeason, Unit, Lesson, LessonProgress
from .services import allowed_unit


class LearningPathHundredSeasonHttpTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            'step4_100', 'step4_100@example.invalid', 'Step4_Safe_Test_2026!')
        cls.language = Language.objects.create(
            code='en', name='English', slug='step4-hundred-english', is_published=True)
        cls.level = Level.objects.create(
            language=cls.language, code='A0', order=0, description='A0')
        cls.seasons, cls.units, cls.lessons = [], [], []
        for index in range(1, 101):
            season = LearningSeason.objects.create(
                level=cls.level, slug=f'step4-season-{index}', title=f'Season {index}',
                order=index, published=True)
            unit = Unit.objects.create(
                level=cls.level, season=season, slug=f'step4-unit-{index}',
                title=f'Unit {index}', summary='Step 4 QA only', published=True, order=index)
            lesson = Lesson.objects.create(
                unit=unit, slug='step4-lesson', title=f'Lesson {index}',
                skill='reading', content='QA only', published=True)
            cls.seasons.append(season)
            cls.units.append(unit)
            cls.lessons.append(lesson)
        profile = cls.user.learning_profile
        profile.preferred_language = cls.language
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.save()
        LessonProgress.objects.bulk_create([
            LessonProgress(user=cls.user, lesson=lesson, score=100)
            for lesson in cls.lessons[:74]
        ])

    def setUp(self):
        self.client.force_login(self.user)

    def test_focus_season_seventy_five_without_skipping_access(self):
        response = self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code, 200)
        seasons = response.context['R27_SEASONS']
        self.assertEqual(len(seasons), 100)
        self.assertEqual([s['index'] for s in seasons if s['focused']], [75])
        self.assertTrue(allowed_unit(self.user, self.units[74]))
        self.assertFalse(allowed_unit(self.user, self.units[75]))

    def test_server_provides_real_100_season_selector_and_locked_no_link(self):
        response = self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code, 200)
        html = response.content.decode('utf-8')
        self.assertEqual(html.count('data-r70-season-index="'), 100)
        self.assertIn(f'value="r27-season-s{self.seasons[74].pk}" selected', html)
        self.assertNotIn(self.lessons[99].get_absolute_url(), html)
        self.assertIn('data-r70-season-locked="true"', html)

    def test_direct_locked_lesson_remains_denied_even_with_client_side_anchor(self):
        self.assertFalse(allowed_unit(self.user, self.units[99]))
        response = self.client.get(self.lessons[99].get_absolute_url())
        self.assertNotEqual(response.status_code, 200)

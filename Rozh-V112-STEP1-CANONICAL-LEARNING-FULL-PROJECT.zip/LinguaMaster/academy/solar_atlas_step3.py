"""Read-only Solar Atlas STEP 3 lesson presentation.

No grading rules, answers, database mutations or authorization are defined here.
The published season title is manager-authored; the skin is a visual-only choice.
"""

THEMES = {'dawn': 'dawn', 'coast': 'river', 'grove': 'grove', 'sky': 'sky'}
COPY = {
    'nl': dict(eyebrow='Jouw leerstudio', subtitle='Maak woorden jouw wereld',
               lesson='Les', overview='Leerpad', concept='Ontdek dit eerst',
               exercise='Oefen met aandacht', result='Jouw lesresultaat',
               state='Je oefent met echte lessen; antwoorden worden veilig nagekeken.',
               step='Eén vraag tegelijk', complete='Al voltooid',
               focus='Kies of typ je antwoord en controleer het.',
               heart='Harten', reward='Beloning', continue_path='Terug naar leerpad'),
    'en': dict(eyebrow='Your learning studio', subtitle='Make words your world',
               lesson='Lesson', overview='Learning path', concept='Start with this',
               exercise='Practice with intention', result='Your lesson result',
               state='Real lessons, with answers checked securely.',
               step='One question at a time', complete='Already completed',
               focus='Choose or type your answer, then check it.',
               heart='Hearts', reward='Reward', continue_path='Back to learning path'),
    'ckb': dict(eyebrow='ستۆدیۆی فێربوونت', subtitle='وشەکان بکە بە جیهانی خۆت',
                lesson='وانە', overview='ڕێڕەوی فێربوون', concept='سەرەتا ئەمە بفێربە',
                exercise='بە سەرنجەوە ڕاهێنان بکە', result='ئەنجامی وانەکەت',
                state='وانەکان ڕاستەقینەن و وەڵامەکان بە پارێزراوی پشکنین دەکرێن.',
                step='هەر جارە یەک پرسیار', complete='پێشتر تەواوبووە',
                focus='وەڵامەکەت هەڵبژێرە یان بینووسە، پاشان پشکنینی بکە.',
                heart='دڵەکان', reward='خەڵات', continue_path='گەڕانەوە بۆ ڕێڕەوی فێربوون'),
    'ar': dict(eyebrow='استوديو التعلم', subtitle='اجعل الكلمات عالمك',
               lesson='درس', overview='مسار التعلم', concept='تعرف على هذا أولًا',
               exercise='تدرب بتركيز', result='نتيجة درسك',
               state='دروس حقيقية تُصحّح إجاباتها بأمان.',
               step='سؤال واحد في كل مرة', complete='مكتمل سابقًا',
               focus='اختر أو اكتب إجابتك ثم تحقق منها.',
               heart='القلوب', reward='المكافأة', continue_path='العودة لمسار التعلم'),
}


def lesson_presentation(lesson, language):
    """Only use a published editorial season when rendering its title/theme."""
    season = lesson.unit.season if lesson.unit.season_id else None
    published_season = season if season is not None and season.published else None
    return {
        'skin': THEMES.get(published_season.theme, 'dawn') if published_season else 'dawn',
        'season_title': published_season.title if published_season else '',
        'copy': COPY.get(language, COPY['en']),
    }


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'solar_atlas_step3', ['COPY'])

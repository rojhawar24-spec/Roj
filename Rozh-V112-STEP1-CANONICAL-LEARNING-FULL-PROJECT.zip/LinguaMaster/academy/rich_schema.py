"""Bounded, text-only grammar article schema shared by editors and importers.

Strings are plain text. They are always escaped by Django templates; HTML is
never interpreted as authoring markup.
"""
import json
from .grammar_components_v57 import VISUAL_COMPONENT_TYPES
from django.core.exceptions import ValidationError


ROLES = ('subject', 'verb', 'object', 'time', 'place', 'connector', 'other')
ARTICLE_KEYS = ('intro', 'learning_goals', 'sections', 'rule_tables',
                'sentence_patterns', 'example_pairs', 'common_traps',
                'quick_rules', 'checklist', 'faq', 'visual_blocks')


def _fail(path, message):
    raise ValidationError(f'{path}: {message}', code='invalid_grammar_article')


def _object(value, path, allowed, required=()):
    if not isinstance(value, dict):
        _fail(path, 'must be an object')
    unknown = set(value) - set(allowed)
    if unknown:
        _fail(path, 'unknown field(s): ' + ', '.join(sorted(str(key) for key in unknown)))
    missing = set(required) - set(value)
    if missing:
        _fail(path, 'missing field(s): ' + ', '.join(sorted(missing)))
    return value


def _text(value, path, maximum, required=True):
    if not isinstance(value, str):
        _fail(path, 'must be plain text')
    if len(value) > maximum:
        _fail(path, f'must contain at most {maximum} characters')
    if required and not value.strip():
        _fail(path, 'must not be empty')
    return value.strip()


def _list(value, path, maximum, minimum=0):
    if not isinstance(value, list):
        _fail(path, 'must be a list')
    if not minimum <= len(value) <= maximum:
        _fail(path, f'must contain {minimum}–{maximum} items')
    return value


def normalize_article(value):
    """Validate and return a fresh article with explicit optional defaults."""
    article = _object(value, 'article', ARTICLE_KEYS)
    result = {'intro': _text(article.get('intro', ''), 'intro', 3000, False)}
    result['learning_goals'] = [_text(goal, f'learning_goals[{i}]', 250)
        for i, goal in enumerate(_list(article.get('learning_goals', []), 'learning_goals', 8))]
    sections = []
    for i, item in enumerate(_list(article.get('sections', []), 'sections', 12)):
        path = f'sections[{i}]'
        _object(item, path, ('title', 'body'), ('title', 'body'))
        sections.append({'title': _text(item['title'], path + '.title', 160),
                         'body': _text(item['body'], path + '.body', 8000)})
    result['sections'] = sections
    tables = []
    for i, item in enumerate(_list(article.get('rule_tables', []), 'rule_tables', 8)):
        path = f'rule_tables[{i}]'
        _object(item, path, ('title', 'columns', 'rows', 'note'), ('title', 'columns', 'rows'))
        columns = [_text(column, path + '.columns', 100)
                   for column in _list(item['columns'], path + '.columns', 6, 1)]
        rows = []
        for row_index, row in enumerate(_list(item['rows'], path + '.rows', 30, 1)):
            row_path = f'{path}.rows[{row_index}]'
            _list(row, row_path, len(columns), len(columns))
            rows.append([_text(cell, row_path, 500, False) for cell in row])
        tables.append({'title': _text(item['title'], path + '.title', 160), 'columns': columns,
                       'rows': rows, 'note': _text(item.get('note', ''), path + '.note', 1000, False)})
    result['rule_tables'] = tables
    patterns = []
    for i, item in enumerate(_list(article.get('sentence_patterns', []), 'sentence_patterns', 10)):
        path = f'sentence_patterns[{i}]'
        _object(item, path, ('label', 'tokens'), ('label', 'tokens'))
        tokens = []
        for token_index, token in enumerate(_list(item['tokens'], path + '.tokens', 20, 1)):
            token_path = f'{path}.tokens[{token_index}]'
            _object(token, token_path, ('text', 'role'), ('text', 'role'))
            if token['role'] not in ROLES:
                _fail(token_path + '.role', 'choose one of: ' + ', '.join(ROLES))
            tokens.append({'text': _text(token['text'], token_path + '.text', 100), 'role': token['role']})
        patterns.append({'label': _text(item['label'], path + '.label', 160), 'tokens': tokens})
    result['sentence_patterns'] = patterns
    pairs = []
    for i, item in enumerate(_list(article.get('example_pairs', []), 'example_pairs', 20)):
        path = f'example_pairs[{i}]'
        _object(item, path, ('original', 'translation', 'note'), ('original', 'translation'))
        pairs.append({'original': _text(item['original'], path + '.original', 500),
                      'translation': _text(item['translation'], path + '.translation', 500),
                      'note': _text(item.get('note', ''), path + '.note', 1000, False)})
    result['example_pairs'] = pairs
    traps = []
    for i, item in enumerate(_list(article.get('common_traps', []), 'common_traps', 12)):
        path = f'common_traps[{i}]'
        _object(item, path, ('wrong', 'correct', 'why'), ('wrong', 'correct', 'why'))
        traps.append({'wrong': _text(item['wrong'], path + '.wrong', 500),
                      'correct': _text(item['correct'], path + '.correct', 500),
                      'why': _text(item['why'], path + '.why', 1500)})
    result['common_traps'] = traps
    # V15: editorial blocks remain plain text; template auto-escapes every field.
    if 'quick_rules' in article:
        blocks = []
        for i, item in enumerate(_list(article['quick_rules'], 'quick_rules', 16)):
            path = f'quick_rules[{i}]'
            _object(item, path, ('kind', 'title', 'body'), ('kind', 'title', 'body'))
            if item['kind'] not in ('rule', 'tip', 'warning', 'remember'):
                _fail(path + '.kind', 'must be rule, tip, warning or remember')
            blocks.append({'kind': item['kind'], 'title': _text(item['title'], path+'.title', 160),
                           'body': _text(item['body'], path+'.body', 2500)})
        result['quick_rules'] = blocks
    if 'checklist' in article:
        result['checklist'] = [_text(s, f'checklist[{i}]', 350)
            for i, s in enumerate(_list(article['checklist'], 'checklist', 20))]
    if 'faq' in article:
        faqs = []
        for i, item in enumerate(_list(article['faq'], 'faq', 20)):
            path = f'faq[{i}]'
            _object(item, path, ('question', 'answer'), ('question', 'answer'))
            faqs.append({'question': _text(item['question'], path+'.question', 200),
                         'answer': _text(item['answer'], path+'.answer', 2000)})
        result['faq'] = faqs

    # V17: typed visual blocks. Each layout has an explicit, bounded schema.
    # No HTML, JavaScript, custom URLs, arbitrary style names or raw markup.
    if 'visual_blocks' in article:
        visual = []
        for i, block in enumerate(_list(article['visual_blocks'], 'visual_blocks', 24)):
            path = f'visual_blocks[{i}]'
            if not isinstance(block, dict) or not isinstance(block.get('type'), str):
                _fail(path, 'must have a component type')
            kind = block['type']
            layout = VISUAL_COMPONENT_TYPES.get(kind)
            if layout is None:
                _fail(path + '.type', 'not a supported grammar component')
            common = {'type', 'title'}
            spec = {
                'note': (common | {'body'}, ('type', 'title', 'body')),
                'tokens': (common | {'tokens'}, ('type', 'title', 'tokens')),
                'table': (common | {'columns', 'rows', 'note'}, ('type', 'title', 'columns', 'rows')),
                'compare': (common | {'left', 'right', 'explanation'}, ('type', 'title', 'left', 'right')),
                'steps': (common | {'items', 'note'}, ('type', 'title', 'items')),
                'fill': (common | {'prompt', 'answer', 'hint'}, ('type', 'title', 'prompt', 'answer')),
                'choice': (common | {'prompt', 'options', 'answer', 'hint'}, ('type', 'title', 'prompt', 'options', 'answer')),
                'builder': (common | {'tokens', 'hint'}, ('type', 'title', 'tokens')),
                'accordion': (common | {'entries'}, ('type', 'title', 'entries')),
                'tabs': (common | {'entries'}, ('type', 'title', 'entries')),
                'glossary': (common | {'entries'}, ('type', 'title', 'entries')),
                'flip': (common | {'front', 'back'}, ('type', 'title', 'front', 'back')),
                'tooltip': (common | {'term', 'definition'}, ('type', 'title', 'term', 'definition')),
            }
            allowed, required = spec[layout]
            _object(block, path, allowed, required)
            clean = {'type': kind, 'title': _text(block['title'],path+'.title',160)}
            if layout == 'note':
                clean['body'] = _text(block['body'], path+'.body',2500)
            elif layout == 'tokens':
                clean['tokens'] = []
                for j, token in enumerate(_list(block['tokens'],path+'.tokens',20,1)):
                    tp = f'{path}.tokens[{j}]'
                    _object(token,tp,('text','role'),('text','role'))
                    if token['role'] not in ROLES:
                        _fail(tp+'.role','unknown token role')
                    clean['tokens'].append({'text':_text(token['text'],tp+'.text',120), 'role':token['role']})
            elif layout == 'table':
                clean['columns'] = [_text(v,path+'.columns',120) for v in _list(block['columns'],path+'.columns',6,1)]
                clean['rows'] = []
                for j, row in enumerate(_list(block['rows'],path+'.rows',24,1)):
                    _list(row, f'{path}.rows[{j}]',len(clean['columns']),len(clean['columns']))
                    clean['rows'].append([_text(v,f'{path}.rows[{j}]',400,False) for v in row])
                clean['note'] = _text(block.get('note',''),path+'.note',900,False)
            elif layout == 'compare':
                clean['left'] = _text(block['left'],path+'.left',1000)
                clean['right'] = _text(block['right'],path+'.right',1000)
                clean['explanation'] = _text(block.get('explanation',''),path+'.explanation',1200,False)
            elif layout == 'steps':
                clean['items'] = [_text(v,path+'.items',500) for v in _list(block['items'],path+'.items',12,2)]
                clean['note'] = _text(block.get('note',''),path+'.note',900,False)
            elif layout in ('fill', 'choice'):
                clean['prompt'] = _text(block['prompt'],path+'.prompt',500)
                clean['answer'] = _text(block['answer'],path+'.answer',120)
                clean['hint'] = _text(block.get('hint',''),path+'.hint',600,False)
                if layout == 'choice':
                    clean['options'] = [_text(v,path+'.options',120) for v in _list(block['options'],path+'.options',6,2)]
                    if len(set(v.casefold() for v in clean['options'])) != len(clean['options']):
                        _fail(path+'.options','options must be unique')
                    if clean['answer'] not in clean['options']:
                        _fail(path+'.answer','answer must be among options')
            elif layout == 'builder':
                clean['tokens'] = [_text(v,path+'.tokens',120) for v in _list(block['tokens'],path+'.tokens',12,2)]
                clean['hint'] = _text(block.get('hint',''),path+'.hint',600,False)
            elif layout in ('accordion', 'tabs', 'glossary'):
                clean['entries'] = []
                minimum = 2 if layout in ('tabs', 'glossary') else 1
                for j, entry in enumerate(_list(block['entries'], path+'.entries', 10, minimum)):
                    ep = f'{path}.entries[{j}]'
                    _object(entry, ep, ('title', 'body'), ('title', 'body'))
                    clean['entries'].append({'title': _text(entry['title'], ep+'.title', 160),
                                             'body': _text(entry['body'], ep+'.body', 1500)})
            elif layout == 'flip':
                clean['front'] = _text(block['front'], path+'.front', 800)
                clean['back'] = _text(block['back'], path+'.back', 1200)
            elif layout == 'tooltip':
                clean['term'] = _text(block['term'], path+'.term', 160)
                clean['definition'] = _text(block['definition'], path+'.definition', 1200)
            visual.append(clean)
        result['visual_blocks'] = visual

    if len(json.dumps(result, ensure_ascii=False)) > 90000:
        _fail('article', 'total content must contain at most 90,000 characters')
    return result


def validate_article(value):
    normalize_article(value)

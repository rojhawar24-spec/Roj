"""Course switching preserves placement, global activity and private progress."""
from datetime import date
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import Client, TestCase
from django.urls import reverse
from .course_models import CourseEnrollment
from .courses_v10 import course_name, export_enrollments, record_current_course, switch_course
from .models import (Assessment, Exercise, Language, Lesson, LessonProgress, Level,
                     Profile, Unit, XPEvent)


class CourseSwitchingV10Tests(TestCase):
    def setUp(self):
        cache.clear()
        self.user=get_user_model().objects.create_user('multilingual',email='learner@example.org')
        self.languages={}
        self.lessons={}
        for code,name in [('nl','Dutch'),('en','English'),('de','German'),('fr','French')]:
            language=Language.objects.create(code=code,name=name,slug=code,description=name,is_published=True)
            self.languages[code]=language
            level=Level.objects.create(language=language,code='A0',description='Starter')
            unit=Unit.objects.create(level=level,slug='first',title='First',summary='First steps',published=True)
            lesson=Lesson.objects.create(unit=unit,slug='grammar',title='First lesson',skill='grammar',content='Hello',published=True)
            self.lessons[code]=lesson
            Exercise.objects.create(lesson=lesson,prompt='Hello?',options=['Yes','No'],answer='Yes',explanation='A greeting')
        profile=self.user.learning_profile
        profile.preferred_language=self.languages['nl']
        profile.ui_language='nl'
        profile.placement_completed=True
        profile.placement_level='B1'
        profile.onboarding_completed=True
        profile.xp=125
        profile.streak=7
        profile.last_active_day=date(2026,11,7)
        profile.save()
        LessonProgress.objects.create(user=self.user,lesson=self.lessons['nl'],score=100)
        XPEvent.objects.create(user=self.user,event_key='historic-xp',reason='lesson',amount=25)
        Assessment.objects.create(user=self.user,kind='unit',unit=self.lessons['nl'].unit,passed=True,score=100)
        self.client.force_login(self.user)

    def profile_values(self,code):
        return {'avatar':'🎓','bio':'Languages are fun','ui_language':'nl','daily_goal_xp':20,
            'preferred_language':self.languages[code].pk}

    def test_switch_and_return_preserves_each_courses_starting_point(self):
        english=switch_course(self.user,self.languages['en'],start_at_a0=True)
        self.assertEqual((english.placement_level,english.placement_completed),('A0',True))
        self.assertEqual(CourseEnrollment.objects.get(user=self.user,language=self.languages['nl']).placement_level,'B1')
        english.placement_level='A1'
        english.save(update_fields=['placement_level'])
        record_current_course(english)
        dutch=switch_course(self.user,self.languages['nl'],start_at_a0=True)
        self.assertEqual((dutch.placement_level,dutch.placement_completed),('B1',True))
        english=switch_course(self.user,self.languages['en'])
        self.assertEqual((english.placement_level,english.placement_completed),('A1',True))

    def test_switch_leaves_global_and_course_activity_untouched(self):
        before=(XPEvent.objects.count(),Assessment.objects.count(),LessonProgress.objects.count())
        self.client.post(reverse('course_switch',args=['de']),{'start':'A0'})
        profile=Profile.objects.get(user=self.user)
        self.assertEqual((profile.xp,profile.streak,profile.last_active_day),(125,7,date(2026,11,7)))
        self.assertEqual((XPEvent.objects.count(),Assessment.objects.count(),LessonProgress.objects.count()),before)
        self.assertTrue(LessonProgress.objects.filter(user=self.user,lesson=self.lessons['nl']).exists())

    def test_course_start_is_explicit_a0_and_does_not_require_placement(self):
        Profile.objects.filter(user=self.user).update(preferred_language=None,
            placement_completed=False,onboarding_completed=False,placement_level='A0')
        response=self.client.post(reverse('course_switch',args=['fr']),{'start':'A0'})
        self.assertRedirects(response,reverse('play_hub'),fetch_redirect_response=False)
        profile=Profile.objects.get(user=self.user)
        self.assertEqual(profile.preferred_language,self.languages['fr'])
        self.assertTrue(profile.placement_completed)
        self.assertTrue(profile.onboarding_completed)
        self.assertEqual(profile.placement_level,'A0')

    def test_new_course_placement_option_does_not_copy_other_language_level(self):
        response=self.client.post(reverse('course_switch',args=['en']),{'start':'placement'})
        self.assertRedirects(response,reverse('placement'),fetch_redirect_response=False)
        profile=Profile.objects.get(user=self.user)
        self.assertFalse(profile.placement_completed)
        self.assertEqual(profile.placement_level,'A0')

    def test_same_course_click_never_downgrades_completed_placement(self):
        for _ in range(2):
            self.client.post(reverse('course_switch',args=['nl']),{'start':'A0'})
        profile=Profile.objects.get(user=self.user)
        self.assertEqual((profile.placement_level,profile.placement_completed),('B1',True))
        self.assertEqual(CourseEnrollment.objects.count(),1)

    def test_published_courses_only_and_post_required(self):
        self.languages['de'].is_published=False
        self.languages['de'].save(update_fields=['is_published'])
        self.assertEqual(self.client.post(reverse('course_switch',args=['de']),{'start':'A0'}).status_code,404)
        self.assertEqual(self.client.get(reverse('course_switch',args=['en'])).status_code,405)
        self.assertEqual(self.client.post(reverse('course_switch',args=['en']),{'start':'C1'}).status_code,400)
        self.assertEqual(Profile.objects.get(user=self.user).preferred_language,self.languages['nl'])
        self.assertFalse(CourseEnrollment.objects.exists())

    def test_course_chooser_counts_only_published_material(self):
        lesson=self.lessons['nl']
        Lesson.objects.create(unit=lesson.unit,slug='draft',title='Draft',skill='grammar',content='Draft',published=False)
        draft_unit=Unit.objects.create(level=lesson.unit.level,slug='draft-unit',title='Draft unit',summary='Draft',published=False)
        Lesson.objects.create(unit=draft_unit,slug='hidden',title='Hidden',skill='grammar',content='Hidden',published=True)
        response=self.client.get(reverse('courses'))
        self.assertEqual(response.status_code,200)
        self.assertEqual(len(response.context['cards']),4)
        dutch=response.context['cards'][0]
        self.assertEqual((dutch['lessons'],dutch['units'],dutch['questions'],dutch['completed']),(1,1,1,1))
        self.assertEqual(dutch['stages'][0]['lessons'],1)
        self.assertEqual(dutch['stages'][1]['lessons'],0)
        self.assertContains(response,'Duits')
        self.assertContains(response,'Jouw voortgang')
        self.assertNotContains(response,'course-stages')  # V51: compact list; no 6-level table per language
        self.assertNotContains(response,'Duitslands')

    def test_profile_change_snapshots_old_language_before_bound_form_mutation(self):
        response=self.client.post(reverse('profile'),self.profile_values('en'))
        self.assertEqual(response.status_code,302)
        profile=Profile.objects.get(user=self.user)
        self.assertEqual((profile.placement_completed,profile.placement_level),(False,'A0'))
        old=CourseEnrollment.objects.get(user=self.user,language=self.languages['nl'])
        self.assertEqual((old.placement_completed,old.placement_level),(True,'B1'))
        self.client.post(reverse('profile'),self.profile_values('nl'))
        profile.refresh_from_db()
        self.assertEqual((profile.placement_completed,profile.placement_level),(True,'B1'))
        self.assertEqual(profile.bio,'Languages are fun')

    def test_onboarding_course_change_preserves_returning_course(self):
        values={'ui_language':'ckb','preferred_language':self.languages['en'].pk,'daily_goal_xp':20}
        self.client.post(reverse('onboarding'),values)
        profile=Profile.objects.get(user=self.user)
        self.assertEqual((profile.placement_completed,profile.placement_level),(False,'A0'))
        values['preferred_language']=self.languages['nl'].pk
        self.client.post(reverse('onboarding'),values)
        profile.refresh_from_db()
        self.assertEqual((profile.placement_completed,profile.placement_level),(True,'B1'))
        self.assertEqual(profile.ui_language,'ckb')

    def test_export_is_current_and_private_without_creating_enrollments(self):
        other=get_user_model().objects.create_user('other-learner')
        CourseEnrollment.objects.create(user=other,language=self.languages['de'],placement_level='C1')
        exported=export_enrollments(self.user)
        self.assertEqual(len(exported),1)
        self.assertEqual(exported[0]['language'],'nl')
        self.assertEqual(exported[0]['placement_level'],'B1')
        self.assertTrue(exported[0]['active'])
        self.assertFalse(CourseEnrollment.objects.filter(user=self.user).exists())

    def test_sorani_names_and_rtl(self):
        Profile.objects.filter(user=self.user).update(ui_language='ckb')
        response=self.client.get(reverse('courses'))
        self.assertContains(response,'dir="rtl"')
        for name in ['هۆڵەندی','ئینگلیزی','ئەڵمانی','فەڕەنسی']:
            self.assertContains(response,name)
        self.assertEqual(course_name(self.languages['de'],'nl'),'Duits')

    def test_switch_requires_login_and_csrf(self):
        self.client.logout()
        self.assertEqual(self.client.get(reverse('courses')).status_code,302)
        client=Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        self.assertEqual(client.post(reverse('course_switch',args=['en']),{'start':'A0'}).status_code,403)

    def test_v15_course_flags_use_local_assets_and_real_totals(self):
        """These are live Django test-client assertions; not source-only tests."""
        response=self.client.get(reverse('courses'))
        self.assertEqual(response.status_code,200)
        self.assertEqual([c['language'].code for c in response.context['cards']], ['nl','en','de','fr'])
        for card in response.context['cards']:
            self.assertEqual(card['flag_path'],f"academy/flags/{card['language'].code}.svg")
            self.assertContains(response,f"/static/academy/flags/{card['language'].code}.svg")
            self.assertEqual((card['units'],card['lessons'],card['questions']),(1,1,1))
        self.assertContains(response,'course-flag-frame',count=4)
        self.assertGreaterEqual(response.content.decode('utf-8').count('alt=""'),4)

    def test_v15_unmapped_language_uses_safe_text_fallback(self):
        Language.objects.create(code='es',name='Spanish',slug='es',description='Spanish',is_published=True)
        response=self.client.get(reverse('courses'))
        self.assertEqual(response.status_code,200)
        spanish=next(c for c in response.context['cards'] if c['language'].code=='es')
        self.assertIsNone(spanish['flag_path'])
        self.assertContains(response,'course-flag-fallback')

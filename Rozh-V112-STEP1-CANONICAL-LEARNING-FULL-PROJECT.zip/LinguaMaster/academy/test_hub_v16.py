"""Read-only entry to the existing server-authorized assessments."""
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect,render
from django.views.decorators.http import require_GET
from .services import level_units_passed

@login_required
@require_GET
def tests_hub(request):
    profile=request.user.learning_profile
    if not profile.placement_completed:
        return redirect('placement')
    lang=profile.preferred_language
    levels=[]
    if lang and lang.is_published:
        from .models import Exercise
        available_levels = set(Exercise.objects.filter(
            lesson__unit__level__language=lang, lesson__published=True,
            lesson__unit__published=True, kind='mcq'
        ).values_list('lesson__unit__level_id', flat=True).distinct())
        for level in lang.levels.order_by('order','pk'):
            levels.append({'level':level,'ready':level.pk in available_levels and
                           level_units_passed(request.user,level)})
    return render(request,'academy/tests_hub_v16.html', {'levels':levels,'noindex':True})

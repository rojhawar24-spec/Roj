"""Phase 15 real-Django integration checks (NOT run without installed Django).

Student/Manager boundaries and completed-round ledger; only use a disposable
Django test SQLite database (phase15 isolated runner), never real user data.
"""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .models import (Exercise, HeartEvent, Language, Lesson, LessonProgress,
                     Level, MistakeRecord, Unit, XPEvent)

User = get_user_model()


class StudentLearningReplayTests(TestCase):
    def setUp(self):
        cache.clear()
        self.student = User.objects.create_user('phase15_student', password='TestOnly!2026')
        self.course = Language.objects.create(code='nl', name='Dutch', slug='phase15-dutch',
                                             description='Learning test', is_published=True)
        self.level = Level.objects.create(language=self.course, code='A0', description='Start')
        self.unit = Unit.objects.create(level=self.level, slug='phase15-start', title='Start',
                                        summary='Start', published=True)
        self.lesson = Lesson.objects.create(unit=self.unit, slug='phase15-lesson', title='Greetings',
                                            content='Learning test', skill='grammar', published=True)
        self.exercises = [Exercise.objects.create(lesson=self.lesson, kind='mcq',
                prompt=f'Question {i}', options=['Yes', 'No'], answer='Yes',
                explanation='Answer is yes', order=i) for i in range(4)]
        profile = self.student.learning_profile
        profile.preferred_language = self.course
        profile.placement_completed = True
        profile.onboarding_required = False
        profile.onboarding_completed = True
        profile.save(update_fields=['preferred_language', 'placement_completed',
                                    'onboarding_required', 'onboarding_completed'])
        self.client.force_login(self.student)
        self.answer_url = reverse('lesson_answer', args=[self.lesson.pk])
        self.lesson_url = reverse('lesson', args=[self.lesson.pk])

    def _new_round(self):
        response = self.client.get(self.lesson_url)
        self.assertEqual(response.status_code, 200)
        return response.context['lesson_round_key']

    def _api(self, exercise, answer, round_key):
        return self.client.post(self.answer_url, {
            'exercise_id': exercise.pk, 'answer': answer, 'round_key': round_key,
        })

    def test_student_read_only_journey_does_not_award_xp_or_progress(self):
        for page in ('dashboard', 'play_hub', 'learn_path'):
            with self.subTest(page=page):
                self.assertEqual(self.client.get(reverse(page)).status_code, 200)
        self.assertEqual(XPEvent.objects.filter(user=self.student).count(), 0)
        self.assertEqual(LessonProgress.objects.filter(user=self.student).count(), 0)

    def test_completed_ajax_round_cannot_reopen_mistake_or_duplicate_xp(self):
        token = self._new_round()
        self.assertEqual(self._api(self.exercises[0], 'No', token).status_code, 200)
        for exercise in self.exercises[1:]:
            finished = self._api(exercise, 'Yes', token)
            self.assertEqual(finished.status_code, 200)
        self.assertTrue(finished.json()['completed'])
        self.assertEqual(finished.json()['score'], 75)
        self.assertEqual(XPEvent.objects.filter(user=self.student, reason='lesson').count(), 1)
        mistake = MistakeRecord.objects.get(user=self.student, exercise=self.exercises[0])
        self.assertIsNone(mistake.corrected_at)
        heart_count = HeartEvent.objects.filter(user=self.student, kind='answer').count()

        # Previously, the cleared answers-session let this alter a mistake
        # without a fresh lesson GET, despite no additional XP being granted.
        response = self._api(self.exercises[0], 'Yes', token)
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json()['error_code'], 'round_finished')
        mistake.refresh_from_db()
        self.assertIsNone(mistake.corrected_at)
        self.assertEqual(HeartEvent.objects.filter(user=self.student, kind='answer').count(), heart_count)
        self.assertEqual(XPEvent.objects.filter(user=self.student, reason='lesson').count(), 1)

        new_token = self._new_round()
        self.assertNotEqual(new_token, token)
        self.assertEqual(self._api(self.exercises[0], 'Yes', new_token).status_code, 200)
        mistake.refresh_from_db()
        self.assertIsNotNone(mistake.corrected_at)

    def test_ssr_passed_round_replay_rejected_before_new_mistake_writes(self):
        token = self._new_round()
        body = {'round_key': token}
        for i, exercise in enumerate(self.exercises):
            body[f'answer_{exercise.pk}'] = 'No' if i == 0 else 'Yes'
        self.assertEqual(self.client.post(self.lesson_url, body).status_code, 200)
        self.assertEqual(XPEvent.objects.filter(user=self.student, reason='lesson').count(), 1)
        self.assertEqual(MistakeRecord.objects.filter(user=self.student).count(), 1)
        self.assertEqual(self.client.post(self.lesson_url, body).status_code, 409)
        self.assertEqual(MistakeRecord.objects.filter(user=self.student).count(), 1)
        self.assertEqual(XPEvent.objects.filter(user=self.student, reason='lesson').count(), 1)

    def test_student_cannot_enter_manager_even_with_session_mfa_flag(self):
        session = self.client.session
        session['mfa_verified_id'] = self.student.pk
        session.save()
        for name in ('manager', 'manager_users', 'manager_audit'):
            with self.subTest(name=name):
                self.assertEqual(self.client.get(reverse(name)).status_code, 403)

    def test_user_without_selected_course_cannot_post_lesson_answer(self):
        profile = self.student.learning_profile
        profile.preferred_language = None
        profile.placement_completed = False
        profile.save(update_fields=['preferred_language', 'placement_completed'])
        result = self._api(self.exercises[0], 'Yes', '0' * 32)
        self.assertEqual(result.status_code, 403)
        self.assertFalse(XPEvent.objects.filter(user=self.student).exists())


class OwnerRoleBoundaryTests(TestCase):
    def setUp(self):
        cache.clear()
        self.owner = User.objects.create_superuser(
            'phase15_owner', 'owner-phase15@example.invalid', 'TestOwnerOnly!2026')
        profile = self.owner.learning_profile
        profile.email_verified_at = timezone.now()
        profile.totp_secret = 'JBSWY3DPEHPK3PXP'
        profile.save(update_fields=['email_verified_at', 'totp_secret'])
        self.client.force_login(self.owner)

    def test_owner_requires_verified_mfa_for_manager_and_users(self):
        self.assertEqual(self.client.get(reverse('manager_users')).status_code, 403)
        session = self.client.session
        session['mfa_verified_id'] = self.owner.pk
        session.save()
        self.assertEqual(self.client.get(reverse('manager_users')).status_code, 200)

    def test_manager_user_list_pagination_keeps_search_term(self):
        for index in range(28):
            User.objects.create_user(f'phase15_page_{index:02d}', password='TestUserOnly!2026')
        session = self.client.session
        session['mfa_verified_id'] = self.owner.pk
        session.save()
        url = reverse('manager_users')
        first = self.client.get(url, {'q': 'phase15_page_', 'page': '1'})
        second = self.client.get(url, {'q': 'phase15_page_', 'page': '2'})
        self.assertEqual(first.status_code, 200)
        self.assertEqual(second.status_code, 200)
        self.assertEqual(first.context['page'].number, 1)
        self.assertEqual(second.context['page'].number, 2)
        self.assertEqual(first.context['term'], 'phase15_page_')
        self.assertEqual(second.context['term'], 'phase15_page_')
        self.assertEqual(first.context['page'].paginator.count, 28)
        self.assertEqual(len(first.context['users']), 25)
        self.assertEqual(len(second.context['users']), 3)

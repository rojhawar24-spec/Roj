"""Optional Django integration tests; run only with a provisioned disposable test DB."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Profile

class InterfaceV74HTTP(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user(username='locale74',password='A_very_safe_test_pw74!')
        profile, _ = Profile.objects.get_or_create(user=self.user)
        profile.onboarding_required=False
        profile.onboarding_completed=True
        profile.save(update_fields=['onboarding_required','onboarding_completed'])

    def test_public_canonical_locales(self):
        for lang in ('kmr','uk','fr'):
            with self.subTest(locale=lang):
                resp=self.client.get(reverse('home_'+lang))
                self.assertEqual(resp.status_code,200)
                self.assertContains(resp,'lang="kmr-Arab"' if lang=='kmr' else 'lang="'+lang+'"')
                self.assertContains(resp,'dir="rtl"' if lang=='kmr' else 'dir="ltr"')

    def test_auth_language_switch(self):
        for lang in ('kmr','uk','fr'):
            with self.subTest(locale=lang):
                resp=self.client.get(reverse('login'),{'ui':lang})
                self.assertEqual(resp.status_code,200)
                self.assertContains(resp, 'dir="rtl"' if lang=='kmr' else 'dir="ltr"')

    def test_student_language_switch_preserves_course(self):
        self.client.force_login(self.user)
        old_course=self.user.learning_profile.preferred_language_id
        for lang in ('kmr','uk','fr'):
            resp=self.client.post(reverse('switch_ui_language'),{'ui_language':lang})
            self.assertEqual(resp.status_code,302)
            profile=Profile.objects.get(user=self.user)
            self.assertEqual(profile.ui_language,lang)
            self.assertEqual(profile.preferred_language_id,old_course)

    def test_invalid_language_rejected(self):
        self.client.force_login(self.user)
        resp=self.client.post(reverse('switch_ui_language'),{'ui_language':'../../secret'})
        self.assertEqual(resp.status_code,400)

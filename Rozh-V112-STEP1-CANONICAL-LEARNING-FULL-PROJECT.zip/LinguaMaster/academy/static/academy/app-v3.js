/* First-party progressive enhancement. Quiz deadline, scoring and XP live in Django. */
(() => {
  'use strict';
  const shell = document.querySelector('.v3-arena-run');
  if (!shell) return;
  const form = document.getElementById('arenaQuiz');
  const items = Array.from(form.querySelectorAll('[data-arena-question]'));
  const next = document.getElementById('arenaNext');
  const submit = document.getElementById('arenaSubmit');
  const counter = document.getElementById('arenaCounter');
  const progress = document.getElementById('arenaProgress');
  const time = document.getElementById('arenaTime');
  if (!items.length) return;
  shell.classList.add('js-active');
  form.noValidate = true;
  let current = 0;
  let sent = false;
  // Use wall-clock time; server expiry is authoritative regardless of tab suspension.
  const deadline = Date.now() + Math.max(0,Number(time.dataset.seconds || 0))*1000;
  const show = () => {
    items.forEach((item,index) => {item.hidden = index !== current;});
    const last = current === items.length - 1;
    next.hidden = last;
    submit.hidden = !last;
    counter.textContent = `Question ${current+1} of ${items.length}`;
    progress.value = Math.round(100*current/items.length);
    const legend = items[current].querySelector('legend');
    if (legend) { legend.tabIndex = -1; legend.focus({preventScroll:true}); }
  };
  next.addEventListener('click', () => {
    if (!items[current].querySelector('input:checked')) {
      items[current].querySelector('input')?.focus();
      return;
    }
    current += 1;
    show();
  });
  form.addEventListener('submit', e => {
    if (sent) { e.preventDefault(); return; }
    const missing = items.findIndex(item => !item.querySelector('input:checked'));
    if (Date.now()<deadline && missing!==-1) {
      e.preventDefault();
      current=missing;
      show();
      items[current].querySelector('input')?.focus();
      return;
    }
    sent = true;
    submit.disabled = true;
    progress.value = 100;
  });
  show();
  const countdown = () => {
    const seconds = Math.max(0,Math.ceil((deadline-Date.now())/1000));
    time.textContent = `${seconds}s`;
    if (seconds<=10) time.style.color = '#dc5c38';
    if (seconds===0 && !sent) {
      clearInterval(timer);
      // Submit current answers: expired submissions never receive XP, enforced on server.
      sent=true;
      form.submit();
    }
  };
  const timer=setInterval(countdown,250);
  countdown();
})();

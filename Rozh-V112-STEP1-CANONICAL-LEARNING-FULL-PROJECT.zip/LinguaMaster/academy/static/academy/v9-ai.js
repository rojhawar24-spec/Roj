(() => {
  document.querySelectorAll('[data-ai-prompt]').forEach(button => {
    button.addEventListener('click', () => {
      const input = document.querySelector('.ai-compose textarea');
      if (input) { input.value = button.dataset.aiPrompt; input.focus(); }
    });
  });
})();

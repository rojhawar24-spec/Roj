/* Rozh V17: admin-only visual grammar block builder; does not publish automatically. */
(() => {
 'use strict';
 const TYPES = {"rule_highlight": "note", "rule_tip": "note", "grammar_warning": "note", "exception_explorer": "note", "quick_reference": "note", "prerequisite_card": "note", "learning_objectives": "note", "difficulty_indicator": "note", "lesson_summary": "note", "study_strategy": "note", "remember_card": "note", "context_note": "note", "adaptive_hint": "note", "color_coded_sentence": "tokens", "sentence_breakdown": "tokens", "word_order_diagram": "tokens", "pattern_recognition": "tokens", "word_role_map": "tokens", "clause_map": "tokens", "phrase_anatomy": "tokens", "conjugation_table": "table", "rule_matrix": "table", "pronoun_table": "table", "article_table": "table", "comparative_table": "table", "translation_grid": "table", "before_after": "compare", "common_mistake": "compare", "translation_comparison": "compare", "correction_explainer": "compare", "formal_informal": "compare", "verb_timeline": "steps", "decision_tree": "steps", "mind_map": "steps", "lesson_steps": "steps", "process_map": "steps", "related_lessons": "steps", "spaced_review": "steps", "mastery_check": "steps", "fill_blanks": "fill", "mini_quiz": "choice", "sentence_builder": "builder"};
 const LABELS = {"en": {"title": "Add a visual grammar component", "choose": "Choose one of 42 components", "add": "Add block", "added": "Block added; edit its text in the JSON field and save.", "invalid": "Fix the JSON first.", "limit": "Maximum 24 visual blocks."}, "nl": {"title": "Visueel grammaticablok toevoegen", "choose": "Kies een van 42 componenten", "add": "Blok toevoegen", "added": "Blok toegevoegd; bewerk de JSON en sla op.", "invalid": "Herstel eerst de JSON.", "limit": "Maximaal 24 visuele blokken."}, "ckb": {"title": "زیادکردنی بەشی بینراوی ڕێزمان", "choose": "یەکێک لە ٤٢ بەشەکە هەڵبژێرە", "add": "بەش زیاد بکە", "added": "زیاد کرا؛ لە JSON دەستکاری بکە و پاشەکەوت بکە.", "invalid": "سەرەتا JSON چاک بکەرەوە.", "limit": "زۆرترین ٢٤ بەشی بینراو."}, "ar": {"title": "إضافة جزء بصري للقواعد", "choose": "اختر أحد 42 جزءًا", "add": "إضافة جزء", "added": "تمت الإضافة؛ عدّل JSON ثم احفظ.", "invalid": "أصلح JSON أولاً.", "limit": "الحد 24 جزءًا مرئيًا."}};
 function create(tag,text) {const el=document.createElement(tag);if(text!==undefined)el.textContent=text;return el;}
 function starter(type,layout){
   const block={type,title:type.replace(/_/g,' ')};
   if(layout==='note')block.body='Explain the rule here.';
   if(layout==='tokens')block.tokens=[{text:'Ik',role:'subject'},{text:'leer',role:'verb'},{text:'Nederlands',role:'object'}];
   if(layout==='table'){block.columns=['Subject','Verb'];block.rows=[['ik','leer'],['jij','leert']];block.note='';}
   if(layout==='compare'){block.left='Before';block.right='After';block.explanation='Explain the difference.';}
   if(layout==='steps'){block.items=['First step','Second step'];block.note='';}
   if(layout==='fill'){block.prompt='Ik ____ Nederlands.';block.answer='leer';block.hint='';}
   if(layout==='choice'){block.prompt='Which answer is correct?';block.options=['Ik leer.','Ik leren.'];block.answer='Ik leer.';block.hint='';}
   if(layout==='builder'){block.tokens=['Ik','leer','Nederlands'];block.hint='';}
   return block;
 }
 function boot(){
   const locale=(document.documentElement.lang||'en').split('-')[0];const L=LABELS[locale]||LABELS.en;
   document.querySelectorAll('textarea.v15-grammar-json').forEach((input)=>{
     if(input.dataset.v17Ready==='1')return;input.dataset.v17Ready='1';
     const section=create('section');section.className='g17-author';
     const title=create('h3',L.title);section.append(title);
     const select=create('select');select.setAttribute('aria-label',L.choose);
     const groups={};
     for(const [type,layout] of Object.entries(TYPES)){
       if(!groups[layout]){groups[layout]=create('optgroup');groups[layout].label=layout;select.append(groups[layout]);}
       const option=create('option',type.replace(/_/g,' '));option.value=type;groups[layout].append(option);
     }
     section.append(select);
     const add=create('button',L.add);add.type='button';section.append(add);
     const status=create('p');status.setAttribute('role','status');section.append(status);
     input.parentNode.insertBefore(section,input);
     add.addEventListener('click',()=>{
       let data;try{data=JSON.parse(input.value.trim()||'{}');if(!data||Array.isArray(data)||typeof data!=='object')throw Error('invalid');}catch(_){status.textContent=L.invalid;return;}
       if(!Array.isArray(data.visual_blocks))data.visual_blocks=[];
       if(data.visual_blocks.length>=24){status.textContent=L.limit;return;}
       data.visual_blocks.push(starter(select.value,TYPES[select.value]));
       input.value=JSON.stringify(data,null,2);input.dispatchEvent(new Event('input',{bubbles:true}));status.textContent=L.added;
     });
   });
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
 if('MutationObserver' in window)new MutationObserver(boot).observe(document.documentElement,{childList:true,subtree:true});
})();

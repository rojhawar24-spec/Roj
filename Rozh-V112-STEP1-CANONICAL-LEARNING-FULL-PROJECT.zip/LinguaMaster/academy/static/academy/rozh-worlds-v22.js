/* V22 cosmetic only. No fetch, no account state, no data persistence. */
(() => {
 'use strict';
 const journey = document.querySelector('.lm22-journey');
 if (!journey) return;
 const seasons = [...journey.querySelectorAll('.lm20-season')];
 const nav = [...journey.querySelectorAll('.lm20-index-pill')];
 // Only visually identify the user's server-selected current checkpoint.
 const current = journey.querySelector('[data-lm20-current="true"]');
 if (current) {
   const activeSeason = current.closest('.lm20-season');
   if (activeSeason) {
     const id = activeSeason.id;
     nav.forEach(a => {
       const match = a.getAttribute('href') === '#'+id;
       a.classList.toggle('is-current', match);
       if (match) a.setAttribute('aria-current','location');
       else a.removeAttribute('aria-current');
     });
   }
 }
 const rail = document.querySelector('.lm20-rail-drawer');
 if (rail && window.matchMedia('(min-width: 1151px)').matches) rail.open = true;
 // The original V21 SVG remains responsible for the winding lines.
 seasons.forEach(s => {s.classList.add('lm22-world-ready');});
})();

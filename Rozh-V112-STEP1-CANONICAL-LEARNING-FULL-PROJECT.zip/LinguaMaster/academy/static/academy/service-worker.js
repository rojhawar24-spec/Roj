/* ROZH-V18-DAILY-WORD-ASSETS */
/* Public static assets only; never store user pages, submissions, APIs or assessment answers. */
const CACHE_NAME = 'linguamaster-app-v13-unified-studio-v18-nova-v20-constellation-v21-atlas-20261108-rozh-sun-20261108-transparent-2-v22-worlds-20261108-v23-public-home-20261108-v24-journey-v25-2-professional-20261109-v26-locale-auth-20261109-v27-1-polish-20261109-v28-auth-studio-20261109-v29-dashboard-20261109-v30-dashboard-20261109-v43-dashboard-20261110-v44-clean-20261110-v45-three-zone-20261110-v46-rozh-20261111-v47-manager-locales-20261111-v27-home-studio-20261109-v31-home-20261109-v33-home-20261110-v53-learning-20261111-step5-solar-landing-20261113-step6-solar-auth-20261113-step7-solar-manager-20261113-phase4-vocabulary-20261113-phase5-grammar-daily-20261114-phase6-social-20261114-phase7-ai-privacy-20261114-phase12-lean-pwa-20261114-clean-v10-pwa-ui-20261116-v11-audit-fixes-20261118-v14-design-foundation-20261120-v15-course-flags-20261120-v16-path-20261120-v17-grammar-20261120-v18-daily-20261120-v21-a11y-20261120-v97-self-review-flow-v101-clear-feedback-v102-mixed-five-v103-assessment-blank-v104-five-assessment';
// On a local Django development server never intercept traffic: a stopped
// server must appear as a connection failure, not as a misleading offline page.
const LOCAL_DEVELOPMENT = ['localhost', '127.0.0.1', '[::1]'].includes(self.location.hostname);
const ASSETS = [
  '/static/academy/solar-atlas-step2.css',
  '/static/academy/rozh2027-phase16.css',
  '/static/academy/rozh2027-responsive-v6.css',
  '/static/academy/rozh2027-design-clarity-v9.css',
  '/static/academy/rozh-design-foundation-v14.css',
  '/static/academy/rozh-learning-path-v16.css',
  '/static/academy/rozh-daily-word-v18.css',
  '/static/academy/grammar-visual-v17.css',
  '/static/academy/grammar-visual-v17.js',
  '/static/academy/rozh2027-design-clarity-v9.js',
  '/static/academy/platform-v13.css',
  '/static/academy/studio-v15.css',
  '/static/academy/app-path-v16.css',
  '/static/academy/desktop-v17.css',
  '/static/academy/nova-v18.css',
  '/static/academy/signature-v19.css',
  '/static/academy/constellation-v20.css',
  '/static/academy/constellation-v20.js',
  '/static/academy/rozh-worlds-v22.css',
  '/static/academy/rozh-path-v24.css',
  '/static/academy/rozh-path-v24.js',
  '/static/academy/home-v23.css',
  '/static/academy/home-v25.css',
  '/static/academy/home-v27.css',
  '/static/academy/home-v31-bundle.css',
  '/static/academy/solar-atlas-step5.css',
  '/static/academy/solar-atlas-step6-auth.css',
  '/static/academy/solar-atlas-step7-manager.css',
  '/static/academy/auth-v26.css',
  '/static/academy/auth-v28.css',
  '/static/academy/dashboard-v29.css',
  '/static/academy/dashboard-v30.css',
  '/static/academy/dashboard-v43.css',
  '/static/academy/lm44-clean.css',
  '/static/academy/lm45-three-zone.css',
  '/static/academy/rozh2027.css',
  '/static/academy/rozh2027-v53.css',
  '/static/academy/rozh2027-vocabulary.css',
  '/static/academy/rozh2027-phase5.css',
  '/static/academy/rozh2027-phase6.css',
  '/static/academy/rozh2027-phase7.css',
  '/static/academy/rozh2027-legacy-nav.css',
  '/static/academy/rozh2027.js',
  '/static/academy/rozh2027-icons.svg',
  '/static/academy/rozh-worlds-v22.js',
  '/static/academy/rozh-world-v22-1.svg',
  '/static/academy/rozh-world-v22-2.svg',
  '/static/academy/rozh-world-v22-3.svg',
  '/static/academy/rozh-world-v22-4.svg',
  '/static/academy/rozh-world-v22-5.svg',
  '/static/academy/rozh-world-v22-6.svg',
  '/static/academy/atlas-v21.css',
  '/static/academy/atlas-v21.js',
  '/static/academy/atlas-v21-illustration.svg',
  '/static/academy/rozh-brand.css',
  '/static/academy/rozh-sun-192.png',
  '/static/academy/rozh-sun-512.png',
  '/static/academy/rozh-sun-favicon.png',
  '/static/academy/icon-maskable-512.png',
  '/static/academy/lm20-ai-coach.svg',
  '/static/academy/signature-monogram.svg',
  '/static/academy/signature-emblem.svg',
  '/static/academy/nova-world.svg',
  '/static/academy/nova-companion.svg',
  '/static/academy/nova-mark.svg',
  '/static/academy/app-shell.css',
  '/static/academy/app-v3.css',
  '/static/academy/app-v3.js',
  '/static/academy/app-v4.js',
  '/static/academy/app-v4.css',
  '/static/academy/app-v5.css',
  '/static/academy/auth-v5.css',
  '/static/academy/ux-v7.css',
  '/static/academy/pro-v8.css',
  '/static/academy/ux-v7.js',
  '/static/academy/demo-v8.css',
  '/static/academy/demo-engine.js',
  '/static/academy/demo-v8.js',
  '/static/academy/skill-practice.js',
  '/static/academy/pip-sprout.svg',
  '/static/academy/style.css',
  '/static/academy/app.js',
  '/static/academy/app-experience.js',
  '/static/academy/theme-bootstrap.js',
  '/static/academy/pwa-v9.js',
  '/static/academy/pwa-v9.css',
  '/static/academy/experience-v9.css',
  '/static/academy/experience-v10.css',
  '/static/academy/grammar-v10.css',
  '/static/academy/course-v10.css',
  '/static/academy/course-flags-v15.css',
  '/static/academy/flags/nl.svg',
  '/static/academy/flags/en.svg',
  '/static/academy/flags/de.svg',
  '/static/academy/flags/fr.svg',
  '/static/academy/hearts-v10.css',
  '/static/academy/path-v10.css',
  '/static/academy/journey-v11.css',
  '/static/academy/journey-v11.js',
  '/static/academy/skill-v10.css',
  '/static/academy/photos-v10.css',
  '/static/academy/photos/coffee.jpg',
  '/static/academy/photos/books.jpg',
  '/static/academy/photos/train.jpg',
  '/static/academy/photos/forest.jpg',
  '/static/academy/practice-v9.css',
  '/static/academy/v9-social.css',
  '/static/academy/v9-avatar.js',
  '/static/academy/v9-grammar.css',
  '/static/academy/v9-ai.css',
  '/static/academy/v9-ai.js',
  '/static/academy/icon-192.png',
  '/static/academy/icon-512.png',
  '/static/academy/favicon.svg',
  '/static/academy/offline.html'
];
// Keep the offline-first install small. The allowlist above remains exhaustive
// for backwards compatibility; only visited public static assets are cached.
const PRECACHE = [
  '/static/academy/offline.html',
  '/static/academy/pwa-v9.css',
  '/static/academy/pwa-v9.js',
  '/static/academy/theme-bootstrap.js',
  '/static/academy/rozh-sun-192.png',
  '/static/academy/rozh2027.css',
  '/static/academy/rozh2027-v53.css',
  '/static/academy/rozh2027.js'
];
self.addEventListener('install', event => {
  if (LOCAL_DEVELOPMENT) { event.waitUntil(self.skipWaiting()); return; }
  event.waitUntil(caches.open(CACHE_NAME)
    .then(cache => cache.addAll(PRECACHE))
    .then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(names => Promise.all(
    names.filter(name => name.startsWith('linguamaster-app-') && name !== CACHE_NAME)
         .map(name => caches.delete(name))
  )).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  if (LOCAL_DEVELOPMENT) return; // no stale assets, private pages or offline fallback on localhost
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  // App pages can contain personal data: ALWAYS ask the network, NEVER cache.
  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).catch(async () => {
      const cached = await caches.match('/static/academy/offline.html');
      return cached || Response.error();
    }));
    return;
  }
  if (!ASSETS.includes(url.pathname)) return;
  event.respondWith(caches.open(CACHE_NAME).then(async cache => {
    const cached = await cache.match(request);
    if (cached) return cached;
    const response = await fetch(request);
    // No failed, opaque, external or private responses are cached.
    if (response.ok && response.type !== 'opaque' && response.type !== 'opaqueredirect') {
      try { await cache.put(request, response.clone()); } catch (_) { /* full quota */ }
    }
    return response;
  }).catch(() => fetch(request))); // degraded cache storage must not break online assets
});

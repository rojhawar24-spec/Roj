/* LinguaMaster interactive learning app. No analytics. Answers are graded in Django, never here. */
(() => {
  'use strict';
  document.documentElement.classList.add('js');
  const one = (root, selector) => root.querySelector(selector);
  const all = (root, selector) => Array.from(root.querySelectorAll(selector));
  const formatCount = (template, current, total) => template
    .replace(/\{current\}/g, String(current)).replace(/\{total\}/g, String(total));
  const scrollOptions = block => ({
    behavior: document.documentElement.dataset.reduceMotion === 'true' ||
      window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
    block
  });

  // Keep the PWA offline cache restricted to public app assets.
  if ('serviceWorker' in navigator && window.isSecureContext) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/service-worker.js', {scope:'/'}).catch(() => {});
    });
  }
  // Installation help and native install prompts are managed by pwa-v9.js.

  // Fullscreen-ish study steps, with explicit user control and accessible feedback.
  const lesson = document.querySelector('[data-lesson-root]');
  if (lesson) {
    const label = name => lesson.getAttribute('data-label-' + name) || '';
    const uiError = message => Object.assign(new Error(message), {userFacing:true});
    const intro = one(lesson, '#lessonIntro');
    const practice = one(lesson, '#lessonPractice');
    const finish = one(lesson, '#lessonFinish');
    const form = one(lesson, '#practiceForm');
    const questions = all(form, '[data-exercise-id]');
    const selfReviewSaved = !questions.length && lesson.dataset.selfReviewSaved === 'true';
    if (questions.length) form.noValidate = true; // validate current item manually, not hidden future items
    const start = one(lesson, '#startLesson');
    const feedback = one(lesson, '#lessonFeedback');
    const feedbackTitle = one(lesson, '#lessonFeedbackTitle');
    const feedbackText = one(lesson, '#lessonFeedbackText');
    const solutionBox = one(lesson, '#lessonFeedbackSolution');
    const solutionValue = one(lesson, '#lessonSolutionValue');
    const submit = one(lesson, '#practiceSubmit');
    const next = one(lesson, '#practiceNext');
    const error = one(lesson, '#practiceError');
    const progress = one(lesson, '#lessonProgress');
    const progressText = one(lesson, '#lessonProgressText');
    const counter = one(lesson, '#practiceCount');
    let heartsEmpty = questions.length > 0 && Number(lesson.dataset.heartsRemaining) === 0;
    const updateHearts = state => {
      if (!state || !Number.isInteger(state.remaining)) return;
      lesson.dataset.heartsRemaining = String(state.remaining);
      document.querySelectorAll('[data-heart-count]').forEach(node => { node.textContent = String(state.remaining); });
      heartsEmpty = questions.length > 0 && state.remaining === 0;
      start.disabled = heartsEmpty;
      submit.disabled = heartsEmpty;
      all(lesson, '[data-heart-warning]').forEach(node => { node.hidden = !heartsEmpty; });
    };
    let index = 0;
    let pending = false;
    let latestResult = null;
    practice.hidden = true;
    finish.hidden = !selfReviewSaved;
    const setProgress = value => {
      progress.value = value;
      progress.setAttribute('aria-valuetext', progressText.textContent);
    };
    if (selfReviewSaved) {
      intro.hidden = true;
      progressText.textContent = label('complete');
      setProgress(100);
      const heading = one(finish, '#lessonFinishTitle');
      if (heading) heading.focus({preventScroll:true});
    }
    const setError = message => { error.textContent = message; error.hidden = !message; };
    const showQuestion = () => {
      // V81: unlock only the current question's Memory Match card controls.
      form.dataset.v81Locked = 'false';
      questions.forEach((q, idx) => { q.hidden = idx !== index; });
      feedback.hidden = true;
      feedback.classList.remove('is-incorrect');
      if (solutionBox) solutionBox.hidden = true;
      if (solutionValue) solutionValue.textContent = '';
      next.hidden = true;
      submit.hidden = false;
      setError(heartsEmpty ? label('hearts-empty') : '');
      submit.disabled = heartsEmpty;
      const countLabel = formatCount(label('question-count'), index + 1, questions.length);
      counter.textContent = countLabel + '. ' + label('question-help');
      progressText.textContent = countLabel;
      setProgress(Math.round((index / questions.length) * 100));
      const legend = one(questions[index], 'legend');
      if (legend) { legend.tabIndex = -1; legend.focus({preventScroll:true}); }
    };
    const beginLesson = (scroll = false) => {
      if (heartsEmpty) return;
      intro.hidden = true;
      practice.hidden = false;
      setProgress(0);
      if (questions.length) showQuestion();
      else {
        progressText.textContent = label('independent');
        counter.textContent = label('self-instructions');
      }
      if (scroll) practice.scrollIntoView(scrollOptions('start'));
    };
    start.addEventListener('click', () => beginLesson(true));
    // V63: published authored exercises open directly at question one. Keep
    // the optional explanation expandable; learners never face a second Start.
    // If hearts are exhausted, retain the intro/recovery notice instead.
    if (questions.length && !heartsEmpty) beginLesson(false);
    if (!questions.length) {
      // V97: self-review is a full-page POST, not the AJAX graded-answer endpoint.
      // Without JS the native required checkbox remains the fallback.
      form.noValidate = true;
      const confirmation = one(form, 'input[name=self_check]');
      form.addEventListener('submit', event => {
        if (confirmation && confirmation.checked) return;
        event.preventDefault();
        setError(label('self-confirm-required'));
        if (confirmation) confirmation.focus({preventScroll:true});
      });
      if (confirmation) confirmation.addEventListener('change', () => {
        if (confirmation.checked) setError('');
      });
    }
    if (questions.length) {
      form.addEventListener('submit', async event => {
        event.preventDefault();
        if (pending || latestResult) return;
        if (heartsEmpty) { setError(label('hearts-empty')); return; }
        const question = questions[index];
        const input = one(question, 'input[type=radio]:checked') || one(question, '[data-v58-answer]') || one(question, 'input[type=text], input:not([type])');
        const answer = input ? input.value.trim() : '';
        if (!answer) { setError(label('answer-required')); return; }
        setError('');
        pending = true;
        // Keep the visible answer identical to the one sent to the server.
        question.disabled = true;
        submit.disabled = true;
        submit.textContent = label('checking');
        try {
          const data = new FormData();
          data.set('csrfmiddlewaretoken', one(form, 'input[name=csrfmiddlewaretoken]').value);
          data.set('exercise_id', question.dataset.exerciseId);
          data.set('answer', answer);
          if (form.dataset.roundKey) data.set('round_key', form.dataset.roundKey);
          const response = await fetch(form.dataset.endpoint, {
            method:'POST',body:data,credentials:'same-origin',
            headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest'}
          });
          // Login-required Django endpoints redirect anonymous sessions to the
          // HTML sign-in screen. Never parse that HTML as JSON (or show a cryptic
          // 'Unexpected token <' error) after a learner's session expires.
          if (response.redirected && new URL(response.url).pathname === '/login/') {
            window.location.assign('/login/?next=' + encodeURIComponent(window.location.pathname));
            return;
          }
          if (!(response.headers.get('content-type') || '').includes('application/json')) {
            throw uiError(label('session-expired'));
          }
          const result = await response.json();
          updateHearts(result.hearts);
          if (response.status === 402 && result.error_code === 'hearts_empty') {
            throw uiError(label('hearts-empty'));
          }
          if (!response.ok) {
            const message = response.status === 429 ? label('rate-limit')
              : response.status === 403 ? label('locked')
              : response.status === 409 ? label('already-checked') : label('check-failed');
            throw uiError(message);
          }
          latestResult = result;
          // Prevent modifying submitted memory pairs while server feedback is visible.
          form.dataset.v81Locked = 'true';
          feedback.hidden = false;
          feedback.classList.toggle('is-incorrect',!result.correct);
          feedbackTitle.textContent = result.correct ? label('nice') : label('not-quite');
          feedbackText.textContent = result.explanation || (result.correct ? label('correct-answer') : label('review-idea'));
          if (solutionBox && solutionValue) {
            const solution = !result.correct && typeof result.solution === 'string' ? result.solution : '';
            solutionValue.textContent = solution;
            solutionBox.hidden = !solution;
          }
          submit.hidden = true;
          next.hidden = false;
          next.textContent = result.finished ? label('result') : label('next');
          progressText.textContent = result.correct ? label('good-thinking') : label('learn-from');
          setProgress(Math.round(((index + 1) / questions.length) * 100));
          feedback.scrollIntoView(scrollOptions('nearest'));
          next.focus({preventScroll:true});
        } catch (ex) { setError(ex.userFacing ? ex.message : label('network-error')); }
        finally {
          pending = false;
          // Re-enable after rejected/network submissions; keep accepted answers locked.
          if (!latestResult) question.disabled = false;
          submit.disabled = heartsEmpty; submit.textContent = label('check');
        }
      });
      next.addEventListener('click', () => {
        if (!latestResult) return;
        const result = latestResult;
        latestResult = null;
        if (result.finished) {
          practice.hidden = true;
          finish.hidden = false;
          setProgress(100);
          progressText.textContent = label('complete');
          progress.setAttribute('aria-valuetext', progressText.textContent);
          one(finish,'#lessonFinalScore').textContent = `${result.score}%`;
          one(finish,'#lessonEarnedXp').textContent = `${Number(result.xp_awarded || 0)} XP`;
          const primary = one(finish, '#lessonFinishPrimary');
          const endNote = one(finish, '#lessonFinishNoNext');
          const action = result.next_action;
          if (!result.completed) {
            one(finish,'#lessonFinishTitle').textContent = label('keep-practicing');
            one(finish,'#lessonFinishText').textContent = label('pass-help');
            one(finish,'#lessonEarnedXp').textContent = '0 XP';
            primary.textContent = lesson.dataset.flowRetry || label('retry');
            primary.href = window.location.pathname;
            primary.hidden = false;
            endNote.hidden = true;
          } else {
            if (!result.xp_awarded) one(finish,'#lessonEarnedXp').textContent = label('already-earned');
            // Only a server-issued, same-origin learning URL is navigable.
            // Never infer the next lesson from the client-side question index.
            const isKnownAction = action && (action.kind === 'lesson' || action.kind === 'unit_test');
            const isSafePath = isKnownAction && typeof action.url === 'string' &&
              /^\/(lessons\/\d+\/|assessment\/unit\/\d+\/)$/.test(action.url);
            if (isSafePath) {
              primary.href = action.url;
              primary.textContent = action.kind === 'unit_test'
                ? lesson.dataset.flowPrimaryTest : lesson.dataset.flowPrimaryLesson;
              primary.hidden = false;
              endNote.hidden = true;
            } else {
              primary.hidden = true;
              endNote.hidden = false;
              endNote.textContent = lesson.dataset.flowNoNext;
            }
          }
          finish.scrollIntoView(scrollOptions('start'));
          const finishHeading = one(finish, '#lessonFinishTitle');
          if (finishHeading) finishHeading.focus({preventScroll:true});
        } else {
          index++;
          showQuestion();
        }
      });
      // Optional shortcuts for multiple-choice, without intercepting input typing.
      lesson.addEventListener('keydown', event => {
        if (practice.hidden || pending || latestResult || event.target.closest('input,textarea,select,button')) return;
        const number = Number(event.key);
        if (number >= 1 && number <= 9) {
          const options = all(questions[index], 'input[type=radio]');
          if (options[number - 1]) options[number - 1].checked = true;
        }
      });
    }
  }

  // Placement / unit / level tests progress through one question at a time.
  const assessment = document.querySelector('[data-quiz-wizard]');
  if (assessment) {
    const questions = all(assessment,'[data-assessment-question]');
    assessment.noValidate = true; // future hidden questions have required options
    const next = one(assessment,'#assessmentNext');
    const submit = one(assessment,'#assessmentSubmit');
    const progress = document.getElementById('assessmentProgress');
    const progressText = document.getElementById('assessmentProgressText');
    let index = 0;
    const answerPresent = q => {
      const selects = all(q, '[data-assessment-indexed] select');
      if (selects.length) {
        const values = selects.map(control => control.value);
        return values.every(value => value !== '') && new Set(values).size === values.length;
      }
      const text = one(q, 'input[type="text"]');
      return text ? Boolean(text.value.trim()) : Boolean(one(q, 'input[type=radio]:checked'));
    };
    if (questions.length) {
      next.hidden = false;
      const present = () => {
        questions.forEach((q,i) => { q.hidden = i !== index; });
        const last = index === questions.length - 1;
        next.hidden = last;
        submit.hidden = !last;
        if (progress) progress.value = Math.round((index/questions.length)*100);
        if (progressText) {
          progressText.textContent = formatCount(assessment.dataset.labelQuestionCount || 'Question {current} of {total}', index + 1, questions.length);
          if (progress) progress.setAttribute('aria-valuetext', progressText.textContent);
        }
        const legend = one(questions[index],'legend');
        if (legend) { legend.tabIndex = -1; legend.focus({preventScroll:true}); }
      };
      const refreshChoices = q => {
        const selects = all(q, '[data-assessment-indexed] select');
        selects.forEach(control => {
          const used = new Set(selects.filter(other => other !== control).map(other => other.value));
          Array.from(control.options).forEach(option => {
            option.disabled = option.value !== '' && option.value !== control.value && used.has(option.value);
          });
        });
      };
      questions.forEach(q => {
        refreshChoices(q);
        q.addEventListener('change', () => refreshChoices(q));
      });
      present();
      next.addEventListener('click', () => {
        if (!answerPresent(questions[index])) {
          const first = one(questions[index],'input[type=text],input[type=radio],select');
          if (first) first.focus();
          return;
        }
        if (index < questions.length - 1) { index++; present(); }
      });
      assessment.addEventListener('submit', event => {
        if (questions.some(q => !answerPresent(q))) {
          event.preventDefault();
          const missing = questions.findIndex(q => !answerPresent(q));
          index = missing;
          present();
        }
      });
    }
  }

  // Real spaced repetition cards. No answer is hidden from non-JavaScript users.
  document.querySelectorAll('[data-flashcard]').forEach(card => {
    const answer = one(card,'[data-flash-answer]');
    const reveal = one(card,'[data-flash-reveal]');
    const grade = one(card,'[data-flash-grade]');
    if (!answer || !reveal || !grade) return;
    answer.hidden = true;
    grade.hidden = true;
    reveal.addEventListener('click', () => {
      answer.hidden = false;
      grade.hidden = false;
      reveal.hidden = true;
      grade.scrollIntoView(scrollOptions('nearest'));
    });
  });
})();

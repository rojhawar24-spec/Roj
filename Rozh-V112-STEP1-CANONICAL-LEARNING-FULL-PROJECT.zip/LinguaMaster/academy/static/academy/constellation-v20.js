/* LinguaMaster V20: accessibility-oriented progressive enhancement only.
   No new server routes, account mutations, trackers or simulated user data. */
(() => {
  'use strict';
  const menus = [...document.querySelectorAll('[data-lm20-popover]')];
  menus.forEach(menu => {
    menu.addEventListener('toggle', () => {
      if (menu.open) menus.filter(other => other !== menu).forEach(other => { other.open = false; });
    });
  });
  document.addEventListener('click', event => {
    if (!event.target.closest('[data-lm20-popover]')) menus.forEach(menu => { menu.open = false; });
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      const opened = menus.filter(menu => menu.open);
      opened.forEach(menu => { menu.open = false; });
      if (opened.length) opened[opened.length - 1].querySelector('summary')?.focus();
    }
  });
  const tools = document.querySelector('.lm20-rail-drawer');
  if (tools && window.matchMedia('(max-width: 1280px)').matches) tools.open = false;
  const journey = document.getElementById('learning-journey');
  if (!journey || window.location.hash) return;
  const current = journey.querySelector('[data-lm20-current="true"]');
  if (!current) return;
  // Return to the first unfinished, server-unlocked level. Keep focus unchanged.
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches ||
    document.documentElement.dataset.reduceMotion === 'true';
  window.requestAnimationFrame(() => {
    current.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'auto' });
    if (!reduceMotion) current.classList.add('lm20-resume-current');
  });
})();

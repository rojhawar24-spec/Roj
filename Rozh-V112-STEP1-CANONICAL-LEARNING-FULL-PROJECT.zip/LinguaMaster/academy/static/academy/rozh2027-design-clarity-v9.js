/* CLEAN V9: abbreviate visual XP at narrow phone widths without changing
   backend totals, link targets, accessible full-value labels or saved state. */
(() => {
  'use strict';
  const xpValue = document.querySelector('.r53-student .r53-chip-xp strong');
  if (!xpValue) return;
  const fullValue = xpValue.textContent.trim();
  if (!/^\d+$/.test(fullValue)) return;
  const number = Number(fullValue);
  if (!Number.isSafeInteger(number)) return;
  const compact = new Intl.NumberFormat('en', {notation:'compact', maximumFractionDigits:1}).format(number);
  function updateMobileXp() {
    const phone = window.matchMedia('(max-width: 420px)').matches;
    xpValue.textContent = phone && fullValue.length >= 5 ? compact : fullValue;
  }
  updateMobileXp();
  window.addEventListener('resize', updateMobileXp, {passive:true});
})();

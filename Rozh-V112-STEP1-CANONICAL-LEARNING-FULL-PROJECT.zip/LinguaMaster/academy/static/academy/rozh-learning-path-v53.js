/* Rozh V53: scalable, progressive-enhancement-only season navigation. */
(() => {
  'use strict';
  if (document.querySelector('[data-r70-season-browser]')) return; // V70 owns focused season browsing.
  const region = document.querySelector('[data-r53-path-navigation]');
  const selector = document.querySelector('[data-r53-season-select]');
  if (!region || !selector) return;
  const seasons = Array.from(document.querySelectorAll('.r53-journey details.r53-season'));
  if (!seasons.length) return;
  region.hidden = false;

  function openTarget(id, shouldScroll) {
    // All option values are generated server-side from authorized, published seasons.
    const target = seasons.find(el => el.id === id);
    if (!target) return;
    seasons.forEach(el => { if (el !== target) el.open = false; });
    target.open = true;
    if (shouldScroll) {
      const title = target.querySelector('summary');
      (title || target).scrollIntoView({behavior: 'auto', block: 'start'});
      if (title && shouldScroll) title.focus({preventScroll: true});
    }
  }
  selector.addEventListener('change', () => openTarget(selector.value, true));
  seasons.forEach(el => {
    const summary = el.querySelector('summary');
    if (summary) summary.tabIndex = 0;
    el.addEventListener('toggle', () => {
      if (el.open) {
        seasons.forEach(other => { if (other !== el) other.open = false; });
        selector.value = el.id;
        window.dispatchEvent(new Event('resize'));
      }
    });
  });
  function revealHash() {
    let id = '';
    try { id = decodeURIComponent(window.location.hash.substring(1)); } catch (_) { return; }
    if (!id) return;
    const node = document.getElementById(id);
    const target = node && node.closest('details.r53-season');
    if (target) {
      seasons.forEach(el => { if (el !== target) el.open = false; });
      target.open = true;
      selector.value = target.id;
      requestAnimationFrame(() => node.scrollIntoView({block: 'start'}));
    }
  }
  window.addEventListener('hashchange', revealHash);
  revealHash();
})();

/* V70: focus on the learner's actual season, not a 100-season scroll. */
(() => {
  'use strict';
  const browser = document.querySelector('[data-r70-season-browser]');
  const selector = browser?.querySelector('[data-r53-season-select]');
  const collection = document.querySelector('.r53-seasons');
  if (!browser || !selector || !collection) return;
  const seasons = Array.from(collection.querySelectorAll(':scope > details.r53-season'));
  if (!seasons.length) return;
  const btnPrev = browser.querySelector('[data-r70-previous]');
  const btnNext = browser.querySelector('[data-r70-next]');
  const btnMine = browser.querySelector('[data-r70-my-season]');
  const position = browser.querySelector('[data-r70-active-label]');
  const status = browser.querySelector('[data-r70-active-status]');
  const mine = seasons.find(el => el.hasAttribute('data-r70-focused-season')) || seasons[0];
  let selected = mine;

  function refreshCurves() {
    // Existing snake SVG positions are measured only after the panel is visible.
    window.dispatchEvent(new Event('resize'));
  }
  function reveal(target, options = {}) {
    if (!target || !seasons.includes(target)) return;
    selected = target;
    seasons.forEach(el => {
      el.hidden = el !== target;
      if (el === target) el.open = true;
      else el.open = false;
    });
    selector.value = target.id;
    if (position) {
      const outof = browser.dataset.r70OutofLabel;
      const countSuffix = outof ? ` ${outof} ${seasons.length}` : '';
      position.textContent = `${browser.dataset.r70SeasonLabel || 'Season'} ${target.dataset.r70SeasonIndex}${countSuffix}`;
    }
    if (status) status.textContent = target.dataset.r70SeasonLocked === 'true'
      ? (browser.dataset.r70LockedLabel || 'Locked')
      : target.dataset.r70SeasonComplete === 'true'
        ? (browser.dataset.r70CompleteLabel || 'Completed') : target.dataset.r70SeasonName || '';
    const index = seasons.indexOf(target);
    // A focused native button immediately loses focus when it becomes disabled.
    // On the first/last season, hand keyboard users an enabled control before
    // disabling Previous/Next; otherwise Chromium drops focus to <body>.
    if ((index === 0 && document.activeElement === btnPrev) ||
        (index === seasons.length - 1 && document.activeElement === btnNext) ||
        (target === mine && document.activeElement === btnMine)) {
      // ``My Season`` disables itself on arrival; retain a visible focus
      // target until its requested season summary receives focus on the next frame.
      selector.focus({preventScroll:true});
    }
    if (btnPrev) btnPrev.disabled = index === 0;
    if (btnNext) btnNext.disabled = index === seasons.length - 1;
    if (btnMine) btnMine.disabled = target === mine;
    // Keep the native select or pager button focused, so keyboard users can
    // move across dozens of seasons without having focus stolen on each change.
    // Only record explicit navigation; never overwrite incoming #r27-current
    // links or a user's browser-restored location on initial render.
    if (options.updateUrl) {
      try {
        window.history.replaceState(null, '', '#' + encodeURIComponent(target.id));
      } catch (_) { /* Embedded/locked-down browsers may disallow History API. */ }
    }
    refreshCurves();
    if (options.scroll) {
      requestAnimationFrame(() => {
        // Align the real season, rather than showing a huge list of previous seasons.
        target.querySelector('summary')?.scrollIntoView({behavior:'auto',block:'start'});
        if (options.focus) target.querySelector('summary')?.focus({preventScroll:true});
      });
    }
  }
  browser.hidden = false;
  // Progressive enhancement: without JavaScript the original details list
  // remains available; with JS, all other seasons are removed from layout.
  reveal(mine, {scroll:false});
  collection.classList.add('r70-browser-ready');

  selector.addEventListener('change', () => reveal(seasons.find(el => el.id === selector.value), {updateUrl:true}));
  btnPrev?.addEventListener('click', () => reveal(seasons[seasons.indexOf(selected)-1], {updateUrl:true}));
  btnNext?.addEventListener('click', () => reveal(seasons[seasons.indexOf(selected)+1], {updateUrl:true}));
  btnMine?.addEventListener('click', () => reveal(mine, {scroll:true,focus:true,updateUrl:true}));
  seasons.forEach(el => el.addEventListener('toggle', () => { if (el === selected && el.open) refreshCurves(); }));

  const hashTarget = () => {
    let id = '';
    try { id = decodeURIComponent(window.location.hash.slice(1)); } catch (_) {return false;}
    const node = id ? document.getElementById(id) : null;
    const target = node?.closest('details.r53-season');
    if (!target || !seasons.includes(target)) return false;
    reveal(target, {scroll:true});
    requestAnimationFrame(() => node.scrollIntoView({behavior:'auto',block:'start'}));
    return true;
  };
  window.addEventListener('hashchange', hashTarget);
  if (!hashTarget()) {
    // Initial arrival intentionally lands at the CURRENT season, including
    // season 5/50/100. Browser back with restored scroll is left undisturbed.
    const navigation = performance?.getEntriesByType?.('navigation')?.[0];
    if (navigation?.type !== 'back_forward') {
      window.addEventListener('load', () => {
        requestAnimationFrame(() => {
          const summary = mine.querySelector('summary');
          summary?.scrollIntoView({behavior:'auto',block:'start'});
        });
      }, {once:true});
    }
  }
})();

/* Rozh V57 - 100 visual grammar components, safe Manager-only authoring palette.
 * No remote dependencies, no arbitrary HTML, no automatic publish or save. */
(() => {
'use strict';
const CATALOG=[{"id":"rule_card","label":"Regelkaart","layout":"note","group":"Cards & Callout Blocks"},{"id":"remember_block","label":"Onthoud-blok","layout":"note","group":"Cards & Callout Blocks"},{"id":"tip_card","label":"Tipkaart","layout":"note","group":"Cards & Callout Blocks"},{"id":"info_card","label":"Infokaart","layout":"note","group":"Cards & Callout Blocks"},{"id":"example_card","label":"Voorbeeldkaart","layout":"note","group":"Cards & Callout Blocks"},{"id":"warning_card","label":"Waarschuwingskaart","layout":"note","group":"Cards & Callout Blocks"},{"id":"exception_card","label":"Uitzonderingskaart","layout":"note","group":"Cards & Callout Blocks"},{"id":"common_error_card","label":"Veelgemaakte-foutkaart","layout":"note","group":"Cards & Callout Blocks"},{"id":"correction_card","label":"Correctiekaart","layout":"note","group":"Cards & Callout Blocks"},{"id":"summary_card","label":"Samenvattingskaart","layout":"note","group":"Cards & Callout Blocks"},{"id":"color_coded_sentence","label":"Color-coded Sentences","layout":"tokens","group":"Colors & Highlights"},{"id":"keyword_highlight","label":"Keyword Highlight","layout":"tokens","group":"Colors & Highlights"},{"id":"verb_highlight","label":"Verb Highlight","layout":"tokens","group":"Colors & Highlights"},{"id":"subject_highlight","label":"Subject Highlight","layout":"tokens","group":"Colors & Highlights"},{"id":"object_highlight","label":"Object Highlight","layout":"tokens","group":"Colors & Highlights"},{"id":"sentence_chunking","label":"Sentence Chunking","layout":"tokens","group":"Colors & Highlights"},{"id":"color_legend","label":"Color Legend","layout":"tokens","group":"Colors & Highlights"},{"id":"underline_annotation","label":"Underline Annotation","layout":"tokens","group":"Colors & Highlights"},{"id":"grammar_tags","label":"Grammar Tags","layout":"tokens","group":"Colors & Highlights"},{"id":"word_group_highlight","label":"Word Group Highlight","layout":"tokens","group":"Colors & Highlights"},{"id":"grammar_table","label":"Grammaticatabel","layout":"table","group":"Grammar Tables"},{"id":"conjugation_table","label":"Conjugation Table","layout":"table","group":"Grammar Tables"},{"id":"verb_forms_table","label":"Verb Forms Table","layout":"table","group":"Grammar Tables"},{"id":"pronoun_table","label":"Pronoun Table","layout":"table","group":"Grammar Tables"},{"id":"article_table","label":"Article Table","layout":"table","group":"Grammar Tables"},{"id":"singular_plural_table","label":"Singular / Plural Table","layout":"table","group":"Grammar Tables"},{"id":"tense_comparison_table","label":"Tense Comparison Table","layout":"table","group":"Grammar Tables"},{"id":"word_order_table","label":"Word Order Table","layout":"table","group":"Grammar Tables"},{"id":"exception_table","label":"Exception Table","layout":"table","group":"Grammar Tables"},{"id":"quick_reference_table","label":"Quick Reference Table","layout":"table","group":"Grammar Tables"},{"id":"word_order_diagram","label":"Word Order Diagram","layout":"tokens","group":"Diagrams & Schemas"},{"id":"sentence_structure_diagram","label":"Sentence Structure Diagram","layout":"tokens","group":"Diagrams & Schemas"},{"id":"sentence_breakdown","label":"Sentence Breakdown","layout":"tokens","group":"Diagrams & Schemas"},{"id":"grammar_flowchart","label":"Grammar Flowchart","layout":"steps","group":"Diagrams & Schemas"},{"id":"decision_tree","label":"Decision Tree","layout":"steps","group":"Diagrams & Schemas"},{"id":"mind_map","label":"Mind Map","layout":"steps","group":"Diagrams & Schemas"},{"id":"tree_diagram","label":"Tree Diagram","layout":"steps","group":"Diagrams & Schemas"},{"id":"arrow_diagram","label":"Arrow Diagram","layout":"steps","group":"Diagrams & Schemas"},{"id":"sentence_pattern_diagram","label":"Sentence Pattern Diagram","layout":"tokens","group":"Diagrams & Schemas"},{"id":"grammar_relationship_map","label":"Grammar Relationship Map","layout":"steps","group":"Diagrams & Schemas"},{"id":"verb_timeline","label":"Verb Timeline","layout":"steps","group":"Timelines"},{"id":"past_present_future_timeline","label":"Past–Present–Future Timeline","layout":"steps","group":"Timelines"},{"id":"tense_timeline","label":"Tense Timeline","layout":"steps","group":"Timelines"},{"id":"continuous_action_timeline","label":"Continuous Action Timeline","layout":"steps","group":"Timelines"},{"id":"completed_action_timeline","label":"Completed Action Timeline","layout":"steps","group":"Timelines"},{"id":"event_sequence_diagram","label":"Event Sequence Diagram","layout":"steps","group":"Timelines"},{"id":"time_marker_chart","label":"Time Marker Chart","layout":"steps","group":"Timelines"},{"id":"duration_diagram","label":"Duration Diagram","layout":"steps","group":"Timelines"},{"id":"frequency_scale","label":"Frequency Scale","layout":"steps","group":"Timelines"},{"id":"tense_overview","label":"Tense Overview","layout":"steps","group":"Timelines"},{"id":"before_after","label":"Before / After","layout":"compare","group":"Comparisons"},{"id":"correct_vs_incorrect","label":"Correct vs Incorrect","layout":"compare","group":"Comparisons"},{"id":"side_by_side_comparison","label":"Side-by-Side Comparison","layout":"compare","group":"Comparisons"},{"id":"translation_comparison","label":"Translation Comparison","layout":"compare","group":"Comparisons"},{"id":"formal_informal","label":"Formal vs Informal","layout":"compare","group":"Comparisons"},{"id":"singular_vs_plural","label":"Singular vs Plural","layout":"compare","group":"Comparisons"},{"id":"positive_vs_negative","label":"Positive vs Negative","layout":"compare","group":"Comparisons"},{"id":"question_vs_statement","label":"Question vs Statement","layout":"compare","group":"Comparisons"},{"id":"similar_rules_comparison","label":"Similar Rules Comparison","layout":"compare","group":"Comparisons"},{"id":"common_mistakes_gallery","label":"Common Mistakes Gallery","layout":"compare","group":"Comparisons"},{"id":"learning_objective","label":"Learning Objective","layout":"note","group":"Explanation Blocks"},{"id":"simple_rule_explanation","label":"Simple Rule Explanation","layout":"note","group":"Explanation Blocks"},{"id":"step_by_step_explanation","label":"Step-by-Step Explanation","layout":"steps","group":"Explanation Blocks"},{"id":"detailed_rule_explanation","label":"Detailed Rule Explanation","layout":"note","group":"Explanation Blocks"},{"id":"grammar_formula","label":"Grammar Formula","layout":"tokens","group":"Explanation Blocks"},{"id":"rule_breakdown","label":"Rule Breakdown","layout":"steps","group":"Explanation Blocks"},{"id":"pattern_explanation","label":"Pattern Explanation","layout":"note","group":"Explanation Blocks"},{"id":"exception_explorer","label":"Exception Explorer","layout":"note","group":"Explanation Blocks"},{"id":"grammar_definition","label":"Grammar Definition","layout":"note","group":"Explanation Blocks"},{"id":"key_point_summary","label":"Key Point Summary","layout":"note","group":"Explanation Blocks"},{"id":"example_sentence","label":"Example Sentence","layout":"note","group":"Examples & Context"},{"id":"translated_example","label":"Translated Example","layout":"compare","group":"Examples & Context"},{"id":"contextual_example","label":"Contextual Example","layout":"note","group":"Examples & Context"},{"id":"everyday_usage_card","label":"Everyday Usage Card","layout":"note","group":"Examples & Context"},{"id":"sentence_breakdown_card","label":"Sentence Breakdown Card","layout":"tokens","group":"Examples & Context"},{"id":"grammar_in_context","label":"Grammar in Context","layout":"note","group":"Examples & Context"},{"id":"meaning_comparison","label":"Meaning Comparison","layout":"compare","group":"Examples & Context"},{"id":"usage_note","label":"Usage Note","layout":"note","group":"Examples & Context"},{"id":"multiple_examples_grid","label":"Multiple Examples Grid","layout":"table","group":"Examples & Context"},{"id":"real_life_sentence_card","label":"Real-Life Sentence Card","layout":"note","group":"Examples & Context"},{"id":"remember_this","label":"Remember This","layout":"note","group":"Remember & Review"},{"id":"golden_rule","label":"Golden Rule","layout":"note","group":"Remember & Review"},{"id":"memory_trick","label":"Memory Trick","layout":"note","group":"Remember & Review"},{"id":"mnemonic_card","label":"Mnemonic Card","layout":"note","group":"Remember & Review"},{"id":"key_takeaway","label":"Key Takeaway","layout":"note","group":"Remember & Review"},{"id":"cheat_sheet","label":"Cheat Sheet","layout":"table","group":"Remember & Review"},{"id":"rule_recap","label":"Rule Recap","layout":"note","group":"Remember & Review"},{"id":"important_reminder","label":"Important Reminder","layout":"note","group":"Remember & Review"},{"id":"pattern_recognition_guide","label":"Pattern Recognition Guide","layout":"tokens","group":"Remember & Review"},{"id":"mini_summary","label":"Mini Summary","layout":"note","group":"Remember & Review"},{"id":"accordion_explanation","label":"Accordion Explanation","layout":"accordion","group":"Interactive Explanation UI"},{"id":"expandable_rule","label":"Expandable Rule","layout":"accordion","group":"Interactive Explanation UI"},{"id":"tooltip","label":"Tooltip","layout":"tooltip","group":"Interactive Explanation UI"},{"id":"grammar_tabs","label":"Grammar Tabs","layout":"tabs","group":"Interactive Explanation UI"},{"id":"flip_card","label":"Flip Card","layout":"flip","group":"Interactive Explanation UI"},{"id":"interactive_word_highlight","label":"Interactive Word Highlight","layout":"tokens","group":"Interactive Explanation UI"},{"id":"clickable_sentence_breakdown","label":"Clickable Sentence Breakdown","layout":"tokens","group":"Interactive Explanation UI"},{"id":"visual_grammar_glossary","label":"Visual Grammar Glossary","layout":"glossary","group":"Interactive Explanation UI"},{"id":"expandable_example","label":"Expandable Example","layout":"accordion","group":"Interactive Explanation UI"},{"id":"rule_explorer","label":"Rule Explorer","layout":"tabs","group":"Interactive Explanation UI"}];
const COPY={
 nl:{title:'Rozh · 100 visuele grammatica-elementen',intro:'Kies een onderdeel en schrijf je eigen lesinhoud. Alleen ingevulde onderdelen worden toegevoegd. Je onderwerp wordt nooit automatisch gepubliceerd.',search:'Zoek component...',group:'Alle groepen',component:'Component',blockTitle:'Titel in de les',body:'Uitleg',add:'Toevoegen aan les',saved:'Toegevoegd aan de JSON. Controleer je inhoud en sla daarna zelf op.',invalid:'De JSON bevat een fout; herstel die eerst.',incomplete:'Vul alle verplichte velden in.',limit:'Maximaal 24 componenten per les. Gebruik alleen wat past.',pattern:'Regel per onderdeel',entry:'Titel | uitleg (één per regel)',columns:'Kolommen (gescheiden met |)',rows:'Rijen (één rij per regel, cellen met |)',left:'Links',right:'Rechts',explain:'Extra uitleg (optioneel)',front:'Voorkant',back:'Achterkant',term:'Begrip',definition:'Definitie',hint:'Tip: voeg minimaal twee items toe voor tabbladen of woordenlijst.',tokens:'Rol: woord (één per regel)',invalidRows:'Controleer het aantal cellen en de kolommen.',noFake:'Geen voorbeeldzinnen toegevoegd: alleen jouw eigen inhoud.',selected:'Geselecteerd'},
 en:{title:'Rozh · 100 visual grammar elements',intro:'Choose a component and write your own lesson content. Only completed components are added. Nothing is published automatically.',search:'Search components...',group:'All groups',component:'Component',blockTitle:'Lesson heading',body:'Explanation',add:'Add to lesson',saved:'Added to JSON. Review your content and save it yourself.',invalid:'Fix your JSON first.',incomplete:'Fill in all required fields.',limit:'Maximum 24 components per lesson. Choose only what fits.',pattern:'One item per line',entry:'Title | explanation (one per line)',columns:'Columns (separated by |)',rows:'Rows (one per line, cells separated by |)',left:'Left',right:'Right',explain:'Additional explanation (optional)',front:'Front',back:'Back',term:'Term',definition:'Definition',hint:'Tip: add at least two items for tabs or glossary.',tokens:'Role: word (one per line)',invalidRows:'Check columns and row lengths.',noFake:'No fake example sentences: only your own lesson content.',selected:'Selected'},
 ckb:{title:'ڕۆژ · ١٠٠ پێکهاتەی بینراوی ڕێزمان',intro:'بەشێک هەڵبژێرە و ناوەڕۆکی وانەی خۆت بنووسە. هیچ شتێک بە خۆکار بڵاو ناکرێتەوە.',search:'گەڕان بۆ پێکهاتە...',group:'هەموو گرووپەکان',component:'پێکهاتە',blockTitle:'ناونیشانی وانە',body:'ڕوونکردنەوە',add:'زیادکردن بۆ وانە',saved:'لە JSON زیاد کرا. ناوەڕۆکەکە بپشکنە و خۆت پاشەکەوتی بکە.',invalid:'JSON ـەکە چاک بکەرەوە.',incomplete:'خانە پێویستەکان پڕ بکەرەوە.',limit:'زۆرترین ٢٤ پێکهاتە بۆ هەر وانەیەک.',pattern:'هەر دانەیەک لە هێڵێک',entry:'ناونیشان | ڕوونکردنەوە',columns:'ستوونەکان بە | جیا بکەوە',rows:'ڕیزەکان بە | جیا بکەوە',left:'چەپ',right:'ڕاست',explain:'ڕوونکردنەوەی زیاتر',front:'پێشەوە',back:'دواوە',term:'زاراوە',definition:'پێناسە',hint:'بۆ تاب و فەرهەنگ لانیکەم دوو دانە.',tokens:'ڕۆڵ: وشە',invalidRows:'ژمارەی ستوون و خانەکان بپشکنە.',noFake:'هیچ نموونەی ساختە زیاد ناکرێت.',selected:'هەڵبژێردراو'},
 ar:{title:'روز · 100 مكون مرئي للقواعد',intro:'اختر المكون واكتب محتوى الدرس الحقيقي. لا يتم النشر تلقائياً.',search:'بحث عن مكون...',group:'جميع المجموعات',component:'المكون',blockTitle:'عنوان الدرس',body:'الشرح',add:'إضافة إلى الدرس',saved:'أُضيف إلى JSON. راجع المحتوى ثم احفظه بنفسك.',invalid:'أصلح JSON أولاً.',incomplete:'أكمل جميع الحقول المطلوبة.',limit:'الحد 24 مكوناً لكل درس.',pattern:'عنصر لكل سطر',entry:'عنوان | شرح',columns:'الأعمدة مفصولة بـ |',rows:'الصفوف مفصولة بـ |',left:'الأيسر',right:'الأيمن',explain:'شرح إضافي',front:'الوجه',back:'الخلف',term:'المصطلح',definition:'التعريف',hint:'أضف عنصرين على الأقل للتبويبات والقاموس.',tokens:'الدور: الكلمة',invalidRows:'تحقق من طول الصفوف والأعمدة.',noFake:'لا توجد أمثلة مزيفة أو نشر تلقائي.',selected:'محدد'}
};
const ROLES=['subject','verb','object','time','place','connector','other'];
function node(tag,txt,cls){const n=document.createElement(tag);if(txt!==undefined)n.textContent=txt;if(cls)n.className=cls;return n;}
function field(container,name,title,multi=false,required=true,placeholder=''){
 const wrap=node('label',undefined,'g57-field');wrap.append(node('span',title+(required?' *':'')));
 const input=node(multi?'textarea':'input');if(!multi)input.type='text';input.dataset.key=name;
 if(placeholder)input.placeholder=placeholder;input.required=required;
 if(multi)input.rows=multi===true?3:multi;wrap.append(input);container.append(wrap);return input;
}
const lines=(value)=>value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
function parseEntries(text,min){const entries=lines(text).map(line=>{const n=line.indexOf('|');if(n<=0)return null;const title=line.slice(0,n).trim(),body=line.slice(n+1).trim();return title&&body?{title,body}:null;});return entries.length>=min&&entries.length<=10&&entries.every(Boolean)?entries:null;}
function parseTokens(text){const tokens=lines(text).map(line=>{let n=line.indexOf(':');if(n<=0)return null;const role=line.slice(0,n).trim().toLowerCase(),word=line.slice(n+1).trim();return ROLES.includes(role)&&word?{role,text:word}:null;});return tokens.length>=1&&tokens.length<=20&&tokens.every(Boolean)?tokens:null;}
function initialize(input){
 if(input.dataset.v57Ready)return;input.dataset.v57Ready='1';
 const lang=(document.documentElement.lang||'en').toLowerCase().split('-')[0];const t=COPY[lang]||COPY.en;
 const form=node('section',undefined,'g57-author');form.setAttribute('aria-label',t.title);
 form.append(node('h3',t.title),node('p',t.intro,'g57-intro'));
 const controls=node('div',undefined,'g57-controls');
 const search=node('input');search.type='search';search.placeholder=t.search;search.setAttribute('aria-label',t.search);
 const group=node('select');group.setAttribute('aria-label',t.group);group.append(new Option(t.group,''));
 [...new Set(CATALOG.map(c=>c.group))].forEach(g=>group.append(new Option(g,g)));
 const select=node('select');select.setAttribute('aria-label',t.component);
 const count=node('span','100','g57-count');controls.append(search,group,select,count);form.append(controls);
 const custom=node('div',undefined,'g57-fields');form.append(custom);
 const hint=node('p',t.noFake,'g57-no-fake');form.append(hint);
 const add=node('button',t.add,'g57-add');add.type='button';form.append(add);
 const state=node('p','', 'g57-author-status');state.setAttribute('role','status');form.append(state);
 const inventory=node('section',undefined,'g80-inventory');inventory.setAttribute('aria-label','Bestaande visuele blokken');
 const inventoryTitle=node('h4',undefined);inventory.append(inventoryTitle);
 const inventoryNote=node('p',undefined,'g80-inventory-hint');inventory.append(inventoryNote);
 const inventoryList=node('ol',undefined,'g80-block-list');inventory.append(inventoryList);form.append(inventory);
 let editingIndex=null;
 const words=lang==='nl'?{title:'Blokken in dit artikel',note:'Wijzigingen blijven concept tot je onderaan op Opslaan klikt.',none:'Nog geen blokken. Voeg eerst een vorm toe.',edit:'Bewerken',up:'Omhoog',down:'Omlaag',remove:'Verwijderen',apply:'Wijzig blok',cancel:'Annuleer bewerking',invalid:'Het artikel bevat ongeldige JSON.',updated:'Blok aangepast in concept. Klik op Opslaan om wijzigingen te bewaren.',removed:'Blok verwijderd uit concept. Klik op Opslaan om te bewaren.'}:
 {title:'Blocks in this article',note:'Changes remain a draft until you press Save below.',none:'No blocks yet. Add a component first.',edit:'Edit',up:'Move up',down:'Move down',remove:'Remove',apply:'Update block',cancel:'Cancel editing',invalid:'Article contains invalid JSON.',updated:'Draft block updated. Press Save to persist.',removed:'Draft block removed. Press Save to persist.'};
 inventoryTitle.textContent=words.title;inventoryNote.textContent=words.note;
 const cancel=node('button',words.cancel,'g80-cancel');cancel.type='button';cancel.hidden=true;form.insertBefore(cancel,state);
 function resetEdit(){editingIndex=null;add.textContent=t.add;cancel.hidden=true;}
 function dataFromInput(){try{const result=JSON.parse(input.value.trim()||'{}');return result&&typeof result==='object'&&!Array.isArray(result)&&(!('visual_blocks' in result)||Array.isArray(result.visual_blocks))?result:null;}catch(_){return null;}}
 function commitData(data){input.value=JSON.stringify(data,null,2);input.dispatchEvent(new Event('input',{bubbles:true}));}
 function editBlock(i){
   const data=dataFromInput();if(!data||!data.visual_blocks||!data.visual_blocks[i])return;
   const b=data.visual_blocks[i],kind=CATALOG.find(item=>item.id===b.type);
   if(!kind){state.textContent=words.invalid;return;}
   search.value='';group.value='';populate();select.value=kind.id;paint();
   const values={title:b.title||'',body:b.body||'',tokens:(b.tokens||[]).map(t=>t.role+': '+t.text).join('\n'),
     columns:(b.columns||[]).join(' | '),rows:(b.rows||[]).map(row=>row.join(' | ')).join('\n'),
     left:b.left||'',right:b.right||'',explanation:b.explanation||'',
     items:(b.items||[]).join('\n'),entries:(b.entries||[]).map(e=>e.title+' | '+e.body).join('\n'),
     front:b.front||'',back:b.back||'',term:b.term||'',definition:b.definition||''};
   custom.querySelectorAll('[data-key]').forEach(el=>{if(Object.prototype.hasOwnProperty.call(values,el.dataset.key))el.value=values[el.dataset.key];});
   custom.dispatchEvent(new Event('input',{bubbles:true}));
   editingIndex=i;add.textContent=words.apply;cancel.hidden=false;
   state.textContent=words.apply+' · '+kind.label;
   search.scrollIntoView({block:'nearest',behavior:'smooth'});custom.querySelector('[data-key=title]')?.focus();
 }
 function renderInventory(){
   inventoryList.replaceChildren();const data=dataFromInput();if(!data){inventoryNote.textContent=words.invalid;return;}
   const blocks=data.visual_blocks||[];inventoryNote.textContent=words.note+' · '+blocks.length+'/24';
   if(!blocks.length){inventoryList.append(node('li',words.none));return;}
   blocks.forEach((block,index)=>{
     const li=node('li',undefined,'g80-block-row');
     const meta=node('span',undefined,'g80-block-meta');const name=CATALOG.find(c=>c.id===block.type);
     meta.append(node('strong',String(index+1)+'. '+String(block.title||name?.label||block.type||'—')));
     meta.append(node('small',name?.label||String(block.type||'—')));li.append(meta);
     const buttons=node('span',undefined,'g80-block-actions');
     function action(label,disabled,handler){const button=node('button',label);button.type='button';button.disabled=disabled;button.addEventListener('click',handler);buttons.append(button);}
     action(words.edit,false,()=>editBlock(index));
     action('↑ '+words.up,index===0,()=>{const a=data.visual_blocks;[a[index-1],a[index]]=[a[index],a[index-1]];resetEdit();commitData(data);});
     action('↓ '+words.down,index===blocks.length-1,()=>{const a=data.visual_blocks;[a[index],a[index+1]]=[a[index+1],a[index]];resetEdit();commitData(data);});
     action(words.remove,false,()=>{data.visual_blocks.splice(index,1);resetEdit();commitData(data);state.textContent=words.removed;});
     li.append(buttons);inventoryList.append(li);
   });
 }
 cancel.addEventListener('click',()=>{resetEdit();state.textContent='';});
 input.addEventListener('input',renderInventory);renderInventory();
 const advanced=input.closest('.v80-advanced-json');(advanced||input).parentNode.insertBefore(form,advanced||input);
 function populate(){const q=search.value.trim().toLocaleLowerCase();let candidates=CATALOG.filter(c=>(!group.value||c.group===group.value)&&(!q||(c.label+' '+c.group+' '+c.id).toLocaleLowerCase().includes(q)));
 const previous=select.value;select.replaceChildren();for(const c of candidates)select.append(new Option(c.label+' · '+c.group,c.id));if(candidates.some(x=>x.id===previous))select.value=previous;count.textContent=String(candidates.length);paint();}
 function paint(){custom.replaceChildren();let c=CATALOG.find(x=>x.id===select.value);add.disabled=!c;if(!c)return;
 custom.append(node('p',c.label+' · '+c.layout,'g57-selection'));
 field(custom,'title',t.blockTitle,false,true).value=c.label;
 if(c.layout==='note')field(custom,'body',t.body,true);
 if(c.layout==='tokens')field(custom,'tokens',t.tokens,true,true,'subject: Ik\nverb: leer');
 if(c.layout==='table'){field(custom,'columns',t.columns,false,true,'Persoon | Vorm');field(custom,'rows',t.rows,true,true,'I | am\nShe | is');}
 if(c.layout==='compare'){field(custom,'left',t.left,true);field(custom,'right',t.right,true);field(custom,'explanation',t.explain,true,false);}
 if(c.layout==='steps')field(custom,'items',t.pattern,true);
 if(['accordion','tabs','glossary'].includes(c.layout)){field(custom,'entries',t.entry,true);custom.append(node('p',t.hint,'g57-hint'));}
 if(c.layout==='flip'){field(custom,'front',t.front,true);field(custom,'back',t.back,true);}
 if(c.layout==='tooltip'){field(custom,'term',t.term);field(custom,'definition',t.definition,true);}
 const preview=node('div',undefined,'g57-preview');preview.setAttribute('aria-label','Preview');custom.append(preview);
 function renderPreview(){
  preview.replaceChildren();const data={};custom.querySelectorAll('[data-key]').forEach(el=>{data[el.dataset.key]=el.value.trim();});
  preview.append(node('strong',data.title||c.label,'g57-preview-title'));
  const addLine=(text)=>{if(text)preview.append(node('p',text,'g57-preview-line'));};
  if(c.layout==='note')addLine(data.body);
  if(c.layout==='tokens'){const track=node('div',undefined,'g57-preview-tokens');(parseTokens(data.tokens||'')||[]).forEach(x=>track.append(node('span',x.text+' · '+x.role)));preview.append(track);}
  if(c.layout==='table'){const cols=(data.columns||'').split('|').map(x=>x.trim()).filter(Boolean);if(cols.length)preview.append(node('p',cols.join('  ·  '),'g57-preview-line'));lines(data.rows||'').forEach(x=>addLine(x.replaceAll('|',' · ')));}
  if(c.layout==='compare'){addLine(data.left);addLine('↔');addLine(data.right);addLine(data.explanation);}
  if(c.layout==='steps'){
   const nodes=lines(data.items||'');
   const type=c.id;
   const mode=(c.group==='Timelines')?'timeline':
     (['mind_map','grammar_relationship_map'].includes(type)?'map':
     (['decision_tree','tree_diagram'].includes(type)?'tree':
     (['grammar_flowchart','arrow_diagram'].includes(type)?'flow':'steps')));
   if(mode==='steps')nodes.forEach((x,i)=>addLine((i+1)+'. '+x));
   else {
     const scene=node('div',undefined,'g64-author-scene g64-author-'+mode);
     if(mode==='map'||mode==='tree')scene.append(node('strong',data.title||c.label,'g64-author-root'));
     const list=node('ol');nodes.forEach((x,i)=>{
       const li=node('li');if(mode==='timeline'||mode==='flow')li.append(node('small',String(i+1)));
       li.append(node('span',x));list.append(li);
     });scene.append(list);preview.append(scene);
   }
  }
  if(['accordion','tabs','glossary'].includes(c.layout)){(parseEntries(data.entries||'',1)||[]).forEach(x=>addLine(x.title+' — '+x.body));}
  if(c.layout==='flip'){addLine(data.front);if(data.back)addLine('↳ '+data.back);}
  if(c.layout==='tooltip'){addLine(data.term);addLine(data.definition);}
 }
 custom.addEventListener('input',renderPreview);renderPreview();
 }
 search.addEventListener('input',()=>{resetEdit();populate();});group.addEventListener('change',()=>{resetEdit();populate();});select.addEventListener('change',()=>{resetEdit();paint();});
 add.addEventListener('click',()=>{
 const c=CATALOG.find(x=>x.id===select.value);if(!c)return;
 let data;try{data=JSON.parse(input.value.trim()||'{}');if(!data||Array.isArray(data)||typeof data!=='object')throw Error();}catch(_){state.textContent=t.invalid;return;}
 if(data.visual_blocks!==undefined&&!Array.isArray(data.visual_blocks)){state.textContent=t.invalid;return;}
 if((data.visual_blocks||[]).length>=24 && editingIndex===null){state.textContent=t.limit;return;}
 const values={};custom.querySelectorAll('[data-key]').forEach(el=>{values[el.dataset.key]=el.value.trim();});
 if(!values.title){state.textContent=t.incomplete;return;}
 const b={type:c.id,title:values.title};
 if(c.layout==='note')b.body=values.body;
 if(c.layout==='tokens')b.tokens=parseTokens(values.tokens||'');
 if(c.layout==='table'){
   b.columns=(values.columns||'').split('|').map(x=>x.trim()).filter(Boolean);
   b.rows=lines(values.rows||'').map(x=>x.split('|').map(v=>v.trim()));
   if(!b.columns.length||b.columns.length>6||!b.rows.length||b.rows.length>24||b.rows.some(row=>row.length!==b.columns.length||row.some(x=>!x))){state.textContent=t.invalidRows;return;}
 }
 if(c.layout==='compare'){b.left=values.left;b.right=values.right;b.explanation=values.explanation||'';}
 if(c.layout==='steps')b.items=lines(values.items||'');
 if(['accordion','tabs','glossary'].includes(c.layout))b.entries=parseEntries(values.entries||'',c.layout==='accordion'?1:2);
 if(c.layout==='flip'){b.front=values.front;b.back=values.back;}
 if(c.layout==='tooltip'){b.term=values.term;b.definition=values.definition;}
 const valid= Object.entries(b).every(([k,v])=>k==='type'||(Array.isArray(v)?v.length>0:typeof v==='string' && (k==='explanation'||v.length>0)));
 if(!valid||c.layout==='steps'&&b.items.length<2||c.layout==='tokens'&&!b.tokens){state.textContent=t.incomplete;return;}
 if(!data.visual_blocks)data.visual_blocks=[];
 if(editingIndex!==null){
   if(!data.visual_blocks[editingIndex]||data.visual_blocks[editingIndex].type!==c.id){state.textContent=t.invalid;return;}
   data.visual_blocks[editingIndex]=b;commitData(data);resetEdit();state.textContent=words.updated;
 }else{data.visual_blocks.push(b);commitData(data);state.textContent=t.saved;}
 });
 populate();
}
function boot(){document.querySelectorAll('textarea.v15-grammar-json').forEach(initialize);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
if('MutationObserver' in window)new MutationObserver(boot).observe(document.documentElement,{childList:true,subtree:true});
})();

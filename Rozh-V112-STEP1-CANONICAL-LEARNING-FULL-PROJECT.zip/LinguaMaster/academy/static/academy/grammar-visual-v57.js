/* V57: accessible tab panel switching. No network, no answer grading, no XP. */
(() => {
'use strict';
function init(root){
 if(root.dataset.g57Ready)return;root.dataset.g57Ready='1';
 const tabs=[...root.querySelectorAll('[role="tab"]')];const panels=[...root.querySelectorAll('[role="tabpanel"]')];
 if(tabs.length!==panels.length)return;
 function select(index,focus){
  tabs.forEach((tab,i)=>{const chosen=i===index;tab.setAttribute('aria-selected',String(chosen));tab.tabIndex=chosen?0:-1;panels[i].hidden=!chosen;});
  if(focus)tabs[index].focus();
 }
 tabs.forEach((tab,i)=>{
  tab.addEventListener('click',()=>select(i,false));
  tab.addEventListener('keydown',ev=>{
   const key=ev.key;let next;
   if(key==='ArrowRight'||key==='ArrowDown')next=(i+1)%tabs.length;
   else if(key==='ArrowLeft'||key==='ArrowUp')next=(i-1+tabs.length)%tabs.length;
   else if(key==='Home')next=0;else if(key==='End')next=tabs.length-1;
   else return;
   ev.preventDefault();select(next,true);
  });
 });
}
function boot(){document.querySelectorAll('.g57-tabs[data-g57-tabs]').forEach(init);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();

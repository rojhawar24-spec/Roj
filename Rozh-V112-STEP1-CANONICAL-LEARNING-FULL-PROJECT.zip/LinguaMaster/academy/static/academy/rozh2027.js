/* Rozh 2027 — presentation only. No lesson completion, reward, permission or XP changes. */
(() => {
  'use strict';
  const doc = document.documentElement;
  // The modern student shell does not include app-experience.js, which is
  // responsible for PWA registration on legacy pages. Register here as well,
  // but never cache student pages, API responses or assessment submissions.
  if (document.body.classList.contains('r27-student') &&
      'serviceWorker' in navigator && window.isSecureContext) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/service-worker.js', {scope:'/'}).catch(() => {});
    }, {once:true});
  }
  const paths = Array.from(document.querySelectorAll('[data-r27-path]'));
  let pending = false;
  function draw() {
    pending = false;
    paths.forEach(list => {
      const svg = list.querySelector('.r27-path-svg');
      if (!svg) return;
      const width = list.clientWidth, height = list.scrollHeight;
      if (!width || !height) { svg.hidden = true; return; }
      svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
      const bounds = list.getBoundingClientRect();
      const sections = [];
      let current = [];
      // Unit headings interrupt the decorative curve; don't draw over text.
      Array.from(list.children).forEach(child => {
        if (child.classList.contains('r53-unit-heading')) {
          if (current.length) sections.push(current);
          current = [];
        }
        const node = child.classList.contains('r27-node')
          ? child.querySelector('.r27-node-button') : null;
        if (node) {
          const rect = node.getBoundingClientRect();
          current.push([rect.left - bounds.left + rect.width/2,
                        rect.top - bounds.top + rect.height/2]);
        }
      });
      if (current.length) sections.push(current);
      const curves = [];
      sections.forEach(dots => {
        if (dots.length < 2) return;
        let d = `M ${dots[0][0].toFixed(1)} ${dots[0][1].toFixed(1)}`;
        for (let i = 1; i < dots.length; i++) {
          const [x0, y0] = dots[i - 1], [x1, y1] = dots[i];
          const bend = list.dataset.solarCurve === "flow" ? .26 : list.dataset.solarCurve === "arc" ? .68 : .48;
          const dy = Math.max(8, (y1 - y0) * bend);
          d += ` C ${x0.toFixed(1)} ${(y0 + dy).toFixed(1)}, ${x1.toFixed(1)} ${(y1 - dy).toFixed(1)}, ${x1.toFixed(1)} ${y1.toFixed(1)}`;
        }
        curves.push(d);
      });
      svg.hidden = !curves.length;
      const pathData = curves.join(' ');
      svg.querySelectorAll('path').forEach(path => path.setAttribute('d', pathData));
    });
  }
  function schedule() {
    if (pending) return;
    pending = true;
    requestAnimationFrame(draw);
  }
  schedule();
  // A previously collapsed season has no measurable SVG curve until opened.
  document.querySelectorAll('.r53-journey details.r53-season').forEach(season => {
    season.addEventListener('toggle', schedule);
  });
  if (typeof ResizeObserver !== 'undefined') {
    const resize = new ResizeObserver(schedule);
    paths.forEach(path => resize.observe(path));
  } else {
    window.addEventListener('resize', schedule, {passive:true});
  }
  if (document.fonts?.ready) document.fonts.ready.then(schedule).catch(() => {});
  const toggle = document.querySelector('[data-r27-theme]');
  let themeSaving = false;
  if (toggle) {
    function syncThemeAccessibility(theme) {
      const isDark = theme === 'dark';
      toggle.setAttribute('aria-pressed', String(isDark));
      const label = isDark ? toggle.getAttribute?.('data-theme-action-light') : toggle.getAttribute?.('data-theme-action-dark');
      if (label) toggle.setAttribute('aria-label', label);
    }
    syncThemeAccessibility(doc.dataset.theme);
    toggle.addEventListener('click', async () => {
      if (themeSaving) return; // avoid competing, out-of-order saves
      const csrf = document.querySelector('input[name=csrfmiddlewaretoken]')?.value;
      if (!csrf) return; // no misleading unsaved visual change
      const current = doc.dataset.theme === 'dark' ? 'dark' : 'light';
      const desired = current === 'dark' ? 'light' : 'dark';
      themeSaving = true;
      toggle.disabled = true;
      doc.dataset.theme = desired;
      doc.dataset.themePreference = desired;
      syncThemeAccessibility(desired);
      const data = new FormData(); data.set('theme', desired);
      try {
        const response = await fetch('/profile/appearance/', {
          method:'POST', credentials:'same-origin', body:data,
          headers: {'X-CSRFToken':csrf,'Accept':'application/json'}
        });
        if (!response.ok || response.redirected) throw new Error('Theme save failed');
        const saved = await response.json();
        if (saved.theme !== desired) throw new Error('Unexpected theme response');
        // Persist only a confirmed server preference; failed saves roll back.
        try { localStorage.setItem('linguamaster-theme', desired); } catch (_) {}
      } catch (_) {
        doc.dataset.theme = current;
        doc.dataset.themePreference = current;
        syncThemeAccessibility(current);
      } finally {
        themeSaving = false;
        toggle.disabled = false;
      }
    });
  }
  document.querySelectorAll('[data-confirm]').forEach(form => {
    form.addEventListener('submit', event => {
      if (!window.confirm(form.dataset.confirm || 'Confirm this action?')) event.preventDefault();
    });
  });
  // Mobile navigation is a non-modal disclosure. Close it when the user
  // presses Escape or interacts outside the disclosure; do not intercept
  // links or forms (including the protected POST logout form).
  const mobileMenus = Array.from(document.querySelectorAll('.r27-mobile-menu,.r27-manager-menu'));
  if (mobileMenus.length) {
    document.addEventListener('keydown', event => {
      if (event.key !== 'Escape') return;
      mobileMenus.forEach(details => {
        if (!details.open) return;
        details.open = false;
        details.querySelector('summary')?.focus();
      });
    });
    document.addEventListener('pointerdown', event => {
      mobileMenus.forEach(details => {
        if (details.open && !details.contains(event.target)) details.open = false;
      });
    });
  }
})();

/* LinguaMaster V4: visual affordances only. No local XP, answers or permissions. */
(() => {
 'use strict';
 // Highlight the current lesson stop; no calls and no persistence needed.
 const current = document.querySelector('.v4-journey-stop:not(.v4-journey-locked):not(.v4-journey-done)');
 if (current) current.classList.add('v4-is-current');
 // Respect reduced motion. Anchor focus behavior remains native for keyboard users.
 const reduced = document.documentElement.dataset.reduceMotion === 'true' ||
   document.documentElement.dataset.accountReduceMotion === 'true' ||
   (typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
 if (!reduced && current && window.location.hash === '#continue') {
   current.scrollIntoView({block:'center',behavior:'smooth'});
 }
})();

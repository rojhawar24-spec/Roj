/* Browser-assisted practice. Microphone recognition starts only on a user gesture. */
(() => {
  'use strict';
  const studio = document.getElementById('skills-practice');
  if (!studio) return;
  let labels = {};
  try { labels = JSON.parse(document.getElementById('v10-skill-labels').textContent); } catch (_) { return; }
  const answer = document.getElementById('v5-answer');
  const source = document.getElementById('v5-source');
  const locale = studio.dataset.targetLocale;
  const transcript = document.getElementById('v10-transcript');
  if (transcript) transcript.addEventListener('toggle', () => {
    const summary = transcript.querySelector('summary');
    summary.textContent = transcript.open ? summary.dataset.hide : summary.dataset.show;
  });

  const audioButtons = Array.from(studio.querySelectorAll('[data-v10-audio]'));
  const audioStatus = document.getElementById('v10-audio-status');
  const waveform = studio.querySelector('.v10-audio-stage');
  let audioSequence = 0;
  let recognizer = null;
  let recording = false;
  let starting = false;
  function setAudioStatus(text, sequence) {
    if (sequence !== audioSequence) return;
    if (audioStatus) audioStatus.textContent = text;
  }
  // School listening audio must come from a vetted, self-hosted clip.
  // Never generate a substitute browser voice that was not dialect/rights reviewed.
  const missingApprovedAudio = audioButtons.filter(button => !button.dataset.rozhAudioSrc);
  missingApprovedAudio.forEach(button => { button.disabled = true; button.setAttribute('aria-disabled','true'); });
  if (missingApprovedAudio.length && audioStatus) audioStatus.textContent = labels.audio_error;
  audioButtons.forEach(button => button.addEventListener('click', () => {
    const sequence = ++audioSequence;
    if (recognizer && (recording || starting)) { try { recognizer.abort(); } catch (_) {} }
    const onStart = () => {
      if (sequence !== audioSequence) return;
      if (waveform) waveform.classList.add('is-playing');
      setAudioStatus(labels.audio_playing, sequence);
    };
    const onEnd = () => {
      if (sequence !== audioSequence) return;
      if (waveform) waveform.classList.remove('is-playing');
      setAudioStatus(labels.audio_done, sequence);
    };
    const onError = () => {
      if (sequence !== audioSequence) return;
      if (waveform) waveform.classList.remove('is-playing');
      setAudioStatus(labels.audio_error, sequence);
    };
    if (window.RozhAudioV78?.play(button, {slow: Number(button.dataset.rate) < 0.8,
                                            onStart, onEnd, onError})) return;
    onError();
  }));

  if (answer && studio.dataset.kind === 'writing') {
    const count = document.getElementById('v10-word-count');
    const checklist = document.getElementById('v10-live-checks');
    const normalize = value => value.normalize('NFKC').toLowerCase().replace(/ß/g, 'ss').replace(/[\p{P}]/gu, '').replace(/\s+/g, ' ').trim();
    const update = () => {
      const text = answer.value;
      const tokens = text.normalize('NFKC').match(/[\p{L}\p{N}_]+(?:['’\-][\p{L}\p{N}_]+)*/gu) || [];
      const words = tokens.length;
      const output = `${words} ${labels.word_count}`;
      if (count && count.textContent !== output) count.textContent = output;
      const focus = normalize(studio.dataset.focusWord || '');
      const normalized = ` ${normalize(text)} `;
      const checks = {words:words >= 6, target:Boolean(focus) && normalized.includes(` ${focus} `),
        capital: /^\p{Lu}/u.test(text.trimStart()), punctuation:/[.!?؟]$/.test(text.trimEnd())};
      if (checklist) checklist.querySelectorAll('[data-check]').forEach(item => {
        const passed = checks[item.dataset.check];
        item.dataset.complete = String(passed);
        const icon = item.querySelector('span');
        if (icon) icon.textContent = passed ? '✓' : '○';
        const state = item.querySelector('.v10-check-state');
        if (state) state.textContent = passed ? labels.check_done : labels.check_pending;
      });
    };
    answer.addEventListener('input', update);
    update();
  }

  const trigger = document.getElementById('v5-record');
  if (trigger && answer && source) {
    const status = document.getElementById('v5-speech-status');
    const Recognizer = window.SpeechRecognition || window.webkitSpeechRecognition;
    const reset = () => {
      recording = false; starting = false; trigger.disabled = false;
      trigger.textContent = '🎤 ' + labels.start_mic;
      trigger.setAttribute('aria-pressed', 'false');
    };
    if (!Recognizer) {
      trigger.disabled = true;
      status.textContent = labels.mic_unsupported;
    } else trigger.addEventListener('click', () => {
      if (recording && recognizer) {
        try { recognizer.stop(); status.textContent = labels.mic_idle; }
        catch (_) { reset(); status.textContent = labels.mic_error; }
        return;
      }
      if (starting) return;
      ++audioSequence;
      if (waveform) waveform.classList.remove('is-playing');
      window.RozhAudioV78?.stop();
      starting = true; trigger.disabled = true;
      try {
        recognizer = new Recognizer();
        recognizer.lang = locale;
        recognizer.interimResults = false;
        recognizer.continuous = false;
        recognizer.maxAlternatives = 1;
        recognizer.onstart = () => {
          starting = false; recording = true; trigger.disabled = false;
          trigger.textContent = '■ ' + labels.stop_mic;
          trigger.setAttribute('aria-pressed', 'true');
          status.textContent = labels.mic_listening;
        };
        recognizer.onresult = event => {
          const recognized = event.results?.[event.resultIndex || 0]?.[0]?.transcript || '';
          if (recognized) {
            answer.value = recognized.slice(0, 800);
            source.value = 'microphone';
            status.textContent = labels.mic_ready;
            answer.focus();
          }
        };
        recognizer.onerror = event => {
          status.textContent = ['not-allowed', 'service-not-allowed'].includes(event.error) ? labels.mic_denied : labels.mic_error;
          reset();
        };
        recognizer.onend = reset;
        recognizer.start();
      } catch (_) { reset(); status.textContent = labels.mic_error; }
    });
    answer.addEventListener('input', () => { source.value = 'typed'; });
    const form = document.getElementById('v5-skill-form');
    if (form) form.addEventListener('submit', () => {
      if (recognizer && (recording || starting)) { try { recognizer.abort(); } catch (_) {} }
    });
  }
  window.addEventListener('pagehide', () => {
    ++audioSequence;
    window.RozhAudioV78?.stop();
    if (recognizer) { try { recognizer.abort(); } catch (_) {} }
  });
})();

/* LinguaMaster V15: helper for structured, escaped grammar content.
 * Keeps the existing JSONField and protected Django admin save workflow.
 * No remote dependencies, no eval, no injected HTML, no client-side persistence.
 */
(() => {
  'use strict';
  const text = {
    en: {heading:'Grammar block builder',note:'Choose a block. Edit its text in the JSON editor below, then save with Django. No content is published automatically.',rule:'Rule',tip:'Tip',warning:'Warning',remember:'Remember',faq:'FAQ',list:'Checklist',table:'Comparison table',row:'Add row',column:'Add column',section:'Explanation',example:'Example + translation',preview:'Safe preview',invalid:'Fix the JSON syntax before adding a block.',added:'Block added. Save your topic when ready.',limit:'Block limit reached.',tableMissing:'Create a table first.',question:'Question',answer:'Answer',bad:'Incorrect',good:'Correct',type:'Content'},
    nl: {heading:'Grammatica-blokken maken',note:'Kies een blok, bewerk de tekst in JSON en sla het onderwerp op. Er wordt niets automatisch gepubliceerd.',rule:'Regel',tip:'Tip',warning:'Waarschuwing',remember:'Onthouden',faq:'Veelgestelde vraag',list:'Onthoudlijst',table:'Vergelijkingstabel',row:'Rij toevoegen',column:'Kolom toevoegen',section:'Uitleg',example:'Voorbeeld + vertaling',preview:'Veilige preview',invalid:'Corrigeer eerst de JSON-syntax.',added:'Blok toegevoegd. Sla het onderwerp op.',limit:'Maximum bereikt.',tableMissing:'Maak eerst een tabel.',question:'Vraag',answer:'Antwoord',bad:'Fout',good:'Goed',type:'Inhoud'},
    ckb: {heading:'دروستکردنی بەشی ڕێزمان',note:'بەشێک هەڵبژێرە، دەقەکەی لە JSON دا دەستکاری بکە و پاشەکەوتی بکە. هیچ شتێک بە خۆکار بڵاو ناکرێتەوە.',rule:'ڕێسا',tip:'ئامۆژگاری',warning:'ئاگاداری',remember:'لەبیرت بێت',faq:'پرسیاری باو',list:'لیستی بیرخستنەوە',table:'خشتەی بەراورد',row:'زیادکردنی ڕیز',column:'زیادکردنی ستوون',section:'ڕوونکردنەوە',example:'نموونە و وەرگێڕان',preview:'پێشبینینی پارێزراو',invalid:'سەرەتا JSON ڕاست بکەرەوە.',added:'بەشەکە زیاد کرا. پاشەکەوتی بکە.',limit:'گەیشتە سنوور.',tableMissing:'سەرەتا خشتەیەک دروست بکە.',question:'پرسیار',answer:'وەڵام',bad:'هەڵە',good:'ڕاست',type:'ناوەڕۆک'}
  };
  function append(parent, tag, value, className) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (value !== undefined && value !== null) element.textContent = String(value);
    parent.append(element);
    return element;
  }
  function initialize(input) {
    if (input.dataset.v15Ready === '1') return;
    input.dataset.v15Ready = '1';
    const locale = (document.documentElement.lang || 'en').split('-')[0];
    const L = text[locale] || text.en;
    const panel = document.createElement('section');
    panel.className = 'v15-author';
    panel.setAttribute('aria-label', L.heading);
    append(panel, 'h3', L.heading);
    append(panel, 'p', L.note, 'v15-author-note');
    const buttons = append(panel, 'div', '', 'v15-author-actions');
    const status = append(panel, 'p', '', 'v15-author-status');
    status.setAttribute('role','status');
    const preview = append(panel, 'div', '', 'v15-author-preview');
    append(preview, 'h4', L.preview);
    const contents = append(preview, 'div', '', 'v15-author-preview-body');
    input.parentNode.insertBefore(panel,input);
    function parse() {
      const raw = input.value.trim();
      try {
        const data = raw ? JSON.parse(raw) : {};
        if (!data || Array.isArray(data) || typeof data !== 'object') throw new Error('object expected');
        return data;
      } catch (_error) { status.textContent = L.invalid; return null; }
    }
    function render() {
      contents.replaceChildren();
      const data = parse();
      if (!data) return;
      if (typeof data.intro === 'string' && data.intro) append(contents, 'p', data.intro);
      for (const b of Array.isArray(data.quick_rules) ? data.quick_rules : []) {
        const block = append(contents,'article',null,'v15-author-block v15-author-'+(String(b.kind||'rule').replace(/[^a-z]/g,'')));
        append(block,'strong',b.title); append(block,'p',b.body);
      }
      for (const table of Array.isArray(data.rule_tables) ? data.rule_tables : []) {
        const wrap=append(contents,'div',null,'v15-author-table-wrap');
        append(wrap,'h5',table.title);
        const el=append(wrap,'table'); const head=append(el,'thead');const tr=append(head,'tr');
        for(const c of Array.isArray(table.columns)?table.columns:[]) append(tr,'th',c);
        const body=append(el,'tbody');
        for(const row of Array.isArray(table.rows)?table.rows:[]) {const r=append(body,'tr');for(const c of Array.isArray(row)?row:[]) append(r,'td',c);}
      }
      for(const item of Array.isArray(data.faq)?data.faq:[]) {const block=append(contents,'article');append(block,'strong',item.question);append(block,'p',item.answer);}
      if(Array.isArray(data.checklist)&&data.checklist.length) {const ul=append(contents,'ul');for(const item of data.checklist) append(ul,'li',item);}
    }
    const actions = [
      [L.rule,'rule'],[L.tip,'tip'],[L.warning,'warning'],[L.remember,'remember'],
      [L.faq,'faq'],[L.list,'checklist'],[L.table,'table'],[L.row,'row'],[L.column,'column'],
      [L.section,'section'],[L.example,'example']
    ];
    function add(action) {
      const data = parse();if (!data) return;
      const put = (key,obj,max) => {
        if (!Array.isArray(data[key])) data[key]=[];
        if (data[key].length>=max){status.textContent=L.limit;return false;}
        data[key].push(obj);return true;
      };
      let ok = true;
      if (['rule','tip','warning','remember'].includes(action)) {
        ok=put('quick_rules',{kind:action,title:L[action],body:L.type},16);
      } else if(action==='faq') {
        ok=put('faq',{question:L.question,answer:L.answer},20);
      } else if(action==='checklist') {
        ok=put('checklist',L.remember,20);
      } else if(action==='table') {
        ok=put('rule_tables',{title:L.table,columns:[L.type,L.example],rows:[[L.type,L.example]],note:''},8);
      } else if(action==='row'||action==='column') {
        const tables=Array.isArray(data.rule_tables)?data.rule_tables:[];
        const table=tables.at(-1);
        if(!table){status.textContent=L.tableMissing;return;}
        if (!Array.isArray(table.columns) || !Array.isArray(table.rows)) {status.textContent=L.invalid;return;}
        if(action==='row') {if(table.rows.length>=30){status.textContent=L.limit;return;}table.rows.push(Array(table.columns.length).fill(L.type));}
        else {if(table.columns.length>=6){status.textContent=L.limit;return;}table.columns.push(L.type);for(const row of table.rows) if(Array.isArray(row))row.push(L.type);}
      } else if(action==='section') {
        ok=put('sections',{title:L.section,body:L.type},12);
      } else if(action==='example') {
        ok=put('example_pairs',{original:L.example,translation:L.type,note:''},20);
      }
      if(!ok)return;
      input.value=JSON.stringify(data,null,2);
      input.dispatchEvent(new Event('input',{bubbles:true}));
      status.textContent=L.added;
      render();
    }
    for(const [label,key] of actions){
      const btn=append(buttons,'button',label);btn.type='button';btn.dataset.v15Action=key;
      btn.addEventListener('click',()=>add(key));
    }
    input.addEventListener('input',render);
    render();
  }
  function boot(){document.querySelectorAll('textarea.v15-grammar-json').forEach(initialize);}
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot);else boot();
  // Django's "add another" inlines can append a new widget without reloading.
  if ('MutationObserver' in window) new MutationObserver(boot).observe(document.documentElement,{childList:true,subtree:true});
})();

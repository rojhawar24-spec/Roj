/* Only on anonymous account pages. Never store or log credentials. */
(() => {
  'use strict';
  for (const button of document.querySelectorAll('[data-password-toggle]')) {
    const input = button.closest('.lm-password-wrap')?.querySelector('input');
    if (!input) continue;
    button.addEventListener('click', () => {
      const visible = input.type === 'password';
      input.type = visible ? 'text' : 'password';
      const label = visible ? (button.dataset.hideLabel || 'Hide') : (button.dataset.showLabel || 'Show');
      button.textContent = label;
      button.setAttribute('aria-pressed', String(visible));
      button.setAttribute('aria-label', `${label} ${input.labels?.[0]?.textContent?.trim() || ''}`.trim());
      input.focus({preventScroll: true});
    });
  }
  // Progressive enhancement: never intercept or replace the actual Django POST.
  // No password, email, code or form contents are copied, stored or logged.
  for (const form of document.querySelectorAll('[data-auth-submit]')) {
    const button = form.querySelector('[data-auth-submit-button]');
    const text = button?.querySelector('[data-auth-submit-label]');
    const status = form.querySelector('[data-auth-submit-status]');
    if (!button) continue;
    const original = text?.textContent || button.textContent;
    let submitting = false;
    const restore = () => {
      submitting = false;
      button.disabled = false;
      button.removeAttribute('aria-busy');
      form.removeAttribute('aria-busy');
      form.classList.remove('lm-auth-is-submitting');
      if (text) text.textContent = original;
      if (status) status.textContent = '';
    };
    // A browser-back navigation must never leave the sign-in button disabled.
    window.addEventListener('pageshow', restore);
    form.addEventListener('submit', (event) => {
      if (submitting) { event.preventDefault(); return; }
      if (!form.checkValidity()) return;
      submitting = true;
      const progress = form.dataset.authPendingLabel || original;
      form.setAttribute('aria-busy', 'true');
      button.setAttribute('aria-busy', 'true');
      form.classList.add('lm-auth-is-submitting');
      if (text) text.textContent = progress;
      if (status) status.textContent = progress;
      button.disabled = true;
    });
  }
  const summary = document.querySelector('[data-auth-error-summary]');
  if (summary) summary.focus({preventScroll: true});
})();

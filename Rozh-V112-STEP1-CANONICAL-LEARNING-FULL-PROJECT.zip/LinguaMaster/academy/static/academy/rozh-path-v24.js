/* LinguaMaster V24: accessible route navigation, decoration only.
   No requests, account writes, storage or client-side reward state. */
(() => {
  'use strict';
  const root = document.querySelector('.lm24-voyage');
  if (!root) return;
  const current = root.querySelector('#lm24-current-checkpoint');
  if (!current) return;
  // A real anchor to a server-selected authorized unit. Reappear on long maps,
  // disappear when the user can already see their current checkpoint.
  const float = document.createElement('a');
  float.className = 'lm24-floating-resume';
  float.href = '#lm24-current-checkpoint';
  const label = root.querySelector('.lm24-hero-focus a');
  float.textContent = label ? label.textContent.trim() : '↓';
  float.setAttribute('aria-label', float.textContent);
  document.body.appendChild(float);
  let currentInView = false;
  let introInView = true;
  const update = () => {
    float.classList.toggle('is-visible', !introInView && !currentInView);
  };
  if ('IntersectionObserver' in window) {
    const currentObserver = new IntersectionObserver(entries => {
      currentInView = entries.some(entry => entry.isIntersecting);update();
    }, {rootMargin:'-20% 0px -15% 0px'});
    currentObserver.observe(current);
    const hero = root.querySelector('.lm20-welcome');
    if (hero) {
      const heroObserver = new IntersectionObserver(entries => {
        introInView = entries.some(entry => entry.isIntersecting); update();
      }, {threshold:0});
      heroObserver.observe(hero);
    }
  } else {
    const scrollUpdate = () => {
      const rect = current.getBoundingClientRect();
      currentInView = rect.top < window.innerHeight * .85 && rect.bottom > window.innerHeight * .2;
      introInView = window.scrollY < 250;
      update();
    };
    window.addEventListener('scroll',scrollUpdate,{passive:true});
    scrollUpdate();
  }
})();

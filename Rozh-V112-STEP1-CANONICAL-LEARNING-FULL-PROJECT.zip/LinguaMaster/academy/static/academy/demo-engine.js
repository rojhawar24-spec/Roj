/* LinguaMaster public demo: original teaching content, no tracking and no XP. */
(function (scope, make) {
  'use strict';
  const api = make();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else scope.LinguaMasterDemoEngine = api;
})(typeof window === 'undefined' ? {} : window, function () {
  'use strict';
  const questions = Object.freeze([
    {id:'greeting',kind:'choice',say:null, answer:'morning',
      prompt:{en:'What does “Goedemorgen” mean?',nl:'Wat betekent “Goedemorgen”?',ckb:'واتای «Goedemorgen» چییە؟',ar:'ماذا تعني «Goedemorgen»؟'},
      options:[
        {id:'evening',label:{en:'Good evening',nl:'Goedenavond',ckb:'ئێوارە باش',ar:'مساء الخير'}},
        {id:'morning',label:{en:'Good morning',nl:'Goedemorgen',ckb:'بەیانی باش',ar:'صباح الخير'}},
        {id:'goodbye',label:{en:'Goodbye',nl:'Tot ziens',ckb:'ماڵئاوا',ar:'إلى اللقاء'}}
      ],hint:{en:'Think about greeting someone early in the day.',nl:'Denk aan een begroeting in de ochtend.',ckb:'بیر لە سڵاوکردن لە بەیانی بکەرەوە.',ar:'فكّر في التحية في الصباح.'},
      explain:{en:'“Goedemorgen” means good morning.',nl:'“Goedemorgen” zeg je in de ochtend.',ckb:'«Goedemorgen» واتە بەیانی باش.',ar:'«Goedemorgen» تعني صباح الخير.'}},
    {id:'listen',kind:'choice',say:'Ik ben Noor.', answer:'im-noor',
      prompt:{en:'Listen. Which Dutch sentence do you hear?',nl:'Luister. Welke Nederlandse zin hoor je?',ckb:'گوێ بگرە. کام ڕستەی هۆڵەندی دەبیستیت؟',ar:'استمع. أي جملة هولندية تسمع؟'},
      options:[
        {id:'are-noor',label:{en:'Jij bent Noor.',nl:'Jij bent Noor.',ckb:'Jij bent Noor.',ar:'Jij bent Noor.'}},
        {id:'im-noor',label:{en:'Ik ben Noor.',nl:'Ik ben Noor.',ckb:'Ik ben Noor.',ar:'Ik ben Noor.'}},
        {id:'have-noor',label:{en:'Ik heb Noor.',nl:'Ik heb Noor.',ckb:'Ik heb Noor.',ar:'Ik heb Noor.'}}
      ],hint:{en:'“Ik ben” means “I am”.',nl:'“Ik ben” betekent “I am”.',ckb:'«Ik ben» واتە «من ...م».',ar:'«Ik ben» تعني «أنا». '},
      explain:{en:'“Ik ben Noor” means “I am Noor”.',nl:'“Ik ben Noor” betekent “I am Noor”.',ckb:'«Ik ben Noor» واتە «من نوورم».',ar:'«Ik ben Noor» تعني «أنا نور».'}},
    {id:'order',kind:'order',answer:'Ik ben Noor',
      prompt:{en:'Build the Dutch sentence: “I am Noor.”',nl:'Maak de zin: “I am Noor.”',ckb:'ئەم ڕستەیە بە هۆڵەندی دروست بکە: «من نوورم.»',ar:'رتّب الكلمات لتقول بالهولندية: «أنا نور».'},
      tokens:[{id:'noor',text:'Noor'},{id:'ik',text:'Ik'},{id:'bent',text:'bent'},{id:'ben',text:'ben'}],
      hint:{en:'Start with “Ik”, then the verb “ben”.',nl:'Begin met “Ik” en daarna “ben”.',ckb:'بە «Ik» دەست پێ بکە، پاشان «ben».',ar:'ابدأ بـ «Ik» ثم «ben».'},
      explain:{en:'Correct word order: Ik ben Noor.',nl:'De juiste volgorde is: Ik ben Noor.',ckb:'ڕیزبەندی دروست: Ik ben Noor.',ar:'الترتيب الصحيح: Ik ben Noor.'}},
    {id:'write',kind:'text',answer:['dank je','dank u','dankjewel','dank je wel','dank u wel'],
      prompt:{en:'Write “thank you” in Dutch.',nl:'Schrijf “thank you” in het Nederlands.',ckb:'«سوپاس» بە هۆڵەندی بنووسە.',ar:'اكتب «شكراً» باللغة الهولندية.'},
      hint:{en:'It starts with “dank…”.',nl:'Het begint met “dank…”.',ckb:'بە «dank…» دەست پێ دەکات.',ar:'تبدأ الكلمة بـ «dank…».'},
      explain:{en:'“Dank je” is a friendly way to say thank you.',nl:'“Dank je” is een vriendelijke manier om te bedanken.',ckb:'«Dank je» ڕێگایەکی دۆستانەی سوپاسکردنە.',ar:'«Dank je» طريقة لطيفة لقول شكراً.'}},
    {id:'cafe',kind:'choice',answer:'welcome',
      prompt:{en:'At a café someone says “Dank je”. What do you reply?',nl:'Iemand zegt “Dank je” in een café. Wat antwoord je?',ckb:'لە قاوەخانەیەک کەسێک دەڵێت «Dank je». چی دەڵێیتەوە؟',ar:'يقول أحدهم «Dank je» في المقهى. بماذا تجيب؟'},
      options:[{id:'hello',label:{en:'Goedemorgen',nl:'Goedemorgen',ckb:'Goedemorgen',ar:'Goedemorgen'}},{id:'welcome',label:{en:'Graag gedaan',nl:'Graag gedaan',ckb:'Graag gedaan',ar:'Graag gedaan'}},{id:'name',label:{en:'Ik ben Noor',nl:'Ik ben Noor',ckb:'Ik ben Noor',ar:'Ik ben Noor'}}],
      hint:{en:'You want to say “You’re welcome”.',nl:'Je wilt zeggen “Graag gedaan”.',ckb:'دەبێت بڵێیت «بە خۆشی».',ar:'أنت تريد أن تقول «على الرحب والسعة».'},
      explain:{en:'“Graag gedaan” means “You’re welcome”.',nl:'“Graag gedaan” is het juiste antwoord.',ckb:'«Graag gedaan» واتە «بە خۆشی».',ar:'«Graag gedaan» تعني «على الرحب والسعة».'}}
  ]);
  const locales = ['en','nl','ckb','ar'];
  function clean(value) {
    if (typeof value !== 'string') return '';
    return value.normalize('NFKC').toLocaleLowerCase('nl').replace(/[.,!?،؛؟]/g,'').replace(/\s+/g,' ').trim();
  }
  function evaluate(item, answer) {
    if (!item || !['choice','order','text'].includes(item.kind)) return false;
    if (item.kind === 'choice') return typeof answer === 'string' && answer === item.answer;
    const normalized = clean(answer);
    if (!normalized) return false;
    if (item.kind === 'order') return normalized === clean(item.answer);
    return item.answer.some(candidate => clean(candidate) === normalized);
  }
  function phrase(value, locale) { return (value && value[locale]) || (value && value.en) || ''; }
  return Object.freeze({questions,locales,clean,evaluate,phrase});
});

/* Install help and appearance controls. No private content is cached here. */
(() => {
  'use strict';
  const normalizeMode = value => ['system', 'light', 'dark'].includes(value) ? value : 'system';
  const resolvedMode = (preference, systemDark) => normalizeMode(preference) === 'system' ? (systemDark ? 'dark' : 'light') : normalizeMode(preference);
  const installPlatform = (userAgent, platform, maxTouchPoints) => /iPad|iPhone|iPod/.test(userAgent) || (platform === 'MacIntel' && maxTouchPoints > 1) ? 'ios' : /Android/.test(userAgent) ? 'android' : 'desktop';
  // The pure environment decisions can also be verified without a browser.
  if (typeof module !== 'undefined' && module.exports) module.exports = {normalizeMode, resolvedMode, installPlatform};
  if (typeof document === 'undefined') return;

  const copy = {
    en: {
      appearance:'Appearance', appearanceNote:'Choose what feels comfortable. System follows your device settings.', chooseTheme:'Color theme', system:'System', light:'Light', dark:'Dark', close:'Close', saved:'Appearance saved.', saveFailed:'Your preference could not be saved. Please try again.', saving:'Saving…',
      install:'Install Rozh', installTitle:'Your learning app, one tap away', installNote:'Add Rozh to your home screen and open it in its own window.',
      ios1:'Open this website in Safari on your iPhone or iPad.', ios2:'Tap Share (the square with an upward arrow). You may find it in the browser menu.', ios3:'Choose “Add to Home Screen”, then tap “Add”.',
      android1:'Open your browser menu (usually the three dots).', android2:'Choose “Install app” or “Add to Home screen”.', android3:'Confirm, then open Rozh from your home screen.',
      desktop1:'Look for the install icon in your browser’s address bar or menu.', desktop2:'Choose “Install Rozh” or “Install this site as an app”.', desktop3:'If your browser has no install option, you can still use all online lessons here.',
      offlineNote:'Lessons and your progress currently need an internet connection. Installing the app does not download your lessons.', installNow:'Install app', installDeclined:'You can install later using your browser menu.',
      offlineTitle:'Let’s reconnect', offlineBody:'We cannot reach the learning server. Check your internet connection and try again.', retry:'Try again', offlinePrivacy:'This offline page contains no account information. Lessons are not downloaded for offline use.', connected:'Connection restored. Tap “Try again” to continue.'
    },
    nl: {
      appearance:'Weergave', appearanceNote:'Kies wat prettig leest. Systeem volgt de instellingen van je apparaat.', chooseTheme:'Kleurthema', system:'Systeem', light:'Licht', dark:'Donker', close:'Sluiten', saved:'Weergave opgeslagen.', saveFailed:'Je voorkeur kon niet worden opgeslagen. Probeer het opnieuw.', saving:'Opslaan…',
      install:'Rozh installeren', installTitle:'Je leerapp, met één tik geopend', installNote:'Zet Rozh op je beginscherm en open het in een eigen venster.',
      ios1:'Open deze website in Safari op je iPhone of iPad.', ios2:'Tik op Delen (het vierkant met een pijl omhoog). Dit staat soms in het browsermenu.', ios3:'Kies ‘Zet op beginscherm’ en tik daarna op ‘Voeg toe’.',
      android1:'Open het browsermenu (meestal de drie puntjes).', android2:'Kies ‘App installeren’ of ‘Toevoegen aan startscherm’.', android3:'Bevestig en open Rozh vanaf je startscherm.',
      desktop1:'Zoek het installatie-icoon in de adresbalk of het menu van je browser.', desktop2:'Kies ‘Rozh installeren’ of ‘Deze site als app installeren’.', desktop3:'Heeft je browser geen installatie-optie? Je kunt hier alle online lessen blijven gebruiken.',
      offlineNote:'Voor lessen en het opslaan van je voortgang is nu internet nodig. Installeren downloadt je lessen niet.', installNow:'App installeren', installDeclined:'Je kunt later installeren via het browsermenu.',
      offlineTitle:'Even opnieuw verbinden', offlineBody:'We kunnen de leerserver niet bereiken. Controleer je internetverbinding en probeer het opnieuw.', retry:'Opnieuw proberen', offlinePrivacy:'Deze offlinepagina bevat geen accountgegevens. Lessen zijn niet gedownload voor offline gebruik.', connected:'De verbinding is hersteld. Tik op ‘Opnieuw proberen’ om verder te gaan.'
    },
    ckb: {
      appearance:'ڕووکار', appearanceNote:'ئەو شێوازە هەڵبژێرە کە بۆ خوێندنەوە ئاسوودەیە. سیستەم شوێنی ڕێکخستنەکانی ئامێرەکەت دەکەوێت.', chooseTheme:'ڕەنگی ڕووکار', system:'سیستەم', light:'ڕوون', dark:'تاریک', close:'داخستن', saved:'ڕووکار پاشەکەوت کرا.', saveFailed:'هەڵبژاردنەکەت پاشەکەوت نەکرا. دووبارە هەوڵ بدەوە.', saving:'پاشەکەوت دەکرێت…',
      install:'دامەزراندنی Rozh', installTitle:'ئەپەکەی فێربوونت، بە یەک دەستلێدان', installNote:'Rozh بخەرە سەر شاشەی سەرەکی و لە پەنجەرەیەکی تایبەتدا بیکەرەوە.',
      ios1:'ئەم وێبسایتە لە Safari لە iPhone یان iPad بکەرەوە.', ios2:'دوگمەی Share دابگرە؛ چوارگۆشەیەکە بە تیرێک بەرەو سەرەوە. لەوانەیە لە لیستی وێبگەڕەکەدا بێت.', ios3:'«Add to Home Screen» هەڵبژێرە، پاشان «Add» دابگرە.',
      android1:'لیستی وێبگەڕەکە بکەرەوە؛ زۆرجار سێ خاڵە.', android2:'«Install app» یان «Add to Home screen» هەڵبژێرە.', android3:'پشتڕاستی بکەرەوە و Rozh لە شاشەی سەرەکی بکەرەوە.',
      desktop1:'لە ناونیشان یان لیستی وێبگەڕەکەت بگەڕێ بۆ ئایکۆنی دامەزراندن.', desktop2:'«Install Rozh» یان «Install this site as an app» هەڵبژێرە.', desktop3:'ئەگەر هەڵبژاردەی دامەزراندن نییە، هەر دەتوانیت هەموو وانە ئۆنلاینەکان لێرە بەکاربهێنیت.',
      offlineNote:'ئێستا وانەکان و پێشکەوتنەکەت پێویستیان بە ئینتەرنێت هەیە. دامەزراندنی ئەپ وانەکان داناگرێت.', installNow:'ئەپەکە دابمەزرێنە', installDeclined:'دەتوانیت دواتر لە لیستی وێبگەڕەکە دایبمەزرێنیت.',
      offlineTitle:'با دووبارە پەیوەست بینەوە', offlineBody:'ناتوانین بگەینە ڕاژەکاری فێربوون. پەیوەندیی ئینتەرنێتەکەت بپشکنە و دووبارە هەوڵ بدەوە.', retry:'دووبارە هەوڵ بدەوە', offlinePrivacy:'ئەم پەڕەیە هیچ زانیارییەکی ئەکاونتی تێدا نییە. وانەکان بۆ بەکارهێنانی بێ ئینتەرنێت دانەگیراون.', connected:'پەیوەندی گەڕایەوە. بۆ بەردەوامبوون «دووبارە هەوڵ بدەوە» دابگرە.'
    },
    ar: {
      appearance:'المظهر', appearanceNote:'اختر ما يريحك في القراءة. يتبع خيار النظام إعدادات جهازك.', chooseTheme:'نمط الألوان', system:'النظام', light:'فاتح', dark:'داكن', close:'إغلاق', saved:'تم حفظ المظهر.', saveFailed:'تعذر حفظ تفضيلك. حاول مرة أخرى.', saving:'جارٍ الحفظ…',
      install:'تثبيت Rozh', installTitle:'تطبيق التعلّم، بلمسة واحدة', installNote:'أضف Rozh إلى الشاشة الرئيسية وافتحه في نافذة مستقلة.',
      ios1:'افتح هذا الموقع في Safari على iPhone أو iPad.', ios2:'اضغط على المشاركة (المربع الذي يحتوي على سهم للأعلى). قد تجده في قائمة المتصفح.', ios3:'اختر «إضافة إلى الشاشة الرئيسية»، ثم اضغط «إضافة».',
      android1:'افتح قائمة المتصفح (عادةً النقاط الثلاث).', android2:'اختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية».', android3:'أكّد الاختيار ثم افتح Rozh من الشاشة الرئيسية.',
      desktop1:'ابحث عن رمز التثبيت في شريط العنوان أو قائمة المتصفح.', desktop2:'اختر «تثبيت Rozh» أو «تثبيت هذا الموقع كتطبيق».', desktop3:'إذا لم يتوفر التثبيت في متصفحك، يمكنك متابعة جميع الدروس عبر الموقع.',
      offlineNote:'تحتاج الدروس وحفظ التقدم حاليًا إلى الإنترنت. تثبيت التطبيق لا ينزّل الدروس.', installNow:'تثبيت التطبيق', installDeclined:'يمكنك التثبيت لاحقًا من قائمة المتصفح.',
      offlineTitle:'لنُعِد الاتصال', offlineBody:'يتعذر الوصول إلى خادم التعلّم. تحقق من اتصالك بالإنترنت وحاول مجددًا.', retry:'المحاولة مجددًا', offlinePrivacy:'لا تحتوي هذه الصفحة على معلومات الحساب. لم تُنزّل الدروس للاستخدام دون إنترنت.', connected:'عاد الاتصال. اضغط «المحاولة مجددًا» للمتابعة.'
    }
  };
  const root = document.documentElement;
  let language = (root.lang || 'en').toLowerCase().split('-')[0];
  // The offline fallback is static and has no session context: reuse only the UI language.
  if (document.body.classList.contains('pwa-offline-page')) {
    try { language = localStorage.getItem('linguamaster-ui-language') || language; } catch (_) {}
    root.lang = copy[language] ? language : 'en';
    root.dir = ['ckb', 'kmr', 'kmr-Arab', 'ar'].includes(root.lang) ? 'rtl' : 'ltr';
  } else {
    try { localStorage.setItem('linguamaster-ui-language', language); } catch (_) {}
  }
  const t = copy[language] || copy.en;
  const darkMedia = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : {matches:false};
  const account = document.getElementById('accountAppearance');
  let preference = normalizeMode(root.dataset.themePreference);
  if (account) preference = normalizeMode(account.dataset.theme);
  else try { preference = normalizeMode(localStorage.getItem('linguamaster-theme')); } catch (_) {}
  function applyAppearance(mode) {
    preference = normalizeMode(mode);
    root.dataset.themePreference = preference;
    root.dataset.theme = resolvedMode(preference, darkMedia.matches);
    try { localStorage.setItem('linguamaster-theme', preference); } catch (_) {}
  }
  if (account) root.dataset.reduceMotion = account.dataset.reduceMotion === 'true' ? 'true' : 'false';
  applyAppearance(preference);
  const systemChanged = () => applyAppearance(preference);
  if (darkMedia.addEventListener) darkMedia.addEventListener('change', systemChanged);
  else if (darkMedia.addListener) darkMedia.addListener(systemChanged);
  window.addEventListener('storage', event => {
    if (event.key === 'linguamaster-theme') applyAppearance(event.newValue);
  });

  function element(tag, text, className) {
    const node = document.createElement(tag);
    if (text) node.textContent = text;
    if (className) node.className = className;
    return node;
  }
  const visibleControl = node => !node.disabled && !node.hidden && node.tabIndex !== -1 &&
    (!node.closest || !node.closest('[hidden],[inert]')) &&
    (!node.getClientRects || node.getClientRects().length > 0) &&
    (!window.getComputedStyle || window.getComputedStyle(node).visibility !== 'hidden');
  function tabbableControls(dialog) {
    const controls = Array.from(dialog.querySelectorAll('button,input,a[href],[tabindex]')).filter(visibleControl);
    return controls.filter(node => {
      // A named radio group is one Tab stop: the checked radio, or its first option.
      if (node.type !== 'radio' || !node.name) return true;
      const group = controls.filter(other => other.type === 'radio' && other.name === node.name && other.form === node.form);
      return node === (group.find(other => other.checked) || group[0]);
    });
  }
  function makeDialog(kind, title) {
    const dialog = element('dialog', '', 'pwa-dialog');
    dialog.id = 'pwa-' + kind;
    dialog.setAttribute('aria-labelledby', dialog.id + '-title');
    const close = element('button', '×', 'pwa-dialog-close');
    close.type = 'button'; close.setAttribute('aria-label', t.close);
    const heading = element('h2', title);
    heading.id = dialog.id + '-title';
    dialog.append(close, heading);
    document.body.append(dialog);
    let opener = null;
    function restoreFocus() {
      if (opener && visibleControl(opener)) opener.focus();
      else {
        // Installation can hide its own opener after success.
        const fallback = document.getElementById('themeToggle');
        if (fallback && visibleControl(fallback)) fallback.focus();
      }
    }
    function hide() {
      if (typeof dialog.close === 'function') dialog.close();
      else { dialog.removeAttribute('open'); restoreFocus(); }
    }
    close.addEventListener('click', hide);
    dialog.addEventListener('close', restoreFocus);
    dialog.addEventListener('keydown', event => {
      if (event.key === 'Escape') { event.preventDefault(); hide(); }
      if (event.key !== 'Tab') return;
      const focusable = tabbableControls(dialog);
      const first = focusable[0], last = focusable[focusable.length - 1];
      if (!first) { event.preventDefault(); return; }
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    });
    return {dialog, open(trigger) {
      opener = trigger || document.activeElement;
      if (dialog.open) return;
      if (typeof dialog.showModal === 'function') dialog.showModal();
      else { dialog.setAttribute('open',''); dialog.setAttribute('role','dialog'); dialog.setAttribute('aria-modal','true'); }
      close.focus();
    }, close:hide, focusClose() { close.focus(); }};
  }

  const themeButton = document.getElementById('themeToggle');
  if (themeButton) {
    themeButton.setAttribute('aria-label', t.appearance);
    themeButton.title = t.appearance;
    themeButton.setAttribute('aria-haspopup', 'dialog');
    const appearance = makeDialog('appearance', t.appearance);
    const description = element('p', t.appearanceNote);
    description.id = 'pwa-appearance-description';
    appearance.dialog.setAttribute('aria-describedby', description.id);
    appearance.dialog.append(description);
    const options = element('fieldset', '', 'pwa-appearance-options');
    options.append(element('legend', t.chooseTheme));
    const inputs = [];
    const status = element('p', '', 'pwa-dialog-status');
    status.tabIndex = -1;
    status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite');
    for (const [mode, icon] of [['system','◐'], ['light','☀'], ['dark','☾']]) {
      const label = element('label', '', 'pwa-appearance-option');
      const input = element('input'); input.type = 'radio'; input.name = 'pwa-theme'; input.value = mode; input.checked = mode === preference;
      const symbol = element('span', icon, 'pwa-option-icon'); symbol.setAttribute('aria-hidden','true');
      label.append(input, symbol, element('span', t[mode])); options.append(label); inputs.push(input);
      input.addEventListener('change', async () => {
        if (!input.checked || input.disabled) return;
        const previous = preference;
        applyAppearance(mode);
        if (!account || !account.dataset.saveUrl) { status.textContent = t.saved; return; }
        const focusedInput = document.activeElement === input;
        inputs.forEach(item => { item.disabled = true; }); status.textContent = t.saving;
        // Disabling the focused input otherwise moves browser focus out of the dialog.
        if (focusedInput) status.focus();
        try {
          const body = new URLSearchParams({theme:mode, csrfmiddlewaretoken:account.dataset.csrf || ''});
          const response = await fetch(account.dataset.saveUrl, {method:'POST',credentials:'same-origin',headers:{'Accept':'application/json'},body});
          if (!response.ok || response.redirected) throw new Error('save failed');
          const result = await response.json();
          if (!['system','light','dark'].includes(result.theme)) throw new Error('invalid preference');
          applyAppearance(result.theme); account.dataset.theme = result.theme;
          inputs.forEach(item => { item.checked = item.value === result.theme; });
          status.textContent = t.saved;
        } catch (_) {
          applyAppearance(previous); inputs.forEach(item => { item.checked = item.value === previous; }); status.textContent = t.saveFailed;
        } finally {
          inputs.forEach(item => { item.disabled = false; });
          if (appearance.dialog.open && document.activeElement === status) {
            const selected = inputs.find(item => item.checked);
            if (selected) selected.focus();
          }
        }
      });
    }
    appearance.dialog.append(options, status);
    themeButton.addEventListener('click', () => {
      inputs.forEach(item => { item.checked = item.value === preference; });
      status.textContent = ''; appearance.open(themeButton);
    });
  }

  let nativePrompt = null;
  const installButton = document.getElementById('installApp');
  const standalone = () => Boolean(navigator.standalone || (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches));
  let installDialog = null;
  let installAction = null;
  if (installButton) {
    installButton.textContent = '';
    const icon = element('span', '⇩', 'pwa-install-icon'); icon.setAttribute('aria-hidden','true');
    installButton.append(icon, element('span', t.install, 'pwa-install-label'));
    installButton.setAttribute('aria-label', t.install); installButton.title = t.install;
    installButton.setAttribute('aria-haspopup','dialog'); installButton.hidden = standalone();
    installDialog = makeDialog('install', t.installTitle);
    const description = element('p', t.installNote);
    description.id = 'pwa-install-description';
    installDialog.dialog.setAttribute('aria-describedby', description.id);
    installDialog.dialog.append(description);
    const steps = element('ol');
    const platform = installPlatform(navigator.userAgent || '', navigator.platform || '', navigator.maxTouchPoints || 0);
    for (let index=1; index<=3; index++) steps.append(element('li', t[platform + index]));
    installDialog.dialog.append(steps, element('p', t.offlineNote, 'pwa-note'));
    const status = element('p', '', 'pwa-dialog-status'); status.setAttribute('role','status');
    installAction = element('button', t.installNow, 'pwa-primary pwa-dialog-action'); installAction.type='button'; installAction.hidden=true;
    installAction.addEventListener('click', async () => {
      if (!nativePrompt) return;
      const prompt = nativePrompt; nativePrompt = null; installAction.hidden = true;
      installDialog.focusClose();
      try {
        await prompt.prompt();
        const choice = await prompt.userChoice;
        if (choice && choice.outcome === 'accepted') { installButton.hidden = true; installDialog.close(); }
        else status.textContent = t.installDeclined;
      } catch (_) { status.textContent = t.installDeclined; }
    });
    installDialog.dialog.append(installAction, status);
    installButton.addEventListener('click', () => { installAction.hidden = !nativePrompt; installDialog.open(installButton); });
  }
  window.addEventListener('beforeinstallprompt', event => {
    // With no install control, keep the browser's default prompt available.
    if (!installButton) return;
    event.preventDefault(); nativePrompt = event;
    installButton.hidden = standalone(); if (installAction) installAction.hidden = false;
  });
  window.addEventListener('appinstalled', () => {
    nativePrompt = null;
    if (installButton) installButton.hidden = true;
    if (installDialog && installDialog.dialog.open) installDialog.close();
  });

  const offlineHeading = document.getElementById('offlineTitle');
  if (offlineHeading) {
    document.title = 'Rozh — ' + t.offlineTitle;
    offlineHeading.textContent = t.offlineTitle;
    document.getElementById('offlineBody').textContent = t.offlineBody;
    document.getElementById('offlinePrivacy').textContent = t.offlinePrivacy;
    const retry = document.getElementById('offlineRetry'); retry.textContent = t.retry;
    retry.addEventListener('click', event => { event.preventDefault(); window.location.reload(); });
    window.addEventListener('online', () => { document.getElementById('offlineStatus').textContent = t.connected; });
  }
})();

/* Progressive enhancement only: no credentials, answers or personal data stored. */
(() => {
  'use strict';
  document.querySelectorAll('[data-password-toggle]').forEach(toggle => {
    const wrapper = toggle.closest('.lm-password-wrap');
    const field = wrapper && wrapper.querySelector('input[type=password],input[type=text]');
    if (!field) return;
    toggle.addEventListener('click', () => {
      const showing = field.type === 'password';
      field.type = showing ? 'text' : 'password';
      toggle.textContent = showing ? (toggle.dataset?.hideLabel || 'Hide') : (toggle.dataset?.showLabel || 'Show');
      toggle.setAttribute('aria-pressed', String(showing));
      toggle.setAttribute('aria-label', (showing ? (toggle.dataset?.hideLabel || 'Hide') : (toggle.dataset?.showLabel || 'Show')) + ' ' + (field.labels && field.labels[0] ? field.labels[0].textContent.trim() : 'password'));
      field.focus({preventScroll:true});
    });
  });
  // Connect server-side errors to their fields for assistive technology.
  const errors = Array.from(document.querySelectorAll('.lm-auth-field-error'));
  errors.forEach((block, index) => {
    const field = block.querySelector('input:not([type=hidden]),select,textarea');
    const messages = block.querySelectorAll('.lm-auth-error');
    if (!field) return;
    field.setAttribute('aria-invalid','true');
    const ids = [];
    messages.forEach((message, i) => {
      if (!message.id) message.id = `lm-error-${index}-${i}`;
      ids.push(message.id);
    });
    if (ids.length) field.setAttribute('aria-describedby', [field.getAttribute('aria-describedby'), ...ids].filter(Boolean).join(' '));
  });
  if (errors.length) {
    const first = errors[0].querySelector('input:not([type=hidden]),select,textarea');
    if (first) first.focus({preventScroll:true});
  }
})();

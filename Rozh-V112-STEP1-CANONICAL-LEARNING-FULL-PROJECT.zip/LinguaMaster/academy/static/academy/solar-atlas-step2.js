/* Presentation-only winding lines. No state changes, analytics, network or storage. */
(() => {
  'use strict';
  const paths = Array.from(document.querySelectorAll('[data-solar-path]'));
  if (!paths.length) return;
  let queued = false;
  function draw() {
    queued = false;
    paths.forEach(list => {
      const svg = list.querySelector('.solar-learn-route-svg');
      if (!svg) return;
      const nodes = Array.from(list.querySelectorAll('[data-solar-node] .solar-node-icon'));
      const rect = list.getBoundingClientRect();
      if (nodes.length < 2 || rect.width === 0) { svg.hidden = true; return; }
      svg.hidden = false;
      svg.setAttribute('viewBox', `0 0 ${rect.width} ${list.scrollHeight}`);
      const dots = nodes.map(node => {
        const r = node.getBoundingClientRect();
        return [r.left - rect.left + r.width / 2, r.top - rect.top + r.height / 2];
      });
      const bend = list.dataset.solarCurve === 'flow' ? .26 : list.dataset.solarCurve === 'arc' ? .69 : .48;
      let path = `M ${dots[0][0].toFixed(1)} ${dots[0][1].toFixed(1)}`;
      for (let i = 1; i < dots.length; i++) {
        const [x0, y0] = dots[i-1], [x1, y1] = dots[i];
        const dy = Math.max(5, (y1 - y0) * bend);
        path += ` C ${x0.toFixed(1)} ${(y0 + dy).toFixed(1)} ${x1.toFixed(1)} ${(y1 - dy).toFixed(1)} ${x1.toFixed(1)} ${y1.toFixed(1)}`;
      }
      svg.querySelectorAll('path').forEach(p => p.setAttribute('d', path));
    });
  }
  function schedule() { if (!queued) { queued=true; requestAnimationFrame(draw); } }
  schedule();
  if ('ResizeObserver' in window) {
    const observer = new ResizeObserver(schedule);
    paths.forEach(el=>observer.observe(el));
  } else window.addEventListener('resize', schedule, {passive:true});
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(schedule).catch(() => {});
})();

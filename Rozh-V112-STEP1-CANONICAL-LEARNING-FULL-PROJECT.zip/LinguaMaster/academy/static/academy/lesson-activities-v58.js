/* Reusable student controls. Server alone checks correctness. No paid APIs. */
(() => {
  'use strict';
  document.querySelectorAll('[data-v58-builder]').forEach(root => {
    const buttons = Array.from(root.querySelectorAll('[data-v58-tile]'));
    const input = root.querySelector('[data-v58-answer]');
    const assembled = root.querySelector('[data-v58-assembled]');
    const chosen = [];
    if (!input || !assembled) return;
    const draw = () => {
      input.value = chosen.map(id => buttons.find(b => b.dataset.v58Tile === id)?.dataset.v58Word || '').join(' ');
      assembled.replaceChildren();
      for (const id of chosen) {
        const element = document.createElement('span');
        element.textContent = buttons.find(b => b.dataset.v58Tile === id)?.dataset.v58Word || '';
        assembled.append(element);
      }
      buttons.forEach(b => { b.disabled = chosen.includes(b.dataset.v58Tile); });
    };
    buttons.forEach(button => button.addEventListener('click', () => {
      if (root.closest('form')?.classList.contains('has-feedback')) return;
      chosen.push(button.dataset.v58Tile);draw();
    }));
    root.querySelector('[data-v58-undo]')?.addEventListener('click', () => {
      chosen.pop();draw();
    });
    input.addEventListener('input', () => {
      chosen.length = 0;assembled.replaceChildren();buttons.forEach(b => {b.disabled=false;});
    });
  });
  // V95 Step 3 B: prevent duplicate match submissions before grading.
  // Keep native required/select validation as a no-JS fallback; the server is
  // authoritative, even when somebody crafts a POST bypassing the browser.
  const matchingCopy = {
    nl: {progress:(n,t)=>`${n} van ${t} koppelingen gekozen.`,duplicate:'Kies voor elke rij een ander antwoord.',complete:'Alle koppelingen gekozen. Controleer je antwoord.',help:'Kies voor iedere rij één ander antwoord.'},
    en: {progress:(n,t)=>`${n} of ${t} matches selected.`,duplicate:'Choose a different answer for each row.',complete:'All matches selected. Check your answer.',help:'Select one different match for every row.'},
    de: {progress:(n,t)=>`${n} von ${t} Zuordnungen gewählt.`,duplicate:'Wähle für jede Zeile eine andere Antwort.',complete:'Alle Zuordnungen gewählt. Prüfe deine Antwort.',help:'Wähle für jede Zeile eine andere Zuordnung.'},
    fr: {progress:(n,t)=>`${n} correspondances sur ${t} choisies.`,duplicate:'Choisissez une réponse différente pour chaque ligne.',complete:'Toutes les correspondances sont choisies. Vérifiez votre réponse.',help:'Associez chaque ligne à une réponse différente.'},
    uk: {progress:(n,t)=>`Вибрано ${n} із ${t} відповідностей.`,duplicate:'Оберіть різні відповіді для кожного рядка.',complete:'Усі відповідності вибрано. Перевірте відповідь.',help:'Для кожного рядка виберіть іншу відповідь.'},
    ar: {progress:(n,t)=>`تم اختيار ${n} من ${t} أزواج.`,duplicate:'اختر إجابة مختلفة لكل صف.',complete:'تم اختيار جميع الأزواج. راجع إجابتك.',help:'اختر إجابة مختلفة لكل صف.'},
    ckb: {progress:(n,t)=>`${n} لە ${t} جووت هەڵبژێردراوە.`,duplicate:'بۆ هەر ڕیزێک وەڵامێکی جیاواز هەڵبژێرە.',complete:'هەموو جووتەکان هەڵبژێردراون. وەڵامەکەت بپشکنە.',help:'هەر ڕیزێک بە وەڵامێکی جیاواز ببەستەوە.'},
    kmr: {progress:(n,t)=>`${n} ژ ${t} جووت هاتنە هەلبژارتن.`,duplicate:'بۆ هەر ڕێزەکێ بەرسڤەکا جیاواز هەلبژێرە.',complete:'هەمی جووت هاتنە هەلبژارتن. بەرسڤا خۆ بپشکنە.',help:'هەر ڕێزەکێ ب بەرسڤەکا جیاواز گرێ بدە.'},
    ku: {progress:(n,t)=>`${n} ji ${t} cot hatin hilbijartin.`,duplicate:'Ji bo her rêzekê bersiveke cuda hilbijêre.',complete:'Hemû cot hatin hilbijartin. Bersiva xwe kontrol bike.',help:'Her rêzekê bi bersiveke cuda girê bide.'}
  };
  document.querySelectorAll('[data-v58-matching]').forEach(root => {
    const rows = Array.from(root.querySelectorAll('[data-v58-match-select]'));
    const hidden = root.querySelector('[data-v58-answer]');
    const status = root.querySelector('[data-v58-match-status]');
    const copy = matchingCopy[root.dataset.v58Locale] || matchingCopy.en;
    if (!hidden || !rows.length) return;
    const help = root.querySelector('[data-v58-match-help]');
    if (help) help.textContent = copy.help;
    const update = () => {
      const selections = rows.map(s => s.value);
      const seen = new Set();
      let hasDuplicate = false;
      rows.forEach((select,i) => {
        const value = selections[i];
        const duplicate = value !== '' && seen.has(value);
        if (value !== '') seen.add(value);
        if (duplicate) hasDuplicate = true;
        select.setCustomValidity(duplicate ? copy.duplicate : '');
        if (duplicate) select.setAttribute('aria-invalid','true');
        else select.removeAttribute('aria-invalid');
      });
      const complete = selections.every(value => value !== '');
      hidden.value = complete && !hasDuplicate ? JSON.stringify(selections.map(Number)) : '';
      if (status) status.textContent = hasDuplicate ? copy.duplicate
        : complete ? copy.complete
        : copy.progress(selections.filter(value => value !== '').length,rows.length);
    };
    rows.forEach(select => select.addEventListener('change',update));
    update();
  });
  // V81: distinct Memory Match interaction. Never embed or compare correct pairs in JavaScript.
  // The browser only submits the learner's proposed permutation; server remains authoritative.
  const memoryCopy = {
    nl: {instruction:'Draai een kaart uit elke kolom om en verbind de woorden. De controle gebeurt pas bij indienen.',pair:'Verbind de kaarten',reset:'Opnieuw beginnen',help:'Klik op een gekoppelde kaart om dat paar te veranderen.',status:(n,total)=>`${n} van ${total} paren verbonden.`,select:'Selecteer één kaart uit elke kolom.',complete:'Alle paren verbonden. Je kunt je antwoord indienen.',left:'Linkerkaart',right:'Rechterkaart',face:'omgedraaid',hidden:'gedekt',linked:'gekoppeld'},
    en: {instruction:'Turn over a card from each column, then connect the matching words. Answers are checked only when submitted.',pair:'Connect selected cards',reset:'Start again',help:'Select a linked card to change its pair.',status:(n,total)=>`${n} of ${total} pairs linked.`,select:'Choose one card from each column.',complete:'All pairs linked. You can submit.',left:'Left card',right:'Right card',face:'revealed',hidden:'face down',linked:'linked'},
    de: {instruction:'Decke eine Karte aus jeder Spalte auf und verbinde passende Wörter. Die Antwort wird erst beim Absenden geprüft.',pair:'Karten verbinden',reset:'Neu beginnen',help:'Wähle eine verbundene Karte, um das Paar zu ändern.',status:(n,total)=>`${n} von ${total} Paaren verbunden.`,select:'Wähle eine Karte aus jeder Spalte.',complete:'Alle Paare verbunden. Du kannst die Antwort absenden.',left:'Linke Karte',right:'Rechte Karte',face:'aufgedeckt',hidden:'verdeckt',linked:'verbunden'},
    fr: {instruction:'Retournez une carte de chaque colonne, puis associez-les. La correction a lieu lors de la validation.',pair:'Associer les cartes',reset:'Recommencer',help:'Sélectionnez une carte associée pour modifier la paire.',status:(n,total)=>`${n} paire(s) sur ${total} associée(s).`,select:'Sélectionnez une carte de chaque colonne.',complete:'Toutes les cartes sont associées. Vous pouvez valider.',left:'Carte de gauche',right:'Carte de droite',face:'visible',hidden:'retournée',linked:'associée'},
    uk: {instruction:'Відкрийте по одній картці з кожного стовпця та з’єднайте пари. Правильність перевіряється після надсилання.',pair:'З’єднати картки',reset:'Почати знову',help:'Натисніть на з’єднану картку, щоб змінити пару.',status:(n,total)=>`З’єднано ${n} з ${total} пар.`,select:'Виберіть по одній картці з кожного стовпця.',complete:'Усі пари з’єднано. Можна надсилати.',left:'Ліва картка',right:'Права картка',face:'відкрита',hidden:'закрита',linked:'з’єднана'},
    ar: {instruction:'اكشف بطاقة من كل عمود ثم اربط البطاقتين. سيتم تصحيح الإجابات بعد الإرسال فقط.',pair:'ربط البطاقتين',reset:'البدء من جديد',help:'اختر بطاقة مرتبطة لتغيير الربط.',status:(n,total)=>`تم ربط ${n} من ${total} أزواج.`,select:'اختر بطاقة من كل عمود.',complete:'تم ربط جميع الأزواج. يمكنك الإرسال.',left:'البطاقة اليسرى',right:'البطاقة اليمنى',face:'مكشوفة',hidden:'مخفية',linked:'مرتبطة'},
    ckb: {instruction:'لە هەر ستوونێک کارتەیەک بکەرەوە و پێکەوەیان ببەستە. وەڵامەکان تەنها دوای ناردن پشکنین دەکرێن.',pair:'کارتەکان ببەستەوە',reset:'لەسەرەتاوە دەست پێ بکە',help:'بۆ گۆڕینی جووتێک، کرتە لەسەر کارتەی بەستراو بکە.',status:(n,total)=>`${n} لە ${total} جووت بەستراوە.`,select:'لە هەر ستوونێک کارتەیەک هەڵبژێرە.',complete:'هەموو جووتەکان بەسترانەوە. دەتوانیت وەڵام بنێریت.',left:'کارتەی چەپ',right:'کارتەی ڕاست',face:'کراوەتەوە',hidden:'داخراوە',linked:'بەستراوە'},
    kmr: {instruction:'ژ هەر ستوونەکێ کارتەکێ ڤەکە و هەڤبەش بکە. وەڵام پشتی هنارتنێ دهێن پشکنین.',pair:'کارتان گرێبدە',reset:'ژ نووە دەست پێ بکە',help:'بۆ گوهۆڕینا جووتەکێ، کارتێ گرێدای کرتە بکە.',status:(n,total)=>`${n} ژ ${total} جووت هاتنە گرێدان.`,select:'ژ هەر ستوونەکێ کارتێ هەلبژێرە.',complete:'هەمی جووت هاتنە گرێدان. دەتوانی بهنێری.',left:'کارتی چەپ',right:'کارتی راست',face:'ڤەکری',hidden:'نەڤەکری',linked:'گرێدای'},
    ku: {instruction:'Ji her stûnê kartekê vekin û hevdu bikin. Bersiv tenê piştî şandinê tê kontrolkirin.',pair:'Kartan girê bide',reset:'Ji nû ve dest pê bike',help:'Ji bo guhertina cotekê, li karta girêdayî bitikîne.',status:(n,total)=>`${n} ji ${total} cot hatin girêdan.`,select:'Ji her stûnê kartekê hilbijêre.',complete:'Hemû cot hatin girêdan. Tu dikarî bişînî.',left:'Karta çepê',right:'Karta rastê',face:'vekirî',hidden:'veşartî',linked:'girêdayî'}
  };
  document.querySelectorAll('[data-v81-memory]').forEach(root => {
    const copy=memoryCopy[root.dataset.v81Locale] || memoryCopy.en;
    const left=[...root.querySelectorAll('[data-v81-memory-left]')];
    const right=[...root.querySelectorAll('[data-v81-memory-right]')];
    const hidden=root.querySelector('[data-v58-answer]');
    const pair=root.querySelector('[data-v81-memory-pair]');
    const reset=root.querySelector('[data-v81-memory-reset]');
    const status=root.querySelector('[data-v81-memory-status]');
    if (!hidden || !pair || !reset || !status || !left.length || left.length !== right.length) return;
    const completed=Array(left.length).fill(null); // left index -> right shuffled index
    let selectedLeft=null,selectedRight=null;
    const blocked=()=>root.closest('form')?.classList.contains('has-feedback') || root.closest('form')?.dataset.v81Locked==='true';
    root.querySelector('[data-v81-memory-instruction]').textContent=copy.instruction;
    root.querySelector('[data-v81-memory-help]').textContent=copy.help;
    pair.textContent=copy.pair;reset.textContent=copy.reset;
    root.querySelector('[data-v81-memory-left-column]')?.setAttribute('aria-label',copy.left);
    root.querySelector('[data-v81-memory-right-column]')?.setAttribute('aria-label',copy.right);
    const update=()=>{
      const linked=new Set(completed.filter(value=>value!==null));
      left.forEach((button,i)=>{
        const paired=completed[i]!==null,active=selectedLeft===i;
        const show=paired || active;
        button.querySelector('.v81-memory-card-face').textContent=show?button.dataset.v81MemoryWord:'?';
        button.classList.toggle('is-linked',paired);
        button.classList.toggle('is-selected',active);
        button.setAttribute('aria-pressed',String(active));
        button.setAttribute('aria-label',`${copy.left} ${i+1}: ${show?button.dataset.v81MemoryWord:copy.hidden}. ${paired?copy.linked:''}`);
        const marker=button.querySelector('.v81-memory-card-index');marker.textContent=paired ? `✓ ${i+1}` : String(i+1);
      });
      right.forEach((button,i)=>{
        const paired=linked.has(i),active=selectedRight===i;
        const show=paired || active;
        button.querySelector('.v81-memory-card-face').textContent=show?button.dataset.v81MemoryWord:'?';
        button.classList.toggle('is-linked',paired);
        button.classList.toggle('is-selected',active);
        button.setAttribute('aria-pressed',String(active));
        button.setAttribute('aria-label',`${copy.right} ${i+1}: ${show?button.dataset.v81MemoryWord:copy.hidden}. ${paired?copy.linked:''}`);
        button.querySelector('.v81-memory-card-index').textContent=paired ? '✓' : String(i+1);
      });
      const total=completed.filter(value=>value!==null).length;
      hidden.value=total===left.length?JSON.stringify(completed):'';
      pair.disabled=blocked() || selectedLeft===null || selectedRight===null;
      const message=total===left.length?copy.complete:(selectedLeft!==null || selectedRight!==null?copy.select:copy.status(total,left.length));
      status.textContent=message;
    };
    const remove=(side,index)=>{
      if(side==='left' && completed[index]!==null){completed[index]=null;selectedLeft=null;selectedRight=null;return true;}
      if(side==='right'){
        const other=completed.indexOf(index);
        if(other!==-1){completed[other]=null;selectedLeft=null;selectedRight=null;return true;}
      }
      return false;
    };
    for(const [side,buttons] of [['left',left],['right',right]]){
      buttons.forEach((button,i)=>button.addEventListener('click',()=>{
        if(blocked())return;
        if(remove(side,i)){update();return;}
        if(side==='left') selectedLeft=selectedLeft===i?null:i;
        else selectedRight=selectedRight===i?null:i;
        update();
      }));
    }
    pair.addEventListener('click',()=>{
      if(blocked() || selectedLeft===null || selectedRight===null || completed[selectedLeft]!==null || completed.includes(selectedRight))return;
      completed[selectedLeft]=selectedRight;
      selectedLeft=null;selectedRight=null;update();
    });
    reset.addEventListener('click',()=>{
      if(blocked())return;
      completed.fill(null);selectedLeft=null;selectedRight=null;update();
    });
    update();
  });
  const listenCopy = {
    nl: {label:'Luister naar de opname',aria:'Speel de goedgekeurde geluidsopname af',playing:'Opname speelt…',done:'Opname afgelopen.',error:'Goedgekeurde opname niet beschikbaar. Vraag je leerkracht of beheerder.'},
    en: {label:'Listen to recording',aria:'Play approved listening recording',playing:'Playing…',done:'Finished.',error:'Approved audio unavailable. Ask your teacher or Manager.'},
    de: {label:'Aufnahme anhören',aria:'Freigegebene Hörübung abspielen',playing:'Aufnahme läuft…',done:'Aufnahme beendet.',error:'Freigegebene Aufnahme nicht verfügbar. Frage deine Lehrkraft.'},
    fr: {label:'Écouter l’enregistrement',aria:'Lire l’enregistrement validé',playing:'Lecture en cours…',done:'Lecture terminée.',error:'Enregistrement indisponible. Demandez à votre enseignant.'},
    uk: {label:'Прослухати запис',aria:'Відтворити затверджений аудіозапис',playing:'Відтворення…',done:'Завершено.',error:'Аудіозапис недоступний. Зверніться до викладача.'},
    ar: {label:'استمع إلى التسجيل',aria:'تشغيل التسجيل الصوتي المعتمد',playing:'جارٍ التشغيل…',done:'انتهى التشغيل.',error:'التسجيل المعتمد غير متاح. اسأل معلمك.'},
    ckb: {label:'گوێ لە تۆمارەکە بگرە',aria:'لێدانی دەنگی پەسەندکراو',playing:'دەنگەکە لێدەدرێت…',done:'دەنگەکە تەواو بوو.',error:'دەنگی پەسەندکراو بەردەست نییە. پرسیار لە مامۆستا بکە.'},
    kmr: {label:'گوهداری تۆمارێ بکە',aria:'لێدانا دەنگێ پەسەندکری',playing:'دەنگ دهێتە لێدان…',done:'دەنگ تەمام بوو.',error:'دەنگێ پەسەندکری بەردەست نینە. ژ مامۆستایێ خۆ بپرسە.'},
    ku: {label:'Guhdarî tomarkirinê bike',aria:'Tomarkirina dengê pejirandî bilîze',playing:'Deng tê lîstin…',done:'Deng qediya.',error:'Tomarkirina pejirandî tune ye. Ji mamosteyê xwe bipirse.'}
  };
  document.querySelectorAll('[data-rozh-audio-src].v58-speak').forEach(button => {
    const root=button.closest('.v58-listen');
    const status=root?.querySelector('[data-v58-speech-status]');
    const locale=button.closest('[data-v58-activity]')?.dataset.v58UiLang;
    const copy=listenCopy[locale] || listenCopy.en;
    const label=button.querySelector('[data-v58-listen-label]');
    if (label) label.textContent=copy.label;
    button.setAttribute('aria-label',copy.aria);
    button.addEventListener('click', () => {
      if (window.RozhAudioV78?.play(button, {
        onStart: () => { if (status) status.textContent=copy.playing; },
        onEnd: () => { if (status) status.textContent=copy.done; },
        onError: () => { if (status) status.textContent=copy.error; }
      })) return;
      if (status) status.textContent=copy.error;
    });
  });
})();

/* Original Atlas V21: connect actual Django-rendered checkpoints with a decorative
   route. It cannot unlock lessons or write user state. */
(() => {
  'use strict';
  const NS = 'http://www.w3.org/2000/svg';
  const make = (tag, attrs) => {
    const node = document.createElementNS(NS, tag);
    Object.entries(attrs || {}).forEach(([name, value]) => node.setAttribute(name, String(value)));
    return node;
  };
  function initJourney(route) {
    let wire = null;
    const stops = [...route.querySelectorAll('.lm20-stop-connector')];
    if (stops.length < 2) return;
    function render() {
      if (window.matchMedia('(max-width:760px)').matches && !route.closest('.lm24-voyage')) {
        if (wire) wire.hidden = true;
        return;
      }
      if (!wire) {
        wire = make('svg', {'class':'lm21-route-wire','aria-hidden':'true',focusable:'false','preserveAspectRatio':'none'});
        route.insertBefore(wire,route.firstChild);
      }
      wire.hidden = false;
      const bounds = route.getBoundingClientRect();
      const width = route.clientWidth, height = route.scrollHeight;
      if (!width || !height) return;
      wire.setAttribute('viewBox', `0 0 ${width} ${height}`);
      const points = stops.map(stop => {
        const r = stop.getBoundingClientRect();
        return {x:r.left+r.width/2-bounds.left,y:r.top+r.height/2-bounds.top};
      });
      const d = points.slice(1).reduce((path,p,i) => {
        const from = points[i];
        const midY = (p.y+from.y)/2;
        return `${path} C ${from.x} ${midY}, ${p.x} ${midY}, ${p.x} ${p.y}`;
      },`M ${points[0].x} ${points[0].y}`);
      wire.replaceChildren(make('path',{d,'class':'lm21-wire-under'}),make('path',{d,'class':'lm21-wire-main'}));
    }
    let scheduled = false;
    const update = () => {
      if (scheduled) return;
      scheduled = true;
      requestAnimationFrame(() => {scheduled=false;render();});
    };
    const observer = 'ResizeObserver' in window ? new ResizeObserver(update) : null;
    if (observer) {
      observer.observe(route);
      stops.forEach(stop => observer.observe(stop));
    }
    window.addEventListener('resize',update,{passive:true});
    route.addEventListener('toggle',update,true);
    update();
  }
  // Match the V21 laptop breakpoint; the older V20 script only knows 1280px.
  const rail = document.querySelector('.lm20-rail-drawer');
  if (rail && window.matchMedia('(min-width: 1151px)').matches) rail.open = true;
  document.querySelectorAll('.lm20-route').forEach(initJourney);
})();

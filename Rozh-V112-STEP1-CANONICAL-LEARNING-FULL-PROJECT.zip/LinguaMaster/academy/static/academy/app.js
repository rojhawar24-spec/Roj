/* Minimal progressive enhancement: first-party only, no analytics or trackers. */
(() => {
  'use strict';
  // Appearance is managed by pwa-v9.js; theme-bootstrap.js applies it before paint.
  document.querySelectorAll('.speak-button').forEach(button => {
    button.addEventListener('click', () => {
      // School-quality audio: only the approved, hashed local recording.
      if (window.RozhAudioV78?.play(button)) return;
      // Never silently play an unreviewed or device-dependent voice.
      button.disabled = true;
      button.title = 'Approved recording unavailable';
    });
  });
  document.querySelectorAll('form[data-confirm]').forEach(form => {
    form.addEventListener('submit', event => {
      if (!window.confirm(form.dataset.confirm)) event.preventDefault();
    });
  });
})();

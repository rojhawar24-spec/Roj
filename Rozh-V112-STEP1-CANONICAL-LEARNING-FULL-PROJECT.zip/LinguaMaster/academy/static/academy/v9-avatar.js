(() => {
  'use strict';
  const editor = document.getElementById('avatar-editor');
  const preview = document.getElementById('avatar-preview');
  const emoji = document.getElementById('avatar-preview-emoji');
  if (!editor || !preview || !emoji) return;
  editor.addEventListener('change', () => {
    const values = new FormData(editor);
    const palette = values.get('palette');
    const accessory = values.get('accessory');
    emoji.textContent = values.get('avatar') || emoji.textContent;
    for (const name of Array.from(preview.classList)) {
      if (name.startsWith('avatar-palette-') || name.startsWith('avatar-accessory-')) preview.classList.remove(name);
    }
    if (['sky', 'lavender', 'sand', 'forest'].includes(palette)) preview.classList.add(`avatar-palette-${palette}`);
    if (['none', 'star', 'confetti'].includes(accessory)) preview.classList.add(`avatar-accessory-${accessory}`);
  });
})();

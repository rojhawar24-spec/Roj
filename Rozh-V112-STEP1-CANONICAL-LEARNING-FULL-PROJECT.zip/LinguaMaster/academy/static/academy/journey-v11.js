/* One question per screen, server-owned answer keys, explicit feedback. */
(() => {
  'use strict';
  const root = document.querySelector('[data-journey-player]');
  if (!root) return;
  const form = document.getElementById('j11-form');
  const lang = root.dataset.language || 'nl';
  root.querySelectorAll('[data-play-speech]').forEach(button => {
    button.addEventListener('click', () => {
      const warning = root.querySelector('[data-journey-error]');
      const audioError = () => {
        if (warning) { warning.textContent = root.dataset.labelAudioUnavailable; warning.hidden = false; }
      };
      if (window.RozhAudioV78?.play(button, {
          slow: button.dataset.speed === 'slow',
          onStart: () => { if (warning) warning.hidden = true; },
          onError: audioError
      })) return;
      audioError(); // Never fallback to unknown browser voice for a graded school task.
    });
  });
  if (!form) return;
  let isPending = false;
  let answerChecked = false;
  const status = form.querySelector('[data-journey-error]');
  const check = form.querySelector('[data-journey-check]');
  const next = form.querySelector('[data-journey-next]');
  const feedback = form.querySelector('[data-journey-feedback]');
  const headline = form.querySelector('[data-journey-feedback-title]');
  const explanation = form.querySelector('[data-journey-feedback-text]');
  const tokens = Array.from(form.querySelectorAll('[data-token]'));
  const selected = [];
  const answerField = form.querySelector('#j11-word-answer');
  const assembled = form.querySelector('[data-assembled]');
  const renderWords = () => {
    if (!answerField || !assembled) return;
    const values = selected.map(id => tokens.find(node => node.dataset.token === id)?.dataset.value || '');
    answerField.value = values.join(' ');
    assembled.replaceChildren();
    values.forEach(value => {
      const span = document.createElement('span');
      span.textContent = value;
      assembled.appendChild(span);
    });
    tokens.forEach(node => { node.disabled = selected.includes(node.dataset.token); });
  };
  tokens.forEach(token => token.addEventListener('click', () => {
    if (isPending || answerChecked) return;
    selected.push(token.dataset.token);
    renderWords();
  }));
  form.querySelector('[data-undo-word]')?.addEventListener('click', () => {
    if (isPending || answerChecked) return;
    selected.pop();
    renderWords();
  });
  // A learner can also type instead of using the word tiles (keyboard / no JavaScript).
  answerField?.addEventListener('input', () => {
    if (isPending || answerChecked) return;
    if (!selected.length) return;
    selected.length = 0;
    assembled.replaceChildren();
    tokens.forEach(node => { node.disabled = false; });
  });
  const showError = text => { status.textContent = text; status.hidden = !text; };
  next?.addEventListener('click', () => { window.location.assign(form.dataset.nextUrl); });
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (isPending || answerChecked) return;
    const checked = form.querySelector('input[type="radio"]:checked');
    const answer = checked?.value || form.querySelector('[name="answer"]')?.value || '';
    const confirm = form.querySelector('[data-self-confirm]');
    const draft = form.querySelector('[data-self-writing]');
    if (!answer.trim() || (confirm && !confirm.checked) || (draft && draft.value.trim().length < 10)) {
      showError(root.dataset.labelRequired); return;
    }
    showError('');
    isPending = true;
    check.disabled = true;
    // Serialize before disabling: disabled controls are excluded from FormData.
    const request = new FormData(form);
    request.set('answer', answer);
    const controls = Array.from(form.querySelectorAll('input:not([type="hidden"]), select, textarea, button[type="button"]'))
      .filter(node => node !== next && !node.matches('[data-play-speech], [data-rozh-audio-src]'));
    const oldDisabled = controls.map(node => node.disabled);
    controls.forEach(node => { node.disabled = true; });
    try {
      const response = await fetch(form.action, {
        method:'POST', body:request, credentials:'same-origin',
        headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest'}
      });
      if (response.redirected && new URL(response.url).pathname === '/login/') {
        window.location.assign('/login/?next=' + encodeURIComponent(window.location.pathname));return;
      }
      if (!(response.headers.get('content-type') || '').includes('application/json')) {
        throw new Error(root.dataset.labelError);
      }
      const data = await response.json();
      if (data.hearts && Number.isInteger(data.hearts.remaining)) {
        root.querySelectorAll('[data-journey-hearts]').forEach(node => {
          node.textContent = data.hearts.remaining;
          node.closest('a')?.setAttribute('aria-label', `${root.dataset.labelHeartsCount} ${data.hearts.remaining}`);
        });
      }
      if (!response.ok) {
        if (response.status === 402 && data.error_code === 'hearts_empty') {
          const recovery = root.querySelector('[data-v72-heart-recover]');
          if (recovery) { recovery.hidden = false; recovery.focus({preventScroll:true}); }
        }
        throw new Error(data.error || root.dataset.labelError);
      }
      answerChecked = true;
      form.classList.add('has-feedback');
      check.hidden = true;
      next.hidden = false;
      feedback.hidden = false;
      feedback.classList.toggle('is-wrong', data.correct === false);
      const nl = document.documentElement.lang?.startsWith('nl');
      const ckb = document.documentElement.lang?.startsWith('ckb');
      const ar = document.documentElement.lang?.startsWith('ar');
      const good = ckb ? 'زۆر باشە!' : ar ? 'أحسنت!' : nl ? 'Goed gedaan!' : 'Well done!';
      const wrong = ckb ? 'هێشتا تەواو نییە' : ar ? 'ليس تماماً' : nl ? 'Nog niet helemaal' : 'Not quite yet';
      headline.textContent = data.ungraded ? '✓' : data.correct ? (root.dataset.labelCorrect || good) : (root.dataset.labelIncorrect || wrong);
      const solution = form.querySelector('[data-journey-solution]');
      const value = form.querySelector('[data-journey-solution-value]');
      if (solution && value) {
        const text = data.correct === false && typeof data.solution === 'string' ? data.solution : '';
        value.textContent = text;
        solution.hidden = !text;
      }
      explanation.textContent = data.explanation || (data.ungraded ? '' : data.correct ? '✓' : '');
      next.textContent = data.finished ? (root.dataset.labelResult + ' →') : next.textContent;
      next.focus({preventScroll:true});
      const noMotion = document.documentElement.dataset.reduceMotion === 'true' ||
        document.documentElement.dataset.accountReduceMotion === 'true' ||
        (typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
      feedback.scrollIntoView({block:'nearest',behavior:noMotion ? 'auto' : 'smooth'});
    } catch (error) { showError(error.message || root.dataset.labelError); }
    finally {
      if (!answerChecked) controls.forEach((node, index) => { node.disabled = oldDisabled[index]; });
      isPending = false; check.disabled = answerChecked;
    }
  });
})();

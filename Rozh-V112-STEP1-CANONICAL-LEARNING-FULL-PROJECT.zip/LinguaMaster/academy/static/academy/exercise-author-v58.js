/* Manager-only documentation of the 13 genuinely supported formats. Never auto-save. */
(() => {
  'use strict';
  const root = document.querySelector('[data-v58-author]');
  if (!root) return;
  const kind = document.getElementById('id_kind');
  const example = root.querySelector('[data-v58-author-example]');
  if (!kind || !example) return;
  const examples = {
    mcq:'Options = ["Yes", "No"]\nAnswer = Yes\nActivity data = {}',
    short:'Options = []\nAnswer = one short correct answer\nActivity data = {}',
    sentence_builder:'Options = ["She", "is", "happy."]\nAnswer = She is happy.\nActivity data = {}',
    picture_match:'Options = ["books", "forest", "train"]\nAnswer = books\nActivity data = {"image":"academy/photos/books.jpg","image_alt":"A stack of books on a table"}',
    fill_blank:'Prompt = She ___ happy.\nOptions = []\nAnswer = is\nActivity data = {}',
    word_matching:'Options = []\nAnswer = (leave empty)\nActivity data = {"pairs":[{"left":"apple","right":"fruit"},{"left":"chair","right":"furniture"}]}',
    listening:'Options = ["I am happy.", "I are happy."]\nAnswer = I am happy.\nActivity data = {"audio_text":"I am happy."}',
    true_false:'Options = []\nAnswer = True OR False\nActivity data = {}',
    spelling:'Options = []\nAnswer = beautiful\nActivity data = {}',
    word_order:'Options = ["Where", "are", "you?"]\nAnswer = Where are you?\nActivity data = {}',
    find_mistake:'Options = ["She", "are", "happy."]\nAnswer = are\nActivity data = {}',
    memory_match:'Options = []\nAnswer = (leave empty)\nActivity data = {"pairs":[{"left":"dog","right":"animal"},{"left":"red","right":"colour"}]}',
    choose_image:'Options = []\nAnswer = train\nActivity data = {"images":[{"label":"train","path":"academy/photos/train.jpg"},{"label":"books","path":"academy/photos/books.jpg"}]}',
    complete_conversation:'Options = ["My name is Sara.", "I live at home."]\nAnswer = My name is Sara.\nActivity data = {"dialogue":["Hello!", "What is your name?"]}',
  };
  function update() {
    example.textContent = (examples[kind.value] || 'Choose a supported type.') + '\n\nThese are EDITOR EXAMPLES. Write and verify your own course content before saving.';
  }
  kind.addEventListener('change', update);
  update();
})();

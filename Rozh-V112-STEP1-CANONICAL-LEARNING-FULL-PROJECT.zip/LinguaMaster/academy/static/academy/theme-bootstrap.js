/* Render the saved appearance before CSS loads. First-party, CSP-compatible.
   V66: also respond to system changes and keep browser chrome theme coherent. */
(() => {
  'use strict';
  const root = document.documentElement;
  const valid = value => ['light', 'dark', 'system'].includes(value);
  let preference = 'system';
  try { preference = localStorage.getItem('linguamaster-theme') || 'system'; } catch (_) {}
  // Server account setting takes precedence over a stale device setting.
  const accountTheme = root.dataset.accountTheme;
  if (valid(accountTheme)) preference = accountTheme;
  if (!valid(preference)) preference = 'system';
  const system = typeof matchMedia === 'function' ? matchMedia('(prefers-color-scheme: dark)') : null;
  const resolve = () => preference === 'system' ? (system?.matches ? 'dark' : 'light') : preference;
  root.dataset.theme = resolve();
  root.dataset.themePreference = preference;
  if (root.dataset.accountReduceMotion === 'true') root.dataset.reduceMotion = 'true';
  // The meta tag exists before this script in all four independent page shells.
  function paintBrowserChrome() {
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', root.dataset.theme === 'dark' ? '#111f2b' : '#f5f8f7');
  }
  paintBrowserChrome();
  // The authenticated switcher changes data-theme after a successful POST; the
  // observer updates only browser-chrome metadata, never the saved preference.
  if (typeof MutationObserver !== 'undefined') {
    new MutationObserver(paintBrowserChrome).observe(root,{attributes:true,attributeFilter:['data-theme']});
  }
  function systemChanged() {
    if (root.dataset.themePreference === 'system') root.dataset.theme = resolve();
  }
  if (system?.addEventListener) system.addEventListener('change',systemChanged);
  else if (system?.addListener) system.addListener(systemChanged);
})();

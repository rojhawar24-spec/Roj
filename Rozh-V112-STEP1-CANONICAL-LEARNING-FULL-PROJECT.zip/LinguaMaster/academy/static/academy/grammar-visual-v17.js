/* Rozh V17: optional, local, keyboard-accessible practice; no fetch, no XP, no audio. */
(() => {
 'use strict';
 const normalized = (value) => String(value ?? '').trim().normalize('NFC').toLocaleLowerCase();
 function feedback(el, ok, empty=false) {
   const status = el.querySelector('.g17-feedback'); if (!status) return;
   status.textContent = empty ? '' : ok ? el.dataset.right : el.dataset.wrong;
   if (empty) status.removeAttribute('data-status');
   else status.dataset.status = ok ? 'correct' : 'incorrect';
 }
 document.querySelectorAll('.g17-practice[data-g17-mode="fill"],.g17-practice[data-g17-mode="choice"]').forEach((form)=>{
   form.querySelector('button[type=submit]')?.removeAttribute('disabled');
   form.addEventListener('submit', (event)=>{
     event.preventDefault();
     let value='';
     if (form.dataset.g17Mode==='fill') value=form.querySelector('input[type="text"]')?.value ?? '';
     else value=form.querySelector('input[type="radio"]:checked')?.value ?? '';
     feedback(form, Boolean(value.trim()) && normalized(value)===normalized(form.dataset.answer));
   });
 });
 document.querySelectorAll('.g17-builder[data-g17-mode="builder"]').forEach((panel)=>{
   const options=[...panel.querySelectorAll('.g17-word')];
   const target=panel.querySelector('.g17-build-target');
   const chosen=[];
   // Mix the visible choices, retaining stable source indexes for validation.
   const mixed=[...options];
   for(let i=mixed.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[mixed[i],mixed[j]]=[mixed[j],mixed[i]];}
   for(const button of mixed)panel.querySelector('.g17-build-options').append(button);
   function paint(){
     target.replaceChildren();
     for (const index of chosen){
       const node=document.createElement('span');node.className='g17-chosen-word';
       node.textContent=options[index].dataset.word;target.append(node);
     }
     options.forEach((button,i)=>{button.disabled=chosen.includes(i);});
     feedback(panel,false,true);
   }
   options.forEach((button,i)=>button.addEventListener('click',()=>{if(!chosen.includes(i)){chosen.push(i);paint();}}));
   panel.querySelector('.g17-remove')?.addEventListener('click',()=>{chosen.pop();paint();});
   panel.querySelector('.g17-reset')?.addEventListener('click',()=>{chosen.length=0;paint();});
   panel.querySelector('.g17-check')?.addEventListener('click',()=>{
     const okay=chosen.length===options.length && chosen.every((index,j)=>index===j);
     feedback(panel,okay);
   });
   paint();
 });
})();

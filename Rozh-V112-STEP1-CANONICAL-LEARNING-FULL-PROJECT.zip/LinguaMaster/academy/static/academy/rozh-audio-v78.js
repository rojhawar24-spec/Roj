/* Rozh V78: approved static audio first; never calls paid or remote TTS APIs. */
(() => {
  'use strict';
  let active = null;
  const stop = () => {
    if (!active) return;
    try { active.pause(); active.currentTime = 0; active.src = ''; active.load(); } catch (_) { /* ignore */ }
    active = null;
  };
  window.RozhAudioV78 = Object.freeze({
    stop,
    play(button, options = {}) {
      // Absence of an approved clip explicitly permits existing browser-TTS fallback.
      const src = button?.dataset?.rozhAudioSrc || '';
      if (!src || !src.startsWith('/')) return false;
      stop();
      const audio = new Audio(src);
      active = audio;
      audio.preload = 'none';
      audio.playbackRate = options.slow ? 0.82 : 1.0;
      audio.preservesPitch = true;
      audio.addEventListener('playing', () => {
        if (active === audio) options.onStart?.();
      }, { once:true });
      audio.addEventListener('ended', () => {
        if (active === audio) { active = null; options.onEnd?.(); }
      }, { once:true });
      const fail = () => {
        if (active === audio) { stop(); options.onError?.(); }
      };
      audio.addEventListener('error', fail, { once:true });
      try { Promise.resolve(audio.play()).catch(fail); } catch (_) { fail(); }
      return true;
    },
  });
  window.addEventListener('pagehide', stop);
})();

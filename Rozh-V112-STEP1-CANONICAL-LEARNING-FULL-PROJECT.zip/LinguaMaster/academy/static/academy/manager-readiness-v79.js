(() => { 'use strict';
const input=document.querySelector('[data-v79-filter]');if(!input)return;
const groups=[...document.querySelectorAll('.v79-group')];
input.addEventListener('input',()=>{const needle=input.value.trim().toLocaleLowerCase();
  groups.forEach(group=>{let seen=0;group.querySelectorAll('[data-v79-component]').forEach(item=>{
    const match=item.dataset.v79Component.toLocaleLowerCase().includes(needle);
    item.hidden=!match;if(match)seen++;});group.hidden=!seen;if(needle&&seen)group.open=true;});});
})();

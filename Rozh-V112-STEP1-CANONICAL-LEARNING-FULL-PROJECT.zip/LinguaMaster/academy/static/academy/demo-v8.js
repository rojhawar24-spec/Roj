/* Progressive-enhanced demo; no tracking, no account changes, no XP endpoints. */
(() => {
  'use strict';
  const root = document.getElementById('lm-demo');
  if (!root) return;
  const engine = window.LinguaMasterDemoEngine;
  if (!engine) { root.dataset.error = 'engine-not-loaded'; return; }
  const $ = id => document.getElementById(id);
  const copy = {
    en:{exit:'Exit demo',starter:'DUTCH · A0 STARTER MISSION',headline:'Your first five Dutch words and phrases!',intro:'No account needed. Learn by trying, with helpful hints along the way.',begin:'Start my mission',listen:'Play Dutch audio',showTranscript:'Show transcript',hideTranscript:'Hide transcript',noAudio:'Speech unavailable. Use the transcript instead.',check:'Check answer',next:'Continue',tryAgain:'Almost! Try once more.',correct:'Nice! You got it.',notQuite:'Good effort. Here is the right idea.',empty:'Choose or write an answer first.',progress:'Your first mission',complete:'MISSION COMPLETE',finishTitle:'You did it!',finishCopy:'Your first steps in Dutch are underway. Keep going!',firstTry:'Correct on the first try',honesty:'This is a practice demo, not a CEFR exam. Demo answers and XP are not saved.',saveProgress:'Create an account to save real learning progress',replay:'Play this mission again',asideTitle:'Learn Dutch for real life',asideCopy:'Say hello, introduce yourself and answer a café conversation.',skill1:'Write a phrase',skill2:'Listen with a transcript',skill3:'Build a sentence',privacy:'No signup, tracking or account data is needed for this demo.',kindChoice:'Choose the answer',kindOrder:'Build the sentence',kindText:'Write in Dutch',inputLabel:'Your Dutch answer',inputPlace:'Type your answer...',answerArea:'Tap words to build a sentence',available:'Available words',selected:'Your sentence',removeWord:'Remove word',transcript:'Transcript'},
    nl:{exit:'Demo verlaten',starter:'NEDERLANDS · A0 STARTMISSIE',headline:'Je eerste vijf Nederlandse woorden en zinnen!',intro:'Geen account nodig. Probeer het en krijg handige tips.',begin:'Start mijn missie',listen:'Nederlandse zin afspelen',showTranscript:'Transcript tonen',hideTranscript:'Transcript verbergen',noAudio:'Audio niet beschikbaar. Lees het transcript.',check:'Antwoord controleren',next:'Verder',tryAgain:'Bijna! Probeer het opnieuw.',correct:'Goed gedaan!',notQuite:'Goed geprobeerd. Dit is het juiste antwoord.',empty:'Kies of schrijf eerst een antwoord.',progress:'Je eerste missie',complete:'MISSIE VOLTOOID',finishTitle:'Je hebt het gedaan!',finishCopy:'Je hebt de eerste stap gezet. Ga verder!',firstTry:'In één keer goed',honesty:'Dit is een demo, geen CEFR-examen. Antwoorden en XP worden niet bewaard.',saveProgress:'Maak een account om je echte leerprogressie te bewaren',replay:'Missie opnieuw spelen',asideTitle:'Leer Nederlands voor het echte leven',asideCopy:'Begroet iemand, stel jezelf voor en reageer in een café.',skill1:'Schrijf een zin',skill2:'Luister met transcript',skill3:'Maak een zin',privacy:'Geen account, tracking of persoonsgegevens nodig voor deze demo.',kindChoice:'Kies het antwoord',kindOrder:'Maak de zin',kindText:'Schrijf in het Nederlands',inputLabel:'Jouw antwoord',inputPlace:'Typ je antwoord...',answerArea:'Tik op woorden om een zin te maken',available:'Beschikbare woorden',selected:'Jouw zin',removeWord:'Verwijder woord',transcript:'Transcript'},
    ckb:{exit:'دەرچوون لە تاقیکردنەوە',starter:'هۆڵەندی · A0 یەکەم ئەرک',headline:'یەکەم پێنج وشە و ڕستەی هۆڵەندی فێربە!',intro:'پێویست بە هەژمار نییە. تاقی بکەرەوە و ڕێنمایی وەربگرە.',begin:'دەستپێکردنی ئەرک',listen:'گوێ لە هۆڵەندی بگرە',showTranscript:'نیشاندانی دەق',hideTranscript:'شاردنەوەی دەق',noAudio:'دەنگ بەردەست نییە. دەقەکە بخوێنەرەوە.',check:'پشکنینی وەڵام',next:'بەردەوامبە',tryAgain:'نزیک بوویت! جارێکی تر هەوڵ بدە.',correct:'زۆر باش!',notQuite:'هەوڵێکی باش بوو. ئەمە وەڵامی دروستە.',empty:'سەرەتا وەڵامێک هەڵبژێرە یان بنووسە.',progress:'یەکەم ئەرکت',complete:'ئەرک تەواو بوو',finishTitle:'سەرکەوتووبوویت!',finishCopy:'یەکەم هەنگاوت لە هۆڵەندی نا. بەردەوامبە!',firstTry:'لە یەکەم هەوڵدا دروست',honesty:'ئەمە تاقیکردنەوەی فێربوونە، نەک تاقیکردنەوەی فەرمی CEFR. XP پاشەکەوت ناکرێت.',saveProgress:'هەژمار دروست بکە بۆ پاشەکەوتکردنی پێشکەوتنی ڕاستەقینە',replay:'دووبارە یاری بکە',asideTitle:'هۆڵەندی بۆ ژیانی ڕۆژانە',asideCopy:'سڵاو بکە، خۆت بناسێنە و لە قاوەخانەدا وەڵام بدەرەوە.',skill1:'ڕستەیەک بنووسە',skill2:'گوێ بگرە و دەق بخوێنە',skill3:'ڕستەیەک دروست بکە',privacy:'بۆ ئەم تاقیکردنەوەیە هەژمار یان زانیاریی تایبەتی پێویست نییە.',kindChoice:'وەڵام هەڵبژێرە',kindOrder:'ڕستە دروست بکە',kindText:'بە هۆڵەندی بنووسە',inputLabel:'وەڵامەکەت',inputPlace:'وەڵام بنووسە...',answerArea:'بۆ دروستکردنی ڕستە وشەکان دابگرە',available:'وشەکان',selected:'ڕستەکەت',removeWord:'سڕینەوەی وشە',transcript:'دەقی دەنگ'},
    ar:{exit:'مغادرة التجربة',starter:'الهولندية · مهمة البداية A0',headline:'تعلّم أول خمس كلمات وعبارات هولندية!',intro:'لا تحتاج إلى حساب. جرّب واحصل على تلميحات مفيدة.',begin:'ابدأ المهمة',listen:'استمع إلى الهولندية',showTranscript:'عرض النص',hideTranscript:'إخفاء النص',noAudio:'الصوت غير متاح. استخدم النص بدلاً منه.',check:'تحقق من الإجابة',next:'متابعة',tryAgain:'اقتربت! حاول مرة أخرى.',correct:'أحسنت!',notQuite:'محاولة جيدة. هذه هي الإجابة الصحيحة.',empty:'اختر إجابة أو اكتبها أولاً.',progress:'مهمتك الأولى',complete:'اكتملت المهمة',finishTitle:'لقد نجحت!',finishCopy:'هذه خطوتك الأولى في تعلم الهولندية. تابع!',firstTry:'صحيح من المحاولة الأولى',honesty:'هذه تجربة تدريبية وليست اختبار CEFR رسمياً. لا نحفظ الإجابات أو نقاط XP.',saveProgress:'أنشئ حساباً لحفظ تقدمك الحقيقي',replay:'أعد هذه المهمة',asideTitle:'تعلم الهولندية للحياة اليومية',asideCopy:'سلّم على الآخرين، عرّف بنفسك وتحدث في المقهى.',skill1:'اكتب عبارة',skill2:'استمع واقرأ النص',skill3:'كوّن جملة',privacy:'لا تحتاج هذه التجربة إلى حساب أو تتبع أو بيانات شخصية.',kindChoice:'اختر الإجابة',kindOrder:'كوّن الجملة',kindText:'اكتب بالهولندية',inputLabel:'إجابتك الهولندية',inputPlace:'اكتب إجابتك...',answerArea:'اضغط الكلمات لتكوين الجملة',available:'الكلمات المتاحة',selected:'جملتك',removeWord:'إزالة الكلمة',transcript:'النص'}
  };
  const questions=engine.questions;
  let locale = engine.locales.includes(root.dataset.locale) ? root.dataset.locale : 'en';
  let started = false, current = 0, selected = '', ordered = [], attempts = 0, firstTry = 0, locked = false, finished = false, feedbackMode = '';
  const tr = key => copy[locale][key] || copy.en[key] || key;
  const pick = value => engine.phrase(value,locale);
  const lang = $('lm-demo-lang'); lang.value = locale;
  function translatePage() {
    root.lang=locale; root.dir=['ckb','ar'].includes(locale) ? 'rtl':'ltr';
    root.querySelectorAll('[data-t]').forEach(n=>{n.textContent=tr(n.dataset.t);});
    $('lm-demo-check-text').textContent=locked?tr('next'):tr('check');
    $('lm-demo-progress-digits').textContent=`${Math.min(current,questions.length)} / ${questions.length}`;
    if (started && !finished) renderQuestion(true);
  }
  lang.addEventListener('change',()=>{if (!engine.locales.includes(lang.value)) return;locale=lang.value;translatePage();});
  function node(tag, cls, text) {const el=document.createElement(tag); if(cls) el.className=cls; if(text!==undefined) el.textContent=text;return el;}
  function showError(message) {const target=$('lm-demo-error');target.textContent=message;target.hidden=false;}
  function clearError() {const target=$('lm-demo-error');target.textContent='';target.hidden=true;}
  function updateCheck() {
    const q=questions[current];
    const textAnswer = root.querySelector('#lm-demo-written');
    const ready = q.kind==='choice' ? Boolean(selected) : q.kind==='order' ? ordered.length>0 : Boolean(textAnswer && textAnswer.value.trim());
    $('lm-demo-check').disabled = !locked && !ready;
  }
  function choiceButton(option) {
    const button=node('button','lm-demo-option',pick(option.label));button.type='button';
    button.dataset.optionId=option.id;button.setAttribute('aria-pressed',String(selected===option.id));button.disabled=locked;
    button.addEventListener('click',()=>{
      if(locked)return;selected=option.id;clearError();
      root.querySelectorAll('.lm-demo-option').forEach(el=>el.setAttribute('aria-pressed',String(el===button)));
      updateCheck();
    });return button;
  }
  function renderOrder() {
    const q=questions[current], panel=$('lm-demo-answers');panel.replaceChildren();
    const chosen=node('div','lm-demo-word-line');chosen.setAttribute('aria-label',tr('selected'));
    const chosenTitle=node('p','lm-demo-word-title',tr('selected'));panel.append(chosenTitle,chosen);
    ordered.forEach((id,index)=>{
      const token=q.tokens.find(t=>t.id===id);
      const b=node('button','lm-demo-word lm-demo-word-chosen',token.text);b.type='button';b.disabled=locked;
      b.setAttribute('aria-label',`${tr('removeWord')} ${index+1}: ${token.text}`);
      b.addEventListener('click',()=>{ordered.splice(index,1);renderOrder();updateCheck();});chosen.append(b);
    });
    if(!ordered.length)chosen.append(node('span','lm-demo-placeholder',tr('answerArea')));
    panel.append(node('p','lm-demo-word-title',tr('available')));
    const available=node('div','lm-demo-word-pool');
    q.tokens.filter(token=>!ordered.includes(token.id)).forEach(token=>{
      const b=node('button','lm-demo-word',token.text);b.type='button';b.disabled=locked;
      b.addEventListener('click',()=>{ordered.push(token.id);clearError();renderOrder();updateCheck();});available.append(b);
    });panel.append(available);
  }
  function renderQuestion(keepAnswer=false) {
    const q=questions[current], panel=$('lm-demo-answers');
    const draft = keepAnswer ? $('lm-demo-written')?.value || '' : '';
    if (!keepAnswer) {selected='';ordered=[];attempts=0;locked=false;feedbackMode='';clearError();}
    $('lm-demo-question-title').textContent=pick(q.prompt);
    $('lm-demo-counter').textContent=`${current+1} / ${questions.length}`;
    $('lm-demo-kind').textContent=tr(q.kind==='order'?'kindOrder':q.kind==='text'?'kindText':'kindChoice');
    $('lm-demo-progress-digits').textContent=`${current} / ${questions.length}`;
    $('lm-demo-progress').value=current;
    $('lm-demo-feedback').hidden=true;
    panel.replaceChildren();
    const audio=$('lm-demo-audio');audio.hidden=!q.say;
    $('lm-demo-transcript').hidden=true;
    $('lm-demo-transcript').textContent=q.say||'';
    $('lm-demo-transcript-toggle').setAttribute('aria-expanded','false');
    $('lm-demo-transcript-toggle').textContent=tr('showTranscript');
    if (q.kind==='choice') q.options.forEach(option=>panel.append(choiceButton(option)));
    else if(q.kind==='order')renderOrder();
    else {
      const label=node('label','lm-demo-input-label',tr('inputLabel'));label.htmlFor='lm-demo-written';
      const field=node('input','lm-demo-input');field.type='text';field.id='lm-demo-written';field.name='demo-answer';field.autocomplete='off';field.maxLength=90;
      field.placeholder=tr('inputPlace');field.lang='nl';field.dir='ltr';field.value=draft;field.disabled=locked;
      field.addEventListener('input',()=>{clearError();updateCheck();});
      field.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault(); if(!$('lm-demo-check').disabled)$('lm-demo-check').click();}});
      panel.append(label,field);
    }
    $('lm-demo-check-text').textContent=locked?tr('next'):tr('check');
    updateCheck();
    if(keepAnswer && feedbackMode){
      const feedback=$('lm-demo-feedback');feedback.hidden=false;feedback.className=`lm-demo-feedback lm-demo-${feedbackMode}`;
      $('lm-demo-feedback-head').textContent=feedbackMode==='hint'?tr('tryAgain'):feedbackMode==='success'?tr('correct'):tr('notQuite');
      $('lm-demo-feedback-copy').textContent=pick(feedbackMode==='hint'?q.hint:q.explain);
    }
    updateCheck();
  }
  function currentAnswer() {
    const q=questions[current];
    return q.kind==='choice'?selected:q.kind==='order'?ordered.map(id=>q.tokens.find(t=>t.id===id).text).join(' '):$('lm-demo-written')?.value || '';
  }
  function setLockedFeedback(right) {
    locked=true;feedbackMode=right?'success':'learning';
    const feedback=$('lm-demo-feedback');feedback.hidden=false;
    feedback.className=`lm-demo-feedback ${right?'lm-demo-success':'lm-demo-learning'}`;
    $('lm-demo-feedback-head').textContent=right?tr('correct'):tr('notQuite');
    $('lm-demo-feedback-copy').textContent=pick(questions[current].explain);
    $('lm-demo-check-text').textContent=tr('next');
    $('lm-demo-check').disabled=false;
    $('lm-demo-answers').querySelectorAll('button,input').forEach(el=>el.disabled=true);
  }
  function check() {
    if(locked){
      if(current===questions.length-1){finish();return;}
      current+=1;renderQuestion();$('lm-demo-question-title').focus();return;
    }
    const answer=currentAnswer();
    if (!String(answer).trim()){showError(tr('empty'));return;}
    const correct=engine.evaluate(questions[current],answer);
    if(correct){if(attempts===0)firstTry+=1;setLockedFeedback(true);return;}
    attempts+=1;
    if(attempts>=2){setLockedFeedback(false);return;}
    feedbackMode='hint';
    const feedback=$('lm-demo-feedback');feedback.hidden=false;feedback.className='lm-demo-feedback lm-demo-hint';
    $('lm-demo-feedback-head').textContent=tr('tryAgain');
    $('lm-demo-feedback-copy').textContent=pick(questions[current].hint);
    $('lm-demo-check').disabled=false;
  }
  function finish(){
    finished=true;$('lm-demo-progress').value=questions.length;
    $('lm-demo-progress-digits').textContent=`${questions.length} / ${questions.length}`;
    $('lm-demo-question').hidden=true;$('lm-demo-finish').hidden=false;
    $('lm-demo-score').textContent=`${firstTry} / ${questions.length}`;
    $('lm-demo-finish-heading').focus?.();
  }
  $('lm-demo-listen').addEventListener('click',()=>{
    const q=questions[current]; if(!q.say)return;
    if(!('speechSynthesis' in window) || !('SpeechSynthesisUtterance' in window)){
      $('lm-demo-transcript').hidden=false;
      $('lm-demo-transcript-toggle').setAttribute('aria-expanded','true');
      showError(tr('noAudio'));return;
    }
    try {window.speechSynthesis.cancel();const speech=new SpeechSynthesisUtterance(q.say);speech.lang='nl-NL';speech.rate=.88;window.speechSynthesis.speak(speech);}
    catch(_){$('lm-demo-transcript').hidden=false;showError(tr('noAudio'));}
  });
  $('lm-demo-transcript-toggle').addEventListener('click',()=>{
    const transcript=$('lm-demo-transcript');transcript.hidden=!transcript.hidden;
    $('lm-demo-transcript-toggle').setAttribute('aria-expanded',String(!transcript.hidden));
    $('lm-demo-transcript-toggle').textContent=tr(transcript.hidden?'showTranscript':'hideTranscript');
  });
  $('lm-demo-start').addEventListener('click',()=>{
    started=true;current=0;firstTry=0;finished=false;
    $('lm-demo-intro').hidden=true;$('lm-demo-question').hidden=false;$('lm-demo-finish').hidden=true;
    renderQuestion();$('lm-demo-question-title').focus();
  });
  $('lm-demo-check').addEventListener('click',check);
  $('lm-demo-replay').addEventListener('click',()=>{
    started=false;finished=false;current=0;firstTry=0;attempts=0;locked=false;feedbackMode='';
    $('lm-demo-intro').hidden=false;$('lm-demo-question').hidden=true;$('lm-demo-finish').hidden=true;
    $('lm-demo-progress').value=0;translatePage();$('lm-demo-start').focus();
  });
  translatePage();
})();

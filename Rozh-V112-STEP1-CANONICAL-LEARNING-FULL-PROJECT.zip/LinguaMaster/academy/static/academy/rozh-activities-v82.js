/* Rozh V82 — two distinct keyboard-operated learning activities.
 * Correct answers and grading remain exclusively on the server.
 * Localized controls are interface language; tile text uses the course language.
 */
(() => {
  'use strict';
  const UI = {
    nl: {build:'Kies de woorden en bouw een zin. De server controleert je antwoord.',order:'Verplaats de woorden met de pijlen naar de juiste volgorde.',undo:'Laatste woord terug',clear:'Zin leegmaken',reset:'Beginvolgorde herstellen',up:'Verplaats omhoog',down:'Verplaats omlaag',choose:'Gekozen woorden',available:'Beschikbare woorden',sequence:'Volgorde van woorden',count:(n,t)=>`${n} van ${t} woorden gekozen.`,position:(n,t)=>`Woord ${n} van ${t}.`,moved:(n,t)=>`Woord verplaatst naar positie ${n} van ${t}.`},
    en: {build:'Select words to build a sentence. The server checks your answer.',order:'Move the words into the correct order using the arrows.',undo:'Remove last word',clear:'Clear sentence',reset:'Restore starting order',up:'Move up',down:'Move down',choose:'Selected words',available:'Available words',sequence:'Word order',count:(n,t)=>`${n} of ${t} words chosen.`,position:(n,t)=>`Word ${n} of ${t}.`,moved:(n,t)=>`Word moved to position ${n} of ${t}.`},
    de: {build:'Wähle Wörter, um einen Satz zu bilden. Die Antwort wird auf dem Server geprüft.',order:'Bringe die Wörter mit den Pfeilen in die richtige Reihenfolge.',undo:'Letztes Wort zurück',clear:'Satz leeren',reset:'Anfangsreihenfolge',up:'Nach oben',down:'Nach unten',choose:'Gewählte Wörter',available:'Verfügbare Wörter',sequence:'Wortfolge',count:(n,t)=>`${n} von ${t} Wörtern ausgewählt.`,position:(n,t)=>`Wort ${n} von ${t}.`,moved:(n,t)=>`Wort an Position ${n} von ${t} verschoben.`},
    fr: {build:'Choisissez des mots pour créer une phrase. La réponse est vérifiée par le serveur.',order:'Déplacez les mots avec les flèches pour former la phrase.',undo:'Annuler le dernier mot',clear:'Effacer la phrase',reset:'Ordre initial',up:'Monter',down:'Descendre',choose:'Mots choisis',available:'Mots disponibles',sequence:'Ordre des mots',count:(n,t)=>`${n} mot(s) sur ${t} choisis.`,position:(n,t)=>`Mot ${n} sur ${t}.`,moved:(n,t)=>`Mot déplacé en position ${n} sur ${t}.`},
    uk: {build:'Виберіть слова, щоб скласти речення. Відповідь перевіряє сервер.',order:'Розташуйте слова за допомогою стрілок.',undo:'Прибрати останнє слово',clear:'Очистити речення',reset:'Початковий порядок',up:'Угору',down:'Униз',choose:'Обрані слова',available:'Доступні слова',sequence:'Порядок слів',count:(n,t)=>`Обрано ${n} із ${t} слів.`,position:(n,t)=>`Слово ${n} із ${t}.`,moved:(n,t)=>`Слово переміщено на позицію ${n} із ${t}.`},
    ar: {build:'اختر الكلمات لتكوين جملة. يتم فحص الإجابة على الخادم.',order:'رتّب الكلمات باستخدام أزرار الأسهم.',undo:'إزالة آخر كلمة',clear:'مسح الجملة',reset:'استعادة الترتيب الأول',up:'تحريك للأعلى',down:'تحريك للأسفل',choose:'الكلمات المختارة',available:'الكلمات المتاحة',sequence:'ترتيب الكلمات',count:(n,t)=>`اخترت ${n} من ${t} كلمات.`,position:(n,t)=>`الكلمة ${n} من ${t}.`,moved:(n,t)=>`نُقلت الكلمة إلى الموضع ${n} من ${t}.`},
    ckb: {build:'وشەکان هەڵبژێرە و ڕستەیەک دروست بکە. وەڵامەکەت لە سێرڤەر پشکنین دەکرێت.',order:'بە دوگمەکانی تیر وشەکان بە ڕیزبەندی دروست دابنێ.',undo:'وشەی کۆتایی بگەڕێنەوە',clear:'ڕستەکە بەتاڵ بکە',reset:'گەڕانەوە بۆ ڕیزی سەرەتا',up:'بەرەو سەرەوە',down:'بەرەو خوارەوە',choose:'وشە هەڵبژێردراوەکان',available:'وشە بەردەستەکان',sequence:'ڕیزی وشەکان',count:(n,t)=>`${n} لە ${t} وشە هەڵبژێردراوە.`,position:(n,t)=>`وشەی ${n} لە ${t}.`,moved:(n,t)=>`وشەکە چووە شوێنی ${n} لە ${t}.`},
    kmr: {build:'پەیڤان هەلبژێرە و ڕستەیەکێ چێکە. بەرسڤ ل سێرڤەرێ دهێتە پشکنین.',order:'پەیڤان ب تیران ب ڕێزەکا دروست دابنێ.',undo:'پەیڤا داویێ ڤەگەڕینە',clear:'ڕستەیێ ڤالا بکە',reset:'ڕێزا دەستپێکێ',up:'بۆ سەر',down:'بۆ خوار',choose:'پەیڤێن هەلبژارتین',available:'پەیڤێن بەردەست',sequence:'ڕێزا پەیڤان',count:(n,t)=>`${n} ژ ${t} پەیڤ هاتنە هەلبژارتن.`,position:(n,t)=>`پەیڤا ${n} ژ ${t}.`,moved:(n,t)=>`پەیڤ چوو شوێنا ${n} ژ ${t}.`},
    ku: {build:'Peyvan hilbijêre û hevokekê ava bike. Bersiv li ser serverê tê kontrolkirin.',order:'Bi tîran peyvan bi rêza rast rêz bike.',undo:'Peyva dawî vegerîne',clear:'Hevokê vala bike',reset:'Rêza destpêkê',up:'Ber bi jor',down:'Ber bi jêr',choose:'Peyvên bijartî',available:'Peyvên amade',sequence:'Rêza peyvan',count:(n,t)=>`${n} ji ${t} peyv hatin hilbijartin.`,position:(n,t)=>`Peyva ${n} ji ${t}.`,moved:(n,t)=>`Peyv çû cihê ${n} ji ${t}.`}
  };
  const copy = root => UI[root.dataset.v82Locale] || UI.en;
  const blocked = root => !!root.closest('form')?.classList.contains('has-feedback') || root.closest('form')?.dataset.v81Locked === 'true';
  function compose(root) {
    const lang=copy(root);
    const tiles=[...root.querySelectorAll('[data-v82-compose-token]')];
    const answer=root.querySelector('[data-v82-compose-answer]');
    const built=root.querySelector('[data-v82-compose-built]');
    const status=root.querySelector('[data-v82-compose-status]');
    const undo=root.querySelector('[data-v82-compose-undo]');
    const clear=root.querySelector('[data-v82-compose-clear]');
    if(!answer || !built || !status || !undo || !clear || !tiles.length)return;
    const chosen=[];
    root.querySelector('[data-v82-compose-instruction]').textContent=lang.build;
    root.querySelector('[data-v82-compose-bank]').setAttribute('aria-label',lang.available);
    built.setAttribute('aria-label',lang.choose);
    undo.textContent=lang.undo;clear.textContent=lang.clear;
    function redraw(){
      built.replaceChildren();
      for(const id of chosen){
        const token=tiles.find(x=>x.dataset.v82ComposeToken===id);
        if(!token)continue;
        const display=document.createElement('span');display.textContent=token.dataset.v82Word;
        display.lang=token.lang;display.dir='auto';built.append(display);
      }
      for(const tile of tiles)tile.disabled=blocked(root) || chosen.includes(tile.dataset.v82ComposeToken);
      undo.disabled=blocked(root) || !chosen.length;
      clear.disabled=blocked(root) || !chosen.length;
      status.textContent=lang.count(chosen.length,tiles.length);
      answer.value=chosen.map(id=>tiles.find(t=>t.dataset.v82ComposeToken===id)?.dataset.v82Word||'').join(' ');
    }
    tiles.forEach(tile=>tile.addEventListener('click',()=>{
      if(blocked(root) || chosen.includes(tile.dataset.v82ComposeToken))return;
      chosen.push(tile.dataset.v82ComposeToken);redraw();
    }));
    undo.addEventListener('click',()=>{if(blocked(root))return;chosen.pop();redraw();});
    clear.addEventListener('click',()=>{if(blocked(root))return;chosen.length=0;redraw();});
    // Allow a typed sentence as accessible fallback. Never silently overwrite user-typed work.
    answer.addEventListener('input',()=>{if(blocked(root))return;chosen.length=0;built.replaceChildren();tiles.forEach(t=>t.disabled=false);undo.disabled=true;clear.disabled=true;status.textContent='';});
    redraw();
  }
  function order(root){
    const lang=copy(root);
    const list=root.querySelector('[data-v82-order-list]');
    const answer=root.querySelector('[data-v82-order-answer]');
    const status=root.querySelector('[data-v82-order-status]');
    const reset=root.querySelector('[data-v82-order-reset]');
    if(!list||!answer||!status||!reset)return;
    const initial=[...list.querySelectorAll('[data-v82-order-item]')];
    if(initial.length<2)return;
    root.querySelector('[data-v82-order-instruction]').textContent=lang.order;
    list.setAttribute('aria-label',lang.sequence);reset.textContent=lang.reset;
    const current=()=>[...list.querySelectorAll('[data-v82-order-item]')];
    function redraw(message=''){
      const items=current(),total=items.length;
      answer.value=items.map(n=>n.dataset.v82Word).join(' ');
      items.forEach((item,index)=>{
        item.querySelector('.v82-order-number').textContent=String(index+1);
        const up=item.querySelector('[data-v82-order-up]'),down=item.querySelector('[data-v82-order-down]');
        up.disabled=blocked(root) || index===0;down.disabled=blocked(root) || index===total-1;
        up.setAttribute('aria-label',lang.up+': '+item.dataset.v82Word+', '+lang.position(index+1,total));
        down.setAttribute('aria-label',lang.down+': '+item.dataset.v82Word+', '+lang.position(index+1,total));
      });
      reset.disabled=blocked(root) || items.every((e,i)=>e===initial[i]);
      status.textContent=message || lang.position(1,total);
    }
    list.addEventListener('click',event=>{
      const button=event.target.closest('[data-v82-order-up],[data-v82-order-down]');
      if(!button || blocked(root))return;
      const item=button.closest('[data-v82-order-item]');
      const isUp=button.hasAttribute('data-v82-order-up');
      const other=isUp?item.previousElementSibling:item.nextElementSibling;
      if(!other)return;
      if(isUp)other.before(item);else other.after(item);
      const index=current().indexOf(item)+1;
      redraw(lang.moved(index,current().length));
      // When the word reaches an edge the used arrow becomes disabled.
      // Focusing a disabled control loses keyboard focus; instead focus the
      // opposite (enabled) arrow on the SAME word. Keep the learner oriented.
      const used=item.querySelector(isUp?'[data-v82-order-up]':'[data-v82-order-down]');
      const otherArrow=item.querySelector(isUp?'[data-v82-order-down]':'[data-v82-order-up]');
      const focusTarget=used && !used.disabled ? used :
        otherArrow && !otherArrow.disabled ? otherArrow : item;
      if(focusTarget===item)item.tabIndex=-1;
      focusTarget.focus();
    });
    reset.addEventListener('click',()=>{if(blocked(root))return;list.replaceChildren(...initial);redraw();});
    // Optional typing for accessibility: preserve text when someone uses input instead of reordering.
    answer.addEventListener('input',()=>{status.textContent='';});
    redraw();
  }
  document.querySelectorAll('[data-v82-compose]').forEach(compose);
  document.querySelectorAll('[data-v82-order]').forEach(order);
})();

"""Run: python manage.py test academy --verbosity 2
These tests have NOT been executed in the offline packaging environment.
"""
import json
from unittest.mock import patch
from django.conf import settings
from django.contrib.staticfiles import finders
from django.templatetags.static import static
from django.contrib.auth import get_user_model
from django.core import mail
from django.test import SimpleTestCase, TestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from django.core.cache import cache
import pyotp
from .models import (Profile,PlatformSettings,Language,Level,Unit,Lesson,Exercise,LessonProgress,
                     Assessment,ReviewCard,Vocabulary,Certificate,Friendship,AIUsage,GrammarTopic,XPEvent)
from .services import grade,save_review,allowed_unit,unit_lessons_done,level_units_passed
from .ai_service import tutor_reply,AIUnavailable
User=get_user_model()


class MigrationConsistencyTests(SimpleTestCase):
    """Protect the self-referential unit prerequisite links against schema churn."""
    def test_historical_state_matches_current_models(self):
        from django.apps import apps
        from django.db.migrations.autodetector import MigrationAutodetector
        from django.db.migrations.loader import MigrationLoader
        from django.db.migrations.state import ProjectState
        loader = MigrationLoader(None)
        recorded = loader.project_state()
        current = ProjectState.from_apps(apps)
        changes = MigrationAutodetector(recorded, current).changes(graph=loader.graph)
        self.assertEqual(changes.get('academy', []), [], 'Academy migration state is not synchronized')
        field = recorded.models['academy', 'unit'].fields['prerequisites']
        self.assertTrue(field.many_to_many)
        self.assertFalse(field.remote_field.symmetrical)

    def test_prerequisite_migration_has_no_database_operations(self):
        # Read operations dynamically by importlib; numbered migration name is valid via import_module.
        from importlib import import_module
        mod = import_module('academy.migrations.0004_reconcile_unit_prerequisites_state')
        self.assertEqual(len(mod.Migration.operations), 1)
        operation = mod.Migration.operations[0]
        self.assertEqual(operation.database_operations, [])
        self.assertEqual(len(operation.state_operations), 2)

class StaticManifestRegressionTests(SimpleTestCase):
    """Regression: a new PWA install must render in local mode without collectstatic."""
    def test_local_pwa_manifest_is_present_and_resolvable(self):
        if not settings.DEBUG:
            self.skipTest('This regression specifically verifies local DEBUG=1 mode')
        self.assertEqual(
            settings.STORAGES['staticfiles']['BACKEND'],
            'django.contrib.staticfiles.storage.StaticFilesStorage',
        )
        self.assertIsNotNone(finders.find('academy/manifest.webmanifest'))
        self.assertEqual(
            static('academy/manifest.webmanifest'),
            '/static/academy/manifest.webmanifest',
        )

class SiteTests(TestCase):
    def setUp(self):
        cache.clear()
        self.lang=Language.objects.create(name='Dutch',code='nl',slug='dutch',description='Learn Dutch.',is_published=True)
        self.level=Level.objects.create(language=self.lang,code='A0',description='Pre-A1',order=0)
    def test_public_routes_and_seo(self):
        for path in ('/','/languages/dutch/','/languages/dutch/a0/','/grammar/','/word-of-the-day/','/how-it-works/','/privacy/','/terms/'):
            response=self.client.get(path)
            self.assertEqual(response.status_code,200,path)
            self.assertContains(response,'canonical')
            self.assertIn('Content-Security-Policy',response)
        sitemap=self.client.get('/sitemap.xml')
        self.assertEqual(sitemap.status_code,200)
        self.assertContains(sitemap,'/languages/dutch/')
        self.assertContains(self.client.get('/robots.txt'),'Disallow: /secure-admin/')
    def test_unpublished_not_public(self):
        self.lang.is_published=False;self.lang.save()
        self.assertEqual(self.client.get('/languages/dutch/').status_code,404)
    def test_readiness_needs_privacy_contact(self):
        self.assertEqual(self.client.get('/health/').status_code,200)
        self.assertEqual(self.client.get('/ready/').status_code,503)
        cfg=PlatformSettings.load();cfg.privacy_email='privacy@example.org';cfg.save()
        # A privacy inbox without the accountable operator identity is NOT ready.
        self.assertEqual(self.client.get('/ready/').status_code,503)
        cfg.organization_name='Rozh Learning Operations Ltd'
        cfg.save(update_fields=['organization_name'])
        self.assertEqual(self.client.get('/ready/').status_code,200)
    def test_xss_is_escaped(self):
        topic=GrammarTopic.objects.create(level=self.level,slug='test',title='<img src=x onerror=alert(1)>',
          explanation='Use <script>alert(1)</script> safely.',examples=['Example'],exceptions='None',common_mistakes='None',
          check_question='Example?',check_options=['Yes','No'],check_answer='Yes',published=True)
        response=self.client.get(topic.get_absolute_url())
        self.assertNotIn(b'<script>alert(1)</script>',response.content)
        self.assertContains(response,'&lt;script&gt;')

class AccountTests(TestCase):
    def setUp(self):cache.clear()
    def test_registration_auto_login_and_login_again(self):
        response=self.client.post('/register/', {'username':'new_learner','email':'USER@example.org',
            'password1':'AStrongExamplePassword!23','age_confirmed':'on'})
        self.assertEqual(response.status_code,302)
        user=User.objects.get(email='user@example.org')
        self.assertTrue(user.is_active)
        self.assertIsNone(user.learning_profile.email_verified_at)
        self.assertEqual(len(mail.outbox),0)
        self.assertEqual(int(self.client.session['_auth_user_id']),user.pk)
        self.assertRedirects(self.client.post('/logout/'),'/',fetch_redirect_response=False)
        response=self.client.post('/login/',{'email':user.email,'password':'AStrongExamplePassword!23'})
        self.assertRedirects(response,'/onboarding/',fetch_redirect_response=False)

    def test_public_login_and_register_are_clear_and_accessible(self):
        sign_in=self.client.get('/login/')
        self.assertEqual(sign_in.status_code,200)
        self.assertContains(sign_in,'Sign in and continue')
        self.assertContains(sign_in,'Create account')
        self.assertContains(sign_in,'Forgot password?')
        self.assertContains(sign_in,'Forgot password?')
        self.assertContains(sign_in,'autocomplete="current-password"')
        sign_up=self.client.get('/register/')
        self.assertEqual(sign_up.status_code,200)
        self.assertContains(sign_up,'Create my account')
        self.assertContains(sign_up,'autocomplete="new-password"')
        self.assertContains(sign_up,'Start learning now.')
        self.assertContains(sign_up,'name="csrfmiddlewaretoken"')

    def test_verified_account_can_sign_in_with_username_and_log_out(self):
        learner=User.objects.create_user(username='my_user',email='me@example.org',password='AStrongExamplePassword!23')
        r=self.client.post('/login/',{'email':'MY_USER','password':'AStrongExamplePassword!23'})
        self.assertEqual(r.status_code,302)
        self.assertEqual(int(self.client.session['_auth_user_id']),learner.pk)
        self.assertRedirects(self.client.get('/dashboard/'),'/placement/',fetch_redirect_response=False)
        self.assertEqual(self.client.get('/logout/').status_code,405)
        self.assertRedirects(self.client.post('/logout/'), '/', fetch_redirect_response=False)
        self.assertNotIn('_auth_user_id',self.client.session)

    def test_under_16_cannot_register_without_attestation(self):
        response=self.client.post('/register/',{'email':'young@example.org','password1':'AStrongExamplePassword!23',
            'password2':'AStrongExamplePassword!23'})
        self.assertEqual(response.status_code,200)
        self.assertFalse(User.objects.filter(email='young@example.org').exists())
    def test_mfa_required_before_login(self):
        user=User.objects.create_user('learner@example.org','learner@example.org','AStrongExamplePassword!23')
        secret=pyotp.random_base32()
        p=user.learning_profile;p.totp_secret=secret;p.save()
        r=self.client.post('/login/',{'email':user.email,'password':'AStrongExamplePassword!23'})
        self.assertRedirects(r,'/mfa/verify/',fetch_redirect_response=False)
        self.assertNotIn('_auth_user_id',self.client.session)
        r=self.client.post('/mfa/verify/',{'code':pyotp.TOTP(secret).now()})
        self.assertEqual(r.status_code,302)
        self.assertEqual(int(self.client.session['mfa_verified_id']),user.pk)
    def test_password_hash_not_exposed_by_export(self):
        user=User.objects.create_user('learner@example.org','learner@example.org','AStrongExamplePassword!23')
        self.client.force_login(user)
        data=self.client.post('/account/export/', {'password': 'AStrongExamplePassword!23'})
        self.assertEqual(data.status_code,200)
        self.assertIn('completed_lessons',json.loads(data.content))
        self.assertNotIn('password',data.content.decode())
        self.assertEqual(self.client.post('/account/delete/',{'password':'wrong'}).status_code,200)
        self.assertTrue(User.objects.filter(pk=user.pk).exists())
        self.assertEqual(self.client.post('/account/delete/',{'password':'AStrongExamplePassword!23'}).status_code,302)
        self.assertFalse(User.objects.filter(pk=user.pk).exists())
    def test_admin_requires_two_factor(self):
        owner=User.objects.create_superuser('owner@example.org','owner@example.org','AStrongExamplePassword!23')
        self.client.force_login(owner)
        self.assertEqual(self.client.get('/secure-admin/').status_code,302)
        self.assertEqual(self.client.get('/manager/').status_code,403)
        p=owner.learning_profile;p.totp_secret=pyotp.random_base32();p.email_verified_at=timezone.now();p.save()
        session=self.client.session;session['mfa_verified_id']=owner.pk;session.save()
        self.assertEqual(self.client.get('/manager/').status_code,200)
        self.assertEqual(self.client.get('/secure-admin/').status_code,200)

class LearningTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user=User.objects.create_user('student@example.org','student@example.org','AStrongExamplePassword!23')
        self.client.force_login(self.user)
        self.lang=Language.objects.create(name='Dutch',code='nl',slug='dutch',description='Learn Dutch',is_published=True)
        profile=self.user.learning_profile
        profile.preferred_language=self.lang
        profile.placement_completed=True
        profile.save(update_fields=['preferred_language','placement_completed'])
        self.level=Level.objects.create(language=self.lang,code='A1',description='First level',order=1)
        self.unit=Unit.objects.create(level=self.level,slug='first',title='First unit',summary='Start',published=True)
        self.lesson=Lesson.objects.create(unit=self.unit,slug='grammar',title='Simple grammar',skill='grammar',
                                         content='Ik werk.',order=1,published=True)
        self.exercise=Exercise.objects.create(lesson=self.lesson,prompt='Correct verb?',options=['werk','werkt'],answer='werk',
                                              explanation='Ik werk.',difficulty=1)
    def test_quiz_gating_progress_and_unit_test(self):
        self.assertEqual(self.client.get(reverse('assessment_unit',args=[self.unit.pk])).status_code,403)
        self.assertTrue(grade(self.exercise,'  WERK '))
        self.assertFalse(grade(self.exercise,'werkt'))
        self.assertEqual(self.client.post(reverse('lesson',args=[self.lesson.pk]),{f'answer_{self.exercise.pk}':'werkt'}).status_code,200)
        self.assertFalse(LessonProgress.objects.filter(user=self.user).exists())
        self.assertEqual(self.client.post(reverse('lesson',args=[self.lesson.pk]),{f'answer_{self.exercise.pk}':'werk'}).status_code,200)
        self.assertTrue(unit_lessons_done(self.user,self.unit))
        self.user.learning_profile.refresh_from_db()
        self.assertEqual(self.user.learning_profile.xp,20)
        result=self.client.post(reverse('assessment_unit',args=[self.unit.pk]),{f'q_{self.exercise.pk}':'werk'})
        self.assertEqual(result.status_code,200)
        self.assertTrue(Assessment.objects.filter(user=self.user,unit=self.unit,passed=True).exists())
        self.assertEqual(self.client.get(reverse('assessment_level',args=[self.level.pk])).status_code,200)
    def test_prerequisites(self):
        second=Unit.objects.create(level=self.level,slug='second',title='Second unit',summary='More',published=True)
        second.prerequisites.add(self.unit)
        self.assertFalse(allowed_unit(self.user,second))
    def test_spaced_repetition_algorithm(self):
        word=Vocabulary.objects.create(level=self.level,word='huis',translation='house',pronunciation='huys',
                                       example='Het huis.',published=True)
        card=ReviewCard.objects.create(user=self.user,vocabulary=word)
        save_review(card,5)
        self.assertEqual(card.interval_days,1)
        save_review(card,5)
        self.assertEqual(card.interval_days,6)
        save_review(card,0)
        self.assertEqual(card.repetitions,0)
        self.assertGreaterEqual(card.ease,1.3)
    def test_certification_is_internal_only(self):
        LessonProgress.objects.create(user=self.user,lesson=self.lesson,score=100)
        Assessment.objects.create(user=self.user,kind='unit',unit=self.unit,score=100,passed=True)
        result=self.client.post(reverse('assessment_level',args=[self.level.pk]),{f'q_{self.exercise.pk}':'werk'})
        self.assertEqual(result.status_code,200)
        cert=Certificate.objects.get(user=self.user,level=self.level)
        response=self.client.get(reverse('certificate',args=[cert.serial]))
        self.assertContains(response,'Not an official CEFR qualification')
        cert.revoked_at=timezone.now();cert.save()
        self.assertContains(self.client.get(reverse('certificate',args=[cert.serial])),'REVOKED')
    def test_adaptive_practice_records_result(self):
        res=self.client.post(reverse('adaptive_practice',args=[self.level.pk]),{f'q_{self.exercise.pk}':'werk'})
        self.assertEqual(res.status_code,200)
        self.assertTrue(Assessment.objects.filter(user=self.user,kind='practice').exists())

class SocialAndAITests(TestCase):
    def setUp(self):
        cache.clear()
        self.a=User.objects.create_user('a@example.org','a@example.org','AStrongExamplePassword!23')
        self.b=User.objects.create_user('b@example.org','b@example.org','AStrongExamplePassword!23')
        self.client.force_login(self.a)
    def test_social_opt_in_required(self):
        self.assertContains(self.client.get('/friends/'),'Enable social features')
        for user in (self.a,self.b):
            profile=user.learning_profile;profile.social_opt_in=True;profile.save()
        self.client.post('/friends/',{'username':self.b.username})
        relation=Friendship.objects.get(from_user=self.a,to_user=self.b)
        self.client.force_login(self.b)
        self.client.post(reverse('friend_action',args=[relation.pk,'accept']))
        relation.refresh_from_db();self.assertEqual(relation.status,'accepted')
    @override_settings(AI_API_KEY='test-key')
    def test_ai_feature_flags_and_budget_fail_closed(self):
        config=PlatformSettings.load()
        self.assertEqual(self.client.get('/ai-tutor/').status_code,404)
        config.ai_enabled=True;config.ai_emergency_stop=False;config.ai_monthly_budget_eur='0.00';config.save()
        p=self.a.learning_profile;p.ai_opt_in=True;p.save()
        with self.assertRaises(AIUnavailable):tutor_reply(self.a,'Explain Dutch word order.')
        self.assertEqual(AIUsage.objects.filter(user=self.a).count(),0)
    @override_settings(AI_API_KEY='test-key')
    @patch('academy.ai_service._post')
    def test_ai_moderates_both_sides(self,post):
        from .billing_models import AICreditWallet
        AICreditWallet.objects.create(user=self.a, balance=1, purchased=1)
        cfg=PlatformSettings.load();cfg.ai_enabled=True;cfg.ai_emergency_stop=False;cfg.ai_monthly_budget_eur='10.00';cfg.save()
        p=self.a.learning_profile;p.ai_opt_in=True;p.save()
        post.side_effect=[{'results':[{'flagged':False}]},
            {'choices':[{'message':{'content':'Ik werk = I work.'}}],'usage':{'prompt_tokens':80,'completion_tokens':14}},
            {'results':[{'flagged':False}]}]
        answer=tutor_reply(self.a,'What does ik werk mean?')
        self.assertIn('I work',answer)
        self.assertEqual(post.call_count,3)
        self.assertEqual(AIUsage.objects.get(user=self.a).status,'ok')

class AppExperienceTests(TestCase):
    """Integration checks for the installable interactive app, not a visual/browser audit."""
    def setUp(self):
        cache.clear()
        self.user = User.objects.create_user('app-user@example.org', 'app-user@example.org', 'StrongExamplePassword!23')
        profile = self.user.learning_profile
        profile.placement_completed = True
        profile.save(update_fields=['placement_completed'])
        self.language = Language.objects.create(code='nl',slug='dutch',name='Dutch',description='Learn Dutch',is_published=True)
        profile.preferred_language=self.language
        profile.save(update_fields=['preferred_language'])
        self.level = Level.objects.create(language=self.language,code='A0',description='Introduction',order=0)
        self.unit = Unit.objects.create(level=self.level,title='Learn hello',slug='hello',summary='Learn greetings',order=1,published=True)
        self.lesson = Lesson.objects.create(unit=self.unit,slug='grammar',title='Say hello',skill='grammar',content='Hoi = hi',order=1,published=True)
        self.exercise = Exercise.objects.create(lesson=self.lesson,kind='mcq',prompt='Which word means hello?',
            options=['Hoi','Bedankt','Tot ziens'],answer='Hoi',explanation='Hoi is a greeting.',order=1)
        self.client.force_login(self.user)

    def test_dashboard_is_app_and_uses_actual_progress(self):
        result = self.client.get('/dashboard/')
        self.assertEqual(result.status_code,200)
        self.assertContains(result,'app-frame')
        self.assertContains(result,'Learn hello')
        self.assertContains(result,'0%')
        self.assertNotContains(result,'AI tutor')  # default owner-controlled AI is off
        LessonProgress.objects.create(user=self.user,lesson=self.lesson,score=100)
        self.assertContains(self.client.get('/dashboard/'),'100%')

    def test_path_contains_units_and_states(self):
        result = self.client.get('/learn/')
        self.assertEqual(result.status_code,200)
        self.assertContains(result,'app-path-node')
        self.assertContains(result,'Learn hello')
        self.assertContains(result,self.lesson.get_absolute_url())
        self.assertEqual(self.client.get('/learn/',follow=True).status_code,200)

    def test_v4_dashboard_has_real_quest_and_app_modes(self):
        response = self.client.get('/dashboard/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'v4-main-quest')
        self.assertContains(response, 'v4-mode-grid')
        self.assertContains(response, 'Learn hello')
        self.assertContains(response, 'academy/app-v4.css')
        self.assertContains(response, 'academy/pip-sprout.svg')
        self.assertNotContains(response, 'AI tutor')

    def test_v4_path_exposes_actual_unit_and_keeps_prerequisites(self):
        response = self.client.get('/learn/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'v4-journey-stop')
        self.assertContains(response, 'Learn hello')
        self.assertContains(response, self.lesson.get_absolute_url())
        self.assertContains(response, 'v4-chapter-heading')

    def test_questions_checked_server_side_and_xp_not_repeatable(self):
        url = reverse('lesson_answer', args=[self.lesson.pk])
        self.assertNotIn('Hoi is a greeting.',self.client.get(self.lesson.get_absolute_url()).content.decode())
        bad = self.client.post(url,{'exercise_id':self.exercise.pk,'answer':'Bedankt'})
        self.assertEqual(bad.status_code,200)
        self.assertFalse(bad.json()['completed'])
        self.assertEqual(LessonProgress.objects.filter(user=self.user).count(),0)
        good = self.client.post(url,{'exercise_id':self.exercise.pk,'answer':'Hoi'})
        self.assertEqual(good.status_code,200)
        self.assertTrue(good.json()['correct'])
        self.assertTrue(good.json()['completed'])
        self.assertTrue(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())
        self.user.learning_profile.refresh_from_db()
        self.assertEqual(self.user.learning_profile.xp,20)
        self.assertEqual(good.json()['xp_awarded'],20)
        repeat=self.client.post(url,{'exercise_id':self.exercise.pk,'answer':'Hoi'})
        self.assertEqual(repeat.json()['xp_awarded'],0)
        self.user.learning_profile.refresh_from_db()
        self.assertEqual(self.user.learning_profile.xp,20)

    def test_answer_is_scoped_to_lesson_and_allowed_options(self):
        url=reverse('lesson_answer',args=[self.lesson.pk])
        self.assertEqual(self.client.post(url,{'exercise_id':self.exercise.pk,'answer':'Invalid option'}).status_code,400)
        other=Lesson.objects.create(unit=self.unit,slug='reading',title='Read hello',skill='reading',content='Hello',published=True)
        other_question=Exercise.objects.create(lesson=other,kind='mcq',prompt='Other?',options=['a','b'],answer='a')
        self.assertEqual(self.client.post(url,{'exercise_id':other_question.pk,'answer':'a'}).status_code,404)
        self.assertEqual(self.client.post(url,{'exercise_id':'abc','answer':'Hoi'}).status_code,400)
        self.assertEqual(self.client.post(url,{'exercise_id':self.exercise.pk,'answer':'a'*301}).status_code,400)

    def test_locked_unit_cannot_be_graded(self):
        later=Unit.objects.create(level=self.level,title='Advanced greetings',slug='greetings-two',summary='Stage two',order=2,published=True)
        later.prerequisites.add(self.unit)
        lesson=Lesson.objects.create(unit=later,slug='grammar',title='Continue grammar',skill='grammar',content='More',published=True)
        question=Exercise.objects.create(lesson=lesson,kind='mcq',prompt='Which?',options=['Yes','No'],answer='Yes')
        url=reverse('lesson_answer',args=[lesson.pk])
        self.assertEqual(self.client.post(url,{'exercise_id':question.pk,'answer':'Yes'}).status_code,403)
        Assessment.objects.create(user=self.user,kind='unit',unit=self.unit,score=100,passed=True)
        self.assertEqual(self.client.post(url,{'exercise_id':question.pk,'answer':'Yes'}).status_code,200)

    def test_pwa_serves_worker_without_private_page_caching(self):
        response=self.client.get('/service-worker.js')
        self.assertEqual(response.status_code,200)
        self.assertIn('text/javascript',response['Content-Type'])
        self.assertEqual(response['Service-Worker-Allowed'],'/')
        self.assertIn(b"request.mode === 'navigate'",response.content)
        self.assertIn(b'fetch(request)',response.content)
        self.assertNotIn(b'caches.put(request',response.content)
        # A disabled local server must show a real connection failure, not a fake offline PWA page.
        self.assertIn(b'if (LOCAL_DEVELOPMENT) return',response.content)

    def test_no_js_lesson_submission_still_works(self):
        response=self.client.post(self.lesson.get_absolute_url(),{'answer_'+str(self.exercise.pk):'Hoi'})
        self.assertEqual(response.status_code,200)
        self.assertTrue(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())

    def test_csrf_required_on_answer_endpoint(self):
        from django.test import Client
        protected=Client(enforce_csrf_checks=True)
        protected.force_login(self.user)
        response=protected.post(reverse('lesson_answer',args=[self.lesson.pk]),
                                {'exercise_id':self.exercise.pk,'answer':'Hoi'})
        self.assertEqual(response.status_code,403)


class GamifiedAppV3Tests(TestCase):
    """Onboarding, stateful practice, server-authoritative rewards and private app pages."""
    def setUp(self):
        cache.clear()
        self.user=User.objects.create_user('v3learner','v3@example.org','StrongExamplePassword!23')
        self.lang=Language.objects.create(name='Dutch',code='nl',slug='dutch',description='Dutch',is_published=True)
        self.level=Level.objects.create(language=self.lang,code='A0',description='Pre-A1',order=0)
        self.unit=Unit.objects.create(level=self.level,title='Hello',summary='Hello in Dutch',slug='hello',order=1,published=True)
        self.lesson=Lesson.objects.create(unit=self.unit,slug='read',title='Learn hello',skill='reading',content='Hoi = hello',published=True)
        self.questions=[Exercise.objects.create(lesson=self.lesson,kind='mcq',prompt=f'Question {i}',
                   options=['Hoi','Dag','Nee'],answer='Hoi',explanation='Hoi is correct.',order=i) for i in range(1,6)]
        Vocabulary.objects.create(level=self.level,word='Hallo',translation='Hello',pronunciation='hal-oh',
                                   example='Hallo, hoe gaat het?',published=True)
        self.client.force_login(self.user)
        p=self.user.learning_profile
        p.preferred_language=self.lang
        p.placement_completed=True
        p.onboarding_completed=True
        p.save()

    def test_onboarding_saves_language_goal_and_locale(self):
        p=self.user.learning_profile
        p.onboarding_completed=False
        p.save(update_fields=['onboarding_completed'])
        self.assertRedirects(self.client.post('/onboarding/', {'step': '1', 'choice': 'ckb'}),
                             '/onboarding/?step=2', fetch_redirect_response=False)
        self.assertRedirects(self.client.post('/onboarding/', {'step': '2', 'choice': str(self.lang.pk)}),
                             '/onboarding/?step=3', fetch_redirect_response=False)
        self.assertRedirects(self.client.post('/onboarding/', {'step': '3', 'choice': 'beginner'}),
                             '/onboarding/?step=4', fetch_redirect_response=False)
        result=self.client.post('/onboarding/', {'step': '4', 'choice': '35'})
        self.assertRedirects(result, '/onboarding/ready/', fetch_redirect_response=False)
        p.refresh_from_db()
        self.assertEqual((p.ui_language,p.daily_goal_xp,p.onboarding_completed),('ckb',35,True))
        page=self.client.get('/dashboard/')
        self.assertContains(page,'dir="rtl"')
        self.assertContains(page,'فێربوون')

    def test_username_login_as_well_as_email(self):
        self.client.logout()
        result=self.client.post('/login/',{'email':'V3LEARNER','password':'StrongExamplePassword!23'})
        self.assertRedirects(result,'/play/',fetch_redirect_response=False)

    def test_server_tracks_mistake_and_one_correction_reward(self):
        answer_url=reverse('lesson_answer',args=[self.lesson.pk])
        res=self.client.post(answer_url,{'exercise_id':self.questions[0].pk,'answer':'Nee'})
        self.assertEqual(res.status_code,200)
        self.assertFalse(res.json()['correct'])
        from .models import MistakeRecord,XPEvent
        mistake=MistakeRecord.objects.get(user=self.user,exercise=self.questions[0])
        self.assertIsNone(mistake.corrected_at)
        self.assertContains(self.client.get('/mistakes/'),'Question 1')
        repair=self.client.post('/mistakes/',{'mistake_id':mistake.pk,'answer':'Hoi'})
        self.assertRedirects(repair,'/mistakes/',fetch_redirect_response=False)
        mistake.refresh_from_db();self.assertIsNotNone(mistake.corrected_at)
        self.user.learning_profile.refresh_from_db();self.assertEqual(self.user.learning_profile.xp,5)
        self.assertEqual(XPEvent.objects.filter(user=self.user,reason='mistake').count(),1)
        self.assertEqual(self.client.post('/mistakes/',{'mistake_id':mistake.pk,'answer':'Hoi'}).status_code,404)
        self.user.learning_profile.refresh_from_db();self.assertEqual(self.user.learning_profile.xp,5)

    def test_arena_unlocks_levels_and_is_server_graded_and_paid_once(self):
        from .models import ArenaRun,XPEvent
        response=self.client.post('/arena/start/',{'level_id':self.level.pk})
        self.assertEqual(response.status_code,302)
        run=ArenaRun.objects.get(user=self.user)
        page=self.client.get(reverse('arena_run',args=[run.pk]))
        self.assertEqual(page.status_code,200)
        self.assertNotIn('Hoi is correct.',page.content.decode())
        answers={f'q_{pk}':'Hoi' for pk in run.question_ids}
        result=self.client.post(reverse('arena_run',args=[run.pk]),answers)
        self.assertRedirects(result,reverse('arena_result',args=[run.pk]),fetch_redirect_response=False)
        run.refresh_from_db();self.assertEqual((run.score,run.earned_xp),(100,30))
        self.client.post(reverse('arena_run',args=[run.pk]),answers)
        self.assertEqual(XPEvent.objects.filter(user=self.user,reason='arena').count(),1)
        nextlevel=Level.objects.create(language=self.lang,code='A1',description='Next stage',order=1)
        self.assertEqual(self.client.post('/arena/start/',{'level_id':nextlevel.pk}).status_code,403)

    def test_arena_expired_run_gets_no_xp(self):
        from .models import ArenaRun
        self.client.post('/arena/start/',{'level_id':self.level.pk})
        run=ArenaRun.objects.get(user=self.user)
        run.deadline=timezone.now()-timezone.timedelta(seconds=1)
        run.save(update_fields=['deadline'])
        answers={f'q_{pk}':'Hoi' for pk in run.question_ids}
        self.client.post(reverse('arena_run',args=[run.pk]),answers)
        run.refresh_from_db();self.assertEqual(run.score,100)
        self.assertEqual(run.earned_xp,0)

    def test_archived_language_blocks_arena_launch_and_payout(self):
        from .models import ArenaRun, XPEvent
        self.assertEqual(self.client.post('/arena/start/', {'level_id': self.level.pk}).status_code, 302)
        run = ArenaRun.objects.get(user=self.user)
        self.lang.is_published = False
        self.lang.save(update_fields=['is_published'])
        self.assertEqual(self.client.post('/arena/start/', {'level_id': self.level.pk}).status_code, 404)
        answers = {f'q_{pk}': 'Hoi' for pk in run.question_ids}
        self.assertEqual(self.client.post(reverse('arena_run', args=[run.pk]), answers).status_code, 403)
        run.refresh_from_db()
        self.assertIsNone(run.finished_at)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='arena').count(), 0)
        self.assertNotContains(self.client.get('/arena/'), 'Play A0', status_code=200)

    def test_archiving_arena_question_disables_existing_round(self):
        from .models import ArenaRun, XPEvent
        self.assertEqual(self.client.post('/arena/start/', {'level_id': self.level.pk}).status_code, 302)
        run = ArenaRun.objects.get(user=self.user)
        self.lesson.published = False
        self.lesson.save(update_fields=['published'])
        answers = {f'q_{pk}': 'Hoi' for pk in run.question_ids}
        self.assertEqual(self.client.post(reverse('arena_run', args=[run.pk]), answers).status_code, 503)
        run.refresh_from_db()
        self.assertIsNone(run.finished_at)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='arena').count(), 0)

    def test_archived_word_is_not_reviewed_or_rewarded(self):
        from .models import XPEvent
        word = Vocabulary.objects.get(level=self.level)
        card = ReviewCard.objects.create(user=self.user, vocabulary=word, due=timezone.now())
        word.published = False
        word.save(update_fields=['published'])
        self.assertRedirects(self.client.get('/review/'), reverse('word'))
        self.assertEqual(self.client.post('/review/', {'card_id': card.pk, 'quality': 5}).status_code, 404)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='review').count(), 0)

    def test_archived_question_cannot_be_repaired_for_xp(self):
        from .models import MistakeRecord, XPEvent
        self.client.post(reverse('lesson_answer', args=[self.lesson.pk]),
                         {'exercise_id': self.questions[0].pk, 'answer': 'Nee'})
        mistake = MistakeRecord.objects.get(user=self.user, exercise=self.questions[0])
        self.lang.is_published = False
        self.lang.save(update_fields=['is_published'])
        self.assertEqual(self.client.post('/mistakes/', {
            'mistake_id': mistake.pk, 'answer': 'Hoi',
        }).status_code, 404)
        self.assertNotContains(self.client.get('/mistakes/'), 'Question 1', status_code=200)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='mistake').count(), 0)

    def test_daily_chest_needs_learning_and_never_doubles(self):
        from .models import DailyChest,XPEvent
        from .services import award_xp
        self.client.post('/daily-chest/open/')
        self.assertEqual(DailyChest.objects.count(),0)
        award_xp(self.user,20,reason='lesson',event_key='lesson:sample')
        self.client.post('/daily-chest/open/')
        self.assertEqual(DailyChest.objects.count(),1)
        self.client.post('/daily-chest/open/')
        self.user.learning_profile.refresh_from_db()
        self.assertEqual(self.user.learning_profile.xp,30)
        self.assertEqual(XPEvent.objects.filter(reason='chest').count(),1)
        self.assertEqual(self.user.learning_profile.streak,1)

    def test_vocabulary_added_once_and_notifications_private(self):
        from .models import AppNotification
        word=Vocabulary.objects.first()
        self.assertRedirects(self.client.get('/vocabulary/'), reverse('practice_hub'))
        url=reverse('vocabulary_save',args=[word.pk])
        self.assertEqual(self.client.post(url).status_code,410)
        self.assertFalse(ReviewCard.objects.filter(user=self.user,vocabulary=word).exists())
        from .services import award_xp
        award_xp(self.user,200,reason='lesson',event_key='milestone')
        self.assertTrue(AppNotification.objects.filter(user=self.user,read_at__isnull=True).exists())
        self.client.post('/notifications/read/')
        self.assertFalse(AppNotification.objects.filter(user=self.user,read_at__isnull=True).exists())

    def test_actions_require_csrf_and_login(self):
        from django.test import Client
        guest=Client()
        self.assertEqual(guest.get('/daily-chest/').status_code,302)
        guarded=Client(enforce_csrf_checks=True)
        guarded.force_login(self.user)
        self.assertEqual(guarded.post('/daily-chest/open/').status_code,403)
        self.assertEqual(guarded.post('/arena/start/',{'level_id':self.level.pk}).status_code,403)

    def test_ui_translation_keys_have_all_four_languages(self):
        from .ui import TEXT
        expected=set(TEXT['en'])
        for locale in ('en','nl','ckb','ar'):
            self.assertEqual(set(TEXT[locale]),expected)
        response=self.client.get('/service-worker.js')
        self.assertContains(response,'app-v3.css')
        self.assertContains(response,'app-v3.js')

class V3RecoveryCodeTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user=User.objects.create_user('securelearner','secure@example.org','StrongExamplePassword!23')
        profile=self.user.learning_profile
        profile.placement_completed=True
        profile.onboarding_completed=True
        profile.save(update_fields=['placement_completed','onboarding_completed'])
        self.client.force_login(self.user)

    def test_totp_qr_and_single_use_backup_codes(self):
        from .models import Profile
        setup=self.client.get('/mfa/setup/')
        self.assertEqual(setup.status_code,200)
        self.assertContains(setup,'data:image/svg+xml;base64,')
        self.assertIn('no-store',setup['Cache-Control'])
        secret=self.client.session['mfa_setup_secret']
        result=self.client.post('/mfa/setup/',{'code':pyotp.TOTP(secret).now()})
        self.assertRedirects(result,'/mfa/recovery/',fetch_redirect_response=False)
        codes=list(self.client.session['mfa_recovery_codes_once'])
        self.assertEqual(len(set(codes)),8)
        profile=Profile.objects.get(user=self.user)
        self.assertNotIn(codes[0],str(profile.mfa_recovery_hashes))
        reveal=self.client.get('/mfa/recovery/')
        self.assertContains(reveal,codes[0])
        self.assertIn('no-store',reveal['Cache-Control'])
        self.assertRedirects(self.client.get('/mfa/recovery/'),'/profile/',fetch_redirect_response=False)
        self.client.post('/logout/')
        auth=self.client.post('/login/',{'email':'securelearner','password':'StrongExamplePassword!23'})
        self.assertRedirects(auth,'/mfa/verify/',fetch_redirect_response=False)
        verified=self.client.post('/mfa/verify/',{'code':codes[0]})
        self.assertRedirects(verified,'/play/',fetch_redirect_response=False)
        profile.refresh_from_db()
        self.assertEqual(len(profile.mfa_recovery_hashes),7)
        self.client.post('/logout/')
        self.client.post('/login/',{'email':'securelearner','password':'StrongExamplePassword!23'})
        failed=self.client.post('/mfa/verify/',{'code':codes[0]})
        self.assertEqual(failed.status_code,200)
        self.assertNotIn('_auth_user_id',self.client.session)

class FromScratchAuditRegressionTests(TestCase):
    """New regression coverage for account state, private caching and MFA throttling."""
    def setUp(self):
        cache.clear()
        self.user=User.objects.create_user('audit_learner','audit@example.org','StrongValidPassword!2026')
        self.nl=Language.objects.create(code='nl',name='Dutch',slug='dutch-audit',description='Dutch',is_published=True)
        self.fr=Language.objects.create(code='fr',name='French',slug='french-audit',description='French',is_published=True)
        self.draft=Language.objects.create(code='xx',name='Unpublished',slug='draft-audit',description='Draft',is_published=False)
        profile=self.user.learning_profile
        profile.preferred_language=self.nl
        profile.placement_completed=True
        profile.placement_level='B1'
        profile.onboarding_completed=True
        profile.save(update_fields=['preferred_language','placement_completed','placement_level','onboarding_completed'])

    def _profile_values(self, language):
        return {'avatar':'🎓','bio':'','ui_language':'nl','daily_goal_xp':'20',
                'preferred_language':language,'leaderboard_opt_in':'',
                'social_opt_in':'','reminder_opt_in':'','summary_opt_in':'','ai_opt_in':''}

    def test_changing_learning_language_resets_placement(self):
        self.client.force_login(self.user)
        response=self.client.post('/profile/',self._profile_values(self.fr.pk))
        self.assertEqual(response.status_code,302)
        profile=Profile.objects.get(user=self.user)
        self.assertEqual(profile.preferred_language_id,self.fr.pk)
        self.assertFalse(profile.placement_completed)
        self.assertEqual(profile.placement_level,'A0')

    def test_same_learning_language_keeps_placement(self):
        self.client.force_login(self.user)
        response=self.client.post('/profile/',self._profile_values(self.nl.pk))
        self.assertEqual(response.status_code,302)
        profile=Profile.objects.get(user=self.user)
        self.assertTrue(profile.placement_completed)
        self.assertEqual(profile.placement_level,'B1')

    def test_unpublished_language_cannot_be_selected_in_profile(self):
        self.client.force_login(self.user)
        response=self.client.post('/profile/',self._profile_values(self.draft.pk))
        self.assertEqual(response.status_code,200)
        self.assertIn('preferred_language',response.context['form'].errors)
        self.assertEqual(Profile.objects.get(user=self.user).preferred_language_id,self.nl.pk)

    @patch('academy.views.send_mail',side_effect=OSError('SMTP unavailable'))
    def test_signup_succeeds_without_mailer_and_does_not_send_verification(self,send_mock):
        data={'username':'new_audit_user','email':'newaudit@example.org',
              'password1':'StrongValidPassword!2026','age_confirmed':'on'}
        response=self.client.post('/register/',data)
        self.assertRedirects(response,'/onboarding/',fetch_redirect_response=False)
        user=User.objects.get(username='new_audit_user')
        self.assertTrue(user.is_active)
        self.assertIsNone(user.learning_profile.email_verified_at)
        self.assertEqual(send_mock.call_count,0)

    @patch('academy.views.send_mail',side_effect=OSError('Welcome mail unavailable'))
    def test_welcome_email_outage_does_not_undo_verification(self,send_mock):
        from academy.email_verification_tokens import email_verification_token_generator
        from django.utils.http import urlsafe_base64_encode
        from django.utils.encoding import force_bytes
        self.user.is_active=False
        self.user.save(update_fields=['is_active'])
        url=reverse('verify_email',args=[
            urlsafe_base64_encode(force_bytes(self.user.pk)),
            email_verification_token_generator.make_token(self.user)])
        preview=self.client.get(url)
        self.assertEqual(preview.status_code,200)
        self.user.refresh_from_db()
        self.assertFalse(self.user.is_active)
        response=self.client.post(url)
        self.assertRedirects(response,'/login/',fetch_redirect_response=False)
        self.user.refresh_from_db()
        self.assertTrue(self.user.is_active)
        self.assertIsNotNone(self.user.learning_profile.email_verified_at)
        self.assertEqual(send_mock.call_count,1)

    def test_private_pages_are_never_cached(self):
        self.client.force_login(self.user)
        response=self.client.get('/profile/')
        self.assertEqual(response.status_code,200)
        self.assertIn('no-store',response['Cache-Control'])
        self.client.logout()
        response=self.client.get('/login/')
        self.assertIn('no-store',response['Cache-Control'])

    def test_disabling_mfa_is_rate_limited(self):
        profile=self.user.learning_profile
        profile.totp_secret='JBSWY3DPEHPK3PXP'
        profile.save(update_fields=['totp_secret'])
        self.client.force_login(self.user)
        for _ in range(6):
            self.assertEqual(self.client.post('/mfa/disable/',{'code':'not-a-code'}).status_code,403)
        self.assertEqual(self.client.post('/mfa/disable/',{'code':'not-a-code'}).status_code,429)
        self.assertTrue(Profile.objects.get(user=self.user).totp_secret)

    def test_mobile_profile_includes_real_logout_post(self):
        self.client.force_login(self.user)
        response=self.client.get('/profile/')
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'Sign out securely on this device.')
        self.assertContains(response,'Log out')

    def test_review_submissions_are_rate_limited(self):
        word=Vocabulary.objects.create(level=Level.objects.create(language=self.nl,code='A0',description='Intro',order=0),
                                       word='testwoord',translation='test',pronunciation='test',example='test',published=True)
        card=ReviewCard.objects.create(user=self.user,vocabulary=word)
        self.client.force_login(self.user)
        with patch('academy.views.rate_limit',return_value=True) as limiter:
            response=self.client.post('/review/',{'card_id':card.pk,'quality':'5'})
        self.assertEqual(response.status_code,429)
        self.assertEqual(limiter.call_args.args[1:], ('review-submit',80,3600,True))

class ReleaseHardeningTests(TestCase):
    """Runtime regressions for publish-state and answer validation.

    Run with: python manage.py test academy.tests.ReleaseHardeningTests --verbosity 2
    These must still be executed in an environment with Django installed.
    """
    def setUp(self):
        cache.clear()
        self.user = User.objects.create_user(
            username='releaselearner', email='release@example.org',
            password='StrongExamplePassword!23',
        )
        self.client.force_login(self.user)
        self.language = Language.objects.create(
            code='nl', slug='dutch-release', name='Dutch',
            description='Learn Dutch', is_published=True,
        )
        self.level = Level.objects.create(language=self.language, code='A0', order=0, description='Start')
        self.unit = Unit.objects.create(
            level=self.level, slug='unit-release', title='Basics', summary='Start', published=True,
        )
        self.lesson = Lesson.objects.create(
            unit=self.unit, slug='first-release', title='First',
            skill='reading', content='Hello', published=True,
        )
        self.exercise = Exercise.objects.create(
            lesson=self.lesson, kind='mcq', prompt='Translate',
            options=['Hoi', 'Nee'], answer='Hoi', explanation='Hoi is correct.',
        )
        self.profile = self.user.learning_profile
        self.profile.preferred_language = self.language
        self.profile.placement_completed = True
        self.profile.onboarding_completed = True
        self.profile.save()

    def test_legacy_post_rejects_forged_multiple_choice_and_does_not_reward(self):
        response = self.client.post(
            self.lesson.get_absolute_url(),
            {f'answer_{self.exercise.pk}': 'Not a real option'},
        )
        self.assertEqual(response.status_code, 400)
        self.assertFalse(LessonProgress.objects.filter(user=self.user, lesson=self.lesson).exists())
        self.assertEqual(XPEvent.objects.filter(user=self.user).count(), 0)
        valid = self.client.post(
            self.lesson.get_absolute_url(), {f'answer_{self.exercise.pk}': 'Hoi'},
        )
        self.assertEqual(valid.status_code, 200)
        self.assertTrue(LessonProgress.objects.filter(user=self.user, lesson=self.lesson).exists())

    def test_withdrawn_course_cannot_start_or_repeat_assessments(self):
        unit_url = reverse('assessment_unit', args=[self.unit.pk])
        level_url = reverse('assessment_level', args=[self.level.pk])
        self.language.is_published = False
        self.language.save(update_fields=['is_published'])
        self.assertEqual(self.client.get(unit_url).status_code, 404)
        self.assertEqual(self.client.post(unit_url, {}).status_code, 404)
        self.assertEqual(self.client.get(level_url).status_code, 404)
        self.assertEqual(self.client.post(level_url, {}).status_code, 404)

    def test_unpublished_lesson_is_excluded_from_path_progress(self):
        from .views import _learning_path_data
        other = Lesson.objects.create(
            unit=self.unit, slug='hidden-release', title='Hidden',
            skill='reading', content='Hidden', published=False,
        )
        LessonProgress.objects.create(user=self.user, lesson=self.lesson, score=100)
        LessonProgress.objects.create(user=self.user, lesson=other, score=100)
        route = _learning_path_data(self.user)
        self.assertEqual(route['total_lessons'], 1)
        self.assertEqual(route['done_lessons'], 1)
        self.assertEqual(route['progress_percent'], 100)
        self.assertEqual(route['stages'][0]['items'][0]['done'], 1)

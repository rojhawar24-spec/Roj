"""Read-only Django content quality checks for managers and release checks.

The checks are deliberately narrow and conservative. Passing means *data
consistency*, never that language pedagogy, native audio or CEFR accuracy
has been independently verified.
"""
from .models import Language, Level, Unit, Lesson, Exercise, Vocabulary, GrammarTopic
from .quality_rules import check_exercise
from .assessment_policy_v103 import assessment_ready
from .learning_content_policy_v100 import classify_lesson_publication, classify_unit_assessment


def audit_published_content(max_issues=30):
    issues = []
    totals = {'languages': 0, 'units': 0, 'lessons': 0, 'questions': 0, 'words': 0}
    def add(severity, code, message):
        issues.append({'severity': severity, 'code': code, 'message': str(message)[:240]})

    languages = list(Language.objects.filter(is_published=True).order_by('pk'))
    totals['languages'] = len(languages)
    if not languages:
        add('warning', 'no-course', 'No language course is published yet.')
    for language in languages:
        levels = list(Level.objects.filter(language=language).order_by('order'))
        if not levels:
            add('error', 'course-no-level', f'{language.name}: no levels exist.')
        for level in levels:
            units = list(Unit.objects.filter(level=level, published=True).order_by('order'))
            if not units:
                add('warning', 'level-empty', f'{language.name} {level.code}: no published units.')
            for unit in units:
                totals['units'] += 1
                if not isinstance(unit.outcomes, list) or not any(str(outcome).strip() for outcome in unit.outcomes):
                    add('warning', 'unit-outcomes', f'{unit.title}: add measurable learning outcomes.')
                lessons = list(Lesson.objects.filter(unit=unit, published=True).order_by('order'))
                if not lessons:
                    add('error', 'unit-no-lessons', f'{unit.title}: published unit has no published lessons.')
                question_groups = []
                for lesson in lessons:
                    totals['lessons'] += 1
                    if not lesson.content.strip():
                        add('error', 'lesson-no-content', f'{lesson.title}: lesson text is empty.')
                    questions = list(Exercise.objects.filter(lesson=lesson).order_by('pk'))
                    # V100: classify failures that cause live learner 409s and
                    # the remaining legacy exercise types. Read-only audit;
                    # no progress, publication, or learner records are changed.
                    kinds = [question.kind for question in questions]
                    question_groups.append([q.kind for q in questions if assessment_ready(q, language.code)])
                    lesson_audio_ready = None
                    activity_audio_ready = None
                    if lesson.skill == 'listening':
                        from .audio_v78 import approved_audio_url
                        lesson_audio_ready = bool(approved_audio_url(lesson.audio_text, language.code))
                    if 'listening' in kinds:
                        from .lesson_activities_v58 import student_ready
                        activity_audio_ready = all(student_ready(question, language.code)
                                                   for question in questions if question.kind == 'listening')
                    for risk in classify_lesson_publication(
                            lesson.skill, kinds, lesson_audio_ready=lesson_audio_ready,
                            listening_activity_audio_ready=activity_audio_ready):
                        add(risk['severity'], risk['code'], f"{lesson.title}: {risk['detail']}")
                    from .lesson_readiness_v96 import lesson_block_reason
                    if lesson_block_reason(lesson, course_code=language.code, exercises=questions):
                        add('error', 'lesson-not-playable', f'{lesson.title}: published lesson is not playable under the five-kind policy.')
                    for question in questions:
                        totals['questions'] += 1
                        for severity, code, detail in check_exercise(question.kind, question.prompt,
                                question.options, question.answer, question.explanation, question.activity_data):
                            add(severity, code, f'{lesson.title}, question {question.pk}: {detail}')
                if lessons:
                    # The assessment route selects the five validated activity kinds.
                    # Flag a unit that would finish lessons but cannot open a test.
                    for risk in classify_unit_assessment(question_groups):
                        add(risk['severity'], risk['code'], f"{unit.title}: {risk['detail']}")
            for word in Vocabulary.objects.filter(level=level, published=True):
                totals['words'] += 1
                if not word.translation.strip():
                    add('error', 'word-no-translation', f'{language.name} {level.code}: {word.word} needs a translation.')
                if not word.example.strip():
                    add('warning', 'word-no-context', f'{language.name} {level.code}: {word.word} needs a usage example.')
            for topic in GrammarTopic.objects.filter(level=level, published=True):
                if topic.check_options and topic.check_answer not in topic.check_options:
                    add('error', 'grammar-key', f'{topic.title}: correct answer absent from published grammar options.')

    errors=sum(item['severity']=='error' for item in issues)
    warnings=len(issues)-errors
    return {'totals': totals, 'errors': errors, 'warnings': warnings,
            'issues': issues[:max(0,int(max_issues))], 'truncated': len(issues)>max(0,int(max_issues)),
            'editorial_review_required': True}

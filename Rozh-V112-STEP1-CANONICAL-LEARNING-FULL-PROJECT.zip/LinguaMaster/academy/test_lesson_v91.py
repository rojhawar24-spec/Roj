"""Lesson-interface regressions: real short answers and safe locale transport."""
from html.parser import HTMLParser
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse

from .models import Exercise, Language, Lesson, LessonProgress, Level, Profile, Unit, XPEvent
from .ui import ASSESSMENT_TEXT, LESSON_TEXT, TEXT


class LessonMarkup(HTMLParser):
    def __init__(self, html):
        super().__init__(convert_charrefs=True)
        self.root = {}
        self.inputs = []
        self.images = []
        self.feed(html)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'data-lesson-root' in attrs:
            self.root = attrs
        if tag == 'input':
            self.inputs.append(attrs)
        if tag == 'img':
            self.images.append(attrs)


class LessonInterfaceV91Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user('lesson-ui', 'lesson@example.org', 'StrongPassword!2026')
        cls.language = Language.objects.create(code='nl', name='Dutch', slug='dutch-lesson-ui', description='Dutch', is_published=True)
        cls.level = Level.objects.create(language=cls.language, code='A0', description='Start', order=0)
        cls.unit = Unit.objects.create(level=cls.level, slug='hello-ui', title='Greetings', summary='Start', published=True)
        cls.lesson = Lesson.objects.create(unit=cls.unit, slug='short-ui', title='Original Dutch title',
                                          skill='writing', content='Original authored course text.', published=True)
        cls.short = Exercise.objects.create(lesson=cls.lesson, kind='fill_blank', prompt='Original authored prompt? ___',
                                           answer='Goedemorgen', explanation='Original authored explanation.')
        cls.mcq = Lesson.objects.create(unit=cls.unit, slug='mcq-ui', title='Multiple choice',
                                        skill='reading', content='Original multiple-choice content.', published=True)
        Exercise.objects.create(lesson=cls.mcq, kind='mcq', prompt='A greeting?', options=['Hoi', 'Nee'],
                                answer='Hoi', explanation='Hoi is a greeting.')
        profile = cls.user.learning_profile
        profile.preferred_language = cls.language
        profile.placement_completed = True
        profile.onboarding_completed = True
        profile.save()

    def setUp(self):
        cache.clear()
        self.client.force_login(self.user)

    def locale(self, value):
        Profile.objects.filter(user=self.user).update(ui_language=value)

    def test_short_answer_field_is_explicit_text_and_answer_key_is_not_rendered(self):
        response = self.client.get(self.lesson.get_absolute_url())
        self.assertEqual(response.status_code, 200)
        markup = LessonMarkup(response.content.decode())
        short = next(field for field in markup.inputs if field.get('name') == f'answer_{self.short.pk}')
        self.assertEqual(short.get('type'), 'text')
        self.assertNotContains(response, self.short.answer)
        self.assertContains(response, 'id="lessonProgress" max="100" value="10" aria-label="Lesson progress"')
        self.assertContains(response, 'id="lessonFinishTitle" tabindex="-1"')

    def test_short_answer_is_server_graded_and_completion_awards_xp_once(self):
        token = self.client.get(self.lesson.get_absolute_url()).context['lesson_round_key']
        url = reverse('lesson_answer', args=[self.lesson.pk])
        result = self.client.post(url, {'exercise_id': self.short.pk, 'answer': '  GOEDEMORGEN  ', 'round_key':token})
        self.assertEqual(result.status_code, 200)
        self.assertTrue(result.json()['correct'])
        self.assertTrue(result.json()['completed'])
        self.assertEqual(result.json()['xp_awarded'], 20)
        self.assertEqual(LessonProgress.objects.get(user=self.user, lesson=self.lesson).score, 100)
        repeated = self.client.post(url, {'exercise_id': self.short.pk, 'answer': 'Goedemorgen', 'round_key':token})
        self.assertEqual(repeated.json()['xp_awarded'], 0)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='lesson').count(), 1)

    def test_all_supported_locales_render_complete_interactive_labels(self):
        for locale in ('en', 'nl', 'ckb', 'ar'):
            with self.subTest(locale=locale):
                self.locale(locale)
                response = self.client.get(self.lesson.get_absolute_url())
                markup = LessonMarkup(response.content.decode())
                labels = {name: value for name, value in markup.root.items() if name.startswith('data-label-')}
                self.assertEqual(labels['data-label-check'], TEXT[locale]['lesson_check'])
                self.assertEqual(labels['data-label-question-count'], TEXT[locale]['lesson_question_count'])
                self.assertEqual(labels['data-label-answer-required'], TEXT[locale]['lesson_answer_required'])
                self.assertTrue(all(labels.values()), labels)
                self.assertContains(response, TEXT[locale]['lesson_intro'])
                self.assertContains(response, 'Original authored course text.')
                self.assertContains(response, 'Original authored prompt?')
                self.assertContains(response, 'dir="rtl"' if locale in ('ckb', 'ar') else 'dir="ltr"')

    def test_locale_attributes_escape_quotes_and_html_without_inserting_elements(self):
        self.locale('nl')
        malicious = '"><img src=x onerror=alert(1)> & "quoted"'
        with patch.dict(TEXT['nl'], {'lesson_question_help': malicious}):
            response = self.client.get(self.lesson.get_absolute_url())
        markup = LessonMarkup(response.content.decode())
        self.assertEqual(markup.root['data-label-question-help'], malicious)
        self.assertFalse(any(image.get('src') == 'x' for image in markup.images))

    def test_lesson_and_assessment_translation_keys_have_parity(self):
        for group in (LESSON_TEXT, ASSESSMENT_TEXT):
            expected = set(group['en'])
            for locale in ('nl', 'ckb', 'ar'):
                self.assertEqual(set(group[locale]), expected)
                self.assertTrue(all(group[locale].values()))
        for locale in ('en', 'nl', 'ckb', 'ar'):
            counter = TEXT[locale]['lesson_question_count']
            self.assertIn('{current}', counter)
            self.assertIn('{total}', counter)

    def test_assessment_controls_and_counter_use_same_locale(self):
        Profile.objects.filter(user=self.user).update(placement_completed=False)
        for locale in ('nl', 'ckb', 'ar'):
            with self.subTest(locale=locale):
                self.locale(locale)
                response = self.client.get('/placement/')
                self.assertEqual(response.status_code, 200)
                self.assertContains(response, TEXT[locale]['assessment_show'])
                self.assertContains(response, TEXT[locale]['assessment_finish'])
                self.assertContains(response, f'data-label-question-count="{TEXT[locale]["lesson_question_count"]}"')
                self.assertContains(response, f'aria-label="{TEXT[locale]["assessment_progress"]}"')

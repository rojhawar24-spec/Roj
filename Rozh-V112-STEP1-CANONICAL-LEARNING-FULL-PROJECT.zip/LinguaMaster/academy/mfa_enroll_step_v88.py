"""V88 MFA enrollment: bind the accepted TOTP to its exact time-step.

The previous implementation accepted an adjacent-step code but persisted the
*current* step. That could allow a future-step code to be accepted again later.
This helper is framework-independent and does not record secrets or tokens.
"""
import time


def matched_enrollment_step(token, code, *, now=None):
    """Return the EXACT matched step for a six-digit OTP in the ±1 window.

    Return None if invalid/expired. For rare numeric-code collisions across
    steps, conservatively mark the latest matching step as consumed.
    """
    if not isinstance(code, str) or len(code) != 6 or not code.isascii() or not code.isdigit():
        return None
    interval = getattr(token, 'interval', None)
    if type(interval) is not int or interval <= 0:
        return None
    observed = time.time() if now is None else now
    if type(observed) not in (int, float) or observed < 0:
        return None
    current_step = int(observed) // interval
    matched = []
    for step in (current_step - 1, current_step, current_step + 1):
        if step >= 0 and token.verify(code, for_time=step * interval, valid_window=0):
            matched.append(step)
    return max(matched, default=None)

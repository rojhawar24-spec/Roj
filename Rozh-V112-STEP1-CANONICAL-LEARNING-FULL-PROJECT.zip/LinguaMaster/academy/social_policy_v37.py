"""Pure fail-closed policy for positive social actions and avatar changes.

Friend removals, blocks and unblocks remain usable for privacy cleanup even
when social opt-in is disabled; they cannot create a new positive connection.
Use *locked, freshly loaded* profiles for any database-mutating permission check.
"""


def social_access_allowed(profile, *, user_active, require_opt_in=True):
    return bool(
        profile is not None
        and user_active
        and getattr(profile, 'suspended_at', None) is None
        and not getattr(profile, 'legacy_review_required', True)
        and (not getattr(profile, 'onboarding_required', True)
             or getattr(profile, 'onboarding_completed', False))
        and (not require_opt_in or getattr(profile, 'social_opt_in', False))
    )

"""V38 real-ORM/Django HTTP ranking tests — must run in isolated Django QA."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import XPEvent

class RankingV38HttpTests(TestCase):
    def new_user(self, username, *, xp=0, points=0, consent=True):
        user=get_user_model().objects.create_user(username=username,password='StrongV38TestingPass!')
        profile=user.learning_profile
        profile.leaderboard_opt_in=consent
        profile.xp=xp
        profile.save(update_fields=['leaderboard_opt_in','xp'])
        if points:
            XPEvent.objects.create(user=user,amount=points,reason='lesson',event_key='v38-'+username)
        return user

    def ranking(self, period='all'):
        response=self.client.get(reverse('leaderboard'),{'period':period})
        self.assertEqual(response.status_code,200)
        return response.context['leaders']

    def test_public_alltime_and_week_are_visible_for_consented_active_accounts(self):
        self.new_user('v38_allowed',xp=101,points=7)
        for period in ('all','week'):
            self.assertEqual([r['username'] for r in self.ranking(period)],['v38_allowed'])

    def test_opted_out_user_hidden_in_both_periods(self):
        self.new_user('v38_private',xp=200,points=100,consent=False)
        for period in ('all','week'):
            self.assertFalse(self.ranking(period))

    def test_suspended_user_hidden_without_erasing_xp_or_consent(self):
        user=self.new_user('v38_suspended',xp=400,points=40)
        profile=user.learning_profile
        from django.utils import timezone
        profile.suspended_at=timezone.now()
        profile.save(update_fields=['suspended_at'])
        for period in ('all','week'):
            self.assertFalse(self.ranking(period))
        profile.refresh_from_db()
        self.assertEqual(profile.xp,400)
        self.assertTrue(profile.leaderboard_opt_in)

    def test_historical_review_hold_hidden(self):
        user=self.new_user('v38_review',xp=400,points=40)
        profile=user.learning_profile
        profile.legacy_review_required=True
        profile.save(update_fields=['legacy_review_required'])
        for period in ('all','week'):
            self.assertFalse(self.ranking(period))

    def test_required_onboarding_hidden_and_legacy_not_required_allowed(self):
        user=self.new_user('v38_awaiting',xp=400,points=40)
        p=user.learning_profile
        p.onboarding_required=True
        p.onboarding_completed=False
        p.save(update_fields=['onboarding_required','onboarding_completed'])
        for period in ('all','week'):
            self.assertFalse(self.ranking(period))
        p.onboarding_required=False
        p.save(update_fields=['onboarding_required'])
        for period in ('all','week'):
            self.assertEqual([row['username'] for row in self.ranking(period)],['v38_awaiting'])

    def test_deactivated_user_hidden(self):
        user=self.new_user('v38_deactivated',xp=500,points=70)
        user.is_active=False
        user.save(update_fields=['is_active'])
        for period in ('all','week'):
            self.assertFalse(self.ranking(period))

    def test_invalid_account_must_be_filtered_before_top_thirty(self):
        allowed=self.new_user('v38_final_eligible',xp=1,points=1)
        from django.utils import timezone
        for n in range(31):
            user=self.new_user('v38_hidden_%02d'%n,xp=1000+n,points=1000+n)
            p=user.learning_profile
            p.suspended_at=timezone.now()
            p.save(update_fields=['suspended_at'])
        for period in ('all','week'):
            names=[row['username'] for row in self.ranking(period)]
            self.assertEqual(names,[allowed.username])

    def test_nonlearning_events_do_not_inflate_week(self):
        u=self.new_user('v38_chest',xp=40)
        XPEvent.objects.create(user=u,amount=40,reason='chest',event_key='v38-chest')
        self.assertFalse(self.ranking('week'))

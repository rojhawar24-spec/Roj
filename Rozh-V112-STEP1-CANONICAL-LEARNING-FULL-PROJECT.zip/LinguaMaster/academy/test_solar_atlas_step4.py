"""Run on an isolated Django TestCase database; never on a production DB."""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse, resolve

from .models import Profile
from .progress_models import LearningPreferences
from .social_models import AvatarStyle
from .progress_v9 import profile as active_profile


class SolarAtlasStep4ProfileTests(TestCase):
    def setUp(self):
        cache.clear()
        User = get_user_model()
        self.user = User.objects.create_user('solar_step4', 'step4@example.test', 'ExcellentPass2026!')
        self.other = User.objects.create_user('other_step4', 'other@example.test', 'ExcellentPass2026!')
        self.client.force_login(self.user)

    def test_active_route_is_legacy_compatible_progress_view(self):
        self.assertIs(resolve('/profile/').func, active_profile)
        self.assertEqual(reverse('profile'), '/profile/')

    def test_profile_get_uses_real_private_data_and_solar_template(self):
        result = self.client.get(reverse('profile'))
        self.assertEqual(result.status_code, 200)
        self.assertTemplateUsed(result, 'academy/profile.html')
        self.assertContains(result, 'solar-profile-hero')
        self.assertContains(result, 'step4@example.test')
        self.assertNotContains(result, 'other@example.test')
        self.assertContains(result, 'name="csrfmiddlewaretoken"')
        self.assertContains(result, 'solar-atlas-step4.css')
        self.assertEqual(result.context['progress']['daily_earned'], 0)

    def test_unauthenticated_cannot_view_private_profile(self):
        self.client.logout()
        response = self.client.get(reverse('profile'))
        self.assertEqual(response.status_code, 302)
        self.assertIn('/login/', response.url)

    def test_profile_settings_change_without_xp_or_course_reset(self):
        profile = self.user.learning_profile
        Profile.objects.filter(pk=profile.pk).update(xp=125, coins=11, streak=2)
        response = self.client.post(reverse('profile'), {
            'avatar':'🎓', 'bio':'My learning journey', 'ui_language':'nl',
            'daily_goal_xp':'35', 'preferred_language':'',
            'social_opt_in':'on', 'leaderboard_opt_in':'on',
            'preferences-timezone_name':'Europe/Brussels',
            'preferences-theme':'dark', 'preferences-reduce_motion':'on',
        })
        self.assertEqual(response.status_code, 302)
        profile.refresh_from_db()
        self.assertEqual(profile.daily_goal_xp, 35)
        self.assertEqual(profile.ui_language, 'nl')
        self.assertEqual(profile.xp, 125)
        self.assertEqual(profile.coins, 11)
        self.assertEqual(profile.streak, 2)
        self.assertTrue(profile.social_opt_in)
        prefs = LearningPreferences.objects.get(user=self.user)
        self.assertEqual((prefs.theme, prefs.timezone_name, prefs.reduce_motion), ('dark','Europe/Brussels',True))

    def test_invalid_timezone_does_not_persist_profile_updates(self):
        response = self.client.post(reverse('profile'), {
            'avatar':'🎓','bio':'New bio','ui_language':'nl','daily_goal_xp':'50',
            'preferred_language':'', 'preferences-timezone_name':'Invalid/Nowhere',
            'preferences-theme':'light',
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'solar-profile-errors')
        self.user.learning_profile.refresh_from_db()
        self.assertNotEqual(self.user.learning_profile.daily_goal_xp, 50)

    def test_privacy_choices_do_not_inherit_other_users_consent(self):
        Profile.objects.filter(user=self.other).update(ai_opt_in=True, social_opt_in=True)
        response = self.client.get(reverse('profile'))
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.context['form'].initial.get('ai_opt_in', False))
        self.assertFalse(response.context['form'].initial.get('social_opt_in', False))

    def test_avatar_get_and_locked_palette_rejected_without_xp_change(self):
        page = self.client.get(reverse('avatar_studio'))
        self.assertEqual(page.status_code, 200)
        self.assertContains(page, 'solar-avatar-page')
        self.assertContains(page, 'name="csrfmiddlewaretoken"')
        response = self.client.post(reverse('avatar_studio'), {
            'avatar':'🎓','palette':'forest','accessory':'none'
        })
        self.assertEqual(response.status_code, 302)
        style = AvatarStyle.objects.get(user=self.user)
        self.assertEqual(style.palette, 'sky')
        self.assertEqual(self.user.learning_profile.xp, 0)

    def test_valid_avatar_update_only_cosmetic(self):
        response = self.client.post(reverse('avatar_studio'), {
            'avatar':'🌱','palette':'sand','accessory':'none'
        })
        self.assertEqual(response.status_code, 302)
        self.user.learning_profile.refresh_from_db()
        self.assertEqual(self.user.learning_profile.avatar, '🌱')
        self.assertEqual(AvatarStyle.objects.get(user=self.user).palette, 'sand')
        self.assertEqual(self.user.learning_profile.xp, 0)

    def test_each_interface_locale_gets_translated_step4_copy(self):
        from .solar_profile_copy import for_language
        for locale in ('nl','en','ckb','ar'):
            Profile.objects.filter(user=self.user).update(ui_language=locale)
            self.user.learning_profile.refresh_from_db()
            response=self.client.get(reverse('profile'))
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.context['S4']['learning'], for_language(locale)['learning'])

    def test_avatar_endpoint_no_side_effect_from_get(self):
        self.client.get(reverse('avatar_studio'))
        old=self.user.learning_profile.avatar
        self.user.learning_profile.refresh_from_db()
        self.assertEqual(self.user.learning_profile.avatar, old)

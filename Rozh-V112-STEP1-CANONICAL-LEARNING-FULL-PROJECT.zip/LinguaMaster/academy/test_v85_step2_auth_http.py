"""V85 TRUE Django integration suite — execute ONLY on disposable QA database.

No claims of passing results until Django dependencies are installed and this
module is executed through manage.py test with config.settings_local_qa.
"""
import pyotp
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.test import Client, TestCase
from django.urls import reverse
from django.utils import timezone
from .manager_roles_v48 import MANAGER_GROUP
from .models import AuditEvent, Profile


class Step2AuthenticationAndAuthorizationHTTP(TestCase):
    PASS='V85-QA-Only-Strong-Password!'
    SECRET='JBSWY3DPEHPK3PXP'

    @classmethod
    def setUpTestData(cls):
        User=get_user_model()
        cls.learner=User.objects.create_user('v85learner','v85learner@example.invalid',cls.PASS)
        cls.manager=User.objects.create_user('v85manager','v85manager@example.invalid',cls.PASS)
        cls.staff=User.objects.create_user('v85staff','v85staff@example.invalid',cls.PASS,is_staff=True)
        cls.owner=User.objects.create_superuser('v85owner','v85owner@example.invalid',cls.PASS)
        Group.objects.get_or_create(name=MANAGER_GROUP)[0].user_set.add(cls.manager)
        for user in (cls.learner,cls.manager,cls.staff,cls.owner):
            profile=user.learning_profile
            profile.email_verified_at=timezone.now()
            profile.totp_secret=cls.SECRET
            profile.save(update_fields=['email_verified_at','totp_secret'])

    def as_user(self,user,mfa=True,csrf=False):
        self.client=Client(enforce_csrf_checks=csrf)
        self.client.force_login(user)
        session=self.client.session
        session['mfa_verified_id']=user.pk if mfa else None
        session.save()

    def test_01_anonymous_all_manager_reads_redirect(self):
        for name in ('manager','manager_users','manager_ai_v79','manager_readiness_v79','manager_audit'):
            with self.subTest(route=name):
                self.assertEqual(self.client.get(reverse(name)).status_code,302)

    def test_02_student_denied_all_manager_reads_even_with_forged_mfa_id(self):
        self.as_user(self.learner)
        for name in ('manager','manager_users','manager_ai_v79','manager_readiness_v79','manager_audit'):
            with self.subTest(route=name):
                self.assertEqual(self.client.get(reverse(name)).status_code,403)

    def test_03_manager_requires_same_user_mfa(self):
        self.as_user(self.manager,mfa=False)
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)
        session=self.client.session
        session['mfa_verified_id']=self.learner.pk;session.save()
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)

    def test_04_authorized_manager_gets_manager_read_pages(self):
        self.as_user(self.manager)
        for name in ('manager','manager_users','manager_ai_v79','manager_readiness_v79','manager_audit'):
            with self.subTest(route=name):
                self.assertEqual(self.client.get(reverse(name)).status_code,200)

    def test_05_authorized_owner_gets_manager_pages(self):
        self.as_user(self.owner)
        self.assertEqual(self.client.get(reverse('manager')).status_code,200)
        self.assertEqual(self.client.get(reverse('manager_ai_v79')).status_code,200)

    def test_06_django_staff_cannot_gain_rozh_manager_pages(self):
        self.as_user(self.staff)
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)

    def test_07_revoke_manager_group_during_session_revokes_login(self):
        # V93+ invalidates the *entire* authenticated session when its group
        # fingerprint changes. An HTTP 302 to login is more secure than the
        # former view-level 403, as long as the old session is actually gone.
        self.as_user(self.manager)
        self.assertEqual(self.client.get(reverse('manager')).status_code,200)
        self.manager.groups.clear()
        response = self.client.get(reverse('manager'))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response['Location'], reverse('login'))
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_08_suspend_manager_during_session_immediately_denies(self):
        self.as_user(self.manager)
        Profile.objects.filter(user=self.manager).update(suspended_at=timezone.now())
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)

    def test_09_revoke_manager_email_proof_during_session_immediately_denies(self):
        self.as_user(self.manager)
        Profile.objects.filter(user=self.manager).update(email_verified_at=None)
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)

    def test_10_missing_profile_fails_closed_no_500(self):
        self.as_user(self.manager)
        Profile.objects.filter(user=self.manager).delete()
        response=self.client.get(reverse('manager'))
        self.assertEqual(response.status_code,403)

    def test_11_direct_permission_grant_invalidates_delegated_manager(self):
        # The V93 privilege fingerprint revokes the WHOLE old session before
        # manager_only runs.  A redirect to login plus missing auth session
        # is stricter than an isolated 403, and must be asserted explicitly.
        self.as_user(self.manager)
        permission=Permission.objects.filter(content_type__app_label='auth').first()
        self.assertIsNotNone(permission)
        self.manager.user_permissions.add(permission)
        response=self.client.get(reverse('manager'))
        self.assertEqual(response.status_code,302)
        self.assertEqual(response['Location'],reverse('login'))
        self.assertNotIn('_auth_user_id',self.client.session)
        self.assertIn('no-store',response['Cache-Control'])

    def test_12_non_owner_cannot_award_or_promote_users(self):
        self.as_user(self.manager)
        self.assertEqual(self.client.post(reverse('manager_award')).status_code,403)
        self.assertEqual(self.client.post(reverse('manager_user_action',args=[self.learner.pk,'promote'])).status_code,403)

    def test_13_manager_mutations_reject_get_and_wrong_verbs(self):
        self.as_user(self.owner)
        path=reverse('manager_user_action',args=[self.learner.pk,'block'])
        self.assertEqual(self.client.get(path).status_code,405)
        self.assertEqual(self.client.put(path,data='').status_code,405)

    def test_14_manager_console_accepts_only_get_and_post(self):
        self.as_user(self.owner)
        self.assertEqual(self.client.put(reverse('manager'),data='').status_code,405)
        self.assertEqual(self.client.delete(reverse('manager')).status_code,405)

    def test_15_manager_users_read_only(self):
        self.as_user(self.owner)
        self.assertEqual(self.client.post(reverse('manager_users'),{}).status_code,405)

    def test_16_sensitive_mutations_require_real_csrf_token(self):
        self.as_user(self.owner,csrf=True)
        target=reverse('manager_user_action',args=[self.learner.pk,'block'])
        response=self.client.post(target,{})
        self.assertEqual(response.status_code,403)
        self.learner.refresh_from_db()
        self.assertTrue(self.learner.is_active)

    def test_17_manager_ai_changes_require_real_csrf_token(self):
        self.as_user(self.manager,csrf=True)
        response=self.client.post(reverse('manager_ai_v79'),{'ai_enabled':'on'})
        self.assertEqual(response.status_code,403)

    def test_18_private_manager_responses_are_uncacheable(self):
        self.as_user(self.owner)
        for name in ('manager','manager_users','manager_ai_v79'):
            with self.subTest(route=name):
                response=self.client.get(reverse(name))
                self.assertIn('no-store',response['Cache-Control'])

    def test_19_admin_requires_mfa_and_staff_role(self):
        self.as_user(self.owner,mfa=False)
        self.assertEqual(self.client.get('/secure-admin/').status_code,302)
        self.as_user(self.owner,mfa=True)
        self.assertEqual(self.client.get('/secure-admin/').status_code,200)
        self.as_user(self.manager,mfa=True)
        self.assertEqual(self.client.get('/secure-admin/').status_code,302)

    def test_20_private_progress_cannot_be_retargeted_with_user_id_query(self):
        self.as_user(self.learner)
        Profile.objects.filter(user=self.learner).update(xp=17)
        Profile.objects.filter(user=self.owner).update(xp=999)
        response=self.client.get('/api/me/progress/',{'user_id':self.owner.pk})
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.json()['xp'],17)

    def test_21_anonymous_private_progress_denied(self):
        self.client=Client()
        self.assertIn(self.client.get('/api/me/progress/').status_code,(401,403))

    def test_22_removed_mfa_enrollment_revokes_manager(self):
        self.as_user(self.manager)
        Profile.objects.filter(user=self.manager).update(totp_secret='')
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)

    def test_23_old_session_mfa_owner_cannot_bypass_deactivation(self):
        self.as_user(self.owner)
        get_user_model().objects.filter(pk=self.owner.pk).update(is_active=False)
        self.assertNotEqual(self.client.get(reverse('manager')).status_code,200)

    def test_24_manager_cannot_silently_get_grammar_editor_without_mfa(self):
        self.as_user(self.manager,mfa=False)
        self.assertEqual(self.client.get(reverse('manager_grammar_article_v75',args=[999])).status_code,403)

    def test_25_totp_replay_denied_after_successful_login(self):
        self.client=Client()
        response=self.client.post(reverse('login'),{'email':self.manager.email,'password':self.PASS})
        self.assertEqual(response.status_code,302)
        self.assertEqual(response['Location'],reverse('mfa_verify'))
        code=pyotp.TOTP(self.SECRET).now()
        result=self.client.post(reverse('mfa_verify'),{'code':code})
        self.assertEqual(result.status_code,302)
        self.assertEqual(self.client.session.get('mfa_verified_id'),self.manager.pk)
        # Subsequent sign-in with the SAME code must not bypass replay protection.
        self.client.post(reverse('logout'))
        self.client.post(reverse('login'),{'email':self.manager.email,'password':self.PASS})
        replay=self.client.post(reverse('mfa_verify'),{'code':code})
        self.assertNotIn('mfa_verified_id',dict(self.client.session.items()))
        self.assertEqual(replay.status_code,200)

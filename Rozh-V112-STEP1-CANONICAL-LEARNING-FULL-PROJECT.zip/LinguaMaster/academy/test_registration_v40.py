"""V42 Django HTTP regression tests: simple signup, optional email, and privileged boundaries.

The historical V40 file is intentionally updated to test the *current* behavior.
Django uses isolated TEST database; no real mail is sent (locmem backend).
"""
import re
from urllib.parse import urlsplit
from unittest.mock import patch
from django.contrib.auth import get_user_model
from django.core import mail
from django.core.cache import cache
from django.test import Client, TestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from .models import PlatformSettings
from .email_verification_tokens import email_verification_token_generator
User = get_user_model()

@override_settings(MAILERS={'default':{'BACKEND':'django.core.mail.backends.locmem.EmailBackend'}}, SITE_URL='http://testserver')
class RegisterToLearnV42Tests(TestCase):
    PASSWORD = 'UniqueSafe2026!'
    def setUp(self):
        cache.clear()
        config=PlatformSettings.load()
        config.public_registration_enabled=True
        config.save(update_fields=['public_registration_enabled'])

    def register(self, username='learner42', email='learner42@example.test', password=None, next='/play/'):
        return self.client.post(reverse('register'), {
            'username':username,'email':email,'password1':password or self.PASSWORD,
            'age_confirmed':'on','next':next,
        })

    def opt_in_link(self, email='learner42@example.test'):
        response=self.client.post(reverse('resend_verification'), {'email':email})
        self.assertEqual(response.status_code,302)
        self.assertEqual(len(mail.outbox),1)
        match=re.search(r'https?://[^\s]+/verify/[^\s]+',mail.outbox[-1].body)
        self.assertIsNotNone(match)
        return urlsplit(match.group()).path

    def test_signup_auto_login_without_email_or_password_confirmation(self):
        response=self.register()
        self.assertRedirects(response,reverse('onboarding'),fetch_redirect_response=False)
        account=User.objects.get(username='learner42')
        self.assertTrue(account.is_active)
        self.assertIsNone(account.learning_profile.email_verified_at)
        self.assertTrue(account.check_password(self.PASSWORD))
        self.assertEqual(len(mail.outbox),0)
        self.assertEqual(int(self.client.session['_auth_user_id']),account.pk)
        self.assertNotIn('registration_pending_user_id',self.client.session)
        page=Client().get(reverse('register'))
        self.assertContains(page,'name="password1"')
        self.assertNotContains(page,'name="password2"')

    def test_signup_existing_feature_intent_then_login_again(self):
        self.register(next='/grammar/')
        account=User.objects.get(username='learner42')
        state=account.learning_profile
        state.onboarding_completed=True
        state.placement_completed=True
        state.save(update_fields=['onboarding_completed','placement_completed'])
        self.assertEqual(self.client.get(reverse('play_hub')).status_code,200)
        self.assertEqual(self.client.post(reverse('logout')).status_code,302)
        self.assertNotIn('_auth_user_id',self.client.session)
        response=self.client.post(reverse('login'),{'email':account.email,'password':self.PASSWORD})
        self.assertRedirects(response,reverse('play_hub'),fetch_redirect_response=False)
        self.assertEqual(int(self.client.session['_auth_user_id']),account.pk)

    def test_new_signup_does_not_depend_on_smtp(self):
        with patch('academy.views.send_mail',side_effect=RuntimeError('should not be called')) as sender:
            response=self.register()
        self.assertEqual(response.status_code,302)
        sender.assert_not_called()
        self.assertTrue(User.objects.get(username='learner42').is_active)

    def test_optional_verification_get_is_read_only_post_sets_mail_proof(self):
        self.register()
        account=User.objects.get(username='learner42')
        url=self.opt_in_link()
        self.assertEqual(self.client.get(url).status_code,200)
        account.refresh_from_db()
        self.assertIsNone(account.learning_profile.email_verified_at)
        response=self.client.post(url)
        self.assertEqual(response.status_code,302)
        account.refresh_from_db()
        self.assertTrue(account.is_active)
        self.assertIsNotNone(account.learning_profile.email_verified_at)
        self.assertEqual(self.client.post(url).status_code,302)  # one-use token

    def test_unverified_email_cannot_receive_password_reset_token(self):
        self.register()
        self.client.post(reverse('password_reset'),{'email':'learner42@example.test'})
        self.assertEqual(len(mail.outbox),0)
        link=self.opt_in_link()
        self.client.post(link)
        mail.outbox.clear()
        self.assertEqual(self.client.post(reverse('password_reset'),{'email':'learner42@example.test'}).status_code,302)
        self.assertEqual(len(mail.outbox),1)
        self.assertIn('/reset/',mail.outbox[0].body)

    def test_previous_pending_account_can_sign_in_by_password_not_email(self):
        account=User.objects.create_user('pending42','pending42@example.test',self.PASSWORD,is_active=False)
        self.assertEqual(account.learning_profile.email_verification_version,0)
        response=self.client.post(reverse('login'),{'email':account.username,'password':self.PASSWORD})
        self.assertRedirects(response,reverse('onboarding'),fetch_redirect_response=False)
        account.refresh_from_db()
        self.assertTrue(account.is_active)
        self.assertIsNone(account.learning_profile.email_verified_at)

    def test_legacy_reviewed_and_manager_blocked_accounts_stay_closed(self):
        for name,profile_updates in (
            ('under_review42',{'legacy_review_required':True}),
            ('review_approved42',{'email_verification_version':2}),
            ('manager_blocked42',{'suspended_at':timezone.now()}),
        ):
            account=User.objects.create_user(name,name+'@example.test',self.PASSWORD,is_active=False)
            for k,v in profile_updates.items(): setattr(account.learning_profile,k,v)
            account.learning_profile.save(update_fields=list(profile_updates))
            self.client.logout()
            response=self.client.post(reverse('login'),{'email':name,'password':self.PASSWORD})
            self.assertEqual(response.status_code,200, name)
            account.refresh_from_db()
            self.assertFalse(account.is_active,name)
            self.assertNotIn('_auth_user_id',self.client.session)

    def test_manager_unblock_requires_current_email_verification(self):
        self.register()
        account=User.objects.get(username='learner42')
        owner=User.objects.create_superuser('owner42','owner42@example.test',self.PASSWORD)
        owner.learning_profile.email_verified_at = timezone.now()
        owner.learning_profile.totp_secret = 'JBSWY3DPEHPK3PXP'
        owner.learning_profile.save(update_fields=['email_verified_at','totp_secret'])
        self.client.force_login(owner)
        s=self.client.session;s['mfa_verified_id']=owner.pk;s.save()
        endpoint=lambda action:reverse('manager_user_action',args=[account.pk,action])
        self.assertEqual(self.client.post(endpoint('block')).status_code,302)
        account.refresh_from_db();self.assertFalse(account.is_active)
        self.assertEqual(self.client.post(endpoint('unblock')).status_code,302)
        account.refresh_from_db()
        self.assertFalse(account.is_active)  # Never restore an unverified account.
        self.assertIsNone(account.learning_profile.email_verified_at)

    def test_duplicate_email_does_not_change_existing_account(self):
        existing=User.objects.create_user('existing42','existing42@example.test',self.PASSWORD)
        response=self.register(username='other42',email=existing.email)
        self.assertRedirects(response,reverse('login'),fetch_redirect_response=False)
        self.assertFalse(User.objects.filter(username='other42').exists())
        self.assertNotIn('_auth_user_id',self.client.session)
        self.assertEqual(len(mail.outbox),0)

    def test_bad_email_short_password_and_underage_attestation_rejected(self):
        for data in (
            {'username':'x','email':'invalid','password1':self.PASSWORD,'age_confirmed':'on'},
            {'username':'short42','email':'short42@example.test','password1':'Tiny2!','age_confirmed':'on'},
            {'username':'young42','email':'young42@example.test','password1':self.PASSWORD},
        ):
            with self.subTest(data=data):
                response=self.client.post(reverse('register'),data)
                self.assertEqual(response.status_code,200)
        self.assertEqual(User.objects.count(),0)

    def test_locale_accessible_csrf_and_no_mail_confirmation_on_signup(self):
        for lang in ('nl','en','ckb','ar'):
            with self.subTest(lang=lang):
                page=self.client.get(reverse('register'),{'ui':lang})
                self.assertContains(page,'name="csrfmiddlewaretoken"')
                self.assertContains(page,'autocomplete="new-password"')
                self.assertContains(page,'auth-v42.css')
                self.assertContains(page,'dir="rtl"' if lang in ('ckb','ar') else 'dir="ltr"')
                self.assertIn('no-store',page['Cache-Control'])

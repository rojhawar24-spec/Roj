"""Step 3F: an all-or-nothing server-scored SSR lesson batch.

The caller MUST wrap this function in a Django transaction.atomic() savepoint
and catch the exceptions *outside* that savepoint. This is not a replacement
for the HTTP/DB integration tests.
"""


class BatchHeartsExhausted(Exception):
    """The whole submitted batch must be rolled back (HTTP 402)."""


class BatchReplayRejected(Exception):
    """An already charged answer was replayed (HTTP 409)."""


def grade_ssr_batch(*, submissions, user, lesson_pk, round_key,
                    snapshot, spend_for_answer, record_exercise_result,
                    heart_empty_exception):
    """Grade one bound batch; atomic rollback is owned by the caller.

    Every wrong response must create exactly one new heart event. If a heart
    runs out halfway through the batch, raise rather than returning partial
    progress. No mistake record should survive a rejected batch.
    """
    from .lesson_feedback_v101 import graded_solution
    correct = 0
    feedback = []
    for exercise, _submitted, success in submissions:
        if snapshot(user)['empty']:
            raise BatchHeartsExhausted('Not enough hearts for this full batch.')
        if not success:
            key = f'lesson:{lesson_pk}:round:{round_key}:question:{exercise.pk}'
            try:
                debit = spend_for_answer(user, key)
            except heart_empty_exception as exc:
                raise BatchHeartsExhausted('Hearts ran out while scoring.') from exc
            if not debit['spent']:
                raise BatchReplayRejected('A question debit was already recorded.')
        record_exercise_result(user, exercise, success)
        correct += int(success)
        feedback.append({'correct': success, 'prompt': exercise.prompt,
                         'explanation': exercise.explanation,
                         'solution': graded_solution(exercise, success)})
    return correct, feedback

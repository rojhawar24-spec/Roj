"""Dependency-free editorial checks for language-learning exercise authoring.

These checks do not grade CEFR competency or certify pedagogical quality.
"""


def check_exercise(kind, prompt, options, answer, explanation, activity_data=None):
    """Return stable (severity, code, message) triples for one exercise."""
    issues = []
    if not isinstance(prompt, str) or not prompt.strip():
        issues.append(('error', 'question-empty', 'A question needs a prompt.'))
    from .lesson_activities_v58 import MATCHING
    if kind not in MATCHING and (not isinstance(answer, str) or not answer.strip()):
        issues.append(('error', 'answer-empty', 'A question needs a correct answer.'))
    if not isinstance(explanation, str) or not explanation.strip():
        issues.append(('warning', 'explanation-empty', 'Add a useful explanation for wrong answers.'))
    if kind == 'mcq':
        if not isinstance(options, list) or len(options) < 2 or not all(
            isinstance(option, str) and option.strip() for option in options
        ):
            issues.append(('error', 'choices-invalid', 'A multiple-choice question needs at least two nonempty options.'))
        else:
            normalized = [option.strip().casefold() for option in options]
            if len(set(normalized)) != len(normalized):
                issues.append(('error', 'choices-duplicate', 'Multiple-choice options must be distinct.'))
            if isinstance(answer, str) and answer.strip().casefold() not in normalized:
                issues.append(('error', 'answer-not-in-options', 'The correct answer is missing from the options.'))
    elif kind != 'short':
        from .lesson_activities_v58 import validate_activity, KIND_KEYS
        if kind in KIND_KEYS:
            # All V58 types require useful feedback and validated authored data.
            for detail in validate_activity(kind, prompt, options, answer, explanation, activity_data):
                issues.append(('error','activity-v58',detail))
        else:
            issues.append(('error', 'question-kind', 'Unsupported question type.'))
    return issues

"""V31 live integration tests. Must be run with Django/pyotp installed.

These tests were authored with this release but could not be executed in its
isolated build environment. Run `manage.py test academy.test_login_v31`.
"""
from unittest.mock import patch

import pyotp
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.db import connection, transaction
from django.test import TestCase

from .auth_security import verify_totp_step
from .models import Profile

User = get_user_model()
PASSWORD = 'CorrectHorseBatteryExample!2026'


class LoginV31IntegrationTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = User.objects.create_user('v31_learner', 'v31@example.test', PASSWORD)
        self.profile = self.user.learning_profile
        self.profile.placement_completed = True
        self.profile.onboarding_completed = True
        self.profile.save(update_fields=['placement_completed', 'onboarding_completed'])

    def test_unknown_account_also_passes_through_password_backend(self):
        with patch('academy.views.authenticate', return_value=None) as mock_auth:
            response = self.client.post('/login/', {'email': 'not-an-account', 'password': 'wrong-password'})
        self.assertEqual(response.status_code, 200)
        mock_auth.assert_called_once()
        self.assertContains(response, 'data-auth-error-summary')
        self.assertNotContains(response, 'User not found')

    def test_username_and_email_aliases_count_toward_one_account_limit(self):
        for i in range(7):
            identifier = self.user.email if i % 2 else self.user.username
            response = self.client.post('/login/', {'email': identifier, 'password': 'wrong-password'})
            self.assertEqual(response.status_code, 200)
        response = self.client.post('/login/', {'email': self.user.email, 'password': PASSWORD})
        self.assertEqual(response.status_code, 429)

    def test_learner_intent_and_open_redirect_rejection(self):
        response = self.client.post('/login/', {'email': self.user.email, 'password': PASSWORD,
                                                'next': '/grammar/'})
        self.assertRedirects(response, '/grammar/', fetch_redirect_response=False)
        self.client.post('/logout/')
        response = self.client.post('/login/', {'email': self.user.email, 'password': PASSWORD,
                                                'next': '//evil.example.test/'})
        self.assertRedirects(response, '/play/', fetch_redirect_response=False)

    def test_signed_in_learner_can_choose_another_feature(self):
        self.client.force_login(self.user)
        response = self.client.get('/login/', {'next': '/grammar/'})
        self.assertRedirects(response, '/grammar/', fetch_redirect_response=False)

    def test_admin_must_enrol_two_factor_and_owner_gate_remains(self):
        staff = User.objects.create_user('v31_staff', 'staff@example.test', PASSWORD, is_staff=True)
        response = self.client.post('/login/', {'email': staff.username, 'password': PASSWORD})
        self.assertRedirects(response, '/mfa/setup/', fetch_redirect_response=False)
        self.assertEqual(self.client.get('/manager/').status_code, 403)
        self.assertEqual(self.client.get('/secure-admin/').status_code, 302)

    def test_totp_is_encrypted_in_actual_database(self):
        self.profile.totp_secret = pyotp.random_base32()
        expected = self.profile.totp_secret
        self.profile.save(update_fields=['totp_secret'])
        with connection.cursor() as cursor:
            cursor.execute('SELECT totp_secret FROM academy_profile WHERE user_id=%s', [self.user.pk])
            stored = cursor.fetchone()[0]
        self.assertTrue(stored.startswith('enc:v1:'))
        self.assertNotEqual(stored, expected)
        self.assertEqual(Profile.objects.get(user=self.user).totp_secret, expected)

    def test_totp_replay_is_rejected_across_successive_sessions(self):
        self.profile.totp_secret = 'JBSWY3DPEHPK3PXP'
        self.profile.save(update_fields=['totp_secret'])
        with patch('time.time', return_value=1_000_000_020):
            code = pyotp.TOTP(self.profile.totp_secret).at(1_000_000_020)
            self.assertEqual(self.client.post('/login/', {'email': self.user.email,
                                                           'password': PASSWORD}).status_code, 302)
            self.assertRedirects(self.client.post('/mfa/verify/', {'code': code}),
                                 '/play/', fetch_redirect_response=False)
            self.client.post('/logout/')
            self.client.post('/login/', {'email': self.user.email, 'password': PASSWORD})
            failed = self.client.post('/mfa/verify/', {'code': code})
            self.assertEqual(failed.status_code, 200)
            self.assertContains(failed, 'data-auth-error-summary')
            self.assertNotIn('_auth_user_id', self.client.session)

    def test_valid_totp_time_step_is_consumed_only_once(self):
        self.profile.totp_secret = pyotp.random_base32()
        self.profile.save(update_fields=['totp_secret'])
        with transaction.atomic():
            locked = Profile.objects.select_for_update().get(user=self.user)
            with patch('time.time', return_value=90_000):
                code = pyotp.TOTP(locked.totp_secret).at(90_000)
                self.assertTrue(verify_totp_step(locked, code))
                self.assertFalse(verify_totp_step(locked, code))

    def test_duplicate_email_registration_does_not_disclose_account(self):
        data = {'username': 'another_user', 'email': self.user.email,
                'password1': PASSWORD, 'password2': PASSWORD, 'age_confirmed': 'on'}
        response = self.client.post('/register/', data)
        self.assertRedirects(response, '/register/check-email/', fetch_redirect_response=False)
        self.assertFalse(User.objects.filter(username='another_user').exists())
        self.assertNotIn('already taken', response.content.decode().lower())

    def test_login_errors_are_accessible_in_four_locales(self):
        for locale in ('nl', 'en', 'ckb', 'ar'):
            with self.subTest(locale=locale):
                response = self.client.post('/login/?ui=' + locale,
                                            {'email': self.user.username, 'password': 'invalid'})
                self.assertEqual(response.status_code, 200)
                self.assertContains(response, 'data-auth-error-summary')
                self.assertContains(response, f'lang="{locale}"')

    def test_form_validation_links_errors_without_javascript(self):
        response = self.client.post('/register/', {'email': 'not-an-email', 'username': '',
                                                   'password1': 'short', 'password2': ''})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'aria-invalid="true"')
        self.assertContains(response, 'help-username error-username-0')

    def test_login_has_private_headers_and_reduced_assets(self):
        response = self.client.get('/login/')
        self.assertEqual(response.status_code, 200)
        self.assertIn('no-store', response['Cache-Control'])
        self.assertIn('noindex', response['X-Robots-Tag'])
        self.assertContains(response, 'auth-v35-bundle.css')
        self.assertNotContains(response, 'constellation-v20.js')
        self.assertNotContains(response, 'rozh-path-v24.css')

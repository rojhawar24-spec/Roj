"""STEP12 real Django URL-resolution contracts; MUST run on a Django installation.

Adding this file is not a claim that a Django test was executed during building.
"""
from django.test import SimpleTestCase
from django.urls import resolve, reverse
from academy import billing_v9, grammar_v9, progress_v9, social_v9


class Step12CanonicalFeatureRoutingTests(SimpleTestCase):
    CANONICAL = (
        ('ai_tutor', (), '/ai-tutor/', billing_v9.ai_tutor),
        ('profile', (), '/profile/', progress_v9.profile),
        ('friends', (), '/friends/', social_v9.friends),
        ('friend_action', (9, 'accept'), '/friends/9/accept/', social_v9.friend_action),
        ('grammar_library', (), '/grammar/', grammar_v9.grammar_library),
        ('grammar', (9,), '/grammar/9/', grammar_v9.grammar_detail),
        ('mistakes', (), '/mistakes/', grammar_v9.mistakes),
    )

    def test_name_to_path_and_path_to_actual_callable(self):
        for name, args, expected_path, view in self.CANONICAL:
            with self.subTest(name=name):
                self.assertEqual(reverse(name, args=args), expected_path)
                resolved = resolve(expected_path)
                self.assertEqual(resolved.url_name, name)
                self.assertIs(resolved.func, view)

    def test_login_and_manager_routes_stay_distinct(self):
        for name in ('login', 'register', 'logout', 'mfa_verify', 'manager',
                     'manager_users', 'manager_award', 'lesson_answer'):
            with self.subTest(name=name):
                self.assertIsNotNone(reverse(name, args=(9,) if name == 'lesson_answer' else ()))

"""Run through python manage.py test academy on a configured installation."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse


class GuestDemoTests(TestCase):
    def test_guest_can_open_complete_demo_without_authentication(self):
        res=self.client.get(reverse('try_lesson'))
        self.assertEqual(res.status_code,200)
        self.assertContains(res, 'id="lm-demo"')
        self.assertContains(res, 'demo-engine.js')
        self.assertContains(res, 'demo-v8.js')
        self.assertContains(res, 'demo-v8.css')
        self.assertContains(res, 'Create an account')

    def test_demo_is_read_only(self):
        response=self.client.post(reverse('try_lesson'), {'answer':'morning'})
        self.assertEqual(response.status_code,405)

    def test_home_has_a_playable_entry_point(self):
        response=self.client.get(reverse('home'))
        self.assertContains(response, reverse('try_lesson'))

    def test_public_sitemap_includes_free_mini_lesson(self):
        response = self.client.get(reverse('sitemap'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, '/try/')

    def test_pwa_worker_is_get_only(self):
        self.assertEqual(self.client.post(reverse('service_worker')).status_code, 405)

    def test_demo_has_distinct_public_metadata(self):
        response=self.client.get(reverse('try_lesson'))
        self.assertContains(response,'Try a free Dutch mini-lesson')
        self.assertContains(response, reverse('try_lesson'))


class GuestDemoAccountIsolationTests(TestCase):
    def test_demo_does_not_change_user_progress(self):
        User=get_user_model()
        user=User.objects.create_user(username='demo-integration',password='SamplePassword2026!')
        self.client.force_login(user)
        response=self.client.get(reverse('try_lesson'))
        self.assertEqual(response.status_code,200)
        from .models import LessonProgress, XPEvent
        self.assertEqual(LessonProgress.objects.filter(user=user).count(),0)
        self.assertEqual(XPEvent.objects.filter(user=user).count(),0)

"""Phase 14 Django HTTP safety tests. Not equivalent to execution until run."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .models import PlatformSettings


class AnonymousJourneyBoundaryTests(TestCase):
    def test_anonymous_stays_out_of_private_student_and_manager_pages(self):
        for name in ('dashboard', 'learn_path', 'manager', 'manager_users',
                     'manager_audit', 'data_export', 'delete_account'):
            with self.subTest(route=name):
                response = self.client.get(reverse(name), follow=False)
                self.assertIn(response.status_code, (302, 401, 403))

    def test_manager_mutations_never_respond_successfully_to_anonymous(self):
        for name, arguments, data in (
            ('manager_award', [], {'action': 'grant', 'user_id': '1', 'award_target': 'badge:1'}),
            ('manager_user_action', [1, 'promote'], {}),
        ):
            with self.subTest(route=name):
                response = self.client.post(reverse(name, args=arguments), data)
                self.assertIn(response.status_code, (302, 401, 403, 404))
                self.assertFalse(response.status_code == 200)

    def test_health_and_ready_get_cannot_create_operator_settings(self):
        PlatformSettings.objects.filter(pk=1).delete()
        before = PlatformSettings.objects.count()
        for route in ('health', 'ready'):
            self.client.get(reverse(route))
        self.assertEqual(PlatformSettings.objects.count(), before)


class LearnerPrivilegeBoundaryTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.learner = User.objects.create_user('phase14_learner',
                                                email='learner-phase14@example.invalid',
                                                password='TestOnly!2026')
        self.client.force_login(self.learner)

    def test_ordinary_learner_cannot_get_or_post_manager_controls(self):
        self.assertEqual(self.client.get(reverse('manager')).status_code, 403)
        self.assertEqual(self.client.get(reverse('manager_users')).status_code, 403)
        self.assertEqual(self.client.post(reverse('manager'), {'ai_enabled': 'on'}).status_code, 403)
        self.assertEqual(self.client.post(reverse('manager_user_action', args=[self.learner.pk, 'promote'])).status_code, 403)
        self.assertEqual(self.client.post(reverse('manager_award'), {'action': 'grant'}).status_code, 403)

    def test_stolen_mfa_session_flag_does_not_grant_manager_permission(self):
        session = self.client.session
        session['mfa_verified_id'] = self.learner.pk
        session.save()
        self.assertEqual(self.client.get(reverse('manager')).status_code, 403)

    def test_secure_admin_requires_staff_and_verified_mfa(self):
        # Regular learners are not staff. Middleware must deny even with a forged flag.
        session = self.client.session
        session['mfa_verified_id'] = self.learner.pk
        session.save()
        response = self.client.get('/secure-admin/', follow=False)
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.headers.get('Location', '').startswith(reverse('login')))

"""STEP 2 pure design metadata tests. Django URL and auth E2E need separate environment."""
from django.test import SimpleTestCase
from .solar_atlas_step2 import COPY, SKINS, skin, decorate


class SolarAtlasPresentationTests(SimpleTestCase):
    def test_six_distinct_accents_have_stable_metadata(self):
        self.assertEqual(len({row[0] for row in SKINS}), 6)
        self.assertEqual([skin(i)['curve'] for i in range(3)], ['soft','flow','arc'])

    def test_decorate_leaves_existing_access_and_progress_untouched(self):
        stages = [{'anchor':'s12', 'title':'My custom season', 'items':[{'state':'locked', 'game_url':None}], 'done':0, 'total':2},
                  {'anchor':'l22', 'title':'Existing chapter', 'items':[{'state':'active', 'game_url':'/play/1/'}], 'done':1, 'total':2}]
        decorate(stages)
        self.assertEqual(stages[0]['title'], 'My custom season')
        self.assertEqual(stages[0]['items'][0], {'state':'locked', 'game_url':None})
        self.assertEqual(stages[1]['items'][0]['game_url'], '/play/1/')
        self.assertEqual(stages[1]['done'], 1)
        self.assertNotEqual(stages[0]['solar']['slug'], stages[1]['solar']['slug'])

    def test_all_ui_languages_have_matching_keys(self):
        keys = set(COPY['nl'])
        for lang in ('en','ckb','ar'):
            self.assertEqual(keys, set(COPY[lang]))

    def test_theme_index_is_safe_and_repeatable(self):
        self.assertEqual(skin(6)['slug'], skin(0)['slug'])
        with self.assertRaises(ValueError): skin(-1)

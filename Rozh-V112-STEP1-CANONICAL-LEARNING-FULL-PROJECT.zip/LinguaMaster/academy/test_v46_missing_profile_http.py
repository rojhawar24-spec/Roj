"""V46 real Django HTTP checks. NOT a passing claim until run in the QA DB."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .models import Profile
from .progress_models import LearningPreferences


class SharedContextMissingProfileV46(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username='v46-context-user', email='v46@example.invalid', password='StrongExample!2026')
        self.client.force_login(self.user)

    def _remove_profile(self):
        Profile.objects.filter(user=self.user).delete()
        self.assertFalse(Profile.objects.filter(user=self.user).exists())

    def test_authenticated_account_without_profile_can_open_public_home(self):
        self._remove_profile()
        before=LearningPreferences.objects.filter(user=self.user).count()
        response=self.client.get(reverse('home'))
        self.assertEqual(response.status_code,200)
        self.assertEqual(LearningPreferences.objects.filter(user=self.user).count(),before)

    def test_authenticated_missing_profile_can_open_sorani_home(self):
        self._remove_profile()
        response=self.client.get(reverse('home_ckb'))
        self.assertEqual(response.status_code,200)

    def test_missing_profile_is_denied_account_preferences(self):
        self._remove_profile()
        self.assertEqual(self.client.get(reverse('profile')).status_code,403)
        self.assertEqual(self.client.post(reverse('appearance_preferences'), {'theme':'dark'}).status_code,403)

    def test_suspended_account_has_no_private_global_xp_context(self):
        Profile.objects.filter(user=self.user).update(xp=500,suspended_at=timezone.now())
        response=self.client.get(reverse('home'))
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.context['DESK_XP_LEVEL'],1)
        with self.assertRaises(KeyError):
            _ = response.context['HEARTS']

    def test_account_under_review_has_no_private_global_xp_context(self):
        Profile.objects.filter(user=self.user).update(xp=500,legacy_review_required=True)
        response=self.client.get(reverse('home'))
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.context['DESK_XP_LEVEL'],1)

    def test_active_sorani_profile_keeps_rtl_ui(self):
        Profile.objects.filter(user=self.user).update(ui_language='ckb')
        # The public homepage forces its own locale; use the authenticated
        # course page to check the shared UI context instead.
        response=self.client.get(reverse('courses'))
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.context['UI_DIR'],'rtl')

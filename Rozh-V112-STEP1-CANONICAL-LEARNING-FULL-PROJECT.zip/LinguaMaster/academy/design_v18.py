"""Nova V18 localized labels. Presentation only; never gives XP or permissions."""
COPY = {
 'en': {'leaderboard':'Leaderboard', 'quests':'Daily quests', 'view_all':'View all', 'today':'Today', 'xp_goal':'Earn your daily XP', 'lessons_quest':'Complete 2 lessons', 'review_quest':'Mistakes to review', 'word':'Word of the day', 'word_missing':'No published word for today', 'languages':'Learning languages', 'change_language':'Choose language', 'start_here':'Start here', 'explore':'Explore', 'none_leader':'No public rankings yet', 'section':'SECTION', 'unit':'UNIT', 'complete':'Completed', 'locked':'Locked', 'goal':'Daily goal', 'reward':'Reward unlocked', 'progress':'My journey', 'practice':'Practice more', 'xp':'XP', 'coins':'Gems', 'hearts':'Lives'},
 'nl': {'leaderboard':'Ranglijst', 'quests':'Dagelijkse uitdagingen', 'view_all':'Bekijk alles', 'today':'Vandaag', 'xp_goal':'Verdien je dagelijkse XP', 'lessons_quest':'Voltooi 2 lessen', 'review_quest':'Fouten om te oefenen', 'word':'Woord van de dag', 'word_missing':'Nog geen woord voor vandaag', 'languages':'Leertalen', 'change_language':'Kies taal', 'start_here':'Begin hier', 'explore':'Ontdekken', 'none_leader':'Nog geen openbare ranglijst', 'section':'SECTIE', 'unit':'UNIT', 'complete':'Voltooid', 'locked':'Vergrendeld', 'goal':'Dagdoel', 'reward':'Beloning ontgrendeld', 'progress':'Mijn leerreis', 'practice':'Verder oefenen', 'xp':'XP', 'coins':'Munten', 'hearts':'Levens'},
 'ckb': {'leaderboard':'پلەبەندی', 'quests':'ئەرکە ڕۆژانەکان', 'view_all':'هەمووی ببینە', 'today':'ئەمڕۆ', 'xp_goal':'XP ـی ڕۆژانەت بەدەست بهێنە', 'lessons_quest':'٢ وانە تەواو بکە', 'review_quest':'هەڵەکان بۆ دووبارەکردنەوە', 'word':'وشەی ڕۆژ', 'word_missing':'ئەمڕۆ هێشتا وشەی بڵاوکراوە نییە', 'languages':'زمانەکانی فێربوون', 'change_language':'زمان هەڵبژێرە', 'start_here':'لێرە دەست پێ بکە', 'explore':'بگەڕێ', 'none_leader':'هێشتا پلەبەندی گشتی نییە', 'section':'بەش', 'unit':'ئاست', 'complete':'تەواوبوو', 'locked':'داخراوە', 'goal':'ئامانجی ڕۆژانە', 'reward':'خەڵات کراوەتەوە', 'progress':'گەشتی فێربوونم', 'practice':'زیاتر ڕاهێنان بکە', 'xp':'XP', 'coins':'سکە', 'hearts':'دڵ'},
 'ar': {'leaderboard':'لوحة الترتيب', 'quests':'المهام اليومية', 'view_all':'عرض الكل', 'today':'اليوم', 'xp_goal':'احصل على نقاط XP اليومية', 'lessons_quest':'أكمل درسين', 'review_quest':'أخطاء للمراجعة', 'word':'كلمة اليوم', 'word_missing':'لا توجد كلمة منشورة اليوم', 'languages':'لغات التعلّم', 'change_language':'اختر اللغة', 'start_here':'ابدأ هنا', 'explore':'استكشف', 'none_leader':'لا يوجد ترتيب عام بعد', 'section':'قسم', 'unit':'وحدة', 'complete':'مكتمل', 'locked':'مغلق', 'goal':'الهدف اليومي', 'reward':'المكافأة متاحة', 'progress':'رحلتي', 'practice':'المزيد من التدريب', 'xp':'XP', 'coins':'عملات', 'hearts':'القلوب'},
}

def for_request(request):
    from .safe_profile_context_v46 import visible_learning_profile
    profile = visible_learning_profile(request.user)
    lang = profile.ui_language if profile is not None else 'en'
    return COPY.get(lang, COPY['en'])


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'design_v18', ['COPY'])

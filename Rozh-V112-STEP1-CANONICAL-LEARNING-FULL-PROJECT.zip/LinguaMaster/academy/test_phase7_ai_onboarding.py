"""Phase 7 Django integration contracts; run ONLY against an isolated test DB.

These tests are shipped as pending when Django is unavailable in the packaging
container; they must not be counted as passing offline tests.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Language, PlatformSettings, Profile


class Phase7AIConsentAndJourneyTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            'phase7_student', 'phase7@example.invalid', 'Safe-Local-Password-2026!'
        )
        self.language = Language.objects.create(
            name='Dutch', code='nl', slug='phase7-dutch', description='', is_published=True
        )
        Profile.objects.filter(user=self.user).update(
            ai_opt_in=True, ui_language='en', preferred_language=self.language,
            onboarding_required=False, onboarding_completed=True,
            placement_completed=True, placement_level='A0',
        )
        self.client.force_login(self.user)
        self.config = PlatformSettings.load()
        self.config.ai_enabled = True
        self.config.ai_emergency_stop = False
        self.config.save(update_fields=['ai_enabled', 'ai_emergency_stop'])

    def remember(self):
        session = self.client.session
        session['ai_v9_history'] = [{'role': 'user', 'content': 'Private earlier AI question'}]
        session['ai_v9_course'] = f'{self.language.pk}:A0:en'
        session.save()

    def test_ai_teacher_uses_student_shell_not_legacy(self):
        response = self.client.get(reverse('ai_tutor'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'academy/rozh2027_student_shell.html')
        self.assertContains(response, 'r57-ai-page')

    def test_ai_opt_out_erases_session_history_at_profile_save(self):
        self.remember()
        response = self.client.post(reverse('profile'), {
            'avatar': '🎓', 'bio': '', 'ui_language': 'en',
            'daily_goal_xp': 20, 'preferred_language': self.language.pk,
            # Omitting checkbox ai_opt_in deliberately revokes consent.
        })
        self.assertEqual(response.status_code, 302)
        self.assertFalse(Profile.objects.get(user=self.user).ai_opt_in)
        self.assertNotIn('ai_v9_history', self.client.session)
        self.assertNotIn('ai_v9_course', self.client.session)

    def test_stale_session_chat_does_not_appear_after_opt_out(self):
        Profile.objects.filter(user=self.user).update(ai_opt_in=False)
        self.remember()
        response = self.client.get(reverse('ai_tutor'))
        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, 'Private earlier AI question')
        self.assertEqual(response.context['history'], [])
        self.assertNotIn('ai_v9_history', self.client.session)
        self.assertNotIn('ai_v9_course', self.client.session)

    def test_owner_emergency_stop_hides_ai_and_erases_session_chat(self):
        self.remember()
        self.config.ai_emergency_stop = True
        self.config.save(update_fields=['ai_emergency_stop'])
        self.assertEqual(self.client.get(reverse('ai_tutor')).status_code, 404)
        self.assertNotIn('ai_v9_history', self.client.session)
        self.assertNotIn('ai_v9_course', self.client.session)
        home = self.client.get(reverse('play_hub'))
        self.assertNotContains(home, 'href="' + reverse('ai_tutor') + '"')

    def test_interface_language_switch_returns_to_ai_teacher(self):
        response = self.client.post(reverse('switch_ui_language'), {
            'ui_language': 'ckb', 'return_to': 'ai_tutor',
        })
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse('ai_tutor'))
        self.assertEqual(Profile.objects.get(user=self.user).ui_language, 'ckb')
        page = self.client.get(response.url)
        self.assertContains(page, 'dir="rtl"')

    def test_switch_during_unfinished_onboarding_preserves_private_draft(self):
        Profile.objects.filter(user=self.user).update(
            ui_language='en', onboarding_required=True, onboarding_completed=False,
        )
        response = self.client.post(reverse('switch_ui_language'), {
            'ui_language': 'ckb', 'return_to': 'ai_tutor',
        })
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse('onboarding'))
        self.assertEqual(Profile.objects.get(user=self.user).ui_language, 'en')

    def test_ai_language_return_not_an_open_redirect(self):
        response = self.client.post(reverse('switch_ui_language'), {
            'ui_language': 'ar', 'return_to': 'https://another.example/',
        })
        self.assertEqual(response.url, reverse('play_hub'))

    def test_invalid_interface_language_does_not_change_profile(self):
        response = self.client.post(reverse('switch_ui_language'), {
            'ui_language': 'en_US', 'return_to': 'ai_tutor',
        })
        self.assertEqual(response.status_code, 400)
        self.assertEqual(Profile.objects.get(user=self.user).ui_language, 'en')

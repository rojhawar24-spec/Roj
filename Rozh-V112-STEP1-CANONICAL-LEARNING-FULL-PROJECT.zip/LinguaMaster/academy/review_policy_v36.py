"""Fail-closed course/account policy for spaced vocabulary review.

Card ownership and current-course scope are checked separately by the view.
"""


def review_access_allowed(profile, *, user_active, course_published):
    return bool(
        profile is not None
        and user_active
        and course_published
        and profile.preferred_language_id is not None
        and profile.placement_completed
        and (not profile.onboarding_required or profile.onboarding_completed)
        and profile.suspended_at is None
        and not profile.legacy_review_required
    )

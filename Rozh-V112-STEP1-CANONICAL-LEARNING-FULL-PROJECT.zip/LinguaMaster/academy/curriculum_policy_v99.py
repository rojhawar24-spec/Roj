"""Rozh V99 — conservative retirement of historic ungraded seed pages.

Never infer that a Manager-authored lesson is a disposable self-review. This
module is pure, read-only, and does not modify Django models or student data.
"""

AUTO_GRADED_LEER_SPEEL_KINDS = (
    'mcq', 'fill_blank', 'word_matching', 'word_order', 'listening',
)

# Never identify an edited Dutch lesson by matching only an unchanged prefix
# and suffix: that could silently unpublish a Manager's rewritten middle.
import hashlib
import json

from .legacy_dutch_seed_fingerprints_v100 import DUTCH_UNGRADED_SEED_SHA256


def _dutch_seed_digest(lesson):
    """Exact original V98 fields: any editorial change makes retirement ineligible."""
    fields = [lesson.skill, lesson.title, lesson.content,
              getattr(lesson, 'audio_text', None), getattr(lesson, 'order', None)]
    payload = json.dumps(fields, ensure_ascii=False, separators=(',', ':'))
    return hashlib.sha256(payload.encode('utf-8')).hexdigest()


def _source_course(course_code):
    if course_code == 'en':
        from .starter_v10 import COURSE
    elif course_code == 'de':
        from .starter_de_v10 import COURSE
    elif course_code == 'fr':
        from .starter_fr_v10 import COURSE
    else:
        return None
    return COURSE


def _other_starter_source(course_code, unit_slug, skill):
    # Exact authored content comparison: even small Manager edits make a lesson
    # ineligible for automatic retirement. Pure Python starter modules only.
    COURSE = _source_course(course_code)
    if COURSE is None:
        return None
    for unit in COURSE['units']:
        if unit['slug'] == unit_slug:
            for entry in unit['lessons']:
                if entry['skill'] == skill and not entry.get('exercises'):
                    return entry
    return None


def is_original_ungraded_seed_lesson(lesson, *, has_exercises=False,
                                    course_code='nl', unit_slug=None):
    """Only original, unchanged, ungraded starter pages; never delete content."""
    # The editor increments content_version for authored changes. Refuse any
    # non-original version even if a title/prefix still resembles old seed.
    if has_exercises or getattr(lesson, 'content_version', None) != 1:
        return False
    kind = getattr(lesson, 'skill', None)
    if kind not in ('speaking', 'writing') or getattr(lesson, 'slug', None) != kind:
        return False
    title = getattr(lesson, 'title', None)
    content = getattr(lesson, 'content', None)
    if not isinstance(content, str):
        return False
    if course_code == 'nl':
        approved_hash = DUTCH_UNGRADED_SEED_SHA256.get(unit_slug or '', {}).get(kind)
        return bool(approved_hash and _dutch_seed_digest(lesson) == approved_hash)
    original = _other_starter_source(course_code, unit_slug, kind)
    if not original:
        return False
    from_skill_order = next(
        (index for index, entry in enumerate(
            next(unit['lessons'] for unit in _source_course(course_code)['units']
                 if unit['slug'] == unit_slug), 1)
         if entry['skill'] == kind), None)
    return bool(title == original['title']
                and content == original['content']
                and getattr(lesson, 'audio_text', None) == original['audio_text']
                and getattr(lesson, 'order', None) == from_skill_order)

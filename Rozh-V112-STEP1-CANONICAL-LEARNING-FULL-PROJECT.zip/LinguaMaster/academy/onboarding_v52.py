"""Account-scoped, fully server-backed, interruption-safe setup for learners.

Step writes only the private OnboardingDraft. Profile/course writes are atomic at
completion, with old enrollments/progress preserved by switch_course().
"""
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import HttpResponseBadRequest
from django.shortcuts import redirect, render
from django.urls import reverse
from django.views.decorators.http import require_http_methods, require_GET

from .models import Language, OnboardingDraft, Profile
from .manager_roles_v48 import has_manager_role
from .courses_v10 import switch_course
from .onboarding_copy_v52 import APP_LANGUAGES, COPY, LANGUAGE_NAMES, KURDISH_SELECTOR_LABELS, localized_copy
from .services import rate_limit
from .placement_adaptive_v77 import smart_placement_available

STEPS = (1, 2, 3, 4)
GOALS = (10, 20, 35, 50)


def _locale(profile, draft=None):
    code = (draft.ui_language if draft and draft.ui_language in COPY else profile.ui_language)
    return code if code in COPY else 'en'


def _redirect_after_setup(profile):
    if not profile.placement_completed and not profile.preferred_language_id:
        return redirect('courses')
    return redirect('play_hub' if profile.placement_completed else 'smart_placement_v77')


@login_required
@require_http_methods(['GET', 'POST'])
def onboarding(request):
    # Existing users are NEVER required to repeat setup.
    profile = request.user.learning_profile
    if has_manager_role(request.user):
        return redirect('manager')
    if not profile.onboarding_required or profile.onboarding_completed:
        return _redirect_after_setup(profile)
    if request.method == 'POST' and rate_limit(request, 'onboarding', 36, 3600, True):
        from django.http import HttpResponse
        return HttpResponse('Too many attempts.', status=429)

    error = ''
    with transaction.atomic():
        draft, _ = OnboardingDraft.objects.select_for_update().get_or_create(user=request.user)
        courses = list(Language.objects.filter(is_published=True).order_by('code', 'pk'))
        codes = {str(course.pk): course for course in courses}
        current_step = max(1, min(4, draft.step))
        try:
            requested = int(request.POST.get('step', '') if request.method == 'POST'
                            else request.GET.get('step', current_step))
        except (TypeError, ValueError):
            requested = current_step
        if requested not in STEPS or requested > current_step:
            requested = current_step
        step = requested

        if request.method == 'POST':
            value = request.POST.get('choice', '')
            skip = request.POST.get('skip') == '1'
            labels = localized_copy(_locale(profile, draft))
            if step == 1:
                if skip:
                    value = profile.ui_language if profile.ui_language in COPY else 'en'
                if value not in COPY:
                    error = labels['choice_required']
                else:
                    draft.ui_language = value
                    draft.step = max(current_step, 2)
            elif step == 2:
                if value not in codes:
                    error = labels['course_unavailable'] if value else labels['choice_required']
                else:
                    course = codes[value]
                    changed = draft.preferred_language_id != course.pk
                    draft.preferred_language = course
                    if changed:
                        draft.start_choice = ''
                        draft.step = 3
                    else:
                        draft.step = max(current_step, 3)
            elif step == 3:
                if skip:
                    value = 'beginner'
                if value not in ('beginner', 'placement'):
                    error = labels['choice_required']
                elif not draft.preferred_language_id or str(draft.preferred_language_id) not in codes:
                    error = labels['course_unavailable']
                elif value == 'placement':
                    if not smart_placement_available(draft.preferred_language):
                        error = labels['placement_unavailable']
                if not error:
                    draft.start_choice = value
                    draft.step = max(current_step, 4)
            elif step == 4:
                if skip:
                    value = '20'
                try:
                    goal = int(value)
                except (ValueError, TypeError):
                    goal = -1
                if goal not in GOALS:
                    error = labels['choice_required']
                elif not (draft.ui_language in COPY and draft.preferred_language_id and
                          draft.start_choice in ('beginner', 'placement')):
                    error = labels['incomplete']
                elif str(draft.preferred_language_id) not in codes:
                    error = labels['course_unavailable']
                else:
                    if draft.start_choice == 'placement':
                        if not smart_placement_available(draft.preferred_language):
                            error = labels['placement_unavailable']
                    if not error:
                        # Revalidate the published language *inside* switch_course.
                        try:
                            active = switch_course(request.user, draft.preferred_language,
                                                   start_at_a0=(draft.start_choice == 'beginner'))
                        except Language.DoesNotExist:
                            error = labels['course_unavailable']
                        else:
                            active.ui_language = draft.ui_language
                            active.daily_goal_xp = goal
                            active.onboarding_completed = True
                            active.onboarding_required = False
                            active.save(update_fields=['ui_language', 'daily_goal_xp', 'onboarding_completed', 'onboarding_required'])
                            request.session['r52_ready_once'] = '1'
                            # Preserve an earlier, locally validated guest feature selection.
                            # The ready page consumes it once after profile setup.
                            draft.delete()
                            return redirect('onboarding_ready_v52')
            if not error:
                draft.save()
                return redirect(reverse('onboarding') + '?step=' + str(draft.step))

        locale = _locale(profile, draft)
        L = localized_copy(locale)
        localized_courses = [{'id': course.pk,
                              'name': LANGUAGE_NAMES.get(locale, LANGUAGE_NAMES['en']).get(course.code, course.name),
                              'code': course.code.upper(), 'native': course.name} for course in courses]
        # An entry quiz is a REAL optional feature only if usable published questions exist.
        quiz_available = bool(draft.preferred_language_id and
                              str(draft.preferred_language_id) in codes and
                              smart_placement_available(draft.preferred_language))
        selected = {
            1: draft.ui_language,
            2: str(draft.preferred_language_id or ''),
            3: draft.start_choice,
            4: str(draft.daily_goal_xp or ''),
        }[step]
        # The last question's selected goal is stored only on completion.
        if step == 4 and not selected:
            selected = '20'
        if step == 3 and not selected and not quiz_available:
            selected = 'beginner'
        flag_assets = {'nl': 'academy/flags/nl.svg', 'en': 'academy/flags/en.svg',
                       'de': 'academy/flags/de.svg', 'fr': 'academy/flags/fr.svg',
                       'ckb': 'academy/flags/ckb.svg', 'kmr':'academy/flags/ckb.svg',
                       'ku':'academy/flags/ckb.svg','uk':'academy/flags/uk.svg'}
        options = [
            {'value': value, 'name': label, 'symbol': 'ع' if value == 'ar' else code,
             'flag_path': flag_assets.get(value, ''), 'detail': ''}
            for value, label, code in APP_LANGUAGES
        ] if step == 1 else (
            [{'value': str(item['id']), 'name': item['name'], 'symbol': item['code'],
              'flag_path': flag_assets.get(item['code'].lower(), ''), 'detail': item['native']}
             for item in localized_courses] if step == 2 else (
                ([{'value': 'beginner', 'name': L['beginner'], 'symbol': 'A0', 'detail': L['beginner_detail']}] +
                 ([{'value': 'placement', 'name': L['placement'], 'symbol': '?', 'detail': L['placement_detail']}]
                  if quiz_available else []))
                if step == 3 else [
                    {'value': str(xp), 'name': L['goals'][i][0], 'symbol': str(xp) + ' XP', 'detail': L['goals'][i][1]}
                    for i, xp in enumerate(GOALS)])
        )
        back = reverse('onboarding') + '?step=' + str(step - 1) if step > 1 else None
        return render(request, 'academy/onboarding_v52.html', {
            'L': L, 'step': step, 'step_text': L['step_label'].format(step=step),
            'question': (L['questions'][2][0], L['no_quiz']) if step == 3 and not quiz_available
                        else L['questions'][step - 1],
            'options': options, 'selected': selected,
            'kurdish_options': [item for item in options if item['value'] in ('ckb','kmr','ku')] if step == 1 else [],
            'other_options': [item for item in options if item['value'] not in ('ckb','kmr','ku')] if step == 1 else [],
            'kurdish_selected': selected in ('ckb','kmr','ku') if step == 1 else False,
            'kurdish_labels': KURDISH_SELECTOR_LABELS.get(locale, KURDISH_SELECTOR_LABELS['en']),
            'back': back, 'error': error, 'has_courses': bool(courses),
            'can_skip': False, 'locale': locale,
            'quiz_available': quiz_available,
            'noindex': True,
        })


@login_required
@require_GET
def ready(request):
    profile = request.user.learning_profile
    if has_manager_role(request.user):
        return redirect('manager')
    if profile.onboarding_required and not profile.onboarding_completed:
        return redirect('onboarding')
    if request.session.pop('r52_ready_once', None) != '1':
        return _redirect_after_setup(profile)
    locale = _locale(profile)
    L = localized_copy(locale)
    language = profile.preferred_language
    language_name = LANGUAGE_NAMES.get(locale, LANGUAGE_NAMES['en']).get(language.code, language.name) if language else ''
    destination = reverse('play_hub') if profile.placement_completed else reverse('smart_placement_v77')
    # Keep a previously requested local learning feature after first setup,
    # while all ordinary returning visits resume the learning path.
    if profile.placement_completed:
        from .views import _post_setup_destination
        destination = _post_setup_destination(request)
    return render(request, 'academy/onboarding_ready_v52.html', {
        'L': L, 'locale': locale, 'language_name': language_name,
        'profile': profile, 'destination': destination,
        'noindex': True,
    })

"""V42 evolution of pending-recovery tests: unverified emails are NOT trusted for reset.

Legacy V39 permitted password reset to unverified addresses; V42 deliberately
closes that takeover risk. Tests use only Django's isolated test database.
"""
import re
from urllib.parse import urlsplit
from django.contrib.auth import get_user_model
from django.core import mail
from django.core.cache import cache
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

User=get_user_model()

@override_settings(MAILERS={'default':{'BACKEND':'django.core.mail.backends.locmem.EmailBackend'}})
class VerifiedOnlyRecoveryTests(TestCase):
    PASSWORD='Recover-Strong-2026!'
    def setUp(self):
        cache.clear()
        self.account=User.objects.create_user('pending39','pending39@example.test',self.PASSWORD,is_active=False)
    def reset(self):
        return self.client.post(reverse('password_reset'),{'email':self.account.email})
    def test_pending_without_email_proof_does_not_get_reset_token(self):
        self.assertEqual(self.reset().status_code,302)
        self.assertEqual(len(mail.outbox),0)
        self.account.refresh_from_db()
        self.assertFalse(self.account.is_active)
    def test_explicit_mail_verification_then_recovery(self):
        self.assertEqual(self.client.post(reverse('resend_verification'),{'email':self.account.email}).status_code,302)
        self.assertEqual(len(mail.outbox),1)
        match=re.search(r'https?://[^\s]+/verify/[^\s]+',mail.outbox[-1].body)
        self.assertIsNotNone(match)
        url=urlsplit(match.group()).path
        self.assertEqual(self.client.get(url).status_code,200)
        self.account.refresh_from_db();self.assertFalse(self.account.is_active)
        self.assertEqual(self.client.post(url).status_code,302)
        self.account.refresh_from_db()
        self.assertTrue(self.account.is_active)
        self.assertIsNotNone(self.account.learning_profile.email_verified_at)
        mail.outbox.clear()
        self.assertEqual(self.reset().status_code,302)
        self.assertEqual(len(mail.outbox),1)
        self.assertIn('/reset/',mail.outbox[0].body)
    def test_manager_suspension_prohibits_reset_and_activation(self):
        p=self.account.learning_profile
        p.suspended_at=timezone.now();p.save(update_fields=['suspended_at'])
        self.assertEqual(self.reset().status_code,302)
        self.assertEqual(self.client.post(reverse('resend_verification'),{'email':self.account.email}).status_code,302)
        self.assertEqual(len(mail.outbox),0)
    def test_privileged_and_quarantined_pending_accounts_no_tokens(self):
        self.account.is_staff=True;self.account.save(update_fields=['is_staff'])
        self.assertEqual(self.reset().status_code,302)
        self.assertEqual(self.client.post(reverse('resend_verification'),{'email':self.account.email}).status_code,302)
        self.assertEqual(len(mail.outbox),0)
        self.account.is_staff=False;self.account.save(update_fields=['is_staff'])
        p=self.account.learning_profile;p.legacy_review_required=True;p.save(update_fields=['legacy_review_required'])
        self.assertEqual(self.reset().status_code,302)
        self.assertEqual(len(mail.outbox),0)
    def test_generic_unknown_mail_response(self):
        self.assertEqual(self.client.post(reverse('password_reset'),{'email':'unknown@example.test'}).status_code,302)
        self.assertEqual(len(mail.outbox),0)
    def test_local_private_mail_hint_only_for_file_backend(self):
        page=self.client.get(reverse('password_reset_done'))
        self.assertNotContains(page,'not delivered to your real inbox')
        with override_settings(MAILERS={'default':{'BACKEND':'django.core.mail.backends.filebased.EmailBackend'}}, DEBUG=True):
            page=self.client.get(reverse('password_reset_done'),{'ui':'en'})
            self.assertContains(page,'private .private-email-outbox folder')

"""Pure fail-closed access policy for Adaptive Practice.

Shared by the preview and the transactional submission path. Keeping this
predicate Django-independent enables meaningful offline behavior tests.
"""


def adaptive_practice_allowed(profile, level, *, user_active):
    if not user_active or profile is None or level is None:
        return False
    if getattr(profile, 'suspended_at', None) is not None:
        return False
    if getattr(profile, 'legacy_review_required', False):
        return False
    if (getattr(profile, 'onboarding_required', False)
            and not getattr(profile, 'onboarding_completed', False)):
        return False
    if not getattr(profile, 'placement_completed', False):
        return False
    language = getattr(level, 'language', None)
    return bool(
        getattr(profile, 'preferred_language_id', None) is not None
        and getattr(profile, 'preferred_language_id', None) == getattr(level, 'language_id', None)
        and getattr(language, 'is_published', False)
    )

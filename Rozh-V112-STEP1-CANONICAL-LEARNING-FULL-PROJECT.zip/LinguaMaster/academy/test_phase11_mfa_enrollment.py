"""Phase 11 Django integration tests (NOT executed without Django dependencies).

Use only via an isolated Django test database, never a real user's database.
"""
import pyotp
from django.contrib.auth import get_user_model
from django.test import Client, TestCase
from django.urls import reverse


class Phase11MFAEnrollmentTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user(
            username='phase11-learner',email='phase11@example.invalid',
            password='Phase11-Only-Test-Passphrase!')

    def test_enrollment_creates_eight_one_time_recovery_codes(self):
        self.client.force_login(self.user)
        start=self.client.get(reverse('mfa_setup'))
        self.assertEqual(start.status_code,200)
        secret=self.client.session['mfa_setup_secret']
        response=self.client.post(reverse('mfa_setup'),
                                  {'code':pyotp.TOTP(secret).now(), 'password':'Phase11-Only-Test-Passphrase!'})
        self.assertEqual(response.status_code,302)
        self.assertEqual(response['Location'],reverse('mfa_recovery'))
        self.user.learning_profile.refresh_from_db()
        self.assertEqual(self.user.learning_profile.totp_secret,secret)
        self.assertEqual(len(self.user.learning_profile.mfa_recovery_hashes),8)
        self.assertEqual(len(self.client.session['mfa_recovery_codes_once']),8)

    def test_two_existing_setup_sessions_cannot_replace_active_totp(self):
        first=Client();second=Client()
        first.force_login(self.user);second.force_login(self.user)
        first.get(reverse('mfa_setup'));second.get(reverse('mfa_setup'))
        old_secret=first.session['mfa_setup_secret']
        second_secret=second.session['mfa_setup_secret']
        self.assertNotEqual(old_secret,second_secret)
        response=first.post(reverse('mfa_setup'),{'code':pyotp.TOTP(old_secret).now(), 'password':'Phase11-Only-Test-Passphrase!'})
        self.assertEqual(response.status_code,302)
        self.user.learning_profile.refresh_from_db()
        recovery=list(self.user.learning_profile.mfa_recovery_hashes)
        result=second.post(reverse('mfa_setup'),{'code':pyotp.TOTP(second_secret).now(), 'password':'Phase11-Only-Test-Passphrase!'})
        self.assertEqual(result.status_code,302)
        self.assertEqual(result['Location'],reverse('profile'))
        self.user.learning_profile.refresh_from_db()
        self.assertEqual(self.user.learning_profile.totp_secret,old_secret)
        self.assertEqual(self.user.learning_profile.mfa_recovery_hashes,recovery)
        self.assertNotIn('mfa_recovery_codes_once',second.session)

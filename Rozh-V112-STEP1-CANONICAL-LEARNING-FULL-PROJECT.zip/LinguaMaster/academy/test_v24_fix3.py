"""Real Django integration tests for locked levels and empty Seasons.

Run on an installed Django environment: python manage.py test academy.test_v24_fix3
Tests create a temporary test database only; they never edit the user's SQLite file.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Exercise, Language, Lesson, LessonProgress, Level, Unit, XPEvent


class V24Fix3RuntimeTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            username='v24-fix3-learner', email='v24-fix3@example.test', password='StrongTestPassword!2026')
        cls.lang = Language.objects.create(name='Dutch', code='nl', slug='v24-fix3-dutch',
                                           description='Dutch', is_published=True)
        cls.level = Level.objects.create(language=cls.lang, code='A0', order=0, description='First steps')
        cls.current = Unit.objects.create(level=cls.level, slug='v24-fix3-first',
                                          title='First step', summary='Start here', order=1, published=True)
        lesson = Lesson.objects.create(unit=cls.current, slug='v24-fix3-hello', title='Hello',
                                       skill='grammar', content='Hello', order=1, published=True)
        Exercise.objects.create(lesson=lesson, kind='mcq', prompt='Which greeting?',
                                options=['Hallo', 'Nee'], answer='Hallo', explanation='The greeting is Hallo')
        cls.locked = Unit.objects.create(level=cls.level, slug='v24-fix3-second',
                                         title='Second step', summary='Locked by test', order=2, published=True)
        Lesson.objects.create(unit=cls.locked, slug='v24-fix3-locked', title='Later',
                              skill='grammar', content='Later', order=1, published=True)
        cls.locked.prerequisites.add(cls.current)
        profile = cls.user.learning_profile
        profile.preferred_language = cls.lang
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.ui_language = 'nl'
        profile.save()

    def setUp(self):
        self.client.force_login(self.user)

    def test_visible_resume_and_locked_explanation_are_correct(self):
        response = self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Level 1')
        self.assertContains(response, 'Eerst vorige level afronden')
        self.assertContains(response, reverse('journey_play', args=[self.current.pk]))
        self.assertNotContains(response, reverse('journey_play', args=[self.locked.pk]))
        self.assertContains(response, 'id="lm24-current-checkpoint"')
        self.assertContains(response, 'href="#lm24-current-checkpoint"')

    def test_locked_direct_game_get_and_post_rejected(self):
        response = self.client.get(reverse('journey_play', args=[self.locked.pk]))
        self.assertEqual(response.status_code, 403)
        response = self.client.post(reverse('journey_answer', args=[self.locked.pk]),
                                    {'answer': 'Hallo', 'round_token': 'invalid', 'challenge_id': 'invalid'})
        self.assertEqual(response.status_code, 403)
        self.assertEqual(LessonProgress.objects.filter(user=self.user).count(), 0)
        self.assertEqual(XPEvent.objects.filter(user=self.user).count(), 0)

    def test_empty_world_no_false_reward_or_start_link(self):
        self.current.published=False
        self.current.save(update_fields=['published'])
        self.locked.published=False
        self.locked.save(update_fields=['published'])
        response = self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Er staan nog geen gepubliceerde levels in deze wereld.')
        self.assertNotContains(response, 'class="lm20-season-reward lm24-world-finish"')
        self.assertNotContains(response, 'href="'+self.level.get_absolute_url()+'"')

    def test_get_play_hub_does_not_award_xp(self):
        self.client.get(reverse('play_hub'))
        self.assertEqual(XPEvent.objects.filter(user=self.user).count(), 0)
        self.assertEqual(LessonProgress.objects.filter(user=self.user).count(), 0)

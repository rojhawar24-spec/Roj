"""Step 3H: durable, per-learner record for a server-issued lesson round.

Session values are presentation hints, not a concurrency-safe grading ledger. The
receipt row is exclusively locked within the caller's database transaction.
"""
from django.conf import settings
from django.db import models
from django.utils import timezone


class LessonRoundReceipt(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                             related_name='lesson_round_receipts')
    lesson = models.ForeignKey('academy.Lesson', on_delete=models.CASCADE,
                               related_name='round_receipts')
    round_key = models.CharField(max_length=32)
    channel = models.CharField(max_length=4, choices=[('ajax', 'Question by question'),
                                                        ('ssr', 'Complete form')])
    # Only correctness booleans, never raw typed answers or personal content.
    answers = models.JSONField(default=dict, blank=True)
    score = models.PositiveSmallIntegerField(null=True, blank=True)
    finished_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=('user', 'lesson', 'round_key'),
                                               name='one_lesson_round_receipt_step3h')]

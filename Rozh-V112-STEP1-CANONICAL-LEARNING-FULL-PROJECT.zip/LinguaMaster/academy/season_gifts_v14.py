"""Secure one-time rewards for completed CEFR seasons.

Course seasons are existing Level records (A0..C1), not global user XP levels.
All amounts are server-side and configurable in secure Django admin.
"""
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import F
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect
from django.views.decorators.http import require_POST

from .models import Assessment, CoinEvent, Language, Level, Profile, SeasonGift, SeasonGiftClaim
from .services import award_xp, notify, rate_limit


DEFAULT_XP = 50
DEFAULT_COINS = 100


class SeasonGiftUnavailable(Exception):
    pass


def season_reward_access_allowed(profile, language_id):
    """Pure reward gate; do not trust a previously completed assessment alone."""
    return bool(
        profile.placement_completed
        and profile.preferred_language_id == language_id
        and (not profile.onboarding_required or profile.onboarding_completed)
        and profile.suspended_at is None
        and not profile.legacy_review_required
    )


def claim_season_gift(user, level):
    """Grant at most once, even on double-click or concurrent requests.

    Returns (newly_claimed, xp, coins). Every operation is one DB transaction.
    Caller must not rely on a browser-reported result or payment status.
    """
    if not user.is_authenticated:
        raise SeasonGiftUnavailable('Login required.')

    with transaction.atomic():
        # The same Profile row is locked by the course-switch action. Always
        # read its CURRENT state inside this transaction; never trust the
        # course chosen when the page was rendered or an earlier user object.
        profile = Profile.objects.select_for_update().get(user=user)
        if not profile.preferred_language_id:
            raise SeasonGiftUnavailable('Choose a course first.')
        # Lock in Profile -> Language -> Level order, consistent with the
        # assessment reward path. Publication and level affiliation can change
        # while the learner is reading the page.
        language = Language.objects.select_for_update().get(
            pk=profile.preferred_language_id
        )
        locked_level = Level.objects.select_for_update().get(pk=level.pk)
        if (not season_reward_access_allowed(profile, locked_level.language_id)
                or not language.is_published):
            raise SeasonGiftUnavailable('Course or onboarding is unavailable.')
        if not Assessment.objects.filter(
                user=user, kind='level', level=locked_level, passed=True).exists():
            raise SeasonGiftUnavailable('Finish the season test first.')
        level = locked_level
        previous = SeasonGiftClaim.objects.filter(user=user, level=level).first()
        if previous:
            return False, previous.xp_awarded, previous.coins_awarded

        # A missing config uses safe defaults. Admin can disable or adjust it.
        gift, _ = SeasonGift.objects.get_or_create(
            level=level, defaults={'bonus_xp': DEFAULT_XP, 'bonus_coins': DEFAULT_COINS}
        )
        if not gift.enabled:
            raise SeasonGiftUnavailable('This reward is currently unavailable.')
        xp, coins = gift.bonus_xp, gift.bonus_coins
        if not (0 <= xp <= 250 and 0 <= coins <= 5000):
            raise SeasonGiftUnavailable('Reward is misconfigured.')
        claim, created = SeasonGiftClaim.objects.get_or_create(
            user=user, level=level,
            defaults={'xp_awarded':xp, 'coins_awarded':coins}
        )
        if not created:
            return False, claim.xp_awarded, claim.coins_awarded
        if xp:
            # Existing durable XP ledger ensures duplicate season events cannot inflate XP.
            if not award_xp(user, xp, reason='season', event_key=f'season:{level.pk}', learning=False):
                raise SeasonGiftUnavailable('Duplicate XP event.')
        if coins:
            CoinEvent.objects.create(user=user, key=f'season:{level.pk}', amount=coins)
            Profile.objects.filter(pk=profile.pk).update(coins=F('coins') + coins)
        notify(user, f'season-gift:{level.pk}', 'Season reward 🎁',
               f'You completed {level.language.name} {level.code}: +{xp} XP, +{coins} coins.')
        return True, claim.xp_awarded, claim.coins_awarded


COPY = {
    'nl': {'success':'Seizoenscadeau ontvangen!', 'claimed':'Dit cadeau had je al opgehaald.',
           'unavailable':'Dit cadeau is nog niet beschikbaar.'},
    'en': {'success':'Season gift received!', 'claimed':'You already claimed this gift.',
           'unavailable':'This gift is not available yet.'},
    'ckb': {'success':'دیاریی وەرزەکەت وەرگرت!', 'claimed':'پێشتر ئەم دیارییەت وەرگرتووە.',
            'unavailable':'هێشتا ئەم دیارییە بەردەست نییە.'},
    'ar': {'success':'لقد حصلت على هدية الموسم!', 'claimed':'لقد حصلت على هذه الهدية بالفعل.',
           'unavailable':'هذه الهدية غير متاحة بعد.'},
}


@login_required
@require_POST
def claim_season_gift_view(request, pk):
    if rate_limit(request, 'season-gift', 10, 3600, True):
        return HttpResponse(status=429)
    level = get_object_or_404(Level.objects.select_related('language'), pk=pk)
    labels = COPY.get(request.user.learning_profile.ui_language, COPY['en'])
    try:
        created, _, _ = claim_season_gift(request.user, level)
    except SeasonGiftUnavailable:
        messages.error(request, labels['unavailable'])
    else:
        messages.success(request, labels['success'] if created else labels['claimed'])
    return redirect('play_hub')


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'season_gifts_v14', ['COPY'])

"""Django integration checks for previously uncaught missing-Profile actions.

These tests require real Django and must only be run by the disposable SQLite
runner. Static/offline source checks are NOT equivalent to these tests.
"""
import json
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .models import Profile, AuditEvent


class OwnerActionsAgainstIncompleteAccountTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.owner = User.objects.create_superuser(
            username='v8_owner', email='v8-owner@example.invalid', password='OwnerOnly#2026v8'
        )
        owner_profile = self.owner.learning_profile
        owner_profile.email_verified_at = timezone.now()
        owner_profile.totp_secret = 'JBSWY3DPEHPK3PXP'
        owner_profile.save(update_fields=['email_verified_at', 'totp_secret'])
        self.target = User.objects.create_user(
            username='v8_incomplete', email='v8-incomplete@example.invalid', password='TargetOnly#2026v8'
        )
        Profile.objects.filter(user=self.target).delete()
        self.client.force_login(self.owner)
        session = self.client.session
        session['mfa_verified_id'] = self.owner.pk
        session.save()

    def test_all_manager_actions_fail_closed_without_profile(self):
        before = AuditEvent.objects.count()
        for action in ('block', 'unblock', 'delete', 'promote', 'demote', 'approve_legacy'):
            with self.subTest(action=action):
                result = self.client.post(reverse('manager_user_action', args=[self.target.pk, action]))
                self.assertEqual(result.status_code, 409)
                self.target.refresh_from_db()
                self.assertTrue(self.target.is_active)
                self.assertFalse(self.target.is_staff)
                self.assertFalse(Profile.objects.filter(user=self.target).exists())
        self.assertEqual(AuditEvent.objects.count(), before)

    def test_missing_profile_user_still_listed_for_owner_review(self):
        result = self.client.get(reverse('manager_users'))
        self.assertEqual(result.status_code, 200)
        self.assertIn(self.target.pk, [u.pk for u in result.context['users']])


class MissingProfileSelfServiceTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username='v8_legacy', email='v8-legacy@example.invalid', password='TestOnly#2026v8'
        )
        Profile.objects.filter(user=self.user).delete()
        self.client.force_login(self.user)

    def test_mfa_disable_missing_profile_logs_out_without_creating_one(self):
        result = self.client.post(reverse('mfa_disable'), {'code': '123456'})
        self.assertRedirects(result, reverse('login'), fetch_redirect_response=False)
        self.assertNotIn('_auth_user_id', self.client.session)
        self.assertFalse(Profile.objects.filter(user=self.user).exists())

    def test_missing_profile_mfa_disable_denied_before_throttling_or_feedback(self):
        # On 429/privileged branches template context previously accessed
        # user.learning_profile and crashed before our in-transaction guard.
        from unittest.mock import patch
        with patch('academy.views.rate_limit') as limiter:
            response = self.client.post(reverse('mfa_disable'), {'code': 'not-a-code'})
        self.assertRedirects(response, reverse('login'), fetch_redirect_response=False)
        limiter.assert_not_called()
        self.assertFalse(Profile.objects.filter(user=self.user).exists())

    def test_data_export_missing_profile_returns_remaining_account_data(self):
        result = self.client.post(reverse('data_export'), {'password': 'TestOnly#2026v8'})
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result['Content-Type'], 'application/json')
        payload = json.loads(result.content)
        self.assertEqual(payload['username'], self.user.username)
        self.assertEqual(payload['email'], self.user.email)
        self.assertIsNone(payload['profile'])
        self.assertEqual(payload['completed_lessons'], [])
        self.assertFalse(Profile.objects.filter(user=self.user).exists())
        self.assertIn('no-store', result['Cache-Control'])

    def test_missing_profile_export_is_not_available_anonymously(self):
        self.client.logout()
        result = self.client.post(reverse('data_export'), {'password': 'TestOnly#2026v8'})
        self.assertEqual(result.status_code, 302)
        self.assertIn('/login/', result['Location'])

    def test_data_export_with_normal_profile_is_unchanged(self):
        Profile.objects.create(user=self.user, xp=37, streak=2)
        result = self.client.post(reverse('data_export'), {'password': 'TestOnly#2026v8'})
        self.assertEqual(result.status_code, 200)
        data = json.loads(result.content)
        self.assertEqual(data['profile']['xp'], 37)
        self.assertEqual(data['profile']['streak'], 2)
        self.assertTrue(Profile.objects.filter(user=self.user).exists())

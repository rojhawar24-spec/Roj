"""V13 real Django HTTP/DB tests; run ONLY against an isolated test database.

These are intentionally not part of source-only Python unittest discovery.
"""
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse

from .models import AuditEvent


@override_settings(CACHES={'default': {'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
                                      'LOCATION': 'v13-auth-audit-tests'}})
class AuthAuditV13DjangoTests(TestCase):
    def setUp(self):
        self.password = 'V13-Private-Test-Password-2026!'
        self.user = get_user_model().objects.create_user(
            'auth_audit_v13', email='auth-audit@example.test', password=self.password)
        profile = self.user.learning_profile
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.save(update_fields=['onboarding_completed', 'placement_completed'])

    def test_real_password_login_creates_only_minimal_success_event(self):
        response = self.client.post(reverse('login'), {'email':self.user.email,
                                                       'password':self.password})
        self.assertEqual(response.status_code,302)
        row = AuditEvent.objects.get(action='login_success', actor=self.user)
        self.assertEqual((row.target,row.metadata),('authentication',{}))

    def test_invalid_credentials_remain_unattributed_and_secret_free(self):
        response = self.client.post(reverse('login'), {'email':self.user.email,
                                                       'password':'PRIVATE-INCORRECT'})
        self.assertEqual(response.status_code,200)
        row = AuditEvent.objects.get(action='login_failure')
        self.assertIsNone(row.actor)
        self.assertEqual((row.target,row.metadata),('authentication',{}))
        self.assertNotIn(self.user.email,str(row.metadata))

    def test_mfa_invalid_code_does_not_serialize_code_to_audit(self):
        profile = self.user.learning_profile
        profile.totp_secret = 'JBSWY3DPEHPK3PXP'
        profile.save(update_fields=['totp_secret'])
        session = self.client.session
        from .pending_mfa_binding_step2 import start_pending_mfa
        start_pending_mfa(session, self.user, self.user.learning_profile)
        session.save()
        with patch('academy.views.verify_totp_step', return_value=False):
            response = self.client.post(reverse('mfa_verify'), {'code':'000000'})
        self.assertIn(response.status_code,(200,429))
        row = AuditEvent.objects.get(action='mfa_failure',actor=self.user)
        self.assertEqual((row.target,row.metadata),('authentication',{}))

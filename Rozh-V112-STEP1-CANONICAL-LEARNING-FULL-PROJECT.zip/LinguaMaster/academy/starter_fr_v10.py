"""Original French starter material, not a complete or validated CEFR syllabus.

English explanations support beginner learners; examples and audio are French.
Speaking and writing activities invite self-review, not automatic certification.
"""


def mcq(prompt, options, answer, explanation):
    return {'kind': 'mcq', 'prompt': prompt, 'options': options,
            'answer': answer, 'explanation': explanation}


def short(prompt, answer, explanation):
    return {'kind': 'short', 'prompt': prompt, 'options': [],
            'answer': answer, 'explanation': explanation}


def lesson(skill, title, content, audio_text='', exercises=None):
    if skill == 'listening' and audio_text:
        content += '\n\nFrench transcript:\n' + audio_text
    return {'skill': skill, 'title': title, 'content': content,
            'audio_text': audio_text, 'exercises': exercises or []}


def word(text, translation, ipa, example, emoji):
    return {'word': text, 'translation': translation, 'pronunciation': ipa,
            'example': example, 'emoji': emoji}


BE_EXPLANATION = (
    'Use être to identify a person, describe someone, or say where someone is. '
    'Learn the present forms as complete pairs: je suis, tu es, il/elle est, '
    'nous sommes, vous êtes, ils/elles sont. These forms are irregular; do not '
    'try to build them with regular -er endings. In ordinary statements the '
    'subject comes before the verb: Je suis élève. Elle est à Paris.\n\n'
    'Choose tu for one person you address informally. Vous can address one '
    'person politely or several people. In both cases the verb is êtes. '
    'Bonjour works as a daytime greeting; salut is informal. Merci expresses '
    'thanks and au revoir is used when leaving.\n\n'
    'An adjective can change to match the person described: Il est français; '
    'elle est française. Nationality adjectives take a lower-case letter in '
    'French. For a basic profession statement, French commonly uses no '
    'indefinite article: Je suis professeur. English normally needs an article '
    'in its translation: I am a teacher. To ask politely about identity, use '
    'a complete question such as Vous êtes professeur ? with rising intonation '
    'in conversation. Practice the matching subject and verb before adding '
    'longer descriptions.'
)


BE_RICH = {
    'intro': (
        'A first conversation becomes easier when you can greet someone and '
        'build one reliable sentence about yourself. Être means “to be”. This '
        'guide focuses on its present tense in short statements about identity, '
        'description and location. It is a starting point, not a complete guide '
        'to every use of être.'
    ),
    'learning_goals': [
        'Match all six subject groups to the present form of être.',
        'Introduce yourself with a profession or a simple description.',
        'Choose tu or vous for an appropriate first conversation.',
        'Notice agreement in the model pair français / française.',
    ],
    'sections': [
        {'title': 'Build a small sentence you can reuse', 'body': (
            'Start with a subject, add the correct form of être, then add the '
            'information. Je suis élève identifies the speaker as a student. '
            'Elle est à Paris gives a location. Nous sommes ici says where a '
            'group including the speaker is. Keep the subject in ordinary '
            'statements even when the verb ending is not easy to hear. '
            'French is not usually a language where you can omit je or elle '
            'just because the context seems clear.')},
        {'title': 'Learn sound and spelling together', 'body': (
            'Être has irregular forms. The spelling of es belongs with tu; '
            'est belongs with il or elle. These forms can sound the same in '
            'isolation, so hearing one sound does not tell you which spelling '
            'to write. The subject supplies that information. In vous êtes, '
            'a linking /z/ sound is normally heard between vous and êtes. '
            'Listen to the complete phrase rather than trying to pronounce '
            'each written letter independently.')},
        {'title': 'Address one person or a group', 'body': (
            'Sentences beginning tu es fit one person in an informal '
            'relationship. Vous êtes fits a polite exchange with one person '
            'and also any group you address. The verb remains êtes in both '
            'uses. The social choice depends on the relationship and setting; '
            'it cannot be reduced to an age rule. Starting a formal first '
            'meeting with bonjour and vous is a useful beginner default.')},
        {'title': 'Compare French and English carefully', 'body': (
            'Translate the meaning, not every individual word. Je suis '
            'professeur normally becomes “I am a teacher”, even though the '
            'simple French profession statement has no un or une. A '
            'description may need adjective agreement: Il est français '
            'becomes Elle est française when the person described is female. '
            'This lesson models just that pair; it does not supply a full '
            'system for all adjective endings. Age is expressed with avoir, '
            'not with être: J’ai vingt ans. Save the avoir forms for a '
            'separate lesson rather than guessing a translation from English.')},
    ],
    'rule_tables': [{
        'title': 'Être: present tense',
        'columns': ['Subject', 'Verb', 'Complete example', 'Meaning'],
        'rows': [
            ['je', 'suis', 'Je suis élève.', 'I am a student.'],
            ['tu', 'es', 'Tu es ici.', 'You are here.'],
            ['il / elle', 'est', 'Elle est à Paris.', 'She is in Paris.'],
            ['nous', 'sommes', 'Nous sommes ici.', 'We are here.'],
            ['vous', 'êtes', 'Vous êtes professeur.', 'You are a teacher.'],
            ['ils / elles', 'sont', 'Ils sont à Lyon.', 'They are in Lyon.'],
        ],
        'note': 'Vous can refer to one person politely or to several people. '
                'Ils and elles both use sont.',
    }, {
        'title': 'Useful choices in a first conversation',
        'columns': ['Purpose', 'French', 'When to use it'],
        'rows': [
            ['Daytime greeting', 'Bonjour.', 'A neutral polite opening.'],
            ['Informal greeting', 'Salut !', 'With someone you address informally.'],
            ['Thanks', 'Merci.', 'To express gratitude.'],
            ['Goodbye', 'Au revoir.', 'When leaving an exchange.'],
        ],
        'note': 'A greeting and a thank-you perform different jobs in a conversation.',
    }],
    'sentence_patterns': [
        {'label': 'Identity: subject + être + profession', 'tokens': [
            {'text': 'Je', 'role': 'subject'}, {'text': 'suis', 'role': 'verb'},
            {'text': 'professeur.', 'role': 'other'}]},
        {'label': 'Location: subject + être + place', 'tokens': [
            {'text': 'Elle', 'role': 'subject'}, {'text': 'est', 'role': 'verb'},
            {'text': 'à Paris.', 'role': 'place'}]},
        {'label': 'A group including the speaker', 'tokens': [
            {'text': 'Nous', 'role': 'subject'}, {'text': 'sommes', 'role': 'verb'},
            {'text': 'ici.', 'role': 'place'}]},
    ],
    'example_pairs': [
        {'original': 'Bonjour, je suis élève.', 'translation': 'Hello, I am a student.',
         'note': 'A greeting followed by a short introduction.'},
        {'original': 'Vous êtes professeur.', 'translation': 'You are a teacher.',
         'note': 'A basic profession statement normally has no indefinite article.'},
        {'original': 'Elle est française.', 'translation': 'She is French.',
         'note': 'Française agrees with elle; the nationality adjective is lower-case.'},
        {'original': 'Nous sommes à Paris.', 'translation': 'We are in Paris.',
         'note': 'À introduces the city in this location example.'},
    ],
    'common_traps': [
        {'wrong': 'Je est élève.', 'correct': 'Je suis élève.',
         'why': 'Je requires suis; est belongs with il or elle.'},
        {'wrong': 'Vous sont ici.', 'correct': 'Vous êtes ici.',
         'why': 'Vous takes êtes whether it addresses one person politely or a group.'},
        {'wrong': 'Elle est français.', 'correct': 'Elle est française.',
         'why': 'In this example the nationality adjective needs its feminine form.'},
        {'wrong': 'Je suis vingt ans.', 'correct': 'J’ai vingt ans.',
         'why': 'French uses avoir for age. Être is not the appropriate verb here.'},
    ],
}


COURSE = {
    'code': 'fr', 'name': 'French', 'slug': 'french',
    'description': (
        'Original French starter lessons for first conversations, noun articles '
        'and everyday present-tense sentences. A0 and A1 contain introductory '
        'material; A2–C1 are curriculum placeholders awaiting authored content. '
        'This growing course is not a complete or validated CEFR programme.'
    ),
    'units': [
        {
            'level': 'A0', 'slug': 'introductions-with-etre',
            'title': 'Bonjour: introduce yourself with être',
            'summary': 'Greet someone and match je, tu, elle, nous and vous to être.',
            'outcomes': [
                'Choose a suitable greeting or goodbye.',
                'Introduce yourself using je suis.',
                'Match subjects to present-tense forms of être.',
            ],
            'explanation': BE_EXPLANATION,
            'examples': ['Bonjour, je suis élève.', 'Elle est française.',
                         'Nous sommes à Paris.', 'Vous êtes professeur.'],
            'exceptions': (
                'Être is irregular. Vous can mean one polite “you” or several '
                'people. French uses avoir for age: J’ai vingt ans.'
            ),
            'common_mistakes': 'Use je suis, not je est. Match elle with française '
                               'in this model sentence: Elle est française.',
            'rich': BE_RICH,
            'lessons': [
                lesson('grammar', 'Meet the present forms of être', BE_EXPLANATION,
                       'Je suis élève. Tu es ici. Elle est française. Nous sommes à Paris. Vous êtes professeur. Ils sont à Lyon.', [
                    mcq('Complete: Je ... élève.', ['suis', 'est', 'sommes'], 'suis',
                        'The present-tense form of être used with je is suis.'),
                    short('Write the missing verb only: Vous ... professeur.', 'êtes',
                          'Vous requires êtes. Keep the circumflex accent in the spelling.'),
                    mcq('Choose the matching subject and verb.',
                        ['Nous sommes ici.', 'Nous sont ici.', 'Nous êtes ici.'],
                        'Nous sommes ici.', 'Nous pairs with sommes.'),
                ]),
                lesson('reading', 'Two people meet at a language school',
                       'Read this short exchange. Notice which information each person gives.\n\n'
                       '— Bonjour ! Je suis élève. Je suis à Paris.\n'
                       '— Bonjour ! Je suis professeur.\n'
                       '— Vous êtes français ?\n'
                       '— Oui, je suis français.\n'
                       '— Merci. Au revoir !\n\n'
                       'The question uses vous for a polite exchange. Au revoir closes the conversation.',
                       'Bonjour ! Je suis élève. Je suis à Paris. Bonjour ! Je suis professeur. Vous êtes français ? Oui, je suis français. Merci. Au revoir !', [
                    mcq('Where is the student?', ['À Paris.', 'À Lyon.', 'À Nice.'], 'À Paris.',
                        'The student says Je suis à Paris.'),
                    mcq('What is the second person’s profession?', ['Professeur.', 'Médecin.', 'Artiste.'],
                        'Professeur.', 'The second person says Je suis professeur.'),
                    short('Copy the one-word expression of thanks from the exchange, without punctuation.',
                          'Merci', 'Merci means thank you. Au revoir is the goodbye.'),
                ]),
                lesson('listening', 'Hear a short introduction',
                       'Use the audio control. Listen once for the greeting and once '
                       'for the people and place. Answer from what you hear. '
                       'The device voice must support French; if it is unavailable, '
                       'read the transcript as a supported reading exercise.',
                       'Bonjour. Je suis professeur. Elle est élève. Nous sommes à Lyon. Merci et au revoir.', [
                    mcq('What is the speaker?', ['Professeur.', 'Élève.', 'Artiste.'], 'Professeur.',
                        'The speaker says Je suis professeur.'),
                    mcq('Which city do you hear?', ['Lyon', 'Paris', 'Lille'], 'Lyon',
                        'The recording says Nous sommes à Lyon.'),
                    short('Complete the phrase you hear. Write the verb only: Nous ... à Lyon.',
                          'sommes', 'The subject nous takes sommes.'),
                ]),
                lesson('speaking', 'Give your first introduction',
                       'Listen, then say Bonjour. Je suis élève. Nous sommes ici. '
                       'Repeat with a comfortable pace. Next, introduce yourself '
                       'using a description that is true for you. Say vous êtes '
                       'as a complete phrase and listen for its linking /z/ sound. '
                       'Compare your wording with the models before marking '
                       'the activity self-reviewed. This is speaking practice, '
                       'not an independently graded pronunciation assessment.',
                       'Bonjour. Je suis élève. Nous sommes ici. Vous êtes professeur.'),
                lesson('writing', 'Write a greeting and two statements',
                       'Write a greeting, one sentence beginning Je suis and one '
                       'sentence beginning Nous sommes. You may use élève, '
                       'professeur, ici or à Paris when appropriate. Check that '
                       'each sentence has a subject, the matching verb and final '
                       'punctuation. End with a goodbye. Review your own work '
                       'against the models before marking this self-check '
                       'complete. No automated grammar score is issued.'),
            ],
            'vocabulary': [
                word('bonjour', 'hello / good day', '/bɔ̃.ʒuʁ/', 'Bonjour, je suis élève.', '👋'),
                word('salut', 'hi / bye (informal)', '/sa.ly/', 'Salut, tu es ici !', '🙋'),
                word('merci', 'thank you', '/mɛʁ.si/', 'Merci, madame.', '🙏'),
                word('au revoir', 'goodbye', '/o ʁə.vwaʁ/', 'Au revoir, à demain !', '👋'),
                word('élève', 'pupil / student', '/e.lɛv/', 'Elle est élève.', '🎒'),
                word('professeur', 'teacher', '/pʁɔ.fɛ.sœʁ/', 'Vous êtes professeur.', '🧑‍🏫'),
            ],
        },
        {
            'level': 'A0', 'slug': 'articles-and-everyday-objects',
            'title': 'Un livre, une table: articles and objects',
            'summary': 'Learn a noun together with its article and recognize a plural group.',
            'outcomes': [
                'Use un with a masculine singular noun and une with a feminine singular noun.',
                'Recognize le, la, l’ and les in everyday noun phrases.',
                'Read a short description of a classroom.',
            ],
            'explanation': (
                'French nouns have grammatical gender. Learn the article with '
                'the noun: un livre is masculine and une table is feminine. '
                'The gender of an object is not its biological sex; it is a '
                'property of the noun. Un and une introduce one unspecified '
                'item. Des introduces an unspecified plural group: des livres, '
                'des tables.\n\n'
                'Use le for a masculine singular noun and la for a feminine '
                'singular noun when referring to the identified item: le livre, '
                'la table. Before a vowel sound or a mute h, le and la become '
                'l’: l’école. With plural nouns, use les for both genders: '
                'les livres, les tables. Written plural -s is often not '
                'pronounced, so the article is an important listening clue. '
                'Compare un livre with des livres.\n\n'
                'The classroom phrase Le livre est sur la table means “The '
                'book is on the table”. Start by recognizing the complete '
                'groups le livre and la table. Do not guess a noun’s gender '
                'only from its final letter; learn and check the noun with '
                'its article.'
            ),
            'examples': ['un livre → le livre', 'une table → la table',
                         'une école → l’école', 'des livres → les livres'],
            'exceptions': 'Some words beginning with written h block elision. '
                          'Learn these individually later. L’ does not tell '
                          'you whether a noun is masculine or feminine.',
            'common_mistakes': 'Say une table and un livre. The plural definite '
                               'article is les for both genders; it is not las.',
            'lessons': [
                lesson('grammar', 'Give each noun its article',
                       'Learn the pairs un livre / le livre and une table / la '
                       'table. L’école uses l’ before a vowel sound. A plural '
                       'group can be des livres or les livres. Des leaves '
                       'the group unspecified; les identifies the group in context.',
                       'Un livre. Le livre. Une table. La table. Une école. L’école. Des livres. Les livres.', [
                    mcq('Choose the indefinite singular phrase for “a table”.',
                        ['une table', 'un table', 'des table'], 'une table',
                        'Table is feminine singular, so use une.'),
                    short('Write the missing definite article only: ... livres (the books).',
                          'les', 'The plural definite article is les for both genders.'),
                    mcq('Which phrase correctly uses elision?',
                        ['l’école', 'la école', 'le école'], 'l’école',
                        'École begins with a vowel sound, so la becomes l’.'),
                ]),
                lesson('reading', 'Look around a classroom',
                       'Read the description. Sur means “on” and près de means '
                       '“near”.\n\n'
                       'Voici une classe. Le livre est sur la table. '
                       'Le cahier est sur la chaise. La porte est près de la table.\n\n'
                       'Picture each object in its location. Notice the article '
                       'every time a noun appears.',
                       'Voici une classe. Le livre est sur la table. Le cahier est sur la chaise. La porte est près de la table.', [
                    mcq('Where is the book?', ['Sur la table.', 'Sur la chaise.', 'Près de la porte.'],
                        'Sur la table.', 'The text says Le livre est sur la table.'),
                    mcq('What is on the chair?', ['Le cahier.', 'La porte.', 'Le livre.'],
                        'Le cahier.', 'The text says Le cahier est sur la chaise.'),
                    short('Copy the noun meaning “door”, without its article.',
                          'porte', 'La porte means the door; the noun alone is porte.'),
                ]),
                lesson('listening', 'Hear one item and several items',
                       'Listen for the article before each noun. Then listen '
                       'again for the item described as being on the table. '
                       'If French speech is unavailable, use the transcript '
                       'and treat this as a reading exercise.',
                       'Un livre. Une chaise. Des cahiers. Le livre est sur la table. La porte est ici.', [
                    mcq('Which plural group do you hear?', ['Des cahiers.', 'Des tables.', 'Des portes.'],
                        'Des cahiers.', 'Des cahiers is the plural group in the recording.'),
                    short('Write the article heard before chaise.', 'une',
                          'The recording says une chaise.'),
                    mcq('What is on the table?', ['Le livre.', 'La chaise.', 'La porte.'],
                        'Le livre.', 'The complete statement is Le livre est sur la table.'),
                ]),
                lesson('speaking', 'Name the objects around you',
                       'Repeat each pair with its article: un livre, une table, '
                       'un cahier, une chaise. Point to a real object or a '
                       'picture while saying its phrase. Then say Le livre '
                       'est sur la table. Listen for the difference between '
                       'un and une; do not try to pronounce every final '
                       'written consonant. Compare with the model and mark '
                       'completion only after self-review. Pronunciation '
                       'is not independently graded.',
                       'Un livre. Une table. Un cahier. Une chaise. Le livre est sur la table.'),
                lesson('writing', 'Label your small classroom',
                       'Write six labels using livre, table, école, cahier, '
                       'chaise and porte. Add an indefinite article to each '
                       'singular noun. Check: un livre, une table, une école, '
                       'un cahier, une chaise, une porte. Then rewrite livre '
                       'and table as plural definite phrases. Your models are '
                       'les livres and les tables. This is a self-reviewed '
                       'writing activity, without an independent grammar score.'),
            ],
            'vocabulary': [
                word('livre', 'book', '/livʁ/', 'Le livre est sur la table.', '📘'),
                word('table', 'table', '/tabl/', 'La table est ici.', '🪑'),
                word('école', 'school', '/e.kɔl/', 'L’école est à Paris.', '🏫'),
                word('cahier', 'exercise book / notebook', '/ka.je/', 'Le cahier est sur la chaise.', '📓'),
                word('chaise', 'chair', '/ʃɛz/', 'La chaise est près de la table.', '🪑'),
                word('porte', 'door', '/pɔʁt/', 'La porte est près de la table.', '🚪'),
            ],
        },
        {
            'level': 'A1', 'slug': 'regular-er-verbs-and-routine',
            'title': 'Je parle: describe an everyday routine',
            'summary': 'Build short present-tense statements with regular -er verbs.',
            'outcomes': [
                'Match regular -er endings to the subject.',
                'Read and hear a short work-and-study routine.',
                'Write an everyday sentence and a simple negative.',
            ],
            'explanation': (
                'Many French verbs end in -er. For a regular present-tense '
                'verb such as parler, remove -er to find parl-, then add '
                'the matching ending: je parle, tu parles, il/elle parle, '
                'nous parlons, vous parlez, ils/elles parlent. The forms '
                'with je, tu, il, elle, ils and elles often sound alike, '
                'but their spellings differ. Keep the subject and ending '
                'together when you write.\n\n'
                'Use the same basic pattern for travailler and habiter. '
                'Before a vowel sound or mute h, je becomes j’: j’habite. '
                'Étudier keeps the i in its stem: nous étudions. A short '
                'statement usually starts subject + conjugated verb: '
                'Je travaille ici. Add a place or a time to make the '
                'message useful: Nous étudions le français aujourd’hui.\n\n'
                'To negate these simple present statements, place ne before '
                'the conjugated verb and pas after it: Je ne parle pas '
                'allemand. Before a vowel sound, ne becomes n’: Je '
                'n’habite pas à Paris. In informal speech people often '
                'omit ne, but practise both parts in careful beginner '
                'writing. This lesson covers a small regular pattern; '
                'it does not mean every verb ending in -er is fully '
                'regular. Aller, for example, has irregular forms.'
            ),
            'examples': ['Je parle français.', 'Tu travailles ici.',
                         'Nous étudions le français.', 'Vous parlez anglais.',
                         'Je ne parle pas allemand.'],
            'exceptions': 'Aller is irregular. Some -er verbs have spelling '
                          'changes not taught here. Je and ne elide before '
                          'a vowel sound or mute h: j’habite, je n’habite pas.',
            'common_mistakes': 'Write nous parlons, not nous parle. With vous '
                               'write parlez. The ending -ent in parlent '
                               'is not pronounced as a separate syllable.',
            'lessons': [
                lesson('grammar', 'Choose the ending for the subject',
                       'Parler follows this pattern: je parle, tu parles, '
                       'elle parle, nous parlons, vous parlez, elles parlent. '
                       'Travailler and habiter follow the same basic pattern. '
                       'Use ne ... pas around the verb to make a negative: '
                       'Je ne parle pas allemand.',
                       'Je parle français. Tu parles anglais. Elle travaille ici. Nous parlons français. Vous parlez allemand. Elles travaillent à Paris.', [
                    mcq('Complete: Nous ... français.', ['parlons', 'parle', 'parlez'], 'parlons',
                        'Nous takes the ending -ons: nous parlons.'),
                    short('Conjugate parler for vous. Write only the verb.', 'parlez',
                          'Remove -er and add -ez: vous parlez.'),
                    mcq('Choose the correctly formed negative.',
                        ['Je ne parle pas allemand.', 'Je parle ne allemand pas.', 'Je ne parler pas allemand.'],
                        'Je ne parle pas allemand.', 'Ne goes before the conjugated verb and pas goes after it.'),
                ]),
                lesson('reading', 'A study day in Lyon',
                       'Read this short routine. Aujourd’hui means “today”.\n\n'
                       'J’habite à Lyon. Je travaille ici. Aujourd’hui, '
                       'nous étudions le français. Ma sœur parle anglais. '
                       'Je ne parle pas allemand.\n\n'
                       'Notice that the narrator uses j’habite because '
                       'habiter begins with a mute h. The final sentence '
                       'has both parts of the negative.',
                       'J’habite à Lyon. Je travaille ici. Aujourd’hui, nous étudions le français. Ma sœur parle anglais. Je ne parle pas allemand.', [
                    mcq('Where does the narrator live?', ['À Lyon.', 'À Paris.', 'À Lille.'], 'À Lyon.',
                        'The first sentence says J’habite à Lyon.'),
                    mcq('Which language does the sister speak?', ['Anglais.', 'Allemand.', 'Italien.'], 'Anglais.',
                        'Ma sœur parle anglais means my sister speaks English.'),
                    short('Copy the verb after je in the sentence meaning “I work here”.',
                          'travaille', 'Je travaille ici means I work here. The verb is travaille.'),
                ]),
                lesson('listening', 'Listen to a work-and-study plan',
                       'Listen for who is working, who is studying, and the '
                       'language they speak. Replay once before answering. '
                       'Use the transcript as a reading alternative if your '
                       'device has no French voice.',
                       'Aujourd’hui, vous travaillez ici. Nous étudions le français. Elle habite à Paris. Nous parlons français.', [
                    mcq('Who studies French in the recording?', ['Nous.', 'Elle.', 'Tu.'], 'Nous.',
                        'The recording says Nous étudions le français.'),
                    mcq('Where does she live?', ['À Paris.', 'À Lyon.', 'À Lille.'], 'À Paris.',
                        'Listen for Elle habite à Paris.'),
                    short('Complete the phrase from the recording with the verb only: Vous ... ici.',
                          'travaillez', 'Vous takes -ez: vous travaillez.'),
                ]),
                lesson('speaking', 'Describe two everyday activities',
                       'Listen and repeat Je travaille ici. Nous étudions '
                       'le français. Then make a short truthful introduction '
                       'using j’habite à plus a city and je parle plus a '
                       'language. If a model does not describe your life, '
                       'practise it as a role-play. Finish by saying a '
                       'negative: Je ne parle pas allemand. Compare subject '
                       'and verb with the models before marking self-review '
                       'complete. This practice does not grade your accent.',
                       'Je travaille ici. Nous étudions le français. J’habite à Lyon. Je ne parle pas allemand.'),
                lesson('writing', 'Write a three-sentence daily note',
                       'Write one sentence beginning Je parle, one beginning '
                       'Nous étudions and one using Je ne ... pas. Use the '
                       'model Je ne parle pas allemand if it is true, or '
                       'write it as role-play. Check the -ons ending with '
                       'nous and put pas after the conjugated verb. Add '
                       'aujourd’hui to one sentence if appropriate. This '
                       'is a self-check; a completed activity is not proof '
                       'that all grammar or meaning has been verified.'),
            ],
            'vocabulary': [
                word('parler', 'to speak', '/paʁ.le/', 'Je parle français.', '💬'),
                word('habiter', 'to live / reside', '/a.bi.te/', 'J’habite à Lyon.', '🏠'),
                word('travailler', 'to work', '/tʁa.va.je/', 'Vous travaillez ici.', '💼'),
                word('étudier', 'to study', '/e.ty.dje/', 'Nous étudions le français.', '📚'),
                word('aujourd’hui', 'today', '/o.ʒuʁ.dɥi/', 'Aujourd’hui, je travaille ici.', '📅'),
                word('ici', 'here', '/i.si/', 'Elle travaille ici.', '📍'),
            ],
        },
    ],
}

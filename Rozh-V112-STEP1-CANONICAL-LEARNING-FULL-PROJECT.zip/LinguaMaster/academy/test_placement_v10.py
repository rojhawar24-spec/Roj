"""Starting points follow published course evidence, never a total-score CEFR label."""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.http import QueryDict
from django.test import TestCase
from django.urls import reverse

from .course_models import CourseEnrollment
from .models import Assessment, Exercise, Language, Lesson, Level, Profile, Unit, XPEvent
from .placement_service import placement_questions


class CoursePlacementV10Tests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = get_user_model().objects.create_user('starting-point')
        self.course = Language.objects.create(code='en', name='English', slug='placement-english', is_published=True)
        self.foreign = Language.objects.create(code='nl', name='Dutch', slug='placement-dutch', is_published=True)
        Profile.objects.filter(user=self.user).update(preferred_language=self.course, placement_level='A0',
                                                     placement_completed=False, onboarding_completed=True)
        self.client.force_login(self.user)
        self.url = reverse('placement')

    def stage(self, code, *, course=None, published=True, unit_published=True):
        language = course or self.course
        level = Level.objects.create(language=language, code=code, order=['A0','A1','A2','B1','B2','C1'].index(code))
        unit = Unit.objects.create(level=level, slug='first', title='First', published=unit_published)
        lesson = Lesson.objects.create(unit=unit, slug='intro', title='Intro', skill='grammar', published=published)
        return [Exercise.objects.create(lesson=lesson, prompt=f'{language.code} {code} question {number}',
                    options=['Right', 'Wrong'], answer='Right', explanation='Why right', order=number)
                for number in range(2)]

    @staticmethod
    def answers(questions, answer='Right'):
        return {f'q_{question.pk}':answer for question in questions}

    def assert_untouched(self):
        profile = Profile.objects.get(user=self.user)
        self.assertEqual((profile.placement_level, profile.placement_completed), ('A0', False))
        self.assertFalse(Assessment.objects.filter(user=self.user).exists())
        self.assertFalse(CourseEnrollment.objects.filter(user=self.user).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_a0_only_perfect_score_starts_a0_and_records_course_without_xp(self):
        questions = self.stage('A0')
        response = self.client.post(self.url, self.answers(questions))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context['report'], {'score':100, 'band':'A0'})
        profile = Profile.objects.get(user=self.user)
        self.assertEqual((profile.placement_level, profile.placement_completed), ('A0', True))
        enrollment = CourseEnrollment.objects.get(user=self.user, language=self.course)
        self.assertEqual((enrollment.placement_level, enrollment.placement_completed), ('A0', True))
        assessment = Assessment.objects.get(user=self.user, kind='placement')
        self.assertEqual(assessment.level.language_id, self.course.pk)
        self.assertEqual(assessment.responses, {str(question.pk):'Right' for question in questions})
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_perfect_score_cannot_exceed_highest_published_question_stage(self):
        questions = self.stage('A0') + self.stage('A1')
        Level.objects.create(language=self.course, code='C1', order=5)
        response = self.client.post(self.url, self.answers(questions))
        self.assertEqual(response.context['report']['band'], 'A1')
        self.assertEqual(Profile.objects.get(user=self.user).placement_level, 'A1')

    def test_higher_stage_answers_do_not_skip_failed_foundations(self):
        foundation = self.stage('A0')
        questions = foundation + self.stage('A1') + self.stage('A2')
        answers = self.answers(questions)
        answers[f'q_{foundation[0].pk}'] = 'Wrong'
        response = self.client.post(self.url, answers)
        self.assertEqual(response.context['report']['band'], 'A0')

    def test_missing_intermediate_stage_cannot_be_skipped(self):
        questions = self.stage('A0') + self.stage('C1')
        response = self.client.post(self.url, self.answers(questions))
        self.assertEqual(response.context['report']['band'], 'A0')

    def test_first_unmastered_available_stage_is_the_starting_point(self):
        first, second, third = self.stage('A0'), self.stage('A1'), self.stage('A2')
        answers = self.answers(first) | self.answers(second, 'Wrong') | self.answers(third)
        response = self.client.post(self.url, answers)
        self.assertEqual(response.context['report']['band'], 'A1')

    def test_other_languages_and_unpublished_lesson_or_unit_provide_no_evidence(self):
        visible = self.stage('A0')
        self.stage('C1', course=self.foreign)
        self.stage('B1', published=False)
        self.stage('B2', unit_published=False)
        self.assertEqual([q.pk for q in placement_questions(self.course)], [q.pk for q in visible])
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, 'nl C1 question')
        self.assertNotContains(response, 'en B1 question')
        self.assertNotContains(response, 'en B2 question')
        response = self.client.post(self.url, self.answers(visible))
        self.assertEqual(response.context['report']['band'], 'A0')

    def test_empty_or_missing_answer_cannot_finish_or_change_starting_point(self):
        questions = self.stage('A0')
        for answers in ({}, self.answers(questions[:1]), self.answers(questions, '')):
            with self.subTest(answers=answers):
                self.assertEqual(self.client.post(self.url, answers).status_code, 400)
                self.assert_untouched()

    def test_forged_foreign_or_duplicate_option_cannot_mutate_state(self):
        questions = self.stage('A0')
        foreign = self.stage('A1', course=self.foreign)
        invalid = self.answers(questions)
        invalid[f'q_{questions[0].pk}'] = 'Made up answer'
        foreign_answers = self.answers(questions) | self.answers(foreign)
        for answers in (invalid, foreign_answers):
            with self.subTest(answers=answers):
                self.assertEqual(self.client.post(self.url, answers).status_code, 400)
                self.assert_untouched()
        repeated = QueryDict('', mutable=True)
        repeated.update(self.answers(questions))
        repeated.setlist(f'q_{questions[0].pk}', ['Right', 'Wrong'])
        response = self.client.post(self.url, repeated.urlencode(), content_type='application/x-www-form-urlencoded')
        self.assertEqual(response.status_code, 400)
        self.assert_untouched()

    def test_missing_or_unpublished_selected_course_never_falls_back_to_another_language(self):
        self.stage('A0', course=self.foreign)
        Profile.objects.filter(user=self.user).update(preferred_language=None)
        self.assertContains(self.client.get(self.url), 'not available yet')
        self.course.is_published = False
        self.course.save(update_fields=['is_published'])
        self.stage('A0')
        Profile.objects.filter(user=self.user).update(preferred_language=self.course)
        self.assertContains(self.client.get(self.url), 'not available yet')
        self.assert_untouched()

    def test_repeated_submission_redirects_without_rewriting_state(self):
        questions = self.stage('A0') + self.stage('A1')
        self.client.post(self.url, self.answers(questions))
        response = self.client.post(self.url, self.answers(questions, 'Wrong'))
        self.assertRedirects(response, reverse('play_hub'), fetch_redirect_response=False)
        self.assertEqual(Assessment.objects.filter(user=self.user, kind='placement').count(), 1)
        self.assertEqual(Profile.objects.get(user=self.user).placement_level, 'A1')
        self.assertEqual(CourseEnrollment.objects.get(user=self.user, language=self.course).placement_level, 'A1')

    def test_invalid_editor_mcqs_are_not_used_for_placement(self):
        questions = self.stage('A0')
        Exercise.objects.filter(pk=questions[0].pk).update(options=['Right', 'right'])
        Exercise.objects.filter(pk=questions[1].pk).update(answer='Not an option')
        self.assertContains(self.client.get(self.url), 'not available yet')
        self.assert_untouched()

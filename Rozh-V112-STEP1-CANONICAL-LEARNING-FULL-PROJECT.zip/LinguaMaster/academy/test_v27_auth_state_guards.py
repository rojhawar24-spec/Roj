"""V27 / STEP14 Django HTTP regressions — DISPOSABLE Django TEST DB ONLY.

Never call these tests against a production database. They are not counted as
PASS until a local Django installation actually executes them.
"""
import pyotp
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from .models import Profile

User = get_user_model()


@override_settings(REQUIRE_EMAIL_VERIFICATION=False)
class RevokedAuthenticationStateTests(TestCase):
    PASSWORD = 'V27-Unique-Long-Password-2026!'

    def setUp(self):
        cache.clear()
        self.user = User.objects.create_user('v27_login_user', 'v27@example.invalid', self.PASSWORD)
        self.profile = self.user.learning_profile
        self.profile.onboarding_completed = True
        self.profile.onboarding_required = False
        self.profile.placement_completed = True
        self.profile.save(update_fields=['onboarding_completed', 'onboarding_required', 'placement_completed'])

    def login_request(self):
        return self.client.post(reverse('login'), {
            'email': self.user.username, 'password': self.PASSWORD,
        })

    def test_active_unverified_local_student_can_still_sign_in(self):
        response = self.login_request()
        self.assertEqual(response.status_code, 302)
        self.assertEqual(int(self.client.session['_auth_user_id']), self.user.pk)

    def test_active_but_suspended_profile_denies_password_login(self):
        self.profile.suspended_at = timezone.now()
        self.profile.save(update_fields=['suspended_at'])
        response = self.login_request()
        self.assertEqual(response.status_code, 403)
        self.assertNotIn('_auth_user_id', self.client.session)
        self.assertNotIn('pending_mfa_user_id', self.client.session)

    def test_active_but_quarantined_profile_denies_password_login(self):
        self.profile.legacy_review_required = True
        self.profile.save(update_fields=['legacy_review_required'])
        response = self.login_request()
        self.assertEqual(response.status_code, 403)
        self.assertNotIn('_auth_user_id', self.client.session)
        self.assertNotIn('pending_mfa_user_id', self.client.session)

    def test_revoked_mfa_account_does_not_get_pending_challenge(self):
        self.profile.totp_secret = pyotp.random_base32()
        self.profile.suspended_at = timezone.now()
        self.profile.save(update_fields=['totp_secret', 'suspended_at'])
        response = self.login_request()
        self.assertEqual(response.status_code, 403)
        self.assertNotIn('pending_mfa_user_id', self.client.session)

    def test_existing_authenticated_session_is_logged_out_after_suspension(self):
        self.client.force_login(self.user)
        self.profile.suspended_at = timezone.now()
        self.profile.save(update_fields=['suspended_at'])
        response = self.client.get(reverse('login'))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse('login'))
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_existing_authenticated_session_is_logged_out_after_quarantine(self):
        self.client.force_login(self.user)
        self.profile.legacy_review_required = True
        self.profile.save(update_fields=['legacy_review_required'])
        response = self.client.get(reverse('login'))
        self.assertEqual(response.status_code, 302)
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_suspended_account_cannot_enroll_mfa_even_when_active(self):
        self.client.force_login(self.user)
        self.profile.suspended_at = timezone.now()
        self.profile.save(update_fields=['suspended_at'])
        response = self.client.get(reverse('mfa_setup'))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse('login'))
        self.assertNotIn('_auth_user_id', self.client.session)
        self.profile.refresh_from_db()
        self.assertFalse(self.profile.totp_secret)

    def test_quarantined_account_cannot_enroll_mfa(self):
        self.client.force_login(self.user)
        self.profile.legacy_review_required = True
        self.profile.save(update_fields=['legacy_review_required'])
        response = self.client.get(reverse('mfa_setup'))
        self.assertEqual(response.status_code, 302)
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_suspended_account_cannot_disable_enrolled_mfa(self):
        self.profile.totp_secret = pyotp.random_base32()
        self.profile.suspended_at = timezone.now()
        self.profile.save(update_fields=['totp_secret', 'suspended_at'])
        self.client.force_login(self.user)
        response = self.client.post(reverse('mfa_disable'), {'code': '000000'})
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse('login'))
        self.assertNotIn('_auth_user_id', self.client.session)
        self.profile.refresh_from_db()
        self.assertTrue(self.profile.totp_secret)

    def test_missing_profile_never_signs_in(self):
        Profile.objects.filter(user=self.user).delete()
        response = self.login_request()
        self.assertEqual(response.status_code, 403)
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_revoked_session_cannot_view_pending_mfa_recovery_codes(self):
        self.client.force_login(self.user)
        session = self.client.session
        session['mfa_recovery_codes_once'] = ['SYNTHETIC-TEST-CODE']
        session.save()
        self.profile.suspended_at = timezone.now()
        self.profile.save(update_fields=['suspended_at'])
        response = self.client.get(reverse('mfa_recovery'))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse('login'))
        self.assertNotIn('SYNTHETIC-TEST-CODE', response.content.decode())
        self.assertNotIn('_auth_user_id', self.client.session)

"""STEP 5 integration tests — must be run with Django and disposable test DB.
NOT run during this release's container build (Django unavailable).
"""
import json,re
from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from .models import Language


class SolarAtlasLandingTests(TestCase):
    def test_localized_public_pages_and_solar_copy(self):
        for url,code in (('/', 'nl'),('/en/','en'),('/ckb/','ckb'),('/ar/','ar')):
            with self.subTest(locale=code):
                resp=self.client.get(url)
                self.assertEqual(resp.status_code,200)
                self.assertEqual(resp.context['UI_LANG'],code)
                self.assertIn('hero_a',resp.context['S5'])
                self.assertContains(resp, 'class="s5-landing"')
                self.assertContains(resp,'lang="'+code+'"')
                self.assertContains(resp,'class="s5-dawnline"')
                self.assertContains(resp, 'solar-atlas-step5.css')
                self.assertContains(resp,'rel="canonical"')
                if code in ('ckb','ar'):
                    self.assertContains(resp,'dir="rtl"')
    def test_public_demo_and_login_destinations(self):
        resp=self.client.get('/')
        self.assertContains(resp,'href="/try/"')
        self.assertContains(resp,'href="/register/?next=/play/"')
        self.assertContains(resp,'href="/login/?next=/play/"')
        self.assertContains(resp,'href="/login/?next=/grammar/"')
        self.assertContains(resp,'href="/login/?next=/vocabulary/"')
        self.assertNotContains(resp,'href="/grammar/"')
    def test_published_course_is_public_unpublished_is_hidden(self):
        Language.objects.create(code='nl',name='Nederlands',slug='dutch',description='Dutch',is_published=True)
        Language.objects.create(code='xx',name='Secret',slug='secret',description='Hidden',is_published=False)
        resp=self.client.get('/en/')
        self.assertContains(resp,'href="/languages/dutch/"')
        self.assertNotContains(resp,'href="/languages/secret/"')
    def test_course_name_escaped(self):
        Language.objects.create(code='nl',name='<script>alert(1)</script>',slug='safe',description='Escaping',is_published=True)
        resp=self.client.get('/')
        self.assertNotContains(resp,'<script>alert(1)</script>')
        self.assertContains(resp,'&lt;script&gt;')
    def test_legacy_locale_redirect_and_seo_schema(self):
        resp=self.client.get('/?ui=ckb')
        self.assertEqual(resp.status_code,302)
        self.assertEqual(resp['Location'],reverse('home_ckb'))
        for code,url in [('nl','/'),('en','/en/'),('ckb','/ckb/'),('ar','/ar/')]:
            text=self.client.get(url).content.decode('utf-8')
            match=re.search(r'<script type="application/ld\+json">(.*?)</script>',text,re.S)
            self.assertIsNotNone(match)
            self.assertEqual(json.loads(match.group(1))['inLanguage'],code)
    def test_public_home_has_no_analytics_or_fake_progress(self):
        text=self.client.get('/').content.decode('utf-8')
        self.assertNotIn('fonts.googleapis.com',text)
        self.assertNotIn('utm_source=',text)
        self.assertIn('Illustratie, geen echte accountvoortgang',text)
        self.assertNotIn('10,000 learners',text)
    def test_authentication_on_home_never_shows_public_landing(self):
        u=get_user_model().objects.create_user(username='solar_step5_reader',email='solar_step5@example.invalid',password='DemoOnlyTesting123!')
        self.client.force_login(u)
        response=self.client.get('/')
        self.assertIn(response.status_code,(301,302))
        self.assertNotIn('class="s5-landing"',response.content.decode('utf-8'))

"""Live Django HTTP/SQLite integration. NOT run by the offline packaging checks.

These tests exercise the actual ORM, transaction boundaries, session mirrors,
hearts/mistakes and XP. Run using the disposable QA settings and real Django.
"""
from django.contrib.auth import get_user_model
from django.db import IntegrityError, transaction
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .heart_models import HeartBalance, HeartEvent
from .lesson_round_models_step3h import LessonRoundReceipt
from .models import (Exercise, Language, Lesson, LessonProgress, Level,
                     MistakeRecord, Profile, Unit, XPEvent)


class DurableRoundReceiptHTTPTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            username='step3h-learner', password='DisposableStrongStep3H!95')
        cls.language = Language.objects.create(code='en', name='Step3H English',
            slug='step3h-english', description='Disposable', is_published=True)
        cls.level = Level.objects.create(language=cls.language, code='A0',
                                        order=0, description='QA')
        cls.unit = Unit.objects.create(level=cls.level, slug='step3h-unit',
            title='Step3H Unit', summary='QA', published=True)
        cls.lesson = Lesson.objects.create(unit=cls.unit, slug='step3h-lesson',
            title='Step3H Lesson', skill='grammar', content='Only disposable content',
            published=True)
        cls.first = Exercise.objects.create(lesson=cls.lesson, kind='mcq', options=['yes','no'],
            prompt='Question one?', answer='yes', explanation='QA', order=1)
        cls.second = Exercise.objects.create(lesson=cls.lesson, kind='mcq', options=['yes','no'],
            prompt='Question two?', answer='yes', explanation='QA', order=2)
        Profile.objects.filter(user=cls.user).update(
            preferred_language=cls.language, placement_completed=True,
            onboarding_required=False, onboarding_completed=True,
            suspended_at=None, legacy_review_required=False)

    def setUp(self):
        self.client.force_login(self.user)
        self.lesson_url = reverse('lesson', args=[self.lesson.pk])
        self.ajax_url = reverse('lesson_answer', args=[self.lesson.pk])
        HeartBalance.objects.update_or_create(user=self.user,
            defaults={'remaining': 5, 'regenerated_at': timezone.now()})
        self.round = self.open_new_round()

    def open_new_round(self):
        result = self.client.get(self.lesson_url)
        self.assertEqual(result.status_code, 200)
        return result.context['lesson_round_key']

    def ajax(self, exercise, answer):
        return self.client.post(self.ajax_url, {
            'round_key': self.round, 'exercise_id': exercise.pk, 'answer': answer})

    def ssr(self, first='yes', second='yes'):
        return self.client.post(self.lesson_url, {
            'round_key': self.round, f'answer_{self.first.pk}': first,
            f'answer_{self.second.pk}': second})

    def discard_session_mirrors(self):
        session = self.client.session
        for key in (f'lesson_answers_{self.lesson.pk}',
                    f'lesson_round_channel_{self.lesson.pk}',
                    f'lesson_completed_round_{self.lesson.pk}'):
            session.pop(key, None)
        session.save()

    def test_wrong_ajax_replay_rejected_even_without_session_answer(self):
        self.assertEqual(self.ajax(self.first, 'no').status_code, 200)
        self.discard_session_mirrors()
        self.assertEqual(self.ajax(self.first, 'no').status_code, 409)
        self.assertEqual(HeartEvent.objects.filter(user=self.user, kind='answer').count(), 1)
        self.assertEqual(MistakeRecord.objects.get(user=self.user, exercise=self.first).wrong_count, 1)
        row = LessonRoundReceipt.objects.get(user=self.user, lesson=self.lesson, round_key=self.round)
        self.assertEqual(row.answers, {str(self.first.pk): False})
        self.assertEqual(row.channel, 'ajax')

    def test_correct_ajax_replay_rejected_even_without_heart_debit(self):
        self.assertEqual(self.ajax(self.first, 'yes').status_code, 200)
        self.discard_session_mirrors()
        self.assertEqual(self.ajax(self.first, 'yes').status_code, 409)
        self.assertEqual(self.ajax(self.second, 'yes').status_code, 200)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='lesson').count(), 1)
        self.assertEqual(LessonRoundReceipt.objects.get(user=self.user,lesson=self.lesson,
            round_key=self.round).score, 100)

    def test_ajax_then_ssr_refused_even_after_session_channel_cleared(self):
        self.assertEqual(self.ajax(self.first, 'yes').status_code, 200)
        self.discard_session_mirrors()
        self.assertEqual(self.ssr().status_code, 409)
        self.assertFalse(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())
        self.assertEqual(XPEvent.objects.filter(user=self.user,reason='lesson').count(),0)

    def test_ssr_then_ajax_refused_even_after_session_channel_cleared(self):
        self.assertEqual(self.ssr('no','yes').status_code, 200)
        self.discard_session_mirrors()
        self.assertEqual(self.ajax(self.first, 'yes').status_code, 409)
        self.assertEqual(HeartEvent.objects.filter(user=self.user, kind='answer').count(), 1)
        self.assertEqual(MistakeRecord.objects.get(user=self.user,exercise=self.first).wrong_count,1)

    def test_finished_ssr_cannot_be_replayed_after_session_reset(self):
        self.assertEqual(self.ssr().status_code, 200)
        self.discard_session_mirrors()
        self.assertEqual(self.ssr().status_code, 409)
        self.assertEqual(XPEvent.objects.filter(user=self.user,reason='lesson').count(),1)

    def test_finished_ajax_cannot_be_replayed_after_session_reset(self):
        self.assertEqual(self.ajax(self.first,'yes').status_code,200)
        self.assertEqual(self.ajax(self.second,'yes').status_code,200)
        self.discard_session_mirrors()
        self.assertEqual(self.ajax(self.first,'yes').status_code,409)
        self.assertEqual(XPEvent.objects.filter(user=self.user,reason='lesson').count(),1)

    def test_not_enough_hearts_rolls_back_receipt_and_mistakes(self):
        HeartBalance.objects.filter(user=self.user).update(remaining=1)
        self.assertEqual(self.ssr('no','no').status_code,402)
        self.assertFalse(LessonRoundReceipt.objects.filter(user=self.user,
            lesson=self.lesson, round_key=self.round).exists())
        self.assertFalse(HeartEvent.objects.filter(user=self.user,kind='answer').exists())
        self.assertFalse(MistakeRecord.objects.filter(user=self.user).exists())

    def test_fresh_round_has_independent_receipt(self):
        self.assertEqual(self.ajax(self.first,'no').status_code,200)
        old = self.round
        self.round = self.open_new_round()
        self.assertNotEqual(old,self.round)
        self.assertEqual(self.ssr('yes','yes').status_code,200)
        self.assertEqual(LessonRoundReceipt.objects.filter(user=self.user,lesson=self.lesson).count(),2)
        self.assertTrue(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())

    def test_database_unique_constraint_prevents_duplicate_round_record(self):
        self.assertEqual(self.ajax(self.first,'yes').status_code,200)
        with self.assertRaises(IntegrityError), transaction.atomic():
            LessonRoundReceipt.objects.create(user=self.user,lesson=self.lesson,
                round_key=self.round,channel='ssr')
        self.assertEqual(LessonRoundReceipt.objects.filter(user=self.user,
            lesson=self.lesson,round_key=self.round).count(),1)

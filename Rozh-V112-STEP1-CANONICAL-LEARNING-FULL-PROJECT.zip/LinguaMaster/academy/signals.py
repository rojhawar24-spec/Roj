from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth import get_user_model
from .models import Profile

@receiver(post_save, sender=get_user_model())
def create_profile(sender,instance,created,**kwargs):
    if created:
        Profile.objects.get_or_create(user=instance)


# Existing Django authentication signals cover direct logins, registration
# logins and MFA-completed logins without duplicating events in each view.
from django.contrib.auth.signals import user_logged_in, user_login_failed
from .auth_audit_v13 import record_auth_event


@receiver(user_logged_in, dispatch_uid='rozh.auth.audit.success.v13')
def log_successful_login(sender, request, user, **kwargs):
    record_auth_event('login_success', user=user)


@receiver(user_login_failed, dispatch_uid='rozh.auth.audit.failure.v13')
def log_failed_login(sender, credentials, request=None, **kwargs):
    # Never inspect credentials: this dictionary can contain a password.
    record_auth_event('login_failure')


# V91: bind every Django login, including force_login in integration tests,
# to the real database account-state revision.  Profile-less logins do not
# get a valid private-session binding and are denied by middleware.
from .session_revocation_v91 import (
    SESSION_STATE_VERSION_KEY, current_state_version,
)


@receiver(user_logged_in, dispatch_uid='rozh.auth.bind_account_state.v91')
def bind_authenticated_session_revision(sender, request, user, **kwargs):
    if request is None or user is None:
        return
    profile = Profile.objects.filter(user_id=user.pk).only('email_verification_version').first()
    version = current_state_version(profile)
    if version is None:
        request.session.pop(SESSION_STATE_VERSION_KEY, None)
    else:
        request.session[SESSION_STATE_VERSION_KEY] = version

    # Bind current role, group and effective permission assignments as well.
    # Direct SQL and QuerySet.update() can otherwise skip V92's revision bump.
    from .privilege_session_v93 import SESSION_PRIVILEGE_KEY, privilege_fingerprint
    permission_fingerprint = privilege_fingerprint(user)
    if permission_fingerprint is None:
        request.session.pop(SESSION_PRIVILEGE_KEY, None)
    else:
        request.session[SESSION_PRIVILEGE_KEY] = permission_fingerprint

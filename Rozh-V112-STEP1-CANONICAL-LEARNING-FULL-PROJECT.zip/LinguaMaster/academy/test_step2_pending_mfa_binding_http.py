"""Real Django HTTP/SQLite regression; NOT a claim that CI has run it."""
import pyotp
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.test import TestCase, override_settings
from django.urls import reverse

from .pending_mfa_binding_step2 import PENDING_PROOF_KEY
from .models import Profile


@override_settings(REQUIRE_EMAIL_VERIFICATION=False)
class PendingMFAStateBoundaryHTTP(TestCase):
    PASSWORD = 'Step2-Pending-MFA-QA-Password-Only!'
    SECRET = 'JBSWY3DPEHPK3PXP'

    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username='step2_pending',email='step2_pending@example.invalid',password=self.PASSWORD)
        self.profile = Profile.objects.get(user=self.user)
        self.profile.totp_secret = self.SECRET
        self.profile.mfa_recovery_hashes = ['a' * 64, 'b' * 64]
        self.profile.save(update_fields=['totp_secret', 'mfa_recovery_hashes'])
        response=self.client.post(reverse('login'),{'email':self.user.email,'password':self.PASSWORD})
        self.assertEqual(response.status_code,302)
        self.assertEqual(response.url,reverse('mfa_verify'))
        self.assertIn(PENDING_PROOF_KEY,self.client.session)
        self.assertNotIn('_auth_user_id',self.client.session)

    def assert_denied_and_cleared(self):
        response=self.client.post(reverse('mfa_verify'),{'code':pyotp.TOTP(self.SECRET).now()})
        self.assertEqual(response.status_code,302)
        self.assertEqual(response.url,reverse('login'))
        self.assertNotIn('pending_mfa_user_id',self.client.session)
        self.assertNotIn(PENDING_PROOF_KEY,self.client.session)
        self.assertNotIn('_auth_user_id',self.client.session)

    def test_unmodified_password_and_account_can_finish_mfa(self):
        response=self.client.post(reverse('mfa_verify'),{'code':pyotp.TOTP(self.SECRET).now()})
        self.assertEqual(response.status_code,302)
        self.assertEqual(int(self.client.session['_auth_user_id']),self.user.pk)
        self.assertNotIn(PENDING_PROOF_KEY,self.client.session)

    def test_password_reset_between_factors_revokes_pending_mfa(self):
        self.user.set_password('Changed-Step2-Pending-Password!')
        self.user.save(update_fields=['password'])
        self.assert_denied_and_cleared()

    def test_account_revision_change_between_factors_revokes_pending_mfa(self):
        Profile.objects.filter(user=self.user).update(email_verification_version=3)
        self.assert_denied_and_cleared()

    def test_manager_or_permission_change_between_factors_revokes_pending_mfa(self):
        group=Group.objects.create(name='Step2 nonprivileged test group')
        self.user.groups.add(group)
        self.assert_denied_and_cleared()

    def test_totp_secret_rotated_after_password_step_revokes_pending_mfa(self):
        profile=Profile.objects.get(user=self.user)
        profile.totp_secret='GEZDGNBVGY3TQOJQ'
        profile.save(update_fields=['totp_secret'])
        self.assert_denied_and_cleared()

    def test_recovery_codes_reissued_after_password_step_revoke_pending_mfa(self):
        profile=Profile.objects.get(user=self.user)
        profile.mfa_recovery_hashes=['c' * 64, 'd' * 64]
        profile.save(update_fields=['mfa_recovery_hashes'])
        self.assert_denied_and_cleared()

    def test_recovery_code_used_elsewhere_revokes_pending_mfa(self):
        profile=Profile.objects.get(user=self.user)
        # A recovery code consumed in another session invalidates the pending
        # challenge even when this browser submits a valid TOTP code.
        profile.mfa_recovery_hashes=['b' * 64]
        profile.save(update_fields=['mfa_recovery_hashes'])
        self.assert_denied_and_cleared()

    def test_deleted_pending_proof_cannot_finish_mfa(self):
        session=self.client.session
        session.pop(PENDING_PROOF_KEY,None)
        session.save()
        self.assert_denied_and_cleared()

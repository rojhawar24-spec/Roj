from django.urls import path
from .api import LanguagesAPI, LevelsAPI, UnitsAPI, LessonsAPI, ProgressAPI
urlpatterns = [path('languages/',LanguagesAPI.as_view()),path('levels/',LevelsAPI.as_view()),
                path('units/',UnitsAPI.as_view()),path('lessons/',LessonsAPI.as_view()),path('me/progress/',ProgressAPI.as_view())]

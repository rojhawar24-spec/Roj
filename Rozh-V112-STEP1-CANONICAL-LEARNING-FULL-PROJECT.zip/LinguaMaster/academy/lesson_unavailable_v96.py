"""Student-facing editorial availability copy; locale keys are UI, not course languages."""
COPY = {
 'nl': dict(title='Deze les is nog niet klaar', subtitle='De les is tijdelijk niet beschikbaar.',
            audio='Voor deze luisterles ontbreekt een gecontroleerde, goedgekeurde opname. We tonen geen verzonnen audio en rekenen deze les niet als voltooid.',
            activity='Een oefening in deze les moet nog door de Manager worden gecontroleerd. Je verliest geen harten of XP.',
            back='Terug naar Leer & Speel', unit='Bekijk de andere lessen', note='De Manager kan dit oplossen door de inhoud na te kijken en goed te keuren.'),
 'en': dict(title='This lesson is not ready yet', subtitle='The lesson is temporarily unavailable.',
            audio='This listening lesson needs a verified, approved recording. We do not substitute fake audio or mark this lesson complete.',
            activity='One exercise is awaiting editorial review. No hearts or XP were changed.',
            back='Back to Learn & Play', unit='View other lessons', note='A Manager can review and approve the missing content.'),
 'ckb': dict(title='ئەم وانەیە هێشتا ئامادە نییە', subtitle='ئەم وانەیە بە شێوەی کاتی بەردەست نییە.',
             audio='ئەم وانەی گوێگرتنە پێویستی بە تۆمارێکی دەنگی پشکنراو و پەسەندکراو هەیە. دەنگی ساختە بەکارناهێنین و وانەکە بە تەواوبوو هەژمار ناکەین.',
             activity='ڕاهێنانێک چاوەڕێی پشکنینی بەڕێوەبەرە. هیچ دڵ یان XP نەگۆڕاوە.',
             back='گەڕانەوە بۆ فێربوون و یاری', unit='وانەکانی تر ببینە', note='بەڕێوەبەر دەتوانێت ناوەڕۆکەکە پشکنین و پەسەندی بکات.'),
 'ar': dict(title='هذا الدرس غير جاهز بعد', subtitle='الدرس غير متاح مؤقتاً.',
            audio='هذا الدرس يحتاج إلى تسجيل صوتي معتمد ومراجَع. لن نستبدله بصوت غير موثق أو نمنح تقدماً وهمياً.',
            activity='هناك تمرين ينتظر مراجعة المسؤول. لم تتغير النقاط أو القلوب.',
            back='العودة إلى التعلّم واللعب', unit='عرض الدروس الأخرى', note='يمكن للمسؤول مراجعة المحتوى والموافقة عليه.'),
}


def for_locale(locale):
    # Additional interface languages inherit clear English until editorial review.
    return COPY.get(locale, COPY['en'])

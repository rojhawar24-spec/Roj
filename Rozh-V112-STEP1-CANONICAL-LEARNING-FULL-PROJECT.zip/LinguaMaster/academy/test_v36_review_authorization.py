"""Pending Django HTTP tests for active ReviewCard/course reward safety.

Run with the existing isolated QA interpreter and test database, NOT production.
"""
from datetime import datetime, timezone as dt_timezone
from unittest.mock import patch
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .models import Language, Level, Vocabulary, ReviewCard, XPEvent
from .progress_models import LearningPreferences


class ReviewV36DjangoTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user=get_user_model().objects.create_user('v36-review',password='StrongV36ReviewPass2026!')
        self.language=Language.objects.create(name='Dutch V36',code='nl',slug='v36-dutch',description='',is_published=True)
        self.foreign=Language.objects.create(name='French V36',code='fr',slug='v36-french',description='',is_published=True)
        self.level=Level.objects.create(language=self.language,code='A0',order=0,description='Starter')
        self.foreign_level=Level.objects.create(language=self.foreign,code='A0',order=0,description='Starter')
        self.word=Vocabulary.objects.create(level=self.level,word='v36-native-review',translation='meaning',
                    pronunciation='',example='Example.',published=True)
        self.foreign_word=Vocabulary.objects.create(level=self.foreign_level,word='v36-foreign-review',translation='meaning',
                    pronunciation='',example='Example.',published=True)
        self.card=ReviewCard.objects.create(user=self.user,vocabulary=self.word,due=timezone.now())
        self.foreign_card=ReviewCard.objects.create(user=self.user,vocabulary=self.foreign_word,due=timezone.now())
        self.profile=self.user.learning_profile
        self.profile.preferred_language=self.language
        self.profile.placement_completed=True
        self.profile.onboarding_required=True
        self.profile.onboarding_completed=True
        self.profile.save(update_fields=['preferred_language','placement_completed','onboarding_required','onboarding_completed'])
        self.client.force_login(self.user)

    def submit(self,card=None,weekly=False,quality='5'):
        return self.client.post(reverse('weekly_review' if weekly else 'review'),
                                {'card_id':(card or self.card).pk,'quality':quality})

    def assert_unchanged(self,card=None):
        (card or self.card).refresh_from_db()
        self.assertEqual((card or self.card).repetitions,0)
        self.assertEqual((card or self.card).last_quality,0)
        self.assertFalse(XPEvent.objects.filter(user=self.user,reason='review').exists())

    def test_valid_review_persists_and_awards_once_per_user_day(self):
        self.assertEqual(self.submit().status_code,302)
        self.card.refresh_from_db()
        self.assertEqual(self.card.repetitions,1)
        self.assertEqual(XPEvent.objects.filter(user=self.user,reason='review').count(),1)
        self.assertEqual(self.submit().status_code,302)
        self.assertEqual(XPEvent.objects.filter(user=self.user,reason='review').count(),1)

    def test_foreign_course_card_not_visible_or_redeemable(self):
        response=self.client.get(reverse('review'))
        self.assertRedirects(response, reverse('word'))
        self.assertEqual(self.submit(card=self.foreign_card).status_code,404)
        self.assert_unchanged(self.foreign_card)

    def test_weekly_review_is_also_course_scoped(self):
        response=self.client.get(reverse('weekly_review'))
        self.assertRedirects(response, reverse('word'))
        self.assertEqual(self.submit(self.foreign_card,weekly=True).status_code,404)
        self.assert_unchanged(self.foreign_card)

    def test_course_switch_blocks_old_review_without_losing_card(self):
        self.profile.preferred_language=self.foreign
        self.profile.save(update_fields=['preferred_language'])
        self.assertEqual(self.submit().status_code,404)
        self.assertRedirects(self.client.get(reverse('review')),reverse('word'))
        self.assert_unchanged()

    def test_no_selected_course_fails_closed(self):
        self.profile.preferred_language=None
        self.profile.save(update_fields=['preferred_language'])
        self.assertEqual(self.submit().status_code,403)
        self.assertRedirects(self.client.get(reverse('review')),reverse('word'))
        self.assert_unchanged()

    def test_unpublished_course_fails_closed(self):
        self.language.is_published=False
        self.language.save(update_fields=['is_published'])
        self.assertEqual(self.submit().status_code,403)
        self.assertRedirects(self.client.get(reverse('review')),reverse('word'))
        self.assert_unchanged()

    def test_incomplete_onboarding_fails_closed(self):
        self.profile.onboarding_completed=False
        self.profile.save(update_fields=['onboarding_completed'])
        self.assertEqual(self.submit().status_code,403)
        self.assertRedirects(self.client.get(reverse('review')),reverse('word'))
        self.assert_unchanged()

    def test_revoked_placement_fails_closed(self):
        self.profile.placement_completed=False
        self.profile.save(update_fields=['placement_completed'])
        self.assertEqual(self.submit().status_code,403)
        self.assert_unchanged()

    def test_suspended_account_fails_closed(self):
        self.profile.suspended_at=timezone.now()
        self.profile.save(update_fields=['suspended_at'])
        self.assertEqual(self.submit().status_code,403)
        self.assert_unchanged()

    def test_quarantined_account_fails_closed(self):
        self.profile.legacy_review_required=True
        self.profile.save(update_fields=['legacy_review_required'])
        self.assertEqual(self.submit().status_code,403)
        self.assert_unchanged()

    def test_archived_word_not_redeemed(self):
        self.word.published=False
        self.word.save(update_fields=['published'])
        self.assertEqual(self.submit().status_code,404)
        self.assert_unchanged()

    def test_invalid_quality_cannot_change_schedule(self):
        self.assertEqual(self.submit(quality='8').status_code,400)
        self.assert_unchanged()

    def test_award_day_uses_user_timezone_not_server_timezone(self):
        LearningPreferences.objects.update_or_create(user=self.user,defaults={'timezone_name':'America/Los_Angeles'})
        instant=datetime(2026,11,21,1,30,tzinfo=dt_timezone.utc)
        # The UTC date is 21 November; in Los Angeles it is still 20 November.
        with patch('academy.services.timezone.now',return_value=instant):
            self.assertEqual(self.submit().status_code,302)
        event=XPEvent.objects.get(user=self.user,reason='review')
        self.assertEqual(event.event_key,
                         f'user:{self.user.pk}:review:{self.card.pk}:2026-11-20')

    def test_failed_award_rolls_back_review(self):
        with patch('academy.views.award_xp',side_effect=RuntimeError('injected XP write failure')):
            with self.assertRaisesRegex(RuntimeError,'injected XP write failure'):
                self.submit()
        self.assert_unchanged()

    def test_get_has_no_reward_side_effect(self):
        self.assertRedirects(self.client.get(reverse('review')),reverse('word'))
        self.assertRedirects(self.client.get(reverse('weekly_review')),reverse('daily_weekly_review'))
        self.assert_unchanged()

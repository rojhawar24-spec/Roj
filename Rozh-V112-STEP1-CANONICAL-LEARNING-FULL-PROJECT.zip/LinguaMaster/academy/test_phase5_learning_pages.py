"""Phase 5 Django integration checks; only meaningful in an isolated disposable DB.
These test cases have not passed until Django's TestCase runner executes them.
"""
from datetime import date, timedelta
from unittest.mock import patch
from urllib.parse import urlsplit,parse_qs
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import Client, TestCase
from django.urls import reverse
from django.utils import timezone
from .models import Language,Level,Unit,Lesson,Exercise,GrammarTopic,Vocabulary,MistakeRecord,XPEvent
from .grammar_models import GrammarMastery
from .heart_models import HeartEvent

class Phase5LearningPagesTests(TestCase):
    def setUp(self):
        cache.clear()
        self.student=get_user_model().objects.create_user('phase5-student',password='Long test password 2026!')
        self.en=Language.objects.create(code='en',name='English',slug='phase5-english',description='',is_published=True)
        self.level=Level.objects.create(language=self.en,code='A0',order=0,description='Starter')
        self.topic=GrammarTopic.objects.create(level=self.level,slug='phase5-topic',title='Short questions',
              explanation='Choose the right form.',examples=['Is it?'],exceptions='',common_mistakes='',
              check_question='Choose the correct option',check_options=['Yes','No'],check_answer='Yes',published=True)
        self.vocab=Vocabulary.objects.create(level=self.level,word='good morning',translation='a greeting',
              pronunciation='',example='Good morning!',published=True)
        self.unit=Unit.objects.create(level=self.level,slug='phase5-unit',title='Starter',summary='',published=True)
        self.lesson=Lesson.objects.create(unit=self.unit,slug='phase5-lesson',title='Greetings',skill='grammar',
              content='Basic words.',published=True)
        self.exercise=Exercise.objects.create(lesson=self.lesson,order=1,kind='mcq',prompt='Choose Yes',
              options=['Yes','No'],answer='Yes',explanation='Yes is correct.')
        profile=self.student.learning_profile
        profile.preferred_language=self.en;profile.ui_language='nl';profile.onboarding_completed=True
        profile.placement_completed=True;profile.save()
        self.client.force_login(self.student)

    def test_all_four_pages_use_existing_student_shell_and_active_links(self):
        for name,args in (('grammar_library',()),('grammar',(self.topic.pk,)),('mistakes',()),('word',())):
            response=self.client.get(reverse(name,args=args))
            self.assertEqual(response.status_code,200,name)
            self.assertTemplateUsed(response,'academy/rozh2027_student_shell.html')
            self.assertContains(response,'r55-learning-mode')
            self.assertContains(response,'r27-student-frame')
            self.assertContains(response,'aria-current="page"')

    def test_four_ui_languages_show_rtl_and_route_references(self):
        profile=self.student.learning_profile
        for locale in ('nl','en','ckb','ar'):
            profile.ui_language=locale;profile.save(update_fields=['ui_language'])
            response=self.client.get(reverse('mistakes'))
            self.assertContains(response,f'lang="{locale}"')
            self.assertContains(response,'dir="rtl"' if locale in ('ckb','ar') else 'dir="ltr"')

    def test_anonymous_grammar_and_daily_stay_public_not_private_student_shell(self):
        self.client.logout()
        for name,args in (('grammar_library',()),('grammar',(self.topic.pk,)),('word',())):
            r=self.client.get(reverse(name,args=args))
            self.assertEqual(r.status_code,200)
            self.assertTemplateUsed(r,'academy/base.html')
            self.assertNotContains(r,'r27-student-frame')
        self.assertEqual(self.client.get(reverse('mistakes')).status_code,302)

    def test_grammar_25_topics_are_paginated_not_all_rendered(self):
        for n in range(24):
            GrammarTopic.objects.create(level=self.level,slug=f'phase5-extra-{n}',title=f'Additional {n:02}',
               explanation='Example',examples=['One.'],exceptions='',common_mistakes='',published=True)
        first=self.client.get(reverse('grammar_library'))
        second=self.client.get(reverse('grammar_library'),{'page':'2'})
        self.assertEqual(len(first.context['cards']),24)
        self.assertEqual(len(second.context['cards']),1)
        self.assertContains(first,'rel="next"')
        self.assertContains(second,'rel="prev"')

    def test_grammar_local_day_is_used_for_scheduling(self):
        fake_day=date(2026,11,15)
        with patch('academy.grammar_v9.user_localdate',return_value=fake_day):
            self.client.post(reverse('grammar',args=[self.topic.pk]),{'answer':'Yes'})
        mastery=GrammarMastery.objects.get(user=self.student,topic=self.topic)
        self.assertEqual(mastery.last_correct_day,fake_day)

    def test_grammar_route_and_filters_survive_interface_change(self):
        r=self.client.post(reverse('switch_ui_language'),{'ui_language':'ckb','return_to':'grammar_library',
            'grammar_query':'hello & world','grammar_level':'A0','grammar_status':'due','grammar_page':'2'})
        parsed=urlsplit(r.url)
        self.assertEqual(parsed.path,reverse('grammar_library'))
        self.assertEqual(parse_qs(parsed.query),{'q':['hello & world'],'level':['A0'],'status':['due'],'page':['2']})
        r=self.client.post(reverse('switch_ui_language'),{'ui_language':'ar','return_to':'grammar',
              'grammar_topic_id':str(self.topic.pk)})
        self.assertEqual(r.url,reverse('grammar',args=[self.topic.pk]))

    def test_mistakes_word_switch_named_only_and_reject_external_redirect(self):
        for name in ('mistakes','word'):
            r=self.client.post(reverse('switch_ui_language'),{'ui_language':'nl','return_to':name})
            self.assertEqual(r.url,reverse(name))
        r=self.client.post(reverse('switch_ui_language'),{'ui_language':'nl',
             'return_to':'https://evil.example/'})
        self.assertEqual(r.url,reverse('play_hub'))

    def test_wrong_mistake_keeps_record_open_and_no_xp(self):
        mistake=MistakeRecord.objects.create(user=self.student,exercise=self.exercise)
        self.client.post(reverse('mistakes'),{'mistake_id':mistake.pk,'answer':'No'})
        mistake.refresh_from_db()
        self.assertIsNone(mistake.corrected_at)
        self.assertEqual(XPEvent.objects.filter(user=self.student,reason='mistake').count(),0)

    def test_mistake_rollback_when_award_fails(self):
        mistake=MistakeRecord.objects.create(user=self.student,exercise=self.exercise)
        with patch('academy.grammar_v9.award_xp',side_effect=RuntimeError('Simulated write failure')):
            with self.assertRaises(RuntimeError):
                self.client.post(reverse('mistakes'),{'mistake_id':mistake.pk,'answer':'Yes'})
        mistake.refresh_from_db()
        self.assertIsNone(mistake.corrected_at)
        self.assertFalse(HeartEvent.objects.filter(user=self.student,key=f'mistake:{mistake.pk}').exists())
        self.assertFalse(XPEvent.objects.filter(user=self.student,reason='mistake').exists())

    def test_mistake_success_reward_once_and_hearts_consistent(self):
        mistake=MistakeRecord.objects.create(user=self.student,exercise=self.exercise)
        r=self.client.post(reverse('mistakes'),{'mistake_id':mistake.pk,'answer':'Yes'})
        self.assertEqual(r.status_code,302)
        mistake.refresh_from_db()
        self.assertIsNotNone(mistake.corrected_at)
        self.assertEqual(XPEvent.objects.filter(user=self.student,reason='mistake').count(),1)
        self.assertTrue(HeartEvent.objects.filter(user=self.student,key=f'mistake:{mistake.pk}').exists())
        self.assertEqual(self.client.post(reverse('mistakes'),{'mistake_id':mistake.pk,'answer':'Yes'}).status_code,404)

    def test_daily_get_does_not_create_xp(self):
        before=XPEvent.objects.filter(user=self.student).count()
        r=self.client.get(reverse('word'))
        self.assertContains(r,'good morning')
        self.assertEqual(XPEvent.objects.filter(user=self.student).count(),before)

    def test_invalid_grammar_return_id_never_open_redirects(self):
        r=self.client.post(reverse('switch_ui_language'),{'ui_language':'en',
             'return_to':'grammar','grammar_topic_id':'https://evil.example'})
        self.assertEqual(r.url,reverse('play_hub'))

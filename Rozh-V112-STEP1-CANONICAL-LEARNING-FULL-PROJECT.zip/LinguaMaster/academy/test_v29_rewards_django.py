"""V29 integration tests. Requires real Django and an isolated test database.

Static/offline test counts MUST NEVER include this module.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .models import Assessment, CoinEvent, Language, Level, Profile, SeasonGiftClaim, XPEvent
from .season_gifts_v14 import SeasonGiftUnavailable, claim_season_gift
from .services import award_xp


class RewardIntegrityIntegrationTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user('v29student',password='V29TestOnly-LongPassword2026!')
        self.a=Language.objects.create(name='Dutch v29',code='nl',slug='nl-v29',description='',is_published=True)
        self.b=Language.objects.create(name='English v29',code='en',slug='en-v29',description='',is_published=True)
        self.level=Level.objects.create(language=self.a,code='A0',description='A0',order=0)
        Profile.objects.filter(user=self.user).update(
            preferred_language=self.a,placement_completed=True,onboarding_required=True,onboarding_completed=True,
        )
        Assessment.objects.create(user=self.user,kind='level',level=self.level,passed=True,score=100)

    def assert_no_rewards(self):
        self.assertFalse(SeasonGiftClaim.objects.filter(user=self.user).exists())
        self.assertFalse(CoinEvent.objects.filter(user=self.user).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user,reason='season').exists())

    def test_matching_course_claim_once(self):
        self.assertEqual(claim_season_gift(self.user,self.level),(True,50,100))
        self.assertEqual(claim_season_gift(self.user,self.level),(False,50,100))
        self.assertEqual(SeasonGiftClaim.objects.count(),1)
        self.assertEqual(CoinEvent.objects.count(),1)
        self.assertEqual(XPEvent.objects.filter(reason='season').count(),1)

    def test_old_course_exam_cannot_mint_new_reward_after_switch(self):
        Profile.objects.filter(user=self.user).update(preferred_language=self.b)
        with self.assertRaises(SeasonGiftUnavailable):claim_season_gift(self.user,self.level)
        self.assert_no_rewards()

    def test_removed_course_rejected(self):
        Profile.objects.filter(user=self.user).update(preferred_language=None)
        with self.assertRaises(SeasonGiftUnavailable):claim_season_gift(self.user,self.level)
        self.assert_no_rewards()

    def test_revoked_placement_rejected(self):
        Profile.objects.filter(user=self.user).update(placement_completed=False)
        with self.assertRaises(SeasonGiftUnavailable):claim_season_gift(self.user,self.level)
        self.assert_no_rewards()

    def test_incomplete_required_onboarding_rejected(self):
        Profile.objects.filter(user=self.user).update(onboarding_completed=False)
        with self.assertRaises(SeasonGiftUnavailable):claim_season_gift(self.user,self.level)
        self.assert_no_rewards()

    def test_suspension_rejected(self):
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        with self.assertRaises(SeasonGiftUnavailable):claim_season_gift(self.user,self.level)
        self.assert_no_rewards()

    def test_historical_review_rejected(self):
        Profile.objects.filter(user=self.user).update(legacy_review_required=True)
        with self.assertRaises(SeasonGiftUnavailable):claim_season_gift(self.user,self.level)
        self.assert_no_rewards()

    def test_unpublished_selected_course_rejected(self):
        self.a.is_published=False;self.a.save(update_fields=['is_published'])
        with self.assertRaises(SeasonGiftUnavailable):claim_season_gift(self.user,self.level)
        self.assert_no_rewards()

    def test_no_level_pass_rejected(self):
        Assessment.objects.filter(user=self.user).delete()
        with self.assertRaises(SeasonGiftUnavailable):claim_season_gift(self.user,self.level)
        self.assert_no_rewards()

    def test_duplicate_xp_stays_idempotent(self):
        self.assertTrue(award_xp(self.user,20,event_key='v29-unique',learning=False))
        self.assertFalse(award_xp(self.user,20,event_key='v29-unique',learning=False))
        self.assertEqual(Profile.objects.get(user=self.user).xp,20)
        self.assertEqual(XPEvent.objects.filter(user=self.user,event_key=f'user:{self.user.pk}:v29-unique').count(),1)

    def test_post_only_claim_view(self):
        self.client.force_login(self.user)
        self.assertEqual(self.client.get(reverse('season_gift_claim',args=[self.level.pk])).status_code,405)
        self.assert_no_rewards()

    def test_successful_claim_view(self):
        self.client.force_login(self.user)
        response=self.client.post(reverse('season_gift_claim',args=[self.level.pk]))
        self.assertEqual(response.status_code,302)
        self.assertEqual(SeasonGiftClaim.objects.count(),1)

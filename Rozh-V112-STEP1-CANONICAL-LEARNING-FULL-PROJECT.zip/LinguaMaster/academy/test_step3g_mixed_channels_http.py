"""Step 3G real Django HTTP + disposable SQLite integration tests.

NOT run in the offline assistant environment without Django. These assertions
must pass on the real QA runner before Step 3 or production signoff.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .heart_models import HeartBalance, HeartEvent
from .models import (Language, Level, Unit, Lesson, Exercise, Profile,
                     LessonProgress, MistakeRecord, XPEvent)


class Step3GMixedChannelsHTTPTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            username='step3g-learner', password='SyntheticStep3gPassword!951')
        cls.language = Language.objects.create(
            code='en', name='Step3G English', slug='step3g-english',
            description='Disposable only', is_published=True)
        cls.level = Level.objects.create(language=cls.language, code='A0',
                                        order=0, description='Step3G QA')
        cls.unit = Unit.objects.create(level=cls.level, slug='step3g-unit',
            title='Step 3G unit', summary='Disposable only', published=True)
        cls.lesson = Lesson.objects.create(unit=cls.unit, slug='step3g-lesson',
            title='Step 3G lesson', skill='grammar', published=True,
            content='Synthetic questions only')
        cls.first = Exercise.objects.create(lesson=cls.lesson, kind='mcq', options=['yes','no'],
            prompt='First?', answer='yes', explanation='Synthetic', order=1)
        cls.second = Exercise.objects.create(lesson=cls.lesson, kind='mcq', options=['yes','no'],
            prompt='Second?', answer='yes', explanation='Synthetic', order=2)
        Profile.objects.filter(user=cls.user).update(
            preferred_language=cls.language, placement_completed=True,
            onboarding_required=False, onboarding_completed=True,
            suspended_at=None, legacy_review_required=False)

    def setUp(self):
        self.client.force_login(self.user)
        self.lesson_url = reverse('lesson', args=[self.lesson.pk])
        self.ajax_url = reverse('lesson_answer', args=[self.lesson.pk])
        self.round = self.open_new_round()
        HeartBalance.objects.update_or_create(user=self.user,
            defaults={'remaining':5,'regenerated_at':timezone.now()})

    def open_new_round(self):
        page = self.client.get(self.lesson_url)
        self.assertEqual(page.status_code, 200)
        return page.context['lesson_round_key']

    def ajax(self, question, answer, round_key=None):
        return self.client.post(self.ajax_url, {
            'round_key':round_key or self.round,
            'exercise_id':question.pk,'answer':answer})

    def ssr(self, first='yes', second='yes'):
        return self.client.post(self.lesson_url, {
            'round_key':self.round,
            f'answer_{self.first.pk}':first,
            f'answer_{self.second.pk}':second})

    def check_no_completion(self):
        self.assertFalse(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user,reason='lesson').exists())

    def test_ajax_correct_then_ssr_cannot_regrade_or_mint_xp(self):
        first = self.ajax(self.first,'yes')
        self.assertEqual(first.status_code,200)
        blocked = self.ssr('no','yes')
        self.assertEqual(blocked.status_code,409)
        self.check_no_completion()
        self.assertFalse(MistakeRecord.objects.filter(user=self.user).exists())
        self.assertFalse(HeartEvent.objects.filter(user=self.user,kind='answer').exists())

    def test_ajax_wrong_then_ssr_cannot_erase_mistake(self):
        first = self.ajax(self.first,'no')
        self.assertEqual(first.status_code,200)
        self.assertFalse(first.json()['correct'])
        blocked = self.ssr('yes','yes')
        self.assertEqual(blocked.status_code,409)
        self.assertEqual(HeartEvent.objects.filter(user=self.user,kind='answer').count(),1)
        mistake = MistakeRecord.objects.get(user=self.user,exercise=self.first)
        self.assertIsNone(mistake.corrected_at)
        self.check_no_completion()

    def test_failed_legacy_ssr_then_ajax_rejected_without_extra_heart(self):
        first = self.ssr('no','yes')
        self.assertEqual(first.status_code,200)
        self.check_no_completion()
        before = HeartEvent.objects.filter(user=self.user,kind='answer').count()
        self.assertEqual(before,1)
        denied = self.ajax(self.first,'yes')
        self.assertEqual(denied.status_code,409)
        self.assertEqual(denied.json()['error_code'],'round_channel_conflict')
        self.assertEqual(HeartEvent.objects.filter(user=self.user,kind='answer').count(),before)
        self.assertIsNone(MistakeRecord.objects.get(user=self.user,exercise=self.first).corrected_at)
        self.check_no_completion()

    def test_same_ajax_channel_completes_and_awards_once(self):
        self.assertEqual(self.ajax(self.first,'yes').status_code,200)
        second = self.ajax(self.second,'yes')
        self.assertEqual(second.status_code,200)
        self.assertTrue(second.json()['completed'])
        self.assertEqual(XPEvent.objects.filter(user=self.user,reason='lesson').count(),1)

    def test_failed_ssr_can_retry_same_ssr_channel(self):
        self.assertEqual(self.ssr('no','yes').status_code,200)
        second = self.ssr('yes','yes')
        self.assertEqual(second.status_code,200)
        self.assertTrue(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())

    def test_reopening_allows_switch_to_other_channel(self):
        self.assertEqual(self.ajax(self.first,'yes').status_code,200)
        old = self.round
        self.round = self.open_new_round()
        self.assertNotEqual(old,self.round)
        result = self.ssr('yes','yes')
        self.assertEqual(result.status_code,200)
        self.assertTrue(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())

    def test_invalid_ajax_request_does_not_claim_round(self):
        self.assertEqual(self.ajax(self.first,'').status_code,400)
        self.assertEqual(self.ssr('yes','yes').status_code,200)
        self.assertTrue(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())

    def test_depleted_ssr_batch_does_not_claim_round(self):
        HeartBalance.objects.filter(user=self.user).update(remaining=1)
        self.assertEqual(self.ssr('no','no').status_code,402)
        self.assertEqual(self.ajax(self.first,'yes').status_code,200)
        self.check_no_completion()

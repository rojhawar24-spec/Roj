"""V42 real Django/ORM tests. NOT executed until Django is available in isolated QA.

    python manage.py test academy.test_v42_ai_credit_revocation --noinput
Never use real AI, payment, or personal production data for these tests.
"""
from decimal import Decimal
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from .ai_service import tutor_reply, AIUnavailable
from .billing_models import AICreditWallet, AICreditDebit, AICreditPurchase
from .models import AIUsage, PlatformSettings, Profile


@override_settings(AI_API_KEY='v42-local-test-only-key')
class V42AICreditRevocationTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = get_user_model().objects.create_user(
            'v42_ai_learner', 'v42-ai@example.invalid', 'StrongLocalOnlyPassword-2026!')
        Profile.objects.filter(user=self.user).update(ai_opt_in=True)
        config = PlatformSettings.load()
        config.ai_enabled = True
        config.ai_emergency_stop = False
        config.ai_monthly_budget_eur = Decimal('25')
        config.save()
        self.wallet, _ = AICreditWallet.objects.get_or_create(user=self.user)
        self.wallet.balance = 2
        self.wallet.save(update_fields=['balance'])

    def assert_no_credit_consumed(self):
        self.wallet.refresh_from_db()
        self.assertEqual(self.wallet.balance, 2)
        self.assertFalse(AICreditDebit.objects.filter(user=self.user, refunded=False).exists())

    @patch('academy.ai_service._post')
    def test_inactive_user_rejected_before_reservation(self, provider):
        get_user_model().objects.filter(pk=self.user.pk).update(is_active=False)
        with self.assertRaises(AIUnavailable):
            tutor_reply(self.user, 'Explain Dutch verbs.')  # self.user is intentionally stale
        self.assertFalse(AIUsage.objects.exists())
        self.assert_no_credit_consumed()
        provider.assert_not_called()

    @patch('academy.ai_service._post')
    def test_suspended_user_rejected_before_reservation(self, provider):
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        with self.assertRaises(AIUnavailable):
            tutor_reply(self.user, 'Explain Dutch verbs.')
        self.assertFalse(AIUsage.objects.exists())
        self.assert_no_credit_consumed()
        provider.assert_not_called()

    @patch('academy.ai_service._post')
    def test_account_review_rejected_before_reservation(self, provider):
        Profile.objects.filter(user=self.user).update(legacy_review_required=True)
        with self.assertRaises(AIUnavailable):
            tutor_reply(self.user, 'Explain Dutch verbs.')
        self.assertFalse(AIUsage.objects.exists())
        self.assert_no_credit_consumed()
        provider.assert_not_called()

    @patch('academy.ai_service._post')
    def test_opt_out_rejected_before_reservation(self, provider):
        Profile.objects.filter(user=self.user).update(ai_opt_in=False)
        with self.assertRaises(AIUnavailable):
            tutor_reply(self.user, 'Explain Dutch verbs.')
        self.assertFalse(AIUsage.objects.exists())
        self.assert_no_credit_consumed()
        provider.assert_not_called()

    @patch('academy.ai_service._post')
    def test_revoked_during_first_moderation_refunds(self, provider):
        def reply(endpoint, payload):
            self.assertEqual(endpoint, '/moderations')
            Profile.objects.filter(user=self.user).update(legacy_review_required=True)
            return {'results': [{'flagged': False}]}
        provider.side_effect = reply
        with self.assertRaises(AIUnavailable):
            tutor_reply(self.user, 'Explain Dutch verbs.')
        self.assertEqual(provider.call_count, 1)
        usage=AIUsage.objects.get(user=self.user)
        self.assertEqual(usage.status, 'error')
        self.assertTrue(AICreditDebit.objects.get(usage=usage).refunded)
        self.assert_no_credit_consumed()

    @patch('academy.ai_service._post')
    def test_revoked_during_chat_reply_never_returns_answer(self, provider):
        def reply(endpoint, payload):
            if endpoint == '/chat/completions':
                Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
                return {'choices': [{'message': {'content': 'This must not be shown'}}],
                        'usage': {'prompt_tokens': 45, 'completion_tokens': 12}}
            return {'results': [{'flagged': False}]}
        provider.side_effect=reply
        with self.assertRaises(AIUnavailable):
            tutor_reply(self.user, 'Explain Dutch verbs.')
        self.assertEqual(provider.call_count, 3)
        usage=AIUsage.objects.get(user=self.user)
        self.assertEqual(usage.status, 'error')
        self.assertTrue(AICreditDebit.objects.get(usage=usage).refunded)
        self.assert_no_credit_consumed()

    @patch('academy.ai_service._post')
    def test_active_user_spends_one_credit_on_valid_reply(self, provider):
        def reply(endpoint, payload):
            if endpoint == '/chat/completions':
                return {'choices': [{'message': {'content': 'Ik werk means I work.'}}],
                        'usage': {'prompt_tokens': 45, 'completion_tokens': 12}}
            return {'results': [{'flagged': False}]}
        provider.side_effect=reply
        answer=tutor_reply(self.user,'Explain Dutch verbs.')
        self.assertIn('I work', answer)
        self.wallet.refresh_from_db()
        self.assertEqual(self.wallet.balance,1)
        self.assertEqual(AIUsage.objects.get(user=self.user).status,'ok')

    def test_restricted_tutor_get_clears_private_history(self):
        self.client.force_login(self.user)
        session=self.client.session
        session['ai_v9_history']=[{'role':'user','content':'Private note'}]
        session['ai_v9_course']='past-course'
        session.save()
        Profile.objects.filter(user=self.user).update(legacy_review_required=True)
        response=self.client.get(reverse('ai_tutor'))
        self.assertEqual(response.status_code,403)
        self.assertNotIn('Private note',response.content.decode('utf8'))
        self.assertNotIn('ai_v9_history',self.client.session)
        self.assertNotIn('ai_v9_course',self.client.session)

    def test_restricted_customer_cannot_open_payment_screen(self):
        self.client.force_login(self.user)
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        response=self.client.get(reverse('ai_plans'))
        self.assertEqual(response.status_code,403)

    @patch('academy.billing_v9._stripe_checkout')
    def test_restricted_customer_cannot_initiate_checkout(self, stripe):
        self.client.force_login(self.user)
        Profile.objects.filter(user=self.user).update(legacy_review_required=True)
        response=self.client.post(reverse('ai_checkout'))
        self.assertEqual(response.status_code,403)
        stripe.assert_not_called()
        self.assertFalse(AICreditPurchase.objects.filter(user=self.user).exists())

    def test_normal_ai_page_remains_accessible(self):
        self.client.force_login(self.user)
        self.assertEqual(self.client.get(reverse('ai_tutor')).status_code,200)

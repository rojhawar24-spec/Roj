"""V7 runtime regressions. Run using: python manage.py test academy --verbosity 2"""
import json
import re
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Language,Level,Unit,Lesson,Exercise,Profile

User=get_user_model()


class UXSEORegressionTests(TestCase):
    def setUp(self):
        self.user=User.objects.create_user(username='v7learner',email='v7@example.org',password='AProperPasswordExample!349')
        self.profile=self.user.learning_profile
        self.profile.onboarding_completed=True
        self.profile.placement_completed=True
        self.profile.save(update_fields=['onboarding_completed','placement_completed'])

    def test_login_keeps_safe_local_return_page(self):
        response=self.client.post('/login/?next=/learn/',{
            'email':'v7learner','password':'AProperPasswordExample!349','next':'/learn/'})
        self.assertRedirects(response,'/learn/',fetch_redirect_response=False)

    def test_external_return_destinations_are_rejected(self):
        for next_target in ('https://evil.example/','//evil.example/','/login/','/logout/'):
            self.client.logout()
            response=self.client.post('/login/',{
                'email':'v7learner','password':'AProperPasswordExample!349','next':next_target})
            self.assertRedirects(response,'/play/',fetch_redirect_response=False)

    def test_mfa_preserves_intended_local_page(self):
        import pyotp
        self.profile.totp_secret=pyotp.random_base32()
        self.profile.save(update_fields=['totp_secret'])
        start=self.client.post('/login/',{'email':'v7learner',
            'password':'AProperPasswordExample!349','next':'/learn/'})
        self.assertRedirects(start,'/mfa/verify/',fetch_redirect_response=False)
        verified=self.client.post('/mfa/verify/',{'code':pyotp.TOTP(self.profile.totp_secret).now()})
        self.assertRedirects(verified,'/learn/',fetch_redirect_response=False)

    def test_login_and_registration_have_responsive_controls(self):
        for path in ('/login/','/register/'):
            response=self.client.get(path)
            self.assertEqual(response.status_code,200)
            self.assertContains(response,'ux-v7.css')
            self.assertContains(response,'data-password-toggle')
            self.assertContains(response,'name="csrfmiddlewaretoken"')
            self.assertContains(response,'noindex,nofollow')
            self.assertEqual(response['X-Robots-Tag'],'noindex, nofollow, noarchive')
            self.assertNotContains(response,'property="og:title"')

    def test_public_metadata_and_schema_are_parseable(self):
        response=self.client.get('/')
        self.assertContains(response,'property="og:title"')
        self.assertContains(response,'rel="canonical"')
        self.assertNotContains(response,'noindex,nofollow')
        self.assertNotIn('X-Robots-Tag',response)
        html=response.content.decode('utf-8')
        match=re.search(r'<script type="application/ld\+json">(.*?)</script>',html,re.S)
        self.assertIsNotNone(match)
        data=json.loads(match.group(1))
        self.assertEqual(data['@type'],'WebApplication')

    def test_password_reset_is_noindex(self):
        response=self.client.get('/password-reset/')
        self.assertContains(response,'noindex,nofollow')
        self.assertNotContains(response,'property="og:title"')
        self.assertEqual(response['X-Robots-Tag'],'noindex, nofollow, noarchive')

    def test_logout_stays_post_only_and_clears_session(self):
        self.client.force_login(self.user)
        self.assertEqual(self.client.get('/logout/').status_code,405)
        self.assertRedirects(self.client.post('/logout/'),'/',fetch_redirect_response=False)
        self.assertNotIn('_auth_user_id',self.client.session)

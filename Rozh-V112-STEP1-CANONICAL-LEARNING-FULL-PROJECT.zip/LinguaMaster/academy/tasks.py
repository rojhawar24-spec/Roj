"""Consent-based email workflows; Celery worker and beat both required in production."""
from datetime import timedelta
from celery import shared_task
from django.conf import settings
from django.core.mail import send_mail
from django.utils import timezone
from django.db.models import Count, Q
from .models import Profile, ReviewCard, AIUsage, AuditEvent

@shared_task
def send_opted_reminders():
    now = timezone.localdate()
    count=0
    for profile in Profile.objects.select_related('user').filter(reminder_opt_in=True,user__is_active=True):
        if profile.last_active_day == now-timedelta(days=1) and profile.last_reminder_sent != now:
            send_mail('Your learning reminder','Your next lesson and vocabulary review are ready. You can disable these emails in your profile.',
                      settings.DEFAULT_FROM_EMAIL,[profile.user.email])
            profile.last_reminder_sent=now
            profile.save(update_fields=['last_reminder_sent'])
            count+=1
    return count

@shared_task
def send_weekly_digest():
    count=0
    now=timezone.localdate()
    current_time = timezone.now()
    profiles = Profile.objects.select_related('user').filter(
        summary_opt_in=True, user__is_active=True
    ).annotate(due_review_count=Count(
        'user__reviewcard', filter=Q(user__reviewcard__due__lte=current_time)
    ))
    for profile in profiles.iterator(chunk_size=200):
        if profile.last_summary_sent and profile.last_summary_sent > now-timedelta(days=7):
            continue
        due=profile.due_review_count
        send_mail('Your weekly learning summary',f'XP: {profile.xp}. Current streak: {profile.streak}. Due review words: {due}. Manage email preferences in your profile.',
                  settings.DEFAULT_FROM_EMAIL,[profile.user.email])
        profile.last_summary_sent=now
        profile.save(update_fields=['last_summary_sent'])
        count+=1
    return count

@shared_task
def purge_expired_logs():
    return {'ai':AIUsage.objects.filter(created_at__lt=timezone.now()-timedelta(days=settings.PRIVACY_LOG_RETENTION_DAYS)).delete()[0],
            'audit':AuditEvent.objects.filter(created_at__lt=timezone.now()-timedelta(days=settings.AUDIT_LOG_RETENTION_DAYS)).delete()[0]}

"""Deterministic assessment eligibility; no free-writing grading or database writes."""
import json
from .mixed_policy_v102 import canonical_mcq_errors
from .lesson_activities_v58 import public_activity, student_ready, ready, validate_answer
from .curriculum_policy_v99 import AUTO_GRADED_LEER_SPEEL_KINDS

ASSESSMENT_KINDS = AUTO_GRADED_LEER_SPEEL_KINDS
INDEXED_KINDS = ('word_matching', 'word_order')


def assessment_audio_text(exercise):
    """Required source text; None means the item is not a listening task."""
    if exercise.kind == 'listening':
        data = getattr(exercise, 'activity_data', None)
        text = data.get('audio_text') if isinstance(data, dict) else None
        return text if isinstance(text, str) else ''
    lesson = getattr(exercise, 'lesson', None)
    if getattr(lesson, 'skill', None) == 'listening':
        text = getattr(lesson, 'audio_text', '')
        return text if isinstance(text, str) else ''
    return None


def assessment_audio_url(exercise, course_code):
    text = assessment_audio_text(exercise)
    if text is None:
        return None
    if not course_code or not text.strip():
        return ''
    from .audio_v78 import approved_audio_url
    return approved_audio_url(text, course_code)


def assessment_ready(exercise, course_code=None):
    if assessment_audio_text(exercise) is not None and not assessment_audio_url(exercise, course_code):
        return False
    if exercise.kind == 'mcq':
        return not canonical_mcq_errors(exercise.prompt, exercise.options,
                                        exercise.answer, exercise.explanation,
                                        exercise.activity_data)
    if exercise.kind == 'listening':
        return bool(course_code and student_ready(exercise, course_code))
    return exercise.kind in ('fill_blank', *INDEXED_KINDS) and ready(exercise)


def assessment_rows(exercise):
    """Build public labels only, using the same deterministic order as grading."""
    if exercise.kind not in INDEXED_KINDS:
        return []
    activity = public_activity(exercise)
    if exercise.kind == 'word_matching':
        labels = [row['left'] for row in activity['matches']]
        choices = activity['match_options']
    else:
        choices = [row['text'] for row in activity['tokens']]
        labels = [''] * len(choices)
    return [{'name': f'q_{exercise.pk}_{i}', 'label': label,
             'choices': list(enumerate(choices))} for i, label in enumerate(labels)]


def assessment_responses(questions, post):
    """Exactly one response per field. Indexed responses need a full permutation.

    Native selects work without JavaScript. The server reconstructs the existing
    grading protocol; neither arbitrary words nor duplicate indices are allowed.
    """
    expected, responses = set(), {}
    if not questions:
        return None
    for q in questions:
        key = f'q_{q.pk}'
        if key in responses:
            return None
        if q.kind in INDEXED_KINDS:
            rows = assessment_rows(q)
            if not rows:
                return None
            indices = []
            for row in rows:
                name = row['name']
                expected.add(name)
                values = post.getlist(name)
                allowed = {str(index): index for index, _ in row['choices']}
                if len(values) != 1 or values[0] not in allowed:
                    return None
                indices.append(allowed[values[0]])
            if len(set(indices)) != len(indices):
                return None
            answer = (json.dumps(indices) if q.kind == 'word_matching' else
                      ' '.join(rows[0]['choices'][i][1] for i in indices))
        else:
            expected.add(key)
            values = post.getlist(key)
            if len(values) != 1:
                return None
            answer = values[0]
        if not validate_answer(q, answer):
            return None
        responses[key] = answer
    if {key for key in post if key.startswith('q_')} != expected:
        return None
    return responses


def assessment_payload_valid(questions, post):
    return assessment_responses(questions, post) is not None


def assessment_snapshot(questions, user_id, kind, scope_id):
    """Keyed fingerprint: no answer key in the browser, bind to user and scope."""
    from django.utils.crypto import salted_hmac
    fields = [(q.pk, q.lesson_id, q.kind, q.prompt, q.options, q.answer,
               q.activity_data, q.explanation, assessment_audio_text(q)) for q in questions]
    payload = json.dumps([user_id, kind, scope_id, fields], ensure_ascii=False,
                         sort_keys=True, separators=(',', ':'))
    return salted_hmac('rozh.assessment.snapshot.v104', payload, algorithm='sha256').hexdigest()


MESSAGES = {
    'en': ('This test is not ready yet. Return to your learning path.', 'Answer every question and try again.'),
    'nl': ('Deze toets is nog niet klaar. Ga terug naar je leerpad.', 'Beantwoord elke vraag en probeer opnieuw.'),
    'ckb': ('ئەم تاقیکردنەوەیە هێشتا ئامادە نییە. بگەڕێوە بۆ ڕێڕەوی فێربوون.', 'وەڵامی هەموو پرسیارەکان بدەرەوە و دووبارە هەوڵ بدە.'),
    'ar': ('هذا الاختبار غير جاهز بعد. عد إلى مسار التعلم.', 'أجب عن جميع الأسئلة وحاول مرة أخرى.'),
}


def assessment_message(locale, *, unavailable):
    return MESSAGES.get(locale, MESSAGES['en'])[0 if unavailable else 1]

"""Live V28 rendering and safe redirect checks; run with `manage.py test`.
These tests are NOT executed by offline source checks.
"""
from django.test import TestCase
from django.urls import reverse


class V28AccountRenderingTests(TestCase):
    def test_login_and_signup_render_full_new_design_and_csrf(self):
        for route in ('login', 'register'):
            with self.subTest(route=route):
                response = self.client.get(reverse(route))
                self.assertEqual(response.status_code, 200)
                self.assertContains(response, 'lm28-auth')
                self.assertContains(response, 'auth-v35-bundle.css')
                self.assertContains(response, 'csrfmiddlewaretoken')
                self.assertContains(response, 'rozh-sun-192.png')
                self.assertContains(response, 'data-password-toggle')

    def test_selected_feature_and_four_locales_survive_public_auth(self):
        for language, direction in (('nl', 'ltr'), ('en', 'ltr'), ('ckb', 'rtl'), ('ar', 'rtl')):
            with self.subTest(lang=language):
                response = self.client.get(reverse('login'), {'ui': language, 'next': '/grammar/'})
                self.assertContains(response, f'lang="{language}"')
                self.assertContains(response, f'dir="{direction}"')
                self.assertContains(response, 'name="next" value="/grammar/"')

    def test_external_redirects_never_enter_form(self):
        for dest in ('https://example.org/', '//example.org/', '/login/', '/mfa/verify/'):
            with self.subTest(next=dest):
                response = self.client.get(reverse('login'), {'next': dest})
                self.assertEqual(response.status_code, 200)
                self.assertContains(response, 'name="next" value=""')

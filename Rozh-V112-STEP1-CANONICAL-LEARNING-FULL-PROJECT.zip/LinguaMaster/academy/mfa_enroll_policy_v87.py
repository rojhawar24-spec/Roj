"""V87: account password reauthentication is required before enrolling MFA.

This module contains no Django dependencies so the core decision can be
exercised offline; the real Django view must also check the locked User row.
"""

_ENROLL_ERROR = {
    'nl': 'Controleer je huidige wachtwoord en je authenticatiecode.',
    'en': 'Check your current password and authenticator code.',
    'ckb': 'وشەی نهێنیی ئێستا و کۆدی پشتڕاستکردنەوە بپشکنە.',
    'kmr': 'Şîfreya niha û koda piştrastkirinê kontrol bike.',
    'ku': 'Şîfreya xwe ya niha û koda rastandinê kontrol bike.',
    'uk': 'Перевірте поточний пароль і код автентифікатора.',
    'ar': 'تحقق من كلمة المرور الحالية ورمز المصادقة.',
    'fr': 'Vérifiez votre mot de passe actuel et votre code d’authentification.',
}


def enrollment_error(locale):
    return _ENROLL_ERROR.get(locale, _ENROLL_ERROR['en'])


def verify_enrollment_password(user, password):
    """Reject missing/oversized values without ever storing or echoing them."""
    if not isinstance(password, str) or not password or len(password) > 1024:
        return False
    return bool(user.check_password(password))

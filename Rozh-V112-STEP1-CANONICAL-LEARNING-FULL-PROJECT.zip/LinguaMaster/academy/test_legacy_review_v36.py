"""Django integration tests: legacy account quarantine is fail-closed.

All tests run in Django's isolated TEST database. They do not touch actual
accounts, production secrets, MFA recovery records, or application data.
"""
from importlib import import_module
from io import StringIO
from types import SimpleNamespace
from unittest.mock import patch

from django.contrib.auth import get_user_model
from academy.email_verification_tokens import email_verification_token_generator
from django.core import mail
from django.core.cache import cache
from django.core.management import call_command
from django.db import connection
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from academy.models import Profile


@override_settings(MAILERS={'default':{'BACKEND':'django.core.mail.backends.locmem.EmailBackend'}})
class LegacyQuarantineTests(TestCase):
    def setUp(self):
        cache.clear()
        U = get_user_model()
        self.owner = U.objects.create_superuser('owner36', 'owner36@example.test', 'LongOwnerPass2026!')
        self.owner.learning_profile.email_verified_at = timezone.now()
        self.owner.learning_profile.totp_secret = 'JBSWY3DPEHPK3PXP'
        self.owner.learning_profile.save(update_fields=['email_verified_at','totp_secret'])
        self.user = U.objects.create_user('legacy36', 'legacy36@example.test', 'LongUserPass2026!', is_active=False)
        self.profile = self.user.learning_profile
        self.profile.email_verified_at = None
        self.profile.save(update_fields=['email_verified_at'])

    def token_url(self):
        uid = urlsafe_base64_encode(force_bytes(self.user.pk))
        return reverse('verify_email', args=[uid, email_verification_token_generator.make_token(self.user)])

    def act_as_owner(self, action):
        self.client.force_login(self.owner)
        sess = self.client.session
        sess['mfa_verified_id'] = self.owner.pk
        sess.save()
        return self.client.post(reverse('manager_user_action', args=[self.user.pk, action]))

    def test_migration_quarantines_unknown_legacy_pending_without_activating(self):
        schema = SimpleNamespace(connection=connection)
        migration = import_module('academy.migrations.0010_quarantine_legacy_pending_accounts')
        migration.quarantine_existing_ambiguous_accounts(
            # Migration uses historical models, rather than importing live model.
            __import__('django.apps', fromlist=['apps']).apps, schema)
        self.user.refresh_from_db(); self.profile.refresh_from_db()
        self.assertFalse(self.user.is_active)
        self.assertTrue(self.profile.legacy_review_required)
        self.assertIsNone(self.profile.suspended_at)
        # Re-running migration logic must remain fail-closed and idempotent.
        migration.quarantine_existing_ambiguous_accounts(__import__('django.apps', fromlist=['apps']).apps, schema)
        self.user.refresh_from_db()
        self.assertFalse(self.user.is_active)

    def test_quarantined_user_cannot_request_or_consume_email_verification(self):
        self.profile.legacy_review_required = True
        self.profile.save(update_fields=['legacy_review_required'])
        url = self.token_url()
        self.client.post(reverse('resend_verification'), {'email':self.user.email})
        self.assertEqual(len(mail.outbox), 0)
        self.assertEqual(self.client.get(url).status_code, 302)
        self.assertEqual(self.client.post(url).status_code, 302)
        self.user.refresh_from_db()
        self.assertFalse(self.user.is_active)

    def test_review_release_is_owner_only_post_only_and_never_activates(self):
        self.profile.legacy_review_required = True
        self.profile.save(update_fields=['legacy_review_required'])
        endpoint = reverse('manager_user_action', args=[self.user.pk, 'approve_legacy'])
        self.assertEqual(self.client.get(endpoint).status_code, 302)  # login needed
        self.profile.refresh_from_db()
        self.assertTrue(self.profile.legacy_review_required)
        # GET must not mutate the user even as owner.
        self.client.force_login(self.owner)
        sess = self.client.session
        sess['mfa_verified_id'] = self.owner.pk
        sess.save()
        self.assertEqual(self.client.get(endpoint).status_code, 405)
        self.profile.refresh_from_db()
        self.assertTrue(self.profile.legacy_review_required)
        old_token = self.token_url()
        self.assertEqual(self.act_as_owner('approve_legacy').status_code, 302)
        self.user.refresh_from_db(); self.profile.refresh_from_db()
        self.assertNotEqual(old_token, self.token_url())
        self.client.logout()
        self.assertEqual(self.client.get(old_token).status_code, 302)
        self.assertEqual(self.client.post(old_token).status_code, 302)
        self.user.refresh_from_db()
        self.assertFalse(self.user.is_active)
        self.assertFalse(self.user.is_active)
        self.assertIsNone(self.profile.email_verified_at)
        self.assertFalse(self.profile.legacy_review_required)
        # Only a fresh, user-initiated verified POST can activate.
        self.client.logout()
        self.client.post(reverse('resend_verification'), {'email':self.user.email})
        self.assertEqual(len(mail.outbox), 1)
        self.assertEqual(self.client.get(self.token_url()).status_code, 200)
        self.user.refresh_from_db()
        self.assertFalse(self.user.is_active)
        with patch('academy.views.send_mail'):
            self.assertEqual(self.client.post(self.token_url()).status_code, 302)
        self.user.refresh_from_db()
        self.assertTrue(self.user.is_active)

    def test_preblock_token_never_revalidates_after_manager_block_and_unblock(self):
        token_before = self.token_url()
        self.act_as_owner('block')
        self.act_as_owner('unblock')
        self.user.refresh_from_db(); self.profile.refresh_from_db()
        self.assertFalse(self.user.is_active)
        self.assertFalse(self.profile.legacy_review_required)
        self.assertGreaterEqual(self.profile.email_verification_version, 2)
        self.assertNotEqual(token_before, self.token_url())
        self.client.logout()
        self.assertEqual(self.client.get(token_before).status_code, 302)
        self.assertEqual(self.client.post(token_before).status_code, 302)
        self.user.refresh_from_db()
        self.assertFalse(self.user.is_active)

    def test_manager_suspension_cannot_be_overridden_by_review(self):
        self.profile.legacy_review_required = True
        self.profile.suspended_at = timezone.now()
        self.profile.save(update_fields=['legacy_review_required', 'suspended_at'])
        self.act_as_owner('approve_legacy')
        self.user.refresh_from_db(); self.profile.refresh_from_db()
        self.assertFalse(self.user.is_active)
        self.assertTrue(self.profile.legacy_review_required)
        self.assertIsNotNone(self.profile.suspended_at)
        self.client.logout()
        self.assertEqual(self.client.post(self.token_url()).status_code, 302)
        self.user.refresh_from_db()
        self.assertFalse(self.user.is_active)

    def test_newly_registered_unverified_account_can_verify_normally(self):
        self.assertFalse(self.profile.legacy_review_required)  # model default for new accounts
        with patch('academy.views.send_mail'):
            self.assertEqual(self.client.post(self.token_url()).status_code, 302)
        self.user.refresh_from_db()
        self.assertTrue(self.user.is_active)

    def test_audit_and_local_recovery_reject_quarantine(self):
        self.profile.legacy_review_required = True
        self.profile.save(update_fields=['legacy_review_required'])
        output=StringIO()
        call_command('audit_account_states', stdout=output)
        self.assertIn('historical_review_required:',output.getvalue())
        # Local verification helpers should reject held accounts as well.
        source = __import__('inspect').getsource(import_module('academy.management.commands.local_verification_link'))
        self.assertIn('profile.legacy_review_required',source)

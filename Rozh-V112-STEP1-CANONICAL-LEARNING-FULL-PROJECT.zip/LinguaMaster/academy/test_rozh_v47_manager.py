"""Real Django TestCase (isolated test DB): Manager view locale and authorization."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .models import Profile

class ManagerLocaleAndSecurityTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.owner = get_user_model().objects.create_superuser(
            username='v47-owner', email='v47-owner@example.invalid', password='V47-Test-Owner-Passphrase-!')
        cls.student = get_user_model().objects.create_user(
            username='v47-student', email='v47-student@example.invalid', password='V47-Test-Student-Passphrase-!')
        for user in (cls.owner,cls.student):
            profile, _ = Profile.objects.get_or_create(user=user)
            profile.ui_language = 'ckb' if user.pk==cls.owner.pk else 'nl'
            if user.pk == cls.owner.pk:
                profile.email_verified_at = timezone.now()
                profile.totp_secret = 'JBSWY3DPEHPK3PXP'
            profile.save()

    def test_student_cannot_read_manager_console(self):
        self.client.force_login(self.student)
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)
        self.assertEqual(self.client.get(reverse('manager_users')).status_code,403)

    def test_owner_without_mfa_session_is_denied(self):
        self.client.force_login(self.owner)
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)
        self.assertEqual(self.client.get(reverse('manager_users')).status_code,403)

    def test_verified_owner_receives_sorani_rtl_and_real_forms(self):
        self.client.force_login(self.owner)
        session=self.client.session
        session['mfa_verified_id']=self.owner.pk
        session.save()
        response=self.client.get(reverse('manager'))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'lang="ckb" dir="rtl"')
        self.assertContains(response,'بەڕێوەبردنی پلاتفۆرم')
        self.assertContains(response,'name="csrfmiddlewaretoken"')
        users=self.client.get(reverse('manager_users'))
        self.assertEqual(users.status_code,200)
        self.assertContains(users,'lang="ckb" dir="rtl"')
        self.assertContains(users,'بەکارهێنەران')

    def test_nl_and_en_are_ltr(self):
        self.client.force_login(self.owner)
        session=self.client.session
        session['mfa_verified_id']=self.owner.pk
        session.save()
        profile=self.owner.learning_profile
        for language,word in (('nl','Gebruikers'),('en','Users')):
            profile.ui_language=language
            profile.save(update_fields=['ui_language'])
            response=self.client.get(reverse('manager'))
            self.assertEqual(response.status_code,200)
            self.assertContains(response, f'lang="{language}" dir="ltr"')
            self.assertContains(response,word)

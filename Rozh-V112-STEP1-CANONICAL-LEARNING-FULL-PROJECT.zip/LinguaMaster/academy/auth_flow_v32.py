"""One consistent, localized account recovery experience (no user secrets exposed)."""
from .auth_experience_v26 import auth_context, apply_form_accessibility

FLOW_COPY = {'nl': {'local_console_email': 'Lokale testversie: herstel- en verificatielinks staan in de privémap '
                               '.private-email-outbox waar Django draait. Ze worden niet naar je echte inbox '
                               'verstuurd.',
        'sending': 'Verzenden…',
        'mfa_disable_title': 'Tweestapsverificatie',
        'mfa_disable_privileged': 'Beheerders kunnen tweestapsverificatie niet uitschakelen.',
        'mfa_disable_invalid': 'Controleer je huidige wachtwoord en authenticatiecode en probeer opnieuw.',
        'mfa_disable_back': 'Terug naar je profiel',
        'reset_title': 'Herstel je wachtwoord',
        'reset_desc': 'Vul je e-mailadres in. Als er een geschikt account bestaat, ontvang je een veilige '
                      'herstellink.',
        'reset_action': 'Stuur herstellink',
        'reset_done_title': 'Controleer je inbox',
        'reset_done_desc': 'Als dit e-mailadres van een geverifieerd actief account is, is een resetlink '
                           'verstuurd. Nog niet bevestigd? Vraag eerst een e-mailverificatielink aan.',
        'reset_confirm_title': 'Kies een nieuw wachtwoord',
        'reset_confirm_desc': 'Gebruik een uniek wachtwoord van minimaal 8 tekens (15+ aanbevolen).',
        'reset_confirm_action': 'Wachtwoord bijwerken',
        'reset_invalid_title': 'De link is ongeldig of verlopen',
        'reset_invalid_desc': 'Vraag een nieuwe herstellink aan om verder te gaan.',
        'reset_complete_title': 'Wachtwoord gewijzigd',
        'reset_complete_desc': 'Je kunt weer veilig inloggen met je nieuwe wachtwoord.',
        'resend_title': 'Verificatiemail opnieuw sturen',
        'resend_desc': 'Vul je e-mailadres in. Als er een niet-geverifieerd account bestaat, sturen we een '
                       'nieuwe verificatielink.',
        'resend_action': 'Stuur verificatiemail',
        'resend_notice': 'Als er een niet-geverifieerd account bestaat, is een verificatiemail aangevraagd.',
        'verify_title': 'Bevestig je e-mailadres',
        'verify_success': 'Je e-mailadres is bevestigd. Je kunt nu inloggen.',
        'verify_invalid': 'Deze verificatielink is ongeldig, al gebruikt of verlopen.',
        'verify_confirm_desc': 'Bevestig je e-mailadres met de knop hieronder. Alleen het bekijken van deze '
                               'link verandert je account niet.',
        'verify_confirm_action': 'E-mailadres bevestigen',
        'back_login': 'Terug naar inloggen',
        'again': 'Nieuwe link aanvragen',
        'email_label': 'E-mailadres',
        'new_password1': 'Nieuw wachtwoord',
        'new_password2': 'Bevestig nieuw wachtwoord',
        'try_later': 'Te veel pogingen. Probeer het later opnieuw.',
        'mfa_setup_title': 'Beveilig je account met tweestapsverificatie',
        'mfa_setup_desc': 'Scan de QR-code in je authenticator-app en voer de zescijferige code in.',
        'mfa_setup_action': 'Tweestapsverificatie inschakelen',
        'mfa_setup_manual': 'Of voer deze geheime sleutel handmatig in je app in. Deel deze nooit.',
        'mfa_setup_error': 'De code klopt niet. Controleer de tijd van je toestel en probeer een nieuwe '
                           'code.',
        'mfa_recovery_title': 'Bewaar je herstelcodes',
        'mfa_recovery_desc': 'Deze acht herstelcodes worden maar één keer getoond. Bewaar ze in een '
                             'wachtwoordmanager.',
        'mfa_recovery_done': 'Ik heb de codes veilig opgeslagen',
        'verification_required': 'Verifieer je e-mailadres voordat je inlogt.'},
 'en': {'local_console_email': 'Local development: recovery and verification links are saved in the private '
                               '.private-email-outbox folder used by Django, not delivered to your real '
                               'inbox.',
        'sending': 'Sending…',
        'mfa_disable_title': 'Two-factor authentication',
        'mfa_disable_privileged': 'Privileged accounts cannot disable two-factor authentication.',
        'mfa_disable_invalid': 'Check your current password and authenticator code and try again.',
        'mfa_disable_back': 'Back to your profile',
        'reset_title': 'Reset your password',
        'reset_desc': 'Enter your email. If an eligible account exists, we will send a secure reset link.',
        'reset_action': 'Send reset link',
        'reset_done_title': 'Check your inbox',
        'reset_done_desc': 'If this email belongs to a verified active account, a reset link was requested. '
                           'Not verified yet? Request a verification link first.',
        'reset_confirm_title': 'Choose a new password',
        'reset_confirm_desc': 'Use a unique password with at least 8 characters (15+ recommended).',
        'reset_confirm_action': 'Update password',
        'reset_invalid_title': 'Link invalid or expired',
        'reset_invalid_desc': 'Request another reset link to continue.',
        'reset_complete_title': 'Password updated',
        'reset_complete_desc': 'You can now sign in securely with your new password.',
        'resend_title': 'Resend verification email',
        'resend_desc': 'Enter your email. If an unverified account exists, we will send a new verification '
                       'link.',
        'resend_action': 'Send verification email',
        'resend_notice': 'If an unverified account exists, a verification email has been requested.',
        'verify_title': 'Verify your email address',
        'verify_success': 'Your email address is verified. You can now sign in.',
        'verify_invalid': 'This verification link is invalid, already used or expired.',
        'verify_confirm_desc': 'Confirm your email with the button below. Merely opening this link does not '
                               'change your account.',
        'verify_confirm_action': 'Confirm email',
        'back_login': 'Back to sign in',
        'again': 'Request a new link',
        'email_label': 'Email address',
        'new_password1': 'New password',
        'new_password2': 'Confirm new password',
        'try_later': 'Too many attempts. Try again later.',
        'mfa_setup_title': 'Protect your account with two-factor authentication',
        'mfa_setup_desc': 'Scan the QR code in your authenticator app and enter the six-digit code.',
        'mfa_setup_action': 'Enable two-factor authentication',
        'mfa_setup_manual': 'Or enter this secret key into your app. Never share it.',
        'mfa_setup_error': 'That code did not match. Check your device time and try a new code.',
        'mfa_recovery_title': 'Save your recovery codes',
        'mfa_recovery_desc': 'These eight codes are shown only once. Store them in a password manager.',
        'mfa_recovery_done': 'I have securely saved my codes',
        'verification_required': 'Verify your email address before signing in.'},
 'ckb': {'local_console_email': 'لە وەشانی ناوخۆییدا، لینکی گەڕاندنەوە و پشتڕاستکردنەوە لە فۆڵدەری تایبەتی '
                                '.private-email-outbox پاشەکەوت دەکرێت، نەک لە ئیمەیڵی ڕاستەقینەت.',
         'sending': 'ناردن…',
         'mfa_disable_title': 'پشتڕاستکردنەوەی دوو هەنگاوی',
         'mfa_disable_privileged': 'هەژماری بەڕێوەبەر ناتوانێت پشتڕاستکردنەوەی دوو هەنگاوی ناچالاک بکات.',
         'mfa_disable_invalid': 'وشەی نهێنیی ئێستا و کۆدی پشتڕاستکردنەوە بپشکنە و دووبارە هەوڵ بدە.',
         'mfa_disable_back': 'گەڕانەوە بۆ پرۆفایل',
         'reset_title': 'گەڕاندنەوەی وشەی نهێنی',
         'reset_desc': 'ئیمەیڵەکەت بنووسە. ئەگەر هەژمارێکی گونجاو هەبێت، لینکی گەڕاندنەوەت بۆ دەنێرین.',
         'reset_action': 'ناردنی لینکی گەڕاندنەوە',
         'reset_done_title': 'ئیمەیڵەکەت بپشکنە',
         'reset_done_desc': 'ئەگەر ئەم ئیمەیڵە هی هەژمارێکی چالاک و پشتڕاستکراوەیە، لینکی گەڕاندنەوە '
                            'نێردراوە. ئەگەر پشتڕاست نەکراوەتەوە، داوای لینکی پشتڕاستکردنەوە بکە.',
         'reset_confirm_title': 'وشەی نهێنیی نوێ هەڵبژێرە',
         'reset_confirm_desc': 'وشەی نهێنییەکی تایبەت بە لانیکەم ٨ پیت بەکاربهێنە (١٥+ باشترە).',
         'reset_confirm_action': 'گۆڕینی وشەی نهێنی',
         'reset_invalid_title': 'لینکەکە نادروستە یان بەسەرچووە',
         'reset_invalid_desc': 'بۆ بەردەوامبوون لینکێکی نوێ داوا بکە.',
         'reset_complete_title': 'وشەی نهێنی گۆڕدرا',
         'reset_complete_desc': 'ئێستا دەتوانیت بە وشەی نهێنیی نوێ بچیتە ژوورەوە.',
         'resend_title': 'دووبارە ناردنی ئیمەیڵی پشتڕاستکردنەوە',
         'resend_desc': 'ئیمەیڵەکەت بنووسە. ئەگەر هەژماری پشتڕاستنەکراو هەبێت، لینکێکی نوێ دەنێرین.',
         'resend_action': 'ناردنی ئیمەیڵی پشتڕاستکردنەوە',
         'resend_notice': 'ئەگەر هەژماری پشتڕاستنەکراو هەبێت، داوای ئیمەیڵی پشتڕاستکردنەوە کراوە.',
         'verify_title': 'پشتڕاستکردنەوەی ئیمەیڵ',
         'verify_success': 'ئیمەیڵەکەت پشتڕاست کرایەوە. ئێستا دەتوانیت بچیتە ژوورەوە.',
         'verify_invalid': 'ئەم لینکە نادروستە، پێشتر بەکارهاتووە یان بەسەرچووە.',
         'verify_confirm_desc': 'بە دوگمەکەی خوارەوە ئیمەیڵەکەت پشتڕاست بکەرەوە. تەنها کردنەوەی لینکەکە '
                                'هەژمارەکەت ناگۆڕێت.',
         'verify_confirm_action': 'پشتڕاستکردنەوەی ئیمەیڵ',
         'back_login': 'گەڕانەوە بۆ چوونەژوورەوە',
         'again': 'داواکردنی لینکێکی نوێ',
         'email_label': 'ناونیشانی ئیمەیڵ',
         'new_password1': 'وشەی نهێنیی نوێ',
         'new_password2': 'دووبارە وشەی نهێنیی نوێ',
         'try_later': 'هەوڵەکان زۆر بوون. دواتر دووبارە هەوڵ بدە.',
         'mfa_setup_title': 'پاراستنی هەژمار بە پشتڕاستکردنەوەی دوو هەنگاوی',
         'mfa_setup_desc': 'کۆدی QR بە ئەپی پشتڕاستکردنەوە بسکەنە و کۆدی شەش ژمارەیی بنووسە.',
         'mfa_setup_action': 'چالاککردنی پشتڕاستکردنەوەی دوو هەنگاوی',
         'mfa_setup_manual': 'یان ئەم کلیلی نهێنییە لە ئەپەکەت بنووسە. هەرگیز بۆ کەسی مەینێرە.',
         'mfa_setup_error': 'کۆدەکە نادروستە. کاتی ئامێرەکەت بپشکنە و کۆدی نوێ تاقی بکە.',
         'mfa_recovery_title': 'کۆدەکانی گەڕاندنەوە بپارێزە',
         'mfa_recovery_desc': 'ئەم هەشت کۆدە تەنها یەک جار پیشان دەدرێن. لە Password Manager هەڵیان بگرە.',
         'mfa_recovery_done': 'کۆدەکانم بە پارێزراوی هەڵگرتوون',
         'verification_required': 'پێش چوونەژوورەوە ئیمەیڵەکەت پشتڕاست بکەرەوە.'},
 'ar': {'local_console_email': 'في النسخة المحلية تُحفظ رسائل الاستعادة والتحقق في المجلد الخاص '
                               '.private-email-outbox ولا تُطبع في PowerShell أو تُرسل إلى بريدك الحقيقي.',
        'sending': 'جارٍ الإرسال…',
        'mfa_disable_title': 'المصادقة الثنائية',
        'mfa_disable_privileged': 'لا يمكن لحسابات الإدارة تعطيل المصادقة الثنائية.',
        'mfa_disable_invalid': 'تحقّق من كلمة المرور الحالية ورمز المصادقة ثم حاول مجددًا.',
        'mfa_disable_back': 'العودة إلى ملفك الشخصي',
        'reset_title': 'إعادة تعيين كلمة المرور',
        'reset_desc': 'أدخل بريدك الإلكتروني. إذا وُجد حساب مؤهل، سنرسل رابطًا آمنًا.',
        'reset_action': 'إرسال رابط الاستعادة',
        'reset_done_title': 'تحقّق من بريدك',
        'reset_done_desc': 'إذا كان هذا البريد مرتبطًا بحساب نشط ومؤكد فقد طُلب رابط الاستعادة. إن لم تؤكد '
                           'بريدك، اطلب رابط التأكيد أولًا.',
        'reset_confirm_title': 'اختر كلمة مرور جديدة',
        'reset_confirm_desc': 'استخدم كلمة مرور فريدة من ٨ أحرف على الأقل (يُنصح بـ ١٥ أو أكثر).',
        'reset_confirm_action': 'تحديث كلمة المرور',
        'reset_invalid_title': 'الرابط غير صالح أو انتهت صلاحيته',
        'reset_invalid_desc': 'اطلب رابطًا جديدًا للمتابعة.',
        'reset_complete_title': 'تم تحديث كلمة المرور',
        'reset_complete_desc': 'يمكنك الآن تسجيل الدخول بأمان بكلمة المرور الجديدة.',
        'resend_title': 'إعادة إرسال رسالة التحقق',
        'resend_desc': 'أدخل بريدك. إذا وُجد حساب غير مؤكد، سنرسل رابط تحقق جديدًا.',
        'resend_action': 'إرسال رسالة التحقق',
        'resend_notice': 'إذا وُجد حساب غير مؤكد، فقد تم طلب رسالة تحقق.',
        'verify_title': 'تأكيد عنوان بريدك الإلكتروني',
        'verify_success': 'تم تأكيد بريدك. يمكنك الآن تسجيل الدخول.',
        'verify_invalid': 'رابط التحقق غير صالح أو استُخدم أو انتهت صلاحيته.',
        'verify_confirm_desc': 'أكد بريدك الإلكتروني باستخدام الزر أدناه. فتح الرابط وحده لا يغير حسابك.',
        'verify_confirm_action': 'تأكيد البريد الإلكتروني',
        'back_login': 'العودة إلى تسجيل الدخول',
        'again': 'طلب رابط جديد',
        'email_label': 'البريد الإلكتروني',
        'new_password1': 'كلمة المرور الجديدة',
        'new_password2': 'تأكيد كلمة المرور الجديدة',
        'try_later': 'محاولات كثيرة جدًا. حاول لاحقًا.',
        'mfa_setup_title': 'احمِ حسابك بالمصادقة الثنائية',
        'mfa_setup_desc': 'امسح رمز QR بتطبيق المصادقة وأدخل الرمز المكوّن من ستة أرقام.',
        'mfa_setup_action': 'تفعيل المصادقة الثنائية',
        'mfa_setup_manual': 'أو أدخل هذا المفتاح السري في تطبيقك. لا تشاركه مطلقًا.',
        'mfa_setup_error': 'الرمز غير صحيح. تحقق من وقت الجهاز وجرب رمزًا جديدًا.',
        'mfa_recovery_title': 'احتفظ برموز الاسترداد',
        'mfa_recovery_desc': 'هذه الرموز الثمانية تُعرض مرة واحدة فقط. احفظها في مدير كلمات مرور.',
        'mfa_recovery_done': 'حفظت رموزي بأمان',
        'verification_required': 'أكد بريدك الإلكتروني قبل تسجيل الدخول.'}}


def flow_context(request, form=None, destination='', is_register=False):
    """Produce a complete context for standalone account recovery screens."""
    from .auth_experience_v26 import visitor_language
    locale = visitor_language(request)
    if form is not None:
        auth = auth_context(request, form, destination, is_register)
        for name in ('email', 'new_password1', 'new_password2'):
            if name in form.fields:
                f = form.fields[name]
                f.label = FLOW_COPY[locale]['email_label' if name == 'email' else name]
                f.widget.attrs.setdefault('autocomplete', 'email' if name == 'email' else 'new-password')
                if name == 'new_password1':
                    f.widget.attrs['minlength'] = '8'
                    f.help_text = auth['A26']['password_guidance']
        apply_form_accessibility(form)
    else:
        auth = auth_context(request, type('EmptyForm', (), {'fields': {}})(), destination, is_register)
    return {**auth, 'F32': FLOW_COPY[locale], 'PRIVATE_PAGE': True, 'noindex': True,
            'next_destination': destination}


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'auth_flow_v32', ['FLOW_COPY'])

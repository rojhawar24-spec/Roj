"""Integration tests for V31 FIX3 password policy and safe local recovery.

These MUST run against Django's isolated test database, never the user's live
SQLite database. No email or account activation is simulated as a bypass.
"""
import re
from urllib.parse import urlsplit
from django.conf import settings
from django.contrib.auth import get_user_model
from django.core import mail
from django.core.cache import cache
from django.test import TestCase, override_settings
from django.urls import reverse

from .forms import RegisterForm

User = get_user_model()


@override_settings(MAILERS={'default':{'BACKEND':'django.core.mail.backends.locmem.EmailBackend'}})
class PasswordPolicyV31Fix3Tests(TestCase):
    password = 'Frew0rds-unique-2026'  # 19+ characters for new single-factor accounts

    def setUp(self):
        cache.clear()

    def test_fifteen_or_more_characters_are_allowed_at_registration(self):
        form = RegisterForm(data={
            'username':'test_learner','email':'learner@example.test',
            'password1':self.password,'password2':self.password,'age_confirmed':True,
        })
        self.assertTrue(form.is_valid(), form.errors)

    def test_eight_character_unique_password_is_accepted(self):
        # The owner-approved 8-character minimum; password-only NIST alignment
        # remains an OPEN production decision (15 recommended without MFA).
        password = 'R7!pQ2z@'
        self.assertEqual(len(password), 8)
        form = RegisterForm(data={
            'username':'short_policy', 'email':'short-policy@example.test',
            'password1':password, 'age_confirmed':True,
        })
        self.assertTrue(form.is_valid(), form.errors)

    def test_seven_characters_are_rejected(self):
        form = RegisterForm(data={
            'username':'test_learner','email':'learner@example.test',
            'password1':'Frw0rds','password2':'Frw0rds','age_confirmed':True,
        })
        self.assertFalse(form.is_valid())
        self.assertIn('password1', form.errors)

    def test_common_and_numeric_passwords_remain_blocked(self):
        for value in ('password', '12345678'):
            with self.subTest(value=value):
                form = RegisterForm(data={
                    'username':'test_learner','email':'learner@example.test',
                    'password1':value,'password2':value,'age_confirmed':True,
                })
                self.assertFalse(form.is_valid())
                self.assertIn('password1', form.errors)

    def test_registration_is_active_and_ready_without_email(self):
        response = self.client.post(reverse('register'), {
            'username':'shortpass_learner','email':'shortpass@example.test',
            'password1':self.password,'age_confirmed':'on',
        })
        self.assertEqual(response.status_code,302)
        account=User.objects.get(username='shortpass_learner')
        self.assertTrue(account.is_active)
        self.assertIsNone(account.learning_profile.email_verified_at)
        self.assertEqual(len(mail.outbox),0)
        self.assertEqual(int(self.client.session['_auth_user_id']),account.pk)
        self.client.post(reverse('logout'))
        signed_in=self.client.post(reverse('login'),{'email':account.email,'password':self.password})
        self.assertEqual(signed_in.status_code,302)
        self.assertIn('_auth_user_id',self.client.session)

    def test_reset_form_requires_strong_password_and_login_with_new_password(self):
        user = User.objects.create_user('shortpass_reset', 'reset@example.test', 'SomeOldPass!2026')
        user.learning_profile.email_verified_at=__import__('django.utils.timezone',fromlist=['now']).now()
        user.learning_profile.save(update_fields=['email_verified_at'])
        reset_requested = self.client.post(reverse('password_reset'), {'email':user.email})
        self.assertEqual(reset_requested.status_code, 302)
        self.assertEqual(len(mail.outbox), 1)
        match = re.search(r'https?://[^\s]+/reset/[^\s]+', mail.outbox[0].body)
        self.assertIsNotNone(match)
        first = self.client.get(urlsplit(match.group()).path)
        self.assertEqual(first.status_code, 302)
        success = self.client.post(first['Location'], {
            'new_password1':self.password, 'new_password2':self.password,
        })
        self.assertEqual(success.status_code, 302)
        user.refresh_from_db()
        self.assertTrue(user.check_password(self.password))

    def test_local_verification_command_is_disabled_outside_debug_sqlite(self):
        # Verify safety gate independently; normal test DB may use SQLite in memory.
        from io import StringIO
        from django.core.management import call_command
        from django.core.management.base import CommandError
        with override_settings(DEBUG=False):
            with self.assertRaises(CommandError):
                call_command('local_verification_link', username='noone', stdout=StringIO())

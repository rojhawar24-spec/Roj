"""Support 13 reusable, authored activities without modifying existing exercises."""
from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [('academy','0013_onboarding_required_solar')]
    operations = [
        migrations.AlterField(model_name='exercise',name='kind',
            field=models.CharField(max_length=24,default='mcq',choices=[
                ('mcq','Multiple Choice'),('short','Short answer'),
                ('sentence_builder','Sentence Builder'),('picture_match','Picture Match'),
                ('fill_blank','Fill in the Blank'),('word_matching','Word Matching'),
                ('listening','Listening Challenge'),('true_false','True or False'),
                ('spelling','Spelling Challenge'),('word_order','Word Order'),
                ('find_mistake','Find the Mistake'),('memory_match','Memory Match'),
                ('choose_image','Choose the Image'),('complete_conversation','Complete the Conversation'),
            ])),
        migrations.AlterField(model_name='exercise',name='answer',field=models.CharField(max_length=300,blank=True)),
        migrations.AddField(model_name='exercise',name='activity_data',field=models.JSONField(default=dict,blank=True,
            help_text='V58: type-specific authored data; see editor guidance. No learner answers stored here.')),
    ]

# LinguaMaster 0.3.0: additive app-experience migration, preserves existing records.
from django.conf import settings
from django.db import migrations, models
from django.utils import timezone
from django.core.validators import MinValueValidator, MaxValueValidator
import django.db.models.deletion

class Migration(migrations.Migration):
    dependencies=[('academy','0001_initial'), migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations=[
        migrations.AddField(model_name='profile',name='ui_language',field=models.CharField(max_length=3,choices=[('en','English'),('nl','Nederlands'),('ckb','کوردی (سۆرانی)'),('ar','العربية')],default='en')),
        migrations.AddField(model_name='profile',name='daily_goal_xp',field=models.PositiveSmallIntegerField(choices=[(10,'Casual · 10 XP'),(20,'Regular · 20 XP'),(35,'Serious · 35 XP'),(50,'Intense · 50 XP')],default=20)),
        migrations.AddField(model_name='profile',name='mfa_recovery_hashes',field=models.JSONField(default=list,blank=True)),
        migrations.AddField(model_name='profile',name='onboarding_completed',field=models.BooleanField(default=False)),
        migrations.CreateModel(name='XPEvent',fields=[
            ('id',models.BigAutoField(primary_key=True,serialize=False,auto_created=True,verbose_name='ID')),
            ('reason',models.CharField(max_length=24)),
            ('amount',models.PositiveSmallIntegerField(validators=[MinValueValidator(1),MaxValueValidator(250)])),
            ('event_key',models.CharField(max_length=100,unique=True)),
            ('created_at',models.DateTimeField(default=timezone.now)),
            ('user',models.ForeignKey(to=settings.AUTH_USER_MODEL,on_delete=django.db.models.deletion.CASCADE,related_name='xp_events'))
        ]),
        migrations.CreateModel(name='MistakeRecord',fields=[
            ('id',models.BigAutoField(primary_key=True,serialize=False,auto_created=True,verbose_name='ID')),
            ('wrong_count',models.PositiveIntegerField(default=1)),
            ('corrected_at',models.DateTimeField(null=True,blank=True)),
            ('last_wrong_at',models.DateTimeField(default=timezone.now)),
            ('exercise',models.ForeignKey(to='academy.exercise',on_delete=django.db.models.deletion.CASCADE)),
            ('user',models.ForeignKey(to=settings.AUTH_USER_MODEL,on_delete=django.db.models.deletion.CASCADE,related_name='mistakes'))
        ]),
        migrations.CreateModel(name='ArenaRun',fields=[
            ('id',models.BigAutoField(primary_key=True,serialize=False,auto_created=True,verbose_name='ID')),
            ('started_at',models.DateTimeField(default=timezone.now)),
            ('deadline',models.DateTimeField()),
            ('finished_at',models.DateTimeField(null=True,blank=True)),
            ('question_ids',models.JSONField(default=list)),
            ('responses',models.JSONField(default=dict)),
            ('score',models.PositiveSmallIntegerField(default=0)),
            ('earned_xp',models.PositiveSmallIntegerField(default=0)),
            ('level',models.ForeignKey(to='academy.level',on_delete=django.db.models.deletion.CASCADE)),
            ('user',models.ForeignKey(to=settings.AUTH_USER_MODEL,on_delete=django.db.models.deletion.CASCADE,related_name='arena_runs'))
        ]),
        migrations.CreateModel(name='DailyChest',fields=[
            ('id',models.BigAutoField(primary_key=True,serialize=False,auto_created=True,verbose_name='ID')),
            ('day',models.DateField()),
            ('bonus_xp',models.PositiveSmallIntegerField(default=10)),
            ('opened_at',models.DateTimeField(default=timezone.now)),
            ('user',models.ForeignKey(to=settings.AUTH_USER_MODEL,on_delete=django.db.models.deletion.CASCADE,related_name='daily_chests'))
        ]),
        migrations.CreateModel(name='AppNotification',fields=[
            ('id',models.BigAutoField(primary_key=True,serialize=False,auto_created=True,verbose_name='ID')),
            ('event_key',models.CharField(max_length=120,unique=True)),
            ('title',models.CharField(max_length=100)),
            ('message',models.CharField(max_length=260)),
            ('created_at',models.DateTimeField(default=timezone.now)),
            ('read_at',models.DateTimeField(null=True,blank=True)),
            ('user',models.ForeignKey(to=settings.AUTH_USER_MODEL,on_delete=django.db.models.deletion.CASCADE,related_name='notifications'))
        ],options={'ordering':['-created_at']}),
        migrations.AddIndex(model_name='xpevent',index=models.Index(fields=['user','created_at'],name='xpevent_user_date_idx')),
        migrations.AddIndex(model_name='mistakerecord',index=models.Index(fields=['user','corrected_at'],name='mistake_user_open_idx')),
        migrations.AddIndex(model_name='arenarun',index=models.Index(fields=['user','started_at'],name='arena_user_date_idx')),
        migrations.AddConstraint(model_name='mistakerecord',constraint=models.UniqueConstraint(fields=['user','exercise'],name='one_mistake_per_exercise')),
        migrations.AddConstraint(model_name='dailychest',constraint=models.UniqueConstraint(fields=['user','day'],name='one_daily_chest')),
    ]

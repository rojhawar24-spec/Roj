from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [('academy', '0015_daily_word_calendar_v73')]
    operations = [migrations.AlterField(model_name='profile', name='ui_language', field=models.CharField(max_length=3, default='en', choices=[('nl','Nederlands'),('en','English'),('ckb','کوردی سۆرانی'),('kmr','کوردی بادینی'),('uk','Українська'),('ar','العربية'),('fr','Français')]))]

"""V73: additive daily-word assignment and weekly practice state; no old data changed."""
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone


class Migration(migrations.Migration):
    dependencies = [
        ('academy', '0014_exercise_activities_v58'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.CreateModel(
            name='DailyWordEntry',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('day', models.DateField()),
                ('cycle', models.PositiveIntegerField(default=1)),
                ('word_text', models.CharField(max_length=120, default='')),
                ('meaning_text', models.CharField(max_length=200, default='')),
                ('example_text', models.TextField(blank=True, default='')),
                ('pronunciation_text', models.CharField(max_length=200, blank=True, default='')),
                ('emoji_text', models.CharField(max_length=8, default='📖')),
                ('first_seen_at', models.DateTimeField(default=django.utils.timezone.now)),
                ('completed_at', models.DateTimeField(null=True, blank=True)),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='daily_word_entries', to=settings.AUTH_USER_MODEL)),
                ('course', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='daily_word_entries', to='academy.language')),
                ('vocabulary', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='daily_assignments', to='academy.vocabulary')),
            ],
        ),
        migrations.AddConstraint(model_name='dailywordentry', constraint=models.UniqueConstraint(fields=('user', 'course', 'day'), name='unique_daily_word_course_day')),
        migrations.AddIndex(model_name='dailywordentry', index=models.Index(fields=['user', 'course', 'day'], name='daily_word_user_week_idx')),
        migrations.CreateModel(
            name='DailyWordWeeklySession',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('week_start', models.DateField()),
                ('items', models.JSONField(default=list)),
                ('position', models.PositiveSmallIntegerField(default=0)),
                ('completed_at', models.DateTimeField(null=True, blank=True)),
                ('created_at', models.DateTimeField(default=django.utils.timezone.now)),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='daily_weekly_sessions', to=settings.AUTH_USER_MODEL)),
                ('course', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='daily_weekly_sessions', to='academy.language')),
            ],
        ),
        migrations.AddConstraint(model_name='dailywordweeklysession', constraint=models.UniqueConstraint(fields=('user', 'course', 'week_start'), name='unique_daily_weekly_session')),
    ]

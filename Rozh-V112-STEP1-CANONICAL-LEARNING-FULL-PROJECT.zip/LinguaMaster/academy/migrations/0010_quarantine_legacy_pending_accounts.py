"""Fail closed for unclassifiable historical accounts left by migration 0009.

Before 0009, is_active=False was shared between *email pending* and *owner
blocked*. If audit events have expired, the original reason is unknowable.
Quarantine every existing inactive, unverified, unsuspended account at upgrade
and allow an owner to review it individually. New registrations made AFTER
this migration are not quarantined (model field default=False).

No user is activated, no existing suspension is erased, and no data is deleted.
"""
from django.db import migrations, models


def quarantine_existing_ambiguous_accounts(apps, schema_editor):
    Profile = apps.get_model('academy', 'Profile')
    alias = schema_editor.connection.alias
    Profile.objects.using(alias).filter(
        user__is_active=False,
        email_verified_at__isnull=True,
        suspended_at__isnull=True,
    ).update(legacy_review_required=True)


class Migration(migrations.Migration):
    dependencies = [('academy', '0009_account_suspension_state')]
    operations = [
        migrations.AddField('profile', 'legacy_review_required',
                            models.BooleanField(default=False)),
        migrations.AddField('profile', 'email_verification_version',
                            models.PositiveIntegerField(default=0)),
        # Irreversible by design: rolling back would drop quarantine state and
        # could re-open a historical manager suspension bypass.
        migrations.RunPython(quarantine_existing_ambiguous_accounts),
    ]

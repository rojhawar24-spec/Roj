"""Additive account-scoped onboarding draft; does not modify existing profiles."""
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [
        ('academy', '0011_rozh_editorial_seasons'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.CreateModel(
            name='OnboardingDraft',
            fields=[
                ('id', models.BigAutoField(primary_key=True, serialize=False)),
                ('step', models.PositiveSmallIntegerField(default=1)),
                ('ui_language', models.CharField(blank=True, default='', max_length=3)),
                ('start_choice', models.CharField(blank=True, default='', max_length=12)),
                ('daily_goal_xp', models.PositiveSmallIntegerField(blank=True, null=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('preferred_language', models.ForeignKey(blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL, to='academy.language')),
                ('user', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE,
                    related_name='onboarding_draft', to=settings.AUTH_USER_MODEL)),
            ],
        ),
    ]

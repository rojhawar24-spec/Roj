"""Additive opt-in onboarding flag: no data backfill, reversible schema change.

All historical profiles retain onboarding_completed and default required=False.
Only registrations created after this migration set required=True in the view.
"""
from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [('academy', '0012_onboarding_draft_v52')]
    operations = [
        migrations.AddField(
            model_name='profile', name='onboarding_required',
            field=models.BooleanField(default=False),
        ),
    ]

# LinguaMaster V14 — additive season rewards; existing XP and accounts unchanged.
from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone


class Migration(migrations.Migration):
    dependencies = [
        ('academy', '0006_learning_studio_v10'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.AddField(
            model_name='profile',
            name='coins',
            field=models.PositiveIntegerField(default=0),
        ),
        migrations.CreateModel(
            name='SeasonGift',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('enabled', models.BooleanField(default=True)),
                ('emoji', models.CharField(default='🎁', max_length=8)),
                ('bonus_xp', models.PositiveSmallIntegerField(default=50, validators=[MaxValueValidator(250)])),
                ('bonus_coins', models.PositiveIntegerField(default=100, validators=[MaxValueValidator(5000)])),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('level', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE,
                                               related_name='season_gift', to='academy.level')),
            ],
        ),
        migrations.CreateModel(
            name='SeasonGiftClaim',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('xp_awarded', models.PositiveSmallIntegerField(default=0)),
                ('coins_awarded', models.PositiveIntegerField(default=0)),
                ('claimed_at', models.DateTimeField(default=django.utils.timezone.now)),
                ('level', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT,
                                            related_name='season_gift_claims', to='academy.level')),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,
                                           related_name='season_gifts_claimed', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'constraints': [models.UniqueConstraint(fields=('user','level'), name='one_season_gift_claim')],
                'indexes': [models.Index(fields=['user','claimed_at'], name='season_gift_claim_usr_idx')],
            },
        ),
        migrations.CreateModel(
            name='CoinEvent',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('key', models.CharField(max_length=100)),
                ('amount', models.PositiveIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5000)])),
                ('reason', models.CharField(default='season', max_length=24)),
                ('created_at', models.DateTimeField(default=django.utils.timezone.now)),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,
                                           related_name='coin_events', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'constraints': [models.UniqueConstraint(fields=('user','key'), name='unique_coin_event_per_user')],
                'indexes': [models.Index(fields=['user','created_at'], name='coin_event_user_date_idx')],
            },
        ),
    ]

from django.db import migrations, models
import academy.auth_security


def encrypt_existing_seeds(apps, schema_editor):
    Profile = apps.get_model('academy', 'Profile')
    # MigrationExecutor may target a non-default database. Using the implicit
    # 'default' alias here could read or mutate live production MFA material.
    alias = schema_editor.connection.alias
    # Historical models carry a plain field; direct update avoids calling save hooks.
    for profile in Profile.objects.using(alias).exclude(totp_secret='').iterator(chunk_size=250):
        encrypted = academy.auth_security.encrypt_totp(profile.totp_secret)
        Profile.objects.using(alias).filter(pk=profile.pk).update(totp_secret=encrypted)


class Migration(migrations.Migration):
    dependencies = [('academy', '0007_season_rewards_v14')]
    operations = [
        migrations.AlterField(model_name='profile', name='totp_secret',
                              field=academy.auth_security.EncryptedTOTPField(blank=True, max_length=255)),
        migrations.AddField(model_name='profile', name='mfa_last_totp_step',
                            field=models.BigIntegerField(default=-1)),
        migrations.RunPython(encrypt_existing_seeds, migrations.RunPython.noop),
    ]

"""Step 3H additive round ledger. No previous learner records rewritten."""
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone


class Migration(migrations.Migration):
    dependencies = [
        ('academy', '0018_smart_placement_v77'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.CreateModel(
            name='LessonRoundReceipt',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True,
                                           serialize=False, verbose_name='ID')),
                ('round_key', models.CharField(max_length=32)),
                ('channel', models.CharField(max_length=4, choices=[
                    ('ajax', 'Question by question'), ('ssr', 'Complete form')])),
                ('answers', models.JSONField(default=dict, blank=True)),
                ('score', models.PositiveSmallIntegerField(null=True, blank=True)),
                ('finished_at', models.DateTimeField(null=True, blank=True)),
                ('created_at', models.DateTimeField(default=django.utils.timezone.now)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('lesson', models.ForeignKey(to='academy.lesson',
                    on_delete=django.db.models.deletion.CASCADE, related_name='round_receipts')),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL,
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='lesson_round_receipts')),
            ],
        ),
        migrations.AddConstraint(
            model_name='lessonroundreceipt',
            constraint=models.UniqueConstraint(fields=('user','lesson','round_key'),
                                               name='one_lesson_round_receipt_step3h')),
    ]

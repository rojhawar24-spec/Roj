"""Align the historical self-relation migration state without touching user data.

Existing installs have the academy_unit_prerequisites join table and its
rows already. A Django migration autodetector pass under Django 6.1.3
requests RemoveField + AddField for this relation. These operations are
intentionally confined to PROJECT STATE: no database schema operation
executes, and no existing prerequisite edge is deleted or recreated.

This migration must NOT be converted to database RemoveField/AddField.
"""
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [('academy', '0003_skill_practice')]

    operations = [
        migrations.SeparateDatabaseAndState(
            database_operations=[],
            state_operations=[
                migrations.RemoveField(model_name='unit', name='prerequisites'),
                migrations.AddField(
                    model_name='unit',
                    name='prerequisites',
                    field=models.ManyToManyField(to='academy.unit', blank=True, symmetrical=False),
                ),
            ],
        ),
    ]

"""Preserve known legacy suspensions without activating a single account.

Legacy is_active=False represented both pending verification and manager blocks.
We can prove suspension for inactive+previously-verified accounts or when an
unresolved manager user_block audit event exists. The state of other old inactive
accounts is unknowable without operator review; retain inactive state.
"""
from django.db import migrations, models
from django.utils import timezone


def classify_legacy_inactive(apps, schema_editor):
    User = apps.get_model('auth', 'User')
    Profile = apps.get_model('academy', 'Profile')
    AuditEvent = apps.get_model('academy', 'AuditEvent')
    # Never query the default database when applying this migration to an
    # isolated alias: reading/updating user suspension state is sensitive.
    alias = schema_editor.connection.alias
    # Read the latest recorded owner action for each target. Manager block
    # audit records may be retained for less than the lifetime of an account.
    last_action = {}
    for event in AuditEvent.objects.using(alias).filter(action__in=('user_block', 'user_unblock')).order_by('created_at', 'pk').iterator():
        last_action[event.target] = event.action
    stamp = timezone.now()
    for user in User.objects.using(alias).filter(is_active=False).iterator():
        try:
            profile = Profile.objects.using(alias).get(user_id=user.pk)
        except Profile.DoesNotExist:
            continue
        verified = profile.email_verified_at is not None
        audited_block = last_action.get(str(user.pk)) == 'user_block'
        if verified or audited_block:
            Profile.objects.using(alias).filter(pk=profile.pk).update(
                suspended_at=stamp,
                suspended_was_active=verified,
            )


class Migration(migrations.Migration):
    dependencies = [('academy', '0008_secure_login_mfa')]
    operations = [
        migrations.AddField('profile', 'suspended_at', models.DateTimeField(null=True, blank=True)),
        migrations.AddField('profile', 'suspended_was_active', models.BooleanField(default=False)),
        migrations.RunPython(classify_legacy_inactive, migrations.RunPython.noop),
    ]

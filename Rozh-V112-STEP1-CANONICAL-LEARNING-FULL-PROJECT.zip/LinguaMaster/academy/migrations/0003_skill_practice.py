from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
import django.core.validators
import django.utils.timezone

class Migration(migrations.Migration):
    dependencies = [('academy', '0002_app_progress'), migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations = [
        migrations.CreateModel(name='SkillPracticeAttempt', fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
            ('kind', models.CharField(choices=[('speaking','Speaking'),('writing','Writing')], max_length=8)),
            ('score', models.PositiveSmallIntegerField(validators=[django.core.validators.MinValueValidator(0),django.core.validators.MaxValueValidator(100)])),
            ('input_method', models.CharField(choices=[('microphone','Browser recognition'),('typed','Typed text')], default='typed', max_length=10)),
            ('answer_length', models.PositiveSmallIntegerField(default=0)),
            ('created_at', models.DateTimeField(default=django.utils.timezone.now)),
            ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='skill_attempts', to=settings.AUTH_USER_MODEL)),
            ('vocabulary', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to='academy.vocabulary')),
        ], options={'indexes': [models.Index(fields=['user','created_at'], name='skill_practice_usr_dt_idx')]}),
    ]

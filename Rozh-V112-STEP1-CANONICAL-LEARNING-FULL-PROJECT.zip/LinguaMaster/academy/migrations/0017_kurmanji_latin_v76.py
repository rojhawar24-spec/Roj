from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [('academy', '0016_seven_interface_languages_v74')]
    operations = [migrations.AlterField(model_name='profile', name='ui_language', field=models.CharField(max_length=3, default='en', choices=[('nl','Nederlands'),('en','English'),('ckb','کوردی سۆرانی'),('kmr','کوردی بادینی'),('ku','Kurmancî'),('uk','Українська'),('ar','العربية'),('fr','Français')]))]

"""Additive placement infrastructure. No existing account/course data rewritten."""
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone

STAGES = [('A0','A0 · Pre-A1'),('A1','A1'),('A2','A2'),('B1','B1'),('B2','B2'),('C1','C1')]
SKILLS = [('reading','Reading comprehension'),('listening','Listening comprehension'),
          ('grammar','Grammar in context'),('vocabulary','Vocabulary in context'),
          ('writing','Controlled short written answer')]

class Migration(migrations.Migration):
    dependencies = [
        ('academy', '0017_kurmanji_latin_v76'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]
    operations = [
        migrations.CreateModel(
            name='PlacementBankItem',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('stage', models.CharField(max_length=2, choices=STAGES)),
                ('skill', models.CharField(max_length=12, choices=SKILLS)),
                ('prompt', models.TextField()),
                ('stimulus', models.TextField(blank=True, default='')),
                ('audio_path', models.CharField(max_length=180, blank=True, default='', help_text='Listening only: academy/placement-audio/example.mp3 (self-hosted static file).')),
                ('options', models.JSONField(default=list, blank=True)),
                ('answer', models.CharField(max_length=300, blank=True, default='')),
                ('accepted_answers', models.JSONField(default=list, blank=True, help_text='Only controlled writing; a list of reviewed exact acceptable answers.')),
                ('source_reference', models.CharField(max_length=250, blank=True, default='', help_text='Educator/copyright-safe source and objective.')),
                ('educator_reviewed', models.BooleanField(default=False)),
                ('published', models.BooleanField(default=False)),
                ('content_version', models.PositiveIntegerField(default=1)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('course', models.ForeignKey(to='academy.language', on_delete=django.db.models.deletion.CASCADE, related_name='placement_bank_items')),
            ],
            options={'ordering': ('course_id','stage','skill','pk')},
        ),
        migrations.CreateModel(
            name='PlacementRun',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('status', models.CharField(max_length=10, choices=[('active','In progress'),('ready','Awaiting learner choice'),('confirmed','Confirmed')], default='active')),
                ('history', models.JSONField(default=list)),
                ('current_item_id', models.PositiveIntegerField(null=True, blank=True)),
                ('current_version', models.PositiveIntegerField(default=0)),
                ('current_digest', models.CharField(max_length=64, blank=True, default='')),
                ('result', models.JSONField(default=dict)),
                ('chosen_level', models.CharField(max_length=2, blank=True, default='', choices=STAGES)),
                ('created_at', models.DateTimeField(default=django.utils.timezone.now)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL, on_delete=django.db.models.deletion.CASCADE, related_name='smart_placement_runs')),
                ('course', models.ForeignKey(to='academy.language', on_delete=django.db.models.deletion.CASCADE, related_name='smart_placement_runs')),
            ],
        ),
        migrations.AddIndex('placementbankitem', models.Index(fields=['course','published','stage','skill'], name='placement_bank_filter_v77')),
        migrations.AddIndex('placementrun', models.Index(fields=['user','status'], name='placement_run_user_v77')),
        migrations.AddConstraint('placementrun', models.UniqueConstraint(fields=('user','course'), name='one_smart_placement_run_v77')),
    ]

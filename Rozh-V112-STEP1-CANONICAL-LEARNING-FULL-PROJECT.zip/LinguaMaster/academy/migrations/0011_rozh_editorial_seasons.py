"""Optional, additive learning seasons; old course and progress data are untouched."""
from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    dependencies = [('academy','0010_quarantine_legacy_pending_accounts')]
    operations = [
        migrations.CreateModel(name='LearningSeason', fields=[
            ('id', models.BigAutoField(primary_key=True, serialize=False)),
            ('slug', models.SlugField(max_length=100)),
            ('title', models.CharField(max_length=140)),
            ('description', models.CharField(blank=True, max_length=240)),
            ('order', models.PositiveIntegerField(default=0)),
            ('theme', models.CharField(choices=[('coast','Coast'),('grove','Grove'),('dawn','Dawn'),('sky','Sky')], default='coast', max_length=12)),
            ('published', models.BooleanField(default=False)),
            ('created_at', models.DateTimeField(auto_now_add=True)),
            ('level', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='rozh_seasons', to='academy.level')),
        ], options={'ordering': ('level__language_id','level__order','order','pk')}),
        migrations.AddField(model_name='unit', name='season', field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='units', to='academy.learningseason')),
        migrations.AddField(model_name='vocabulary', name='word_family', field=models.CharField(max_length=300, blank=True)),
        migrations.AddField(model_name='vocabulary', name='usage_notes', field=models.TextField(blank=True)),
        migrations.AddConstraint(model_name='learningseason', constraint=models.UniqueConstraint(fields=('level','slug'), name='unique_rozh_level_season_slug')),
    ]

"""V79: Manager AI control and code-vs-content readiness. No seeded data."""
from collections import OrderedDict
from datetime import timedelta
from django.conf import settings
from django.contrib import messages
from django.db import transaction
from django.db.models import Count
from django.shortcuts import redirect, render
from django.utils import timezone
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods
from .manager_roles_v48 import manager_only
from .manager_i18n_v47 import for_user
from .models import PlatformSettings, AIUsage, AuditEvent, Exercise, Lesson, GrammarTopic, Language
from .forms import AIConfigurationForm
from .manager_content_v48 import ManagerAIToggleForm
from .grammar_components_v57 import COMPONENT_CATALOG
from .lesson_activities_v58 import KINDS
from .grammar_rich_models import GrammarArticle
from .audio_v78 import _CATALOG_FILE
import hashlib
import re
import json


def _model_ai_form(user):
    return AIConfigurationForm if user.is_superuser else ManagerAIToggleForm


def _save_ai(request):
    """Same row lock and restricted update_fields as the V48 manager dashboard."""
    klass = _model_ai_form(request.user)
    with transaction.atomic():
        base = PlatformSettings.load()
        config = PlatformSettings.objects.select_for_update().get(pk=base.pk)
        form = klass(request.POST, instance=config)
        fields = tuple(form.fields)
        before = {field: getattr(config,field) for field in fields}
        if form.is_valid():
            obj = form.save(commit=False)
            changes = [name for name in fields if before[name] != getattr(obj,name)]
            obj.save(update_fields=[*fields,'updated_at'])
            AuditEvent.objects.create(actor=request.user,action='platform_settings_updated',
                target='settings',metadata={'changed_fields':changes,'source':'manager_ai_v79',
                'old_ai':[before.get('ai_enabled'),before.get('ai_emergency_stop')],
                'new_ai':[obj.ai_enabled,obj.ai_emergency_stop]})
            messages.success(request, 'AI-instellingen opgeslagen. Controleer de live-status hieronder.')
            return None
        return form


@never_cache
@manager_only
@require_http_methods(['GET','POST'])
def manager_ai(request):
    if request.method == 'POST':
        form = _save_ai(request)
        if form is None:
            return redirect('manager_ai_v79')
    else:
        form = _model_ai_form(request.user)(instance=PlatformSettings.load())
    config = PlatformSettings.load()
    since = timezone.now()-timedelta(days=30)
    usage = AIUsage.objects.filter(created_at__gte=since)
    configured = bool(settings.AI_API_KEY)
    enabled = bool(config.ai_enabled and not config.ai_emergency_stop)
    # Wallet, consent, safety, moderation and account eligibility remain
    # individually enforced by the actual AI service on every request.
    checks = [
        {'ok': configured, 'label': 'Providercredential aanwezig',
         'detail': 'Alleen aanwezigheid gecontroleerd; er worden geen geheimen of API-sleutels getoond.'},
        {'ok': bool(config.ai_enabled), 'label': 'AI Teacher toegestaan door Manager',
         'detail': 'De hoofdschakelaar staat aan of uit; geen leerlingchat in dit scherm.'},
        {'ok': not config.ai_emergency_stop, 'label': 'Noodstop uitgeschakeld',
         'detail': 'Een actieve noodstop blokkeert elke nieuwe AI-aanvraag.'},
        {'ok': config.ai_monthly_budget_eur > 0, 'label': 'Positief maandbudget ingesteld',
         'detail': 'Kostenlimiet voor de bestaande externe AI-provider.'},
        {'ok': config.ai_daily_limit > 0 and config.ai_monthly_limit > 0,
         'label': 'Dag- en maandlimieten ingesteld',
         'detail': 'De AI-dienst controleert de limieten bij iedere leerlingaanvraag.'},
    ]
    ready = all(check['ok'] for check in checks)
    return render(request,'academy/manager_ai_v79.html',{
        **for_user(request.user),'form':form,'config':config,
        'ai_key_configured':configured,'ai_enabled_now':enabled,
        'ai_preconditions':ready, 'ai_checks':checks, 'usage_30d':usage.count(),
        'usage_failed_30d':usage.filter(status__in=['error','blocked']).count(),
        'usage_success_30d':usage.filter(status='ok').count(),
        'R48_OWNER':request.user.is_superuser})


@never_cache
@manager_only
@require_http_methods(['GET'])
def readiness(request):
    group_catalog=OrderedDict()
    for key,label,layout,group in COMPONENT_CATALOG:
        group_catalog.setdefault(group,[]).append({'key':key,'label':label,'layout':layout})
    counts=dict(Exercise.objects.values('kind').annotate(total=Count('pk')).values_list('kind','total'))
    published_exercises_all = Exercise.objects.filter(
        lesson__published=True, lesson__unit__published=True,
        lesson__unit__level__language__is_published=True)
    public_counts=dict(published_exercises_all.values('kind').annotate(total=Count('pk')).values_list('kind','total'))
    # Only count the 13 declared types. Legacy `short` is not a fourteenth game.
    kinds=[{'key':key,'label':label,'total':counts.get(key,0),
            'published':public_counts.get(key,0),
            'unpublished':counts.get(key,0)-public_counts.get(key,0)}
           for key,label in KINDS]
    try:
        catalog=json.loads(_CATALOG_FILE.read_text(encoding='utf-8'))
        # Never count a mere catalog entry as playable audio. Verify published
        # file bytes and review state; this does not replace listening QA.
        audio_entries = 0
        clips = catalog.get('clips', {})
        if isinstance(clips, dict):
            for entry in clips.values():
                if (not isinstance(entry,dict) or entry.get('reviewed') is not True
                        or entry.get('audio_quality_review_required') is not False):
                    continue
                path = entry.get('path','')
                if not isinstance(path,str) or not re.fullmatch(r'academy/audio-v78/clips/(?:nl|en|de|fr|uk|ar|ckb|kmr|ku)/[a-f0-9]{64}\.(?:mp3|wav)',path):
                    continue
                from django.contrib.staticfiles import finders
                located = finders.find(path)
                if located and isinstance(located,str):
                    digest=hashlib.sha256()
                    with open(located,'rb') as handle:
                        for chunk in iter(lambda:handle.read(1<<20),b''):
                            digest.update(chunk)
                    if digest.hexdigest() == entry.get('sha256'):
                        audio_entries += 1
    except (ValueError,OSError,TypeError):
        audio_entries=0
    # These are actual currently published listening items, not registered types.
    from .audio_v78 import approved_audio_url
    listening_missing = 0
    published_listening_lessons = Lesson.objects.filter(
        published=True, skill='listening', unit__published=True,
        unit__level__language__is_published=True
    ).select_related('unit__level__language')
    for item in published_listening_lessons:
        if not approved_audio_url(item.audio_text, item.unit.level.language.code):
            listening_missing += 1
    for exercise in published_exercises_all.filter(kind='listening').select_related(
            'lesson__unit__level__language'):
        if not approved_audio_url((exercise.activity_data or {}).get('audio_text'),
                                  exercise.lesson.unit.level.language.code):
            listening_missing += 1
    topics=GrammarTopic.objects.count()
    articles=GrammarArticle.objects.count()
    published=GrammarTopic.objects.filter(published=True).count()
    # Counts are sourced from stored rows, never extrapolated from the 13/100 registries.
    # Published lessons need both their Unit and Language published; these counts
    # are not a substitute for pedagogical or end-to-end accessibility checks.
    courses = []
    course_kind_counts = {}
    for code, display in [('nl','Nederlands'),('en','Engels'),('de','Duits'),('fr','Frans')]:
        language = Language.objects.filter(code=code).first()
        if language:
            public = language.is_published
            lessons = Lesson.objects.filter(unit__level__language=language,
                published=True,unit__published=True,unit__level__language__is_published=True)
            published_exercises = Exercise.objects.filter(lesson__in=lessons)
            published_kind_counts = dict(published_exercises.values('kind')
                                        .annotate(total=Count('pk')).values_list('kind','total'))
            course_kind_counts[code] = published_kind_counts
            topics_qs = GrammarTopic.objects.filter(level__language=language,
                published=True,level__language__is_published=True)
            courses.append({'code':code,'label':display,'configured':True,
                'public':public,'lesson_count':lessons.count(),
                'exercise_count':published_exercises.count(),
                'activity_kinds':sum(1 for key,label in KINDS if published_kind_counts.get(key,0)>0),
                'grammar_count':topics_qs.count(),
                'rich_articles':GrammarArticle.objects.filter(topic__in=topics_qs).count()})
        else:
            courses.append({'code':code,'label':display,'configured':False,
                'public':False,'lesson_count':0,'exercise_count':0,
                'activity_kinds':0,'grammar_count':0,'rich_articles':0})
            course_kind_counts[code] = {}
    kind_matrix = [{ 'key':key, 'label':label, 'nl':course_kind_counts['nl'].get(key,0),
                     'en':course_kind_counts['en'].get(key,0),
                     'de':course_kind_counts['de'].get(key,0),
                     'fr':course_kind_counts['fr'].get(key,0)} for key,label in KINDS]
    return render(request,'academy/manager_readiness_v79.html',{ 
        **for_user(request.user),'course_readiness':courses,'grammar_groups':group_catalog.items(),
        'grammar_component_count':len(COMPONENT_CATALOG), 'activity_types':kinds,
        'activity_matrix':kind_matrix,
        'activity_types_count':len(KINDS),'grammar_topic_count':topics,
        'grammar_published_count':published,'grammar_article_count':articles,
        'exercise_count':Exercise.objects.count(),
        'lesson_count':Lesson.objects.count(),
        'lesson_published_count':Lesson.objects.filter(published=True).count(),
        'audio_catalog_entries':audio_entries, 'published_listening_missing_audio':listening_missing})

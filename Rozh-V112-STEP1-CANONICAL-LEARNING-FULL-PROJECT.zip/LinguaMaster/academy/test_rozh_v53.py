"""V53 Django integration tests: temporary Django test database only; not run in source environment."""
from django.contrib.auth import get_user_model
from django.test import Client, TestCase
from django.urls import reverse
from .models import Language, Level, Unit, Lesson, LessonProgress, XPEvent


class V53StudentLearningPathTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user('v53_learner','v53@example.invalid','Test password 2026, unique.')
        language = Language.objects.create(code='en',name='English',slug='v53-eng',description='',is_published=True)
        level = Level.objects.create(language=language,code='A0',order=0,description='Start')
        cls.unit = Unit.objects.create(level=level,slug='introductions-with-be',title='Hello — introduce yourself',summary='Greet',order=1,published=True)
        cls.first = Lesson.objects.create(unit=cls.unit,slug='grammar',title='Grammar 1',skill='grammar',content='Hello',order=1,published=True)
        cls.second = Lesson.objects.create(unit=cls.unit,slug='reading',title='Reading 2',skill='reading',content='Hello',order=2,published=True)
        profile = cls.user.learning_profile
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.preferred_language = language
        profile.ui_language = 'nl'
        profile.save()

    def setUp(self):
        self.client.force_login(self.user)

    def test_one_path_uses_real_published_lesson_count(self):
        response = self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'r53-journey')
        self.assertContains(response,'0 / 2')
        self.assertContains(response,'Hallo — stel jezelf voor')
        self.assertContains(response,'class="r27-node r53-node ',count=2)
        self.assertContains(response,reverse('journey_play',args=[self.unit.pk]))
        self.assertEqual(LessonProgress.objects.filter(user=self.user).count(),0)
        self.assertEqual(XPEvent.objects.filter(user=self.user).count(),0)

    def test_unpublished_lesson_not_shown_or_counted(self):
        Lesson.objects.create(unit=self.unit,slug='private',title='Hidden',skill='writing',content='Hidden',published=False)
        response=self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code,200)
        self.assertNotContains(response,'Hidden')
        self.assertContains(response,'0 / 2')

    def test_locked_lesson_never_gets_href(self):
        later=Unit.objects.create(level=self.unit.level,slug='v53-locked',title='Private locked step',summary='Later',order=2,published=True)
        later.prerequisites.add(self.unit)
        blocked=Lesson.objects.create(unit=later,slug='later',title='Locked lesson',skill='reading',content='Later',published=True)
        response=self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'r53-node-locked')
        self.assertNotContains(response,reverse('lesson',args=[blocked.pk]))
        self.assertNotContains(response,reverse('journey_play',args=[later.pk]))

    def test_four_ui_languages_render_without_fake_fallback_content(self):
        profile=self.user.learning_profile
        for locale in ('en','nl','ckb','ar'):
            profile.ui_language=locale
            profile.save(update_fields=['ui_language'])
            response=self.client.get(reverse('play_hub'))
            self.assertEqual(response.status_code,200,locale)
            self.assertContains(response,'r53-season')
            self.assertContains(response,f'lang="{locale}"')
            self.assertContains(response,'dir="rtl"' if locale in ('ckb','ar') else 'dir="ltr"')

    def test_no_login_bypass(self):
        self.client.logout()
        response=self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code,302)
        self.assertIn(reverse('login'),response['Location'])


class UIChangeSecurityTests(TestCase):
    """Runs with Django + disposable test DB, not with the offline suite."""
    def setUp(self):
        self.user=get_user_model().objects.create_user('switch_account','switch@example.invalid',
                      'Unique password 2026!')
        self.profile=self.user.learning_profile
        self.client.force_login(self.user)

    def test_switch_four_locales_without_changing_course_or_progress(self):
        before=(self.profile.xp, self.profile.preferred_language_id)
        for locale in ('nl','en','ckb','ar'):
            with self.subTest(locale=locale):
                response=self.client.post(reverse('switch_ui_language'),{'ui_language':locale})
                self.assertRedirects(response,reverse('play_hub'), fetch_redirect_response=False)
                self.profile.refresh_from_db()
                self.assertEqual(self.profile.ui_language,locale)
                self.assertEqual((self.profile.xp,self.profile.preferred_language_id),before)

    def test_get_cannot_mutate_and_invalid_language_returns_400(self):
        initial=self.profile.ui_language
        self.assertEqual(self.client.get(reverse('switch_ui_language')).status_code,405)
        self.assertEqual(self.client.post(reverse('switch_ui_language'),
                                          {'ui_language':'__proto__'}).status_code,400)
        self.profile.refresh_from_db()
        self.assertEqual(self.profile.ui_language,initial)

    def test_unauthenticated_user_is_redirected_to_login(self):
        self.client.logout()
        response=self.client.post(reverse('switch_ui_language'),{'ui_language':'nl'})
        self.assertEqual(response.status_code,302)
        self.assertIn(reverse('login'),response['Location'])

    def test_csrf_is_required_for_language_write(self):
        protected=Client(enforce_csrf_checks=True)
        protected.force_login(self.user)
        self.assertEqual(protected.post(reverse('switch_ui_language'),
                                        {'ui_language':'nl'}).status_code,403)

"""Django integration coverage for the public V25 homepage.
Run using manage.py test in a disposable Django test database.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse


class HomepageV25Tests(TestCase):
    def test_guest_sees_one_clear_entry_point_and_real_feature_destinations(self):
        response=self.client.get(reverse('home'))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'class="lm23-home lm25-home"')
        self.assertContains(response,'Start Leer &amp; Speel')
        self.assertContains(response,'/login/?next=/play/')
        self.assertContains(response,'href="/grammar/"')
        self.assertContains(response,'/login/?next=/skills/listening/')
        self.assertContains(response,'/try/')
        self.assertContains(response,'home-v31-bundle.css')

    def test_all_public_locales_have_correct_direction(self):
        for locale,direction in [('nl','ltr'),('en','ltr'),('ckb','rtl'),('ar','rtl')]:
            with self.subTest(locale=locale):
                response=self.client.get(reverse('home')+'?ui='+locale, follow=True)
                self.assertEqual(response.status_code,200)
                self.assertContains(response,'lang="'+locale+'"')
                self.assertContains(response,'dir="'+direction+'"')
                self.assertContains(response,'lm25-feature-grid')

    def test_signed_in_returning_learner_skips_marketing_page(self):
        user=get_user_model().objects.create_user('v25returner','v25returner@example.com','StrongPassword!2026')
        profile=user.learning_profile
        profile.onboarding_completed=True
        profile.placement_completed=True
        profile.save(update_fields=['onboarding_completed','placement_completed'])
        self.client.force_login(user)
        response=self.client.get(reverse('home'))
        self.assertRedirects(response,reverse('play_hub'),fetch_redirect_response=False)

    def test_open_redirect_is_rejected_by_login(self):
        for invalid in ('https://attacker.example/path','//attacker.example/'):
            with self.subTest(invalid=invalid):
                response=self.client.get(reverse('login'),{'next':invalid})
                self.assertEqual(response.status_code,200)
                self.assertContains(response,'name="next" value=""')

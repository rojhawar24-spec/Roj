"""Timezone-aware progress summaries and private account preferences."""
import json
from datetime import timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError, available_timezones

from django import forms
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import HttpResponse, JsonResponse
from django.shortcuts import redirect, render
from django.urls import path
from django.utils import timezone
from django.views.decorators.http import require_POST

from .forms import ProfileForm
from .account_signin_policy_v27 import account_signin_permitted
from .safe_profile_context_v46 import visible_learning_profile
from .models import Profile, XPEvent
from .progress_models import LearningPreferences
from .services import (current_streak, learning_day_bounds, rate_limit, user_localdate,
                       user_timezone)

LEARNING_REASONS = ('lesson', 'assessment', 'arena', 'review', 'mistake')

TEXT = {
    'en': {
        'logout_note': 'Sign out securely on this device.',
        'space': 'YOUR SPACE', 'title': 'Profile & preferences',
        'intro': 'Make your learning experience feel like you.', 'settings': 'Learning & privacy',
        'appearance': 'Appearance & daily rhythm', 'timezone_name': 'Your timezone',
        'timezone_help': 'Your XP day and streak use midnight in this timezone.',
        'theme': 'Appearance', 'system': 'Follow device', 'light': 'Light', 'dark': 'Dark',
        'reduce_motion': 'Reduce animations', 'save': 'Save preferences',
        'saved': 'Your preferences are saved.',
        'changed': 'Saved. Choose a new starting level for your new learning language.',
        'security': 'Account security', 'security_note': 'Two-factor authentication protects your account.',
        'enabled': 'Enabled', 'disabled': 'Disabled', 'mfa': 'Two-factor authentication',
        'enable_mfa': 'Enable 2FA', 'disable_mfa': 'Disable 2FA', 'code': 'Current 2FA code',
        'privacy': 'Your data', 'privacy_note': 'You control social visibility, reminders and AI consent.',
        'export': 'Export my learning data', 'delete': 'Delete my account', 'logout': 'Log out',
        'avatar_studio': 'Customize my avatar', 'longest': 'Longest streak', 'streak': 'Current streak',
        'days': 'days', 'xp_level': 'XP level measures activity. Your course level measures learning progress.',
        'avatar': 'Avatar', 'bio': 'About me', 'ui_language': 'App language',
        'daily_goal_xp': 'Daily XP goal', 'preferred_language': 'Language to learn',
        'leaderboard_opt_in': 'Show me in leaderboards', 'social_opt_in': 'Allow friend invitations',
        'reminder_opt_in': 'Email me learning reminders', 'summary_opt_in': 'Email me progress summaries',
        'ai_opt_in': 'Allow my questions to be processed by the external AI teacher',
        'invalid_timezone': 'Choose a valid timezone such as Europe/Brussels or Asia/Baghdad.',
    },
    'nl': {
        'logout_note': 'Log veilig uit op dit apparaat.',
        'space': 'JOUW PLEK', 'title': 'Profiel & voorkeuren',
        'intro': 'Maak je leeromgeving persoonlijk.', 'settings': 'Leren & privacy',
        'appearance': 'Uiterlijk & dagritme', 'timezone_name': 'Jouw tijdzone',
        'timezone_help': 'Je XP-dag en streak gebruiken middernacht in deze tijdzone.',
        'theme': 'Weergave', 'system': 'Volg apparaat', 'light': 'Licht', 'dark': 'Donker',
        'reduce_motion': 'Minder animaties', 'save': 'Voorkeuren opslaan',
        'saved': 'Je voorkeuren zijn opgeslagen.',
        'changed': 'Opgeslagen. Kies een nieuw startniveau voor je nieuwe leertaal.',
        'security': 'Accountbeveiliging', 'security_note': 'Tweestapsverificatie beschermt je account.',
        'enabled': 'Aan', 'disabled': 'Uit', 'mfa': 'Tweestapsverificatie',
        'enable_mfa': '2FA inschakelen', 'disable_mfa': '2FA uitschakelen', 'code': 'Huidige 2FA-code',
        'privacy': 'Jouw gegevens', 'privacy_note': 'Jij kiest voor sociale zichtbaarheid, herinneringen en AI.',
        'export': 'Mijn leergegevens downloaden', 'delete': 'Mijn account verwijderen', 'logout': 'Uitloggen',
        'avatar_studio': 'Mijn avatar aanpassen', 'longest': 'Langste streak', 'streak': 'Huidige streak',
        'days': 'dagen', 'xp_level': 'Je XP-level meet activiteit. Je cursusniveau meet je leervoortgang.',
        'avatar': 'Avatar', 'bio': 'Over mij', 'ui_language': 'App-taal',
        'daily_goal_xp': 'Dagelijks XP-doel', 'preferred_language': 'Taal om te leren',
        'leaderboard_opt_in': 'Toon mij in ranglijsten', 'social_opt_in': 'Vriendschapsverzoeken toestaan',
        'reminder_opt_in': 'Leerherinneringen per e-mail', 'summary_opt_in': 'Voortgangsoverzichten per e-mail',
        'ai_opt_in': 'Mijn vragen laten verwerken door de externe AI-docent',
        'invalid_timezone': 'Kies een geldige tijdzone, zoals Europe/Brussels of Asia/Baghdad.',
    },
    'ckb': {
        'logout_note': 'بە پارێزراوی لەم ئامێرە بچۆ دەرەوە.',
        'space': 'شوێنی تۆ', 'title': 'پرۆفایل و هەڵبژاردەکان',
        'intro': 'ژینگەی فێربوونەکەت بەپێی حەزی خۆت ڕێک بخە.', 'settings': 'فێربوون و تایبەتمەندی',
        'appearance': 'ڕووکار و کاتی ڕۆژانە', 'timezone_name': 'ناوچەی کاتی تۆ',
        'timezone_help': 'ڕۆژی XP و ستریک لە نیوەشەوی ئەم ناوچەیە دەست پێ دەکەن.',
        'theme': 'ڕووکار', 'system': 'بەپێی ئامێر', 'light': 'ڕوون', 'dark': 'تاریک',
        'reduce_motion': 'جووڵەکان کەم بکەوە', 'save': 'هەڵبژاردەکان پاشەکەوت بکە',
        'saved': 'هەڵبژاردەکانت پاشەکەوت کران.',
        'changed': 'پاشەکەوت کرا. بۆ زمانی نوێ ئاستی دەستپێک هەڵبژێرە.',
        'security': 'پاراستنی هەژمار', 'security_note': 'پشتڕاستکردنەوەی دوو هەنگاو هەژمارەکەت دەپارێزێت.',
        'enabled': 'چالاکە', 'disabled': 'ناچالاکە', 'mfa': 'پشتڕاستکردنەوەی دوو هەنگاو',
        'enable_mfa': '٢FA چالاک بکە', 'disable_mfa': '٢FA ناچالاک بکە', 'code': 'کۆدی ئێستای ٢FA',
        'privacy': 'داتاکانی تۆ', 'privacy_note': 'دیاربوون بۆ هاوڕێکان، بیرخستنەوە و AI بە هەڵبژاردەی تۆن.',
        'export': 'داتاکانی فێربوونم دابگرە', 'delete': 'هەژمارەکەم بسڕەوە', 'logout': 'چوونەدەرەوە',
        'avatar_studio': 'ئەڤاتارەکەم بگۆڕە', 'longest': 'درێژترین ستریک', 'streak': 'ستریکی ئێستا',
        'days': 'ڕۆژ', 'xp_level': 'ئاستی XP چالاکی دەپێوێت. ئاستی کۆرس پێشکەوتنی فێربوونت پیشان دەدات.',
        'avatar': 'ئەڤاتار', 'bio': 'دەربارەی من', 'ui_language': 'زمانی ئەپ',
        'daily_goal_xp': 'ئامانجی XPی ڕۆژانە', 'preferred_language': 'زمانی فێربوون',
        'leaderboard_opt_in': 'لە خشتەی پلەبەندی پیشانم بدە', 'social_opt_in': 'ڕێگە بە داواکاریی هاوڕێیەتی بدە',
        'reminder_opt_in': 'بیرخستنەوەی فێربوون بە ئیمەیڵ', 'summary_opt_in': 'پوختەی پێشکەوتن بە ئیمەیڵ',
        'ai_opt_in': 'ڕێگە بدە پرسیارەکانم بۆ مامۆستای AIی دەرەکی بنێردرێن',
        'invalid_timezone': 'ناوچەی کاتی دروست هەڵبژێرە، وەک Europe/Brussels یان Asia/Baghdad.',
    },
    'ar': {
        'logout_note': 'سجل الخروج بأمان من هذا الجهاز.',
        'space': 'مساحتك', 'title': 'الملف الشخصي والتفضيلات',
        'intro': 'اجعل تجربة التعلم مناسبة لك.', 'settings': 'التعلم والخصوصية',
        'appearance': 'المظهر والتوقيت اليومي', 'timezone_name': 'منطقتك الزمنية',
        'timezone_help': 'يبدأ يوم نقاطك وسلسلتك عند منتصف الليل في هذه المنطقة.',
        'theme': 'المظهر', 'system': 'اتبع الجهاز', 'light': 'فاتح', 'dark': 'داكن',
        'reduce_motion': 'تقليل الحركة', 'save': 'حفظ التفضيلات', 'saved': 'تم حفظ تفضيلاتك.',
        'changed': 'تم الحفظ. اختر مستوى بداية جديدا للغة الجديدة.',
        'security': 'أمان الحساب', 'security_note': 'المصادقة الثنائية تحمي حسابك.',
        'enabled': 'مفعلة', 'disabled': 'معطلة', 'mfa': 'المصادقة الثنائية',
        'enable_mfa': 'تفعيل المصادقة الثنائية', 'disable_mfa': 'تعطيل المصادقة الثنائية', 'code': 'رمز المصادقة الحالي',
        'privacy': 'بياناتك', 'privacy_note': 'أنت تتحكم في الظهور الاجتماعي والتذكيرات والموافقة على الذكاء الاصطناعي.',
        'export': 'تنزيل بيانات تعلمي', 'delete': 'حذف حسابي', 'logout': 'تسجيل الخروج',
        'avatar_studio': 'تخصيص صورتي الرمزية', 'longest': 'أطول سلسلة', 'streak': 'السلسلة الحالية',
        'days': 'أيام', 'xp_level': 'مستوى النقاط يقيس النشاط. مستوى الدورة يعكس تقدم التعلم.',
        'avatar': 'الصورة الرمزية', 'bio': 'نبذة عني', 'ui_language': 'لغة التطبيق',
        'daily_goal_xp': 'هدف النقاط اليومي', 'preferred_language': 'لغة التعلم',
        'leaderboard_opt_in': 'إظهاري في لوحة المتصدرين', 'social_opt_in': 'السماح بطلبات الصداقة',
        'reminder_opt_in': 'تذكيرات التعلم بالبريد الإلكتروني', 'summary_opt_in': 'ملخص التقدم بالبريد الإلكتروني',
        'ai_opt_in': 'السماح بمعالجة أسئلتي بواسطة معلم الذكاء الاصطناعي الخارجي',
        'invalid_timezone': 'اختر منطقة زمنية صالحة مثل Europe/Brussels أو Asia/Baghdad.',
    },
}


def text_for(user):
    profile = visible_learning_profile(user)
    language = getattr(profile, 'ui_language', 'en')
    return TEXT.get(language, TEXT['en'])


def appearance_context(request):
    profile = visible_learning_profile(request.user)
    if profile is None:
        return {}
    preferences, _ = LearningPreferences.objects.get_or_create(user=request.user)
    try:
        zone = ZoneInfo(preferences.timezone_name)
    except (ZoneInfoNotFoundError, ValueError):
        zone = user_timezone(request.user)
    today = timezone.localdate(timezone=zone)
    return {'account_appearance': preferences,
            'CURRENT_STREAK': current_streak(profile, today=today)}


def dashboard_progress(user, now=None):
    now = now or timezone.now()
    zone = user_timezone(user)
    today = timezone.localdate(now, timezone=zone)
    preferences, _ = LearningPreferences.objects.get_or_create(user=user)
    profile = Profile.objects.get(user=user)
    first_day = today - timedelta(days=6)
    start, _ = learning_day_bounds(user, first_day)
    _, end = learning_day_bounds(user, today)
    totals = {}
    events = XPEvent.objects.filter(user=user, created_at__gte=start, created_at__lt=end,
                                   reason__in=LEARNING_REASONS).values_list('created_at', 'amount')
    for created_at, amount in events:
        day = timezone.localdate(created_at, timezone=zone)
        totals[day] = totals.get(day, 0) + amount
    calendar = []
    for offset in range(7):
        day = first_day + timedelta(days=offset)
        xp = totals.get(day, 0)
        calendar.append({'date': day, 'iso': day.isoformat(), 'day': day.day,
                         'weekday': day.weekday(), 'xp': xp, 'active': xp > 0,
                         'goal_met': xp >= profile.daily_goal_xp, 'today': day == today})
    return {'current_streak': current_streak(profile, today=today),
            'longest_streak': max(preferences.longest_streak, profile.streak),
            'calendar': calendar, 'weekly_xp': sum(totals.values()),
            'daily_earned': totals.get(today, 0), 'timezone_name': preferences.timezone_name,
            'learning_days': sum(day['active'] for day in calendar)}


class LearningPreferencesForm(forms.ModelForm):
    class Meta:
        model = LearningPreferences
        fields = ['timezone_name', 'theme', 'reduce_motion']
        widgets = {'timezone_name': forms.TextInput(attrs={'list': 'timezone-options', 'autocomplete': 'off'})}

    def clean_timezone_name(self):
        value = self.cleaned_data['timezone_name'].strip()
        try:
            ZoneInfo(value)
        except (ZoneInfoNotFoundError, ValueError):
            raise forms.ValidationError(self.invalid_timezone_message)
        return value

    def __init__(self, *args, texts=None, **kwargs):
        super().__init__(*args, **kwargs)
        texts = texts or TEXT['en']
        self.invalid_timezone_message = texts['invalid_timezone']
        for name in self.fields:
            self.fields[name].label = texts[name]
        self.fields['timezone_name'].help_text = texts['timezone_help']
        self.fields['theme'].choices = [('system', texts['system']), ('light', texts['light']), ('dark', texts['dark'])]


@login_required
@require_POST
def appearance_preferences(request):
    # A stolen/stale session must not change preferences after suspension.
    # Read the persisted state; never rely on a session-cached Profile.
    current_user = get_user_model().objects.filter(pk=request.user.pk).first()
    current_profile = Profile.objects.filter(user_id=request.user.pk).first()
    if not account_signin_permitted(current_user, current_profile):
        return HttpResponse(status=403)
    if rate_limit(request, 'appearance-v9', 120, 3600, True):
        return JsonResponse({'error': 'Too many preference changes.'}, status=429)
    data = request.POST
    if request.content_type == 'application/json':
        try:
            data = json.loads(request.body)
        except (ValueError, UnicodeDecodeError):
            return JsonResponse({'error': 'Invalid JSON.'}, status=400)
        if not isinstance(data, dict):
            return JsonResponse({'error': 'Invalid preferences.'}, status=400)
    theme = data.get('theme')
    if theme not in ('system', 'light', 'dark'):
        return JsonResponse({'error': 'Invalid appearance.'}, status=400)
    raw_motion = data.get('reduce_motion')
    if raw_motion is not None and raw_motion not in (True, False, 'true', 'false', '1', '0', 'on', 'off'):
        return JsonResponse({'error': 'Invalid motion preference.'}, status=400)
    with transaction.atomic():
        # Serialize revocation and the mutation on the same Profile lock.
        current_profile = Profile.objects.select_for_update().filter(user_id=request.user.pk).first()
        current_user = get_user_model().objects.filter(pk=request.user.pk).first()
        if not account_signin_permitted(current_user, current_profile):
            return HttpResponse(status=403)
        preferences, _ = LearningPreferences.objects.get_or_create(user=request.user)
        preferences = LearningPreferences.objects.select_for_update().get(pk=preferences.pk)
        preferences.theme = theme
        fields = ['theme']
        if raw_motion is not None:
            preferences.reduce_motion = raw_motion in (True, 'true', '1', 'on')
            fields.append('reduce_motion')
        preferences.save(update_fields=fields)
    return JsonResponse({'theme': preferences.theme, 'reduce_motion': preferences.reduce_motion})


@login_required
def profile(request):
    # The real Profile may have been suspended/reviewed after this session began.
    current_user = get_user_model().objects.filter(pk=request.user.pk).first()
    instance = Profile.objects.filter(user_id=request.user.pk).first()
    if not account_signin_permitted(current_user, instance):
        return HttpResponse(status=403)
    previous_language_id = instance.preferred_language_id
    texts = text_for(request.user)
    preferences, _ = LearningPreferences.objects.get_or_create(user=request.user)
    form = ProfileForm(request.POST or None, instance=instance)
    for name, field in form.fields.items():
        if name in texts:
            field.label = texts[name]
    avatars = ['🎓', '📚', '⭐', '🌍', '🚀', '🌱', '🌿', '💎']
    if instance.avatar not in avatars:
        avatars.append(instance.avatar)
    form.fields['avatar'].widget = forms.Select(choices=[(value, value) for value in avatars])
    preference_data = None
    if request.method == 'POST':
        # Older clients only submit the original ProfileForm. Preserve preferences.
        preference_data = request.POST.copy()
        if not any(key.startswith('preferences-') for key in request.POST):
            preference_data['preferences-timezone_name'] = preferences.timezone_name
            preference_data['preferences-theme'] = preferences.theme
            if preferences.reduce_motion:
                preference_data['preferences-reduce_motion'] = 'on'
    preference_form = LearningPreferencesForm(preference_data, instance=preferences,
                                              prefix='preferences', texts=texts)
    if request.method == 'POST':
        if rate_limit(request, 'profile-v9', 40, 3600, True):
            return HttpResponse('Too many preference changes.', status=429)
        valid_profile = form.is_valid()
        valid_preferences = preference_form.is_valid()
        if valid_profile and valid_preferences:
            new_language = form.cleaned_data['preferred_language']
            changed = previous_language_id != (new_language.pk if new_language else None)
            with transaction.atomic():
                # Re-read under the Profile lock BEFORE any form field is saved.
                # Refuse a concurrent course switch instead of overwriting its
                # placement or snapshot from a stale form instance.
                locked_profile = Profile.objects.select_for_update().filter(pk=instance.pk).first()
                current_user = get_user_model().objects.filter(pk=request.user.pk).first()
                if not account_signin_permitted(current_user, locked_profile):
                    return HttpResponse(status=403)
                if locked_profile.preferred_language_id != previous_language_id:
                    return HttpResponse('Course changed; reload preferences before saving.', status=409)
                item = form.save(commit=False)
                # ModelForm validation already changes item.preferred_language.
                # Persist only preferences before the course helper locks a fresh
                # DB profile, snapshots the previous course and restores the next.
                item.save(update_fields=[name for name in form.fields if name != 'preferred_language'])
                from .courses_v10 import record_current_course, switch_course
                if changed and new_language is not None:
                    item = switch_course(request.user, new_language)
                elif changed:
                    record_current_course(item)
                    Profile.objects.filter(pk=item.pk).update(preferred_language=None,
                        placement_completed=False, placement_level='A0')
                    item.placement_completed = False
                else:
                    record_current_course(item)
                preference_form.save()
            # A withdrawn opt-in must also erase earlier AI messages held in
            # this browser session. The credit wallet and learning history stay untouched.
            if not form.cleaned_data['ai_opt_in']:
                from .ai_privacy import clear_ai_history
                clear_ai_history(request)
            messages.success(request, texts['changed'] if changed and not item.placement_completed else texts['saved'])
            return redirect('profile')
    from .solar_profile_copy import for_language as solar_profile_labels
    from .rozh2027 import student_shell_context
    return render(request, 'academy/profile.html', {
        **student_shell_context(request), 'shell_template':'academy/rozh2027_student_shell.html',
        'page_title':texts['title'], 'S4': solar_profile_labels(instance.ui_language),
        'form': form, 'preference_form': preference_form, 'profile': instance,
        'T': texts, 'progress': dashboard_progress(request.user),
        'timezones': sorted(available_timezones()), 'noindex': True,
    })


urlpatterns = [
    path('profile/', profile, name='profile'),
    path('profile/appearance/', appearance_preferences, name='appearance_preferences'),
]


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'progress_v9', ['TEXT'])

"""V21 design must preserve real Django V4 app contracts."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from .models import Language, Level, Unit, Lesson, Exercise

class AtlasRuntimeBackCompatTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        User=get_user_model()
        cls.user=User.objects.create_user('v21-atlas-regression@example.org',
            'v21-atlas-regression@example.org','StrongExamplePassword!23')
        cls.lang=Language.objects.create(code='nl',slug='dutch',name='Dutch',
            description='Dutch',is_published=True)
        cls.level=Level.objects.create(language=cls.lang, code='A0',order=0,description='Intro')
        cls.unit=Unit.objects.create(level=cls.level,title='Learn hello',slug='hello',
            summary='Learn greetings',order=1,published=True)
        cls.lesson=Lesson.objects.create(unit=cls.unit,slug='grammar',title='Say hello',
            skill='grammar',content='Hoi = hi',order=1,published=True)
        cls.exercise=Exercise.objects.create(lesson=cls.lesson, kind='mcq',
            prompt='What means hello?',options=['Hoi','Nee'],answer='Hoi',order=1)

    def setUp(self):
        self.client.force_login(self.user)
        profile=self.user.learning_profile
        profile.placement_completed=True
        profile.save(update_fields=['placement_completed'])

    def test_new_learn_path_preserves_legacy_semantics_and_real_links(self):
        r=self.client.get('/learn/')
        self.assertEqual(r.status_code,200)
        for token in ('lm20-journey','v4-chapter-heading','v4-journey-stop','app-path-node',
                      'Learn hello',self.lesson.get_absolute_url()):
            with self.subTest(token=token):self.assertContains(r,token)

    def test_dashboard_keeps_quest_and_illustration(self):
        r=self.client.get('/dashboard/')
        self.assertEqual(r.status_code,200)
        for token in ('v4-main-quest','v4-mode-grid','academy/app-v4.css',
                      'academy/pip-sprout.svg','Learn hello'):
            with self.subTest(token=token):self.assertContains(r,token)

    def test_locked_prerequisite_is_not_a_play_link(self):
        other=Unit.objects.create(level=self.level,slug='second',title='Second unit',
            summary='Next unit',order=2,published=True)
        other.prerequisites.add(self.unit)
        Lesson.objects.create(unit=other,slug='next',title='Second lesson',
            skill='grammar',content='Ok',order=1,published=True)
        r=self.client.get('/learn/')
        self.assertContains(r,'lm20-stop-locked')
        # The locked item renders a lock label instead of a playable anchor.
        from html.parser import HTMLParser
        class LockedParser(HTMLParser):
            def __init__(self):
                super().__init__();self.locked_stack=[];self.locked_play_links=0
            def handle_starttag(self,tag,attrs):
                a=dict(attrs);classes=a.get('class','').split()
                if tag=='li':
                    self.locked_stack.append('lm20-stop-locked' in classes or
                                             any(self.locked_stack))
                if any(self.locked_stack) and tag=='a' and 'lm20-stop-start' in classes:
                    self.locked_play_links+=1
            def handle_endtag(self,tag):
                if tag=='li' and self.locked_stack:self.locked_stack.pop()
        parser=LockedParser();parser.feed(r.content.decode('utf-8'))
        self.assertEqual(parser.locked_play_links,0)

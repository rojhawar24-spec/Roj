"""Django HTTP/ORM tests for V41 — require Django; NOT run in offline QA."""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .models import Assessment, Exercise, Language, Level, Lesson, MistakeRecord, Profile, Unit, XPEvent

User = get_user_model()


class AdaptivePracticeV41HTTPTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user=User.objects.create_user(username='v41-practice',password='TestOnly-V41-Pass!')
        self.dutch=Language.objects.create(name='Dutch V41',slug='v41-dutch',code='nl',is_published=True)
        self.french=Language.objects.create(name='French V41',slug='v41-french',code='fr',is_published=True)
        self.level=Level.objects.create(language=self.dutch,code='A0',order=0)
        self.unit=Unit.objects.create(level=self.level,slug='v41-unit',title='V41 unit',summary='Test',published=True)
        self.lesson=Lesson.objects.create(unit=self.unit,slug='v41-lesson',title='Test lesson',skill='grammar',content='Test',published=True)
        self.exercise=Exercise.objects.create(lesson=self.lesson,kind='mcq',prompt='Correct?',options=['Yes','No'],answer='Yes',explanation='Yes',difficulty=1)
        Profile.objects.filter(user=self.user).update(preferred_language=self.dutch,placement_completed=True,
                 placement_level='A0',onboarding_required=True,onboarding_completed=True)
        self.client.force_login(self.user)
        self.url=reverse('adaptive_practice',args=[self.level.pk])

    def submit(self, value='Yes'):
        return self.client.post(self.url,{f'q_{self.exercise.pk}':value})

    def unchanged(self):
        self.assertFalse(Assessment.objects.filter(user=self.user,kind='practice').exists())
        self.assertFalse(MistakeRecord.objects.filter(user=self.user).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_valid_preview_and_submission(self):
        self.assertEqual(self.client.get(self.url).status_code,200)
        self.assertEqual(self.submit().status_code,200)
        self.assertEqual(Assessment.objects.filter(user=self.user,kind='practice').count(),1)
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_other_course_get_and_post_rejected(self):
        Profile.objects.filter(user=self.user).update(preferred_language=self.french)
        self.assertEqual(self.client.get(self.url).status_code,403)
        self.assertEqual(self.submit().status_code,403)
        self.unchanged()

    def test_course_changed_after_preview_rejected(self):
        self.client.get(self.url)
        Profile.objects.filter(user=self.user).update(preferred_language=self.french)
        self.assertEqual(self.submit().status_code,403)
        self.unchanged()

    def test_suspension_after_preview_rejected(self):
        self.client.get(self.url)
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        self.assertEqual(self.submit().status_code,403)
        self.unchanged()

    def test_review_after_preview_rejected(self):
        self.client.get(self.url)
        Profile.objects.filter(user=self.user).update(legacy_review_required=True)
        self.assertEqual(self.submit().status_code,403)
        self.unchanged()

    def test_unfinished_onboarding_after_preview_rejected(self):
        self.client.get(self.url)
        Profile.objects.filter(user=self.user).update(onboarding_completed=False)
        self.assertEqual(self.submit().status_code,403)
        self.unchanged()

    def test_placement_revoked_after_preview_rejected(self):
        self.client.get(self.url)
        Profile.objects.filter(user=self.user).update(placement_completed=False)
        self.assertEqual(self.submit().status_code,403)
        self.unchanged()

    def test_unpublished_course_rejected(self):
        self.client.get(self.url)
        Language.objects.filter(pk=self.dutch.pk).update(is_published=False)
        self.assertEqual(self.submit().status_code,404)
        self.unchanged()

    def test_unpublished_unit_blocks_write(self):
        self.client.get(self.url)
        Unit.objects.filter(pk=self.unit.pk).update(published=False)
        self.assertEqual(self.submit().status_code,403)
        self.unchanged()

    def test_unpublished_lesson_blocks_write(self):
        self.client.get(self.url)
        Lesson.objects.filter(pk=self.lesson.pk).update(published=False)
        self.assertEqual(self.submit().status_code,503)
        self.unchanged()

    def test_invalid_oversized_response_does_not_store(self):
        self.assertEqual(self.submit('x'*301).status_code,400)
        self.unchanged()

    def test_wrong_answer_records_mistake_but_no_xp(self):
        self.assertEqual(self.submit('No').status_code,200)
        self.assertEqual(Assessment.objects.filter(user=self.user,kind='practice').count(),1)
        self.assertTrue(MistakeRecord.objects.filter(user=self.user,exercise=self.exercise).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_locked_prerequisite_unit_questions_excluded(self):
        locked=Unit.objects.create(level=self.level,slug='v41-locked',title='Locked',summary='Test',published=True)
        locked.prerequisites.add(self.unit)
        lesson=Lesson.objects.create(unit=locked,slug='v41-locked',title='Locked lesson',skill='grammar',content='Test',published=True)
        question=Exercise.objects.create(lesson=lesson,kind='mcq',prompt='Locked?',options=['Yes','No'],answer='Yes',explanation='Yes',difficulty=1)
        self.assertEqual(self.client.get(self.url).status_code,200)
        self.assertEqual(self.submit().status_code,200)
        self.assertFalse(MistakeRecord.objects.filter(user=self.user,exercise=question).exists())
        self.assertEqual(Assessment.objects.filter(user=self.user,kind='practice').count(),1)

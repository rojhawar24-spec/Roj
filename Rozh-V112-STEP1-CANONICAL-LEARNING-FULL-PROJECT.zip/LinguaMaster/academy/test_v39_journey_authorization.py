"""Real Django HTTP regression cases — NOT executed in the offline audit."""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .journey_v11 import _challenges
from .models import Exercise, Language, Lesson, Level, Profile, Unit, XPEvent, LessonProgress, MistakeRecord
from .heart_models import HeartEvent

class V39JourneyAccessHTTPTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user=get_user_model().objects.create_user(username='v39journey',password='Temporary-Test-Only-Password-2026!')
        self.dutch=Language.objects.create(name='Dutch v39',code='nl',slug='v39-dutch',description='',is_published=True)
        self.english=Language.objects.create(name='English v39',code='en',slug='v39-english',description='',is_published=True)
        self.level=Level.objects.create(language=self.dutch,code='A0',order=0,description='A0')
        self.unit=Unit.objects.create(level=self.level,slug='unit-v39',title='Unit v39',summary='',order=1,published=True)
        self.lesson=Lesson.objects.create(unit=self.unit,slug='lesson-v39',title='Lesson v39',skill='reading',
                                          content='Test',order=1,published=True)
        Exercise.objects.create(lesson=self.lesson,kind='mcq',prompt='A greeting?',options=['Yes','No'],answer='Yes')
        Profile.objects.filter(user=self.user).update(preferred_language=self.dutch,placement_completed=True,
                        onboarding_required=True,onboarding_completed=True,placement_level='A0')
        self.client.force_login(self.user)
        self.page=reverse('journey_play',args=[self.unit.pk])
        self.post=reverse('journey_answer',args=[self.unit.pk])
        response=self.client.get(self.page)
        self.assertEqual(response.status_code,200)
        self.state=self.client.session[f'journey_v11_{self.unit.pk}']
        self.question=_challenges(self.unit,self.state['token'])[0]

    def _answer(self):
        return self.client.post(self.post, {'round_token':self.state['token'],
              'challenge_id':self.question['id'], 'answer':self.question['answer']},
              HTTP_X_REQUESTED_WITH='XMLHttpRequest')

    def _assert_unchanged(self):
        self.assertEqual(XPEvent.objects.filter(user=self.user).count(),0)
        self.assertEqual(LessonProgress.objects.filter(user=self.user).count(),0)
        self.assertEqual(MistakeRecord.objects.filter(user=self.user).count(),0)
        self.assertEqual(HeartEvent.objects.filter(user=self.user).count(),0)
        self.assertEqual(self.client.session[f'journey_v11_{self.unit.pk}']['position'],0)

    def test_suspension_after_round_start_blocks_read_and_post(self):
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        self.assertEqual(self.client.get(self.page).status_code,403)
        self.assertEqual(self._answer().status_code,403)
        self._assert_unchanged()

    def test_legacy_review_after_round_start_blocks_read_and_post(self):
        Profile.objects.filter(user=self.user).update(legacy_review_required=True)
        self.assertEqual(self.client.get(self.page).status_code,403)
        self.assertEqual(self._answer().status_code,403)
        self._assert_unchanged()

    def test_switch_to_another_course_blocks_old_round(self):
        Profile.objects.filter(user=self.user).update(preferred_language=self.english)
        self.assertEqual(self.client.get(self.page).status_code,403)
        self.assertEqual(self._answer().status_code,403)
        self._assert_unchanged()

    def test_placement_revocation_blocks_reward(self):
        Profile.objects.filter(user=self.user).update(placement_completed=False)
        self.assertEqual(self.client.get(self.page).status_code,302)
        self.assertEqual(self._answer().status_code,403)
        self._assert_unchanged()

    def test_incomplete_onboarding_blocks_reward(self):
        Profile.objects.filter(user=self.user).update(onboarding_completed=False)
        self.assertEqual(self.client.get(self.page).status_code,302)
        self.assertEqual(self._answer().status_code,403)
        self._assert_unchanged()

    def test_unpublished_course_blocks_old_round(self):
        Language.objects.filter(pk=self.dutch.pk).update(is_published=False)
        self.assertEqual(self.client.get(self.page).status_code,404)
        self.assertEqual(self._answer().status_code,404)
        self._assert_unchanged()

    def test_valid_round_can_advance(self):
        result=self._answer()
        self.assertEqual(result.status_code,200)
        self.assertTrue(result.json()['correct'])
        self.assertEqual(self.client.session[f'journey_v11_{self.unit.pk}']['position'],1)

"""Phase 9: Django integration checks for transaction integrity.

Run only against a disposable test database (see Run-Phase9-Isolated-Django.ps1).
These tests have not been executed by the authoring environment without Django.
"""
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse

from .models import (
    Assessment, Exercise, Language, Lesson, LessonProgress, Level,
    MistakeRecord, ReviewCard, Unit, Vocabulary, XPEvent,
)


class Phase9TransactionIntegrityTests(TestCase):
    def setUp(self):
        cache.clear()
        self.student = get_user_model().objects.create_user(
            'phase9student', password='Phase9-Only-Testing-Password!'
        )
        self.language = Language.objects.create(
            code='nl', name='Dutch', slug='phase9-dutch',
            description='Private test course', is_published=True,
        )
        self.level = Level.objects.create(
            language=self.language, code='A0', description='Beginner',
        )
        self.unit = Unit.objects.create(
            level=self.level, slug='phase9-unit', title='Unit for tests',
            summary='Testing only', published=True,
        )
        self.lesson = Lesson.objects.create(
            unit=self.unit, slug='phase9-lesson', title='A0 unit lesson',
            skill='grammar', content='Private testing only', published=True,
        )
        LessonProgress.objects.create(user=self.student, lesson=self.lesson, score=100)
        profile = self.student.learning_profile
        profile.preferred_language = self.language
        profile.placement_completed = True
        profile.onboarding_completed = True
        profile.onboarding_required = False
        profile.save(update_fields=[
            'preferred_language', 'placement_completed',
            'onboarding_completed', 'onboarding_required',
        ])
        self.word = Vocabulary.objects.create(
            level=self.level, word='hello', translation='hallo',
            pronunciation='', example='Hello', published=True,
        )
        self.card = ReviewCard.objects.create(user=self.student, vocabulary=self.word)
        self.client.force_login(self.student)

    def _review(self, quality='5'):
        return self.client.post(reverse('review'), {
            'card_id': str(self.card.pk), 'quality': quality,
        })

    def test_review_schedule_rolls_back_when_xp_write_fails(self):
        before = (self.card.repetitions, self.card.interval_days,
                  self.card.ease, self.card.due, self.card.last_quality)
        with patch('academy.views.award_xp', side_effect=RuntimeError('XP failure injected')):
            with self.assertRaisesRegex(RuntimeError, 'XP failure injected'):
                self._review()
        self.card.refresh_from_db()
        after = (self.card.repetitions, self.card.interval_days,
                 self.card.ease, self.card.due, self.card.last_quality)
        self.assertEqual(before, after)
        self.assertFalse(XPEvent.objects.filter(user=self.student, reason='review').exists())

    def test_successful_review_updates_card_and_grants_xp_only_once_per_day(self):
        self.assertEqual(self._review().status_code, 302)
        self.card.refresh_from_db()
        self.assertEqual(self.card.repetitions, 1)
        self.assertEqual(self.card.last_quality, 5)
        self.assertEqual(XPEvent.objects.filter(user=self.student, reason='review').count(), 1)
        self.assertEqual(self._review().status_code, 302)
        self.assertEqual(XPEvent.objects.filter(user=self.student, reason='review').count(), 1)

    def test_invalid_quality_does_not_change_review(self):
        self.assertEqual(self._review('not-a-number').status_code, 400)
        self.card.refresh_from_db()
        self.assertEqual(self.card.repetitions, 0)
        self.assertFalse(XPEvent.objects.filter(user=self.student, reason='review').exists())

    def _assessment_payload(self):
        data = {}
        for index in range(6):
            exercise = Exercise.objects.create(
                lesson=self.lesson, kind='mcq', prompt=f'Question {index}',
                options=['Yes', 'No'], answer='Yes', explanation='Yes', order=index,
            )
            data[f'q_{exercise.pk}'] = 'No' if index == 0 else 'Yes'
        return data

    def test_assessment_mistakes_rollback_if_xp_grant_fails(self):
        data = self._assessment_payload()  # 5/6 = passing score, with one mistake
        with patch('academy.views.award_xp', side_effect=RuntimeError('Assessment XP failure')):
            with self.assertRaisesRegex(RuntimeError, 'Assessment XP failure'):
                self.client.post(reverse('assessment_unit', args=[self.unit.pk]), data)
        self.assertFalse(Assessment.objects.filter(user=self.student).exists())
        self.assertFalse(MistakeRecord.objects.filter(user=self.student).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.student).exists())
        self.student.learning_profile.refresh_from_db()
        self.assertEqual(self.student.learning_profile.xp, 0)

    def test_successful_assessment_commits_mistake_grade_and_xp_together(self):
        data = self._assessment_payload()
        response = self.client.post(reverse('assessment_unit', args=[self.unit.pk]), data)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(Assessment.objects.filter(user=self.student, kind='unit', passed=True).count(), 1)
        self.assertEqual(MistakeRecord.objects.filter(user=self.student).count(), 1)
        self.assertEqual(XPEvent.objects.filter(user=self.student, reason='assessment').count(), 1)
        self.student.learning_profile.refresh_from_db()
        self.assertEqual(self.student.learning_profile.xp, 40)

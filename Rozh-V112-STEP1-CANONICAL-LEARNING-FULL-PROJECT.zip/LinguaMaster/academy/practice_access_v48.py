"""Current learner-state authorization shared by low-stakes practice views.

A logged-in session is not proof that the Profile, course, onboarding or
account authorization still exists. Reads fail closed and writes recheck
inside the same transaction used for saving the attempt.
"""
from django.contrib.auth import get_user_model
from .models import Profile


def eligible_practice_profile(user, *, for_update=False):
    if not getattr(user, 'is_authenticated', False):
        return None
    queryset = Profile.objects.select_related('preferred_language')
    if for_update:
        queryset = queryset.select_for_update()
    profile = queryset.filter(user_id=user.pk).first()
    if profile is None:
        return None
    if (profile.suspended_at is not None or profile.legacy_review_required
            or (profile.onboarding_required and not profile.onboarding_completed)
            or not profile.placement_completed):
        return None
    # The session may still contain an old authenticated User object after an
    # admin disables that row. Consult fresh DB state, not only request.user.
    if not get_user_model()._default_manager.filter(pk=user.pk, is_active=True).exists():
        return None
    return profile

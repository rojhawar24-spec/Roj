"""Django+SQLite HTTP tests (defined for CI/Windows, not run offline)."""
import hashlib
import hmac
from django.conf import settings
from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse
from .models import Profile


@override_settings(REQUIRE_EMAIL_VERIFICATION=False)
class DuplicateRecoveryHashHTTP(TestCase):
    PASSWORD='Step2-Recovery-Repeat-Regression-Password!'
    RECOVERY_A='A1B2C3D4E5F60708'
    RECOVERY_B='1122334455667788'

    def setUp(self):
        self.user=get_user_model().objects.create_user(
            username='step2_recovery_duplicates',email='step2_recovery_duplicates@example.invalid',
            password=self.PASSWORD)
        self.profile=Profile.objects.get(user=self.user)
        self.profile.totp_secret='JBSWY3DPEHPK3PXP'
        self.profile.mfa_recovery_hashes=[self._digest(self.RECOVERY_A),
            self._digest(self.RECOVERY_B),self._digest(self.RECOVERY_A)]
        self.profile.save(update_fields=['totp_secret','mfa_recovery_hashes'])

    def _digest(self,code):
        return hmac.new(settings.SECRET_KEY.encode(),code.encode(),hashlib.sha256).hexdigest()

    def _start_mfa(self):
        response=self.client.post(reverse('login'),{'email':self.user.email,'password':self.PASSWORD})
        self.assertEqual(response.status_code,302)
        self.assertEqual(response.url,reverse('mfa_verify'))

    def test_duplicate_recovery_code_is_consumed_once_total(self):
        self._start_mfa()
        self.assertEqual(self.client.post(reverse('mfa_verify'),{'code':self.RECOVERY_A}).status_code,302)
        self.profile.refresh_from_db()
        self.assertEqual(self.profile.mfa_recovery_hashes,[self._digest(self.RECOVERY_B)])
        self.client.post(reverse('logout'))
        self._start_mfa()
        denied=self.client.post(reverse('mfa_verify'),{'code':self.RECOVERY_A})
        self.assertEqual(denied.status_code,200)
        self.assertNotIn('_auth_user_id',self.client.session)

    def test_unrelated_code_remains_usable_after_duplicate_cleanup(self):
        self._start_mfa()
        self.assertEqual(self.client.post(reverse('mfa_verify'),{'code':self.RECOVERY_A}).status_code,302)
        self.client.post(reverse('logout'))
        self._start_mfa()
        self.assertEqual(self.client.post(reverse('mfa_verify'),{'code':self.RECOVERY_B}).status_code,302)
        self.profile.refresh_from_db()
        self.assertEqual(self.profile.mfa_recovery_hashes,[])

"""Django integration cases for Phase 6; no production database access."""
from datetime import timedelta
from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from django.utils import timezone
from .models import Profile, XPEvent
class Phase6SocialTests(TestCase):
 def setUp(self):
  U=get_user_model();self.me=U.objects.create_user('me_phase6','me6@example.test','Password!2026');self.other=U.objects.create_user('friend_phase6','friend6@example.test','Password!2026');self.hidden=U.objects.create_user('hidden_phase6','hidden6@example.test','Password!2026')
  Profile.objects.filter(user=self.me).update(ui_language='ckb',leaderboard_opt_in=True,social_opt_in=True, xp=20)
  Profile.objects.filter(user=self.other).update(leaderboard_opt_in=True,xp=40)
  Profile.objects.filter(user=self.hidden).update(leaderboard_opt_in=False,xp=10000)
  self.client.force_login(self.me)
 def test_private_participants_never_in_leaderboard(self):
  r=self.client.get(reverse('leaderboard'));self.assertContains(r,'friend_phase6');self.assertNotContains(r,'hidden_phase6');self.assertNotContains(r,'friend6@example.test')
 def test_week_only_recent_earned_learning(self):
  XPEvent.objects.create(user=self.me,event_key='phase6-r',reason='lesson',amount=10)
  XPEvent.objects.create(user=self.other,event_key='phase6-c',reason='chest',amount=30)
  XPEvent.objects.create(user=self.other,event_key='phase6-o',reason='lesson',amount=40,created_at=timezone.now()-timedelta(days=8))
  r=self.client.get(reverse('leaderboard'),{'period':'week'});self.assertEqual([x['username'] for x in r.context['leaders']],['me_phase6'])
 def test_no_profile_xp_mutation_from_get(self):
  self.client.get(reverse('leaderboard'),{'period':'week'});self.assertEqual(Profile.objects.get(user=self.me).xp,20)
 def test_shell_on_social_pages(self):
  for name in ('friends','profile','avatar_studio'):
   r=self.client.get(reverse(name));self.assertEqual(r.status_code,200);self.assertTemplateUsed(r,'academy/rozh2027_student_shell.html')
 def test_language_return_to_named_destinations(self):
  for name in ('friends','leaderboard','profile','avatar_studio'):
   self.assertEqual(self.client.post(reverse('switch_ui_language'),{'ui_language':'nl','return_to':name}).url,reverse(name))
  self.assertEqual(self.client.post(reverse('switch_ui_language'),{'ui_language':'ckb','return_to':'leaderboard_week'}).url,reverse('leaderboard')+'?period=week')
 def test_no_open_redirect(self):
  self.assertEqual(self.client.post(reverse('switch_ui_language'),{'ui_language':'nl','return_to':'https://evil.test'}).url,reverse('play_hub'))

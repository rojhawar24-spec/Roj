"""Fail-closed one-time recovery-code use for legacy duplicate hash inventories.

The caller MUST hold the account/Profile row lock inside transaction.atomic()
and persist the new list before granting MFA access. This helper changes no DB
state and never retains or returns a plaintext recovery code.
"""
import hashlib
import hmac

_HEX = frozenset('0123456789abcdef')


def consume_recovery_hashes(stored_hashes, code, signing_key):
    """Return a new inventory without *any* copies of a matched hash.

    None means no match or invalid data. Multiple equal stored hashes must
    never cause the same recovery token to be usable in later sessions.
    """
    if (type(stored_hashes) is not list or not isinstance(code, str)
            or len(code) != 16 or not code.isascii()
            or any(ch not in '0123456789abcdefABCDEF' for ch in code)
            or not isinstance(signing_key, str) or not signing_key):
        return None
    # Reject corrupted records without partially consuming legitimate codes.
    if any(not isinstance(item, str) or len(item) != 64
           or any(ch not in _HEX for ch in item) for item in stored_hashes):
        return None
    candidate = hmac.new(signing_key.encode('utf-8'), code.upper().encode('ascii'),
                         hashlib.sha256).hexdigest()
    remaining = []
    matched = False
    # Compare against *every* slot; no early exit on a matching code.
    for stored in stored_hashes:
        same = hmac.compare_digest(stored, candidate)
        matched = matched or same
        if not same:
            remaining.append(stored)
    return remaining if matched else None

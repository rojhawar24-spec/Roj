"""Phase 8 real-Django regression coverage for auth/setup/navigation safety.

These are Django TestCase tests. Run only on a fresh disposable SQLite test
DB using scripts/Run-Phase8-Isolated-E2E.ps1. No production data is required.
The tests are deliberately NOT represented as passed until executed.
"""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase, override_settings
from django.urls import reverse

from .models import Language, PlatformSettings

User = get_user_model()


@override_settings(REQUIRE_EMAIL_VERIFICATION=False, SITE_URL='http://testserver')
class Phase8SafeResumeTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = User.objects.create_user(
            username='phase8learner', email='phase8@example.test', password='Phase8UniquePassword2026!'
        )
        self.profile = self.user.learning_profile
        self.profile.placement_completed = True
        self.profile.onboarding_required = False
        self.profile.save(update_fields=['placement_completed', 'onboarding_required'])
        self.client.force_login(self.user)

    def _continue(self, destination):
        session = self.client.session
        session['post_auth_next'] = destination
        session.save()
        response = self.client.get(reverse('placement'))
        self.assertEqual(response.status_code, 302)
        self.assertNotIn('post_auth_next', self.client.session)
        return response['Location']

    def test_original_grammar_and_play_intents_survive(self):
        for path in ('/grammar/', '/play/', '/vocabulary/?q=hello', '/leaderboard/?period=week'):
            with self.subTest(path=path):
                self.assertEqual(self._continue(path), path)

    def test_auth_actions_management_and_checkout_are_never_post_setup_destinations(self):
        denied = (
            '/account/delete/', '/account/export/', '/manager/',
            '/notifications/read/', '/play/season/1/claim/', '/ai/checkout/',
            '/vocabulary/1/save/', '/interface-language/',
            '/onboarding/ready/', '/does-not-exist/',
        )
        for path in denied:
            with self.subTest(path=path):
                self.assertEqual(self._continue(path), reverse('play_hub'))

    def test_cross_origin_and_protocol_relative_intents_rejected(self):
        for path in ('https://evil.test/steal', '//evil.test/steal', '\\\\evil.test', 'javascript:alert(1)'):
            with self.subTest(path=path):
                self.assertEqual(self._continue(path), reverse('play_hub'))

    def test_missing_course_redirects_to_selection_before_placement(self):
        self.profile.placement_completed = False
        self.profile.save(update_fields=['placement_completed'])
        self.assertRedirects(self.client.get(reverse('placement')), reverse('courses'), fetch_redirect_response=False)

    def test_unpublished_course_redirects_to_selection_before_placement(self):
        language = Language.objects.create(code='nl', name='Dutch', slug='phase8-dutch', is_published=False)
        self.profile.placement_completed = False
        self.profile.preferred_language = language
        self.profile.save(update_fields=['placement_completed', 'preferred_language'])
        self.assertRedirects(self.client.get(reverse('placement')), reverse('courses'), fetch_redirect_response=False)

    def test_new_user_cannot_bypass_onboarding_by_opening_placement_directly(self):
        self.profile.placement_completed = False
        self.profile.onboarding_required = True
        self.profile.onboarding_completed = False
        self.profile.save(update_fields=['placement_completed', 'onboarding_required', 'onboarding_completed'])
        self.assertRedirects(self.client.get(reverse('placement')), reverse('onboarding'), fetch_redirect_response=False)


@override_settings(
    REQUIRE_EMAIL_VERIFICATION=True,
    SITE_URL='http://testserver',
    MAILERS={'default': {'BACKEND':'django.core.mail.backends.locmem.EmailBackend'}},
)
class Phase8RegistrationSessionTests(TestCase):
    PASSWORD = 'Phase8StrongPassword2026!'

    def setUp(self):
        cache.clear()
        config = PlatformSettings.load()
        config.public_registration_enabled = True
        config.save(update_fields=['public_registration_enabled'])

    def _register(self, user, email, next_path=''):
        return self.client.post(reverse('register'), {
            'username': user,
            'email': email,
            'password1': self.PASSWORD,
            'age_confirmed': 'on',
            'next': next_path,
        })

    def test_new_signup_stores_only_its_current_valid_intended_page(self):
        response = self._register('phase8new', 'new-phase8@example.test', '/grammar/')
        self.assertRedirects(response, reverse('registration_check_email'), fetch_redirect_response=False)
        self.assertEqual(self.client.session['registration_pending_next'], '/grammar/')
        self.assertIsNotNone(self.client.session.get('registration_pending_user_id'))

    def test_second_duplicate_signup_clears_stale_pending_destination_and_owner(self):
        self._register('phase8new', 'new-phase8@example.test', '/grammar/')
        response = self._register('phase8different', 'new-phase8@example.test')
        self.assertRedirects(response, reverse('registration_check_email'), fetch_redirect_response=False)
        self.assertNotIn('registration_pending_next', self.client.session)
        self.assertNotIn('registration_pending_user_id', self.client.session)
        self.assertFalse(User.objects.filter(username='phase8different').exists())

    def test_second_fresh_signup_without_next_does_not_inherit_previous_destination(self):
        self._register('phase8first', 'first-phase8@example.test', '/grammar/')
        response = self._register('phase8second', 'second-phase8@example.test')
        self.assertRedirects(response, reverse('registration_check_email'), fetch_redirect_response=False)
        self.assertNotIn('registration_pending_next', self.client.session)
        pending = self.client.session.get('registration_pending_user_id')
        self.assertEqual(pending, User.objects.get(username='phase8second').pk)

"""V44 Django HTTP regression cases, pending execution on installed Django."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .models import AppNotification, Profile

class V44NotificationsRevocationHTTPTests(TestCase):
    def setUp(self):
        U=get_user_model()
        self.user=U.objects.create_user('v44_reader',password='Strong-TestOnly-Password2026!')
        self.other=U.objects.create_user('v44_other',password='Strong-TestOnly-Password2026!')
        self.own=AppNotification.objects.create(user=self.user,event_key='v44:private',
              title='Your private note',message='For you only.')
        self.foreign=AppNotification.objects.create(user=self.other,event_key='v44:foreign',
              title='Other private note',message='Never show this.')
        self.url=reverse('notifications')
        self.read_url=reverse('notifications_read')
        self.client.force_login(self.user)

    def test_active_reader_sees_only_own_private_notes(self):
        response=self.client.get(self.url)
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'For you only.')
        self.assertNotContains(response,'Never show this.')
        self.assertIn('no-store',response['Cache-Control'])
    def test_active_read_receipt_updates_only_own(self):
        self.assertEqual(self.client.post(self.read_url).status_code,302)
        self.own.refresh_from_db();self.foreign.refresh_from_db()
        self.assertIsNotNone(self.own.read_at)
        self.assertIsNone(self.foreign.read_at)
    def test_suspended_reader_cannot_open_notifications(self):
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        response=self.client.get(self.url)
        self.assertEqual(response.status_code,403)
        self.assertNotIn('For you only.',response.content.decode())
    def test_suspended_reader_cannot_mark_read(self):
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        self.assertEqual(self.client.post(self.read_url).status_code,403)
        self.own.refresh_from_db();self.assertIsNone(self.own.read_at)
    def test_review_hold_denies_both_routes(self):
        Profile.objects.filter(user=self.user).update(legacy_review_required=True)
        self.assertEqual(self.client.get(self.url).status_code,403)
        self.assertEqual(self.client.post(self.read_url).status_code,403)
        self.own.refresh_from_db();self.assertIsNone(self.own.read_at)
    def test_missing_profile_fails_closed_and_does_not_create_one(self):
        Profile.objects.filter(user=self.user).delete()
        count=Profile.objects.count()
        self.assertEqual(self.client.get(self.url).status_code,403)
        self.assertEqual(self.client.post(self.read_url).status_code,403)
        self.assertEqual(Profile.objects.count(),count)
        self.own.refresh_from_db();self.assertIsNone(self.own.read_at)
    def test_stale_session_inactive_db_user_cannot_mark_read(self):
        get_user_model().objects.filter(pk=self.user.pk).update(is_active=False)
        self.assertNotEqual(self.client.get(self.url).status_code,200)
        self.assertNotEqual(self.client.post(self.read_url).status_code,302)
        self.own.refresh_from_db();self.assertIsNone(self.own.read_at)
    def test_unauthenticated_does_not_read_notifications(self):
        self.client.logout()
        self.assertEqual(self.client.get(self.url).status_code,302)
        self.assertEqual(self.client.post(self.read_url).status_code,302)
    def test_wrong_methods_are_rejected(self):
        self.assertEqual(self.client.post(self.url).status_code,405)
        self.assertEqual(self.client.get(self.read_url).status_code,405)
    def test_eligible_other_not_blocked_by_revoked_account(self):
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        self.client.force_login(self.other)
        response=self.client.get(self.url)
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'Never show this.')
        self.assertNotContains(response,'For you only.')

"""Django integration tests for FIX4 auth rate limits and privilege boundaries.

Requires actual Django + project dependencies; does not modify production users.
"""
from unittest.mock import patch

import pyotp
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase, override_settings
from django.urls import reverse

from academy.models import PlatformSettings


@override_settings(MAILERS={'default':{'BACKEND':'django.core.mail.backends.locmem.EmailBackend'}})
class LoginFix4IntegrationTests(TestCase):
    def setUp(self):
        cache.clear()
        User = get_user_model()
        self.user = User.objects.create_user(
            username='fix4learner', email='fix4learner@example.test', password='UniquePassword#FIX4-2026'
        )
        profile = self.user.learning_profile
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.save(update_fields=['onboarding_completed', 'placement_completed'])

    def assert_form_429(self, response, marker, wait):
        self.assertEqual(response.status_code, 429)
        self.assertEqual(response['Retry-After'], str(wait))
        self.assertIn('no-store', response['Cache-Control'])
        self.assertContains(response, 'csrfmiddlewaretoken', status_code=429)
        self.assertContains(response, 'auth-error-summary', status_code=429)
        self.assertContains(response, marker, status_code=429)

    def test_mfa_throttling_renders_accessible_form_not_raw_text(self):
        profile = self.user.learning_profile
        profile.totp_secret = pyotp.random_base32()
        profile.save(update_fields=['totp_secret'])
        first = self.client.post(reverse('login'), {
            'email': self.user.username, 'password': 'UniquePassword#FIX4-2026',
        })
        self.assertEqual(first.status_code, 302)
        with patch('academy.views.rate_limit_exceeded',
                   side_effect=lambda request, name, *args, **kwargs: name == 'mfa'):
            response = self.client.post(reverse('mfa_verify'), {'code': '000000'})
        self.assert_form_429(response, 'name="code"', 900)
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_mfa_setup_throttling_preserves_qr_and_form(self):
        self.client.force_login(self.user)
        with patch('academy.views.rate_limit', side_effect=lambda request, name, *args, **kwargs: name == 'mfa-setup'):
            response = self.client.post(reverse('mfa_setup'), {'code': '000000'})
        self.assert_form_429(response, 'name="code"', 900)
        self.assertContains(response, 'lm32-mfa-qr', status_code=429)
        self.user.learning_profile.refresh_from_db()
        self.assertFalse(self.user.learning_profile.totp_secret)

    def test_email_reset_throttling_renders_recovery_form(self):
        with patch('academy.views.rate_limit', side_effect=lambda request, name, *args, **kwargs: name == 'reset-password'):
            response = self.client.post(reverse('password_reset'), {'email': self.user.email})
        self.assert_form_429(response, 'name="email"', 3600)

    def test_resend_verification_throttling_renders_form(self):
        with patch('academy.views.rate_limit', side_effect=lambda request, name, *args, **kwargs: name == 'resend-email'):
            response = self.client.post(reverse('resend_verification'), {'email': self.user.email})
        self.assert_form_429(response, 'name="email"', 3600)

    def test_registration_throttling_renders_form(self):
        site = PlatformSettings.load()
        site.public_registration_enabled = True
        site.save(update_fields=['public_registration_enabled'])
        with patch('academy.views.rate_limit', side_effect=lambda request, name, *args, **kwargs: name == 'register'):
            response = self.client.post(reverse('register'), {
                'username': 'anotherfix4', 'email': 'anotherfix4@example.test',
                'password1': 'GoodPass8-2026!', 'password2': 'GoodPass8-2026!', 'age_confirmed': 'on',
            })
        self.assert_form_429(response, 'name="password1"', 3600)
        self.assertFalse(get_user_model().objects.filter(username='anotherfix4').exists())

    def test_superuser_without_staff_cannot_disable_mfa(self):
        self.user.is_superuser = True
        self.user.is_staff = False
        self.user.save(update_fields=['is_superuser', 'is_staff'])
        profile = self.user.learning_profile
        secret = pyotp.random_base32()
        profile.totp_secret = secret
        profile.save(update_fields=['totp_secret'])
        self.client.force_login(self.user)
        response = self.client.post(reverse('mfa_disable'), {'code': pyotp.TOTP(secret).now()})
        self.assertEqual(response.status_code, 403)
        profile.refresh_from_db()
        self.assertEqual(profile.totp_secret, secret)

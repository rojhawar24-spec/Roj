"""Django integration regression suite for the complete authentication experience.

Requires installed requirements and an isolated TEST database. Does not contact
real SMTP or payment providers; never run against production user data.
"""
import hmac
import hashlib
import re
from smtplib import SMTPException
from unittest.mock import patch
from urllib.parse import urlsplit

import pyotp
from django.contrib.auth import get_user_model
from django.core import mail
from django.core.cache import cache
from django.test import TestCase, override_settings
from django.urls import reverse

from academy.models import PlatformSettings

User = get_user_model()


@override_settings(MAILERS={'default':{'BACKEND':'django.core.mail.backends.locmem.EmailBackend'}})
class AccountJourneyV32Tests(TestCase):
    password = 'Long-Secure-Password-For-2026!'

    def setUp(self):
        cache.clear()
        self.user = User.objects.create_user('loginv32', 'loginv32@example.test', self.password)
        profile = self.user.learning_profile
        profile.email_verified_at = __import__('django.utils.timezone',fromlist=['now']).now()
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.save(update_fields=['email_verified_at','onboarding_completed', 'placement_completed'])

    def test_all_recovery_pages_have_brand_privacy_and_lightweight_css(self):
        routes = ('login', 'register', 'resend_verification',
                  'password_reset', 'password_reset_done', 'password_reset_complete')
        for route in routes:
            with self.subTest(page=route):
                response = self.client.get(reverse(route), {'ui': 'ckb'})
                self.assertEqual(response.status_code, 200)
                self.assertContains(response, 'auth-v35-bundle.css')
                self.assertContains(response, 'lang="ckb"')
                self.assertContains(response, 'dir="rtl"')
                self.assertContains(response, 'noindex,nofollow')
                self.assertIn('no-store', response['Cache-Control'])

    def test_password_reset_and_resend_forms_have_accessible_csrf(self):
        for route in ('password_reset', 'resend_verification'):
            with self.subTest(route=route):
                page = self.client.get(reverse(route))
                self.assertContains(page, 'name="csrfmiddlewaretoken"')
                self.assertContains(page, 'type="email"')
                self.assertContains(page, '<label')
                self.assertContains(page, 'name="email"')

    def test_reset_request_does_not_disclose_unknown_address(self):
        response = self.client.post(reverse('password_reset'), {'email': 'does-not-exist@example.test'})
        self.assertRedirects(response, reverse('password_reset_done'), fetch_redirect_response=False)
        self.assertEqual(len(mail.outbox), 0)

    def test_reset_email_allows_one_password_change(self):
        response = self.client.post(reverse('password_reset'), {'email': self.user.email})
        self.assertRedirects(response, reverse('password_reset_done'), fetch_redirect_response=False)
        self.assertEqual(len(mail.outbox), 1)
        link = re.search(r'https?://[^\s]+/reset/[^\s]+', mail.outbox[0].body)
        self.assertIsNotNone(link)
        path = urlsplit(link.group()).path
        first = self.client.get(path)
        # Django replaces the token in the URL with /set-password/ before display.
        self.assertEqual(first.status_code, 302)
        second = self.client.get(first['Location'])
        self.assertContains(second, 'name="new_password1"')
        changed = self.client.post(first['Location'], {
            'new_password1': 'Another-Unpredictable-Password-2026!',
            'new_password2': 'Another-Unpredictable-Password-2026!',
        })
        self.assertRedirects(changed, reverse('password_reset_complete'), fetch_redirect_response=False)
        self.user.refresh_from_db()
        self.assertTrue(self.user.check_password('Another-Unpredictable-Password-2026!'))

    def test_login_keeps_safe_destination_and_rejects_cross_site(self):
        response = self.client.post(reverse('login'), {
            'email': self.user.username, 'password': self.password, 'next': '/grammar/',
        })
        self.assertRedirects(response, '/grammar/', fetch_redirect_response=False)
        self.client.logout()
        response = self.client.post(reverse('login'), {
            'email': self.user.email, 'password': self.password, 'next': '//phishing.invalid/',
        })
        self.assertEqual(response.status_code, 302)
        self.assertNotIn('phishing.invalid', response['Location'])

    def test_logout_must_be_post_and_keep_locale_only(self):
        self.client.get(reverse('login'), {'ui': 'ckb'})
        self.client.post(reverse('login'), {'email': self.user.email, 'password': self.password})
        self.assertEqual(self.client.get(reverse('logout')).status_code, 405)
        signed_out = self.client.post(reverse('logout'))
        self.assertEqual(signed_out.status_code, 302)
        self.assertNotIn('_auth_user_id', self.client.session)
        self.assertEqual(self.client.session['public_ui_language'], 'ckb')

    def test_staff_must_enroll_mfa_before_opening_platform(self):
        self.user.is_staff = True
        self.user.save(update_fields=['is_staff'])
        response = self.client.post(reverse('login'), {'email': self.user.username, 'password': self.password})
        self.assertRedirects(response, reverse('mfa_setup'), fetch_redirect_response=False)
        setup = self.client.get(reverse('mfa_setup'))
        self.assertEqual(setup.status_code, 200)
        secret = self.client.session['mfa_setup_secret']
        self.assertContains(setup, 'name="code"')
        self.assertContains(setup, 'auth-flow-v32.css')
        verified = self.client.post(reverse('mfa_setup'), {'code': pyotp.TOTP(secret).now(), 'password': self.password})
        self.assertRedirects(verified, reverse('mfa_recovery'), fetch_redirect_response=False)
        self.assertEqual(len(self.client.session['mfa_recovery_codes_once']), 8)
        self.assertEqual(self.client.get(reverse('manager')).status_code, 403)

    def test_manager_mfa_then_manager_without_placement(self):
        self.user.is_staff = True
        self.user.is_superuser = True
        self.user.save(update_fields=['is_staff', 'is_superuser'])
        profile = self.user.learning_profile
        profile.totp_secret = pyotp.random_base32()
        profile.onboarding_completed = False
        profile.placement_completed = False
        profile.save(update_fields=['totp_secret', 'onboarding_completed', 'placement_completed'])
        first = self.client.post(reverse('login'), {'email': self.user.username, 'password': self.password})
        self.assertRedirects(first, reverse('mfa_verify'), fetch_redirect_response=False)
        second = self.client.post(reverse('mfa_verify'), {'code': pyotp.TOTP(profile.totp_secret).now()})
        self.assertRedirects(second, reverse('manager'), fetch_redirect_response=False)
        self.assertEqual(self.client.get(reverse('manager')).status_code, 200)

    def test_mfa_cannot_reuse_a_totp_step(self):
        profile = self.user.learning_profile
        profile.totp_secret = pyotp.random_base32()
        profile.save(update_fields=['totp_secret'])
        self.client.post(reverse('login'), {'email': self.user.email, 'password': self.password})
        code = pyotp.TOTP(profile.totp_secret).now()
        first = self.client.post(reverse('mfa_verify'), {'code': code})
        self.assertEqual(first.status_code, 302)
        self.client.post(reverse('logout'))
        self.client.post(reverse('login'), {'email': self.user.email, 'password': self.password})
        second = self.client.post(reverse('mfa_verify'), {'code': code})
        self.assertEqual(second.status_code, 200)
        self.assertContains(second, 'auth-error-summary')

    def test_mfa_recovery_code_consumed_once(self):
        profile = self.user.learning_profile
        profile.totp_secret = pyotp.random_base32()
        recovery = 'A1B2C3D4E5F6A7B8'
        from django.conf import settings
        digest = hmac.new(settings.SECRET_KEY.encode(), recovery.encode(), hashlib.sha256).hexdigest()
        profile.mfa_recovery_hashes = [digest]
        profile.save(update_fields=['totp_secret', 'mfa_recovery_hashes'])
        self.client.post(reverse('login'), {'email': self.user.email, 'password': self.password})
        self.assertEqual(self.client.post(reverse('mfa_verify'), {'code': recovery}).status_code, 302)
        self.client.post(reverse('logout'))
        self.client.post(reverse('login'), {'email': self.user.email, 'password': self.password})
        self.assertEqual(self.client.post(reverse('mfa_verify'), {'code': recovery}).status_code, 200)

    def test_registration_duplicate_identifier_is_not_an_error_or_reactivation(self):
        settings = PlatformSettings.load()
        settings.public_registration_enabled = True
        settings.save(update_fields=['public_registration_enabled'])
        data = {'username': 'differentloginv32', 'email': self.user.email,
                'password1': self.password, 'password2': self.password, 'age_confirmed': 'on'}
        response = self.client.post(reverse('register'), data)
        self.assertRedirects(response, reverse('login'), fetch_redirect_response=False)
        self.user.refresh_from_db()
        self.assertTrue(self.user.is_active)
        self.assertEqual(User.objects.filter(email__iexact=self.user.email).count(), 1)

    def test_reset_mail_outage_has_same_public_outcome(self):
        """SMTP outages must not disclose which address exists via HTTP 500."""
        with patch('django.contrib.auth.forms.PasswordResetForm.send_mail', side_effect=SMTPException('offline')):
            response = self.client.post(reverse('password_reset'), {'email': self.user.email})
        self.assertRedirects(response, reverse('password_reset_done'), fetch_redirect_response=False)

    def test_registration_mail_outage_does_not_disclose_creation(self):
        settings = PlatformSettings.load()
        settings.public_registration_enabled = True
        settings.save(update_fields=['public_registration_enabled'])
        data = {'username': 'freshloginv32', 'email': 'freshloginv32@example.test',
                'password1': self.password, 'password2': self.password, 'age_confirmed': 'on'}
        with patch('academy.views.send_mail', side_effect=SMTPException('offline')):
            response = self.client.post(reverse('register'), data)
        self.assertRedirects(response, reverse('onboarding'), fetch_redirect_response=False)
        user = User.objects.get(username='freshloginv32')
        self.assertTrue(user.is_active)
        self.assertTrue(self.client.get(reverse('resend_verification')).status_code == 200)

    def test_superuser_without_staff_flag_must_enroll_mfa(self):
        """Even unusual legacy superusers must not reach manager without 2FA."""
        self.user.is_superuser = True
        self.user.is_staff = False
        self.user.save(update_fields=['is_superuser', 'is_staff'])
        response = self.client.post(reverse('login'), {'email': self.user.username, 'password': self.password})
        self.assertRedirects(response, reverse('mfa_setup'), fetch_redirect_response=False)
        self.assertEqual(self.client.get(reverse('manager')).status_code, 403)

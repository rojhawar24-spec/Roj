"""Real Django integration tests: run only against a disposable test database."""
from unittest.mock import patch

import pyotp
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.utils import timezone

from .models import Profile


class SecureAdminRevocationTests(TestCase):
    def setUp(self):
        cache.clear()
        self.owner = get_user_model().objects.create_superuser(
            username='step13owner', email='owner13@example.invalid', password='Owner-Step13-Only!')
        profile = self.owner.learning_profile
        profile.email_verified_at = timezone.now()
        profile.totp_secret = pyotp.random_base32()
        profile.save(update_fields=['email_verified_at', 'totp_secret'])
        self.client.force_login(self.owner)
        session = self.client.session
        session['mfa_verified_id'] = self.owner.pk
        session.save()

    def test_valid_mfa_verified_owner_can_open_admin(self):
        self.assertEqual(self.client.get('/secure-admin/').status_code, 200)

    def test_revocations_take_effect_without_logout(self):
        profile = Profile.objects.get(user=self.owner)
        for field, invalid in [('email_verified_at', None), ('legacy_review_required', True),
                               ('suspended_at', timezone.now()), ('totp_secret', '')]:
            with self.subTest(field=field):
                old = getattr(profile, field)
                setattr(profile, field, invalid)
                profile.save(update_fields=[field])
                self.assertEqual(self.client.get('/secure-admin/').status_code, 302)
                setattr(profile, field, old)
                profile.save(update_fields=[field])
                self.assertEqual(self.client.get('/secure-admin/').status_code, 200)

    def test_stale_mfa_session_does_not_grant_admin(self):
        session = self.client.session
        session['mfa_verified_id'] = -1
        session.save()
        self.assertEqual(self.client.get('/secure-admin/').status_code, 302)


class AccountDeletionThrottleTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = get_user_model().objects.create_user('step13learner', 'learner13@example.invalid', 'Learner-Step13-Only!')
        self.client.force_login(self.user)

    def test_five_bad_passwords_prevent_sixth_good_delete_attempt(self):
        for _ in range(5):
            self.assertEqual(self.client.post('/account/delete/', {'password': 'wrong'}).status_code, 200)
        blocked = self.client.post('/account/delete/', {'password': 'Learner-Step13-Only!'})
        self.assertEqual(blocked.status_code, 429)
        self.assertEqual(blocked['Retry-After'], '900')
        self.assertTrue(get_user_model().objects.filter(pk=self.user.pk).exists())
        cache.clear()
        self.assertEqual(self.client.post('/account/delete/', {'password': 'Learner-Step13-Only!'}).status_code, 302)
        self.assertFalse(get_user_model().objects.filter(pk=self.user.pk).exists())

    def test_cache_unavailable_prevents_account_deletion(self):
        with patch('academy.services.cache.get', side_effect=RuntimeError('test cache down')):
            response = self.client.post('/account/delete/', {'password': 'Learner-Step13-Only!'})
        self.assertEqual(response.status_code, 429)
        self.assertTrue(get_user_model().objects.filter(pk=self.user.pk).exists())

    def test_account_delete_response_not_cached(self):
        response = self.client.get('/account/delete/')
        self.assertEqual(response.status_code, 200)
        self.assertIn('no-store', response['Cache-Control'])

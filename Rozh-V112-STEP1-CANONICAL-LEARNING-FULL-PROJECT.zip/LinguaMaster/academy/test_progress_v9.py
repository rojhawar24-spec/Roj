"""Boundary checks for learner calendars, idempotent rewards and private preferences."""
from datetime import date, datetime, timezone as utc_timezone
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase

from .models import Assessment, DailyChest, Language, Level, Profile, Unit, XPEvent
from .progress_models import LearningPreferences
from .progress_v9 import dashboard_progress
from .services import allowed_unit, award_xp, current_streak, daily_xp, learning_day_bounds, user_localdate


class ProgressV9Tests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = get_user_model().objects.create_user('learner', 'learner@example.org', 'StrongPassword!2026')
        self.preferences = LearningPreferences.objects.create(user=self.user, timezone_name='America/Los_Angeles')

    def moment(self, year, month, day, hour=12, minute=0):
        return datetime(year, month, day, hour, minute, tzinfo=utc_timezone.utc)

    def test_learner_calendar_uses_local_date_instead_of_server_date(self):
        now = self.moment(2026, 11, 7, 1)
        self.assertEqual(user_localdate(self.user, now), date(2026, 11, 6))
        with patch('academy.services.timezone.now', return_value=now):
            award_xp(self.user, 20, event_key='first')
        profile = Profile.objects.get(user=self.user)
        self.assertEqual(profile.last_active_day, date(2026, 11, 6))
        self.assertEqual(profile.streak, 1)

    def test_two_rewards_crossing_utc_midnight_do_not_extend_same_local_day(self):
        with patch('academy.services.timezone.now', return_value=self.moment(2026, 11, 6, 23, 55)):
            award_xp(self.user, 20, event_key='one')
        with patch('academy.services.timezone.now', return_value=self.moment(2026, 11, 7, 0, 5)):
            award_xp(self.user, 20, event_key='two')
        self.assertEqual(Profile.objects.get(user=self.user).streak, 1)

    def test_local_midnight_extends_streak_even_on_same_utc_day(self):
        with patch('academy.services.timezone.now', return_value=self.moment(2026, 11, 7, 7, 59)):
            award_xp(self.user, 20, event_key='before')
        with patch('academy.services.timezone.now', return_value=self.moment(2026, 11, 7, 8, 1)):
            award_xp(self.user, 20, event_key='after')
        profile = Profile.objects.get(user=self.user)
        self.assertEqual(profile.streak, 2)
        self.assertEqual(profile.last_active_day, date(2026, 11, 7))
        self.preferences.refresh_from_db()
        self.assertEqual(self.preferences.longest_streak, 2)

    def test_duplicate_event_does_not_extend_streak_or_add_xp_on_later_day(self):
        with patch('academy.services.timezone.now', return_value=self.moment(2026, 11, 6)):
            self.assertTrue(award_xp(self.user, 20, event_key='same'))
        with patch('academy.services.timezone.now', return_value=self.moment(2026, 11, 7)):
            self.assertFalse(award_xp(self.user, 20, event_key='same'))
        profile = Profile.objects.get(user=self.user)
        self.assertEqual((profile.xp, profile.streak), (20, 1))
        self.assertEqual(XPEvent.objects.filter(user=self.user).count(), 1)

    def test_missed_day_displays_zero_and_preserves_longest_on_restart(self):
        Profile.objects.filter(user=self.user).update(streak=8, last_active_day=date(2026, 11, 3))
        summary = dashboard_progress(self.user, now=self.moment(2026, 11, 6))
        self.assertEqual(summary['current_streak'], 0)
        self.assertEqual(summary['longest_streak'], 8)
        with patch('academy.services.timezone.now', return_value=self.moment(2026, 11, 6)):
            award_xp(self.user, 20, event_key='restart')
        self.preferences.refresh_from_db()
        self.assertEqual(self.preferences.longest_streak, 8)
        self.assertEqual(Profile.objects.get(user=self.user).streak, 1)

    def test_yesterday_streak_remains_current_until_today_is_missed(self):
        profile = Profile.objects.get(user=self.user)
        profile.streak = 4
        profile.last_active_day = date(2026, 11, 5)
        self.assertEqual(current_streak(profile, today=date(2026, 11, 6)), 4)
        self.assertEqual(current_streak(profile, today=date(2026, 11, 7)), 0)

    def test_daily_xp_and_calendar_exclude_chests_and_other_learners(self):
        today = date(2026, 11, 6)
        XPEvent.objects.create(user=self.user, reason='lesson', amount=20, event_key='inside', created_at=self.moment(2026, 11, 7, 1))
        XPEvent.objects.create(user=self.user, reason='chest', amount=10, event_key='gift', created_at=self.moment(2026, 11, 6, 12))
        XPEvent.objects.create(user=self.user, reason='lesson', amount=30, event_key='nextday', created_at=self.moment(2026, 11, 7, 9))
        other = get_user_model().objects.create_user('other')
        XPEvent.objects.create(user=other, reason='lesson', amount=50, event_key='other', created_at=self.moment(2026, 11, 6))
        self.assertEqual(daily_xp(self.user, today), 20)
        summary = dashboard_progress(self.user, now=self.moment(2026, 11, 7, 2))
        self.assertEqual(summary['daily_earned'], 20)
        self.assertEqual(summary['weekly_xp'], 20)
        self.assertEqual(len(summary['calendar']), 7)
        self.assertTrue(summary['calendar'][-1]['goal_met'])

    def test_daylight_saving_days_have_correct_utc_window(self):
        start, end = learning_day_bounds(self.user, date(2026, 11, 1))
        self.assertEqual((end.astimezone(utc_timezone.utc) - start.astimezone(utc_timezone.utc)).total_seconds(), 25 * 3600)
        start, end = learning_day_bounds(self.user, date(2026, 3, 8))
        self.assertEqual((end.astimezone(utc_timezone.utc) - start.astimezone(utc_timezone.utc)).total_seconds(), 23 * 3600)

    def test_nonlearning_reward_never_starts_a_streak(self):
        award_xp(self.user, 10, reason='chest', event_key='chest', learning=False)
        profile = Profile.objects.get(user=self.user)
        self.assertEqual(profile.streak, 0)
        self.assertIsNone(profile.last_active_day)


class CEFRProgressionV9Tests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user('path-learner')
        self.language = Language.objects.create(name='Dutch', code='nl', slug='dutch-path', description='Dutch', is_published=True)
        self.a0 = Level.objects.create(language=self.language, code='A0', description='Starter', order=0)
        self.a1 = Level.objects.create(language=self.language, code='A1', description='Beginner', order=1)
        self.b1 = Level.objects.create(language=self.language, code='B1', description='Independent', order=3)
        self.first = Unit.objects.create(level=self.a0, slug='first', title='First', summary='First', published=True)
        self.next = Unit.objects.create(level=self.a1, slug='next', title='Next', summary='Next', published=True)
        self.higher = Unit.objects.create(level=self.b1, slug='higher', title='Higher', summary='Higher', published=True)
        profile = self.user.learning_profile
        profile.preferred_language = self.language
        profile.placement_completed = True
        profile.save()

    def test_higher_band_requires_previous_published_level_test(self):
        self.assertTrue(allowed_unit(self.user, self.first))
        self.assertFalse(allowed_unit(self.user, self.next))
        Assessment.objects.create(user=self.user, kind='level', level=self.a0, passed=False, score=20)
        self.assertFalse(allowed_unit(self.user, self.next))
        Assessment.objects.create(user=self.user, kind='level', level=self.a0, passed=True, score=100)
        self.assertTrue(allowed_unit(self.user, self.next))
        # The course has no A2; its preceding published band is A1.
        self.assertFalse(allowed_unit(self.user, self.higher))
        Assessment.objects.create(user=self.user, kind='level', level=self.a1, passed=True, score=100)
        self.assertTrue(allowed_unit(self.user, self.higher))

    def test_placement_opens_band_but_preserves_unit_prerequisites(self):
        profile = self.user.learning_profile
        profile.placement_level = 'B1'
        profile.save(update_fields=['placement_level'])
        self.assertTrue(allowed_unit(self.user, self.higher))
        later = Unit.objects.create(level=self.b1, slug='later', title='Later', summary='Later', published=True)
        later.prerequisites.add(self.higher)
        self.assertFalse(allowed_unit(self.user, later))
        Assessment.objects.create(user=self.user, kind='unit', unit=self.higher, passed=True, score=100)
        self.assertTrue(allowed_unit(self.user, later))

    def test_other_course_placement_and_other_users_test_cannot_unlock_band(self):
        other_language = Language.objects.create(name='French', code='fr', slug='french-path', description='French', is_published=True)
        profile = self.user.learning_profile
        profile.preferred_language = other_language
        profile.placement_level = 'C1'
        profile.save()
        other = get_user_model().objects.create_user('other-path')
        Assessment.objects.create(user=other, kind='level', level=self.a0, passed=True, score=100)
        self.assertFalse(allowed_unit(self.user, self.next))

    def test_single_band_course_remains_accessible_without_nonexistent_prerequisite(self):
        language = Language.objects.create(name='French', code='fr', slug='single-band', description='French', is_published=True)
        level = Level.objects.create(language=language, code='B1', description='Only band', order=0)
        unit = Unit.objects.create(level=level, slug='single', title='Single', summary='Single', published=True)
        profile=self.user.learning_profile
        profile.preferred_language=language
        profile.placement_level='B1'
        profile.save(update_fields=['preferred_language','placement_level'])
        self.assertTrue(allowed_unit(self.user, unit))

    def test_empty_or_unpublished_lower_bands_do_not_block_course(self):
        self.first.published = False
        self.first.save(update_fields=['published'])
        self.assertTrue(allowed_unit(self.user, self.next))

    def test_unit_test_does_not_substitute_for_level_test(self):
        Assessment.objects.create(user=self.user, kind='unit', unit=self.first, passed=True, score=100)
        self.assertFalse(allowed_unit(self.user, self.next))


class ChestCalendarV9Tests(TestCase):
    def test_chest_uses_same_local_learning_day_as_xp(self):
        cache.clear()
        user = get_user_model().objects.create_user('chest-local')
        language = Language.objects.create(name='Dutch', code='nl', slug='chest-calendar-dutch',
                                           description='Dutch', is_published=True)
        profile = user.learning_profile
        profile.preferred_language = language
        profile.placement_completed = True
        profile.save(update_fields=['preferred_language', 'placement_completed'])
        LearningPreferences.objects.create(user=user, timezone_name='America/Los_Angeles')
        self.client.force_login(user)
        now = datetime(2026, 11, 7, 1, tzinfo=utc_timezone.utc)
        XPEvent.objects.create(user=user, reason='lesson', amount=20, event_key='local-learning', created_at=now)
        with patch('academy.services.timezone.now', return_value=now):
            self.assertEqual(self.client.post('/daily-chest/open/').status_code, 302)
            self.assertEqual(self.client.post('/daily-chest/open/').status_code, 302)
        chest = DailyChest.objects.get(user=user)
        self.assertEqual(chest.day, date(2026, 11, 6))
        self.assertEqual(XPEvent.objects.filter(user=user, reason='chest').count(), 1)
        self.assertEqual(Profile.objects.get(user=user).streak, 0)


class PreferencesV9Tests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = get_user_model().objects.create_user('settings', 'settings@example.org', 'StrongPassword!2026')
        self.language = Language.objects.create(name='Dutch', code='nl', slug='dutch-preferences', description='Dutch', is_published=True)
        self.preferences = LearningPreferences.objects.create(user=self.user, timezone_name='Asia/Baghdad', theme='dark', reduce_motion=True)
        self.client.force_login(self.user)

    def profile_values(self):
        return {'avatar': '🎓', 'bio': '', 'ui_language': 'nl', 'daily_goal_xp': 20,
                'preferred_language': self.language.pk}

    def test_old_profile_submission_preserves_new_preferences(self):
        response = self.client.post('/profile/', self.profile_values())
        self.assertEqual(response.status_code, 302)
        self.preferences.refresh_from_db()
        self.assertEqual(self.preferences.timezone_name, 'Asia/Baghdad')
        self.assertEqual(self.preferences.theme, 'dark')
        self.assertTrue(self.preferences.reduce_motion)

    def test_invalid_timezone_does_not_save_profile_or_preferences(self):
        values = self.profile_values()
        values.update({'bio': 'Should not save', 'preferences-timezone_name': '../not-a-zone', 'preferences-theme': 'light'})
        response = self.client.post('/profile/', values)
        self.assertEqual(response.status_code, 200)
        self.assertIn('timezone_name', response.context['preference_form'].errors)
        self.assertEqual(Profile.objects.get(user=self.user).bio, '')
        self.preferences.refresh_from_db()
        self.assertEqual(self.preferences.theme, 'dark')

    def test_valid_timezone_appearance_and_motion_are_saved(self):
        values = self.profile_values()
        values.update({'preferences-timezone_name': 'Europe/Amsterdam', 'preferences-theme': 'system'})
        self.assertEqual(self.client.post('/profile/', values).status_code, 302)
        self.preferences.refresh_from_db()
        self.assertEqual(self.preferences.timezone_name, 'Europe/Amsterdam')
        self.assertEqual(self.preferences.theme, 'system')
        self.assertFalse(self.preferences.reduce_motion)

    def test_appearance_endpoint_changes_only_own_account(self):
        other = get_user_model().objects.create_user('private')
        other_preferences = LearningPreferences.objects.create(user=other, theme='dark')
        response = self.client.post('/profile/appearance/', {'theme': 'light', 'reduce_motion': 'false', 'user_id': other.pk})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {'theme': 'light', 'reduce_motion': False})
        other_preferences.refresh_from_db()
        self.assertEqual(other_preferences.theme, 'dark')

    def test_appearance_requires_valid_choice_and_login(self):
        self.assertEqual(self.client.post('/profile/appearance/', {'theme': '<script>'}).status_code, 400)
        self.assertEqual(self.client.post('/profile/appearance/', {'theme': 'light', 'reduce_motion': 'maybe'}).status_code, 400)
        self.client.logout()
        self.assertEqual(self.client.post('/profile/appearance/', {'theme': 'light'}).status_code, 302)

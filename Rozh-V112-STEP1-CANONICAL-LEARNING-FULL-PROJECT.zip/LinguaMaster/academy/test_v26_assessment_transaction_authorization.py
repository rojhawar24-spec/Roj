"""V26 real-Django HTTP tests. Must run against an isolated QA test database.

Authoring environment has no Django; tests are provided, NOT claimed passed.
"""
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse

from .models import (Assessment, Certificate, Exercise, Language, Lesson,
                     LessonProgress, Level, MistakeRecord, Profile, Unit, XPEvent)


class AssessmentTransactionAuthorizationV26Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            username='v26_student', email='v26student@example.invalid',
            password='V26-Disposable-QA-Only-Strong!')
        cls.dutch = Language.objects.create(code='nl', name='Dutch', slug='v26-dutch', is_published=True)
        cls.french = Language.objects.create(code='fr', name='French', slug='v26-french', is_published=True)
        cls.level = Level.objects.create(language=cls.dutch, code='A0', order=0)
        cls.unit = Unit.objects.create(level=cls.level, slug='v26-unit', title='V26 Unit',
                                       summary='Assessment test', order=1, published=True)
        cls.lesson = Lesson.objects.create(unit=cls.unit, slug='v26-lesson', title='V26 Lesson',
                                          skill='grammar', content='Assessment', published=True)
        cls.question = Exercise.objects.create(lesson=cls.lesson, kind='mcq', prompt='Say yes',
                                               options=['Yes', 'No'], answer='Yes', explanation='Answer is Yes')
        LessonProgress.objects.create(user=cls.user, lesson=cls.lesson, score=100)
        Profile.objects.filter(user=cls.user).update(
            preferred_language=cls.dutch, placement_completed=True,
            onboarding_required=True, onboarding_completed=True, placement_level='A0')

    def setUp(self):
        cache.clear()
        self.client.force_login(self.user)

    def _post(self, kind='unit'):
        route = 'assessment_unit' if kind == 'unit' else 'assessment_level'
        pk = self.unit.pk if kind == 'unit' else self.level.pk
        return self.client.post(reverse(route, args=[pk]), {f'q_{self.question.pk}': 'Yes'})

    def _during_grade(self, change, kind='unit'):
        def grade_with_change(question, response):
            change()
            return str(response or '').casefold() == question.answer.casefold()
        with patch('academy.views.grade', side_effect=grade_with_change):
            return self._post(kind)

    def _assert_no_assessment_writes(self):
        self.assertFalse(Assessment.objects.filter(user=self.user).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user, reason='assessment').exists())
        self.assertFalse(Certificate.objects.filter(user=self.user).exists())
        self.assertFalse(MistakeRecord.objects.filter(user=self.user).exists())
        self.assertEqual(Profile.objects.get(user=self.user).xp, 0)

    def test_valid_unit_submission_awards_xp(self):
        self.assertEqual(self._post().status_code, 200)
        self.assertEqual(Assessment.objects.filter(user=self.user, kind='unit', passed=True).count(), 1)
        self.assertEqual(Profile.objects.get(user=self.user).xp, 40)

    def test_fill_blank_only_unit_accepts_editor_variant(self):
        Exercise.objects.filter(pk=self.question.pk).update(
            kind='fill_blank', prompt='Ik ___ hier.', options=[], answer='woon',
            activity_data={'accepted_answers':['werk']}, explanation='Both are possible.')
        url = reverse('assessment_unit', args=[self.unit.pk])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'class="app-assessment-text"')
        self.assertNotContains(response, 'accepted_answers')
        response = self.client.post(url, {f'q_{self.question.pk}':'werk'})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(Assessment.objects.filter(user=self.user, passed=True, score=100).exists())

    def test_v104_matching_assessment_snapshot_and_permutation(self):
        import json
        from .assessment_policy_v103 import assessment_rows
        from .lesson_activities_v58 import is_correct
        self.question.kind = 'word_matching'
        self.question.prompt = 'Match the words.'
        self.question.options = []
        self.question.answer = ''
        self.question.activity_data = {'pairs':[{'left':'huis','right':'house'}, {'left':'kat','right':'cat'}]}
        self.question.save()
        url = reverse('assessment_unit', args=[self.unit.pk])
        response = self.client.get(url)
        self.assertEqual(response.status_code,200)
        rows = assessment_rows(self.question)
        values = [0,1] if is_correct(self.question, '[0,1]') else [1,0]
        payload = {row['name']:str(i) for row,i in zip(rows,values)}
        self.assertEqual(self.client.post(url,payload).status_code,409)
        self._assert_no_assessment_writes()
        payload['assessment_snapshot'] = response.context['assessment_snapshot']
        invalid = dict(payload); invalid[rows[1]['name']] = invalid[rows[0]['name']]
        self.assertEqual(self.client.post(url,invalid).status_code,400)
        self._assert_no_assessment_writes()
        Exercise.objects.filter(pk=self.question.pk).update(prompt='Updated prompt')
        self.assertEqual(self.client.post(url,payload).status_code,409)
        self._assert_no_assessment_writes()
        payload['assessment_snapshot'] = self.client.get(url).context['assessment_snapshot']
        self.assertEqual(self.client.post(url,payload).status_code,200)
        self.assertTrue(Assessment.objects.filter(user=self.user,score=100,passed=True).exists())

    def test_options_changed_during_grade_rejects_submission(self):
        response = self._during_grade(lambda: Exercise.objects.filter(pk=self.question.pk)
                                      .update(options=['Yes','Maybe']))
        self.assertEqual(response.status_code, 409)
        self._assert_no_assessment_writes()

    def test_incomplete_or_forged_submission_never_records_attempt(self):
        url = reverse('assessment_unit', args=[self.unit.pk])
        for data in ({}, {f'q_{self.question.pk}':'forged'}, {f'q_{self.question.pk}':['Yes','No']}):
            self.assertEqual(self.client.post(url,data).status_code,400)
            self._assert_no_assessment_writes()

    def test_duplicate_unit_submission_awards_only_once(self):
        self.assertEqual(self._post().status_code, 200)
        self.assertEqual(self._post().status_code, 200)
        self.assertEqual(Assessment.objects.filter(user=self.user, kind='unit').count(), 2)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='assessment').count(), 1)
        self.assertEqual(Profile.objects.get(user=self.user).xp, 40)

    def test_course_switched_while_grading_denies_unit(self):
        response = self._during_grade(lambda: Profile.objects.filter(user=self.user)
                                      .update(preferred_language=self.french))
        self.assertEqual(response.status_code, 403)
        self._assert_no_assessment_writes()

    def test_onboarding_revoked_while_grading_denies_unit(self):
        response = self._during_grade(lambda: Profile.objects.filter(user=self.user)
                                      .update(onboarding_completed=False))
        self.assertEqual(response.status_code, 403)
        self._assert_no_assessment_writes()

    def test_placement_revoked_while_grading_denies_unit(self):
        response = self._during_grade(lambda: Profile.objects.filter(user=self.user)
                                      .update(placement_completed=False))
        self.assertEqual(response.status_code, 403)
        self._assert_no_assessment_writes()

    def test_unit_unpublished_while_grading_denies_unit(self):
        response = self._during_grade(lambda: Unit.objects.filter(pk=self.unit.pk)
                                      .update(published=False))
        self.assertEqual(response.status_code, 403)
        self._assert_no_assessment_writes()

    def test_course_unpublished_while_grading_denies_unit(self):
        response = self._during_grade(lambda: Language.objects.filter(pk=self.dutch.pk)
                                      .update(is_published=False))
        self.assertEqual(response.status_code, 403)
        self._assert_no_assessment_writes()

    def test_lesson_unpublished_while_grading_rejects_stale_questions(self):
        response = self._during_grade(lambda: Lesson.objects.filter(pk=self.lesson.pk)
                                      .update(published=False))
        # A withdrawn last required lesson also revokes unit-test eligibility.
        self.assertEqual(response.status_code, 403)
        self._assert_no_assessment_writes()

    def test_answer_changed_while_grading_rejects_stale_questions(self):
        response = self._during_grade(lambda: Exercise.objects.filter(pk=self.question.pk)
                                      .update(answer='No'))
        self.assertEqual(response.status_code, 409)
        self._assert_no_assessment_writes()

    def test_question_kind_changed_while_grading_rejects_stale_questions(self):
        response = self._during_grade(lambda: Exercise.objects.filter(pk=self.question.pk)
                                      .update(kind='fill'))
        self.assertEqual(response.status_code, 409)
        self._assert_no_assessment_writes()

    def _passed_unit(self):
        Assessment.objects.create(user=self.user, kind='unit', unit=self.unit, passed=True, score=100)

    def test_valid_level_test_issues_one_certificate(self):
        self._passed_unit()
        self.assertEqual(self._post('level').status_code, 200)
        self.assertEqual(Certificate.objects.filter(user=self.user, level=self.level).count(), 1)
        self.assertEqual(Profile.objects.get(user=self.user).xp, 100)
        self.assertEqual(self._post('level').status_code, 200)
        self.assertEqual(Certificate.objects.filter(user=self.user, level=self.level).count(), 1)
        self.assertEqual(Profile.objects.get(user=self.user).xp, 100)

    def test_course_switch_during_level_grading_denies_certificate(self):
        self._passed_unit()
        response = self._during_grade(lambda: Profile.objects.filter(user=self.user)
                                      .update(preferred_language=self.french), kind='level')
        self.assertEqual(response.status_code, 403)
        self.assertFalse(Assessment.objects.filter(user=self.user, kind='level').exists())
        self.assertFalse(Certificate.objects.filter(user=self.user).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user, reason='assessment').exists())

    def test_level_course_unpublished_during_grading_denies_certificate(self):
        self._passed_unit()
        response = self._during_grade(lambda: Language.objects.filter(pk=self.dutch.pk)
                                      .update(is_published=False), kind='level')
        self.assertEqual(response.status_code, 403)
        self.assertFalse(Certificate.objects.filter(user=self.user).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user, reason='assessment').exists())

    def test_level_question_unpublished_during_grading_rejects_attempt(self):
        self._passed_unit()
        response = self._during_grade(lambda: Lesson.objects.filter(pk=self.lesson.pk)
                                      .update(published=False), kind='level')
        self.assertEqual(response.status_code, 409)
        self.assertFalse(Certificate.objects.filter(user=self.user).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user, reason='assessment').exists())

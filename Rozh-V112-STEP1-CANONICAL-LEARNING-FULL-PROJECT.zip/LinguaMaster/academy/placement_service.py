"""Conservative course starting points, never a validated CEFR assessment."""
from .models import Exercise, LEVELS
from .services import grade


STAGES = [code for code, _ in LEVELS]


def _valid_mcq(question):
    options = question.options
    if not isinstance(options, list) or len(options) < 2:
        return False
    if any(not isinstance(option, str) or not option.strip() for option in options):
        return False
    normalized = [option.strip().casefold() for option in options]
    return len(set(normalized)) == len(options) and question.answer.strip().casefold() in normalized


def placement_questions(language):
    """Sample two usable published MCQs per available stage in this course only.

    A missing selected course never silently samples a different language. Empty
    editor-created levels and unusable questions provide no placement evidence.
    """
    if language is None or not language.is_published:
        return []
    grouped = {stage: [] for stage in STAGES}
    questions = Exercise.objects.filter(
        lesson__unit__level__language=language,
        lesson__unit__level__language__is_published=True,
        lesson__unit__published=True, lesson__published=True, kind='mcq',
    ).select_related('lesson__unit__level__language').order_by('order', 'pk')
    for question in questions:
        group = grouped.get(question.lesson.unit.level.code)
        if group is not None and len(group) < 2 and _valid_mcq(question):
            group.append(question)
    return [question for stage in STAGES for question in grouped[stage]]


def placement_result(questions, answers):
    """Validate a complete submission before estimating the next learning stage.

    Start in the first available sampled stage. Advance to the next consecutive
    stage only when every sampled question in the current stage is correct.
    The highest sampled stage is the ceiling, even for a perfect total score.
    """
    if not questions:
        raise ValueError('No published placement questions')
    expected = {f'q_{question.pk}' for question in questions}
    if {key for key in answers if key.startswith('q_')} != expected:
        raise ValueError('Answer every displayed question before continuing')
    responses = {}
    results = {}
    for question in questions:
        key = f'q_{question.pk}'
        supplied = answers.getlist(key)
        if len(supplied) != 1 or supplied[0] not in question.options:
            raise ValueError('Choose one of the displayed options for every question')
        responses[str(question.pk)] = supplied[0]
        stage = question.lesson.unit.level.code
        results.setdefault(stage, []).append(grade(question, supplied[0]))
    stages = [stage for stage in STAGES if stage in results]
    band = stages[0]
    for current, following in zip(stages, stages[1:]):
        if STAGES.index(following) != STAGES.index(current) + 1 or not all(results[current]):
            break
        band = following
    correct = sum(sum(values) for values in results.values())
    return {'score': round(100 * correct / len(questions)), 'band': band, 'responses': responses}

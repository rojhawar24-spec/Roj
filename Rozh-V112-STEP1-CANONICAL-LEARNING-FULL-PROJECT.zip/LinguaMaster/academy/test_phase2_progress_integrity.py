"""Phase 2 Django integration tests: disposable test DB ONLY.

Never treat these tests as executed without a real Django test-run result.
Run: python scripts/phase2_local_progress_runtime.py
"""
from datetime import datetime, timezone as utc_timezone
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .heart_models import HeartEvent
from .hearts import snapshot
from .journey_v11 import _challenges
from .models import (
    Badge, BadgeAward, Exercise, Language, Lesson, LessonProgress, Level,
    MistakeRecord, PlatformSettings, Profile, Unit, XPEvent,
)
from .progress_models import LearningPreferences


class Phase2StudentProgressTests(TestCase):
    def setUp(self):
        cache.clear()
        User = get_user_model()
        self.user = User.objects.create_user('phase2-student', password='TestingOnly!2026')
        self.other = User.objects.create_user('phase2-other', password='TestingOnly!2026')
        self.lang = Language.objects.create(name='Dutch', code='nl', slug='phase2-dutch',
                                            description='NL', is_published=True)
        self.level = Level.objects.create(language=self.lang, code='A0', description='Start')
        self.unit = Unit.objects.create(level=self.level, slug='phase2-hello', title='Hello',
                                        summary='Study', published=True)
        self.lesson = Lesson.objects.create(unit=self.unit, slug='phase2-lesson', title='Learn Dutch',
                                            skill='grammar', content='Original lesson', published=True)
        profile = self.user.learning_profile
        profile.placement_completed = True
        profile.onboarding_completed = True
        profile.preferred_language = self.lang
        profile.save(update_fields=['placement_completed','onboarding_completed','preferred_language'])
        self.client.force_login(self.user)

    def test_quest_counts_learner_local_day_and_only_published_selected_course(self):
        LearningPreferences.objects.update_or_create(
            user=self.user, defaults={'timezone_name':'America/Los_Angeles'}
        )
        inside = datetime(2026,11,7,1,30,tzinfo=utc_timezone.utc)  # Nov 6, LA
        outside = datetime(2026,11,7,8,30,tzinfo=utc_timezone.utc)  # Nov 7, LA
        LessonProgress.objects.create(user=self.user, lesson=self.lesson, completed_at=inside, score=100)
        next_day = Lesson.objects.create(unit=self.unit, slug='next-day', title='Tomorrow',
                                          skill='reading', content='Tomorrow', published=True)
        LessonProgress.objects.create(user=self.user, lesson=next_day, completed_at=outside, score=100)
        hidden_unit = Unit.objects.create(level=self.level,slug='unpublished',title='Private',
                                          summary='Private',published=False)
        hidden = Lesson.objects.create(unit=hidden_unit,slug='private',title='Hidden',
                                       skill='reading',content='Hidden',published=True)
        LessonProgress.objects.create(user=self.user, lesson=hidden, completed_at=inside, score=100)
        other_lang = Language.objects.create(name='French',code='fr',slug='phase2-fr',
                                             description='FR',is_published=True)
        other_level = Level.objects.create(language=other_lang,code='A0',description='FR')
        other_unit = Unit.objects.create(level=other_level,slug='other-course',title='FR',
                                         summary='FR',published=True)
        foreign = Lesson.objects.create(unit=other_unit,slug='fr',title='FR lesson',
                                        skill='reading',content='FR',published=True)
        LessonProgress.objects.create(user=self.user,lesson=foreign,completed_at=inside,score=100)
        LessonProgress.objects.create(user=self.other,lesson=next_day,completed_at=inside,score=100)
        with patch('academy.services.timezone.now', return_value=inside):
            response = self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.context['NOVA_LESSONS_TODAY'],1)
        self.assertEqual(response.context['NOVA_LESSON_PERCENT'],50)
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_classic_lesson_batch_rolls_back_wrong_heart_and_mistake_when_xp_fails(self):
        questions = []
        for i in range(4):
            questions.append(Exercise.objects.create(
                lesson=self.lesson, kind='mcq', prompt=f'Question {i}',
                options=['Yes','No'], answer='Yes', explanation='A real question'
            ))
        page = self.client.get(reverse('lesson',args=[self.lesson.pk]))
        self.assertEqual(page.status_code,200)
        data = {f'answer_{q.pk}': 'No' if i == 0 else 'Yes' for i,q in enumerate(questions)}
        data['round_key'] = page.context['lesson_round_key']
        with patch('academy.views.award_xp', side_effect=RuntimeError('injected XP write failure')):
            with self.assertRaisesRegex(RuntimeError,'injected XP write failure'):
                self.client.post(reverse('lesson',args=[self.lesson.pk]), data)
        self.assertEqual(snapshot(self.user)['remaining'],5)
        self.assertFalse(HeartEvent.objects.filter(user=self.user).exists())
        self.assertFalse(MistakeRecord.objects.filter(user=self.user).exists())
        self.assertFalse(LessonProgress.objects.filter(user=self.user).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_single_answer_heart_rolls_back_when_mistake_write_fails(self):
        exercise = Exercise.objects.create(lesson=self.lesson, kind='mcq',
                 prompt='Choose hello', options=['Yes','No'], answer='Yes', explanation='Yes')
        page = self.client.get(reverse('lesson',args=[self.lesson.pk]))
        payload = {'exercise_id':exercise.pk,'answer':'No','round_key':page.context['lesson_round_key']}
        with patch('academy.views.record_exercise_result', side_effect=RuntimeError('injected mistake failure')):
            with self.assertRaisesRegex(RuntimeError,'injected mistake failure'):
                self.client.post(reverse('lesson_answer',args=[self.lesson.pk]),payload)
        self.assertEqual(snapshot(self.user)['remaining'],5)
        self.assertFalse(HeartEvent.objects.filter(user=self.user).exists())
        self.assertFalse(MistakeRecord.objects.filter(user=self.user).exists())

    def test_mixed_game_heart_rolls_back_when_mistake_write_fails(self):
        # Code 'zz' deliberately avoids supplementary language-specific photo questions.
        Language.objects.filter(pk=self.lang.pk).update(code='zz')
        Exercise.objects.create(lesson=self.lesson,kind='mcq',prompt='Greeting',
                                options=['Yes','No'],answer='Yes',explanation='Yes')
        page = self.client.get(reverse('journey_play',args=[self.unit.pk]))
        self.assertEqual(page.status_code,200)
        state = self.client.session[f'journey_v11_{self.unit.pk}']
        question = _challenges(self.unit,state['token'])[0]
        self.assertEqual(question['type'],'mcq')
        wrong = next(option for option in question['options'] if option != question['answer'])
        with patch('academy.journey_v11.record_exercise_result',side_effect=RuntimeError('injected error')):
            with self.assertRaisesRegex(RuntimeError,'injected error'):
                self.client.post(reverse('journey_answer',args=[self.unit.pk]),{
                    'round_token':state['token'],'challenge_id':question['id'],'answer':wrong
                },HTTP_X_REQUESTED_WITH='XMLHttpRequest')
        self.assertEqual(snapshot(self.user)['remaining'],5)
        self.assertFalse(HeartEvent.objects.filter(user=self.user).exists())
        self.assertEqual(self.client.session[f'journey_v11_{self.unit.pk}']['position'],0)
        self.assertFalse(LessonProgress.objects.filter(user=self.user).exists())


class Phase2ManagerAtomicityTests(TestCase):
    def setUp(self):
        cache.clear()
        User = get_user_model()
        self.owner=User.objects.create_superuser('phase2-owner','owner2@example.invalid','TestingOwner!2026')
        self.student=User.objects.create_user('phase2-awardee',password='TestingStudent!2026')
        profile=self.owner.learning_profile
        profile.email_verified_at=timezone.now()
        profile.totp_secret='JBSWY3DPEHPK3PXP'
        profile.save(update_fields=['email_verified_at','totp_secret'])
        self.client.force_login(self.owner)
        session=self.client.session
        session['mfa_verified_id']=self.owner.pk
        session.save()

    def test_award_and_audit_are_rolled_back_together(self):
        badge=Badge.objects.create(slug='phase2-test-badge',name='Test Badge',
                                   description='Integrity',tier='gold')
        with patch('academy.views.audit', side_effect=RuntimeError('injected audit failure')):
            with self.assertRaisesRegex(RuntimeError,'injected audit failure'):
                self.client.post(reverse('manager_award'), {
                    'user_id':self.student.pk, 'action':'grant',
                    'award_target':f'badge:{badge.pk}', 'reason':'Test-only grant'
                })
        self.assertFalse(BadgeAward.objects.filter(user=self.student,badge=badge).exists())

    def test_manager_ai_toggle_and_audit_are_rolled_back_together(self):
        settings = PlatformSettings.load()
        previous = (settings.ai_enabled, settings.ai_emergency_stop)
        form_data = {
            'ai_enabled':'', 'ai_emergency_stop':'',
            'ai_daily_limit':str(settings.ai_daily_limit),
            'ai_monthly_limit':str(settings.ai_monthly_limit),
            'ai_monthly_budget_eur':str(settings.ai_monthly_budget_eur),
            'ai_input_eur_per_million':str(settings.ai_input_eur_per_million),
            'ai_output_eur_per_million':str(settings.ai_output_eur_per_million),
            'ai_moderation_reserve_eur':str(settings.ai_moderation_reserve_eur),
            'organization_name':settings.organization_name,
            'privacy_email':settings.privacy_email,
            'public_registration_enabled':'on',
        }
        with patch('academy.views.audit',side_effect=RuntimeError('injected manager audit failure')):
            with self.assertRaisesRegex(RuntimeError,'injected manager audit failure'):
                self.client.post(reverse('manager'),form_data)
        settings.refresh_from_db()
        self.assertEqual((settings.ai_enabled,settings.ai_emergency_stop),previous)

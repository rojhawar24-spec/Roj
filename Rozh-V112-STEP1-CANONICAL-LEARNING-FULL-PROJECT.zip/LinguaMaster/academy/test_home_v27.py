"""V27 Django TestCase tests (run only with installed Django and isolated test database)."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

class HomepageV27IntegrationTests(TestCase):
 def test_guest_home_has_branded_accessible_first_actions(self):
  r=self.client.get(reverse('home'))
  self.assertEqual(r.status_code,200)
  self.assertContains(r,'class="lm23-home lm25-home"')
  self.assertContains(r,'class="lm27-home"')
  self.assertContains(r,'home-v31-bundle.css')
  self.assertContains(r, reverse('login')+'?next='+reverse('play_hub'))
  self.assertContains(r, 'href="'+reverse('grammar_library')+'"')
  self.assertContains(r,reverse('try_lesson'))
 def test_locale_direction_is_still_correct(self):
  for locale, direction in (('nl','ltr'),('en','ltr'),('ckb','rtl'),('ar','rtl')):
   with self.subTest(locale=locale):
    r=self.client.get(reverse('home')+'?ui='+locale, follow=True)
    self.assertContains(r,'lang="'+locale+'"')
    self.assertContains(r,'dir="'+direction+'"')
 def test_authenticated_home_goes_to_real_learning_area(self):
  user=get_user_model().objects.create_user('v27homepage','v27homepage@example.org','StrongPassword!2026')
  profile=user.learning_profile
  profile.onboarding_completed=True
  profile.placement_completed=True
  profile.save(update_fields=['onboarding_completed','placement_completed'])
  self.client.force_login(user)
  self.assertRedirects(self.client.get(reverse('home')),reverse('play_hub'),fetch_redirect_response=False)

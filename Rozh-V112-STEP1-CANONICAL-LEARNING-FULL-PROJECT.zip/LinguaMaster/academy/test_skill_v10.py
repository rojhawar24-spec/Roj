"""Course-scoped, privacy-minimal skills: real server behavior, no paid APIs."""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase

from .models import Language, Level, SkillPracticeAttempt, Vocabulary, XPEvent


class SkillStudioV10Tests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = get_user_model().objects.create_user('studiolearner', 'studio@example.org', 'ValidPassword!123')
        self.language = Language.objects.create(code='nl', name='Dutch', slug='dutch', is_published=True)
        self.level = Level.objects.create(language=self.language, code='A0', order=0)
        self.a1 = Level.objects.create(language=self.language, code='A1', order=1)
        self.first = Vocabulary.objects.create(level=self.level, word='boek', translation='book',
            example='Ik lees een boek in de trein.', published=True)
        self.second = Vocabulary.objects.create(level=self.level, word='huis', translation='house',
            example='Dit is een huis naast het station.', published=True)
        self.higher = Vocabulary.objects.create(level=self.a1, word='fiets', translation='bicycle',
            example='Ik fiets elke dag naar mijn werk.', published=True)
        self.hidden = Vocabulary.objects.create(level=self.level, word='geheim', translation='secret',
            example='This unpublished example must stay hidden.', published=False)
        profile = self.user.learning_profile
        profile.preferred_language = self.language
        profile.onboarding_completed = profile.placement_completed = True
        profile.save()
        self.client.force_login(self.user)

    def test_listening_exact_transcription_is_private_and_awards_no_xp(self):
        response = self.client.get('/skills/listening/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context['target'], self.first)
        self.assertContains(response, 'data-target-locale="nl-NL"')
        self.assertRegex(response.content.decode(), r'id="v10-transcript"(?![^>]*\bopen\b)[^>]*>')
        answer = '  IK LEES een boek in de trein!  '
        response = self.client.post('/skills/listening/', {'answer': answer, 'source': 'typed', 'prompt_id': self.first.pk})
        self.assertEqual(response.status_code, 200)
        attempt = SkillPracticeAttempt.objects.get()
        self.assertEqual((attempt.kind, attempt.score, attempt.answer_length), ('listening', 100, len(answer)))
        self.assertNotIn(answer, repr(attempt.__dict__))
        self.assertNotIn(answer, repr(dict(self.client.session)))
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())
        self.assertTrue(response.context['result']['correct'])
        # Reloading and re-submitting the same completed round do not rotate or duplicate it.
        self.assertEqual(self.client.get('/skills/listening/').context['target'], self.first)
        self.client.post('/skills/listening/', {'answer':answer, 'source':'typed'})
        self.assertEqual(SkillPracticeAttempt.objects.count(), 1)
        duplicate = self.client.post('/skills/listening/', {'answer':'a different answer', 'source':'typed'})
        self.assertNotContains(duplicate, 'a different answer')
        self.assertEqual(duplicate.context['result']['score'], 100)

    def test_next_and_retry_are_explicit_and_do_not_create_attempts(self):
        self.client.get('/skills/listening/?level=A0')
        self.assertEqual(self.client.get('/skills/listening/?level=A0').context['target'], self.first)
        response = self.client.post('/skills/listening/?level=A0', {'action':'next', 'prompt_id':self.first.pk})
        self.assertEqual(response.context['target'], self.second)
        self.assertFalse(SkillPracticeAttempt.objects.exists())
        response = self.client.post('/skills/listening/?level=A0', {'answer':self.second.example, 'source':'typed'})
        self.assertEqual(response.context['target'], self.second)
        self.assertEqual(self.client.get('/skills/listening/?level=A0').context['target'], self.second)
        response = self.client.post('/skills/listening/?level=A0', {'action':'retry'})
        self.assertIsNone(response.context['result'])
        self.assertEqual(response.context['target'], self.second)
        self.assertEqual(SkillPracticeAttempt.objects.count(), 1)
        self.client.post('/skills/listening/?level=A0', {'action':'next'})
        self.assertEqual(self.client.get('/skills/listening/?level=A0').context['target'], self.first)

    def test_level_filter_only_uses_available_active_course_words(self):
        foreign = Language.objects.create(code='fr', name='French', slug='french', is_published=True)
        foreign_level = Level.objects.create(language=foreign, code='C1')
        Vocabulary.objects.create(level=foreign_level, word='étranger', example='Un exemple étranger.', published=True)
        response = self.client.get('/skills/listening/?level=A1')
        self.assertEqual(response.context['target'], self.higher)
        self.assertEqual(response.context['levels'], ['A0', 'A1'])
        self.assertNotContains(response, 'value="C1"')
        self.assertNotContains(response, self.hidden.example)
        response = self.client.get('/skills/listening/?level=C1')
        self.assertIsNone(response.context['target'])
        self.assertEqual(self.client.get('/skills/listening/?level=INVALID').status_code, 400)

    def test_target_rotates_only_in_new_active_course_and_target_locale_is_dynamic(self):
        self.client.get('/skills/listening/')
        french = Language.objects.create(code='fr', name='French', slug='french', is_published=True)
        french_level = Level.objects.create(language=french, code='A0')
        mot = Vocabulary.objects.create(level=french_level, word='livre', example='Je lis un livre dans le train.', published=True)
        profile = self.user.learning_profile
        profile.preferred_language = french
        profile.save(update_fields=['preferred_language'])
        stale = self.client.post('/skills/listening/', {'answer': self.first.example})
        self.assertEqual(stale.status_code, 409)
        self.assertFalse(SkillPracticeAttempt.objects.exists())
        response = self.client.get('/skills/listening/')
        self.assertEqual(response.context['target'], mot)
        self.assertContains(response, 'data-target-locale="fr-FR"')
        self.assertContains(response, 'lang="fr" dir="ltr"')
        self.language.is_published = False
        self.language.save()
        self.assertNotContains(response, self.first.example)

    def test_invalid_submissions_never_create_attempts(self):
        for kind in ('listening',):
            self.client.get(f'/skills/{kind}/')
            for answer in ('', '   ', '...', 'x' * 2001, 'bad\x00text'):
                response = self.client.post(f'/skills/{kind}/', {'answer': answer})
                self.assertEqual(response.status_code, 400)
        self.assertEqual(self.client.post('/skills/listening/', {'answer':'text','source':'microphone'}).status_code, 400)
        self.assertEqual(self.client.post('/skills/listening/', {'answer':'text','prompt_id':self.second.pk}).status_code, 409)
        self.assertFalse(SkillPracticeAttempt.objects.exists())

    def test_retired_skill_endpoints_do_not_create_attempts(self):
        for kind in ('speaking', 'writing'):
            self.assertEqual(self.client.get(f'/skills/{kind}/').status_code, 404)
            self.assertEqual(self.client.post(f'/skills/{kind}/', {'answer': 'text'}).status_code, 404)
        self.assertFalse(SkillPracticeAttempt.objects.exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_no_implicit_course_or_unpublished_course_access(self):
        for language in (None, self.language):
            self.language.is_published = False
            self.language.save(update_fields=['is_published'])
            profile = self.user.learning_profile
            profile.preferred_language = language
            profile.save(update_fields=['preferred_language'])
            response = self.client.get('/skills/listening/')
            self.assertIsNone(response.context['target'])
            self.assertEqual(self.client.post('/skills/listening/', {'answer':'hello'}).status_code, 503)
        self.assertFalse(SkillPracticeAttempt.objects.exists())

    def test_sorani_arabic_shell_and_localized_feedback_keep_target_direction(self):
        for locale in ('ckb','ar'):
            profile = self.user.learning_profile
            profile.ui_language = locale
            profile.save(update_fields=['ui_language'])
            response = self.client.get('/skills/listening/')
            self.assertContains(response, 'dir="rtl"')
            self.assertContains(response, 'lang="nl" dir="ltr"')
            self.assertNotContains(response, 'Type the sentence you hear')
            self.assertContains(response, 'href="/skills/photos/"')

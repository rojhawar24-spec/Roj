"""Database-authoritative lesson-round channel, answer and terminal guards.

Call these helpers only under transaction.atomic() and after the normal locked
Profile -> Unit -> Lesson admission. PostgreSQL row locks serialize requests;
SQLite does not provide equivalent SELECT FOR UPDATE, so real SQLite and
PostgreSQL concurrency tests remain deployment gates.
"""

from .lesson_round_models_step3h import LessonRoundReceipt


class RoundReceiptConflict(Exception):
    pass


class RoundReceiptFinished(Exception):
    pass


class RoundReceiptAnswerReplay(Exception):
    pass


def valid_round_key(key):
    return (type(key) is str and len(key) == 32 and
            all(c in '0123456789abcdef' for c in key))


def require_round_state(*, channel, old_channel, finished):
    """Pure policy: no browser session can override a DB receipt."""
    if channel not in ('ajax', 'ssr'):
        raise ValueError('Unsupported grading channel.')
    if old_channel not in (None, 'ajax', 'ssr'):
        raise RoundReceiptConflict('Corrupt stored channel.')
    if old_channel not in (None, channel):
        raise RoundReceiptConflict('This round was already graded by the other channel.')
    if finished:
        raise RoundReceiptFinished('This lesson round has already finished.')


def claim_round(*, user, lesson, round_key, channel):
    """Claim a unique round under row lock; caller owns its transaction."""
    if not valid_round_key(round_key):
        raise RoundReceiptConflict('Invalid issued round key.')
    require_round_state(channel=channel, old_channel=None, finished=False)
    record, _ = LessonRoundReceipt.objects.get_or_create(
        user=user, lesson=lesson, round_key=round_key,
        defaults={'channel': channel})
    record = LessonRoundReceipt.objects.select_for_update().get(pk=record.pk)
    require_round_state(channel=channel, old_channel=record.channel,
                        finished=record.finished_at is not None)
    return record


def check_answer_replay(receipt, exercise_pk):
    """Avoid a second debit or mistake correction on a duplicate AJAX POST."""
    if str(exercise_pk) in receipt.answers:
        raise RoundReceiptAnswerReplay('This question was already checked.')


def save_answer(receipt, exercise_pk, correct):
    check_answer_replay(receipt, exercise_pk)
    receipt.answers = {**receipt.answers, str(exercise_pk): bool(correct)}
    receipt.save(update_fields=['answers', 'updated_at'])


def finish_round(receipt, *, score):
    from django.utils import timezone
    if type(score) is not int or not (0 <= score <= 100):
        raise ValueError('Score outside 0–100 range.')
    if receipt.finished_at is not None:
        raise RoundReceiptFinished('This round is already final.')
    receipt.score = score
    receipt.finished_at = timezone.now()
    receipt.save(update_fields=['score', 'finished_at', 'updated_at'])

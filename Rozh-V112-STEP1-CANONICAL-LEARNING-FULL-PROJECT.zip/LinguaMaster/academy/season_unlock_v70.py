"""V70 season progression. Published authored seasons gate the next season.

Pure calculation below is kept separate from Django data-loading so that the
sequence can be exhaustively tested without touching student accounts or XP.
Unassigned units and unpublished seasons retain their original permission rules.
"""


def calculate_access(level_seasons, completed_unit_ids):
    """Return {season_id: {open, complete, required, completed}}.

    level_seasons: iterable (level_id, season_id, [published participating unit ids]),
    already ordered by CEFR level, season order then PK. Each CEFR band's
    season chain starts independently (placement and level exams remain active).
    Empty seasons cannot block learning or appear complete.
    """
    result = {}
    active_level = None
    preceding_complete = True
    position = 0
    for level_id, season_id, unit_ids in level_seasons:
        if level_id != active_level:
            active_level = level_id
            preceding_complete = True
            position = 0
        position += 1
        required = list(dict.fromkeys(unit_ids))
        done = sum(pk in completed_unit_ids for pk in required)
        complete = bool(required) and done == len(required)
        result[season_id] = {
            'open': preceding_complete,
            'complete': complete,
            'position': position,
            'required': len(required),
            'completed': done,
        }
        if required:  # An empty editorial season must not form a permanent lock.
            preceding_complete = preceding_complete and complete
    return result


def access_for_user(user, language_id, *, levels=None, completed_lesson_ids=None,
                    passed_unit_ids=None, unit_test_ids=None):
    """Authoritative, read-only status based on real published lessons/tests.

    Called by direct URL authorization as well as the learning-path data builder.
    No models, permissions, XP, or schema are modified here.
    """
    from .models import LearningSeason, Level, LessonProgress, Assessment, Exercise

    if levels is None:
        levels = list(Level.objects.filter(language_id=language_id)
                      .order_by('order','pk').prefetch_related('units__lessons'))
    seasons = list(LearningSeason.objects.filter(level__language_id=language_id,
                                                published=True).values('pk','level_id','order'))
    if not seasons:
        return {}
    order = {level.pk: index for index, level in enumerate(levels)}
    seasons.sort(key=lambda s: (order.get(s['level_id'], 999999), s['order'], s['pk']))
    if completed_lesson_ids is None:
        completed_lesson_ids = set(LessonProgress.objects.filter(user=user,
            lesson__unit__level__language_id=language_id, lesson__published=True,
            lesson__unit__published=True).values_list('lesson_id', flat=True))
    if passed_unit_ids is None:
        passed_unit_ids = set(Assessment.objects.filter(user=user,kind='unit',passed=True,
            unit__level__language_id=language_id).values_list('unit_id', flat=True))
    if unit_test_ids is None:
        from .assessment_availability_v105 import assessment_candidates
        unit_test_ids = set(assessment_candidates(language_id=language_id)
            .values_list('lesson__unit_id',flat=True).distinct())
    by_season = {season['pk']: [] for season in seasons}
    completed_units = set(passed_unit_ids)
    for level in levels:
        for unit in level.units.all():
            if not unit.published or unit.season_id not in by_season:
                continue
            published_lessons = [lesson for lesson in unit.lessons.all() if lesson.published]
            if not published_lessons:
                continue
            by_season[unit.season_id].append(unit.pk)
            # Published quiz requires an actually passed assessment; no quiz
            # means the authored published lessons themselves are sufficient.
            if (unit.pk not in unit_test_ids and
                all(lesson.pk in completed_lesson_ids for lesson in published_lessons)):
                completed_units.add(unit.pk)
    return calculate_access(
        [(season['level_id'],season['pk'],by_season[season['pk']]) for season in seasons],
        completed_units,
    )

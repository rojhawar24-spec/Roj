"""V88 Django HTTP tests (pending until Django is installed). Never production DB."""
from unittest.mock import patch
import pyotp
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Profile
from .auth_security import verify_totp_step
from django.db import transaction

class EnrollmentExactTOTPTimeStepHTTP(TestCase):
    PASSWORD='V88-Disposable-Testing-Password!'
    NOW=1800000000 # deterministic, 30s-aligned
    def setUp(self):
        self.user=get_user_model().objects.create_user('v88_learner','v88@example.invalid',self.PASSWORD)
        self.client.force_login(self.user)
        self.assertEqual(self.client.get(reverse('mfa_setup')).status_code,200)
        self.secret=self.client.session['mfa_setup_secret']
        self.token=pyotp.TOTP(self.secret)
    def enroll_at(self,otp_step):
        with patch('academy.mfa_enroll_step_v88.time.time',return_value=self.NOW):
            return self.client.post(reverse('mfa_setup'), {'password':self.PASSWORD,
                'code':self.token.at(otp_step * self.token.interval)})
    def test_future_step_is_marked_consumed(self):
        step=self.NOW//self.token.interval+1
        response=self.enroll_at(step)
        self.assertEqual(response.status_code,302)
        profile=Profile.objects.get(user=self.user)
        self.assertEqual(profile.mfa_last_totp_step,step)
        with patch('time.time',return_value=self.NOW+30):
            with transaction.atomic():
                profile=Profile.objects.select_for_update().get(pk=profile.pk)
                self.assertFalse(verify_totp_step(profile,self.token.at(step*self.token.interval)))
    def test_previous_step_is_stored_correctly(self):
        step=self.NOW//self.token.interval-1
        self.assertEqual(self.enroll_at(step).status_code,302)
        self.assertEqual(Profile.objects.get(user=self.user).mfa_last_totp_step,step)
    def test_current_step_is_stored_correctly(self):
        step=self.NOW//self.token.interval
        self.assertEqual(self.enroll_at(step).status_code,302)
        self.assertEqual(Profile.objects.get(user=self.user).mfa_last_totp_step,step)
    def test_far_future_step_does_not_enroll(self):
        step=self.NOW//self.token.interval+2
        response=self.enroll_at(step)
        self.assertEqual(response.status_code,200)
        self.assertFalse(Profile.objects.get(user=self.user).totp_secret)

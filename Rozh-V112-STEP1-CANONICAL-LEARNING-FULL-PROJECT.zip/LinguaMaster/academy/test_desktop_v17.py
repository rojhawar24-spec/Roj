"""Integration checks for V17. Requires a real Django installation."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import PlatformSettings, Language, Level, Unit, Lesson

class DesktopLandingTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user('desktop17',password='VeryStrongPassword-2026!',email='desktop17@example.org')
        self.language=Language.objects.create(code='nl',name='Dutch',slug='desktop-dutch', description='Dutch course', is_published=True)
        level=Level.objects.create(language=self.language,code='A0',description='Starting level')
        self.unit=Unit.objects.create(level=level,slug='start-v17',title='First step',summary='First steps',published=True)
        Lesson.objects.create(unit=self.unit,slug='first-v17',title='First lesson',skill='reading',content='Greetings',published=True)
        p=self.user.learning_profile
        p.preferred_language=self.language
        p.onboarding_completed=True
        p.placement_completed=True
        p.ui_language='nl'
        p.save()
    def test_login_starts_at_play_after_required_steps(self):
        response=self.client.post(reverse('login'),{'email':'desktop17','password':'VeryStrongPassword-2026!'})
        self.assertRedirects(response,reverse('play_hub'),fetch_redirect_response=False)
    def test_explicit_local_next_still_respected(self):
        response=self.client.post(reverse('login'),{'email':'desktop17','password':'VeryStrongPassword-2026!','next':'/grammar/'})
        self.assertRedirects(response,'/grammar/',fetch_redirect_response=False)
    def test_logged_in_home_opens_play(self):
        self.client.force_login(self.user)
        self.assertRedirects(self.client.get('/'),reverse('play_hub'),fetch_redirect_response=False)
    def test_incomplete_setup_keeps_required_steps(self):
        p = self.user.learning_profile
        p.onboarding_completed = False
        p.save(update_fields=['onboarding_completed'])
        self.client.force_login(self.user)
        self.assertRedirects(self.client.get('/'), reverse('onboarding'), fetch_redirect_response=False)
        p.onboarding_completed = True
        p.placement_completed = False
        p.save(update_fields=['onboarding_completed','placement_completed'])
        self.assertRedirects(self.client.get('/'), reverse('placement'), fetch_redirect_response=False)
    def test_sidebar_includes_real_routes_but_no_ai_when_off(self):
        self.client.force_login(self.user)
        cfg=PlatformSettings.load()
        cfg.ai_enabled=False
        cfg.save()
        response=self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code,200)
        for route in ('play_hub','grammar_library','mistakes','friends','leaderboard','tests_hub_v16','profile'):
            self.assertContains(response,reverse(route))
        self.assertNotContains(response,'href="'+reverse('ai_tutor')+'"')
    def test_read_only_play_does_not_award_xp(self):
        from .models import XPEvent
        self.client.force_login(self.user)
        before=XPEvent.objects.count()
        self.client.get(reverse('play_hub'))
        self.assertEqual(XPEvent.objects.count(),before)
    def test_locked_item_cannot_be_started_from_path(self):
        from .models import Exercise
        second=Unit.objects.create(level=self.unit.level,slug='second-v17',title='Locked next',summary='Next steps',order=2,published=True)
        second.prerequisites.add(self.unit)
        Lesson.objects.create(unit=second,slug='second-lesson-v17',title='Second lesson',skill='reading',content='Next practice',published=True)
        self.client.force_login(self.user)
        response=self.client.get(reverse('play_hub'))
        self.assertNotContains(response,reverse('journey_play',args=[second.pk]))

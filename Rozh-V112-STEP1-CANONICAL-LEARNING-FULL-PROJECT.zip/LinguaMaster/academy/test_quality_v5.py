"""V5 integrations to run with python manage.py test academy --verbosity 2."""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import Client, TestCase
from .models import Language, Level, Vocabulary, SkillPracticeAttempt, XPEvent, Lesson, Unit, LessonProgress


class SkillPracticeIntegrationTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = get_user_model().objects.create_user('skilltester', 'skills@example.org', 'SecureTestPassword!123')
        self.language = Language.objects.create(name='Dutch', slug='dutch', code='nl', description='Dutch', is_published=True)
        self.level = Level.objects.create(language=self.language, code='A0', description='Getting started')
        self.word = Vocabulary.objects.create(level=self.level, word='boek', translation='book', pronunciation='book',
            example='Ik lees een boek in de trein.', published=True)
        profile = self.user.learning_profile
        profile.preferred_language = self.language
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.save()
        self.client.force_login(self.user)

    def test_listening_is_private_and_retired_modes_cannot_award_xp(self):
        self.assertEqual(self.client.get('/skills/listening/').status_code, 200)
        answer = 'Ik lees een boek in de trein.'
        response = self.client.post('/skills/listening/', {'answer':answer, 'source':'typed'})
        self.assertEqual(response.status_code, 200)
        attempt = SkillPracticeAttempt.objects.get()
        self.assertEqual((attempt.kind,attempt.score,attempt.input_method), ('listening',100,'typed'))
        self.assertNotIn(answer, repr(attempt.__dict__))
        for kind in ('speaking', 'writing'):
            self.assertEqual(self.client.get(f'/skills/{kind}/').status_code, 404)
            self.assertEqual(self.client.post(f'/skills/{kind}/', {'answer':answer}).status_code, 404)
        self.assertEqual(SkillPracticeAttempt.objects.filter(user=self.user).count(), 1)
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())
        self.assertContains(self.client.post('/account/export/', {'password': 'AStrongExamplePassword!23'}), 'skills_practice')
        self.assertNotIn(answer, self.client.post('/account/export/', {'password': 'AStrongExamplePassword!23'}).content.decode())

    def test_private_and_csrf_protected(self):
        self.assertEqual(Client().get('/skills/listening/').status_code, 302)
        protected = Client(enforce_csrf_checks=True)
        protected.force_login(self.user)
        self.assertEqual(protected.post('/skills/listening/', {'answer':'Ik heb een boek.'}).status_code, 403)

    def test_arbitrary_targets_and_bad_sources_are_rejected(self):
        self.client.get('/skills/listening/')
        response = self.client.post('/skills/listening/', {'answer': 'Ik lees een boek in de trein.', 'target_id':'999999', 'source':'microphone'})
        self.assertEqual(response.status_code, 400)
        self.assertFalse(SkillPracticeAttempt.objects.exists())
        response = self.client.post('/skills/listening/', {'answer':'x' * 2001, 'source':'typed'})
        self.assertEqual(response.status_code, 400)
        self.assertFalse(SkillPracticeAttempt.objects.exists())

    def test_unpublished_vocabulary_not_used(self):
        self.word.published = False
        self.word.save()
        self.assertContains(self.client.get('/skills/listening/'),'No published', status_code=200)
        self.assertEqual(self.client.post('/skills/listening/', {'answer':'text'}).status_code, 503)

    def test_self_reviewed_speaking_never_claims_exam_score(self):
        unit = Unit.objects.create(level=self.level, slug='basic', title='Basic', summary='Basic', published=True)
        lesson = Lesson.objects.create(unit=unit, slug='speaking', title='Speak', skill='speaking', content='Repeat', published=True)
        response = self.client.post(f'/lessons/{lesson.pk}/', {'self_check':'yes'})
        self.assertEqual(response.status_code, 409)
        self.assertFalse(LessonProgress.objects.filter(user=self.user, lesson=lesson).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_rtl_page_shell(self):
        for locale in ('ckb', 'ar'):
            profile = self.user.learning_profile
            profile.ui_language = locale
            profile.save(update_fields=['ui_language'])
            response = self.client.get('/skills/listening/')
            self.assertContains(response, f'dir="rtl"')
            self.assertContains(response, 'lang="nl" dir="ltr"')

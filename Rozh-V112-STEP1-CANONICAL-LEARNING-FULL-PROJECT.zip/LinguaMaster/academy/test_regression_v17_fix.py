"""V17 app-path compatibility: run with python manage.py test academy.test_regression_v17_fix."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Language, Level, Unit, Lesson


class PlayCompatibilityTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(username='v17fixlearner', password='GoodPassword!2026')
        lang = Language.objects.create(name='Dutch', code='nl', slug='v17fix-dutch', description='Learning', is_published=True)
        level = Level.objects.create(language=lang, code='A0', order=0, description='Starter')
        cls.open_unit = Unit.objects.create(level=level, slug='v17fix-open', title='Hello', summary='First steps', published=True, order=1)
        Lesson.objects.create(unit=cls.open_unit, slug='v17fix-lesson', title='Say hello', skill='reading', content='Practice', published=True)
        cls.locked = Unit.objects.create(level=level, slug='v17fix-locked', title='Next', summary='Later', published=True, order=2)
        cls.locked.prerequisites.add(cls.open_unit)
        Lesson.objects.create(unit=cls.locked, slug='v17fix-lesson2', title='Next lesson', skill='reading', content='Practice', published=True)
        profile = cls.user.learning_profile
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.preferred_language = lang
        profile.ui_language = 'nl'
        profile.save()

    def setUp(self):
        self.client.force_login(self.user)

    def test_title_and_all_existing_modes_are_rendered(self):
        page = self.client.get(reverse('play_hub'))
        self.assertEqual(page.status_code, 200)
        self.assertContains(page, 'Leer &amp; Speel')
        self.assertContains(page, 'v15-play-modes')
        for name in ('learn_path', 'practice_hub', 'review', 'photo_practice'):
            self.assertContains(page, reverse(name))

    def test_locked_unit_shows_correct_localized_reason_but_no_play_url(self):
        page = self.client.get(reverse('play_hub'))
        self.assertContains(page, 'Eerst vorige level afronden')
        self.assertContains(page, reverse('journey_play', args=[self.open_unit.pk]))
        self.assertNotContains(page, reverse('journey_play', args=[self.locked.pk]))

    def test_nl_and_sorani_labels_are_read_from_server_dictionary(self):
        page = self.client.get(reverse('play_hub'))
        self.assertContains(page, 'Leer &amp; Speel')
        profile = self.user.learning_profile
        profile.ui_language = 'ckb'
        profile.save(update_fields=['ui_language'])
        page = self.client.get(reverse('play_hub'))
        self.assertContains(page, 'سەرەتا ئاستی پێشوو تەواو بکە')
        self.assertContains(page, 'v15-play-modes')

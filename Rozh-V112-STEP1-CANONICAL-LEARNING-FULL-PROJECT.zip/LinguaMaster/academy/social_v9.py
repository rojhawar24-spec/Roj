"""Private friend connections and rate-limited, cosmetic gifts."""
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Q
from django.http import HttpResponse, HttpResponseBadRequest
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import path
from django.utils import timezone
from django.views.decorators.http import require_POST
from .models import Friendship, Profile
from .social_policy_v37 import social_access_allowed
from .services import current_streak, notify, rate_limit, user_localdate
from .social_models import AvatarStyle, SocialGift


STRINGS = {
 'en': {
  'title':'Better together', 'intro':'Small encouragements. Real learning. Your own circle.',
  'add':'Add a friend', 'username':'Username', 'send_request':'Send request', 'friends':'Your friends',
  'requests':'Friend requests', 'incoming':'Received', 'outgoing':'Sent', 'accept':'Accept', 'decline':'Decline',
  'remove':'Remove', 'block':'Block', 'unblock':'Unblock', 'blocked':'Blocked accounts', 'cancel':'Cancel',
  'none':'Nothing here yet.', 'no_friends':'Your next learning adventure can be shared. Add a friend above.',
  'privacy_title':'Your social features are off', 'privacy':'Enable social features in your profile to connect with other learners.',
  'profile':'Open profile', 'streak':'day streak', 'xp':'earned XP', 'gift':'Send a gift',
  'gift_note':'Cosmetic gifts are free. Earn 20 learning XP to start. One gift per friend each day; up to five per day.',
  'gift_sent':'Gift sent today', 'gift_locked':'Earn 20 XP to send gifts', 'gift_success':'Your gift has been delivered!',
  'gift_exists':'You already sent this friend a gift today.', 'gift_limit':'You have sent all five gifts for today.',
  'gift_unavailable':'This gift cannot be sent. Check the friendship and your social settings.',
  'star':'Star frame', 'forest':'Forest background', 'confetti':'Celebration badge',
  'inbox':'Your gifts', 'from':'From', 'studio':'Avatar studio', 'studio_intro':'Make your profile feel like you. Gifts unlock extra details.',
  'base':'Choose your avatar', 'background':'Background', 'accessory':'Finishing touch', 'save':'Save avatar',
  'saved':'Your avatar is ready.', 'locked':'Receive this gift to unlock it', 'available':'Available',
  'sky':'Sky', 'lavender':'Lavender', 'sand':'Sand', 'no_accessory':'Simple', 'preview':'Your avatar',
  'request_sent':'Friend request sent.', 'request_invalid':'We could not send this request. Check the username and social preferences.',
  'request_exists':'You already have a connection or request with this learner.', 'request_received':'This learner has already invited you. Accept their request below.',
  'connected':'You are now friends!', 'invalid_avatar':'Choose an available avatar, background and accessory.',
  'no_xp_transfer':'Gifts never change learning XP.', 'gift_notification':'A little encouragement',
  'gift_message':'{name} sent you a cosmetic gift. Open your avatar studio to use it.',
 },
 'nl': {
  'title':'Samen kom je verder', 'intro':'Kleine aanmoedigingen. Echt leren. Jouw eigen kring.',
  'add':'Vriend toevoegen', 'username':'Gebruikersnaam', 'send_request':'Verzoek versturen', 'friends':'Jouw vrienden',
  'requests':'Vriendschapsverzoeken', 'incoming':'Ontvangen', 'outgoing':'Verstuurd', 'accept':'Accepteren', 'decline':'Weigeren',
  'remove':'Verwijderen', 'block':'Blokkeren', 'unblock':'Deblokkeren', 'blocked':'Geblokkeerde accounts', 'cancel':'Annuleren',
  'none':'Hier staat nog niets.', 'no_friends':'Samen leren begint met een uitnodiging. Voeg hierboven een vriend toe.',
  'privacy_title':'Je sociale functies staan uit', 'privacy':'Zet sociale functies aan in je profiel om met anderen te leren.',
  'profile':'Profiel openen', 'streak':'dagen op rij', 'xp':'verdiende XP', 'gift':'Cadeau sturen',
  'gift_note':'Cosmetische cadeaus zijn gratis. Verdien eerst 20 leer-XP. Eén cadeau per vriend per dag; maximaal vijf per dag.',
  'gift_sent':'Vandaag verstuurd', 'gift_locked':'Verdien 20 XP om cadeaus te sturen', 'gift_success':'Je cadeau is bezorgd!',
  'gift_exists':'Je hebt deze vriend vandaag al een cadeau gestuurd.', 'gift_limit':'Je hebt vandaag alle vijf cadeaus verstuurd.',
  'gift_unavailable':'Dit cadeau kan niet worden verstuurd. Controleer de vriendschap en sociale instellingen.',
  'star':'Sterrenkader', 'forest':'Bosachtergrond', 'confetti':'Feestbadge',
  'inbox':'Jouw cadeaus', 'from':'Van', 'studio':'Avatarstudio', 'studio_intro':'Geef je profiel een eigen gezicht. Cadeaus ontgrendelen extra details.',
  'base':'Kies je avatar', 'background':'Achtergrond', 'accessory':'Extra detail', 'save':'Avatar opslaan',
  'saved':'Je avatar is klaar.', 'locked':'Ontvang dit cadeau om het te gebruiken', 'available':'Beschikbaar',
  'sky':'Lucht', 'lavender':'Lavendel', 'sand':'Zand', 'no_accessory':'Eenvoudig', 'preview':'Jouw avatar',
  'request_sent':'Vriendschapsverzoek verstuurd.', 'request_invalid':'Dit verzoek kon niet worden verstuurd. Controleer de gebruikersnaam en sociale voorkeuren.',
  'request_exists':'Er bestaat al een verbinding of verzoek met deze leerling.', 'request_received':'Deze leerling heeft je al uitgenodigd. Accepteer het verzoek hieronder.',
  'connected':'Jullie zijn nu vrienden!', 'invalid_avatar':'Kies een beschikbare avatar, achtergrond en versiering.',
  'no_xp_transfer':'Cadeaus veranderen je leer-XP nooit.', 'gift_notification':'Een kleine aanmoediging',
  'gift_message':'{name} stuurde je een cosmetisch cadeau. Open je avatarstudio om het te gebruiken.',
 },
 'ckb': {
  'title':'پێکەوە زیاتر فێر دەبین', 'intro':'هاندانێکی بچووک. فێربوونی ڕاستەقینە. کۆمەڵەی هاوڕێکانت.',
  'add':'هاوڕێ زیاد بکە', 'username':'ناوی بەکارهێنەر', 'send_request':'داواکاری بنێرە', 'friends':'هاوڕێکانت',
  'requests':'داواکارییەکانی هاوڕێیەتی', 'incoming':'وەرگیراوەکان', 'outgoing':'نێردراوەکان', 'accept':'قبووڵکردن', 'decline':'ڕەتکردنەوە',
  'remove':'سڕینەوە', 'block':'بلۆککردن', 'unblock':'لابردنی بلۆک', 'blocked':'هەژمارە بلۆککراوەکان', 'cancel':'هەڵوەشاندنەوە',
  'none':'هێشتا هیچ شتێک نییە.', 'no_friends':'فێربوونی هاوبەش بە بانگهێشتێک دەست پێ دەکات. هاوڕێیەک زیاد بکە.',
  'privacy_title':'تایبەتمەندییە کۆمەڵایەتییەکانت ناچالاکن', 'privacy':'لە پرۆفایلەکەت تایبەتمەندییە کۆمەڵایەتییەکان چالاک بکە بۆ پەیوەندی لەگەڵ فێرخوازان.',
  'profile':'پرۆفایل بکەرەوە', 'streak':'ڕۆژی بەردەوام', 'xp':'XPی بەدەستهێنراو', 'gift':'دیاری بنێرە',
  'gift_note':'دیارییە جوانکارییەکان بەخۆڕایین. سەرەتا ٢٠ XPی فێربوون بەدەست بهێنە. بۆ هەر هاوڕێیەک ڕۆژانە یەک دیاری؛ کۆی ڕۆژانە پێنج دیاری.',
  'gift_sent':'ئەمڕۆ نێردراوە', 'gift_locked':'بۆ ناردنی دیاری ٢٠ XP بەدەست بهێنە', 'gift_success':'دیارییەکەت گەیشت!',
  'gift_exists':'ئەمڕۆ پێشتر دیاریت بۆ ئەم هاوڕێیە ناردووە.', 'gift_limit':'ئەمڕۆ هەموو پێنج دیارییەکەت ناردووە.',
  'gift_unavailable':'ئەم دیارییە نانێردرێت. هاوڕێیەتی و ڕێکخستنە کۆمەڵایەتییەکان بپشکنە.',
  'star':'چوارچێوەی ئەستێرە', 'forest':'پاشبنەمای دارستان', 'confetti':'نیشانی ئاهەنگ',
  'inbox':'دیارییەکانت', 'from':'لە', 'studio':'ستۆدیۆی ئەڤاتار', 'studio_intro':'ڕووکارێکی تایبەت بە پرۆفایلەکەت بدە. دیارییەکان جوانکاریی زیاتر دەکەنەوە.',
  'base':'ئەڤاتارەکەت هەڵبژێرە', 'background':'پاشبنەما', 'accessory':'جوانکاری', 'save':'ئەڤاتار پاشەکەوت بکە',
  'saved':'ئەڤاتارەکەت ئامادەیە.', 'locked':'بۆ کردنەوەی ئەمە دیارییەکە وەربگرە', 'available':'بەردەستە',
  'sky':'ئاسمان', 'lavender':'مۆر', 'sand':'لم', 'no_accessory':'سادە', 'preview':'ئەڤاتارەکەت',
  'request_sent':'داواکاریی هاوڕێیەتی نێردرا.', 'request_invalid':'نەتوانرا ئەم داواکارییە بنێردرێت. ناوی بەکارهێنەر و ڕێکخستنەکان بپشکنە.',
  'request_exists':'پێشتر پەیوەندی یان داواکاری لەگەڵ ئەم فێرخوازە هەیە.', 'request_received':'ئەم فێرخوازە پێشتر بانگهێشتی کردوویت. لە خوارەوە قبووڵی بکە.',
  'connected':'ئێستا بوون بە هاوڕێ!', 'invalid_avatar':'ئەڤاتار، پاشبنەما و جوانکارییەکی بەردەست هەڵبژێرە.',
  'no_xp_transfer':'دیارییەکان XPی فێربوون ناگوازنەوە.', 'gift_notification':'هاندانێکی بچووک',
  'gift_message':'{name} دیارییەکی جوانکاری بۆ ناردوویت. بۆ بەکارهێنانی ستۆدیۆی ئەڤاتار بکەرەوە.',
 },
 'ar': {
  'title':'نتقدّم معًا', 'intro':'تشجيع صغير. تعلّم حقيقي. دائرة أصدقائك.',
  'add':'إضافة صديق', 'username':'اسم المستخدم', 'send_request':'إرسال الطلب', 'friends':'أصدقاؤك',
  'requests':'طلبات الصداقة', 'incoming':'الواردة', 'outgoing':'المرسلة', 'accept':'قبول', 'decline':'رفض',
  'remove':'إزالة', 'block':'حظر', 'unblock':'إلغاء الحظر', 'blocked':'الحسابات المحظورة', 'cancel':'إلغاء',
  'none':'لا شيء هنا بعد.', 'no_friends':'يبدأ التعلم المشترك بدعوة. أضف صديقًا أعلاه.',
  'privacy_title':'ميزاتك الاجتماعية غير مفعلة', 'privacy':'فعّل الميزات الاجتماعية في ملفك للتواصل مع المتعلمين.',
  'profile':'فتح الملف', 'streak':'أيام متتالية', 'xp':'XP مكتسبة', 'gift':'إرسال هدية',
  'gift_note':'الهدايا التجميلية مجانية. اجمع 20 XP من التعلم أولًا. هدية واحدة لكل صديق يوميًا، وبحد أقصى خمس هدايا يوميًا.',
  'gift_sent':'أُرسلت اليوم', 'gift_locked':'اجمع 20 XP لإرسال الهدايا', 'gift_success':'وصلت هديتك!',
  'gift_exists':'أرسلت لهذا الصديق هدية اليوم بالفعل.', 'gift_limit':'أرسلت الهدايا الخمس لهذا اليوم.',
  'gift_unavailable':'تعذر إرسال الهدية. تحقق من الصداقة والإعدادات الاجتماعية.',
  'star':'إطار النجوم', 'forest':'خلفية الغابة', 'confetti':'شارة الاحتفال',
  'inbox':'هداياك', 'from':'من', 'studio':'استوديو الشخصية', 'studio_intro':'أضف لمستك إلى ملفك. الهدايا تفتح تفاصيل جديدة.',
  'base':'اختر شخصيتك', 'background':'الخلفية', 'accessory':'لمسة إضافية', 'save':'حفظ الشخصية',
  'saved':'شخصيتك جاهزة.', 'locked':'تلقّ هذه الهدية لفتحها', 'available':'متاح',
  'sky':'السماء', 'lavender':'الخزامى', 'sand':'الرمل', 'no_accessory':'بسيط', 'preview':'شخصيتك',
  'request_sent':'أُرسل طلب الصداقة.', 'request_invalid':'تعذر إرسال الطلب. تحقق من الاسم والتفضيلات الاجتماعية.',
  'request_exists':'توجد صداقة أو دعوة مع هذا المتعلم بالفعل.', 'request_received':'هذا المتعلم دعاك بالفعل. اقبل طلبه أدناه.',
  'connected':'أصبحتما صديقين!', 'invalid_avatar':'اختر شخصية وخلفية وزينة متاحة.',
  'no_xp_transfer':'الهدايا لا تنقل XP التعلم.', 'gift_notification':'تشجيع صغير',
  'gift_message':'أرسل {name} هدية تجميلية. افتح استوديو الشخصية لاستخدامها.',
 },
}

AVATARS = ['🎓', '📚', '⭐', '🌍', '🚀', '🌱', '🌿', '💎']
GIFT_ICONS = {'star':'⭐', 'forest':'🌲', 'confetti':'🎉'}


def strings(user):
    return STRINGS.get(user.learning_profile.ui_language, STRINGS['en'])


def pair_query(first, second):
    return Q(from_user=first, to_user=second) | Q(from_user=second, to_user=first)


def eligible_learning_xp(user):
    from django.db.models import Sum
    from .models import XPEvent
    return XPEvent.objects.filter(user=user, reason__in=['lesson','assessment','review','mistake','arena']).aggregate(n=Sum('amount'))['n'] or 0


def _locked_profiles(first, second):
    # A deterministic lock order serializes gifts and reciprocal invitations.
    return {p.user_id:p for p in Profile.objects.select_for_update().filter(user_id__in=[first.pk,second.pk]).order_by('user_id')}


@login_required
def friends(request):
    account_profile = Profile.objects.filter(user=request.user).first()
    if not social_access_allowed(account_profile, user_active=request.user.is_active,
                                 require_opt_in=False):
        return HttpResponse(status=403)
    S = strings(request.user)
    from .rozh2027 import student_shell_context
    context = {**student_shell_context(request), 'shell_template':'academy/rozh2027_student_shell.html',
               'page_title':S['title'], 'S':S, 'noindex':True,
               'social_disabled':not account_profile.social_opt_in}
    if context['social_disabled']:
        return render(request, 'academy/friends.html', context)
    if request.method == 'POST':
        if rate_limit(request,'v9-friend-request',12,3600,True):
            return HttpResponse(S['request_invalid'], status=429)
        username = request.POST.get('username','').strip().removeprefix('@')[:150]
        other = get_user_model().objects.filter(username__iexact=username, is_active=True).exclude(pk=request.user.pk).first()
        if not other:
            messages.error(request, S['request_invalid'])
        else:
            with transaction.atomic():
                profiles = _locked_profiles(request.user, other)
                # The other user may have been suspended after username lookup.
                # Profile locks serialize this check with Manager suspension.
                active_ids = set(get_user_model().objects.filter(
                    pk__in=(request.user.pk, other.pk), is_active=True).values_list('pk', flat=True))
                relations = Friendship.objects.filter(pair_query(request.user,other))
                if (not social_access_allowed(profiles.get(request.user.pk),
                                              user_active=request.user.pk in active_ids)
                        or not social_access_allowed(profiles.get(other.pk),
                                                     user_active=other.pk in active_ids)
                        or relations.filter(status='blocked').exists()):
                    messages.error(request,S['request_invalid'])
                elif relations.filter(status='accepted').exists() or relations.filter(from_user=request.user).exists():
                    messages.info(request,S['request_exists'])
                elif relations.filter(from_user=other,status='pending').exists():
                    messages.info(request,S['request_received'])
                else:
                    Friendship.objects.create(from_user=request.user,to_user=other)
                    messages.success(request,S['request_sent'])
        return redirect('friends')
    received = Friendship.objects.filter(to_user=request.user,status='pending',from_user__is_active=True,
        from_user__learning_profile__social_opt_in=True,
        from_user__learning_profile__suspended_at__isnull=True,
        from_user__learning_profile__legacy_review_required=False).exclude(
        from_user__learning_profile__onboarding_required=True,
        from_user__learning_profile__onboarding_completed=False).select_related('from_user')
    outgoing = Friendship.objects.filter(from_user=request.user,status='pending').select_related('to_user')
    blocked_ids = set(Friendship.objects.filter(
        Q(from_user=request.user)|Q(to_user=request.user),status='blocked').values_list('from_user_id','to_user_id'))
    blocked_users = {uid for pair in blocked_ids for uid in pair if uid != request.user.pk}
    sent_ids = set(SocialGift.objects.filter(sender=request.user,sent_day=user_localdate(request.user)).values_list('recipient_id',flat=True))
    friend_data=[]
    seen=set()
    for relation in Friendship.objects.filter(Q(from_user=request.user)|Q(to_user=request.user), status='accepted').select_related('from_user__learning_profile','to_user__learning_profile','from_user__avatar_style','to_user__avatar_style'):
        other = relation.to_user if relation.from_user_id == request.user.pk else relation.from_user
        if (other.pk in seen or other.pk in blocked_users
                or not social_access_allowed(other.learning_profile,user_active=other.is_active)):
            continue
        seen.add(other.pk)
        style = getattr(other,'avatar_style',None)
        profile = other.learning_profile
        # A stale stored streak must not look current after a missed day.
        active_streak = current_streak(profile)
        friend_data.append({'relation':relation,'user':other,'streak':active_streak,'avatar':profile.avatar,
            'xp':profile.xp,'style':style,'sent_today':other.pk in sent_ids})
    gifts = list(SocialGift.objects.filter(recipient=request.user).exclude(sender_id__in=blocked_users).select_related('sender')[:20])
    for item in gifts:
        item.localized_name=S[item.kind]
        item.icon=GIFT_ICONS[item.kind]
    context.update({'received':received,'outgoing':outgoing,'friend_data':friend_data,
        'blocked':Friendship.objects.filter(from_user=request.user,status='blocked').select_related('to_user'),
        'gifts':gifts,'catalogue':[{'kind':k,'name':S[k],'icon':v} for k,v in GIFT_ICONS.items()],
        'can_gift':eligible_learning_xp(request.user)>=20})
    return render(request,'academy/friends.html',context)


@login_required
@require_POST
def friend_action(request,pk,action):
    if rate_limit(request,'v9-friend-action',60,3600,True):
        return HttpResponse(status=429)
    with transaction.atomic():
        relation=get_object_or_404(Friendship,pk=pk)
        if request.user.pk not in (relation.from_user_id,relation.to_user_id):
            return HttpResponse(status=403)
        other=relation.to_user if relation.from_user_id==request.user.pk else relation.from_user
        profiles=_locked_profiles(request.user,other)
        if request.user.pk not in profiles:
            return HttpResponse(status=403)
        active_ids = set(get_user_model().objects.filter(
            pk__in=(request.user.pk, other.pk), is_active=True).values_list('pk', flat=True))
        relation=Friendship.objects.select_for_update().filter(pk=pk).first()
        if relation is None:
            return redirect('friends')
        if action in ('accept','reject') and relation.to_user_id==request.user.pk and relation.status=='pending':
            if action=='reject':
                relation.delete()
            elif (len(profiles)==2
                  and social_access_allowed(profiles.get(request.user.pk),
                                            user_active=request.user.pk in active_ids)
                  and social_access_allowed(profiles.get(other.pk),
                                            user_active=other.pk in active_ids)
                  and not Friendship.objects.filter(
                      pair_query(request.user,other),status='blocked').exists()):
                relation.status='accepted'
                relation.save(update_fields=['status'])
                messages.success(request,strings(request.user)['connected'])
            else:
                return HttpResponse(status=403)
        elif action=='remove' and relation.status != 'blocked':
            relation.delete()
        elif action=='block':
            # A block belongs to the blocker; the other user cannot remove it.
            Friendship.objects.filter(pair_query(request.user,other)).exclude(status='blocked').delete()
            own,_=Friendship.objects.get_or_create(from_user=request.user,to_user=other,defaults={'status':'blocked'})
            if own.status!='blocked':
                own.status='blocked'
                own.save(update_fields=['status'])
        elif action=='unblock' and relation.from_user_id==request.user.pk and relation.status=='blocked':
            relation.delete()
        else:
            return HttpResponse(status=403)
    return redirect('friends')


@login_required
@require_POST
def gifts_send(request,pk):
    S=strings(request.user)
    kind=request.POST.get('kind','')
    if kind not in GIFT_ICONS:
        return HttpResponseBadRequest(S['gift_unavailable'])
    if rate_limit(request,'v9-gift-send',30,3600,True):
        return HttpResponse(status=429)
    other=get_object_or_404(get_user_model(),pk=pk,is_active=True)
    with transaction.atomic():
        profiles=_locked_profiles(request.user,other)
        active_ids = set(get_user_model().objects.filter(
            pk__in=(request.user.pk, other.pk), is_active=True).values_list('pk', flat=True))
        pair=Friendship.objects.filter(pair_query(request.user,other))
        if (other.pk==request.user.pk or len(profiles)!=2
                or not social_access_allowed(profiles.get(request.user.pk),
                                             user_active=request.user.pk in active_ids)
                or not social_access_allowed(profiles.get(other.pk),
                                             user_active=other.pk in active_ids)
                or pair.filter(status='blocked').exists()
                or not pair.filter(status='accepted').exists()):
            return HttpResponse(S['gift_unavailable'],status=403)
        if eligible_learning_xp(request.user)<20:
            messages.error(request,S['gift_locked'])
            return redirect('friends')
        day=user_localdate(request.user)
        if SocialGift.objects.filter(sender=request.user,recipient=other,sent_day=day).exists():
            messages.info(request,S['gift_exists'])
            return redirect('friends')
        if SocialGift.objects.filter(sender=request.user,sent_day=day).count()>=5:
            messages.info(request,S['gift_limit'])
            return redirect('friends')
        gift=SocialGift.objects.create(sender=request.user,recipient=other,kind=kind,sent_day=day)
        recipient_strings=strings(other)
        notify(other,f'gift:{gift.pk}',recipient_strings['gift_notification'],recipient_strings['gift_message'].format(name=request.user.username))
    messages.success(request,S['gift_success'])
    return redirect('friends')


@login_required
def avatar_studio(request):
    account_profile = Profile.objects.filter(user=request.user).first()
    # Avatar changes need no social opt-in, but must never bypass account
    # suspension, quarantine or mandatory onboarding.
    if not social_access_allowed(account_profile, user_active=request.user.is_active,
                                 require_opt_in=False):
        return HttpResponse(status=403)
    S=strings(request.user)
    if request.method=='POST':
        if rate_limit(request,'v9-avatar',30,3600,True):
            return HttpResponse(status=429)
        base=request.POST.get('avatar','')
        palette=request.POST.get('palette','')
        accessory=request.POST.get('accessory','')
        with transaction.atomic():
            locked_profile = Profile.objects.select_for_update().filter(user=request.user).first()
            current_active = get_user_model().objects.filter(pk=request.user.pk,
                                                              is_active=True).exists()
            if not social_access_allowed(locked_profile, user_active=current_active,
                                         require_opt_in=False):
                return HttpResponse(status=403)
            unlocked=set(SocialGift.objects.filter(recipient=request.user).values_list('kind',flat=True))
            allowed_palettes={'sky','lavender','sand'} | ({'forest'} if 'forest' in unlocked else set())
            allowed_accessories={'none'} | (unlocked & {'star','confetti'})
            if base not in AVATARS or palette not in allowed_palettes or accessory not in allowed_accessories:
                messages.error(request,S['invalid_avatar'])
                return redirect('avatar_studio')
            locked_profile.avatar=base
            locked_profile.save(update_fields=['avatar'])
            AvatarStyle.objects.update_or_create(user=request.user, defaults={
                'palette':palette,'accessory':accessory,'updated_at':timezone.now()})
        messages.success(request,S['saved'])
        return redirect('avatar_studio')
    style,_=AvatarStyle.objects.get_or_create(user=request.user)
    unlocked=set(SocialGift.objects.filter(recipient=request.user).values_list('kind',flat=True))
    palettes=[{'value':key,'name':S[key],'locked':key=='forest' and key not in unlocked} for key,_ in AvatarStyle.PALETTES]
    accessories=[{'value':key,'name':S['no_accessory' if key=='none' else key],'locked':key!='none' and key not in unlocked} for key,_ in AvatarStyle.ACCESSORIES]
    from .rozh2027 import student_shell_context
    return render(request,'academy/avatar_studio.html',{**student_shell_context(request),
        'shell_template':'academy/rozh2027_student_shell.html',
        'page_title':S['studio'], 'S':S,'style':style,'avatars':AVATARS,
        'palettes':palettes,'accessories':accessories,'noindex':True})


urlpatterns=[
    path('friends/',friends,name='friends'),
    path('friends/<int:pk>/<slug:action>/',friend_action,name='friend_action'),
    path('gifts/send/<int:pk>/',gifts_send,name='gifts_send'),
    path('avatar/',avatar_studio,name='avatar_studio'),
]


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'social_v9', ['STRINGS'])

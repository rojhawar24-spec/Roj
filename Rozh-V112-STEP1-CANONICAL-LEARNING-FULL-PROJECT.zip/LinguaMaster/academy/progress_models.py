"""Account preferences and lifetime learning milestones, separate from CEFR levels."""
from django.conf import settings
from django.db import models


class LearningPreferences(models.Model):
    THEMES = [('system', 'System'), ('light', 'Light'), ('dark', 'Dark')]
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name='learning_preferences')
    timezone_name = models.CharField(max_length=64, default=settings.TIME_ZONE)
    theme = models.CharField(max_length=6, choices=THEMES, default='system')
    reduce_motion = models.BooleanField(default=False)
    longest_streak = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f'Learning preferences: {self.user_id}'

"""Starter data integrity, repeatable seeding and editorial preservation."""
from io import StringIO

from django.core.management import call_command
from django.test import TestCase

from .models import Language, Level, Unit, Lesson, Exercise, GrammarTopic, Vocabulary
from .grammar_rich_models import GrammarArticle
from .quality_rules import check_exercise
from .rich_schema import normalize_article
from .services import grade
from .starter_v10 import COURSE as ENGLISH
from .starter_de_v10 import COURSE as GERMAN
from .starter_fr_v10 import COURSE as FRENCH


NEW_CODES = ('en', 'de', 'fr')


class FourLanguageStarterTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        call_command('seed_curriculum', stdout=StringIO())
        call_command('seed_languages_v10', stdout=StringIO())

    def test_published_scope_is_authored_starters_and_future_levels_are_empty(self):
        self.assertEqual(set(Language.objects.filter(is_published=True).values_list('code', flat=True)),
                         {'nl', 'en', 'de', 'fr'})
        for code in NEW_CODES:
            with self.subTest(code=code):
                language = Language.objects.get(code=code)
                self.assertEqual(list(language.levels.order_by('order').values_list('code', flat=True)),
                                 ['A0', 'A1', 'A2', 'B1', 'B2', 'C1'])
                units = Unit.objects.filter(level__language=language, published=True)
                self.assertEqual(units.filter(level__code='A0').count(), 2)
                self.assertEqual(units.filter(level__code='A1').count(), 1)
                self.assertEqual(units.exclude(level__code__in=('A0', 'A1')).count(), 0)
                self.assertEqual(Lesson.objects.filter(unit__in=units, published=True).count(), 6)
                self.assertEqual(Lesson.objects.filter(unit__in=units, skill='listening',
                    published=False).count(), 3)
                # Ungraded Speaking/Writing belong outside the five-kind scored route.
                self.assertFalse(Lesson.objects.filter(unit__in=units,
                    skill__in=('speaking','writing')).exists())
                self.assertEqual(Exercise.objects.filter(lesson__unit__in=units).count(), 27)
                self.assertEqual(Vocabulary.objects.filter(level__language=language, published=True).count(), 18)
                self.assertEqual(GrammarTopic.objects.filter(level__language=language, published=True).count(), 3)
                self.assertIn('A2', language.description)

    def test_all_question_keys_are_gradable_and_no_data_consistency_errors(self):
        questions = Exercise.objects.filter(lesson__unit__level__language__code__in=NEW_CODES)
        self.assertEqual(questions.count(), 81)
        self.assertTrue(questions.filter(kind='fill_blank').exists())
        self.assertFalse(questions.filter(kind='short').exists())
        for exercise in questions:
            with self.subTest(exercise=exercise.pk):
                errors = [issue for issue in check_exercise(exercise.kind, exercise.prompt,
                          exercise.options, exercise.answer, exercise.explanation) if issue[0] == 'error']
                self.assertEqual(errors, [])
                self.assertTrue(grade(exercise, exercise.answer))
                self.assertFalse(grade(exercise, 'a deliberately unrelated incorrect answer'))
                if exercise.kind == 'mcq':
                    self.assertFalse(grade(exercise, next(option for option in exercise.options
                                                        if option != exercise.answer)))

    def test_each_unit_has_useful_five_skill_tasks_and_target_language_audio(self):
        for course in (ENGLISH, GERMAN, FRENCH):
            for unit in course['units']:
                with self.subTest(course=course['code'], unit=unit['slug']):
                    self.assertEqual({item['skill'] for item in unit['lessons']},
                                     {'grammar', 'reading', 'listening', 'speaking', 'writing'})
                    for item in unit['lessons']:
                        self.assertGreater(len(item['content'].strip()), 100)
                        if item['skill'] in ('grammar', 'reading', 'listening'):
                            self.assertEqual(len(item['exercises']), 3)
                            self.assertTrue(item['audio_text'])
                        else:
                            self.assertEqual(item.get('exercises', []), [])
                            self.assertIn('self', item['content'].lower())
                    self.assertGreaterEqual(len(unit['vocabulary']), 6)
                    self.assertTrue(all(word['example'] and word['pronunciation']
                                        for word in unit['vocabulary']))
        # Concrete target-language anchors catch accidental copying of Dutch audio
        # into the new courses. TTS locale is selected from the real Language code.
        for code, phrase in [('en', 'I am Noor.'), ('de', 'Ich bin Nora.'), ('fr', 'Je suis élève.')]:
            self.assertTrue(Lesson.objects.filter(unit__level__language__code=code,
                                                 audio_text__contains=phrase).exists())
        german_table = Vocabulary.objects.get(level__language__code='de', word='Tisch')
        self.assertIn('der Tisch', german_table.translation)
        french_school = Vocabulary.objects.get(level__language__code='fr', word='école')
        self.assertIn('L’école', french_school.example)

    def test_four_substantial_rich_articles_use_the_validated_schema(self):
        articles = GrammarArticle.objects.all()
        self.assertEqual(articles.count(), 4)
        self.assertEqual(set(articles.values_list('topic__level__language__code', flat=True)),
                         {'en', 'de', 'fr', 'nl'})
        for article in articles:
            with self.subTest(article=article.pk):
                normalized = normalize_article(article.content)
                self.assertGreaterEqual(len(normalized['sections']), 4)
                self.assertGreaterEqual(len(normalized['rule_tables']), 2)
                self.assertGreaterEqual(len(normalized['sentence_patterns']), 3)
                self.assertGreaterEqual(len(normalized['example_pairs']), 4)
                self.assertGreaterEqual(len(normalized['common_traps']), 4)

    def test_seeding_again_preserves_edited_records_publication_and_prerequisites(self):
        language = Language.objects.get(code='en')
        level = language.levels.get(code='A0')
        unit = level.units.get(slug='a-an-and-plural-things')
        lesson = unit.lessons.get(skill='grammar')
        exercise = lesson.exercises.order_by('order').first()
        vocabulary = Vocabulary.objects.get(level=level, word='book')
        topic = GrammarTopic.objects.get(level=level, slug=unit.slug)
        article = GrammarArticle.objects.get(topic__level__language=language)
        language.name = 'Editorial English'
        language.is_published = False
        language.save()
        level.description = 'Editor’s own coverage map'
        level.save()
        unit.title = 'Editor’s revised objects unit'
        unit.published = False
        unit.save()
        unit.prerequisites.clear()
        lesson.content = 'Editor’s reviewed lesson content'
        lesson.save()
        exercise.explanation = 'Editor’s specific explanation'
        exercise.save()
        vocabulary.example = 'The editor chose a different example.'
        vocabulary.save()
        topic.explanation = 'Editor’s replacement grammar explanation'
        topic.save()
        article.content = {'intro': 'Editor’s preserved rich article'}
        article.save()
        models = (Language, Level, Unit, Lesson, Exercise, Vocabulary, GrammarTopic, GrammarArticle)
        before = [model.objects.count() for model in models]
        output = StringIO()
        call_command('seed_languages_v10', stdout=output)
        self.assertEqual([model.objects.count() for model in models], before)
        self.assertIn('0 new questions', output.getvalue())
        for item in (language, level, unit, lesson, exercise, vocabulary, topic, article):
            item.refresh_from_db()
        self.assertEqual(language.name, 'Editorial English')
        self.assertFalse(language.is_published)
        self.assertEqual(level.description, 'Editor’s own coverage map')
        self.assertEqual(unit.title, 'Editor’s revised objects unit')
        self.assertFalse(unit.published)
        self.assertFalse(unit.prerequisites.exists())
        self.assertEqual(lesson.content, 'Editor’s reviewed lesson content')
        self.assertEqual(exercise.explanation, 'Editor’s specific explanation')
        self.assertEqual(vocabulary.example, 'The editor chose a different example.')
        self.assertEqual(topic.explanation, 'Editor’s replacement grammar explanation')
        self.assertEqual(article.content['intro'], 'Editor’s preserved rich article')

    def test_dutch_seed_repeat_preserves_manually_edited_prerequisites(self):
        """The seeded Dutch lesson graph must not overwrite teacher changes."""
        level = Level.objects.get(language__code='nl', code='A0')
        units = list(Unit.objects.filter(level=level).order_by('order', 'pk'))
        self.assertGreaterEqual(len(units), 2)
        edited = units[1]
        edited.prerequisites.clear()
        edited.title = 'Edited by curriculum manager'
        edited.save(update_fields=['title'])
        counts_before = (Unit.objects.count(), Lesson.objects.count(), Exercise.objects.count())
        call_command('seed_curriculum', stdout=StringIO())
        edited.refresh_from_db()
        self.assertFalse(edited.prerequisites.exists())
        self.assertEqual(edited.title, 'Edited by curriculum manager')
        self.assertEqual((Unit.objects.count(), Lesson.objects.count(), Exercise.objects.count()), counts_before)

    def test_dutch_topic_is_preserved_and_missing_topic_is_not_recreated(self):
        topic = GrammarTopic.objects.get(level__language__code='nl', level__code='A1',
                                         slug='main-clause-word-order')
        topic.explanation = 'Existing Dutch teacher’s edited explanation'
        topic.save()
        call_command('seed_languages_v10', stdout=StringIO())
        topic.refresh_from_db()
        self.assertEqual(topic.explanation, 'Existing Dutch teacher’s edited explanation')
        Language.objects.get(code='nl').delete()
        output = StringIO()
        call_command('seed_languages_v10', stdout=output)
        self.assertFalse(Language.objects.filter(code='nl').exists())
        self.assertIn('Dutch companion article skipped', output.getvalue())

    def test_second_a0_unit_has_prerequisite_but_a1_is_a_placement_entry(self):
        for code in NEW_CODES:
            with self.subTest(code=code):
                units = list(Unit.objects.filter(level__language__code=code, level__code='A0').order_by('order'))
                self.assertFalse(units[0].prerequisites.exists())
                self.assertEqual(list(units[1].prerequisites.all()), [units[0]])
                self.assertFalse(Unit.objects.get(level__language__code=code,
                                                  level__code='A1').prerequisites.exists())

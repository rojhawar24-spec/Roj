"""Phase 13 real Django/SQLite HTTP tests. Not executed in offline packaging.

Requires Django and a disposable test database. Run via the Phase 13 Windows runner.
"""
from django.test import TestCase
from django.urls import reverse
from academy.models import PlatformSettings


class Phase13ReadinessTests(TestCase):
    def setUp(self):
        PlatformSettings.objects.filter(pk=1).delete()

    def test_readiness_does_not_create_settings_on_get(self):
        before = PlatformSettings.objects.count()
        response = self.client.get(reverse('ready'))
        self.assertEqual(response.status_code, 503)
        self.assertEqual(PlatformSettings.objects.count(), before)
        self.assertEqual(response.json()['database'], 'ok')

    def test_privacy_contact_without_operator_is_not_ready(self):
        cfg = PlatformSettings.objects.create(pk=1, privacy_email='privacy@example.invalid')
        response = self.client.get(reverse('ready'))
        self.assertEqual(response.status_code, 503)
        self.assertTrue(response.json()['privacy_contact_configured'])
        self.assertFalse(response.json()['operator_identity_configured'])
        cfg.organization_name = 'Rozh Example Learning Operator Ltd'
        cfg.save(update_fields=['organization_name'])
        response = self.client.get(reverse('ready'))
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()['ready'])

    def test_operator_without_contact_is_not_ready(self):
        PlatformSettings.objects.create(pk=1, organization_name='Rozh Example Learning Operator Ltd')
        self.assertEqual(self.client.get(reverse('ready')).status_code, 503)

    def test_probe_responses_never_cached(self):
        for name in ('ready', 'health'):
            response = self.client.get(reverse(name))
            self.assertIn('no-store', response['Cache-Control'])
            self.assertIn('no-cache', response['Cache-Control'])

    def test_probe_does_not_accept_post(self):
        for name in ('ready', 'health'):
            self.assertEqual(self.client.post(reverse(name)).status_code, 405)

    def test_health_independent_of_controller_setup(self):
        result = self.client.get(reverse('health'))
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.json(), {'status': 'ok'})

    def test_health_supports_head_without_body(self):
        self.assertEqual(self.client.head(reverse('health')).status_code, 200)

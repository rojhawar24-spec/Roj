"""V35 Django HTTP tests; NOT verified until run against isolated Django DB.

Only tests the live /mistakes/ route, not the retired app_features.mistakes view.
"""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .models import Language, Level, Unit, Lesson, Exercise, MistakeRecord, XPEvent
from .heart_models import HeartEvent


class MistakeAuthorizationV35DjangoTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = get_user_model().objects.create_user('v35-learner',password='V35LongTestPassword2026!')
        self.course = Language.objects.create(code='nl',name='Dutch V35',slug='dutch-v35',
                                               description='',is_published=True)
        self.other = Language.objects.create(code='en',name='English V35',slug='english-v35',
                                              description='',is_published=True)
        self.level = Level.objects.create(language=self.course,code='A0',order=0,description='Starter')
        unit = Unit.objects.create(level=self.level,slug='v35-start',title='Starter',summary='',published=True)
        lesson = Lesson.objects.create(unit=unit,slug='v35-lesson',title='Basics',skill='grammar',
                                       content='Basics.',published=True)
        exercise = Exercise.objects.create(lesson=lesson,kind='mcq',order=1,prompt='Choose Yes',
                                           options=['Yes','No'],answer='Yes',explanation='Yes')
        self.mistake = MistakeRecord.objects.create(user=self.user,exercise=exercise)
        profile = self.user.learning_profile
        profile.preferred_language = self.course
        profile.placement_completed = True
        profile.onboarding_required = True
        profile.onboarding_completed = True
        profile.save(update_fields=['preferred_language','placement_completed',
                                    'onboarding_required','onboarding_completed'])
        self.client.force_login(self.user)

    def submit(self,answer='Yes'):
        return self.client.post(reverse('mistakes'),{'mistake_id':self.mistake.pk,'answer':answer})

    def assert_unchanged(self):
        self.mistake.refresh_from_db()
        self.assertIsNone(self.mistake.corrected_at)
        self.assertFalse(XPEvent.objects.filter(user=self.user,reason='mistake').exists())
        self.assertFalse(HeartEvent.objects.filter(user=self.user,key=f'mistake:{self.mistake.pk}').exists())

    def test_valid_correction_awarded_once(self):
        self.assertEqual(self.submit().status_code,302)
        self.mistake.refresh_from_db()
        self.assertIsNotNone(self.mistake.corrected_at)
        self.assertEqual(XPEvent.objects.filter(user=self.user,reason='mistake').count(),1)
        self.assertEqual(self.submit().status_code,404)
        self.assertEqual(XPEvent.objects.filter(user=self.user,reason='mistake').count(),1)

    def test_old_course_mistake_no_longer_eligible(self):
        self.user.learning_profile.preferred_language = self.other
        self.user.learning_profile.save(update_fields=['preferred_language'])
        self.assertEqual(self.submit().status_code,404)
        self.assert_unchanged()

    def test_no_selected_course_denied(self):
        self.user.learning_profile.preferred_language = None
        self.user.learning_profile.save(update_fields=['preferred_language'])
        self.assertEqual(self.submit().status_code,403)
        self.assert_unchanged()

    def test_unpublished_course_denied(self):
        self.course.is_published = False
        self.course.save(update_fields=['is_published'])
        self.assertEqual(self.submit().status_code,403)
        self.assert_unchanged()

    def test_revoked_placement_denied(self):
        self.user.learning_profile.placement_completed = False
        self.user.learning_profile.save(update_fields=['placement_completed'])
        self.assertEqual(self.submit().status_code,403)
        self.assert_unchanged()

    def test_incomplete_required_onboarding_denied(self):
        self.user.learning_profile.onboarding_completed = False
        self.user.learning_profile.save(update_fields=['onboarding_completed'])
        self.assertEqual(self.submit().status_code,403)
        self.assert_unchanged()

    def test_suspended_account_denied(self):
        self.user.learning_profile.suspended_at = timezone.now()
        self.user.learning_profile.save(update_fields=['suspended_at'])
        self.assertEqual(self.submit().status_code,403)
        self.assert_unchanged()

    def test_legacy_review_account_denied(self):
        self.user.learning_profile.legacy_review_required = True
        self.user.learning_profile.save(update_fields=['legacy_review_required'])
        self.assertEqual(self.submit().status_code,403)
        self.assert_unchanged()

    def test_unpublished_lesson_cannot_be_rewarded(self):
        lesson = self.mistake.exercise.lesson
        lesson.published = False
        lesson.save(update_fields=['published'])
        self.assertEqual(self.submit().status_code,404)
        self.assert_unchanged()

    def test_wrong_answer_never_awards_xp(self):
        self.assertEqual(self.submit('No').status_code,302)
        self.assert_unchanged()

    def test_mistake_write_is_post_only_for_rewards(self):
        self.assertEqual(self.client.get(reverse('mistakes')).status_code,200)
        self.assert_unchanged()

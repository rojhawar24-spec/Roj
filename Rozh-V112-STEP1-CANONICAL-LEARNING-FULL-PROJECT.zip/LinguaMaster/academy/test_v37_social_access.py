"""V37 live-Django tests (NOT executed in offline release environment)."""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .models import Friendship, XPEvent
from .social_models import AvatarStyle, SocialGift


class SocialV37HttpTests(TestCase):
    def setUp(self):
        cache.clear()
        User=get_user_model()
        self.alice=User.objects.create_user(username='v37-alice',password='StrongV37TestPass!')
        self.bob=User.objects.create_user(username='v37-bob',password='StrongV37TestPass!')
        for user in (self.alice,self.bob):
            p=user.learning_profile
            p.social_opt_in=True
            p.save(update_fields=['social_opt_in'])
        self.client.force_login(self.alice)
        XPEvent.objects.create(user=self.alice,event_key='v37-learned',amount=20,reason='lesson')

    def invite(self):
        return self.client.post(reverse('friends'),{'username':self.bob.username})

    def send_gift(self):
        return self.client.post(reverse('gifts_send',args=[self.bob.pk]),{'kind':'star'})

    def connection(self,status='accepted'):
        return Friendship.objects.create(from_user=self.alice,to_user=self.bob,status=status)

    def test_active_friend_request_works(self):
        self.assertEqual(self.invite().status_code,302)
        self.assertEqual(Friendship.objects.filter(from_user=self.alice,to_user=self.bob,status='pending').count(),1)

    def test_suspended_sender_cannot_invite(self):
        p=self.alice.learning_profile
        p.suspended_at=timezone.now();p.save(update_fields=['suspended_at'])
        self.assertEqual(self.invite().status_code,403)
        self.assertFalse(Friendship.objects.exists())

    def test_suspended_target_cannot_be_invited(self):
        p=self.bob.learning_profile
        p.suspended_at=timezone.now();p.save(update_fields=['suspended_at'])
        self.assertEqual(self.invite().status_code,302)
        self.assertFalse(Friendship.objects.exists())

    def test_quarantined_target_cannot_be_invited(self):
        p=self.bob.learning_profile
        p.legacy_review_required=True;p.save(update_fields=['legacy_review_required'])
        self.assertEqual(self.invite().status_code,302)
        self.assertFalse(Friendship.objects.exists())

    def test_pending_onboarding_disallows_invite(self):
        p=self.alice.learning_profile
        p.onboarding_required=True;p.onboarding_completed=False
        p.save(update_fields=['onboarding_required','onboarding_completed'])
        self.assertEqual(self.invite().status_code,403)
        self.assertFalse(Friendship.objects.exists())

    def test_suspended_inviter_cannot_be_accepted(self):
        invitation=Friendship.objects.create(from_user=self.bob,to_user=self.alice,status='pending')
        p=self.bob.learning_profile
        p.suspended_at=timezone.now();p.save(update_fields=['suspended_at'])
        response=self.client.post(reverse('friend_action',args=[invitation.pk,'accept']))
        self.assertEqual(response.status_code,403)
        invitation.refresh_from_db()
        self.assertEqual(invitation.status,'pending')

    def test_suspended_gift_recipient_denied(self):
        self.connection()
        p=self.bob.learning_profile
        p.suspended_at=timezone.now();p.save(update_fields=['suspended_at'])
        self.assertEqual(self.send_gift().status_code,403)
        self.assertFalse(SocialGift.objects.exists())

    def test_quarantined_sender_cannot_send_gift(self):
        self.connection()
        p=self.alice.learning_profile
        p.legacy_review_required=True;p.save(update_fields=['legacy_review_required'])
        self.assertEqual(self.send_gift().status_code,403)
        self.assertFalse(SocialGift.objects.exists())

    def test_active_gift_still_works_once(self):
        self.connection()
        self.assertEqual(self.send_gift().status_code,302)
        self.assertEqual(SocialGift.objects.count(),1)
        self.assertEqual(self.send_gift().status_code,302)
        self.assertEqual(SocialGift.objects.count(),1)

    def test_social_opt_out_cannot_send_gift(self):
        self.connection()
        p=self.alice.learning_profile
        p.social_opt_in=False;p.save(update_fields=['social_opt_in'])
        self.assertEqual(self.send_gift().status_code,403)
        self.assertFalse(SocialGift.objects.exists())

    def test_avatar_studio_refuses_suspended_account_without_writing(self):
        p=self.alice.learning_profile
        before=p.avatar
        p.suspended_at=timezone.now();p.save(update_fields=['suspended_at'])
        self.assertEqual(self.client.get(reverse('avatar_studio')).status_code,403)
        self.assertEqual(self.client.post(reverse('avatar_studio'),{'avatar':'🎓','palette':'sky','accessory':'none'}).status_code,403)
        p.refresh_from_db()
        self.assertEqual(p.avatar,before)
        self.assertFalse(AvatarStyle.objects.filter(user=self.alice).exists())

    def test_avatar_basics_do_not_require_social_opt_in(self):
        p=self.alice.learning_profile
        p.social_opt_in=False;p.save(update_fields=['social_opt_in'])
        self.assertEqual(self.client.get(reverse('avatar_studio')).status_code,200)

    def test_suspended_friend_is_hidden_from_social_list(self):
        self.connection()
        p=self.bob.learning_profile
        p.suspended_at=timezone.now();p.save(update_fields=['suspended_at'])
        response=self.client.get(reverse('friends'))
        self.assertEqual(response.status_code,200)
        self.assertFalse(any(x['user'].pk == self.bob.pk for x in response.context['friend_data']))

    def test_suspended_request_sender_is_hidden(self):
        Friendship.objects.create(from_user=self.bob,to_user=self.alice,status='pending')
        p=self.bob.learning_profile
        p.suspended_at=timezone.now();p.save(update_fields=['suspended_at'])
        response=self.client.get(reverse('friends'))
        self.assertEqual(response.status_code,200)
        self.assertFalse(response.context['received'].exists())

    def test_privacy_block_remains_possible_after_opt_out(self):
        relation=self.connection()
        p=self.alice.learning_profile
        p.social_opt_in=False;p.save(update_fields=['social_opt_in'])
        self.assertEqual(self.client.post(reverse('friend_action',args=[relation.pk,'block'])).status_code,302)
        self.assertTrue(Friendship.objects.filter(from_user=self.alice,to_user=self.bob,status='blocked').exists())

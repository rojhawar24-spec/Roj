"""Grammar progress and feedback are scoped to actual learners and published courses."""
from datetime import timedelta
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .grammar_models import GrammarMastery
from .models import Exercise, GrammarTopic, Language, Lesson, Level, MistakeRecord, Unit, XPEvent


class GrammarV9Tests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = get_user_model().objects.create_user('grammar_student', password='ExamplePassword!234')
        self.other = get_user_model().objects.create_user('other_student', password='ExamplePassword!234')
        self.language = Language.objects.create(code='nl', name='Dutch', slug='dutch', description='Dutch', is_published=True)
        self.other_language = Language.objects.create(code='fr', name='French', slug='french', description='French', is_published=True)
        self.level = Level.objects.create(language=self.language, code='A0', order=0, description='Start')
        self.next_level = Level.objects.create(language=self.language, code='A1', order=1, description='Next')
        self.foreign_level = Level.objects.create(language=self.other_language, code='A0', order=0, description='Start')
        self.topic = self.make_topic(self.level, 'greetings', 'Greetings', 'Hoi is a greeting.')
        self.next_topic = self.make_topic(self.next_level, 'articles', 'Articles', 'Use de or het.')
        self.foreign_topic = self.make_topic(self.foreign_level, 'bonjour', 'Bonjour', 'French greeting.')
        for user in (self.user, self.other):
            profile = user.learning_profile
            profile.preferred_language = self.language
            profile.onboarding_completed = True
            profile.placement_completed = True
            profile.save()
        self.client.force_login(self.user)

    @staticmethod
    def make_topic(level, slug, title, explanation):
        return GrammarTopic.objects.create(level=level, slug=slug, title=title, explanation=explanation,
            examples=['Hoi.'], exceptions='None.', common_mistakes='Mind the word order.',
            check_question='Choose the greeting.', check_options=['Hoi', 'Nee'], check_answer='Hoi', published=True)

    def test_library_filters_by_active_course_level_search(self):
        response = self.client.get(reverse('grammar_library'), {'q': 'Articles', 'level': 'A1', 'language': 'fr'})
        self.assertContains(response, 'Articles')
        self.assertNotContains(response, 'Bonjour')
        self.assertEqual([card['topic'].pk for card in response.context['cards']], [self.next_topic.pk])
        self.assertEqual(response.context['topic_total'], 2)

    def test_progress_counts_are_private_and_filters_work(self):
        GrammarMastery.objects.create(user=self.other, topic=self.topic, attempts=3, correct=3, successful_days=3)
        self.assertEqual(self.client.get(reverse('grammar_library')).context['remembered_total'], 0)
        GrammarMastery.objects.create(user=self.user, topic=self.topic, attempts=1, correct=1,
                                     successful_days=1, due_at=timezone.now() - timedelta(hours=1))
        due = self.client.get(reverse('grammar_library'), {'status': 'due'})
        self.assertEqual([card['topic'].pk for card in due.context['cards']], [self.topic.pk])
        self.assertEqual(due.context['due_total'], 1)

    def test_grade_is_server_checked_and_progress_saved_after_redirect(self):
        url = reverse('grammar', args=[self.topic.pk])
        response = self.client.post(url, {'answer': 'Nee'}, follow=True)
        progress = GrammarMastery.objects.get(user=self.user, topic=self.topic)
        self.assertEqual((progress.attempts, progress.correct, progress.successful_days), (1, 0, 0))
        self.assertIs(response.context['feedback'], False)
        self.assertContains(response, 'Hoi is a greeting.')
        self.assertContains(response, 'The correct answer')
        self.client.get(url)
        progress.refresh_from_db()
        self.assertEqual(progress.attempts, 1)
        self.assertEqual(XPEvent.objects.filter(user=self.user).count(), 0)

    def test_successful_days_cannot_be_farmed_by_repeating_same_day(self):
        url = reverse('grammar', args=[self.topic.pk])
        day = timezone.localdate()
        with patch('academy.grammar_v9.timezone.localdate', return_value=day):
            self.client.post(url, {'answer': 'Hoi'})
            self.client.post(url, {'answer': 'Hoi'})
        progress = GrammarMastery.objects.get(user=self.user, topic=self.topic)
        self.assertEqual(progress.successful_days, 1)
        self.assertEqual(progress.status, 'practising')
        for offset in (1, 2):
            with patch('academy.grammar_v9.timezone.localdate', return_value=day + timedelta(days=offset)):
                self.client.post(url, {'answer': 'Hoi'})
        progress.refresh_from_db()
        self.assertEqual(progress.successful_days, 3)
        self.assertEqual(progress.status, 'mastered')

    def test_forged_answer_and_unpublished_topic_do_not_write_progress(self):
        url = reverse('grammar', args=[self.topic.pk])
        self.assertEqual(self.client.post(url, {'answer': 'forged'}).status_code, 400)
        self.assertFalse(GrammarMastery.objects.filter(user=self.user).exists())
        self.topic.published = False
        self.topic.save()
        self.assertEqual(self.client.post(url, {'answer': 'Hoi'}).status_code, 404)

    def test_other_course_and_drafts_are_not_accessible(self):
        self.assertEqual(self.client.get(reverse('grammar', args=[self.foreign_topic.pk])).status_code, 404)
        self.language.is_published = False
        self.language.save()
        self.assertEqual(self.client.get(reverse('grammar', args=[self.topic.pk])).status_code, 404)

    def test_malformed_published_check_never_grades(self):
        self.topic.check_options = {'Hoi': 'a value', 'Nee': 'another value'}
        self.topic.save()
        url = reverse('grammar', args=[self.topic.pk])
        self.assertFalse(self.client.get(url).context['has_check'])
        self.assertEqual(self.client.post(url, {'answer': 'Hoi'}).status_code, 400)
        self.assertFalse(GrammarMastery.objects.filter(user=self.user).exists())

    def test_public_quick_check_does_not_create_personal_progress(self):
        self.client.logout()
        response = self.client.post(reverse('grammar', args=[self.topic.pk]), {'answer': 'Hoi'})
        self.assertEqual(response.status_code, 200)
        self.assertIs(response.context['feedback'], True)
        self.assertFalse(GrammarMastery.objects.exists())

    def test_sorani_labels_and_rtl_render(self):
        profile = self.user.learning_profile
        profile.ui_language = 'ckb'
        profile.save()
        response = self.client.get(reverse('grammar_library'))
        self.assertContains(response, 'dir="rtl"')
        self.assertContains(response, 'گەڕان بۆ بابەتی ڕێزمان')

    def make_mistake(self, user=None, language=None):
        level = self.foreign_level if language == 'foreign' else self.level
        unit, _ = Unit.objects.get_or_create(level=level, slug='greetings', defaults={
            'title': 'Greetings', 'summary': 'Hello', 'published': True})
        lesson, _ = Lesson.objects.get_or_create(unit=unit, slug='hello', defaults={
            'title': 'Hello', 'skill': 'grammar', 'content': 'Say hello.', 'published': True})
        question, _ = Exercise.objects.get_or_create(lesson=lesson, order=1, defaults={
            'kind': 'mcq', 'prompt': 'Say hello?', 'options': ['Hoi', 'Nee'], 'answer': 'Hoi',
            'explanation': 'Hoi greets someone; Nee means no.'})
        return MistakeRecord.objects.create(user=user or self.user, exercise=question)

    def test_wrong_mistake_answer_shows_explanation_and_related_grammar(self):
        mistake = self.make_mistake()
        response = self.client.post(reverse('mistakes'), {'mistake_id': mistake.pk, 'answer': 'Nee'}, follow=True)
        self.assertContains(response, 'Hoi greets someone; Nee means no.')
        self.assertContains(response, self.topic.get_absolute_url())
        mistake.refresh_from_db()
        self.assertIsNone(mistake.corrected_at)
        self.assertEqual(mistake.wrong_count, 2)

    def test_mistake_reward_is_at_most_once_and_another_user_is_private(self):
        mistake = self.make_mistake()
        url = reverse('mistakes')
        self.client.post(url, {'mistake_id': mistake.pk, 'answer': 'Hoi'})
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='mistake').count(), 1)
        self.assertEqual(self.client.post(url, {'mistake_id': mistake.pk, 'answer': 'Hoi'}).status_code, 404)
        other_mistake = self.make_mistake(user=self.other)
        self.assertEqual(self.client.post(url, {'mistake_id': other_mistake.pk, 'answer': 'Hoi'}).status_code, 404)

    def test_mistakes_in_other_course_and_unpublished_lessons_are_excluded(self):
        foreign = self.make_mistake(language='foreign')
        url = reverse('mistakes')
        self.assertEqual(self.client.get(url).context['pending'], 0)
        self.assertEqual(self.client.post(url, {'mistake_id': foreign.pk, 'answer': 'Hoi'}).status_code, 404)
        mistake = self.make_mistake()
        mistake.exercise.lesson.published = False
        mistake.exercise.lesson.save()
        self.assertEqual(self.client.get(url).context['pending'], 0)
        self.assertEqual(self.client.post(url, {'mistake_id': mistake.pk, 'answer': 'Hoi'}).status_code, 404)

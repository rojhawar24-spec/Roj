"""V33 real Django integration tests. Run locally with Django and an isolated test DB.

python manage.py test academy.test_home_v33
"""
import json
import re

from django.test import TestCase
from django.urls import reverse

from .models import Language


class HomeV33IntegrationTests(TestCase):
    def test_four_public_locales_canonical_and_markup(self):
        for url, code in (('/', 'nl'), ('/en/', 'en'), ('/ckb/', 'ckb'), ('/ar/', 'ar')):
            with self.subTest(code=code):
                response = self.client.get(url)
                self.assertEqual(response.status_code, 200)
                self.assertEqual(response.context['UI_LANG'], code)
                self.assertEqual(response.context['canonical_path'], url)
                self.assertContains(response, '<html lang="' + code + '"')
                self.assertContains(response, 'rel="canonical"')
                self.assertContains(response, 'href="' + url + '"')
                self.assertContains(response, 'href="/privacy/"')
                self.assertContains(response, 'href="/try/"')
                self.assertNotContains(response, 'EXPLORE YOUR LEARNING STUDIO')
                match = re.search(r'<script type="application/ld\+json">(.*?)</script>',
                                  response.content.decode('utf-8'), re.DOTALL)
                self.assertIsNotNone(match)
                self.assertEqual(json.loads(match.group(1))['inLanguage'], code)

    def test_published_course_can_be_discovered_without_account(self):
        Language.objects.create(code='nl', name='Nederlands', slug='dutch',
                                description='Dutch language practice', is_published=True)
        response = self.client.get('/en/')
        self.assertContains(response, 'href="/languages/dutch/"')
        self.assertNotContains(response, 'next=%2Flanguages%2Fdutch%2F')
        course = self.client.get('/languages/dutch/')
        self.assertEqual(course.status_code, 200)

    def test_unpublished_course_not_promoted(self):
        Language.objects.create(code='xx', name='Hidden', slug='hidden',
                                description='Unpublished course', is_published=False)
        response = self.client.get('/en/')
        self.assertNotContains(response, 'href="/languages/hidden/"')

    def test_legacy_ui_language_switch_has_same_origin_redirect(self):
        response = self.client.get('/?ui=ar')
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response['Location'], reverse('home_ar'))
        self.assertEqual(self.client.get(response['Location']).status_code, 200)

    def test_sitemap_and_robots_still_available(self):
        sitemap = self.client.get('/sitemap.xml')
        self.assertEqual(sitemap.status_code, 200)
        self.assertIn('application/xml', sitemap['Content-Type'])
        self.assertContains(sitemap, '/en/')
        self.assertContains(sitemap, '/ckb/')
        self.assertContains(sitemap, '/ar/')
        self.assertEqual(self.client.get('/robots.txt').status_code, 200)

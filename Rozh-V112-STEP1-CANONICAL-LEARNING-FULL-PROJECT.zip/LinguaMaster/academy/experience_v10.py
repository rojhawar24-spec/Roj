"""Small shared labels for the four-course, multi-skill learning experience."""
TEXT={
 'en':dict(hearts='Hearts',courses='My courses',choose='Change course',skills='Your practice studio',photos='Learn with pictures',photos_note='See it, name it, remember it.',listening='Listening',listening_note='Listen, understand and type what you hear.',hearts_note='Out of hearts? Write 5 different words 5 times each to earn one.',skills_note='Read, listen, speak, write and revisit what matters.',lesson='Lesson',unit_check='Unit check',current='Your next step',locked='Locked',done='Completed',available='Ready',growing='More lessons are being prepared',path_intro='A clear route, one small step at a time.',free='Free practice',coming='Content in preparation'),
 'nl':dict(hearts='Hartjes',courses='Mijn cursussen',choose='Andere taal kiezen',skills='Jouw oefenruimte',photos='Leren met foto’s',photos_note='Zien, benoemen en onthouden.',listening='Luisteren',listening_note='Luister, begrijp en typ wat je hoort.',hearts_note='Geen hartjes meer? Schrijf 5 woorden elk 5 keer voor 1 hartje.',skills_note='Lezen, luisteren, spreken, schrijven en blijven herhalen.',lesson='Les',unit_check='Unittoets',current='Jouw volgende stap',locked='Vergrendeld',done='Voltooid',available='Klaar om te leren',growing='Meer lessen worden voorbereid',path_intro='Een duidelijke route, één kleine stap tegelijk.',free='Gratis oefenen',coming='Inhoud in voorbereiding'),
 'ckb':dict(hearts='دڵەکان',courses='کۆرسەکانم',choose='زمانێکی تر هەڵبژێرە',skills='شوێنی ڕاهێنانت',photos='فێربوون بە وێنە',photos_note='ببینە، ناوی بڵێ و لە یاد بگرە.',listening='گوێگرتن',listening_note='گوێ بگرە، تێبگە و ئەوەی دەیبیستیت بنووسە.',hearts_note='ئەگەر دڵ نەما، ٥ وشە هەر یەکەیان ٥ جار بنووسە بۆ یەک دڵ.',skills_note='بخوێنەوە، گوێ بگرە، قسە بکە، بنووسە و پێداچوونەوە بکە.',lesson='وانە',unit_check='تاقیکردنەوەی یەکە',current='هەنگاوی داهاتووت',locked='داخراوە',done='تەواوبوو',available='ئامادەی فێربوون',growing='وانەی زیاتر ئامادە دەکرێت',path_intro='ڕێڕەوێکی ڕوون، هەر جارە هەنگاوێکی بچووک.',free='ڕاهێنانی بەخۆڕایی',coming='ناوەڕۆک لە ئامادەکردندایە'),
 'ar':dict(hearts='القلوب',courses='دوراتي',choose='تغيير لغة التعلم',skills='مساحة تدريبك',photos='تعلم بالصور',photos_note='شاهد وسمِّ وتذكر.',listening='الاستماع',listening_note='استمع وافهم واكتب ما تسمعه.',hearts_note='عند نفاد القلوب، اكتب 5 كلمات 5 مرات لكل كلمة لتحصل على قلب.',skills_note='اقرأ واستمع وتحدث واكتب وراجع باستمرار.',lesson='درس',unit_check='اختبار الوحدة',current='خطوتك التالية',locked='مغلق',done='مكتمل',available='جاهز للتعلم',growing='يجري إعداد دروس إضافية',path_intro='مسار واضح، خطوة صغيرة في كل مرة.',free='تدريب مجاني',coming='المحتوى قيد الإعداد'),
}


def context(request):
    from .safe_profile_context_v46 import visible_learning_profile
    profile = visible_learning_profile(request.user)
    locale = profile.ui_language if profile is not None else 'en'
    result={'V10':TEXT.get(locale,TEXT['en'])}
    if profile is not None:
        from .hearts import snapshot
        result['HEARTS']=snapshot(request.user)
    return result


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'experience_v10', ['TEXT'])

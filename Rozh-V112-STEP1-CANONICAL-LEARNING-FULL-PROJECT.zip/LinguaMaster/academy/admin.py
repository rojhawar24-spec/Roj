"""Content editor admin behind mandatory 2FA; sensitive settings remain owner-only."""
import json
from django.contrib import admin
from django.core.serializers.json import DjangoJSONEncoder
from django.forms.models import model_to_dict
from .models import *

class RevisionAdmin(admin.ModelAdmin):
    """Snapshot each content revision in a durable append-only history."""
    def save_model(self,request,obj,form,change):
        if change and hasattr(obj,'content_version'):
            obj.content_version+=1
        super().save_model(request,obj,form,change)
        if hasattr(obj,'content_version'):
            snapshot=json.loads(json.dumps(model_to_dict(obj),cls=DjangoJSONEncoder))
            ContentRevision.objects.create(model_label=obj._meta.label,object_pk=obj.pk,
                version=obj.content_version,editor=request.user,snapshot=snapshot)
            AuditEvent.objects.create(actor=request.user,action='content_saved',target=f'{obj._meta.label}:{obj.pk}')
    def delete_model(self,request,obj):
        AuditEvent.objects.create(actor=request.user,action='content_deleted',target=f'{obj._meta.label}:{obj.pk}')
        super().delete_model(request,obj)

@admin.register(Language)
class LanguageAdmin(RevisionAdmin):
    list_display=['name','code','is_published'];list_filter=['is_published'];search_fields=['name','code']
@admin.register(Level)
class LevelAdmin(RevisionAdmin):
    list_display=['language','code','order'];list_filter=['language']
@admin.register(Unit)
class UnitAdmin(RevisionAdmin):
    list_display=['title','level','season','order','published','content_version'];list_filter=['level__language','season','published'];search_fields=['title','summary']
    filter_horizontal=['prerequisites']
from django import forms

class V58LessonForm(forms.ModelForm):
    class Meta:
        model = Lesson
        fields = '__all__'

    def clean(self):
        cleaned = super().clean()
        if cleaned.get('published'):
            from .mixed_policy_v102 import publication_has_canonical_exercises
            kinds = self.instance.exercises.values_list('kind', flat=True) if self.instance.pk else ()
            if not publication_has_canonical_exercises(kinds):
                self.add_error('published', 'Save a draft, add supported exercises, then publish.')
        if cleaned.get('published') and cleaned.get('skill') == 'listening' and cleaned.get('unit'):
            from .audio_v78 import approved_audio_url
            if not approved_audio_url(cleaned.get('audio_text'), cleaned['unit'].level.language.code):
                self.add_error('audio_text', 'A published listening lesson requires an approved recording.')
        if self.instance.pk and cleaned.get('published') and cleaned.get('unit'):
            from .lesson_activities_v58 import published_lesson_activity_errors
            issues = published_lesson_activity_errors(
                self.instance.exercises.all(), cleaned['unit'].level.language.code)
            if issues:
                self.add_error('published',
                    'Fix the authored exercises before publishing: ' + '; '.join(issues[:3]))
            from types import SimpleNamespace
            from .lesson_readiness_v96 import lesson_block_reason
            proposed = SimpleNamespace(skill=cleaned.get('skill'), audio_text=cleaned.get('audio_text', ''))
            if lesson_block_reason(proposed, course_code=cleaned['unit'].level.language.code,
                                   exercises=self.instance.exercises.all()):
                self.add_error('published', 'The lesson must contain only valid, ready supported questions.')
        return cleaned

@admin.register(Lesson)
class LessonAdmin(RevisionAdmin):
    form = V58LessonForm
    list_display=['title','unit','skill','published','order','content_version'];list_filter=['skill','published'];search_fields=['title','content']
from django import forms
class V58ExerciseForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from .mixed_policy_v102 import editorial_kind_choices
        field = self.fields['kind']
        field.choices = editorial_kind_choices(field.choices, self.instance.kind if self.instance.pk else None)

    class Meta:
        model=Exercise
        fields='__all__'
    def clean(self):
        cleaned=super().clean()
        from .lesson_activities_v58 import validate_activity
        if all(key in cleaned for key in ('kind','prompt','options','answer','explanation','activity_data')):
            if cleaned['kind'] in ('mcq', 'short'):
                # Admin and the dedicated Manager editor must reject the same
                # invalid MCQ answer keys; neither may bypass editorial checks.
                from .quality_rules import check_exercise
                errors = [message for severity, _, message in check_exercise(
                    cleaned['kind'], cleaned['prompt'], cleaned['options'],
                    cleaned['answer'], cleaned['explanation'], cleaned['activity_data'])
                    if severity == 'error']
            else:
                errors = validate_activity(
                    cleaned['kind'], cleaned['prompt'], cleaned['options'],
                    cleaned['answer'], cleaned['explanation'], cleaned['activity_data'])
            if cleaned['kind'] == 'mcq':
                from .mixed_policy_v102 import canonical_mcq_errors
                errors += canonical_mcq_errors(cleaned['prompt'], cleaned['options'], cleaned['answer'], cleaned['explanation'], cleaned['activity_data'])
            if errors: raise forms.ValidationError('; '.join(dict.fromkeys(errors)))
        if cleaned.get('lesson') and cleaned['lesson'].published and cleaned.get('kind'):
            from .curriculum_policy_v99 import AUTO_GRADED_LEER_SPEEL_KINDS
            if cleaned['kind'] not in AUTO_GRADED_LEER_SPEEL_KINDS:
                self.add_error('kind', 'Convert this historical exercise to a supported kind or unpublish the lesson.')
        if cleaned.get('kind') == 'listening' and cleaned.get('lesson') and cleaned['lesson'].published:
            from .audio_v78 import approved_audio_url
            data = cleaned.get('activity_data')
            if not isinstance(data, dict) or not approved_audio_url(data.get('audio_text'), cleaned['lesson'].unit.level.language.code):
                self.add_error('activity_data', 'Published listening exercises require an approved recording.')
        return cleaned

@admin.register(Exercise)
class ExerciseAdmin(RevisionAdmin):
    form=V58ExerciseForm
    list_display=['prompt','lesson','kind','difficulty'];search_fields=['prompt']
    class Media:
        js = ('academy/exercise-author-v58.js',)
        css = {'all': ('academy/exercise-author-v58.css',)}

from .grammar_rich_models import GrammarArticle

class GrammarArticleInline(admin.StackedInline):
    model = GrammarArticle
    extra = 0
    max_num = 1
    fields = ['content']
    verbose_name = 'Visual grammar article'
    verbose_name_plural = 'Visual grammar article (optional)'

    class Media:
        js = ('academy/grammar-author-v15.js', 'academy/grammar-author-v57.js')
        css = {'all': ('academy/grammar-author-v15.css', 'academy/grammar-author-v57.css', 'academy/grammar-author-v64.css')}

    def formfield_for_dbfield(self, db_field, request, **kwargs):
        field = super().formfield_for_dbfield(db_field, request, **kwargs)
        if field is not None and db_field.name == 'content':
            field.widget.attrs.update({'rows': 24, 'cols': 100, 'class': 'v15-grammar-json'})
        return field

@admin.register(GrammarTopic)
class GrammarTopicAdmin(RevisionAdmin):
    list_display=['title','level','published','content_version'];list_filter=['level__language','level__code','published'];search_fields=['title','explanation']
    inlines = [GrammarArticleInline]
@admin.register(Vocabulary)
class VocabularyAdmin(RevisionAdmin):
    list_display=['word','level','translation','word_family','published'];list_filter=['level__language','published'];search_fields=['word','translation']
@admin.register(Badge)
class BadgeAdmin(admin.ModelAdmin):
    list_display=['name','tier','xp_threshold']

# Read-only evidence, accessible only to users given relevant Django permissions.
@admin.register(ContentRevision)
class ContentRevisionAdmin(admin.ModelAdmin):
    list_display=['model_label','object_pk','version','editor','timestamp'];readonly_fields=[f.name for f in ContentRevision._meta.fields]
    def has_add_permission(self,request):return False
    def has_change_permission(self,request,obj=None):return False
    def has_delete_permission(self,request,obj=None):return False
@admin.register(AuditEvent)
class AuditAdmin(admin.ModelAdmin):
    list_display=['created_at','actor','action','target'];readonly_fields=[f.name for f in AuditEvent._meta.fields]
    def has_add_permission(self,request):return False
    def has_change_permission(self,request,obj=None):return False
    def has_delete_permission(self,request,obj=None):return False

# Owner control is intentionally in /manager; no sensitive user/account settings in content admin.

# Block bulk deletion without per-object audit entries.
admin.site.disable_action('delete_selected')

# User/group permission management stays with the owner, never ordinary content editors.
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.contrib.auth.admin import UserAdmin, GroupAdmin

class OwnerOnlyAdminPermissions:
    def has_module_permission(self, request): return request.user.is_superuser
    def has_view_permission(self,request,obj=None): return request.user.is_superuser
    def has_add_permission(self,request): return request.user.is_superuser
    def has_change_permission(self,request,obj=None): return request.user.is_superuser
    def has_delete_permission(self,request,obj=None): return request.user.is_superuser

admin.site.unregister(get_user_model())
@admin.register(get_user_model())
class OwnerUserAdmin(OwnerOnlyAdminPermissions,UserAdmin):
    def save_related(self, request, form, formsets, change):
        # Called inside Django Admin's atomic change-form transaction AFTER
        # group/direct permission formsets have been saved. Conservatively
        # revoke every old session for any existing User edit; this includes
        # staff/superuser and Manager group changes via Django Admin.
        super().save_related(request, form, formsets, change)
        if change:
            from .privilege_revocation_v92 import revoke_user_sessions
            if revoke_user_sessions(form.instance.pk) != 1:
                raise RuntimeError('Owner User edit rolled back: missing Profile')

admin.site.unregister(Group)
@admin.register(Group)
class OwnerGroupAdmin(OwnerOnlyAdminPermissions,GroupAdmin):
    def save_related(self, request, form, formsets, change):
        # Renaming a Group to "Rozh Managers" or altering Group.permissions
        # may elevate every current member, not merely the edited actor.
        super().save_related(request, form, formsets, change)
        if change:
            from .privilege_revocation_v92 import revoke_group_members_sessions
            revoke_group_members_sessions(form.instance)


# Personal study analytics are read-only and can be inspected only by the owner.
class OwnerReadOnlyAppAdmin(OwnerOnlyAdminPermissions,admin.ModelAdmin):
    def has_add_permission(self,request):return False
    def has_change_permission(self,request,obj=None):return False
    def has_delete_permission(self,request,obj=None):return False

@admin.register(XPEvent)
class XPEventAdmin(OwnerReadOnlyAppAdmin):
    list_display=['user','reason','amount','created_at']
    search_fields=['user__username','user__email']
@admin.register(MistakeRecord)
class MistakeRecordAdmin(OwnerReadOnlyAppAdmin):
    list_display=['user','exercise','wrong_count','corrected_at']
@admin.register(ArenaRun)
class ArenaRunAdmin(OwnerReadOnlyAppAdmin):
    list_display=['user','level','score','earned_xp','started_at','finished_at']
@admin.register(DailyChest)
class DailyChestAdmin(OwnerReadOnlyAppAdmin):
    list_display=['user','day','bonus_xp','opened_at']
@admin.register(AppNotification)
class AppNotificationAdmin(OwnerReadOnlyAppAdmin):
    list_display=['user','title','created_at','read_at']


from .models import SkillPracticeAttempt
@admin.register(SkillPracticeAttempt)
class SkillPracticeAttemptAdmin(admin.ModelAdmin):
    list_display = ('user', 'kind', 'score', 'input_method', 'created_at')
    list_filter = ('kind', 'input_method', 'created_at')
    search_fields = ('user__username',)
    readonly_fields = ('user','vocabulary','kind','score','input_method','answer_length','created_at')
    def has_add_permission(self, request): return False
    def has_change_permission(self, request, obj=None): return False


# Support can inspect new account records; credit balances are never edited here.
for model in (GrammarMastery, AvatarStyle, SocialGift, LearningPreferences,
              AICreditWallet, AICreditPurchase, AICreditDebit, StripeWebhookReceipt,
              CourseEnrollment, HeartBalance, HeartEvent, PhotoAttempt):
    admin.site.register(model, OwnerReadOnlyAppAdmin)


# V14: only the owner can configure minted gifts. Claim and coin records are read-only.
@admin.register(SeasonGift)
class SeasonGiftAdmin(OwnerOnlyAdminPermissions, admin.ModelAdmin):
    list_display = ('level','enabled','bonus_xp','bonus_coins','emoji','updated_at')
    list_filter = ('enabled','level__language','level__code')
    search_fields = ('level__language__name','level__code')
    def save_model(self,request,obj,form,change):
        super().save_model(request,obj,form,change)
        AuditEvent.objects.create(actor=request.user, action='season_gift_configured',
                                  target=f'Level:{obj.level_id}',
                                  metadata={'enabled':obj.enabled,'bonus_xp':obj.bonus_xp,
                                            'bonus_coins':obj.bonus_coins})
    def delete_model(self,request,obj):
        AuditEvent.objects.create(actor=request.user,action='season_gift_deleted',
                                  target=f'Level:{obj.level_id}')
        super().delete_model(request,obj)

@admin.register(SeasonGiftClaim)
class SeasonGiftClaimAdmin(OwnerReadOnlyAppAdmin):
    list_display = ('user','level','xp_awarded','coins_awarded','claimed_at')
    search_fields = ('user__username','user__email')
    list_filter = ('level__language','level__code')

@admin.register(CoinEvent)
class CoinEventAdmin(OwnerReadOnlyAppAdmin):
    list_display = ('user','reason','amount','created_at')
    search_fields = ('user__username','user__email')


@admin.register(LearningSeason)
class LearningSeasonAdmin(admin.ModelAdmin):
    """Owner/content-editor managed seasons. Unit authorization never trusts this metadata."""
    list_display = ['title','level','order','theme','published']
    list_filter = ['level__language','published','theme']
    search_fields = ['title','slug']
    ordering = ['level__language','level__order','order','id']
    def save_model(self, request, obj, form, change):
        super().save_model(request, obj, form, change)
        AuditEvent.objects.create(actor=request.user, action='rozh_season_saved', target=f'season:{obj.pk}')
    def delete_model(self, request, obj):
        AuditEvent.objects.create(actor=request.user, action='rozh_season_deleted', target=f'season:{obj.pk}')
        super().delete_model(request, obj)

# V77: standalone educator-controlled placement items. Do not publish auto-samples.
from .placement_models_v77 import PlacementBankItem, PlacementRun

@admin.register(PlacementBankItem)
class PlacementBankItemAdmin(RevisionAdmin):
    list_display = ['course', 'stage', 'skill', 'educator_reviewed', 'published', 'content_version']
    list_filter = ['course', 'stage', 'skill', 'educator_reviewed', 'published']
    search_fields = ['prompt', 'source_reference']
    readonly_fields = ['content_version', 'updated_at']

@admin.register(PlacementRun)
class PlacementRunAdmin(OwnerReadOnlyAppAdmin):
    list_display = ['user', 'course', 'status', 'chosen_level', 'created_at', 'updated_at']
    list_filter = ['status', 'course']
    readonly_fields = ['user','course','status','history','current_item_id','current_version','current_digest',
                       'result','chosen_level','created_at','updated_at']

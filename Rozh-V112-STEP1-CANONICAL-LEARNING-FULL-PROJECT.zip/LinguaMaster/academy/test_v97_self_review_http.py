"""Run in a real Django environment: python manage.py test academy.test_v97_self_review_http."""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase

from .models import Language, Level, Unit, Lesson, LessonProgress, XPEvent, Exercise


class SelfReviewCompletionHttpTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = get_user_model().objects.create_user(
            'v97_selfreview', 'selfreview@example.org', 'SafePassw0rdV97!')
        self.language = Language.objects.create(
            name='Dutch', slug='dutch', code='nl', description='Dutch', is_published=True)
        self.level = Level.objects.create(language=self.language, code='A0', description='Starter')
        self.unit = Unit.objects.create(level=self.level, slug='v97-unit', title='Starter',
                                        summary='Starter', published=True)
        self.lesson = Lesson.objects.create(unit=self.unit, slug='v97-selfreview',
                                            title='Speaking practice', skill='speaking',
                                            content='Speak three sentences.', published=True)
        profile = self.user.learning_profile
        profile.preferred_language = self.language
        profile.ui_language = 'en'
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.save()
        self.client.force_login(self.user)

    @property
    def url(self):
        return f'/lessons/{self.lesson.pk}/'

    def test_get_shows_branded_unavailable_page(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 409)
        self.assertTemplateUsed(response, 'academy/lesson_unavailable_v96.html')
        self.assertFalse(LessonProgress.objects.filter(user=self.user).exists())

    def test_post_without_confirmation_cannot_create_progress(self):
        response = self.client.post(self.url, {})
        self.assertEqual(response.status_code, 409)
        self.assertFalse(LessonProgress.objects.filter(user=self.user).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_confirmed_self_review_does_not_create_progress_or_xp(self):
        for _ in range(2):
            response = self.client.post(self.url, {'self_check': 'yes'})
            self.assertEqual(response.status_code, 409)
        self.assertFalse(LessonProgress.objects.filter(user=self.user).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_historical_record_is_not_deleted(self):
        LessonProgress.objects.create(user=self.user, lesson=self.lesson, score=0)
        response = self.client.post(self.url, {'self_check': 'yes'})
        self.assertEqual(response.status_code, 409)
        self.assertEqual(LessonProgress.objects.filter(user=self.user, lesson=self.lesson).count(), 1)
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_sorani_block_is_rtl(self):
        profile = self.user.learning_profile
        profile.ui_language = 'ckb'
        profile.save(update_fields=['ui_language'])
        response = self.client.post(self.url, {'self_check': 'yes'})
        self.assertEqual(response.status_code, 409)
        self.assertContains(response, 'dir="rtl"', status_code=409)
        self.assertContains(response, 'ئەم وانەیە هێشتا ئامادە نییە', status_code=409)

    def test_legacy_short_cannot_be_graded_by_direct_ajax_or_full_form(self):
        question = Exercise.objects.create(lesson=self.lesson, kind='short',
            prompt='Old unbounded prompt?', answer='yes', explanation='Old content')
        from django.urls import reverse
        from .heart_models import HeartEvent
        ajax = self.client.post(reverse('lesson_answer', args=[self.lesson.pk]),
                                {'exercise_id': question.pk, 'answer': 'yes'})
        self.assertEqual(ajax.status_code, 409)
        self.assertEqual(ajax.json()['error_code'], 'activity_not_ready')
        self.assertEqual(self.client.post(self.url, {f'answer_{question.pk}': 'yes'}).status_code, 409)
        self.assertFalse(LessonProgress.objects.filter(user=self.user).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())
        self.assertFalse(HeartEvent.objects.filter(user=self.user).exists())

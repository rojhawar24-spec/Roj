"""Django runtime checks for legacy review UI retirement. Run isolated only."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Language, Level, Vocabulary, ReviewCard, XPEvent


class RetiredBrainTrainingDjangoTests(TestCase):
    def setUp(self):
        self.user=get_user_model().objects.create_user('v71-review-user',password='V71TestingSecurePass#123')
        self.client.force_login(self.user)

    def test_old_get_pages_redirect_without_awards(self):
        self.assertRedirects(self.client.get(reverse('review')),reverse('word'))
        self.assertRedirects(self.client.get(reverse('weekly_review')),reverse('daily_weekly_review'))
        self.assertFalse(XPEvent.objects.filter(user=self.user,reason='review').exists())

    def test_no_brain_training_links_in_student_ui(self):
        for route in ('play_hub','practice_hub','dashboard','hearts'):
            response=self.client.get(reverse(route))
            # A consent or onboarding redirect is possible in some environments;
            # only assert absence in a fully rendered 200 page.
            if response.status_code==200:
                content=response.content.decode('utf-8')
                self.assertNotIn('BRAIN TRAINING',content)
                self.assertNotIn('Toughest words',content)
                self.assertNotIn('href="/review/"',content)

    def test_old_get_no_review_card_or_user_progress_mutation(self):
        lang=Language.objects.create(name='V71 Dutch',code='nl',slug='v71-dutch',is_published=True)
        level=Level.objects.create(language=lang,code='A0',order=0,description='')
        word=Vocabulary.objects.create(level=level,word='v71word',translation='word',pronunciation='',example='',published=True)
        card=ReviewCard.objects.create(user=self.user,vocabulary=word)
        for url in ('/review/','/weekly-review/'):
            response=self.client.get(url)
            self.assertEqual(response.status_code,302)
            self.assertNotIn(word.word,response.content.decode('utf-8'))
        card.refresh_from_db()
        self.assertEqual(card.repetitions,0)
        self.assertFalse(XPEvent.objects.filter(user=self.user,reason='review').exists())

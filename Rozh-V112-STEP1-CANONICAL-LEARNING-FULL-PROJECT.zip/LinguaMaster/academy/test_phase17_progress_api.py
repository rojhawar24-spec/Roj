"""Real Django/SQLite/DRF integration tests. Run only in a disposable database.

These are not proof of success until the Windows isolated runner actually
executes them. All tests use self-created accounts and lessons.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Language, Level, Unit, Lesson, LessonProgress, Profile


class ProgressAPITests(TestCase):
    URL = '/api/me/progress/'

    def setUp(self):
        User = get_user_model()
        self.learner = User.objects.create_user('phase17_student',
                         'phase17-student@example.invalid', 'TemporaryStrong!42')
        self.other = User.objects.create_user('phase17_other',
                         'phase17-other@example.invalid', 'TemporaryStrong!42')
        language = Language.objects.create(code='nl', name='Dutch', slug='dutch',
                             description='Dutch language', is_published=True)
        level = Level.objects.create(language=language, code='A0', description='Starting', order=0)
        unit = Unit.objects.create(level=level, slug='phase17-unit', title='Synthetic unit',
                                   summary='Test only', order=0, published=True)
        lessons = Lesson.objects.bulk_create([
            Lesson(unit=unit, slug=f'lesson-{i}', title=f'Lesson {i}',
                   skill='reading', content='Test-only content', order=i,
                   published=True)
            for i in range(125)
        ])
        self.lessons = lessons
        LessonProgress.objects.bulk_create([
            LessonProgress(user=self.learner, lesson=lesson, score=100)
            for lesson in lessons[:121]
        ])
        LessonProgress.objects.create(user=self.other, lesson=lessons[122], score=90)

    def test_anonymous_must_not_access_private_completions(self):
        response = self.client.get(self.URL)
        self.assertIn(response.status_code, (401, 403))

    def test_default_response_is_bounded_and_private(self):
        self.client.force_login(self.learner)
        response = self.client.get(self.URL)
        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertEqual(body['completed_lessons'], 121)
        self.assertEqual(len(body['lesson_ids']), 100)
        self.assertEqual(body['next_offset'], 100)
        self.assertTrue(body['has_more'])
        self.assertEqual(body['lesson_ids'], sorted(body['lesson_ids']))
        self.assertNotIn(self.lessons[122].pk, body['lesson_ids'])
        self.assertIn('no-store', response['Cache-Control'])

    def test_client_can_follow_pages_without_duplicates(self):
        self.client.force_login(self.learner)
        page_1 = self.client.get(self.URL, {'limit': '40'}).json()
        page_2 = self.client.get(self.URL, {'limit': '40', 'offset': '40'}).json()
        page_3 = self.client.get(self.URL, {'limit': '40', 'offset': '80'}).json()
        page_4 = self.client.get(self.URL, {'limit': '40', 'offset': '120'}).json()
        gathered = (page_1['lesson_ids'] + page_2['lesson_ids'] +
                    page_3['lesson_ids'] + page_4['lesson_ids'])
        self.assertEqual(len(gathered), 121)
        self.assertEqual(len(set(gathered)), 121)
        self.assertEqual(gathered, sorted(gathered))
        self.assertFalse(page_4['has_more'])
        self.assertIsNone(page_4['next_offset'])

    def test_invalid_pagination_is_a_controlled_400(self):
        self.client.force_login(self.learner)
        for params in ({'limit':'0'}, {'limit':'101'}, {'offset':'-2'},
                       {'offset':'100001'}, {'limit':'abc'}):
            with self.subTest(params=params):
                self.assertEqual(self.client.get(self.URL, params).status_code, 400)

    def test_missing_profile_is_denied_without_creating_one(self):
        self.client.force_login(self.learner)
        Profile.objects.filter(user=self.learner).delete()
        before = Profile.objects.count()
        response = self.client.get(self.URL, {'limit':'1'})
        self.assertEqual(response.status_code, 403)
        self.assertNotIn('lesson_ids', response.content.decode('utf8'))
        self.assertEqual(Profile.objects.count(), before)

    def test_second_user_sees_only_their_own_progress(self):
        self.client.force_login(self.other)
        result = self.client.get(self.URL).json()
        self.assertEqual(result['completed_lessons'], 1)
        self.assertEqual(result['lesson_ids'], [self.lessons[122].pk])

"""Django integration: run with Windows TEST-ROZH-ALLES.ps1 on an isolated DB.

Never execute against production data. Designed to cover CSRF, XP ledger and
local-day constraints missing from static/offline source checks.
"""
from datetime import date, timedelta
from unittest.mock import patch
from django.contrib.auth import get_user_model
from django.test import TestCase, Client
from django.urls import reverse
from .models import Language, Level, Vocabulary, XPEvent, ReviewCard

class WordOfDayV18Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(username='v18_learner', password='TestPassword!2026')
        cls.dutch = Language.objects.create(code='nl', name='Nederlands', slug='v18-dutch', is_published=True)
        cls.french = Language.objects.create(code='fr', name='Français', slug='v18-french', is_published=True)
        cls.a0_nl = Level.objects.create(language=cls.dutch, code='A0', order=0)
        cls.a0_fr = Level.objects.create(language=cls.french, code='A0', order=0)
        cls.word_nl = Vocabulary.objects.create(level=cls.a0_nl, word='hallo', translation='hello', pronunciation='ha-lo', example='Hallo!', published=True)
        cls.word_fr = Vocabulary.objects.create(level=cls.a0_fr, word='bonjour', translation='hello', pronunciation='bon-jour', example='Bonjour!', published=True)
        cls.draft = Vocabulary.objects.create(level=cls.a0_nl, word='hidden', translation='hidden', pronunciation='', example='', published=False)
        profile=cls.user.learning_profile
        profile.preferred_language=cls.dutch
        profile.placement_completed=True
        profile.save()

    def setUp(self):
        self.client.force_login(self.user)
        self.day=date(2026,11,20)
        patcher=patch('academy.services.user_localdate',return_value=self.day)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_word_and_translation_visible_before_practice(self):
        r=self.client.get(reverse('word'))
        self.assertEqual(r.status_code,200)
        self.assertContains(r,'hallo')
        self.assertContains(r,'hello')
        self.assertNotContains(r,'bonjour')
        self.assertNotContains(r,'hidden')
        self.assertContains(r,'Woord van de dag')

    def test_wrong_translation_does_not_award(self):
        r=self.client.post(reverse('word'),{'answer':'hello'})
        self.assertEqual(r.status_code,200)
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())
        self.assertFalse(ReviewCard.objects.filter(user=self.user).exists())

    def test_correct_spelling_awards_exactly_once(self):
        for value in ('  HALLO  ', 'hallo', 'hallo'):
            self.assertEqual(self.client.post(reverse('word'),{'answer':value}).status_code,200)
        events=XPEvent.objects.filter(user=self.user,reason='daily_word')
        self.assertEqual(events.count(),1)
        self.assertEqual(events.first().amount,10)
        self.user.learning_profile.refresh_from_db()
        self.assertEqual(self.user.learning_profile.xp,10)
        self.assertEqual(ReviewCard.objects.filter(user=self.user, vocabulary=self.word_nl).count(),1)
        self.assertContains(self.client.get(reverse('word')),'al verdiend')

    def test_switch_course_cannot_claim_second_reward_same_day(self):
        self.client.post(reverse('word'), {'answer':'hallo'})
        profile=self.user.learning_profile
        profile.preferred_language=self.french
        profile.save(update_fields=['preferred_language'])
        self.assertEqual(self.client.post(reverse('word'),{'answer':'bonjour'}).status_code,200)
        self.assertEqual(XPEvent.objects.filter(user=self.user,reason='daily_word').count(),1)

    def test_next_calendar_day_can_claim_again(self):
        self.client.post(reverse('word'),{'answer':'hallo'})
        with patch('academy.services.user_localdate', return_value=self.day+timedelta(days=1)):
            self.assertEqual(self.client.post(reverse('word'),{'answer':'hallo'}).status_code,200)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='daily_word').count(),2)

    def test_unpublished_or_missing_course_never_awards_xp(self):
        p=self.user.learning_profile
        p.preferred_language=None
        p.save(update_fields=['preferred_language'])
        self.assertEqual(self.client.post(reverse('word'), {'answer':'hallo'}).status_code,200)
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())
        self.assertContains(self.client.get(reverse('word')), reverse('courses'))

    def test_unbounded_input_and_unrecognized_methods(self):
        self.assertEqual(self.client.post(reverse('word'),{'answer':'hallo'+'x'*10001}).status_code,400)
        self.assertEqual(self.client.put(reverse('word'),data='x', content_type='text/plain').status_code,405)
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_anonymous_can_practise_but_not_earn(self):
        self.client.logout()
        self.assertEqual(self.client.post(reverse('word'),{'answer':'hallo'}).status_code,200)
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_csrf_is_required_for_post(self):
        client=Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        r=client.post(reverse('word'),{'answer':'hallo'})
        self.assertEqual(r.status_code,403)
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

"""V76 integration checks; use an isolated Django test database, never production."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Language, OnboardingDraft, Profile

class KurdishGroupingV76HTTP(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user('kurdi76', 'kurdi76@example.invalid', 'Safe!TempTestPassword76')
        profile, _ = Profile.objects.get_or_create(user=self.user)
        profile.onboarding_required = True
        profile.onboarding_completed = False
        profile.save(update_fields=['onboarding_required','onboarding_completed'])
        self.course = Language.objects.create(code='nl', name='Dutch', slug='v76-nl', is_published=True)
        self.client.force_login(self.user)

    def test_three_distinct_kurdish_options_and_flags(self):
        resp = self.client.get(reverse('onboarding'))
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, 'r76-kurdish-group')
        self.assertContains(resp, 'academy/flags/ckb.svg')
        self.assertContains(resp, 'academy/flags/uk.svg')
        for language in ('ckb','kmr','ku'):
            self.assertContains(resp, 'name="choice" value="'+language+'"')
        self.assertEqual(resp.content.count(b'class="r76-kurdish-group"'), 1)

    def test_kurmanji_saved_in_draft_only_until_complete(self):
        resp = self.client.post(reverse('onboarding'), {'step':'1','choice':'ku'})
        self.assertEqual(resp.status_code, 302)
        draft = OnboardingDraft.objects.get(user=self.user)
        self.assertEqual(draft.ui_language, 'ku')
        self.assertEqual(self.user.learning_profile.ui_language, 'en')
        step = self.client.get(reverse('onboarding'))
        self.assertContains(step,'lang="kmr-Latn"')
        self.assertContains(step,'dir="ltr"')
        self.assertEqual(self.client.post(reverse('onboarding'),{'step':'2','choice':str(self.course.pk)}).status_code, 302)
        self.assertEqual(self.client.post(reverse('onboarding'),{'step':'3','choice':'beginner'}).status_code, 302)
        final = self.client.post(reverse('onboarding'),{'step':'4','choice':'20'})
        self.assertEqual(final.status_code, 302)
        self.user.learning_profile.refresh_from_db()
        self.assertEqual(self.user.learning_profile.ui_language,'ku')
        self.assertEqual(self.user.learning_profile.preferred_language, self.course)
        self.assertTrue(self.user.learning_profile.onboarding_completed)

    def test_badini_remains_rtl_and_independent(self):
        self.client.post(reverse('onboarding'),{'step':'1','choice':'kmr'})
        resp = self.client.get(reverse('onboarding'))
        self.assertContains(resp,'lang="kmr-Arab"')
        self.assertContains(resp,'dir="rtl"')

    def test_other_locale_uses_ukraine_flag(self):
        resp=self.client.get(reverse('onboarding'))
        self.assertContains(resp,'academy/flags/uk.svg')
        self.assertContains(resp,'name="choice" value="uk"')

    def test_rejects_forged_code(self):
        resp=self.client.post(reverse('onboarding'),{'step':'1','choice':'ku-../../x'})
        self.assertEqual(resp.status_code,200)
        self.assertEqual(OnboardingDraft.objects.get(user=self.user).step,1)
        self.assertEqual(OnboardingDraft.objects.get(user=self.user).ui_language,'')

    def test_student_ui_switch_only_changes_ui_locale(self):
        p=self.user.learning_profile
        p.onboarding_required=False;p.onboarding_completed=True;p.preferred_language=self.course
        p.save(update_fields=['onboarding_required','onboarding_completed','preferred_language'])
        resp=self.client.post(reverse('switch_ui_language'),{'ui_language':'ku'})
        self.assertEqual(resp.status_code,302)
        p.refresh_from_db()
        self.assertEqual(p.ui_language,'ku')
        self.assertEqual(p.preferred_language,self.course)

    def test_public_kurmanji_url(self):
        p=self.user.learning_profile
        p.onboarding_required=False;p.onboarding_completed=True
        p.save(update_fields=['onboarding_required','onboarding_completed'])
        self.client.logout()
        resp=self.client.get(reverse('home_ku'))
        self.assertEqual(resp.status_code,200)
        self.assertContains(resp,'lang="kmr-Latn"')
        self.assertContains(resp,'dir="ltr"')

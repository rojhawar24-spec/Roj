"""V72 spelling recovery integration assertions; run on disposable SQLite only."""
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .heart_models import HeartBalance, HeartEvent
from .heart_spelling_v72 import SESSION_KEY, TOTAL, _award, _normalized
from .models import Language, Level, Lesson, Unit, Vocabulary


class HeartSpellingV72Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            username='v72-learner', password='SecureHeartRecoveryV72!')
        cls.other = get_user_model().objects.create_user(
            username='v72-other', password='SecureOtherV72!')
        cls.language = Language.objects.create(code='nl', name='Dutch', slug='dutch-v72',
                                               description='Dutch', is_published=True)
        cls.level = Level.objects.create(language=cls.language, code='A0', description='Beginner')
        cls.unit = Unit.objects.create(level=cls.level, slug='v72-unit', title='Words',
                                       summary='Words', published=True)
        cls.lesson = Lesson.objects.create(unit=cls.unit, slug='v72-lesson',
                                            title='Practice words', skill='reading',
                                            content='Words', published=True)
        cls.words = [Vocabulary.objects.create(level=cls.level, word=word,
                     translation=word+' meaning', pronunciation='', example='', published=True)
                     for word in ('appel', 'huis', 'boek', 'water', 'school', 'tafel')]
        profile = cls.user.learning_profile
        profile.preferred_language = cls.language
        profile.placement_completed = True
        profile.onboarding_completed = True
        profile.save()

    def setUp(self):
        self.client.force_login(self.user)
        HeartBalance.objects.update_or_create(user=self.user,
                defaults={'remaining': 0, 'regenerated_at': timezone.now()})

    def begin(self, next_path=None):
        response = self.client.post(reverse('heart_spelling_start'), {
            'next': next_path or reverse('lesson', args=[self.lesson.pk])})
        self.assertRedirects(response, reverse('heart_spelling'))
        return self.client.session[SESSION_KEY]

    def answer(self, state, text, position=None, token=None):
        return self.client.post(reverse('heart_spelling'), {
            'answer': text, 'position': str(state['position'] if position is None else position),
            'token': state['token'] if token is None else token,
            'claimed_hearts': '5000', 'word_id': '9999'})

    def write_all(self):
        for index in range(TOTAL):
            state = self.client.session[SESSION_KEY]
            pk = state['words'][index // 5]
            text = Vocabulary.objects.get(pk=pk).word
            response = self.answer(state, text)
            self.assertEqual(response.status_code, 302)
            self.assertEqual(self.client.session[SESSION_KEY]['position'], index + 1)

    def test_25_correct_spellings_grant_exactly_one_heart_and_resume(self):
        state = self.begin()
        self.assertEqual(len(state['words']), 5)
        self.assertEqual(len(set(state['words'])), 5)
        self.assertEqual(state['position'], 0)
        self.write_all()
        result = self.client.get(reverse('heart_spelling'))
        self.assertEqual(result.status_code, 200)
        self.assertTrue(result.context['completed'])
        self.assertEqual(result.context['resume'], reverse('lesson', args=[self.lesson.pk]))
        self.assertContains(result, '1 hartje')
        self.assertEqual(HeartBalance.objects.get(user=self.user).remaining, 1)
        ledger = HeartEvent.objects.get(user=self.user, key='spelling:'+state['token'])
        self.assertEqual(ledger.kind, 'recovery')
        self.assertEqual(ledger.delta, 1)
        self.assertEqual(HeartEvent.objects.filter(user=self.user,key__startswith='spelling:').count(), 1)
        last_word = Vocabulary.objects.get(pk=state['words'][-1]).word
        self.assertEqual(self.answer(self.client.session[SESSION_KEY], last_word).status_code, 200)
        self.assertEqual(HeartBalance.objects.get(user=self.user).remaining, 1)

    def test_wrong_answers_retries_and_stale_replays_do_not_advance(self):
        state = self.begin()
        self.assertEqual(self.answer(state, 'not the expected word').status_code, 200)
        self.assertEqual(self.client.session[SESSION_KEY]['position'], 0)
        pk = state['words'][0]
        self.assertEqual(self.answer(state, Vocabulary.objects.get(pk=pk).word).status_code, 302)
        self.assertEqual(self.client.session[SESSION_KEY]['position'], 1)
        self.assertEqual(self.answer(state, Vocabulary.objects.get(pk=pk).word).status_code, 409)
        self.assertEqual(self.answer(self.client.session[SESSION_KEY], 'appel', token='forged').status_code, 409)
        self.assertEqual(self.client.session[SESSION_KEY]['position'], 1)
        self.assertFalse(HeartEvent.objects.filter(user=self.user,key__startswith='spelling:').exists())

    def test_recovery_requires_zero_hearts(self):
        HeartBalance.objects.filter(user=self.user).update(remaining=2)
        response = self.client.post(reverse('heart_spelling_start'))
        self.assertRedirects(response, reverse('hearts'))
        self.assertNotIn(SESSION_KEY, self.client.session)

    def test_not_enough_published_distinct_words(self):
        Vocabulary.objects.filter(pk__in=[word.pk for word in self.words[2:]]).update(published=False)
        self.assertRedirects(self.client.post(reverse('heart_spelling_start')), reverse('hearts'))
        hearts_page = self.client.get(reverse('hearts'))
        self.assertEqual(hearts_page.status_code, 200)
        self.assertContains(hearts_page, '5 verschillende gepubliceerde woorden')

    def test_untrusted_external_return_path_rejected(self):
        state = self.begin('//evil.example/steal')
        self.assertEqual(state['return_to'], reverse('play_hub'))

    def test_course_switch_and_unpublish_invalidate_running_task(self):
        self.begin()
        Vocabulary.objects.filter(pk=self.client.session[SESSION_KEY]['words'][0]).update(published=False)
        state = self.client.session[SESSION_KEY]
        if state['words'][0] == state['words'][state['position']//5]:
            response = self.answer(state, 'anything')
            self.assertRedirects(response, reverse('hearts'))
        self.assertEqual(HeartBalance.objects.get(user=self.user).remaining, 0)
        self.assertFalse(HeartEvent.objects.filter(user=self.user,key__startswith='spelling:').exists())

    def test_award_idempotent_and_full_capacity_never_exceeded(self):
        from unittest.mock import patch
        token='test-idempotent-run'
        first,result = _award(self.user, token)
        self.assertEqual(result, 'earned')
        again,result = _award(self.user, token)
        self.assertEqual(result, 'no_reward')
        self.assertEqual(again['remaining'], 1)
        HeartBalance.objects.filter(user=self.user).update(remaining=5)
        third,result = _award(self.user, 'other-token')
        self.assertEqual(result, 'full')
        self.assertEqual(third['remaining'], 5)
        self.assertEqual(HeartEvent.objects.filter(user=self.user,key__startswith='spelling:').count(), 2)

    def test_one_user_cannot_claim_another_users_task(self):
        state=self.begin()
        self.client.force_login(self.other)
        self.assertRedirects(self.client.get(reverse('heart_spelling')), reverse('hearts'))
        self.assertEqual(HeartBalance.objects.get(user=self.user).remaining, 0)

    def test_localization_spelling_and_no_daily_word_changes(self):
        self.assertEqual(_normalized('  APPÉL  '), _normalized('appél'))
        self.assertNotEqual(_normalized('appel'), _normalized('appél'))
        for value in ('nl','en','ckb','ar'):
            from .heart_spelling_v72 import LABELS
            self.assertEqual(set(LABELS[value]), set(LABELS['en']))
        from pathlib import Path
        source=(Path(__file__).parent/'views.py').read_text(encoding='utf8')
        self.assertIn('def word_of_day(', source)

    def test_play_hub_has_zero_heart_prompt(self):
        response=self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Verdien een hartje')
        self.assertContains(response, 'Je hartjes zijn op!')

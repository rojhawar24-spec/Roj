"""Django integration tests; only count after REAL test runner executes them."""
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType
from django.test import Client, TestCase
from django.urls import reverse
from .privilege_session_v93 import SESSION_PRIVILEGE_KEY

class PermissionMetadataHTTPTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username='v94_qa_student', email='v94_qa_student@example.invalid',
            password='V94-Only-A-Disposable-QA-Password!')
        self.client = Client()
        self.permission = Permission.objects.create(
            codename='rozh_qa_read_alpha', name='Rozh QA read alpha',
            content_type=ContentType.objects.get_for_model(get_user_model()))

    def login(self):
        self.client.force_login(self.user)
        self.assertEqual(len(self.client.session[SESSION_PRIVILEGE_KEY]), 64)

    def assert_revoked(self):
        response = self.client.get(reverse('dashboard'))
        self.assertIn(response.status_code, (301, 302))
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_direct_grant_codename_edited_in_place(self):
        self.user.user_permissions.add(self.permission)
        self.login()
        Permission.objects.filter(pk=self.permission.pk).update(codename='rozh_qa_delete_alpha')
        self.assert_revoked()

    def test_direct_grant_content_type_edited_in_place(self):
        self.user.user_permissions.add(self.permission)
        self.login()
        other_type = ContentType.objects.get_for_model(Group)
        Permission.objects.filter(pk=self.permission.pk).update(content_type=other_type)
        self.assert_revoked()

    def test_group_grant_codename_edited_in_place(self):
        group = Group.objects.create(name='V94 QA group')
        group.permissions.add(self.permission)
        self.user.groups.add(group)
        self.login()
        Permission.objects.filter(pk=self.permission.pk).update(codename='rozh_qa_delete_alpha')
        self.assert_revoked()

    def test_group_grant_content_type_edited_in_place(self):
        group = Group.objects.create(name='V94 QA group')
        group.permissions.add(self.permission)
        self.user.groups.add(group)
        self.login()
        other_type = ContentType.objects.get_for_model(Group)
        Permission.objects.filter(pk=self.permission.pk).update(content_type=other_type)
        self.assert_revoked()

    def test_stable_grants_remain_logged_in(self):
        self.user.user_permissions.add(self.permission)
        self.login()
        self.client.get(reverse('dashboard'))
        self.assertIn('_auth_user_id', self.client.session)

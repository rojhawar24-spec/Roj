"""V30 dashboard presentation — pure read-only mapping of authorized server route.

Never manufactures levels, modifies learner progress, or introduces a new unlock path.
"""
from .dashboard_v29 import LABELS as V29_LABELS

EXTRA = {
 'nl': dict(all_complete='Alle beschikbare lessen afgerond', no_lessons='Er zijn voor deze taal nog geen gepubliceerde lessen. Kies een andere cursus.', finished_note='Je hebt alle beschikbare lessen voltooid. Ontdek nieuwe oefeningen op je leerkaart.', completed_lessons='Afgeronde lessen', reviews_due='Herhalen', my_errors='Mijn fouten', my_world='Mijn leerwereld', next_step='Pak je volgende stap', focus='Jouw focus', world='Wereld', in_this_world='In dit hoofdstuk', view_map='Open mijn volledige leerkaart', jump_current='Naar mijn huidige level', quick_practice='Oefen iets anders', your_today='Vandaag', completed='voltooid', currently='Jij bent hier', lesson_unit='lessen', locked_detail='Voltooi eerst de vorige stap', current_unit='Nu beschikbaar', path_empty='Kies een cursus met beschikbare lessen om je leerwereld te openen.', more_details='Meer statistieken en leerhulpmiddelen', of='van', look_ahead='Kijk wat hierna komt', back_to_study='Verder waar je was', pick_language='Kies eerst je taal', safe_note='Je voortgang wordt automatisch bewaard.', all_tools='Andere leeractiviteiten'),
 'en': dict(all_complete='All available lessons completed', no_lessons='This language has no published lessons yet. Choose another course.', finished_note='You have completed every available lesson. Explore more activities on your learning map.', completed_lessons='Lessons completed', reviews_due='Due for review', my_errors='My mistakes', my_world='My learning world', next_step='Your next step', focus='Your focus', world='World', in_this_world='In this chapter', view_map='Open my full learning map', jump_current='Jump to current level', quick_practice='Practice something else', your_today='Today', completed='complete', currently='You are here', lesson_unit='lessons', locked_detail='Finish the previous step first', current_unit='Ready to play', path_empty='Choose a course with published lessons to begin your journey.', more_details='More stats and learning tools', of='of', look_ahead='See what is next', back_to_study='Pick up where you left off', pick_language='Choose your learning language', safe_note='Your progress saves automatically.', all_tools='Other learning activities'),
 'ckb': dict(all_complete='هەموو وانە بەردەستەکانت تەواو کردووە', no_lessons='ئەم زمانە هێشتا وانەی بڵاوکراوەی نییە. کۆرسێکی تر هەڵبژێرە.', finished_note='هەموو وانە بەردەستەکانت تەواو کردووە. ڕاهێنانی تر لە نەخشەی فێربوون ببینە.', completed_lessons='وانەی تەواوکراو', reviews_due='پێویست بە دووبارەکردنەوە', my_errors='هەڵەکانم', my_world='جیهانی فێربوونی من', next_step='هەنگاوی دواترت', focus='سەرنجی ئێستات', world='جیهان', in_this_world='لە ئەم بەشەدا', view_map='بینینی نەخشەی تەواوی فێربوون', jump_current='بڕۆ بۆ ئاستی ئێستام', quick_practice='ڕاهێنانێکی تر هەڵبژێرە', your_today='ئەمڕۆ', completed='تەواوبووە', currently='تۆ لێرەیت', lesson_unit='وانە', locked_detail='سەرەتا هەنگاوی پێشوو تەواو بکە', current_unit='ئامادەی دەستپێکردن', path_empty='بۆ دەستپێکردن کۆرسێکی خاوەن وانە هەڵبژێرە.', more_details='ئامار و ئامرازەکانی تر', of='لە', look_ahead='ببینە دواتر چی دێت', back_to_study='لەو شوێنە بەردەوام بە کە ماویت', pick_language='سەرەتا زمانی فێربوون هەڵبژێرە', safe_note='پێشکەوتنت بە خۆکار پاشەکەوت دەبێت.', all_tools='چالاکییەکانی تری فێربوون'),
 'ar': dict(all_complete='أكملت جميع الدروس المتاحة', no_lessons='لا توجد دروس منشورة لهذه اللغة بعد. اختر دورة أخرى.', finished_note='لقد أنهيت كل الدروس المتاحة. استكشف أنشطة أخرى في خريطة التعلّم.', completed_lessons='الدروس المكتملة', reviews_due='للمراجعة', my_errors='أخطائي', my_world='عالم تعلّمي', next_step='خطوتك التالية', focus='تركيزك الآن', world='العالم', in_this_world='في هذا الفصل', view_map='افتح خريطة التعلم كاملة', jump_current='انتقل إلى مستواي الحالي', quick_practice='اختر تدريبًا آخر', your_today='اليوم', completed='مكتمل', currently='أنت هنا', lesson_unit='دروس', locked_detail='أكمل الخطوة السابقة أولًا', current_unit='جاهز للبدء', path_empty='اختر دورة تحتوي دروسًا منشورة لتبدأ رحلتك.', more_details='مزيد من الإحصاءات والأدوات', of='من', look_ahead='اكتشف الخطوة القادمة', back_to_study='تابع من حيث توقفت', pick_language='اختر لغة التعلم أولًا', safe_note='يُحفظ تقدمك تلقائيًا.', all_tools='أنشطة تعليمية أخرى'),
}


def for_language(code):
    return EXTRA.get(code, EXTRA['en'])


def pick_worlds(stages, max_worlds=3, max_nodes=6):
    """Show an honest selection of real published curriculum units near current.

    Does not link locked units or change their unlock status; the caller renders
    non-interactive locked items. Full learning map remains available separately.
    """
    if not (1 <= max_worlds <= 8 and 1 <= max_nodes <= 12):
        raise ValueError('Invalid preview size')
    available = [stage for stage in stages if stage.get('items')]
    if not available:
        return []
    current = next((n for n,stage in enumerate(available) if any(i.get('is_current') for i in stage['items'])), 0)
    start = max(0, current-1)
    if start + max_worlds > len(available):
        start = max(0, len(available)-max_worlds)
    result=[]
    for stage in available[start:start+max_worlds]:
        items=stage['items']
        focused=next((n for n,item in enumerate(items) if item.get('is_current')), None)
        begin=0 if focused is None else max(0, min(focused-2, len(items)-max_nodes))
        shown=items[begin:begin+max_nodes]
        result.append(dict(level=stage['level'], chapter_title=stage.get('chapter_title',''),
            items=shown, has_current=any(i.get('is_current') for i in shown),
            total=len(items), shown=len(shown), done=sum(i.get('state')=='done' for i in items),
            progress=int(round(100*stage.get('done',0)/stage.get('total',1))) if stage.get('total') else 0))
    return result


def next_game_url(route, reverse):
    """Use the *game* player or authorized unit test, not a classic lesson link.

    URLs are generated with Django reverse and contain no user-provided hosts.
    """
    item=next((item for stage in route.get('stages', ()) for item in stage.get('items', ())
               if item.get('is_current') and item.get('state') in ('active','test')), None)
    if item is None:
        return None
    if item['state']=='test':
        return reverse('assessment_unit', args=[item['unit'].pk])
    return reverse('journey_play', args=[item['unit'].pk])


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'dashboard_v30', ['EXTRA'])

# V75: both maps contain all seven languages only after V74 locale expansion.
assert set(EXTRA)==set(V29_LABELS)
assert all(set(v)==set(EXTRA['nl']) for v in EXTRA.values())

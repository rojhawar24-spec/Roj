"""Live Django tests, using isolated Django test DB. Not run as offline tests."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

class PublicAuthLanguageTests(TestCase):
    def test_direct_auth_stays_english_for_legacy_unconfigured_visitors(self):
        response=self.client.get(reverse('login'))
        self.assertContains(response, 'Sign in and continue')
        self.assertContains(response, 'Forgot password?')
        self.assertContains(self.client.get(reverse('register')), 'Start learning now.')

    def test_guest_locale_follows_to_selected_feature_signin(self):
        for code,direction in [('nl','ltr'),('en','ltr'),('ckb','rtl'),('ar','rtl')]:
            with self.subTest(code=code):
                self.client.get(reverse('home')+'?ui='+code)
                response=self.client.get(reverse('login')+'?next=/grammar/')
                self.assertEqual(response.status_code,200)
                self.assertContains(response,'lang="'+code+'"')
                self.assertContains(response,'dir="'+direction+'"')
                self.assertContains(response,'name="next" value="/grammar/"')
                self.assertContains(response,'lm26-destination')

    def test_explicit_locale_switch_on_auth_keeps_intent(self):
        self.client.get(reverse('home')+'?ui=ckb')
        response=self.client.get(reverse('register')+'?ui=ar&next=/skills/listening/')
        self.assertContains(response,'lang="ar"')
        self.assertContains(response,'name="next" value="/skills/listening/"')
        response=self.client.get(reverse('login')+'?next=/skills/listening/')
        self.assertContains(response,'lang="ar"')
        self.assertContains(response,'lm26-destination')

    def test_suspicious_destination_is_not_rendered_as_intent(self):
        for unsafe in ('//evil.example/','https://evil.example','/login/','/mfa/verify/'):
            with self.subTest(unsafe=unsafe):
                response=self.client.get(reverse('login'),{'next':unsafe})
                self.assertContains(response,'name="next" value=""')
                self.assertNotContains(response,'lm26-destination')

    def test_successful_login_preserves_local_feature(self):
        user=get_user_model().objects.create_user('v26tester','v26tester@example.org','StrongPassword!2026')
        p=user.learning_profile
        p.onboarding_completed=True
        p.placement_completed=True
        p.save(update_fields=['onboarding_completed','placement_completed'])
        self.client.get(reverse('home')+'?ui=nl')
        response=self.client.post(reverse('login'),{'email':user.email,'password':'StrongPassword!2026','next':'/grammar/'})
        self.assertRedirects(response,'/grammar/',fetch_redirect_response=False)

class PublicLocaleSessionTests(TestCase):
    def test_homepage_default_and_login_locale_are_consistent(self):
        self.client.get(reverse('home'))
        self.assertEqual(self.client.session.get('public_ui_language'), 'nl')
        response=self.client.get(reverse('login'), {'next':'/grammar/'})
        self.assertContains(response, 'lang="nl"')

    def test_sign_in_does_not_lose_visitor_language_after_session_rotation(self):
        user=get_user_model().objects.create_user('locale_user', 'locale@example.org', 'StrongPassword!2026')
        profile=user.learning_profile
        profile.onboarding_completed=True
        profile.placement_completed=True
        profile.save(update_fields=['onboarding_completed','placement_completed'])
        self.client.get(reverse('home')+'?ui=ckb')
        response=self.client.post(reverse('login'), {'email':user.email, 'password':'StrongPassword!2026', 'next':'/grammar/'})
        self.assertRedirects(response, '/grammar/', fetch_redirect_response=False)
        self.assertEqual(self.client.session.get('public_ui_language'), 'ckb')

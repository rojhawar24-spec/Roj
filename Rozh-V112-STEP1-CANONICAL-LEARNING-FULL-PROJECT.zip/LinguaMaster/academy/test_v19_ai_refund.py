"""Django integration tests for a previously confirmed AI credit edge case.

Intended execution (ONLY on an isolated test database):
    python manage.py test academy.test_v19_ai_refund --noinput
These tests have not run in the artifact creation environment without Django.
"""
from decimal import Decimal
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase, override_settings

from .models import AIUsage, PlatformSettings
from .billing_models import AICreditDebit, AICreditWallet
from .ai_service import AIUnavailable, tutor_reply


@override_settings(AI_API_KEY='local-v19-synthetic-test-key')
class V19AICreditRefundTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = get_user_model().objects.create_user(
            'v19_ai_learner', 'v19-ai@example.test', 'LocalOnlyStrongPassword!2026')
        profile = self.user.learning_profile
        profile.ai_opt_in = True
        profile.save(update_fields=['ai_opt_in'])
        settings = PlatformSettings.load()
        settings.ai_enabled = True
        settings.ai_emergency_stop = False
        settings.ai_monthly_budget_eur = Decimal('25')
        settings.save()
        AICreditWallet.objects.create(user=self.user, balance=2)

    @patch('academy.ai_service._post')
    def test_explicit_null_usage_refunds_credit_and_avoids_reserved_state(self, post):
        post.side_effect = [
            {'results': [{'flagged': False}]},
            {'choices': [{'message': {'content': 'Valid grammatical reply'}}], 'usage': None},
            {'results': [{'flagged': False}]},
        ]
        with self.assertRaises(AIUnavailable):
            tutor_reply(self.user, 'Explain a Dutch sentence.')
        log = AIUsage.objects.get(user=self.user)
        wallet = AICreditWallet.objects.get(user=self.user)
        self.assertEqual(wallet.balance, 2)
        self.assertEqual(log.status, 'error')
        self.assertTrue(AICreditDebit.objects.get(usage=log).refunded)

    @patch('academy.ai_service._post')
    def test_valid_usage_still_spends_exactly_one_credit(self, post):
        post.side_effect = [
            {'results': [{'flagged': False}]},
            {'choices': [{'message': {'content': 'This is a correct Dutch answer'}}],
             'usage': {'prompt_tokens': 70, 'completion_tokens': 14}},
            {'results': [{'flagged': False}]},
        ]
        result = tutor_reply(self.user, 'Explain a Dutch sentence.')
        self.assertIn('correct Dutch', result)
        self.assertEqual(AICreditWallet.objects.get(user=self.user).balance, 1)
        self.assertEqual(AIUsage.objects.get(user=self.user).status, 'ok')
        self.assertFalse(AICreditDebit.objects.get(user=self.user).refunded)

"""Integrated V9 user journeys across shared app components and private data."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .models import (Language, Level, Unit, Lesson, LessonProgress, GrammarTopic,
                     GrammarMastery, AvatarStyle, LearningPreferences, AICreditWallet)
from .services import award_xp


class ExperienceV9IntegrationTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user('newlearner', 'learner@example.org', 'LearningPass!234')
        cls.language = Language.objects.create(code='nl',name='Dutch',slug='dutch',description='Dutch course',is_published=True)
        cls.level = Level.objects.create(language=cls.language,code='A0',order=0,description='First steps')
        cls.unit = Unit.objects.create(level=cls.level,slug='hello',title='A first conversation',summary='Greetings',published=True)
        cls.lesson = Lesson.objects.create(unit=cls.unit,slug='hello',title='Hello',content='Say hallo.',skill='reading',published=True)
        p = cls.user.learning_profile
        p.placement_completed = True
        p.preferred_language = cls.language
        p.ui_language = 'nl'
        p.save()

    def setUp(self):
        self.client.force_login(self.user)

    def test_dashboard_renders_all_four_locales_and_app_controls(self):
        for lang, direction in [('nl','ltr'),('en','ltr'),('ckb','rtl'),('ar','rtl')]:
            with self.subTest(lang=lang):
                p=self.user.learning_profile
                p.ui_language=lang
                p.save(update_fields=['ui_language'])
                response=self.client.get(reverse('dashboard'))
                self.assertEqual(response.status_code,200)
                self.assertContains(response, f'lang="{lang}" dir="{direction}"')
                self.assertContains(response,'accountAppearance')
                self.assertContains(response,'A first conversation')
                self.assertContains(response,reverse('friends'))
                self.assertContains(response,'theme-bootstrap.js')
                self.assertContains(response,'experience-v9.css')
                self.assertEqual(response.context['journey']['weekly_xp'],0)

    def test_dashboard_uses_actual_activity_and_account_cosmetic(self):
        LessonProgress.objects.create(user=self.user,lesson=self.lesson,score=100)
        AvatarStyle.objects.create(user=self.user,palette='lavender',accessory='none')
        award_xp(self.user,20,event_key='integration:first',reason='lesson')
        response=self.client.get(reverse('dashboard'))
        self.assertEqual(response.context['daily_earned'],20)
        self.assertEqual(response.context['journey']['current_streak'],1)
        self.assertEqual(response.context['skills'][0]['count'],1)
        self.assertContains(response,'avatar-palette-lavender')
        self.assertContains(response,'100%')
        self.assertContains(response,'Je XP-level meet activiteit.')

    def test_export_contains_new_records_only_for_current_user(self):
        other=get_user_model().objects.create_user('otherlearner','other@example.org')
        LearningPreferences.objects.create(user=self.user,timezone_name='Asia/Baghdad',theme='dark')
        AvatarStyle.objects.create(user=self.user,palette='sand')
        topic=GrammarTopic.objects.create(level=self.level,slug='hello',title='Greetings',explanation='Say hello.',
            examples=['Hallo'],exceptions='',common_mistakes='',check_question='Hello?',check_options=['Hallo','Nee'],check_answer='Hallo',published=True)
        GrammarMastery.objects.create(user=self.user,topic=topic,attempts=1,correct=1,successful_days=1,reviewed_at=timezone.now())
        AICreditWallet.objects.create(user=self.user,balance=7,purchased=10)
        AICreditWallet.objects.create(user=other,balance=999,purchased=999)
        response=self.client.post(reverse('data_export'), {'password': 'AStrongExamplePassword!23'})
        data=response.json()
        self.assertEqual(data['preferences'][0]['timezone_name'],'Asia/Baghdad')
        self.assertEqual(data['avatar_style'][0]['palette'],'sand')
        self.assertEqual(data['grammar_progress'][0]['topic_id'],topic.pk)
        self.assertEqual(data['ai_wallet'][0]['balance'],7)
        self.assertNotContains(response,'other@example.org')
        self.assertIn('no-store',response['Cache-Control'])

    def test_password_reset_uses_product_template(self):
        self.client.logout()
        response=self.client.get(reverse('password_reset'))
        self.assertContains(response,'Rozh')
        self.assertNotContains(response,'Django site admin')
        self.assertContains(response,'noindex,nofollow')

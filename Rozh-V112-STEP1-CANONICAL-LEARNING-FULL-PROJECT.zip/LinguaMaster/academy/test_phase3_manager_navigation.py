"""Phase 3 real Django tests: run ONLY in a disposable sandbox test database.

Run: python scripts/phase3_local_manager_runtime.py
Not executed merely by importing/compiling this module.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone


class ManagerUserDirectoryTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.owner = User.objects.create_superuser(
            username='phase3-owner', email='owner@phase3.invalid', password='OnlyForTests!2026'
        )
        p = self.owner.learning_profile
        p.email_verified_at = timezone.now()
        p.totp_secret = 'JBSWY3DPEHPK3PXP'
        p.save(update_fields=['email_verified_at','totp_secret'])
        for index in range(53):
            User.objects.create_user(
                username=f'phase3-student-{index:03d}',
                email=f'phase3-student-{index:03d}@example.invalid',
                password='OnlyForTests!2026',
            )
        self.client.force_login(self.owner)
        session=self.client.session
        session['mfa_verified_id']=self.owner.pk
        session.save()

    def test_all_users_reachable_without_silent_100_user_limit(self):
        # 54 records, exactly 25 per page except for the final page.
        identities=[]
        for number, expected in ((1,25),(2,25),(3,4)):
            response=self.client.get(reverse('manager_users'),{'page':number})
            self.assertEqual(response.status_code,200)
            self.assertEqual(len(response.context['users']),expected)
            self.assertEqual(response.context['page'].paginator.count,54)
            identities.extend(member.pk for member in response.context['users'])
            self.assertContains(response,'r48-pages')
            self.assertNotContains(response, 'lm20-tools-rail')
            self.assertContains(response,'r27-manager-sidebar')
        self.assertEqual(len(set(identities)),54)

    def test_search_filter_kept_while_paging_and_escaped(self):
        response=self.client.get(reverse('manager_users'),{'q':'phase3-student','page':'2'})
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.context['page'].paginator.count,53)
        self.assertEqual(response.context['page'].number,2)
        self.assertContains(response,'q=phase3-student')
        self.assertEqual(len(response.context['users']),25)
        self.assertNotContains(response,'phase3-owner@')

    def test_nonexistent_page_is_gracefully_clamped(self):
        response=self.client.get(reverse('manager_users'),{'page':'not-a-number'})
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.context['page'].number,1)

    def test_owner_only_action_has_no_get_mutation(self):
        user=get_user_model().objects.get(username='phase3-student-000')
        response=self.client.get(reverse('manager_user_action',args=[user.pk,'block']))
        self.assertEqual(response.status_code,405)
        user.refresh_from_db()
        self.assertTrue(user.is_active)

    def test_privileges_are_not_granted_to_student(self):
        learner=get_user_model().objects.get(username='phase3-student-000')
        self.client.force_login(learner)
        response=self.client.get(reverse('manager_users'))
        self.assertEqual(response.status_code,403)
        self.assertNotContains(response,'phase3-student-052@example.invalid',status_code=403)

    def test_unauthenticated_manager_route_redirects_to_login(self):
        self.client.logout()
        response=self.client.get(reverse('manager_users'))
        self.assertEqual(response.status_code,302)
        self.assertTrue(response.url.startswith(reverse('login')))

    def test_without_current_mfa_home_sends_user_to_login_challenge(self):
        session=self.client.session
        session.pop('mfa_verified_id',None)
        session.save()
        response=self.client.get(reverse('home'))
        self.assertRedirects(response,reverse('login'),fetch_redirect_response=False)
        denied=self.client.get(reverse('manager_users'))
        self.assertEqual(denied.status_code,403)

    def test_manager_with_no_mfa_enrollment_must_set_up_first(self):
        profile=self.owner.learning_profile
        profile.totp_secret=''
        profile.save(update_fields=['totp_secret'])
        response=self.client.get(reverse('home'))
        self.assertRedirects(response,reverse('mfa_setup'),fetch_redirect_response=False)
        denied=self.client.get(reverse('manager_users'))
        self.assertEqual(denied.status_code,403)

    def test_revoked_profile_state_denies_manager_views(self):
        profile=self.owner.learning_profile
        profile.suspended_at=timezone.now()
        profile.save(update_fields=['suspended_at'])
        response=self.client.get(reverse('manager_users'))
        self.assertEqual(response.status_code,403)

    def test_role_membership_is_not_enumerated_outside_visible_page(self):
        response=self.client.get(reverse('manager_users'),{'page':3})
        visible_ids={member.pk for member in response.context['users']}
        self.assertTrue(set(response.context['R48_MANAGER_IDS']).issubset(visible_ids))

"""V63 learner-facing transitions, derived from real published course content.

No writes, unlock overrides, or speculative links. Existing lesson grading, XP,
hearts and prerequisite rules remain authoritative in their original views.
"""
from django.db.models import Q
from django.urls import reverse

from .models import Assessment, Exercise, Lesson, Unit
from .services import allowed_unit, unit_lessons_done
from .lesson_readiness_v96 import lesson_block_reason


LABELS = {
    'nl': dict(next_lesson='Volgende les', unit_test='Doe de unittoets',
               return_path='Terug naar Leer & Speel', help='Uitleg bekijken',
               no_next='Er is nog geen volgende speelbare les. De opname of inhoud kan nog in voorbereiding zijn. Ga terug naar Leer & Speel.',
               resume='Begin meteen met vraag 1', retry='Les opnieuw oefenen'),
    'en': dict(next_lesson='Next lesson', unit_test='Take the unit test',
               return_path='Back to Learn & Play', help='Show explanation',
               no_next='There is no next playable lesson yet. Audio or content may still need review. Return to Learn & Play.',
               resume='Start directly with question 1', retry='Practice this lesson again'),
    'ckb': dict(next_lesson='وانەی داهاتوو', unit_test='تاقیکردنەوەی یەکەکە بکە',
                return_path='گەڕانەوە بۆ فێربە و یاری بکە', help='ڕوونکردنەوە ببینە',
                no_next='هێشتا وانەیەکی داهاتووی ئامادە نییە. لەوانەیە دەنگ یان ناوەڕۆک چاوەڕێی پشکنین بێت. بگەڕێوە بۆ فێربوون و یاری.',
                resume='ڕاستەوخۆ بە پرسیاری یەکەم دەست پێ بکە', retry='وانەکە دووبارە ڕاهێنان بکە'),
    'ar': dict(next_lesson='الدرس التالي', unit_test='ابدأ اختبار الوحدة',
               return_path='العودة إلى تعلّم والعب', help='عرض الشرح',
               no_next='لا يوجد درس تالٍ جاهز بعد. ربما ينتظر الصوت أو المحتوى المراجعة. ارجع إلى مسار التعلّم.',
               resume='ابدأ مباشرة بالسؤال الأول', retry='تدرب على الدرس مجددًا'),
}


def for_language(code):
    return LABELS.get(code, LABELS['en'])


def next_step(user, lesson, *, profile=None):
    """Return only the next server-admitted step or None.

    Stay within the published sequence, never skip a locked unit, and require
    the unit assessment when its authored lessons have all been completed.
    Caller must use this only after the current lesson is completed/credited.
    """
    current_unit = lesson.unit
    candidate = (Lesson.objects.filter(unit=current_unit, published=True)
                 .filter(Q(order__gt=lesson.order) |
                         Q(order=lesson.order, pk__gt=lesson.pk))
                 .select_related('unit__level__language').prefetch_related('exercises')
                 .order_by('order', 'pk').first())
    if candidate is not None:
        if lesson_block_reason(candidate, exercises=candidate.exercises.all()):
            return None
        return {'kind': 'lesson', 'url': reverse('lesson', args=[candidate.pk]),
                'title': candidate.title}

    # Completion depends on real records, not the browser's claimed score.
    if not unit_lessons_done(user, current_unit):
        return None
    if not Assessment.objects.filter(user=user, kind='unit', unit=current_unit, passed=True).exists():
        from .assessment_availability_v105 import has_ready_assessment
        has_test_questions = has_ready_assessment(unit=current_unit)
        if not has_test_questions:
            return None
        return {'kind': 'unit_test', 'url': reverse('assessment_unit', args=[current_unit.pk]),
                'title': current_unit.title}

    # The nearest next published unit is the only candidate. If locked, the
    # student returns to the path; we do not jump over prerequisites.
    later_units = (Unit.objects.filter(
                       level__language_id=current_unit.level.language_id,
                       published=True, lessons__published=True)
                   .select_related('level').distinct()
                   .order_by('level__order', 'level_id', 'order', 'pk'))
    seen_current = False
    for unit in later_units:
        if not seen_current:
            seen_current = unit.pk == current_unit.pk
            continue
        if not allowed_unit(user, unit, profile=profile):
            return None
        next_lesson = unit.lessons.filter(published=True).order_by('order', 'pk').first()
        if next_lesson is not None:
            if lesson_block_reason(next_lesson):
                return None
            return {'kind': 'lesson', 'url': reverse('lesson', args=[next_lesson.pk]),
                    'title': next_lesson.title}
    return None


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'lesson_flow_v63', ['LABELS'])

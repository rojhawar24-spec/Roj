"""Payment integrity and real paid AI access (provider calls are mocked)."""
import hashlib
import hmac
import json
import time
from http.client import IncompleteRead, RemoteDisconnected
from decimal import Decimal
from unittest.mock import patch
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase, override_settings
from django.urls import reverse
from .models import PlatformSettings, AIUsage, Language
from .billing_models import AICreditWallet, AICreditPurchase, AICreditDebit, StripeWebhookReceipt
from .billing_v9 import verify_signature
from .ai_service import tutor_reply, AIUnavailable, _refund_credit

CONFIG = {'STRIPE_SECRET_KEY':'sk_test_local', 'STRIPE_WEBHOOK_SECRET':'whsec_local',
          'STRIPE_AI_PRICE_ID':'price_local', 'AI_CREDIT_PACK_CREDITS':25, 'AI_CREDIT_PACK_AMOUNT_CENTS':499,
          'AI_CREDIT_CURRENCY':'eur', 'AI_API_KEY':'local-test'}


@override_settings(**CONFIG)
class AIPaymentTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = get_user_model().objects.create_user('paidlearner', 'paid@example.test', 'password12345')
        self.client.force_login(self.user)
        cfg = PlatformSettings.load()
        cfg.ai_enabled = True
        cfg.ai_emergency_stop = False
        cfg.ai_monthly_budget_eur = Decimal('25')
        cfg.save()
        self.purchase = AICreditPurchase.objects.create(user=self.user, credits=25, amount_cents=499,
                                          price_id='price_local', stripe_session_id='cs_local')

    def event(self, **changes):
        data = {'id':'cs_local','mode':'payment','status':'complete','payment_status':'paid',
                'metadata':{'purchase_id':str(self.purchase.pk),'credits':'25'},
                'client_reference_id':str(self.user.pk),'amount_total':499,'currency':'eur'}
        data.update(changes)
        return {'id':'evt_local','type':'checkout.session.completed','livemode':False,'data':{'object':data}}

    def post_event(self, event, timestamp=None):
        body = json.dumps(event).encode()
        timestamp = int(time.time()) if timestamp is None else timestamp
        signature = hmac.new(b'whsec_local', str(timestamp).encode()+b'.'+body, hashlib.sha256).hexdigest()
        return self.client.post(reverse('stripe_webhook'), body, content_type='application/json',
                                HTTP_STRIPE_SIGNATURE=f't={timestamp},v1={signature}')

    def test_signed_paid_event_grants_credits_once(self):
        self.assertEqual(self.post_event(self.event()).status_code, 200)
        self.assertEqual(self.post_event(self.event()).status_code, 200)
        wallet = AICreditWallet.objects.get(user=self.user)
        self.assertEqual(wallet.balance,25)
        self.assertEqual(wallet.purchased,25)
        self.assertEqual(StripeWebhookReceipt.objects.count(),1)
        self.purchase.refresh_from_db()
        self.assertEqual(self.purchase.status,'paid')
        self.assertEqual(self.purchase.amount_eur,Decimal('4.99'))

    def test_second_event_for_same_session_does_not_regrant(self):
        self.post_event(self.event())
        second=self.event()
        second['id']='evt_duplicate_session'
        self.assertEqual(self.post_event(second).status_code,200)
        self.assertEqual(AICreditWallet.objects.get(user=self.user).balance,25)

    def test_unsigned_and_stale_events_are_rejected(self):
        response=self.client.post(reverse('stripe_webhook'),json.dumps(self.event()),content_type='application/json')
        self.assertEqual(response.status_code,400)
        self.assertEqual(self.post_event(self.event(),int(time.time())-600).status_code,400)
        self.assertFalse(AICreditWallet.objects.filter(user=self.user).exists())

    def test_wrong_amount_currency_user_status_or_session_never_grants(self):
        for change in ({'amount_total':1},{'currency':'usd'},{'client_reference_id':'999'},
                       {'payment_status':'unpaid'},{'id':'cs_foreign'},{'mode':'subscription'},{'status':'open'}):
            with self.subTest(change=change):
                self.assertEqual(self.post_event(self.event(**change)).status_code,400)
        self.assertFalse(AICreditWallet.objects.filter(user=self.user).exists())

    def test_invalid_purchase_uuid_returns_bad_request_without_credit(self):
        event=self.event()
        event['data']['object']['metadata']['purchase_id']='not-a-uuid'
        self.assertEqual(self.post_event(event).status_code,400)
        self.assertFalse(AICreditWallet.objects.filter(user=self.user).exists())
        self.assertEqual(StripeWebhookReceipt.objects.count(),0)

    def test_test_live_mismatch_never_grants(self):
        event=self.event()
        event['livemode']=True
        self.assertEqual(self.post_event(event).status_code,400)
        self.assertEqual(StripeWebhookReceipt.objects.count(),0)

    def test_return_url_cannot_grant_credit(self):
        response=self.client.get(reverse('ai_plans')+'?payment=return')
        self.assertEqual(response.status_code,200)
        self.assertFalse(AICreditWallet.objects.filter(user=self.user).exists())
        self.assertContains(response,'€ 4.99')

    @patch('academy.billing_v9._stripe_checkout',return_value=('cs_new','https://checkout.stripe.com/c/pay/cs_new'))
    def test_checkout_is_post_only_and_server_sets_pack(self, checkout):
        self.assertEqual(self.client.get(reverse('ai_checkout')).status_code,405)
        response=self.client.post(reverse('ai_checkout'),{'credits':999999,'amount':1})
        self.assertEqual(response.status_code,302)
        new=AICreditPurchase.objects.get(stripe_session_id='cs_new')
        self.assertEqual(new.credits,25)
        self.assertEqual(new.amount_cents,499)
        self.assertEqual(new.status,'pending')
        self.assertFalse(AICreditWallet.objects.filter(user=self.user).exists())

    @override_settings(STRIPE_SECRET_KEY='')
    def test_unconfigured_checkout_is_unavailable(self):
        response=self.client.get(reverse('ai_plans'))
        self.assertContains(response,'currently unavailable')
        self.client.post(reverse('ai_checkout'))
        self.assertEqual(AICreditPurchase.objects.count(),1)

    def test_signature_rejects_modified_body_and_non_ascii_signature(self):
        now=int(time.time())
        signature=hmac.new(b'whsec_local',str(now).encode()+b'.{}',hashlib.sha256).hexdigest()
        self.assertTrue(verify_signature(b'{}',f't={now},v1={signature}','whsec_local',now))
        self.assertFalse(verify_signature(b'{"changed":true}',f't={now},v1={signature}','whsec_local',now))
        self.assertFalse(verify_signature(b'{}',f't={now},v1=کوردی','whsec_local',now))


@override_settings(**CONFIG)
class AIPaidTutorTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user=get_user_model().objects.create_user('ailearner','ai@example.test','password12345')
        profile=self.user.learning_profile
        profile.ai_opt_in=True
        profile.ui_language='ckb'
        profile.placement_level='A1'
        profile.save()
        cfg=PlatformSettings.load()
        cfg.ai_enabled=True
        cfg.ai_emergency_stop=False
        cfg.ai_monthly_budget_eur=Decimal('25')
        cfg.save()

    @patch('academy.ai_service._post')
    def test_no_paid_credit_blocks_provider_and_usage(self, post):
        with self.assertRaises(AIUnavailable):
            tutor_reply(self.user,'Explain Dutch articles.')
        self.assertEqual(AIUsage.objects.count(),0)
        post.assert_not_called()

    @patch('academy.ai_service._post')
    def test_bad_local_input_never_spends_credit(self, post):
        wallet=AICreditWallet.objects.create(user=self.user,balance=2)
        for question in ('','mail me at person@example.test'):
            with self.assertRaises(AIUnavailable):
                tutor_reply(self.user,question)
        wallet.refresh_from_db()
        self.assertEqual(wallet.balance,2)
        self.assertEqual(AICreditDebit.objects.count(),0)
        post.assert_not_called()

    @patch('academy.ai_service._post')
    def test_paid_reply_moderates_both_sides_and_uses_stage_language_and_history(self, post):
        wallet=AICreditWallet.objects.create(user=self.user,balance=2)
        post.side_effect=[{'results':[{'flagged':False}]},
                          {'choices':[{'message':{'content':'Use de for this example.'}}],
                           'usage':{'prompt_tokens':100,'completion_tokens':20}},
                          {'results':[{'flagged':False}]}]
        result=tutor_reply(self.user,'Explain de and het.','Dutch',history=[{'role':'user','content':'I study articles.'}],
                           course_context='A published articles lesson.')
        self.assertEqual(result,'Use de for this example.')
        wallet.refresh_from_db()
        self.assertEqual(wallet.balance,1)
        self.assertEqual(AIUsage.objects.get().status,'ok')
        self.assertEqual(post.call_count,3)
        payload=post.call_args_list[1].args[1]
        self.assertIn('Sorani Kurdish',payload['messages'][0]['content'])
        self.assertIn('A1',payload['messages'][0]['content'])
        self.assertIn('published articles lesson',payload['messages'][0]['content'])
        self.assertEqual(payload['messages'][1]['content'],'I study articles.')

    @patch('academy.ai_service._post',side_effect=AIUnavailable('Unavailable'))
    def test_provider_failure_refunds_exactly_once(self, post):
        wallet=AICreditWallet.objects.create(user=self.user,balance=1)
        with self.assertRaises(AIUnavailable):
            tutor_reply(self.user,'Explain Dutch articles.')
        log=AIUsage.objects.get()
        _refund_credit(log)
        wallet.refresh_from_db()
        self.assertEqual(wallet.balance,1)
        self.assertTrue(AICreditDebit.objects.get().refunded)

    @patch('academy.ai_service.urlrequest.urlopen')
    def test_truncated_or_disconnected_transport_refunds_credit(self, urlopen):
        wallet=AICreditWallet.objects.create(user=self.user,balance=1)
        response=urlopen.return_value.__enter__.return_value
        for failure in (IncompleteRead(b'{', 10), RemoteDisconnected('Connection closed')):
            with self.subTest(failure=type(failure).__name__):
                response.read.side_effect=failure
                with self.assertRaises(AIUnavailable):
                    tutor_reply(self.user,'Explain Dutch articles.')
                wallet.refresh_from_db()
                self.assertEqual(wallet.balance,1)
                latest=AIUsage.objects.latest('pk')
                self.assertEqual(latest.status,'error')
                self.assertTrue(AICreditDebit.objects.get(usage=latest).refunded)
        self.assertFalse(AIUsage.objects.filter(status='reserved').exists())

    @patch('academy.ai_service._post',return_value={'results':[{'flagged':True}]})
    def test_filtered_question_refunds_credit(self, post):
        wallet=AICreditWallet.objects.create(user=self.user,balance=1)
        with self.assertRaises(AIUnavailable):
            tutor_reply(self.user,'Explain a phrase.')
        wallet.refresh_from_db()
        self.assertEqual(wallet.balance,1)
        self.assertEqual(AIUsage.objects.get().status,'blocked')

    def test_sorani_interface_is_rtl_and_credit_gated(self):
        self.client.force_login(self.user)
        response=self.client.get(reverse('ai_tutor'))
        self.assertContains(response,'dir="rtl"')
        self.assertContains(response,'کردیت')
        self.assertNotContains(response,'class="ai-compose"')

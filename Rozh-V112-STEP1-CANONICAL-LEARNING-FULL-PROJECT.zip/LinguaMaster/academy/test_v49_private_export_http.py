"""Django HTTP acceptance tests: execute against disposable local QA DB only.

These tests are NOT represented as run until Django and the database exist.
"""
import json
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import Client, TestCase
from django.urls import reverse
from .models import Profile


class PrivateExportV49Tests(TestCase):
    PASSWORD = 'V49SafeLocalPassword#2026'

    def setUp(self):
        cache.clear()
        self.user = get_user_model().objects.create_user(
            username='v49export', email='v49-export@example.invalid', password=self.PASSWORD)
        self.other = get_user_model().objects.create_user(
            username='v49other', email='v49-other@example.invalid', password='OtherLocalOnly#2026')
        self.client.force_login(self.user)
        self.url = reverse('data_export')

    def test_get_is_confirmation_not_sensitive_json(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'academy/export_account_v49.html')
        self.assertNotEqual(response['Content-Type'], 'application/json')
        self.assertNotIn(b'completed_lessons', response.content)
        self.assertIn('no-store', response['Cache-Control'])
        self.assertContains(response, 'csrfmiddlewaretoken')
        self.assertContains(response, 'export-account-v49.css')

    def test_missing_password_rejected_without_export(self):
        response = self.client.post(self.url)
        self.assertEqual(response.status_code, 403)
        self.assertNotIn('application/json', response['Content-Type'])
        self.assertNotIn(b'completed_lessons', response.content)

    def test_bad_password_rejected_without_export(self):
        response = self.client.post(self.url, {'password': 'wrong'})
        self.assertEqual(response.status_code, 403)
        self.assertNotIn(b'xp_events', response.content)

    def test_correct_password_exports_only_own_data(self):
        self.user.learning_profile.xp = 123
        self.user.learning_profile.save(update_fields=['xp'])
        self.other.learning_profile.xp = 987
        self.other.learning_profile.save(update_fields=['xp'])
        response = self.client.post(self.url, {'password': self.PASSWORD})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response['Content-Type'], 'application/json')
        self.assertIn('attachment', response['Content-Disposition'])
        payload = json.loads(response.content)
        self.assertEqual(payload['profile']['xp'], 123)
        self.assertEqual(payload['email'], self.user.email)
        self.assertNotIn(self.other.email.encode(), response.content)
        self.assertNotIn('password', payload)
        self.assertIn('no-store', response['Cache-Control'])

    def test_missing_profile_keeps_data_portability(self):
        Profile.objects.filter(user=self.user).delete()
        response = self.client.post(self.url, {'password': self.PASSWORD})
        self.assertEqual(response.status_code, 200)
        self.assertIsNone(response.json()['profile'])
        self.assertFalse(Profile.objects.filter(user=self.user).exists())

    def test_fifth_bad_password_locks_export_even_if_correct_later(self):
        for attempt in range(4):
            response = self.client.post(self.url, {'password': 'bad'})
            self.assertEqual(response.status_code, 403, attempt)
        fifth = self.client.post(self.url, {'password': 'bad'})
        self.assertEqual(fifth.status_code, 429)
        self.assertEqual(fifth['Retry-After'], '900')
        response = self.client.post(self.url, {'password': self.PASSWORD})
        self.assertEqual(response.status_code, 429)

    def test_csrf_required_on_password_confirmation(self):
        protected = Client(enforce_csrf_checks=True)
        protected.force_login(self.user)
        response = protected.post(self.url, {'password': self.PASSWORD})
        self.assertEqual(response.status_code, 403)
        self.assertNotIn('application/json', response['Content-Type'])

    def test_anonymous_cannot_view_or_export(self):
        self.client.logout()
        for method in ('get', 'post'):
            response = getattr(self.client, method)(self.url)
            self.assertEqual(response.status_code, 302)
            self.assertIn('/login/', response['Location'])

    def test_put_cannot_download(self):
        self.assertEqual(self.client.put(self.url, {'password': self.PASSWORD}).status_code, 405)

    def test_all_four_translations_and_missing_profile_fallback(self):
        for language in ('en','nl','ckb','ar'):
            Profile.objects.filter(user=self.user).update(ui_language=language)
            response = self.client.get(self.url)
            self.assertEqual(response.status_code, 200)
            self.assertTrue(response.context['E49']['title'])
        Profile.objects.filter(user=self.user).delete()
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context['E49']['title'], 'Download your learning data')

"""Live Django tests (NOT RUN in package-building environment)."""
from copy import deepcopy
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.test import TestCase
from django.urls import reverse
from .grammar_components_v17 import VISUAL_COMPONENT_TYPES
from .grammar_rich_models import GrammarArticle
from .models import GrammarTopic, Language, Level
from .rich_schema import normalize_article

class GrammarV17LiveTests(TestCase):
    def setUp(self):
        self.language=Language.objects.create(code='nl',name='Dutch',slug='dutch',description='Dutch',is_published=True)
        self.level=Level.objects.create(language=self.language,code='A1',description='Basic',order=1)
        self.topic=GrammarTopic.objects.create(level=self.level,slug='word-order',title='Word order',
            explanation='Put the verb second.',examples=['Ik leer.'],exceptions='None',common_mistakes='None',
            check_question='Correct?',check_options=['Ik leer.','Ik leren.'],check_answer='Ik leer.',published=True)
        self.user=get_user_model().objects.create_user('grammar_v17_qa',password='LocalTestPass!234')
        profile=self.user.learning_profile
        profile.preferred_language=self.language
        profile.onboarding_completed=True
        profile.placement_completed=True
        profile.ui_language='nl'
        profile.save()
        self.client.force_login(self.user)

    def test_sample_visual_blocks_render_and_escape(self):
        data={'visual_blocks':[
            {'type':'rule_highlight','title':'Rule','body':'<script>alert(1)</script>'},
            {'type':'word_order_diagram','title':'Sentence','tokens':[{'text':'Ik','role':'subject'},{'text':'leer','role':'verb'}]},
            {'type':'fill_blanks','title':'Fill','prompt':'Ik ____','answer':'leer'},
        ]}
        GrammarArticle.objects.create(topic=self.topic,content=data)
        response=self.client.get(reverse('grammar',args=[self.topic.pk]))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'g17-layout-tokens')
        self.assertContains(response,'&lt;script&gt;alert(1)&lt;/script&gt;')
        self.assertNotContains(response,'<script>alert(1)</script>')
        self.assertNotContains(response,'speak-button')
        self.assertContains(response,'Visuele grammaticagids')

    def test_old_article_and_check_still_work(self):
        GrammarArticle.objects.create(topic=self.topic,content={'intro':'Old explanation'})
        resp=self.client.get(reverse('grammar',args=[self.topic.pk]))
        self.assertNotContains(resp,'g17-toolkit-head')
        self.assertContains(resp,'Old explanation')
        resp=self.client.post(reverse('grammar',args=[self.topic.pk]),{'answer':'Ik leer.'})
        self.assertEqual(resp.status_code,302)

    def test_invalid_component_rejected(self):
        with self.assertRaises(ValidationError):
            GrammarArticle.objects.create(topic=self.topic,content={'visual_blocks':[{'type':'evil','title':'X'}]})

    def test_42_catalog_types(self):
        self.assertEqual(len(VISUAL_COMPONENT_TYPES),42)

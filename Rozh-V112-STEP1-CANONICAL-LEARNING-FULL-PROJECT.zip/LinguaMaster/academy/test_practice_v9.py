"""The mobile practice entry keeps private tools discoverable and counts truthful."""
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .grammar_models import GrammarMastery
from .models import (AppNotification, Exercise, GrammarTopic, Language, Lesson, Level,
                     MistakeRecord, PlatformSettings, ReviewCard, Unit, Vocabulary)
from .practice_v9 import TEXT


class PracticeHubTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user('practice_learner', password='LearningPass!234')
        cls.other = get_user_model().objects.create_user('practice_other', password='LearningPass!234')
        cls.language = Language.objects.create(code='nl', name='Dutch', slug='dutch', description='Dutch', is_published=True)
        cls.foreign = Language.objects.create(code='fr', name='French', slug='french', description='French', is_published=True)
        cls.level = Level.objects.create(language=cls.language, code='A0', order=0, description='Start')
        cls.foreign_level = Level.objects.create(language=cls.foreign, code='A0', order=0, description='Start')
        for user in (cls.user, cls.other):
            profile = user.learning_profile
            profile.preferred_language = cls.language
            profile.onboarding_completed = True
            profile.placement_completed = True
            profile.save()

    def setUp(self):
        self.client.force_login(self.user)

    def word(self, level=None, suffix='1', published=True):
        return Vocabulary.objects.create(level=level or self.level, word='word' + suffix, translation='meaning',
            pronunciation='word', example='A word.', published=published)

    def question(self, level=None, suffix='1', published=True):
        unit = Unit.objects.create(level=level or self.level, slug='unit' + suffix,
            title='Unit', summary='Unit', published=published)
        lesson = Lesson.objects.create(unit=unit, slug='lesson', title='Lesson', skill='grammar',
            content='Content', published=published)
        return Exercise.objects.create(lesson=lesson, prompt='Question?', options=['Yes', 'No'],
            answer='Yes', explanation='Yes is correct.')

    def topic(self, level=None, suffix='1', published=True):
        return GrammarTopic.objects.create(level=level or self.level, slug='topic' + suffix,
            title='Topic', explanation='Explanation.', examples=['Example.'], exceptions='None.',
            common_mistakes='None.', check_question='Question?', check_options=['Yes', 'No'],
            check_answer='Yes', published=published)

    def test_login_required(self):
        self.client.logout()
        response = self.client.get(reverse('practice_hub'))
        self.assertEqual(response.status_code, 302)
        self.assertIn('/login/', response.url)

    def test_due_counts_only_include_this_users_published_active_course(self):
        now = timezone.now()
        due = now - timedelta(days=1)
        ReviewCard.objects.create(user=self.user, vocabulary=self.word(), due=due)
        ReviewCard.objects.create(user=self.user, vocabulary=self.word(suffix='future'), due=now + timedelta(days=1))
        ReviewCard.objects.create(user=self.user, vocabulary=self.word(suffix='draft', published=False), due=due)
        ReviewCard.objects.create(user=self.user, vocabulary=self.word(level=self.foreign_level), due=due)
        ReviewCard.objects.create(user=self.other, vocabulary=self.word(suffix='other'), due=due)
        MistakeRecord.objects.create(user=self.user, exercise=self.question())
        MistakeRecord.objects.create(user=self.user, exercise=self.question(suffix='resolved'), corrected_at=now)
        MistakeRecord.objects.create(user=self.user, exercise=self.question(suffix='draft', published=False))
        MistakeRecord.objects.create(user=self.user, exercise=self.question(level=self.foreign_level))
        MistakeRecord.objects.create(user=self.other, exercise=self.question(suffix='other'))
        GrammarMastery.objects.create(user=self.user, topic=self.topic(), due_at=due)
        GrammarMastery.objects.create(user=self.user, topic=self.topic(suffix='future'), due_at=now + timedelta(days=1))
        GrammarMastery.objects.create(user=self.user, topic=self.topic(suffix='draft', published=False), due_at=due)
        GrammarMastery.objects.create(user=self.user, topic=self.topic(level=self.foreign_level), due_at=due)
        GrammarMastery.objects.create(user=self.other, topic=self.topic(suffix='other'), due_at=due)
        response = self.client.get(reverse('practice_hub'))
        self.assertEqual(response.context['due_words'], 1)
        self.assertEqual(response.context['mistakes'], 1)
        self.assertEqual(response.context['due_grammar'], 1)
        self.assertEqual(response.context['word_count'], 3)
        self.assertEqual(response.context['focus']['url'], reverse('mistakes'))

    def test_no_active_published_course_has_zero_counts(self):
        ReviewCard.objects.create(user=self.user, vocabulary=self.word(), due=timezone.now())
        self.language.is_published = False
        self.language.save()
        try:
            response = self.client.get(reverse('practice_hub'))
            self.assertIsNone(response.context['language'])
            self.assertEqual(response.context['due_words'], 0)
            self.assertEqual(response.context['word_count'], 0)
            self.assertContains(response, reverse('profile'))
        finally:
            self.language.is_published = True
            self.language.save()

    def test_all_core_and_optional_tools_have_real_links(self):
        response = self.client.get(reverse('practice_hub'))
        for route in ('review', 'mistakes', 'grammar_library', 'arena', 'chest', 'leaderboard', 'notifications'):
            self.assertContains(response, f'href="{reverse(route)}"')
        self.assertContains(response, f'href="{reverse("skill_practice", args=["listening"])}"')
        self.assertNotContains(response, '/skills/speaking/')
        self.assertNotContains(response, '/skills/writing/')
        self.assertNotContains(response, 'href="/vocabulary/"')
        self.assertContains(response, 'noindex')

    def test_ai_visibility_respects_global_feature_flag(self):
        settings = PlatformSettings.load()
        settings.ai_enabled = False
        settings.ai_emergency_stop = True
        settings.save()
        response = self.client.get(reverse('practice_hub'))
        self.assertNotContains(response, 'p9-ai-card')
        settings.ai_enabled = True
        settings.ai_emergency_stop = False
        settings.save()
        response = self.client.get(reverse('practice_hub'))
        self.assertContains(response, 'p9-ai-card')
        self.assertContains(response, f'href="{reverse("ai_tutor")}"')
        self.assertContains(response, 'paid credits')

    def test_notifications_count_only_the_current_users_unread_items(self):
        AppNotification.objects.create(user=self.user, event_key='practice:mine', title='Hi', message='Hi')
        AppNotification.objects.create(user=self.user, event_key='practice:read', title='Hi', message='Hi', read_at=timezone.now())
        AppNotification.objects.create(user=self.other, event_key='practice:other', title='Hi', message='Hi')
        self.assertEqual(self.client.get(reverse('practice_hub')).context['unread_count'], 1)

    def test_all_locales_have_labels_and_render_correct_direction(self):
        for locale, direction in [('en', 'ltr'), ('nl', 'ltr'), ('ckb', 'rtl'), ('ar', 'rtl')]:
            with self.subTest(locale=locale):
                self.assertEqual(set(TEXT[locale]), set(TEXT['en']))
                profile = self.user.learning_profile
                profile.ui_language = locale
                profile.save()
                response = self.client.get(reverse('practice_hub'))
                self.assertContains(response, f'lang="{locale}" dir="{direction}"')
                self.assertContains(response, TEXT[locale]['title'])

    def test_next_step_uses_mistakes_then_due_grammar_then_learning(self):
        mistake = MistakeRecord.objects.create(user=self.user, exercise=self.question())
        progress = GrammarMastery.objects.create(user=self.user, topic=self.topic(), due_at=timezone.now() - timedelta(days=1))
        url = reverse('practice_hub')
        self.assertEqual(self.client.get(url).context['focus']['url'], reverse('mistakes'))
        mistake.corrected_at = timezone.now()
        mistake.save()
        self.assertEqual(self.client.get(url).context['focus']['url'], reverse('grammar_library') + '?status=due')
        progress.due_at = timezone.now() + timedelta(days=1)
        progress.save()
        self.assertEqual(self.client.get(url).context['focus']['url'], reverse('learn_path'))

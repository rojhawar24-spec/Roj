"""Bind a pending second-factor challenge to the password-authenticated state.

A pending MFA session MUST NOT outlive a password reset, state-revision bump,
effective privilege change, TOTP secret rotation, or recovery-code change
after the password was accepted. This module
stores only a keyed proof of Django's session-auth hash, account state,
and second-factor inventory. It never stores password hashes, OTPs, recovery
codes, or TOTP secrets in the browser session.

This is defense in depth; the actual Django login/HTTP path must still pass QA.
"""
import hashlib
import hmac
import json

from .session_revocation_v91 import current_state_version
from .privilege_session_v93 import privilege_fingerprint

PENDING_PROOF_KEY = 'rozh_pending_mfa_proof_step2'
PENDING_USER_KEY = 'pending_mfa_user_id'


def _pending_proof(user, profile):
    if user is None or profile is None:
        return None
    auth_hash = user.get_session_auth_hash() if callable(getattr(user, 'get_session_auth_hash', None)) else None
    revision = current_state_version(profile)
    privileges = privilege_fingerprint(user)
    secret = getattr(profile, 'totp_secret', None)
    recovery = getattr(profile, 'mfa_recovery_hashes', None)
    # Do not accept a corrupted or only partially loaded MFA inventory.
    # Recovery hashes are HMAC-SHA256 hex digests; order has no meaning.
    if (not isinstance(auth_hash, str) or not auth_hash or revision is None
            or not isinstance(privileges, str) or len(privileges) != 64
            or not isinstance(secret, str) or not secret
            or type(recovery) is not list
            or any(not isinstance(item, str) or len(item) != 64
                   or any(ch not in '0123456789abcdef' for ch in item)
                   for item in recovery)):
        return None
    state = [str(user.pk), revision, privileges, secret, sorted(recovery)]
    encoded = json.dumps(state, separators=(',', ':'), ensure_ascii=True)
    # Auth hash is already keyed by Django SECRET_KEY; using it as the HMAC
    # key keeps the proof opaque even to a client who can inspect its cookie.
    return hmac.new(auth_hash.encode('utf-8'), encoded.encode('utf-8'),
                    hashlib.sha256).hexdigest()


def start_pending_mfa(session, user, profile):
    """Called ONLY immediately after successful password authentication."""
    proof = _pending_proof(user, profile)
    if proof is None:
        raise RuntimeError('Cannot bind MFA challenge to the authenticated account state.')
    session[PENDING_USER_KEY] = user.pk
    session[PENDING_PROOF_KEY] = proof



def try_start_pending_mfa(session, user, profile):
    """Fail closed on an invalid stored factor inventory without HTTP 500.

    A recoverable invalid account MFA state must never silently bypass the
    second factor or leave a half-built challenge in this browser session.
    Unexpected programming/database exceptions are deliberately not swallowed.
    """
    try:
        start_pending_mfa(session, user, profile)
    except RuntimeError:
        clear_pending_mfa(session)
        return False
    return True


def pending_mfa_matches(session, user, profile):
    supplied = session.get(PENDING_PROOF_KEY)
    expected = _pending_proof(user, profile)
    return bool(
        user is not None and type(session.get(PENDING_USER_KEY)) is type(user.pk)
        and session.get(PENDING_USER_KEY) == user.pk
        and isinstance(supplied, str) and len(supplied) == 64
        and expected is not None and hmac.compare_digest(supplied, expected)
    )


def clear_pending_mfa(session):
    session.pop(PENDING_USER_KEY, None)
    session.pop(PENDING_PROOF_KEY, None)

"""V52 integration tests. Run with Django test runner (temporary test database only)."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Language, OnboardingDraft


class OnboardingV52Tests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user('v52_learner', 'v52@example.invalid', 'A Unique, Secure Test Password 2026!')
        self.user.learning_profile.onboarding_required = True
        self.user.learning_profile.save(update_fields=['onboarding_required'])
        self.lang = Language.objects.create(code='nl', name='Dutch', slug='v52-dutch', description='', is_published=True)
        self.client.force_login(self.user)

    def choose(self, step, value):
        return self.client.post(reverse('onboarding'), {'step': str(step), 'choice': str(value)})

    def test_full_wizard_commits_account_only_at_end(self):
        self.assertContains(self.client.get(reverse('onboarding')), 'Step 1 of 4')
        self.assertRedirects(self.choose(1, 'ckb'), '/onboarding/?step=2', fetch_redirect_response=False)
        self.assertContains(self.client.get('/onboarding/'), 'dir="rtl"')
        self.assertRedirects(self.choose(2, self.lang.pk), '/onboarding/?step=3', fetch_redirect_response=False)
        self.assertRedirects(self.choose(3, 'beginner'), '/onboarding/?step=4', fetch_redirect_response=False)
        original = self.user.learning_profile
        original.refresh_from_db()
        self.assertFalse(original.onboarding_completed)
        self.assertEqual(original.ui_language, 'en')
        self.assertRedirects(self.choose(4, 35), '/onboarding/ready/', fetch_redirect_response=False)
        original.refresh_from_db()
        self.assertTrue(original.onboarding_completed)
        self.assertTrue(original.placement_completed)
        self.assertEqual(original.placement_level, 'A0')
        self.assertEqual(original.preferred_language_id, self.lang.pk)
        self.assertEqual(original.daily_goal_xp, 35)
        self.assertEqual(original.ui_language, 'ckb')
        self.assertFalse(OnboardingDraft.objects.filter(user=self.user).exists())
        self.assertContains(self.client.get('/onboarding/ready/'), 'dir="rtl"')
        self.assertRedirects(self.client.get('/onboarding/ready/'), '/play/', fetch_redirect_response=False)
        self.assertRedirects(self.client.get('/onboarding/'), '/play/', fetch_redirect_response=False)

    def test_interrupted_draft_is_saved_per_user_across_clients(self):
        self.choose(1, 'nl')
        self.choose(2, self.lang.pk)
        draft = OnboardingDraft.objects.get(user=self.user)
        self.assertEqual(draft.step, 3)
        from django.test import Client
        other_device = Client()
        other_device.force_login(self.user)
        self.assertContains(other_device.get('/onboarding/'), 'Stap 3 van 4')
        self.assertNotContains(other_device.get('/onboarding/'), 'app-sidebar')

    def test_existing_completed_user_never_sees_questions(self):
        profile = self.user.learning_profile
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.save(update_fields=['onboarding_completed', 'placement_completed'])
        self.assertRedirects(self.client.get('/onboarding/'), '/play/', fetch_redirect_response=False)
        self.assertFalse(OnboardingDraft.objects.filter(user=self.user).exists())

    def test_cannot_jump_to_step_four(self):
        self.choose(4, '50')
        draft = OnboardingDraft.objects.get(user=self.user)
        self.assertEqual(draft.step, 1)
        self.assertFalse(self.user.learning_profile.onboarding_completed)

    def test_unpublished_course_is_rejected(self):
        hidden = Language.objects.create(code='fr', name='French', slug='v52-french', description='', is_published=False)
        self.choose(1, 'en')
        response = self.choose(2, hidden.pk)
        self.assertContains(response, 'no longer available')
        self.assertIsNone(OnboardingDraft.objects.get(user=self.user).preferred_language)

    def test_skip_choices_use_safe_beginner_defaults(self):
        self.client.post('/onboarding/', {'step':'1', 'skip':'1'})
        self.choose(2, self.lang.pk)
        self.client.post('/onboarding/', {'step':'3', 'skip':'1'})
        self.client.post('/onboarding/', {'step':'4', 'skip':'1'})
        profile = self.user.learning_profile
        profile.refresh_from_db()
        self.assertTrue(profile.onboarding_completed)
        self.assertEqual(profile.daily_goal_xp, 20)
        self.assertTrue(profile.placement_completed)

    def test_starting_level_test_unavailable_has_beginner_fallback(self):
        self.choose(1, 'en')
        self.choose(2, self.lang.pk)
        reply = self.choose(3, 'placement')
        self.assertContains(reply, 'placement quiz is not available')
        self.assertEqual(OnboardingDraft.objects.get(user=self.user).step, 3)
        self.choose(3, 'beginner')
        self.choose(4, 20)
        self.assertTrue(get_user_model().objects.get(pk=self.user.pk).learning_profile.placement_completed)

    def test_change_course_goes_back_to_start_choice(self):
        another = Language.objects.create(code='de', name='German', slug='v52-german', description='', is_published=True)
        self.choose(1, 'en')
        self.choose(2, self.lang.pk)
        self.choose(3, 'beginner')
        self.assertEqual(OnboardingDraft.objects.get(user=self.user).step, 4)
        self.choose(2, another.pk)
        draft = OnboardingDraft.objects.get(user=self.user)
        self.assertEqual(draft.step, 3)
        self.assertEqual(draft.start_choice, '')
        self.assertIsNone(self.user.learning_profile.preferred_language)

    def test_other_account_cannot_read_draft(self):
        self.choose(1, 'ckb')
        stranger = get_user_model().objects.create_user('v52_other', 'other@example.invalid', 'Another Strong Password 2026!')
        stranger.learning_profile.onboarding_required = True
        stranger.learning_profile.save(update_fields=['onboarding_required'])
        self.client.force_login(stranger)
        r = self.client.get('/onboarding/')
        self.assertContains(r, 'Step 1 of 4')
        self.assertNotContains(r, 'Step 2 of 4')

    def test_anonymous_redirects_to_login(self):
        self.client.logout()
        self.assertRedirects(self.client.get('/onboarding/'), '/login/?next=/onboarding/', fetch_redirect_response=False)

    def test_no_sun_or_moon_language_icons(self):
        response = self.client.get('/onboarding/')
        self.assertNotContains(response, '☀️')
        self.assertNotContains(response, '🌙')
        self.assertContains(response, 'name="choice"')
        self.assertContains(response, 'academy/flags/nl.svg')
        self.assertContains(response, 'academy/flags/en.svg')
        self.assertContains(response, 'academy/flags/ckb.svg')
        self.assertNotContains(response, 'academy/flags/ar.svg')

    def test_profile_settings_are_not_changed_during_partial_setup(self):
        self.choose(1, 'ar')
        self.choose(2, self.lang.pk)
        self.user.learning_profile.refresh_from_db()
        self.assertEqual(self.user.learning_profile.ui_language, 'en')
        self.assertIsNone(self.user.learning_profile.preferred_language_id)

    def test_only_real_published_placement_quiz_is_offered(self):
        self.choose(1, 'nl')
        self.choose(2, self.lang.pk)
        response = self.client.get('/onboarding/?step=3')
        self.assertContains(response, 'value="beginner"')
        self.assertNotContains(response, 'value="placement"')
        self.assertNotContains(response, 'Standaard gebruiken')

    def test_goal_options_display_actual_saved_xp_values(self):
        self.choose(1, 'nl')
        self.choose(2, self.lang.pk)
        self.choose(3, 'beginner')
        response = self.client.get('/onboarding/?step=4')
        for amount in (10, 20, 35, 50):
            self.assertContains(response, f'{amount} XP')
        self.assertContains(response, 'value="20" checked')

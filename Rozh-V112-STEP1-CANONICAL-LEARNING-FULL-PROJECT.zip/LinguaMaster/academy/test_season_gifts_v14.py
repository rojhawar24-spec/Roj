"""Django integration tests, to run in user's installed Django environment."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Assessment, CoinEvent, Language, Level, Lesson, Unit, Profile, SeasonGift, SeasonGiftClaim, XPEvent
from .season_gifts_v14 import SeasonGiftUnavailable, claim_season_gift


class SeasonGiftTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        User = get_user_model()
        cls.user = User.objects.create_user(username='gift_student', password='A-super-long-local-password-2026')
        cls.other = User.objects.create_user(username='gift_other', password='A-super-long-local-password-2026')
        cls.lang = Language.objects.create(code='nl', name='Nederlands', slug='dutch', description='Dutch', is_published=True)
        cls.level = Level.objects.create(language=cls.lang, code='A0', order=0, description='Pre A1')
        # Gift claims require an active selected course and completed placement.
        Profile.objects.filter(user__in=(cls.user, cls.other)).update(
            preferred_language=cls.lang, placement_completed=True,
        )

    def passed_level(self, user=None):
        Assessment.objects.create(user=user or self.user, kind='level', level=self.level,
                                  score=90, passed=True)

    def test_cannot_claim_without_passing_official_level_test(self):
        with self.assertRaises(SeasonGiftUnavailable):
            claim_season_gift(self.user, self.level)
        self.assertEqual(SeasonGiftClaim.objects.count(), 0)
        self.assertEqual(CoinEvent.objects.count(), 0)

    def test_claim_once_is_transactional_and_updates_existing_wallet(self):
        self.passed_level()
        profile = Profile.objects.get(user=self.user)
        profile.xp = 20
        profile.coins = 10
        profile.save(update_fields=['xp', 'coins'])
        self.assertEqual(claim_season_gift(self.user, self.level), (True, 50, 100))
        self.assertEqual(claim_season_gift(self.user, self.level), (False, 50, 100))
        profile.refresh_from_db()
        self.assertEqual(profile.xp, 70)
        self.assertEqual(profile.coins, 110)
        self.assertEqual(SeasonGiftClaim.objects.filter(user=self.user).count(), 1)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='season').count(), 1)
        self.assertEqual(CoinEvent.objects.filter(user=self.user).count(), 1)

    def test_admin_configurable_amounts_and_disable_switch(self):
        self.passed_level()
        gift = SeasonGift.objects.create(level=self.level, bonus_xp=75, bonus_coins=260, enabled=False)
        with self.assertRaises(SeasonGiftUnavailable):
            claim_season_gift(self.user, self.level)
        gift.enabled = True
        gift.save(update_fields=['enabled'])
        self.assertEqual(claim_season_gift(self.user, self.level), (True, 75, 260))
        self.assertEqual(SeasonGiftClaim.objects.get().coins_awarded, 260)

    def test_user_cannot_claim_other_user_finished_season(self):
        self.passed_level(self.other)
        with self.assertRaises(SeasonGiftUnavailable):
            claim_season_gift(self.user, self.level)
        self.assertEqual(CoinEvent.objects.count(), 0)

    def test_unpublished_course_cannot_mint_rewards(self):
        self.passed_level()
        self.lang.is_published = False
        self.lang.save(update_fields=['is_published'])
        with self.assertRaises(SeasonGiftUnavailable):
            claim_season_gift(self.user, self.level)

    def test_claim_endpoint_is_post_only_and_requires_login(self):
        url = reverse('season_gift_claim', args=[self.level.pk])
        response = self.client.post(url)
        self.assertEqual(response.status_code, 302)
        self.client.force_login(self.user)
        response = self.client.get(url)
        self.assertEqual(response.status_code, 405)
        response = self.client.post(url)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(SeasonGiftClaim.objects.count(), 0)

    def test_play_hub_shows_reward_only_after_test_passed(self):
        profile = Profile.objects.get(user=self.user)
        profile.preferred_language = self.lang
        profile.placement_completed = True
        profile.save(update_fields=['preferred_language', 'placement_completed'])
        self.client.force_login(self.user)
        url = reverse('play_hub')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, reverse('season_gift_claim', args=[self.level.pk]))
        # Nothing is earned just by viewing the page.
        self.assertEqual(SeasonGiftClaim.objects.count(), 0)

    def test_passing_season_test_exposes_a_real_claim_action(self):
        profile = Profile.objects.get(user=self.user)
        profile.preferred_language = self.lang
        profile.placement_completed = True
        profile.save(update_fields=['preferred_language','placement_completed'])
        unit = Unit.objects.create(level=self.level, slug='unit-one', title='Unit one',
                                   summary='A0 lesson', order=1, published=True)
        Lesson.objects.create(unit=unit, slug='lesson-one', title='Lesson one',
                              skill='reading', content='Hello', published=True)
        Assessment.objects.create(user=self.user, kind='unit', unit=unit,
                                  score=90, passed=True)
        self.passed_level()
        self.client.force_login(self.user)
        response = self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, reverse('season_gift_claim', args=[self.level.pk]))
        self.assertContains(response, 'csrfmiddlewaretoken')
        self.assertEqual(SeasonGiftClaim.objects.count(), 0)


class AIOffSwitchTests(TestCase):
    def test_off_does_not_expose_tutor_credits_or_checkout(self):
        from .models import PlatformSettings
        user = get_user_model().objects.create_user(
            username='ai_off_student', password='A-super-long-local-password-2026'
        )
        self.client.force_login(user)
        cfg = PlatformSettings.load()
        cfg.ai_enabled = False
        cfg.ai_emergency_stop = True
        cfg.save(update_fields=['ai_enabled', 'ai_emergency_stop'])
        self.assertEqual(self.client.get(reverse('ai_tutor')).status_code, 404)
        self.assertEqual(self.client.get(reverse('ai_plans')).status_code, 404)
        self.assertEqual(self.client.post(reverse('ai_checkout')).status_code, 404)

"""V22 real Django integration regression tests; NOT run by an offline source scan.

Execute only in the isolated QA settings via TEST-ROZH-STAP9.ps1. Django's
TestCase creates a throwaway database; never point it at a real project DB.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Language, Level, Unit, Lesson, LessonProgress, XPEvent
from .course_models import CourseEnrollment
from .views import _learning_path_data


class StudentJourneyGuardV22Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        User = get_user_model()
        cls.user = User.objects.create_user(
            username='v22_journey_student', email='v22-student@example.invalid',
            password='V22-Only-Strong-Password!')
        cls.dutch = Language.objects.create(
            code='nl', name='Dutch', slug='v22-dutch', is_published=True)
        cls.english = Language.objects.create(
            code='en', name='English', slug='v22-english', is_published=True)
        for language, slug, title in (
            (cls.dutch, 'dutch', 'V22 Dutch first lesson'),
            (cls.english, 'english', 'V22 English first lesson'),
        ):
            level = Level.objects.create(language=language, code='A0', order=0)
            unit = Unit.objects.create(level=level, slug=slug, title=title,
                                       summary='V22 published test unit', order=1,
                                       published=True)
            Lesson.objects.create(unit=unit, slug='intro', title=title,
                                  skill='grammar', content='Test', order=1,
                                  published=True)
        profile = cls.user.learning_profile
        profile.preferred_language = cls.dutch
        profile.placement_completed = True
        profile.onboarding_required = False
        profile.onboarding_completed = True
        profile.save(update_fields=['preferred_language', 'placement_completed',
                                    'onboarding_required', 'onboarding_completed'])

    def setUp(self):
        self.client.force_login(self.user)

    def _fresh_route(self):
        # Resolve a new model instance so relation caches cannot hide an
        # unpublished course after its state changes inside this test.
        return _learning_path_data(get_user_model().objects.get(pk=self.user.pk))

    def _profile(self, **values):
        profile = self.user.learning_profile
        for field, value in values.items():
            setattr(profile, field, value)
        profile.save(update_fields=list(values))
        return profile

    def test_incomplete_onboarding_blocks_all_three_student_entry_points(self):
        # Test a partially migrated account: a start level exists, but its
        # durable setup draft has NOT been completed.
        self._profile(onboarding_required=True, onboarding_completed=False,
                      placement_completed=True)
        before = (XPEvent.objects.count(), LessonProgress.objects.count(),
                  CourseEnrollment.objects.count())
        for route in ('play_hub', 'learn_path', 'dashboard'):
            with self.subTest(route=route):
                response = self.client.get(reverse(route))
                self.assertRedirects(response, reverse('onboarding'),
                                     fetch_redirect_response=False)
        self.assertEqual(before, (XPEvent.objects.count(),
                                  LessonProgress.objects.count(),
                                  CourseEnrollment.objects.count()))

    def test_incomplete_placement_still_redirects_to_placement(self):
        self._profile(placement_completed=False, onboarding_required=False,
                      onboarding_completed=False)
        for route in ('play_hub', 'learn_path', 'dashboard'):
            with self.subTest(route=route):
                self.assertRedirects(self.client.get(reverse(route)),
                                     reverse('placement'),
                                     fetch_redirect_response=False)

    def test_existing_legacy_learner_is_not_forced_into_new_onboarding(self):
        # Deliberate V52 compatibility: the explicit required flag controls
        # whether a returning legacy learner must repeat onboarding.
        self._profile(onboarding_required=False, onboarding_completed=False,
                      placement_completed=True)
        for route in ('play_hub', 'learn_path', 'dashboard'):
            with self.subTest(route=route):
                self.assertEqual(self.client.get(reverse(route)).status_code, 200)

    def test_published_selected_course_remains_the_only_learning_path(self):
        path = self._fresh_route()
        self.assertEqual(path['language'], self.dutch)
        self.assertEqual(path['total_lessons'], 1)
        self.assertEqual(path['done_lessons'], 0)
        response = self.client.get(reverse('learn_path'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'V22 Dutch first lesson')
        self.assertNotContains(response, 'V22 English first lesson')

    def test_missing_course_does_not_silently_fall_back_to_english(self):
        self._profile(preferred_language=None)
        path = self._fresh_route()
        self.assertIsNone(path['language'])
        self.assertEqual((path['stages'], path['total_lessons'],
                          path['done_lessons'], path['progress_percent']),
                         ([], 0, 0, 0))
        response = self.client.get(reverse('learn_path'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, reverse('courses'))
        self.assertNotContains(response, 'V22 English first lesson')
        dashboard = self.client.get(reverse('dashboard'))
        self.assertEqual(dashboard.status_code, 200)
        self.assertIsNone(dashboard.context['route']['language'])
        self.assertContains(dashboard, reverse('courses'))

    def test_unpublished_selected_course_does_not_render_another_course(self):
        self.dutch.is_published = False
        self.dutch.save(update_fields=['is_published'])
        path = self._fresh_route()
        self.assertIsNone(path['language'])
        self.assertEqual(path['total_lessons'], 0)
        self.assertEqual(self.client.get(reverse('play_hub')).status_code, 200)
        response = self.client.get(reverse('learn_path'))
        self.assertContains(response, reverse('courses'))
        self.assertNotContains(response, 'V22 English first lesson')
        response = self.client.get(reverse('word'))
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.context['course_selected'])
        self.assertEqual(XPEvent.objects.count(), 0)

    def test_valid_selected_course_has_real_daily_course_state(self):
        response = self.client.get(reverse('word'))
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.context['course_selected'])
        self.assertEqual(XPEvent.objects.count(), 0)

    def test_unpublished_course_get_requests_do_not_change_progress(self):
        self.dutch.is_published = False
        self.dutch.save(update_fields=['is_published'])
        before = (XPEvent.objects.count(), LessonProgress.objects.count(),
                  CourseEnrollment.objects.count())
        for route in ('play_hub', 'learn_path', 'dashboard', 'word'):
            with self.subTest(route=route):
                self.assertEqual(self.client.get(reverse(route)).status_code, 200)
        self.assertEqual(before, (XPEvent.objects.count(),
                                  LessonProgress.objects.count(),
                                  CourseEnrollment.objects.count()))

    def test_anonymous_cannot_open_private_student_pages(self):
        self.client.logout()
        for route in ('play_hub', 'learn_path', 'dashboard'):
            with self.subTest(route=route):
                response = self.client.get(reverse(route))
                self.assertEqual(response.status_code, 302)
                self.assertTrue(response['Location'].startswith(reverse('login')))

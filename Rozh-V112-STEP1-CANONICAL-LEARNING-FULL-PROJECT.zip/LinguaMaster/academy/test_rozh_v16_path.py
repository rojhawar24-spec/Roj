"""Live Django tests: intentionally NOT executed in the offline release builder.
   After setting up an isolated local Django database:
   python manage.py test academy.test_rozh_v16_path
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Language, Level, Unit, Lesson, LessonProgress

class LearningPathV16LiveTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user=get_user_model().objects.create_user('v16_learner', 'v16@example.test', 'StrongTestPassword-2026!')
        cls.language=Language.objects.create(name='Dutch',code='nl',slug='v16-dutch',description='Dutch',is_published=True)
        level=Level.objects.create(language=cls.language,code='A0',order=0,description='Starting out')
        cls.unit=Unit.objects.create(level=level,slug='v16-greetings',title='Greetings and polite phrases',summary='Greetings',order=1,published=True)
        cls.lesson=Lesson.objects.create(unit=cls.unit,slug='v16-lesson1',title='Lesson 1',skill='grammar',content='Basic greeting',order=1,published=True)
        profile=cls.user.learning_profile
        profile.preferred_language=cls.language
        profile.placement_completed=True
        profile.ui_language='en'
        profile.save()

    def setUp(self): self.client.force_login(self.user)

    def test_switch_lands_on_canonical_learning_path(self):
        response=self.client.post(reverse('course_switch',args=['nl']),{'start':'A0'})
        self.assertRedirects(response, reverse('play_hub'),fetch_redirect_response=False)
    def test_live_lesson_count_and_server_link(self):
        r=self.client.get(reverse('play_hub'))
        self.assertEqual(r.status_code,200)
        self.assertContains(r,'1 / 1')
        self.assertContains(r,'Lesson 1')
        self.assertContains(r,'rozh-learning-path-v16.css')

    def test_private_page_does_not_change_progress(self):
        self.client.get(reverse('play_hub'))
        self.assertEqual(LessonProgress.objects.filter(user=self.user).count(),0)

    def test_locked_unit_is_not_linked(self):
        second=Unit.objects.create(level=self.unit.level,slug='v16-prereq',title='Next unit',summary='Next unit',order=2,published=True)
        Lesson.objects.create(unit=second,slug='v16-lesson2',title='Lesson 2',skill='reading',content='Next',order=1,published=True)
        second.prerequisites.add(self.unit)
        r=self.client.get(reverse('play_hub'))
        self.assertEqual(r.status_code,200)
        self.assertNotContains(r, reverse('journey_play',args=[second.pk]))

    def test_sorani_rtl(self):
        p=self.user.learning_profile;p.ui_language='ckb';p.save(update_fields=['ui_language'])
        r=self.client.get(reverse('play_hub'))
        self.assertContains(r,'lang="ckb"')
        self.assertContains(r,'dir="rtl"')

"""Display an authored solution only after an answer has been graded.
Never use this function in public question payloads. No AI or new grading rules.
"""


def solution_text(exercise):
    """Human-readable canonical solution, including complete matching pairs."""
    if getattr(exercise, 'kind', None) in ('word_matching', 'memory_match'):
        data = getattr(exercise, 'activity_data', None)
        pairs = data.get('pairs') if isinstance(data, dict) else None
        if not isinstance(pairs, list) or not pairs:
            return ''
        if any(not isinstance(pair, dict) or not isinstance(pair.get('left'), str)
               or not isinstance(pair.get('right'), str) for pair in pairs):
            return ''
        return '\n'.join(f"{pair['left']} — {pair['right']}" for pair in pairs)
    answer = getattr(exercise, 'answer', '')
    return answer if isinstance(answer, str) else ''


def graded_solution(exercise, correct):
    # An accepted alternative is correct: do not present the canonical answer
    # as a correction to an already accepted answer.
    return '' if correct else solution_text(exercise)

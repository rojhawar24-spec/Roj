"""Separate Rozh Manager role. A Manager is not a Django Admin account.

No role is assigned by default. Provision only from the operator's local
Django management command; never via sign-up, a web URL or a GET request.
"""
from functools import wraps
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ObjectDoesNotExist
from django.http import HttpResponse

MANAGER_GROUP = 'Rozh Managers'


def privileged_account_eligible(user, profile=None):
    """Re-check account ownership and safety on EVERY privileged request.

    Do not trust the status present when a Manager role or MFA session was
    originally granted. Suspension/review/email changes immediately revoke
    privileged access, without touching database records or session state.
    """
    if not getattr(user, 'is_authenticated', False) or not getattr(user, 'is_active', False):
        return False
    try:
        profile = profile if profile is not None else user.learning_profile
    except (ObjectDoesNotExist, AttributeError):
        return False
    return bool(profile and profile.email_verified_at is not None
                and not profile.legacy_review_required
                and profile.suspended_at is None
                and profile.totp_secret)



def has_privileged_assignments(user):
    """Treat any Django permission grant or Manager membership as privileged.

    A delegated Manager may only suspend ordinary learner accounts.  Staff
    membership alone is not the whole permission model: group and direct
    permission grants must not become an overlooked route for controlling
    another operator account.
    """
    return bool(
        user.is_staff or user.is_superuser
        or user.groups.filter(name=MANAGER_GROUP).exists()
        or user.user_permissions.exists()
        or user.groups.filter(permissions__isnull=False).exists()
    )


def is_delegated_manager(user):
    if not getattr(user, 'is_authenticated', False) or not user.is_active:
        return False
    # A delegated Manager MUST NOT have Django Admin or superuser rights.
    if user.is_staff or user.is_superuser:
        return False
    # No permissions may be inherited from OTHER groups or direct grants.
    # We refuse access rather than silently stripping legitimate assignments.
    if user.user_permissions.exists() or user.groups.exclude(name=MANAGER_GROUP).filter(permissions__isnull=False).exists():
        return False
    return (user.groups.filter(name=MANAGER_GROUP, permissions__isnull=True).exists()
            and not user.groups.filter(name=MANAGER_GROUP, permissions__isnull=False).exists())


def has_manager_role(user):
    return bool(getattr(user, 'is_authenticated', False) and user.is_active
                and (user.is_superuser or is_delegated_manager(user)))


def verified_manager_session(request):
    if not has_manager_role(request.user):
        return False
    if not privileged_account_eligible(request.user):
        return False
    # Session MFA must match the *same* authenticated user; a past verified
    # session cannot override revoked ownership, role or enrolled MFA.
    return request.session.get('mfa_verified_id') == request.user.pk


def manager_only(view):
    @wraps(view)
    @login_required
    def inner(request, *args, **kwargs):
        if not verified_manager_session(request):
            return HttpResponse('Manager access requires an authorized Manager role and verified MFA.', status=403)
        return view(request, *args, **kwargs)
    return inner

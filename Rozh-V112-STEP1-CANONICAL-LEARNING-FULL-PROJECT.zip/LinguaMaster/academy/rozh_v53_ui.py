"""Read-only learning-path presentation. No model writes, permissions or XP calculations.

Localized labels are authored for the starter curriculum shipped in this repository.
Editors' changed/unknown titles are intentionally not machine-translated: show the
original authored title rather than fabricate a meaning.
"""

LABELS = {
    'nl': dict(kicker='JOUW LEERROUTE', next='Volgende stap', continue_='Verder', here='Je bent hier',
        lesson='Les', lessons='lessen', unit='Onderdeel', completed='Voltooid', available='Beschikbaar',
        locked='Nog gesloten', review='Herhalen', quiz='Onderdeeltoets', route='Jouw leerpad',
        choose='Kies een leerta(a)l', done='Alle beschikbare stappen afgerond',
        plan='Volg je route, stap voor stap.', course='Cursusvoortgang', today='Vandaag',
        daily='Dagdoel', progress='Voortgang', outof='van', season='Seizoen',
        light='Wissel tussen licht en donker', xp='Ervaringspunten', hearts='Hartjes',
        streak='Leerreeks', gems='Munten', jump='Ga naar mijn volgende stap',
        theme='Verschillende werelden, één duidelijke route', all='Alle seizoenen',
        pick_season='Kies een seizoen', seasons_count='seizoenen', expand_hint='Open een seizoen om de lessen te bekijken.',
        status='Status', no_lessons='Er zijn nog geen gepubliceerde lessen.',
        skill_grammar='Grammatica', skill_reading='Lezen', skill_listening='Luisteren',
        skill_speaking='Spreken', skill_writing='Schrijven',
        nextlesson='Jouw volgende onderdeel', changes='Wijzig cursus',
        progress_note='Alleen voltooide, gepubliceerde lessen tellen mee.'),
    'en': dict(kicker='YOUR LEARNING JOURNEY', next='Up next', continue_='Continue', here='You are here',
        lesson='Lesson', lessons='lessons', unit='Unit', completed='Completed', available='Available',
        locked='Not unlocked', review='Review', quiz='Unit check', route='Your learning path',
        choose='Choose a language', done='All available steps completed',
        plan='One real lesson at a time.', course='Course progress', today='Today',
        daily='Daily goal', progress='Progress', outof='of', season='Season',
        light='Switch light and dark theme', xp='Experience points', hearts='Hearts',
        streak='Learning streak', gems='Coins', jump='Jump to my next step',
        theme='Different worlds, one clear route', all='All seasons',
        pick_season='Choose a season', seasons_count='seasons', expand_hint='Open a season to see its lessons.',
        status='Status', no_lessons='No published lessons are available yet.',
        skill_grammar='Grammar', skill_reading='Reading', skill_listening='Listening',
        skill_speaking='Speaking', skill_writing='Writing',
        nextlesson='Your next unit', changes='Change course',
        progress_note='Only completed, published lessons count.'),
    'ckb': dict(kicker='ڕێگای فێربوونی تۆ', next='هەنگاوی داهاتوو', continue_='بەردەوام بە', here='تۆ لێرەیت',
        lesson='وانە', lessons='وانە', unit='بەش', completed='تەواوبوو', available='بەردەستە',
        locked='هێشتا نەکراوەتەوە', review='دووبارەکردنەوە', quiz='تاقیکردنەوەی بەش', route='ڕێگای فێربوونت',
        choose='زمانێک هەڵبژێرە', done='هەموو هەنگاوە بەردەستەکان تەواوبوون',
        plan='هەر جارە، یەک وانەی ڕاستەقینە.', course='پێشکەوتنی کۆرس', today='ئەمڕۆ',
        daily='ئامانجی ڕۆژانە', progress='پێشکەوتن', outof='لە', season='وەرز',
        light='گۆڕینی ڕووناک و تاریک', xp='خاڵی ئەزموون', hearts='دڵەکان',
        streak='زنجیرەی فێربوون', gems='سکەکان', jump='بڕۆ بۆ هەنگاوی داهاتووم',
        theme='جیهانی جیاواز، ڕێگایەکی ڕوون', all='هەموو وەرزەکان',
        pick_season='وەرزێک هەڵبژێرە', seasons_count='وەرز',
        expand_hint='وەرزێک بکەرەوە بۆ بینینی وانەکانی.',
        status='دۆخ', no_lessons='هێشتا هیچ وانەیەکی بڵاوکراوە نییە.',
        skill_grammar='ڕێزمان', skill_reading='خوێندنەوە', skill_listening='گوێگرتن',
        skill_speaking='قسەکردن', skill_writing='نووسین',
        nextlesson='بەشی داهاتووت', changes='گۆڕینی کۆرس',
        progress_note='تەنها وانە بڵاوکراوە و تەواوکراوەکان هەژمار دەکرێن.'),
    'ar': dict(kicker='رحلتك التعليمية', next='خطوتك التالية', continue_='متابعة', here='أنت هنا',
        lesson='درس', lessons='دروس', unit='وحدة', completed='مكتمل', available='متاح',
        locked='غير مفتوح بعد', review='مراجعة', quiz='اختبار الوحدة', route='مسارك التعليمي',
        choose='اختر لغة للتعلم', done='أكملت كل الخطوات المتاحة',
        plan='درس حقيقي واحد في كل خطوة.', course='تقدم الدورة', today='اليوم',
        daily='الهدف اليومي', progress='التقدم', outof='من', season='موسم',
        light='تبديل المظهر الفاتح والداكن', xp='نقاط الخبرة', hearts='القلوب',
        streak='سلسلة التعلم', gems='العملات', jump='الانتقال إلى خطوتي التالية',
        theme='عوالم مختلفة، ومسار واحد واضح', all='كل المواسم',
        pick_season='اختر موسمًا', seasons_count='مواسم', expand_hint='افتح الموسم لعرض دروسه.',
        status='الحالة', no_lessons='لا تتوفر دروس منشورة بعد.',
        skill_grammar='القواعد', skill_reading='القراءة', skill_listening='الاستماع',
        skill_speaking='التحدث', skill_writing='الكتابة',
        nextlesson='وحدتك التالية', changes='تغيير الدورة',
        progress_note='تُحتسب الدروس المنشورة والمكتملة فقط.'),
}


# V70 accessible season browser labels; kept separate from older approved copy.
SEASON_BROWSER_COPY = {
 'nl': dict(previous='Vorig seizoen', following='Volgend seizoen', my_season='Mijn seizoen',
            locked_season='Dit seizoen is nog gesloten.',
            unlock_season='Voltooi alle levels in het vorige seizoen om dit seizoen te openen.',
            current_season='Huidig seizoen', all_done='Alle seizoenen voltooid'),
 'en': dict(previous='Previous season', following='Next season', my_season='My season',
            locked_season='This season is still locked.',
            unlock_season='Complete every level in the previous season to unlock this season.',
            current_season='Current season', all_done='All seasons completed'),
 'ckb': dict(previous='وەرزی پێشوو', following='وەرزی داهاتوو', my_season='وەرزی ئێستام',
             locked_season='ئەم وەرزە هێشتا قوفڵە.',
             unlock_season='هەموو ئاستەکانی وەرزی پێشوو تەواو بکە بۆ کردنەوەی ئەم وەرزە.',
             current_season='وەرزی ئێستا', all_done='هەموو وەرزەکان تەواوبوون'),
 'ar': dict(previous='الموسم السابق', following='الموسم التالي', my_season='موسمي الحالي',
            locked_season='هذا الموسم لا يزال مقفلًا.',
            unlock_season='أكمل كل مستويات الموسم السابق لفتح هذا الموسم.',
            current_season='الموسم الحالي', all_done='اكتملت جميع المواسم'),
}
for _locale, _copy in SEASON_BROWSER_COPY.items():
    LABELS[_locale].update(_copy)


# Index by exact original seeded unit title (never override edited user content).
# Translations describe lesson topics, not target-language example sentences.
TITLES = {
'Greetings and polite phrases':('Begroetingen en beleefde zinnen','سڵاوکردن و دەستەواژەی ڕێزدارانە','التحيات والعبارات المهذبة'),
'Definite and indefinite articles':('Bepaalde en onbepaalde lidwoorden','ئامرازە دیاریکەرەکان و نادیارەکان','أدوات التعريف والتنكير'),
'Subject pronouns':('Persoonlijke voornaamwoorden','جێناوەکانی بکەر','ضمائر الفاعل'),
'Present tense of regular verbs':('Tegenwoordige tijd van regelmatige werkwoorden','کاتی ئێستای کردارە ڕێکوپێکەکان','المضارع للأفعال المنتظمة'),
'Main-clause word order':('Woordvolgorde in hoofdzinnen','ڕیزبەندی وشە لە ڕستەی سەرەکی','ترتيب الكلمات في الجملة الرئيسية'),
'Negation with niet and geen':('Ontkenning met niet en geen','نەرێکردن بە niet و geen','النفي باستخدام niet و geen'),
'Perfect tense with hebben and zijn':('Voltooide tijd met hebben en zijn','کاتی تەواوبوو بە hebben و zijn','زمن الماضي المركب مع hebben و zijn'),
'Modal verbs':('Modale werkwoorden','کردارە یاریدەدەرەکان','الأفعال الناقصة'),
'Comparatives and superlatives':('Vergrotende en overtreffende trap','پلەی بەراورد و پلەی باڵا','صيغ المقارنة والتفضيل'),
'Subordinate clauses with omdat and dat':('Bijzinnen met omdat en dat','ڕستەی لاوەکی بە omdat و dat','الجمل الفرعية باستخدام omdat و dat'),
'Relative clauses with die and dat':('Betrekkelijke bijzinnen met die en dat','ڕستەی پەیوەندی بە die و dat','جمل الوصل باستخدام die و dat'),
'Narrating with the imperfect':('Vertellen in de onvoltooid verleden tijd','گێڕانەوە بە کاتی ڕابردووی سادە','السرد بزمن الماضي البسيط'),
'The passive voice':('De lijdende vorm','شێوازی نادیاری کردار','صيغة المبني للمجهول'),
'Uses of er':('Het gebruik van er','بەکارهێنانی er','استخدامات er'),
'Complex linking and contrast':('Complexe verbanden en tegenstellingen','پەیوەندی و دژایەتیی ئاڵۆز','الروابط المعقدة والتباين'),
'Nominalisation and academic register':('Nominalisatie en academische taal','ناوکردن و شێوازی ئەکادیمی','التحويل إلى أسماء والأسلوب الأكاديمي'),
'Epistemic nuance and cautious claims':('Nuance en voorzichtige uitspraken','وردەکاری و دەربڕینی بەئاگا','دقة التعبير والتحفظ في الادعاءات'),
'Information structure and stylistic inversion':('Informatiestructuur en stilistische inversie','ڕێکخستنی زانیاری و گۆڕینی شێوازی ڕستە','بنية المعلومات والتقديم الأسلوبي'),
'Hello — introduce yourself':('Hallo — stel jezelf voor','سڵاو — خۆت بناسێنە','مرحباً — عرّف بنفسك'),
'Everyday things — a, an and plurals':('Alledaagse dingen — a, an en meervoud','شتە ڕۆژانەکان — a و an و کۆ','أشياء يومية — a و an والجمع'),
'Daily routines — the simple present':('Dagelijkse gewoonten — de simple present','ڕەفتارە ڕۆژانەکان — کاتی ئێستا','الروتين اليومي — المضارع البسيط'),
'Hallo! Introduce yourself with sein':('Hallo! Jezelf voorstellen met sein','سڵاو! ناساندنی خۆت بە sein','مرحباً! عرّف بنفسك باستخدام sein'),
'Der, die, das: learn nouns with their articles':('Der, die, das: zelfstandige naamwoorden leren','Der, die, das: فێربوونی ناو و ئامرازەکانی','Der, die, das: تعلّم الأسماء مع أدواتها'),
'Heute lerne ich: regular verbs and sentence order':('Heute lerne ich: werkwoorden en woordvolgorde','Heute lerne ich: کردار و ڕیزبەندی ڕستە','Heute lerne ich: الأفعال وترتيب الجملة'),
'Bonjour: introduce yourself with être':('Bonjour: jezelf voorstellen met être','Bonjour: ناساندنی خۆت بە être','Bonjour: عرّف بنفسك باستخدام être'),
'Un livre, une table: articles and objects':('Un livre, une table: lidwoorden en voorwerpen','Un livre, une table: ئامراز و شتەکان','Un livre, une table: الأدوات والأشياء'),
'Je parle: describe an everyday routine':('Je parle: je dagelijkse routine beschrijven','Je parle: وەسفکردنی ڕۆژانەت','Je parle: وصف روتينك اليومي'),
}


def unit_title(title, language):
    """Translate only known source titles. Do not invent text for custom unit titles."""
    values = TITLES.get(title)
    if values and language in ('nl', 'ckb', 'ar'):
        return values[('nl', 'ckb', 'ar').index(language)]
    return title


def build_path_nodes(items, language):
    """Each node corresponds to an existing published Lesson, plus optional unit check.

    All access URLs and completion flags come exclusively from _learning_path_data.
    This function is presentation-only: it never guesses or unlocks a lesson.
    """
    result = []
    sequence = 0
    for unit_index, item in enumerate(items, 1):
        lesson_nodes = item.get('lesson_nodes') or []
        for lesson_index, original in enumerate(lesson_nodes, 1):
            lesson = original['lesson']
            has_access = bool(original.get('available')) and item['state'] != 'locked'
            finished = bool(original.get('done'))
            is_current = bool(item.get('is_current') and original.get('next') and item['state'] == 'active')
            if finished and has_access:
                state = 'done'
            elif original.get('pending') and item['state'] != 'locked':
                state = 'pending_content'
            elif not has_access:
                state = 'locked'
            elif is_current:
                state = 'current'
            else:
                state = 'available'
            sequence += 1
            result.append(dict(unit=item['unit'], lesson=lesson, sequence=sequence, unit_index=unit_index,
                first=lesson_index == 1, unit_title=unit_title(item['unit'].title, language),
                unit_done=item['done'], unit_total=item['total'], skill=LABELS[language].get(
                    'skill_'+lesson.skill, LABELS[language]['lesson']),
                state=state, current=is_current, href=original['url'] if has_access else None,
                side=('start','end','center','start','end','center')[(sequence-1) % 6],
                kind='lesson'))
        if item['state'] in ('test', 'done'):
            sequence += 1
            is_current = bool(item.get('is_current') and item['state'] == 'test')
            result.append(dict(unit=item['unit'], lesson=None, sequence=sequence, unit_index=unit_index,
                first=not lesson_nodes, unit_title=unit_title(item['unit'].title, language),
                unit_done=item['done'], unit_total=item['total'], skill=LABELS[language]['quiz'],
                state='done' if item['state']=='done' else 'current' if is_current else 'available',
                current=is_current, href=item.get('game_url') if item['state'] == 'test' else None,
                side=('start','end','center','start','end','center')[(sequence-1) % 6],
                kind='test'))
    return result


COURSE_NAMES = {
    'nl': {'nl':'Nederlands','en':'Engels','fr':'Frans','de':'Duits'},
    'en': {'nl':'Dutch','en':'English','fr':'French','de':'German'},
    'ckb': {'nl':'هۆڵەندی','en':'ئینگلیزی','fr':'فەڕەنسی','de':'ئەڵمانی'},
    'ar': {'nl':'الهولندية','en':'الإنجليزية','fr':'الفرنسية','de':'الألمانية'},
}

def course_name(language, locale):
    if language is None:
        return LABELS[locale]['choose']
    return COURSE_NAMES[locale].get(language.code, language.name)


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'rozh_v53_ui', ['COURSE_NAMES', 'LABELS', 'SEASON_BROWSER_COPY'])

COURSE_NAMES['fr']={'nl':'néerlandais','en':'anglais','fr':'français','de':'allemand'}
COURSE_NAMES['uk']={'nl':'нідерландська','en':'англійська','fr':'французька','de':'німецька'}
COURSE_NAMES['kmr']={'nl':'هۆڵەندی','en':'ئینگلیزی','fr':'فەڕەنسی','de':'ئەڵمانی'}


SEASON_BROWSER_COPY['fr'].update(dict(previous='Saison précédente',following='Saison suivante',my_season='Ma saison',locked_season='Cette saison est verrouillée.',unlock_season='Terminez tous les niveaux de la saison précédente pour la débloquer.',current_season='Saison actuelle',all_done='Toutes les saisons terminées'))
SEASON_BROWSER_COPY['uk'].update(dict(previous='Попередній сезон',following='Наступний сезон',my_season='Мій сезон',locked_season='Цей сезон ще заблоковано.',unlock_season='Заверши всі рівні попереднього сезону, щоб відкрити цей.',current_season='Поточний сезон',all_done='Усі сезони завершено'))
SEASON_BROWSER_COPY['kmr'].update(dict(previous='وەرزا بوری',following='وەرزا داهاتی',my_season='وەرزا من',locked_season='ئەڤ وەرز هێشتا قەدەغەیە.',unlock_season='هەمی ئاستێن وەرزا بوری تەواو بکە دا ئەڤ وەرز ڤەبیت.',current_season='وەرزا نوکە',all_done='هەمی وەرز تەواو بوون'))
COURSE_NAMES['ku']={'nl':'Holandî','en':'Îngilîzî','fr':'Fransî','de':'Almanî'}
SEASON_BROWSER_COPY['ku'].update(dict(previous='Demsala berê',following='Demsala din',my_season='Demsala min',locked_season='Ev demsal hêj girtî ye.',unlock_season='Hemû astên demsala berê biqedîne da ku ev demsal vebe.',current_season='Demsala niha',all_done='Hemû demsal temam bûn'))
for _v74_loc in ('fr','uk','kmr','ku'):
    LABELS[_v74_loc].update(SEASON_BROWSER_COPY[_v74_loc])

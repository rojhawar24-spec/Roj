"""Real Django TestCase: STEP7 manager presentation and existing security contracts.

Run ONLY via `manage.py test` with isolated test DB; never against user data.
Not run in the artifact build environment (Django 6.1.3 unavailable).
"""
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .models import Profile, PlatformSettings
from .manager_roles_v48 import MANAGER_GROUP


class SolarAtlasStep7ManagerTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        User = get_user_model()
        cls.owner = User.objects.create_superuser(
            username='sa7-owner', email='sa7-owner@example.invalid',
            password='Sa7-Owner-TEST-Passphrase-Only!')
        cls.manager = User.objects.create_user(
            username='sa7-manager', email='sa7-manager@example.invalid',
            password='Sa7-Manager-TEST-Passphrase-Only!')
        cls.learner = User.objects.create_user(
            username='sa7-learner', email='sa7-learner@example.invalid',
            password='Sa7-Learner-TEST-Passphrase-Only!')
        grp, _ = Group.objects.get_or_create(name=MANAGER_GROUP)
        cls.manager.groups.add(grp)
        for account, locale in ((cls.owner,'nl'),(cls.manager,'ckb')):
            profile, _ = Profile.objects.get_or_create(user=account)
            profile.ui_language = locale
            profile.totp_secret = 'JBSWY3DPEHPK3PXP'
            profile.email_verified_at = timezone.now()
            profile.legacy_review_required = False
            profile.suspended_at = None
            profile.save()

    def login_verified(self, user):
        self.client.force_login(user)
        session = self.client.session
        session['mfa_verified_id'] = user.pk
        session.save()

    def test_guest_cannot_access_manager(self):
        self.assertEqual(self.client.get(reverse('manager')).status_code,302)

    def test_normal_learner_cannot_access_manager_even_with_session_flag(self):
        self.login_verified(self.learner)
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)

    def test_owner_requires_verified_mfa_session(self):
        self.client.force_login(self.owner)
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)

    def test_verified_owner_gets_solar_atlas_and_its_real_form(self):
        self.login_verified(self.owner)
        resp=self.client.get(reverse('manager'))
        self.assertEqual(resp.status_code,200)
        self.assertContains(resp,'sa7-manager')
        self.assertContains(resp,'sa7-hero')
        self.assertContains(resp,'sa7-metrics')
        self.assertContains(resp,'solar-atlas-step7-manager.css')
        self.assertContains(resp,'name="csrfmiddlewaretoken"')
        self.assertContains(resp,'name="ai_monthly_budget_eur"')
        self.assertContains(resp,'lang="nl" dir="ltr"')

    def test_delegated_manager_gets_sorani_and_only_delegated_ai_form(self):
        self.login_verified(self.manager)
        resp=self.client.get(reverse('manager'))
        self.assertEqual(resp.status_code,200)
        self.assertContains(resp,'lang="ckb" dir="rtl"')
        self.assertContains(resp,'بەڕێوەبردن')
        self.assertContains(resp,'name="ai_enabled"')
        self.assertContains(resp,'name="ai_emergency_stop"')
        self.assertNotContains(resp,'name="ai_monthly_budget_eur"')
        self.assertNotContains(resp,'name="public_registration_enabled"')

    def test_manager_cannot_change_owner_budget_via_post(self):
        self.login_verified(self.manager)
        config=PlatformSettings.load()
        old=config.ai_monthly_budget_eur
        resp=self.client.post(reverse('manager'),{
            'ai_enabled':'', 'ai_emergency_stop':'on',
            'ai_monthly_budget_eur':'999999999',
            'public_registration_enabled':'on'})
        self.assertEqual(resp.status_code,302)
        config.refresh_from_db()
        self.assertEqual(config.ai_monthly_budget_eur,old)

    def test_manager_navigation_real_authorized_routes(self):
        self.login_verified(self.manager)
        for route in ('manager_users','manager_audit'):
            resp=self.client.get(reverse(route))
            self.assertEqual(resp.status_code,200)
            self.assertContains(resp,'solar-atlas-step7-manager.css')
        resp=self.client.get(reverse('manager_content_list',args=['season']))
        self.assertEqual(resp.status_code,200)

    def test_manager_does_not_change_database_on_get(self):
        self.login_verified(self.manager)
        before = PlatformSettings.load().ai_monthly_budget_eur
        response = self.client.get(reverse('manager'))
        self.assertEqual(response.status_code,200)
        after=PlatformSettings.load().ai_monthly_budget_eur
        self.assertEqual(before, after)

    def test_owner_access_rechecks_email_proof(self):
        self.owner.learning_profile.email_verified_at=None
        self.owner.learning_profile.save(update_fields=['email_verified_at'])
        self.login_verified(self.owner)
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)

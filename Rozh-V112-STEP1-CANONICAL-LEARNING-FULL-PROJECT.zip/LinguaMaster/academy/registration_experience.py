"""Localized, non-enumerating registration completion screen."""
COPY = {'nl': {'eyebrow': 'OPTIONEEL',
        'title': 'E-mailadres bevestigen',
        'description': 'Je account werkt zonder bevestigingsmail. Wil je wachtwoordherstel via e-mail '
                       'gebruiken, bevestig dan je adres via de onderstaande link.',
        'step1': 'Vraag een bevestigingslink aan.',
        'step2': 'Open de link uit je e-mail en klik op bevestigen.',
        'step3': 'Je lessen en voortgang blijven behouden.',
        'resend': 'Geen link ontvangen? Vraag opnieuw aan',
        'signin': 'Terug naar inloggen',
        'local_title': 'Alleen bij lokaal testen',
        'local_note': 'Bij de standaard lokale ontwikkeling wordt de verificatiemail veilig opgeslagen in de '
                      'map .private-email-outbox (niet in het PowerShell-log), niet in je inbox. Voor echte '
                      'e-mails moet SMTP worden ingesteld.',
        'security': 'E-mailverificatie is niet nodig om te leren, maar wel voor veilig accountherstel.'},
 'en': {'eyebrow': 'OPTIONAL',
        'title': 'Verify your email',
        'description': 'You can sign in and learn without email verification. Verify only if you want secure '
                       'password recovery by email.',
        'step1': 'Request an email verification link.',
        'step2': 'Open the link and choose Confirm.',
        'step3': 'Your lessons and progress remain saved.',
        'resend': 'No link? Request another',
        'signin': 'Back to sign in',
        'local_title': 'For local development only',
        'local_note': 'With the default local setup, the verification email is stored in the private '
                      '.private-email-outbox folder (not printed to the terminal), not delivered to your '
                      'inbox. Configure SMTP for real email delivery.',
        'security': 'Verification is optional for learning, but required for password recovery.'},
 'ckb': {'eyebrow': 'ئیختیاری',
         'title': 'پشتڕاستکردنەوەی ئیمەیڵ',
         'description': 'بەبێ پشتڕاستکردنەوەی ئیمەیڵ دەتوانیت بچیتە ژوورەوە و فێربیت. بۆ گەڕاندنەوەی وشەی '
                        'نهێنی دەتوانیت ئیمەیڵەکەت پشتڕاست بکەیتەوە.',
         'step1': 'داوای لینکی پشتڕاستکردنەوە بکە.',
         'step2': 'لینکەکە بکەرەوە و پشتڕاستی بکەرەوە.',
         'step3': 'وانەکان و پێشکەوتنت دەپارێزرێن.',
         'resend': 'لینکت پێنەگەیشت؟ دووبارە داوای بکە',
         'signin': 'گەڕانەوە بۆ چوونەژوورەوە',
         'local_title': 'تەنها بۆ تاقیکردنەوەی ناوخۆیی',
         'local_note': 'لە ڕێکخستنی بنەڕەتی ناوخۆییدا ئیمەیڵەکە لە فۆڵدەری تایبەتی .private-email-outbox '
                       'پاشەکەوت دەکرێت، نەک لە Inbox. بۆ ئیمەیڵی ڕاستەقینە SMTP ڕێکبخە.',
         'security': 'بۆ فێربوون پێویست نییە، بەڵام بۆ گەڕاندنەوەی وشەی نهێنی پێویستە.'},
 'ar': {'eyebrow': 'اختياري',
        'title': 'تأكيد البريد الإلكتروني',
        'description': 'يمكنك تسجيل الدخول والتعلم دون تأكيد البريد. أكّده لاحقًا فقط إذا أردت استعادة كلمة '
                       'المرور عبر البريد.',
        'step1': 'اطلب رابط تأكيد البريد.',
        'step2': 'افتح الرابط واختر تأكيد.',
        'step3': 'تبقى دروسك وتقدمك محفوظين.',
        'resend': 'لم يصلك الرابط؟ أعد طلبه',
        'signin': 'العودة لتسجيل الدخول',
        'local_title': 'للتطوير المحلي فقط',
        'local_note': 'في الإعداد المحلي الافتراضي تُحفظ رسالة التأكيد في مجلد .private-email-outbox الخاص '
                      'ولا تُطبع في PowerShell، وليس في صندوق بريدك. اضبط SMTP لإرسال البريد الفعلي.',
        'security': 'التأكيد اختياري للتعلم، لكنه مطلوب لاستعادة كلمة المرور.'}}


def confirmation_copy(locale, required):
    """Non-enumerating copy; required-mode text never assumes an account exists."""
    value = COPY.get(locale, COPY['en']).copy()
    if required:
        value['eyebrow'] = {'nl':'BEVESTIGING', 'en':'VERIFICATION',
                            'ckb':'پشتڕاستکردنەوە', 'ar':'التحقق'}.get(locale, 'VERIFICATION')
        value['security'] = {
            'nl':'Nieuwe accounts worden pas actief na bevestiging van het e-mailadres.',
            'en':'New accounts become active only after email verification.',
            'ckb':'هەژمارە نوێیەکان تەنها دوای پشتڕاستکردنەوەی ئیمەیڵ چالاک دەبن.',
            'ar':'لا تُفعّل الحسابات الجديدة إلا بعد تأكيد البريد الإلكتروني.',
        }.get(locale,'New accounts become active only after email verification.')
    return value


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'registration_experience', ['COPY'])

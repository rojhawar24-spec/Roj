"""Django integration regressions for the mixed section/level game.

Run in the user's Python 3.13 Windows environment:
    python manage.py test academy.test_journey_v11 --verbosity 2
Do not report these as passed until Django has actually run them.
"""
from unittest.mock import patch
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .hearts import snapshot
from .heart_models import HeartBalance, HeartEvent
from .journey_v11 import _challenges, _first_sentence, _fingerprint, _shuffled, LOCALES
from .models import Assessment, Exercise, Language, Lesson, LessonProgress, Level, Unit, Vocabulary, XPEvent

User = get_user_model()


class JourneyUnitGameTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user=User.objects.create_user(username='mixed-student', email='mixed@example.org',password='StrongPassword!2026')
        cls.other=User.objects.create_user(username='mixed-other',email='other@example.org',password='StrongPassword!2026')
        cls.language=Language.objects.create(name='Dutch',code='nl',slug='dutch-journey',description='Real Dutch study',is_published=True)
        cls.level=Level.objects.create(language=cls.language,code='A0',order=0,description='Start')
        cls.unit=Unit.objects.create(level=cls.level,slug='greetings-v11',title='Groeten',summary='Greet someone.',order=1,published=True)
        cls.lessons={}
        for number,skill in enumerate(('grammar','reading','listening','speaking','writing'),1):
            cls.lessons[skill]=Lesson.objects.create(unit=cls.unit,slug=skill,title=skill.title(),skill=skill,
                audio_text={'grammar':'Ik zeg hallo.','listening':'Hallo ik ben Noor.','speaking':'Hallo, ik ben Noor.'}.get(skill,''),
                content='Practise Dutch now.',order=number,published=skill not in ('speaking','writing'))
        cls.exercises=[]
        for skill,prompt,options,answer in (
            ('grammar','A greeting?',['Hallo','Nee'],'Hallo'),
            ('reading','Thank you?',['Bedankt','Nee'],'Bedankt'),
            ('listening','What did you hear?',['Hallo','Tot ziens'],'Hallo'),
        ):
            cls.exercises.append(Exercise.objects.create(lesson=cls.lessons[skill],kind='mcq',prompt=prompt,
                          options=options,answer=answer,explanation='Original classroom feedback.'))
        for word,emoji in [('hallo','👋'),('appel','🍎'),('boek','📗'),('fiets','🚲')]:
            Vocabulary.objects.create(level=cls.level,word=word,translation=word,emoji=emoji,published=True)
        profile=cls.user.learning_profile
        profile.placement_completed=True
        profile.onboarding_completed=True
        profile.preferred_language=cls.language
        profile.ui_language='nl'
        profile.save()
        other=cls.other.learning_profile
        other.placement_completed=True
        other.preferred_language=cls.language
        other.save()

    def setUp(self):
        cache.clear()
        approval = patch('academy.audio_v78.approved_audio_url',return_value='/static/test-only-approved.wav')
        approval.start(); self.addCleanup(approval.stop)
        self.client.force_login(self.user)
        self.url=reverse('journey_play',args=[self.unit.pk])
        self.endpoint=reverse('journey_answer',args=[self.unit.pk])

    def get_state(self):
        return self.client.session[f'journey_v11_{self.unit.pk}']

    def items(self):
        return _challenges(self.unit,self.get_state()['token'])

    def submit(self,item,answer):
        return self.client.post(self.endpoint,{'round_token':self.get_state()['token'],
             'challenge_id':item['id'],'answer':answer},HTTP_X_REQUESTED_WITH='XMLHttpRequest')

    def test_level_path_opens_mixed_player_not_separate_grammar_lesson(self):
        path=self.client.get(reverse('play_hub'))
        self.assertEqual(path.status_code,200)
        self.assertContains(path, self.url)
        self.assertContains(path,'Level 1')
        screen=self.client.get(self.url)
        self.assertEqual(screen.status_code,200)
        self.assertContains(screen,'journey-v11.js')
        self.assertContains(screen,'round_token')
        self.assertEqual(screen.context['position'],1)

    def test_mixed_round_only_uses_published_authored_fixed_choices(self):
        self.assertEqual(self.client.get(self.url).status_code,200)
        items=self.items()
        self.assertEqual({q['type'] for q in items},{'mcq','listening-choice'})
        self.assertEqual(len(items),3)
        self.assertEqual(len({q['id'] for q in items}),3)
        self.assertTrue(all(q['graded'] and q['exercise'] for q in items))

    def test_legacy_self_review_must_not_be_silently_skipped(self):
        Lesson.objects.filter(pk=self.lessons['speaking'].pk).update(published=True)
        self.assertEqual(self.client.get(self.url).status_code,409)
        self.assertEqual(self.client.post(self.endpoint,{}).status_code,409)
        self.assertFalse(LessonProgress.objects.filter(user=self.user).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_round_resume_does_not_reset_after_refresh(self):
        self.client.get(self.url)
        first=self.items()[0]
        self.assertEqual(self.submit(first,first['answer']).status_code,200)
        state=self.get_state()
        self.assertEqual(state['position'],1)
        self.client.get(self.url)
        self.assertEqual(self.get_state()['token'],state['token'])
        self.assertEqual(self.get_state()['position'],1)

    def test_replay_and_forged_tokens_cannot_gain_xp_or_debit_hearts(self):
        self.client.get(self.url)
        first=self.items()[0]
        old=snapshot(self.user)['remaining']
        forged=self.client.post(self.endpoint,{'round_token':'0'*32,'challenge_id':first['id'],'answer':first['answer']})
        self.assertEqual(forged.status_code,409)
        self.assertEqual(snapshot(self.user)['remaining'],old)
        self.assertEqual(self.submit(first,first['answer']).status_code,200)
        self.assertEqual(self.submit(first,first['answer']).status_code,409)
        self.assertEqual(XPEvent.objects.count(),0)
        self.assertEqual(HeartEvent.objects.count(),0)

    def test_bad_mcq_answer_is_rejected_before_any_debit(self):
        self.client.get(self.url)
        first=self.items()[0]
        self.assertEqual(self.submit(first,'a fake unlisted choice').status_code,400)
        self.assertEqual(snapshot(self.user)['remaining'],5)
        self.assertEqual(self.get_state()['position'],0)

    def test_incorrect_valid_choice_spends_one_heart_once(self):
        self.client.get(self.url)
        first=self.items()[0]
        wrong=next(option for option in first['options'] if option != first['answer'])
        result=self.submit(first,wrong)
        self.assertEqual(result.status_code,200)
        self.assertFalse(result.json()['correct'])
        self.assertEqual(snapshot(self.user)['remaining'],4)
        self.assertEqual(self.submit(first,wrong).status_code,409)
        self.assertEqual(snapshot(self.user)['remaining'],4)
        self.assertEqual(HeartEvent.objects.filter(user=self.user,kind='answer').count(),1)

    def test_no_hearts_blocks_even_correct_graded_submission(self):
        HeartBalance.objects.update_or_create(user=self.user,defaults={'remaining':0,'regenerated_at':timezone.now()})
        self.client.get(self.url)
        first=self.items()[0]
        self.assertEqual(self.submit(first,first['answer']).status_code,402)
        self.assertEqual(LessonProgress.objects.count(),0)
        self.assertEqual(XPEvent.objects.count(),0)

    def test_complete_mixed_round_gives_xp_only_for_authored_graded_lessons(self):
        self.client.get(self.url)
        items=self.items()
        last=None
        for item in items:
            last=self.submit(item,item['answer'])
            self.assertEqual(last.status_code,200, item['id'])
            self.assertTrue(last.json()['correct'])
        self.assertTrue(last.json()['finished'])
        self.assertTrue(last.json()['passed'])
        self.assertEqual(last.json()['score'],100)
        self.assertEqual(last.json()['xp_awarded'],60)
        self.assertEqual(LessonProgress.objects.filter(user=self.user,lesson__unit=self.unit).count(),3)
        self.assertEqual(XPEvent.objects.filter(user=self.user).count(),3)
        self.assertEqual(self.client.get(self.url).context['state']['passed'],True)
        self.client.get(self.url+'?restart=1')
        for item in self.items():
            self.assertEqual(self.submit(item,item['answer']).status_code,200)
        self.assertEqual(XPEvent.objects.filter(user=self.user).count(),3)
        self.user.learning_profile.refresh_from_db()
        self.assertEqual(self.user.learning_profile.xp,60)

    def test_bonus_exercises_cannot_mask_wrong_authored_lesson(self):
        self.client.get(self.url)
        items=self.items()
        authored=next(q for q in items if q.get('exercise') is not None)
        final=None
        for q in items:
            answer = (next(option for option in q['options'] if option != q['answer'])
                      if q['id']==authored['id'] else q['answer'])
            final=self.submit(q,answer)
            self.assertEqual(final.status_code,200,q['id'])
        self.assertTrue(final.json()['finished'])
        self.assertFalse(final.json()['passed'])
        self.assertEqual(final.json()['xp_awarded'],0)
        self.assertEqual(LessonProgress.objects.filter(user=self.user).count(),0)
        self.assertEqual(XPEvent.objects.count(),0)

    def test_change_answer_invalidates_stale_game_without_heart_debit(self):
        self.client.get(self.url)
        first=self.items()[0]
        exercise=first['exercise']
        exercise.answer='Something else'
        exercise.save(update_fields=['answer'])
        response=self.submit(first,first['answer'])
        self.assertEqual(response.status_code,409)
        self.assertEqual(snapshot(self.user)['remaining'],5)
        self.assertEqual(XPEvent.objects.count(),0)

    def test_unpublished_unit_or_lesson_can_no_longer_be_played(self):
        self.client.get(self.url)
        self.unit.published=False
        self.unit.save(update_fields=['published'])
        self.assertEqual(self.client.get(self.url).status_code,404)
        self.assertEqual(self.client.post(self.endpoint,{}).status_code,404)

    def test_other_user_does_not_reuse_first_users_round(self):
        self.client.get(self.url)
        first=self.items()[0]
        token=self.get_state()['token']
        self.client.force_login(self.other)
        response=self.client.post(self.endpoint,{'round_token':token,'challenge_id':first['id'],
                                                    'answer':first['answer']})
        self.assertEqual(response.status_code,409)
        self.assertFalse(XPEvent.objects.filter(user=self.other).exists())

    def test_other_course_requires_course_selection(self):
        other_lang=Language.objects.create(name='French',code='fr',slug='french-v11',description='French',is_published=True)
        other_level=Level.objects.create(language=other_lang,code='A0',description='French A0')
        other_unit=Unit.objects.create(level=other_level,slug='start',title='Hello',summary='Hello',published=True)
        self.assertEqual(self.client.get(reverse('journey_play',args=[other_unit.pk])).status_code,403)

    def test_prerequisite_unit_remains_locked_until_assessment(self):
        next_unit=Unit.objects.create(level=self.level,slug='next-level',title='Next',summary='Next',order=2,published=True)
        next_unit.prerequisites.add(self.unit)
        self.assertEqual(self.client.get(reverse('journey_play',args=[next_unit.pk])).status_code,403)
        Assessment.objects.create(user=self.user,kind='unit',unit=self.unit,score=100,passed=True)
        self.assertEqual(self.client.get(reverse('journey_play',args=[next_unit.pk])).status_code,409)  # No authored content.

    def test_public_user_must_login(self):
        self.client.logout()
        self.assertEqual(self.client.get(self.url).status_code,302)
        self.assertEqual(self.client.post(self.endpoint,{}).status_code,302)


class JourneyPureFormattingTests(TestCase):
    def test_all_ui_translations_have_same_keys(self):
        base=set(LOCALES['en'])
        self.assertTrue(base)
        for locale in ('nl','ckb','ar'):
            self.assertEqual(set(LOCALES[locale]),base)
            self.assertTrue(all(LOCALES[locale].values()))

    def test_audio_sentence_and_shuffle_are_bounded_and_stable(self):
        self.assertEqual(_first_sentence('Hallo ik ben Noor. Morgen ben ik thuis.'),'Hallo ik ben Noor.')
        self.assertIsNone(_first_sentence('Hi.'))
        self.assertEqual(_shuffled(['one','two','three'],'abc'),_shuffled(['one','two','three'],'abc'))
        self.assertEqual(len(_fingerprint([])),64)

"""Bind browser authentication to account-state revisions.

The existing Profile.email_verification_version is incremented on manager
suspend, unblock and legacy-review approval.  Reuse it for invalidating old
browser sessions, including those never used during the suspension window.

Only a successful Django user_logged_in signal creates a binding.  Missing
bindings are intentionally rejected when rolling this change out.  This is
not a substitute for PostgreSQL/Redis and full HTTP QA.
"""

SESSION_STATE_VERSION_KEY = 'rozh_auth_state_version'


def current_state_version(profile):
    value = getattr(profile, 'email_verification_version', None)
    return value if type(value) is int and value >= 0 else None


def session_matches_account(session, profile):
    current = current_state_version(profile)
    value = session.get(SESSION_STATE_VERSION_KEY)
    return current is not None and type(value) is int and value == current

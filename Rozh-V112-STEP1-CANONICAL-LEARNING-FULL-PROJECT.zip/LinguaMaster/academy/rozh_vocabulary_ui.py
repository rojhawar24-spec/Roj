"""Human-authored, UI-only vocabulary labels for all four Rozh interface languages.

Content words, sample translations and user-authored notes are never machine
translated here. No queries, database writes or UI-language side effects.
"""
VOCAB_COPY = {
    'nl': dict(kicker='WOORDENSTUDIO', intro='Ontdek woorden, hun betekenis en echte voorbeelden.',
        search_label='Zoek woorden', placeholder='Zoek een woord of vertaling', search='Zoeken',
        level='Niveau', clear='Filters wissen', words='woorden', pronunciation='Uitspraak',
        example='Voorbeeld', word_family='Woordfamilie', usage='Gebruik',
        previous='Vorige', next='Volgende', page='Pagina', of='van', pagination='Woordpagina’s',
        no_results='Geen woorden gevonden met deze filters.',
        empty='Er zijn nog geen gepubliceerde woorden voor deze cursus.',
        no_course='Kies eerst een leerta(a)l om woorden te ontdekken.',
        choose_course='Kies een leerta(a)l', change_course='Andere leerta(a)l'),
    'en': dict(kicker='WORD STUDIO', intro='Explore words, meanings and real-world examples.',
        search_label='Find words', placeholder='Search for a word or translation', search='Search',
        level='Level', clear='Clear filters', words='words', pronunciation='Pronunciation',
        example='Example', word_family='Word family', usage='Usage',
        previous='Previous', next='Next', page='Page', of='of', pagination='Vocabulary pages',
        no_results='No words match these filters.',
        empty='No words have been published for this course yet.',
        no_course='Choose a learning language to explore words.',
        choose_course='Choose a language', change_course='Change language'),
    'ckb': dict(kicker='ستۆدیۆی وشەکان', intro='وشە، واتا و نموونەی بەکارهێنانیان بدۆزەوە.',
        search_label='گەڕان بەدوای وشەدا', placeholder='وشە یان وەرگێڕانێک بنووسە', search='گەڕان',
        level='ئاست', clear='سڕینەوەی فلتەرەکان', words='وشە', pronunciation='تەلەفوز',
        example='نموونە', word_family='خێزانی وشە', usage='بەکارهێنان',
        previous='پێشوو', next='دواتر', page='پەڕە', of='لە', pagination='پەڕەکانی وشەکان',
        no_results='هیچ وشەیەک لەگەڵ ئەم فلتەرانە نەدۆزرایەوە.',
        empty='هێشتا هیچ وشەیەکی بڵاوکراوە بۆ ئەم کۆرسە نییە.',
        no_course='سەرەتا زمانێک بۆ فێربوون هەڵبژێرە.',
        choose_course='هەڵبژاردنی زمان', change_course='گۆڕینی زمانی فێربوون'),
    'ar': dict(kicker='استوديو الكلمات', intro='استكشف الكلمات ومعانيها وأمثلة استعمالها.',
        search_label='البحث عن الكلمات', placeholder='ابحث عن كلمة أو ترجمة', search='بحث',
        level='المستوى', clear='مسح المرشحات', words='كلمة', pronunciation='النطق',
        example='مثال', word_family='عائلة الكلمة', usage='الاستخدام',
        previous='السابق', next='التالي', page='صفحة', of='من', pagination='صفحات المفردات',
        no_results='لم يتم العثور على كلمات تطابق هذه المرشحات.',
        empty='لا توجد كلمات منشورة لهذه الدورة حتى الآن.',
        no_course='اختر لغة لتتعلم كلماتها.',
        choose_course='اختر لغة', change_course='تغيير اللغة'),
}


def for_language(language):
    return VOCAB_COPY.get(language, VOCAB_COPY['en'])


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'rozh_vocabulary_ui', ['VOCAB_COPY'])

"""Private, course-scoped listening, speaking and writing practice.

Only minimal attempt metadata is retained. Transcript comparison and writing
form checks do not assess pronunciation, grammar or CEFR proficiency.
"""
import re
import unicodedata
from difflib import SequenceMatcher

from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import HttpResponse
from django.shortcuts import render
from django.views.decorators.http import require_http_methods

from .models import SkillPracticeAttempt, Vocabulary
from .services import rate_limit
from .skill_feedback import evaluate_speaking, normalize
from .practice_access_v48 import eligible_practice_profile

LEVELS = ('A0', 'A1', 'A2', 'B1', 'B2', 'C1')
TARGET_LOCALES = {'nl': 'nl-NL', 'en': 'en-GB', 'de': 'de-DE', 'fr': 'fr-FR',
                  'ar': 'ar-SA', 'ckb': 'ckb-IQ'}
TEXT = {
    'en': {
        'eyebrow': 'YOUR LANGUAGE STUDIO', 'listening': 'Listening', 'speaking': 'Speaking', 'writing': 'Writing', 'photos': 'Picture practice',
        'title_listening': 'Tune in. Try it yourself.', 'title_speaking': 'Find your voice.', 'title_writing': 'Build a sentence that is yours.',
        'intro_listening': 'Listen to a short example, then type what you hear.', 'intro_speaking': 'Listen, say the example and compare the words in your transcript.', 'intro_writing': 'Use one useful word in a real sentence. Check its form, then improve it.',
        'course': 'Your course', 'level': 'Practice level', 'all_levels': 'All available levels', 'filter': 'Choose level', 'change_course': 'Change course',
        'step_one': 'Explore the example', 'step_two': 'Give it a try', 'step_three': 'Notice and improve',
        'task_listening': 'What do you hear?', 'task_speaking': 'Say this example aloud', 'task_writing': 'Your focus word',
        'listen': 'Listen', 'slow': 'Listen slowly', 'reveal': 'Show transcript', 'hide': 'Hide transcript', 'transcript': 'Example transcript',
        'meaning': 'Meaning', 'context': 'An example in context', 'reference': 'Compare with the example',
        'listen_label': 'Type the sentence you hear', 'speak_label': 'Your spoken words, transcribed', 'write_label': 'Your sentence',
        'listen_placeholder': 'Listen first, then type the words you heard…', 'speak_placeholder': 'Use the microphone, or type what you said…', 'write_placeholder': 'Write a complete sentence of at least six words…',
        'check': 'Check my practice', 'next': 'Next example', 'retry': 'Try this example again', 'result': 'Your practice feedback',
        'match': 'Word match', 'form': 'Sentence form', 'exact': 'You caught every word. Nice listening!', 'listen_again': 'Listen once more and compare with the example.',
        'speak_good': 'Your transcript is close to the example.', 'speak_retry': 'Compare the words and their order, then say it again.',
        'write_good': 'Your sentence meets all four form checks.', 'write_retry': 'Use the checklist to improve your sentence.',
        'notice_speaking': 'This compares transcribed words. It does not assess pronunciation or accent.', 'notice_listening': 'This checks a short transcript, not your overall listening level.', 'notice_writing': 'These are basic form checks. Grammar and meaning have not been independently verified.',
        'privacy': 'The browser may send microphone audio to its recognition provider. Start only if you agree. You can always type instead.',
        'start_mic': 'Start microphone', 'stop_mic': 'Stop microphone', 'mic_idle': 'Microphone is off.', 'mic_listening': 'Listening… say the example now.', 'mic_ready': 'Transcript ready. Check the words before submitting.', 'mic_unsupported': 'Speech recognition is unavailable in this browser. Type what you said instead.', 'mic_denied': 'Microphone access was denied. You can type instead.', 'mic_error': 'Speech recognition could not finish. Try again or type instead.',
        'audio_unsupported': 'Audio is unavailable in this browser. Reveal the transcript to practise reading instead.', 'audio_playing': 'Playing the example…', 'audio_done': 'Playback finished. You can listen again.', 'audio_error': 'Audio could not play. Try again or reveal the transcript.',
        'check_done': 'Ready', 'check_pending': 'Not yet', 'check_words': 'At least six words', 'check_target': 'Use the focus word', 'check_capital': 'Start with a capital letter', 'check_punctuation': 'End with . ! or ?',
        'prompt_basic': 'Write one sentence about your day. Include the focus word.', 'prompt_middle': 'Describe a real situation: who, what, when and where. Include the focus word.', 'prompt_advanced': 'State an opinion and give one reason. Include the focus word.',
        'word_count': 'words', 'history': 'Completed practice attempts', 'data': 'Only the score, input method and answer length are saved. Your text and audio are not stored by Rozh.',
        'empty': 'No published practice words are available for this course and level yet.', 'choose': 'Choose your learning language in your profile.', 'back': 'Back to practice',
        'invalid': 'Enter a readable answer within the character limit.', 'source_error': 'Choose a supported input method.', 'expired': 'This example changed. Reload the page before trying again.', 'limited': 'You have practised a lot. Please try again later.',
    },
    'nl': {
        'eyebrow': 'JOUW TAALSTUDIO', 'listening': 'Luisteren', 'speaking': 'Spreken', 'writing': 'Schrijven', 'photos': 'Oefenen met beelden',
        'title_listening': 'Luister. Probeer het zelf.', 'title_speaking': 'Vind je eigen stem.', 'title_writing': 'Maak een zin die bij jou past.',
        'intro_listening': 'Luister naar een kort voorbeeld en typ wat je hoort.', 'intro_speaking': 'Luister, spreek het voorbeeld na en vergelijk de woorden in je transcript.', 'intro_writing': 'Gebruik een handig woord in een echte zin. Controleer de vorm en verbeter je tekst.',
        'course': 'Jouw cursus', 'level': 'Oefenniveau', 'all_levels': 'Alle beschikbare niveaus', 'filter': 'Kies niveau', 'change_course': 'Andere cursus',
        'step_one': 'Ontdek het voorbeeld', 'step_two': 'Probeer het zelf', 'step_three': 'Vergelijk en verbeter',
        'task_listening': 'Wat hoor je?', 'task_speaking': 'Spreek dit voorbeeld uit', 'task_writing': 'Jouw doelwoord',
        'listen': 'Luisteren', 'slow': 'Langzaam luisteren', 'reveal': 'Transcript tonen', 'hide': 'Transcript verbergen', 'transcript': 'Transcript van het voorbeeld',
        'meaning': 'Betekenis', 'context': 'Een voorbeeld in context', 'reference': 'Vergelijk met het voorbeeld',
        'listen_label': 'Typ de zin die je hoort', 'speak_label': 'De woorden die je uitsprak', 'write_label': 'Jouw zin',
        'listen_placeholder': 'Luister eerst en typ daarna de woorden die je hoorde…', 'speak_placeholder': 'Gebruik de microfoon of typ wat je zei…', 'write_placeholder': 'Schrijf een volledige zin met minstens zes woorden…',
        'check': 'Mijn oefening controleren', 'next': 'Volgend voorbeeld', 'retry': 'Dit voorbeeld opnieuw proberen', 'result': 'Feedback op je oefening',
        'match': 'Woordovereenkomst', 'form': 'Zinsvorm', 'exact': 'Je hoorde alle woorden goed!', 'listen_again': 'Luister nog eens en vergelijk met het voorbeeld.',
        'speak_good': 'Je transcript lijkt sterk op het voorbeeld.', 'speak_retry': 'Vergelijk de woorden en hun volgorde en spreek de zin opnieuw uit.',
        'write_good': 'Je zin voldoet aan de vier vormcontroles.', 'write_retry': 'Verbeter je zin met behulp van de checklist.',
        'notice_speaking': 'Dit vergelijkt uitgeschreven woorden. Het beoordeelt je uitspraak of accent niet.', 'notice_listening': 'Dit controleert een kort transcript, niet je volledige luistervaardigheid.', 'notice_writing': 'Dit zijn eenvoudige vormcontroles. Grammatica en betekenis zijn niet onafhankelijk gecontroleerd.',
        'privacy': 'Je browser kan microfoonaudio naar zijn spraakherkenningsdienst sturen. Start alleen als je akkoord gaat. Je kunt ook typen.',
        'start_mic': 'Microfoon starten', 'stop_mic': 'Microfoon stoppen', 'mic_idle': 'De microfoon staat uit.', 'mic_listening': 'Ik luister… spreek het voorbeeld nu uit.', 'mic_ready': 'Transcript klaar. Controleer de woorden voor je indient.', 'mic_unsupported': 'Spraakherkenning is niet beschikbaar in deze browser. Typ wat je zei.', 'mic_denied': 'Microfoontoegang is geweigerd. Je kunt ook typen.', 'mic_error': 'Spraakherkenning kon niet afronden. Probeer opnieuw of typ je tekst.',
        'audio_unsupported': 'Audio is niet beschikbaar in deze browser. Toon het transcript om te oefenen met lezen.', 'audio_playing': 'Het voorbeeld wordt afgespeeld…', 'audio_done': 'Afspelen voltooid. Je kunt opnieuw luisteren.', 'audio_error': 'De audio kon niet afspelen. Probeer opnieuw of toon het transcript.',
        'check_done': 'Klaar', 'check_pending': 'Nog niet', 'check_words': 'Minstens zes woorden', 'check_target': 'Gebruik het doelwoord', 'check_capital': 'Begin met een hoofdletter', 'check_punctuation': 'Eindig met . ! of ?',
        'prompt_basic': 'Schrijf een zin over je dag. Gebruik het doelwoord.', 'prompt_middle': 'Beschrijf een echte situatie: wie, wat, wanneer en waar. Gebruik het doelwoord.', 'prompt_advanced': 'Geef je mening met één reden. Gebruik het doelwoord.',
        'word_count': 'woorden', 'history': 'Afgeronde oefeningen', 'data': 'Alleen de score, invoermethode en tekstlengte worden bewaard. Rozh slaat je tekst en audio niet op.',
        'empty': 'Er zijn nog geen gepubliceerde oefenwoorden voor deze cursus en dit niveau.', 'choose': 'Kies je leertaal in je profiel.', 'back': 'Terug naar oefenen',
        'invalid': 'Vul een leesbaar antwoord binnen de tekenlimiet in.', 'source_error': 'Kies een ondersteunde invoermethode.', 'expired': 'Dit voorbeeld is veranderd. Herlaad de pagina voordat je verdergaat.', 'limited': 'Je hebt veel geoefend. Probeer het later opnieuw.',
    },
    'ckb': {
        'eyebrow': 'ستۆدیۆی زمانەکەت', 'listening': 'گوێگرتن', 'speaking': 'قسەکردن', 'writing': 'نووسین', 'photos': 'ڕاهێنان بە وێنە',
        'title_listening': 'گوێ بگرە و خۆت تاقی بکەرەوە.', 'title_speaking': 'بە دڵنیایی قسە بکە.', 'title_writing': 'ڕستەیەکی تایبەت بە خۆت بنووسە.',
        'intro_listening': 'گوێ لە نموونەیەکی کورت بگرە، پاشان ئەوەی دەیبیستیت بینووسە.', 'intro_speaking': 'گوێ بگرە، نموونەکە بڵێوە و وشەکان بەراورد بکە.', 'intro_writing': 'وشەیەکی بەسوود لە ڕستەیەکدا بەکاربهێنە و شێوەکەی بپشکنە.',
        'course': 'کۆرسەکەت', 'level': 'ئاستی ڕاهێنان', 'all_levels': 'هەموو ئاستە بەردەستەکان', 'filter': 'ئاست هەڵبژێرە', 'change_course': 'گۆڕینی کۆرس',
        'step_one': 'نموونەکە بناسە', 'step_two': 'خۆت تاقی بکەرەوە', 'step_three': 'بەراورد بکە و باشتر بکە',
        'task_listening': 'چی دەبیستیت؟', 'task_speaking': 'ئەم نموونەیە بە دەنگ بڵێوە', 'task_writing': 'وشەی ئامانجت',
        'listen': 'گوێ بگرە', 'slow': 'بە هێواشی گوێ بگرە', 'reveal': 'دەقەکە پیشان بدە', 'hide': 'دەقەکە بشارەوە', 'transcript': 'دەقی نموونەکە',
        'meaning': 'مانا', 'context': 'نموونەی بەکارهێنان', 'reference': 'لەگەڵ نموونەکە بەراورد بکە',
        'listen_label': 'ئەو ڕستەیە بنووسە کە دەیبیستیت', 'speak_label': 'ئەو وشانەی وتت', 'write_label': 'ڕستەکەت',
        'listen_placeholder': 'سەرەتا گوێ بگرە، پاشان ئەو وشانەی بیستت بنووسە…', 'speak_placeholder': 'مایکرۆفۆن بەکاربهێنە یان ئەوەی وتت بینووسە…', 'write_placeholder': 'ڕستەیەکی تەواو بە لانیکەم شەش وشە بنووسە…',
        'check': 'ڕاهێنانەکەم بپشکنە', 'next': 'نموونەی داهاتوو', 'retry': 'ئەم نموونەیە دووبارە بکەوە', 'result': 'پێداچوونەوەی ڕاهێنانەکەت',
        'match': 'هاوشێوەیی وشەکان', 'form': 'شێوەی ڕستە', 'exact': 'هەموو وشەکانت بە دروستی بیست!', 'listen_again': 'دووبارە گوێ بگرە و لەگەڵ نموونەکە بەراورد بکە.',
        'speak_good': 'دەقەکەت زۆر لە نموونەکە دەچێت.', 'speak_retry': 'وشەکان و ڕیزبەندییان بەراورد بکە و دووبارە بیانڵێوە.',
        'write_good': 'ڕستەکەت چوار پێوەری شێوەکەی تەواو کرد.', 'write_retry': 'بە یارمەتی لیستەکە ڕستەکەت باشتر بکە.',
        'notice_speaking': 'ئەمە وشە نووسراوەکان بەراورد دەکات؛ دەنگدان یان ئەکسێنت هەڵناسەنگێنێت.', 'notice_listening': 'ئەمە دەقێکی کورت دەپشکنێت، نەک هەموو توانای گوێگرتنت.', 'notice_writing': 'ئەمە پشکنینی سادەی شێوەیە. ڕێزمان و مانا بە سەربەخۆیی نەسەلمێنراون.',
        'privacy': 'وێبگەڕەکەت لەوانەیە دەنگ بۆ خزمەتگوزاریی ناسینەوەی قسە بنێرێت. تەنها بە ڕەزامەندی دەست پێ بکە؛ هەمیشە دەتوانیت بنووسیت.',
        'start_mic': 'مایکرۆفۆن چالاک بکە', 'stop_mic': 'مایکرۆفۆن بوەستێنە', 'mic_idle': 'مایکرۆفۆن ناچالاکە.', 'mic_listening': 'گوێ دەگرم… ئێستا نموونەکە بڵێوە.', 'mic_ready': 'دەقەکە ئامادەیە. پێش ناردن وشەکان بپشکنە.', 'mic_unsupported': 'ناسینەوەی قسە لەم وێبگەڕە بەردەست نییە؛ ئەوەی وتت بینووسە.', 'mic_denied': 'ڕێگەی بەکارهێنانی مایکرۆفۆن نەدرا. دەتوانیت بنووسیت.', 'mic_error': 'ناسینەوەی قسە تەواو نەبوو. دووبارە هەوڵ بدە یان بنووسە.',
        'audio_unsupported': 'دەنگ لەم وێبگەڕە بەردەست نییە؛ دەقەکە پیشان بدە و خوێندنەوە ڕاهێنان بکە.', 'audio_playing': 'نموونەکە پەخش دەکرێت…', 'audio_done': 'پەخشکردن تەواو بوو؛ دەتوانیت دووبارە گوێ بگریت.', 'audio_error': 'دەنگ پەخش نەکرا. دووبارە هەوڵ بدە یان دەقەکە پیشان بدە.',
        'check_done': 'ئامادەیە', 'check_pending': 'هێشتا نا', 'check_words': 'لانیکەم شەش وشە', 'check_target': 'وشەی ئامانج بەکاربهێنە', 'check_capital': 'بە پیتی گەورە دەست پێ بکە', 'check_punctuation': 'بە . ! یان ؟ کۆتایی پێ بهێنە',
        'prompt_basic': 'ڕستەیەک دەربارەی ڕۆژەکەت بنووسە و وشەی ئامانج بەکاربهێنە.', 'prompt_middle': 'دۆخێکی ڕاستەقینە باس بکە: کێ، چی، کەی و لەکوێ. وشەی ئامانج بەکاربهێنە.', 'prompt_advanced': 'ڕایەک دەرببڕە و هۆکارێک بۆی بهێنەوە. وشەی ئامانج بەکاربهێنە.',
        'word_count': 'وشە', 'history': 'ڕاهێنانە تەواوکراوەکان', 'data': 'تەنها نمرە، شێوازی نووسین و درێژی وەڵام پاشەکەوت دەکرێن. Rozh دەق و دەنگەکەت پاشەکەوت ناکات.',
        'empty': 'هێشتا هیچ وشەیەکی بڵاوکراوە بۆ ئەم کۆرس و ئاستە نییە.', 'choose': 'زمانی فێربوون لە پرۆفایلەکەت هەڵبژێرە.', 'back': 'گەڕانەوە بۆ ڕاهێنان',
        'invalid': 'وەڵامێکی خوێندراوە لە سنووری ژمارەی پیتەکان بنووسە.', 'source_error': 'شێوازێکی پشتگیریکراو هەڵبژێرە.', 'expired': 'ئەم نموونەیە گۆڕاوە. پەڕەکە نوێ بکەرەوە و دووبارە هەوڵ بدە.', 'limited': 'زۆرت ڕاهێنان کردووە. تکایە دواتر هەوڵ بدەوە.',
    },
    'ar': {
        'eyebrow': 'استوديو اللغة', 'listening': 'الاستماع', 'speaking': 'التحدث', 'writing': 'الكتابة', 'photos': 'التدريب بالصور',
        'title_listening': 'استمع ثم جرّب بنفسك.', 'title_speaking': 'تحدث بثقة.', 'title_writing': 'اكتب جملة تخصك.',
        'intro_listening': 'استمع إلى مثال قصير، ثم اكتب ما تسمعه.', 'intro_speaking': 'استمع وقل المثال ثم قارن الكلمات في النص المنسوخ.', 'intro_writing': 'استخدم كلمة مفيدة في جملة حقيقية، ثم تحقق من بنيتها وحسّنها.',
        'course': 'دورتك', 'level': 'مستوى التدريب', 'all_levels': 'جميع المستويات المتاحة', 'filter': 'اختر المستوى', 'change_course': 'تغيير الدورة',
        'step_one': 'اكتشف المثال', 'step_two': 'جرّب بنفسك', 'step_three': 'قارن وحسّن',
        'task_listening': 'ماذا تسمع؟', 'task_speaking': 'قل هذا المثال بصوتك', 'task_writing': 'الكلمة المستهدفة',
        'listen': 'استمع', 'slow': 'استمع ببطء', 'reveal': 'إظهار النص', 'hide': 'إخفاء النص', 'transcript': 'نص المثال',
        'meaning': 'المعنى', 'context': 'مثال في سياقه', 'reference': 'قارن بالمثال',
        'listen_label': 'اكتب الجملة التي تسمعها', 'speak_label': 'الكلمات التي قلتها', 'write_label': 'جملتك',
        'listen_placeholder': 'استمع أولًا ثم اكتب الكلمات التي سمعتها…', 'speak_placeholder': 'استخدم الميكروفون أو اكتب ما قلته…', 'write_placeholder': 'اكتب جملة كاملة من ست كلمات على الأقل…',
        'check': 'تحقق من تدريبي', 'next': 'المثال التالي', 'retry': 'جرّب هذا المثال مجددًا', 'result': 'ملاحظات التدريب',
        'match': 'تطابق الكلمات', 'form': 'بنية الجملة', 'exact': 'سمعت جميع الكلمات بشكل صحيح!', 'listen_again': 'استمع مرة أخرى وقارن بالمثال.',
        'speak_good': 'النص المنسوخ قريب من المثال.', 'speak_retry': 'قارن الكلمات وترتيبها ثم قل المثال مجددًا.',
        'write_good': 'حققت جملتك شروط البنية الأربعة.', 'write_retry': 'استخدم قائمة المراجعة لتحسين جملتك.',
        'notice_speaking': 'هذه مقارنة للكلمات المنسوخة، وليست تقييمًا للنطق أو اللهجة.', 'notice_listening': 'هذا فحص لنص قصير، وليس تقييمًا شاملًا للاستماع.', 'notice_writing': 'هذه فحوص بسيطة للبنية. لم تُراجع القواعد والمعنى بشكل مستقل.',
        'privacy': 'قد يرسل المتصفح صوت الميكروفون إلى خدمة التعرف على الكلام. ابدأ فقط بموافقتك، ويمكنك دائمًا الكتابة.',
        'start_mic': 'تشغيل الميكروفون', 'stop_mic': 'إيقاف الميكروفون', 'mic_idle': 'الميكروفون متوقف.', 'mic_listening': 'أستمع… قل المثال الآن.', 'mic_ready': 'النص جاهز. راجع الكلمات قبل الإرسال.', 'mic_unsupported': 'التعرف على الكلام غير متاح في هذا المتصفح. اكتب ما قلته بدلًا منه.', 'mic_denied': 'رُفض الوصول إلى الميكروفون. يمكنك الكتابة.', 'mic_error': 'تعذر إكمال التعرف على الكلام. حاول مجددًا أو اكتب.',
        'audio_unsupported': 'الصوت غير متاح في هذا المتصفح. أظهر النص للتدرب على القراءة.', 'audio_playing': 'جارٍ تشغيل المثال…', 'audio_done': 'انتهى التشغيل. يمكنك الاستماع مجددًا.', 'audio_error': 'تعذر تشغيل الصوت. حاول مجددًا أو أظهر النص.',
        'check_done': 'جاهز', 'check_pending': 'ليس بعد', 'check_words': 'ست كلمات على الأقل', 'check_target': 'استخدم الكلمة المستهدفة', 'check_capital': 'ابدأ بحرف كبير', 'check_punctuation': 'اختم بـ . ! أو ؟',
        'prompt_basic': 'اكتب جملة عن يومك باستخدام الكلمة المستهدفة.', 'prompt_middle': 'صف موقفًا حقيقيًا: من وماذا ومتى وأين. استخدم الكلمة المستهدفة.', 'prompt_advanced': 'عبّر عن رأيك مع ذكر سبب واحد، مستخدمًا الكلمة المستهدفة.',
        'word_count': 'كلمات', 'history': 'محاولات التدريب المكتملة', 'data': 'تُحفظ الدرجة وطريقة الإدخال وطول الإجابة فقط. لا يحفظ Rozh نصك أو صوتك.',
        'empty': 'لا توجد كلمات تدريب منشورة لهذه الدورة وهذا المستوى بعد.', 'choose': 'اختر لغة التعلم من ملفك الشخصي.', 'back': 'العودة إلى التدريب',
        'invalid': 'أدخل إجابة مقروءة ضمن الحد المسموح للأحرف.', 'source_error': 'اختر طريقة إدخال مدعومة.', 'expired': 'تغيّر هذا المثال. أعد تحميل الصفحة قبل المحاولة.', 'limited': 'تدرّبت كثيرًا. حاول مجددًا لاحقًا.',
    },
}


def _writing_checks(answer, focus_word, labels):
    words = re.findall(r"\b[\wÀ-ÿ]+(?:['’-][\wÀ-ÿ]+)*\b", unicodedata.normalize('NFKC', answer), flags=re.UNICODE)
    normalized = normalize(answer)
    focus = normalize(focus_word)
    target_found = bool(focus) and re.search(r'(?:^|\s)' + re.escape(focus) + r'(?:$|\s)', normalized) is not None
    checks = [
        {'label': labels['check_words'], 'passed': len(words) >= 6, 'weight': 40},
        {'label': labels['check_target'], 'passed': target_found, 'weight': 35},
        {'label': labels['check_capital'], 'passed': answer.lstrip()[:1].isupper(), 'weight': 10},
        {'label': labels['check_punctuation'], 'passed': answer.rstrip().endswith(('.', '!', '?', '؟')), 'weight': 15},
    ]
    return checks, len(words)


def _feedback(kind, answer, target, labels):
    reference = target.example or target.word
    if kind == 'writing':
        checks, count = _writing_checks(answer, target.word, labels)
        score = sum(item['weight'] for item in checks if item['passed'])
        return {'score': score, 'feedback': labels['write_good' if score == 100 else 'write_retry'],
                'checks': checks, 'word_count': count}
    if kind == 'speaking':
        score, _ = evaluate_speaking(answer, reference)
        return {'score': score, 'feedback': labels['speak_good' if score >= 85 else 'speak_retry']}
    expected, entered = normalize(reference), normalize(answer)
    if entered == expected:
        score = 100
    else:
        matching = sum(block.size for block in SequenceMatcher(None, expected.split(), entered.split(), autojunk=False).get_matching_blocks())
        score = min(99, round(100 * matching / max(len(expected.split()), len(entered.split()), 1)))
    return {'score': score, 'feedback': labels['exact' if score == 100 else 'listen_again'], 'correct': score == 100}


@login_required
@require_http_methods(['GET', 'POST'])
def practice(request, kind):
    if kind != 'listening':
        return HttpResponse('Unknown practice mode', status=404)
    profile = eligible_practice_profile(request.user)
    if profile is None:
        return HttpResponse('Your learning account is not available for practice.', status=403)
    labels = TEXT.get(profile.ui_language, TEXT['en'])
    language = profile.preferred_language
    language = language if language and language.is_published else None
    all_words = Vocabulary.objects.filter(published=True, level__language=language,
        level__language__is_published=True).select_related('level__language').order_by('level__order', 'pk') if language else Vocabulary.objects.none()
    available = set(all_words.values_list('level__code', flat=True))
    selected_level = request.GET.get('level', '').upper()
    if selected_level and selected_level not in LEVELS:
        return HttpResponse(labels['invalid'], status=400)
    words = all_words.filter(level__code=selected_level) if selected_level else all_words
    target_key, scope_key, result_key = (f'practice_target_{kind}', f'practice_scope_{kind}', f'practice_result_{kind}')
    scope = f'{language.pk if language else 0}:{selected_level}'
    same_scope = request.session.get(scope_key) == scope
    target_pk = request.session.get(target_key) if same_scope else None
    target = words.filter(pk=target_pk).first() if target_pk else None
    result = request.session.get(result_key) if target is not None else None
    answer = ''
    if request.method == 'POST':
        if rate_limit(request, f'skill-{kind}', 20, 3600, True):
            return HttpResponse(labels['limited'], status=429)
        action = request.POST.get('action', 'check')
        if action not in ('check', 'next', 'retry'):
            return HttpResponse(labels['invalid'], status=400)
        if not words.exists():
            return HttpResponse(labels['empty'], status=503)
        if action == 'check':
            answer = request.POST.get('answer', '')
            maximum = 2000 if kind == 'writing' else 800
            if not answer.strip() or len(answer) > maximum or not normalize(answer) or '\x00' in answer:
                return HttpResponse(labels['invalid'], status=400)
            source = request.POST.get('source', 'typed')
            if source not in ('typed', 'microphone') or (kind != 'speaking' and source != 'typed'):
                return HttpResponse(labels['source_error'], status=400)
        if target is None:
            return HttpResponse(labels['expired'], status=409)
        if request.POST.get('prompt_id') and request.POST['prompt_id'] != str(target.pk):
            return HttpResponse(labels['expired'], status=409)
        if action == 'next':
            # The ordered queryset is (level.order, pk). Fetch only the next
            # row, wrapping to the first, without materializing all word IDs.
            from django.db.models import Q
            following = words.filter(
                Q(level__order__gt=target.level.order) |
                Q(level__order=target.level.order, pk__gt=target.pk)
            ).first()
            target = following or words.first()
            request.session[target_key] = target.pk
            request.session.pop(result_key, None)
            result = None
        elif action == 'retry':
            request.session.pop(result_key, None)
            result = None
        elif result is not None:
            # A duplicate submission returns the existing round, never its old score
            # alongside a different newly submitted answer. Retry is explicit.
            answer = ''
        else:
            with transaction.atomic():
                # Lock Profile first, matching the course-switching write order.
                current = eligible_practice_profile(request.user, for_update=True)
                if current is None:
                    return HttpResponse('Your learning account is not available for practice.', status=403)
                if not language or current.preferred_language_id != language.pk:
                    return HttpResponse(labels['expired'], status=409)
                # A previously shown vocabulary item can be unpublished/replaced
                # during a request. Only current published course content is graded.
                active_target = Vocabulary.objects.select_for_update().filter(
                    pk=target.pk, published=True,
                    level__language_id=current.preferred_language_id,
                    level__language__is_published=True,
                ).select_related('level__language').first()
                if active_target is None or (selected_level and active_target.level.code != selected_level):
                    return HttpResponse(labels['expired'], status=409)
                result = _feedback(kind, answer, active_target, labels)
                SkillPracticeAttempt.objects.create(user=request.user, vocabulary=active_target, kind=kind,
                    score=result['score'], input_method=source, answer_length=len(answer))
            request.session[result_key] = result
            # No raw writing, transcript or audio is saved, and heuristic checks earn no XP.
    if target is None:
        target = words.first()
        request.session[scope_key] = scope
        request.session.pop(result_key, None)
        result = None
        if target:
            request.session[target_key] = target.pk
        else:
            request.session.pop(target_key, None)
    if result is not None:
        result = dict(result)
        score = result['score']
        if kind == 'writing':
            result['feedback'] = labels['write_good' if score == 100 else 'write_retry']
            result['checks'] = [dict(item, label=labels[key]) for item, key in zip(result.get('checks', []),
                ('check_words', 'check_target', 'check_capital', 'check_punctuation'))]
        elif kind == 'speaking':
            result['feedback'] = labels['speak_good' if score >= 85 else 'speak_retry']
        else:
            result['feedback'] = labels['exact' if score == 100 else 'listen_again']
    reference = target.example or target.word if target else ''
    target_code = target.level.language.code if target else (language.code if language else 'en')
    target_locale = TARGET_LOCALES.get(target_code, target_code)
    writing_prompt = labels['prompt_basic'] if not target or target.level.code in ('A0', 'A1') else labels['prompt_middle' if target.level.code in ('A2', 'B1') else 'prompt_advanced']
    return render(request, 'academy/skill_practice.html', {
        'kind': kind, 'target': target, 'reference': reference, 'result': result, 'answer': answer,
        'language': language, 'target_code': target_code, 'target_locale': target_locale,
        'target_dir': 'rtl' if target_code in ('ar', 'ckb') else 'ltr',
        'labels': labels, 'title': labels['title_' + kind], 'intro': labels['intro_' + kind],
        'notice': labels['notice_' + kind], 'selected_level': selected_level,
        'levels': [level for level in LEVELS if level in available], 'writing_prompt': writing_prompt,
        'noindex': True, 'attempts': SkillPracticeAttempt.objects.filter(user=request.user, kind=kind,
            vocabulary__level__language=language).count() if language else 0,
    })


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'skill_practice', ['TEXT'])

"""Genuine Django HTTP/ORM tests for V40. NOT executed in offline environment."""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .models import Exercise, Language, Lesson, LessonProgress, Level, Profile, Unit, XPEvent, MistakeRecord
from .heart_models import HeartEvent


class ClassicLessonV40HTTPTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user=get_user_model().objects.create_user(username='v40student',password='OnlyForTests-V40!')
        self.dutch=Language.objects.create(code='nl',slug='v40-nl',name='V40 Dutch',is_published=True)
        self.english=Language.objects.create(code='en',slug='v40-en',name='V40 English',is_published=True)
        level=Level.objects.create(language=self.dutch,code='A0',order=0)
        self.unit=Unit.objects.create(level=level,slug='v40-unit',title='V40 unit',summary='',order=1,published=True)
        self.lesson=Lesson.objects.create(unit=self.unit,slug='v40-lesson',title='V40 lesson',skill='grammar',
                                         content='Only test content',order=1,published=True)
        self.exercise=Exercise.objects.create(lesson=self.lesson,kind='mcq',prompt='Is this correct?',
                                              options=['Yes','No'],answer='Yes',explanation='Yes')
        Profile.objects.filter(user=self.user).update(preferred_language=self.dutch,placement_level='A0',
                       placement_completed=True,onboarding_required=True,onboarding_completed=True)
        self.client.force_login(self.user)
        self.ssr=reverse('lesson',args=[self.lesson.pk])
        self.ajax=reverse('lesson_answer',args=[self.lesson.pk])

    def submit(self,route):
        if route=='ssr':
            return self.client.post(self.ssr,{f'answer_{self.exercise.pk}':'Yes',
                        'round_key':self.client.session.get(f'lesson_round_{self.lesson.pk}','')})
        return self.client.post(self.ajax,{'exercise_id':self.exercise.pk,'answer':'Yes',
                        'round_key':self.client.session.get(f'lesson_round_{self.lesson.pk}','')})

    def assert_no_changes(self):
        self.assertFalse(LessonProgress.objects.filter(user=self.user).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())
        self.assertFalse(MistakeRecord.objects.filter(user=self.user).exists())
        self.assertFalse(HeartEvent.objects.filter(user=self.user).exists())

    def test_valid_ssr_lesson_can_complete(self):
        self.assertEqual(self.client.get(self.ssr).status_code,200)
        self.assertEqual(self.submit('ssr').status_code,200)
        self.assertTrue(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())

    def test_valid_ajax_answer_can_complete(self):
        self.assertEqual(self.client.get(self.ssr).status_code,200)
        reply=self.submit('ajax')
        self.assertEqual(reply.status_code,200)
        self.assertTrue(reply.json()['correct'])
        self.assertTrue(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())

    def test_suspension_after_opening_blocks_both_post_flows(self):
        self.client.get(self.ssr)
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        for route in ('ssr','ajax'):
            with self.subTest(route=route): self.assertEqual(self.submit(route).status_code,403)
        self.assert_no_changes()

    def test_mandatory_review_after_opening_blocks_both_post_flows(self):
        self.client.get(self.ssr)
        Profile.objects.filter(user=self.user).update(legacy_review_required=True)
        for route in ('ssr','ajax'):
            with self.subTest(route=route): self.assertEqual(self.submit(route).status_code,403)
        self.assert_no_changes()

    def test_course_switch_after_opening_blocks_both_post_flows(self):
        self.client.get(self.ssr)
        Profile.objects.filter(user=self.user).update(preferred_language=self.english)
        for route in ('ssr','ajax'):
            with self.subTest(route=route): self.assertEqual(self.submit(route).status_code,403)
        self.assert_no_changes()

    def test_placement_revocation_after_opening_blocks_both_post_flows(self):
        self.client.get(self.ssr)
        Profile.objects.filter(user=self.user).update(placement_completed=False)
        for route in ('ssr','ajax'):
            with self.subTest(route=route): self.assertEqual(self.submit(route).status_code,403)
        self.assert_no_changes()

    def test_unpublished_lesson_after_opening_blocks_both_post_flows(self):
        self.client.get(self.ssr)
        Lesson.objects.filter(pk=self.lesson.pk).update(published=False)
        for route in ('ssr','ajax'):
            with self.subTest(route=route): self.assertEqual(self.submit(route).status_code,404)
        self.assert_no_changes()

    def test_unpublished_unit_after_opening_blocks_both_post_flows(self):
        self.client.get(self.ssr)
        Unit.objects.filter(pk=self.unit.pk).update(published=False)
        for route in ('ssr','ajax'):
            with self.subTest(route=route): self.assertEqual(self.submit(route).status_code,404)
        self.assert_no_changes()

    def test_onboarding_after_opening_blocks_ssr_and_ajax(self):
        self.client.get(self.ssr)
        Profile.objects.filter(user=self.user).update(onboarding_completed=False)
        self.assertEqual(self.submit('ssr').status_code,302)
        self.assertEqual(self.submit('ajax').status_code,403)
        self.assert_no_changes()

    def test_unpublished_course_after_opening_blocks_both(self):
        self.client.get(self.ssr)
        Language.objects.filter(pk=self.dutch.pk).update(is_published=False)
        for route in ('ssr','ajax'):
            with self.subTest(route=route): self.assertEqual(self.submit(route).status_code,404)
        self.assert_no_changes()

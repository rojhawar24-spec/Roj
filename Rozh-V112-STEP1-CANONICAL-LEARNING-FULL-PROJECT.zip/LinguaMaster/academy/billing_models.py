"""Paid AI credits. Credit grants originate from verified Stripe payment events."""
import uuid
from decimal import Decimal
from django.conf import settings
from django.db import models
from django.utils import timezone


class AICreditWallet(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='ai_wallet')
    balance = models.PositiveIntegerField(default=0)
    purchased = models.PositiveIntegerField(default=0)
    updated_at = models.DateTimeField(auto_now=True)


class AICreditPurchase(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='ai_purchases')
    status = models.CharField(max_length=10, choices=[('pending', 'Pending'), ('paid', 'Paid'), ('failed', 'Failed')], default='pending')
    stripe_session_id = models.CharField(max_length=255, unique=True, null=True, blank=True)
    price_id = models.CharField(max_length=255)
    credits = models.PositiveIntegerField()
    amount_cents = models.PositiveIntegerField()
    currency = models.CharField(max_length=3, default='eur')
    created_at = models.DateTimeField(default=timezone.now)
    paid_at = models.DateTimeField(null=True, blank=True)
    @property
    def amount_eur(self):
        return Decimal(self.amount_cents) / 100

    class Meta:
        ordering = ['-created_at']


class AICreditDebit(models.Model):
    usage = models.OneToOneField('academy.AIUsage', on_delete=models.CASCADE, related_name='credit_debit')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    refunded = models.BooleanField(default=False)
    created_at = models.DateTimeField(default=timezone.now)


class StripeWebhookReceipt(models.Model):
    event_id = models.CharField(max_length=255, primary_key=True)
    purchase = models.ForeignKey(AICreditPurchase, on_delete=models.CASCADE)
    received_at = models.DateTimeField(default=timezone.now)

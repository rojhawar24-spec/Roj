"""Django acceptance tests; audio approval mocked only for test data."""
import json
from unittest.mock import patch
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse
from .journey_v11 import _challenges
from .lesson_activities_v58 import is_correct
from .models import Exercise, Language, Lesson, LessonProgress, Level, Profile, Unit, XPEvent

class MixedFiveHTTP(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user=get_user_model().objects.create_user('v102-qa-user',password='SyntheticMixedTest!2026')
        lang=Language.objects.create(code='nl',name='Dutch',slug='v102-nl',is_published=True)
        level=Level.objects.create(language=lang,code='A0',order=0)
        cls.unit=Unit.objects.create(level=level,slug='v102-unit',title='Greetings',published=True)
        cls.lesson=Lesson.objects.create(unit=cls.unit,slug='v102-lesson',title='Greetings',skill='grammar',content='QA fixture',published=True)
        rows=[('mcq','Kies.',['Ja','Nee'],'Ja',{}),('fill_blank','Ik ___ hier.',[],'woon',{'accepted_answers':['ben']}),('word_matching','Koppel.',[],'',{'pairs':[{'left':'ja','right':'yes'},{'left':'nee','right':'no'}]}),('word_order','Orden.',['Ik','woon','hier.'],'Ik woon hier.',{}),('listening','Luister.',['Ja','Nee'],'Ja',{'audio_text':'Ja.'})]
        for order,(kind,prompt,opts,answer,data) in enumerate(rows):Exercise.objects.create(lesson=cls.lesson,kind=kind,prompt=prompt,options=opts,answer=answer,activity_data=data,explanation='QA explanation',order=order)
        Profile.objects.filter(user=cls.user).update(preferred_language=lang,placement_completed=True,onboarding_required=False,onboarding_completed=True,suspended_at=None,legacy_review_required=False)
    def setUp(self):
        cache.clear();self.client.force_login(self.user)
        self.url=reverse('journey_play',args=[self.unit.pk]);self.answer=reverse('journey_answer',args=[self.unit.pk])
    def test_missing_audio_blocks_get_and_post_without_rewards(self):
        self.assertEqual(self.client.get(self.url).status_code,409)
        self.assertEqual(self.client.post(self.answer,{}).status_code,409)
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())
    @patch('academy.audio_v78.approved_audio_url',return_value='/static/test-only.wav')
    def test_five_kinds_round_and_one_completion(self,approval):
        self.assertEqual(self.client.get(self.url).status_code,200)
        state=self.client.session[f'journey_v11_{self.unit.pk}'];items=_challenges(self.unit,state['token'])
        self.assertEqual({q['type'] for q in items},{'mcq','fill_blank','word_matching','word_order','listening'})
        for q in items:
            answer=q['answer']
            if q['type']=='fill_blank':answer='ben'
            if q['type']=='word_matching':
                mapping={p['left']:p['right'] for p in q['exercise'].activity_data['pairs']}
                answer=json.dumps([q['match_options'].index(mapping[p['left']]) for p in q['matches']])
            self.assertTrue(is_correct(q['exercise'],answer,state['token']))
            result=self.client.post(self.answer,{'round_token':state['token'],'challenge_id':q['id'],'answer':answer},HTTP_X_REQUESTED_WITH='XMLHttpRequest')
            self.assertEqual(result.status_code,200);self.assertTrue(result.json()['correct']);self.assertEqual(result.json()['solution'],'')
        self.assertTrue(result.json()['passed']);self.assertEqual(result.json()['score'],100)
        self.assertEqual(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).count(),1)
        self.assertEqual(XPEvent.objects.filter(user=self.user,reason='lesson').count(),1)
    @patch('academy.audio_v78.approved_audio_url',return_value='/static/test-only.wav')
    def test_legacy_page_and_direct_post_blocked_without_progress(self,approval):
        Lesson.objects.create(unit=self.unit,slug='old-speaking',title='Old speaking',skill='speaking',content='Old legacy content',published=True)
        self.assertEqual(self.client.get(self.url).status_code,409)
        self.assertEqual(self.client.post(self.answer,{}).status_code,409)
        self.assertFalse(LessonProgress.objects.filter(user=self.user).exists())

"""V90 Django HTTP/SQLite integration tests. PENDING until Django can run.

Execute only with config.settings_local_qa and disposable QA database.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .models import Profile


class RevokedAccountCannotReadPrivateRoutesHTTP(TestCase):
    PASSWORD = 'V90-Disposable-Passphrase-Only!'

    def setUp(self):
        self.user = get_user_model().objects.create_user(
            'v90learner', 'v90@example.invalid', self.PASSWORD)
        self.client.force_login(self.user)

    def test_suspended_but_active_dashboard_denied(self):
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        self.assertTrue(get_user_model().objects.get(pk=self.user.pk).is_active)
        self.assertEqual(self.client.get(reverse('dashboard')).status_code, 403)

    def test_quarantined_learning_route_denied(self):
        Profile.objects.filter(user=self.user).update(legacy_review_required=True)
        self.assertEqual(self.client.get(reverse('play_hub')).status_code, 403)

    def test_quarantined_language_mutation_denied(self):
        Profile.objects.filter(user=self.user).update(legacy_review_required=True)
        response = self.client.post(reverse('switch_ui_language'), {'ui_language': 'ar'})
        self.assertEqual(response.status_code, 403)
        self.assertNotEqual(Profile.objects.get(user=self.user).ui_language, 'ar')

    def test_deleted_profile_private_route_denied(self):
        Profile.objects.filter(user=self.user).delete()
        self.assertEqual(self.client.get(reverse('profile')).status_code, 403)
        self.assertFalse(Profile.objects.filter(user=self.user).exists())

    def test_deleted_profile_public_page_revokes_session(self):
        Profile.objects.filter(user=self.user).delete()
        self.assertEqual(self.client.get(reverse('home_ckb')).status_code, 200)
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_revoked_account_api_has_no_private_data(self):
        Profile.objects.filter(user=self.user).update(legacy_review_required=True)
        response = self.client.get('/api/me/progress/')
        self.assertEqual(response.status_code, 403)
        self.assertEqual(response.json(), {'detail': 'Access denied.'})
        self.assertEqual(response['Cache-Control'], 'no-store')

    def test_public_privacy_page_still_available(self):
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        self.assertEqual(self.client.get(reverse('privacy')).status_code, 200)
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_reinstatement_does_not_reactivate_denied_session(self):
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        self.assertEqual(self.client.get(reverse('dashboard')).status_code, 403)
        self.assertTrue(self.client.session.get('rozh_revocation_seen'))
        Profile.objects.filter(user=self.user).update(suspended_at=None)
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response['Location'], reverse('login'))
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_unrevoked_account_not_blocked_by_global_guard(self):
        # Other onboarding/course gates may redirect, but this new guard must
        # not produce its explicit 403 for a normal active learner.
        response = self.client.get(reverse('dashboard'))
        self.assertNotEqual(response.status_code, 403)

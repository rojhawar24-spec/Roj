"""A learner's recall of a grammar quick check, separate from CEFR assessment."""
from django.conf import settings
from django.db import models


class GrammarMastery(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                             related_name='grammar_progress')
    topic = models.ForeignKey('academy.GrammarTopic', on_delete=models.CASCADE,
                              related_name='learner_progress')
    attempts = models.PositiveIntegerField(default=0)
    correct = models.PositiveIntegerField(default=0)
    successful_days = models.PositiveSmallIntegerField(default=0)
    last_correct_day = models.DateField(null=True, blank=True)
    reviewed_at = models.DateTimeField(null=True, blank=True)
    due_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['user', 'topic'], name='one_grammar_progress'),
            models.CheckConstraint(condition=models.Q(correct__lte=models.F('attempts')),
                                   name='grammar_correct_within_attempts'),
        ]
        indexes = [models.Index(fields=['user', 'due_at'], name='grammar_user_due_idx')]

    @property
    def status(self):
        if self.successful_days >= 3:
            return 'mastered'
        return 'practising' if self.attempts else 'new'

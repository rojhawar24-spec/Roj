"""Read-only, pure classification of publication issues for scored Learn & Play.

The activity type policy is about the scored core, NOT deleting authored
material. Existing old exercises are reported, never silently un-published.
Audio checks must be supplied from the real approved-audio gate by caller.
"""

from .curriculum_policy_v99 import AUTO_GRADED_LEER_SPEEL_KINDS


def classify_lesson_publication(lesson_skill, kinds, *, lesson_audio_ready=None,
                                listening_activity_audio_ready=None):
    """Return issue dicts; pure classification with fail-closed audio statuses."""
    issues = []
    kinds = tuple(kinds)
    unsupported = sorted({kind for kind in kinds if kind not in AUTO_GRADED_LEER_SPEEL_KINDS})
    if unsupported:
        issues.append({'severity': 'error', 'code': 'noncanonical-activity-type',
                       'detail': f'Outside five-kind scored path: {", ".join(unsupported)}.'})
    if not kinds:
        issues.append({'severity': 'error', 'code': 'ungraded-self-review',
                       'detail': 'Published lesson has no independently graded exercises.'})
    if lesson_skill == 'listening' and lesson_audio_ready is not True:
        issues.append({'severity': 'error', 'code': 'published-listening-missing-audio',
                       'detail': 'Published listening lesson requires an approved recording.'})
    if 'listening' in kinds and listening_activity_audio_ready is not True:
        issues.append({'severity': 'error', 'code': 'published-activity-missing-audio',
                       'detail': 'Published listening exercise requires an approved recording.'})
    return issues


def classify_unit_assessment(lesson_kind_groups):
    """Unit assessment supports the five validated activity kinds."""
    groups = list(lesson_kind_groups)
    if groups and not any(set(kinds) & set(AUTO_GRADED_LEER_SPEEL_KINDS) for kinds in groups):
        return [{'severity': 'error', 'code': 'unit-assessment-no-ready-question',
                 'detail': 'No ready canonical activity can power the required unit assessment.'}]
    return []

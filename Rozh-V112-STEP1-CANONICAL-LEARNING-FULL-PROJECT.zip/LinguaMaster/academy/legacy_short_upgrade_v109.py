"""Read-only exact matching of unchanged historical bounded starter questions."""
from .curriculum_policy_v99 import _source_course
from .starter_activity_v106 import starter_activity


def conversion_for(row, *, unique_order=True, has_revision=False):
    """Return a new canonical exercise payload or None. Never infer free text.

    All identity and original content fields must agree. The caller must check
    editorial history and duplicate order, and apply only in a maintenance window.
    """
    if (not unique_order or has_revision or row.kind != 'short'
            or row.content_version != 1):
        return None
    lesson = row.lesson
    unit = lesson.unit
    level = unit.level
    course = _source_course(level.language.code)
    if course is None or lesson.content_version != 1 or unit.content_version != 1:
        return None
    for source_unit in course['units']:
        if (source_unit['slug'], source_unit['level']) != (unit.slug, level.code):
            continue
        for order, source_lesson in enumerate(source_unit['lessons'], 1):
            if (lesson.slug, lesson.skill, lesson.title, lesson.content, lesson.audio_text, lesson.order) != (
                source_lesson['skill'], source_lesson['skill'], source_lesson['title'],
                source_lesson['content'], source_lesson['audio_text'], order):
                continue
            for position, source in enumerate(source_lesson.get('exercises', []), 1):
                if source['kind'] != 'short' or row.order != position:
                    continue
                expected = ('short', source['prompt'], source.get('options', []), source['answer'],
                            source['explanation'], source.get('activity_data', {}),
                            1 if level.code == 'A0' else 2)
                actual = (row.kind, row.prompt, row.options, row.answer, row.explanation,
                          row.activity_data, row.difficulty)
                if actual == expected:
                    converted = starter_activity(source)
                    return {'kind': converted['kind'], 'prompt': converted['prompt']}
    return None

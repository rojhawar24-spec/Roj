"""Django HTTP/ORM regression tests: NOT PASS until live Django runs."""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .models import Language, Level, Vocabulary, Profile, SkillPracticeAttempt
from .visual_models import PhotoAttempt


class PrivatePracticeV48HTTP(TestCase):
    def setUp(self):
        cache.clear()
        self.user = get_user_model().objects.create_user('v48-private-practice', password='SyntheticPassword48!')
        self.nl = Language.objects.create(code='nl', name='Dutch V48', slug='v48-nl', description='', is_published=True)
        self.fr = Language.objects.create(code='fr', name='French V48', slug='v48-fr', description='', is_published=True)
        self.level = Level.objects.create(language=self.nl, code='A0', order=0, description='Starter')
        self.word = Vocabulary.objects.create(level=self.level, word='boek', translation='book',
            example='Ik lees een boek op de trein.', published=True)
        Profile.objects.filter(user=self.user).update(preferred_language=self.nl,
            placement_completed=True, onboarding_required=True, onboarding_completed=True)
        self.client.force_login(self.user)
        self.listening_url = reverse('skill_practice', args=['listening'])
        self.photos_url = reverse('photo_practice')

    def listening_round(self):
        response = self.client.get(self.listening_url)
        self.assertEqual(response.status_code, 200)
        return response.context['target'].pk

    def photo_round(self):
        response = self.client.get(self.photos_url)
        self.assertEqual(response.status_code, 200)
        return response.context['round']

    def listening_submit(self):
        return self.client.post(self.listening_url, {'answer':self.word.example, 'source':'typed'})

    def photo_submit(self, nonce):
        return self.client.post(self.photos_url, {'round':nonce, 'answer':'koffie'})

    def test_active_learner_can_practice_without_xp(self):
        from .models import XPEvent
        self.listening_round()
        self.assertEqual(self.listening_submit().status_code, 200)
        self.assertEqual(SkillPracticeAttempt.objects.filter(user=self.user).count(), 1)
        nonce=self.photo_round()
        self.assertEqual(self.photo_submit(nonce).status_code,302)
        self.assertEqual(PhotoAttempt.objects.filter(user=self.user).count(), 1)
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_suspension_denies_both_gets_and_writes(self):
        self.listening_round(); nonce=self.photo_round()
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        for url in (self.listening_url, self.photos_url):
            self.assertEqual(self.client.get(url).status_code,403)
        self.assertEqual(self.listening_submit().status_code,403)
        self.assertEqual(self.photo_submit(nonce).status_code,403)
        self.assertFalse(SkillPracticeAttempt.objects.exists())
        self.assertFalse(PhotoAttempt.objects.exists())

    def test_account_review_denies_both(self):
        self.listening_round(); nonce=self.photo_round()
        Profile.objects.filter(user=self.user).update(legacy_review_required=True)
        self.assertEqual(self.listening_submit().status_code,403)
        self.assertEqual(self.photo_submit(nonce).status_code,403)
        self.assertFalse(SkillPracticeAttempt.objects.exists())
        self.assertFalse(PhotoAttempt.objects.exists())

    def test_missing_profile_denies_without_500(self):
        Profile.objects.filter(user=self.user).delete()
        self.assertEqual(self.client.get(self.listening_url).status_code,403)
        self.assertEqual(self.client.get(self.photos_url).status_code,403)
        self.assertFalse(SkillPracticeAttempt.objects.exists())
        self.assertFalse(PhotoAttempt.objects.exists())

    def test_stale_session_after_user_deactivation_denied(self):
        get_user_model().objects.filter(pk=self.user.pk).update(is_active=False)
        self.assertNotEqual(self.client.get(self.photos_url).status_code,200)
        self.assertNotEqual(self.client.get(self.listening_url).status_code,200)
        self.assertFalse(SkillPracticeAttempt.objects.exists())

    def test_unfinished_onboarding_denies_both(self):
        Profile.objects.filter(user=self.user).update(onboarding_completed=False)
        self.assertEqual(self.client.get(self.listening_url).status_code,403)
        self.assertEqual(self.client.get(self.photos_url).status_code,403)

    def test_revoked_placement_denies_both(self):
        Profile.objects.filter(user=self.user).update(placement_completed=False)
        self.assertEqual(self.client.get(self.listening_url).status_code,403)
        self.assertEqual(self.client.get(self.photos_url).status_code,403)

    def test_photo_old_round_rejected_after_course_switch(self):
        nonce=self.photo_round()
        Profile.objects.filter(user=self.user).update(preferred_language=self.fr)
        self.assertNotEqual(self.photo_submit(nonce).status_code,302)
        self.assertFalse(PhotoAttempt.objects.exists())

    def test_listening_old_round_rejected_after_course_switch(self):
        self.listening_round()
        Profile.objects.filter(user=self.user).update(preferred_language=self.fr)
        self.assertNotEqual(self.listening_submit().status_code,200)
        self.assertFalse(SkillPracticeAttempt.objects.exists())

    def test_unpublished_word_cannot_be_graded(self):
        self.listening_round()
        Vocabulary.objects.filter(pk=self.word.pk).update(published=False)
        self.assertNotEqual(self.listening_submit().status_code,200)
        self.assertFalse(SkillPracticeAttempt.objects.exists())

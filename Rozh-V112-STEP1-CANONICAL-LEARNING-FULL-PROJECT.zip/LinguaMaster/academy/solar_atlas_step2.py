"""Solar Atlas STEP 2: pure, read-only themes for existing published seasons.

Do not modify progress, publication, authorization, rewards or model rows here.
Managers' actual LearningSeason titles/descriptions always take precedence.
"""

SKINS = (
    ('dawn', 'soft', '☀', 'De eerste dageraad'),
    ('river', 'flow', '≋', 'De rivier van woorden'),
    ('sky', 'arc', '✦', 'De bibliotheek van de lucht'),
    ('grove', 'soft', '✿', 'De tuin van zinnen'),
    ('ember', 'flow', '◇', 'De warme avond'),
    ('violet', 'arc', '✧', 'De sterrenkaart'),
)


def skin(index):
    """Provide a visual theme, never invented content or an unlock state."""
    if not isinstance(index, int) or index < 0:
        raise ValueError('Season index must be non-negative')
    name, curve, symbol, sample_name = SKINS[index % len(SKINS)]
    return {'slug':name, 'curve':curve, 'symbol':symbol,
            'sample_name':sample_name, 'index':index + 1}


def decorate(seasons):
    """Add appearance-only metadata to existing trusted season dictionaries."""
    for i, stage in enumerate(seasons):
        stage['solar'] = skin(i)
    return seasons


COPY = {
    'nl': dict(tagline='Make words your world', status='De drie stappen van je leerroute',
       complete='Voltooid', current='Huidige stap', locked='Vergrendeld', available='Beschikbaar',
       season='Seizoen', back='Alle leeractiviteiten', path='Jouw route door de seizoenen',
       intro='Een nieuwe wereld begint met één woord. Ga verder waar je gebleven bent.',
       detail='Elke bocht is een echte les. Je voortgang komt uit je account.',
       head='Jouw volgende hoofdstuk', all='Bekijk je volledige leerpad',
       completed='Afgeronde lessen', progression='Cursusvoortgang',
       no_content='Er zijn nog geen gepubliceerde lessen voor deze cursus.'),
    'en': dict(tagline='Make words your world', status='Your path status guide',
       complete='Completed', current='Current step', locked='Locked', available='Available',
       season='Season', back='All learning tools', path='Your route through the seasons',
       intro='Every new world begins with one word. Continue where you left off.',
       detail='Every curve represents a real lesson. Progress is from your account.',
       head='Your next chapter', all='Explore your complete path',
       completed='Completed lessons', progression='Course progress',
       no_content='No published lessons are available for this course yet.'),
    'ckb': dict(tagline='Make words your world', status='ڕوونکردنەوەی دۆخی ڕێگاکەت',
       complete='تەواوبوو', current='هەنگاوی ئێستا', locked='داخراوە', available='بەردەستە',
       season='وەرز', back='هەموو ئامرازەکانی فێربوون', path='ڕێگاکەت لەنێو وەرزەکاندا',
       intro='هەر جیهانێکی نوێ بە وشەیەک دەست پێ دەکات. لەوێوە بەردەوام بە کە ماویت.',
       detail='هەر پێچێک وانەیەکی ڕاستەقینەیە. پێشکەوتنەکەت لە ئەکاونتەکەتەوەیە.',
       head='بەشی داهاتووت', all='هەموو ڕێگای فێربوونت ببینە',
       completed='وانە تەواوبووەکان', progression='پێشکەوتنی کۆرس',
       no_content='هێشتا هیچ وانەیەکی بڵاوکراوە بۆ ئەم کۆرسە نییە.'),
    'ar': dict(tagline='Make words your world', status='دليل حالات المسار',
       complete='مكتمل', current='خطوتك الحالية', locked='مغلق', available='متاح',
       season='موسم', back='كل أدوات التعلم', path='طريقك عبر المواسم',
       intro='كل عالم جديد يبدأ بكلمة واحدة. تابع من حيث توقفت.',
       detail='كل منعطف يمثل درسًا حقيقيًا. التقدم محفوظ في حسابك.',
       head='الفصل التالي', all='استكشف مسار تعلمك الكامل',
       completed='الدروس المكتملة', progression='تقدم الدورة',
       no_content='لا توجد دروس منشورة لهذه الدورة بعد.'),
}


def for_language(code):
    return COPY.get(code, COPY['en'])


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'solar_atlas_step2', ['COPY'])

"""V61 live Django HTTP/DB regression tests.

These tests are *not* verified by offline source inspection; they must run
with Django against the disposable test database, never a production DB.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Exercise, Language, Lesson, LessonProgress, Level, Profile, Unit, XPEvent


class ClassicLessonRoundBindingV61Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            username='v61-round-learner', password='SyntheticV61Pass!404')
        cls.language = Language.objects.create(
            code='en', name='English V61', slug='v61-english',
            description='Synthetic test language', is_published=True)
        cls.level = Level.objects.create(
            language=cls.language, code='A0', order=0, description='Starter')
        cls.unit = Unit.objects.create(
            level=cls.level, slug='v61-unit', title='V61 unit',
            summary='Synthetic test unit', published=True, order=1)
        cls.lesson = Lesson.objects.create(
            unit=cls.unit, slug='v61-lesson', title='V61 Lesson',
            skill='grammar', content='Synthetic test lesson', published=True)
        cls.exercise = Exercise.objects.create(
            lesson=cls.lesson, kind='mcq', prompt='Pick the greeting',
            options=['Hello', 'Bye'], answer='Hello',
            explanation='Hello is a greeting', difficulty=1)
        Profile.objects.filter(user=cls.user).update(
            preferred_language=cls.language, placement_completed=True,
            onboarding_required=False, onboarding_completed=True,
            suspended_at=None, legacy_review_required=False)

    def setUp(self):
        self.client.force_login(self.user)
        self.lesson_url = reverse('lesson', args=[self.lesson.pk])
        self.answer_url = reverse('lesson_answer', args=[self.lesson.pk])

    def opened_round(self):
        response = self.client.get(self.lesson_url)
        self.assertEqual(response.status_code, 200)
        return response.context['lesson_round_key']

    def assert_no_course_credit(self):
        self.assertFalse(LessonProgress.objects.filter(user=self.user, lesson=self.lesson).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user, reason='lesson').exists())

    def test_legacy_question_changed_after_open_rejected_by_ajax(self):
        round_key = self.opened_round()
        # A raw import can bypass Manager's explicit content_version bump.
        Exercise.objects.filter(pk=self.exercise.pk).update(
            prompt='Edited by manager', options=['Hello', 'Bye'], answer='Bye')
        response = self.client.post(self.answer_url, {
            'exercise_id': self.exercise.pk, 'answer': 'Hello',
            'round_key': round_key,
        })
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json().get('error_code'), 'stale_lesson')
        self.assert_no_course_credit()

    def test_legacy_explanation_changed_after_open_rejected_by_ssr(self):
        round_key = self.opened_round()
        Exercise.objects.filter(pk=self.exercise.pk).update(
            explanation='New explanation imported after lesson was opened')
        response = self.client.post(self.lesson_url, {
            'round_key': round_key, f'answer_{self.exercise.pk}': 'Hello',
        })
        self.assertEqual(response.status_code, 409)
        self.assert_no_course_credit()

    def test_extra_legacy_question_added_after_open_rejected(self):
        round_key = self.opened_round()
        Exercise.objects.create(lesson=self.lesson, kind='short',
            prompt='Added during old round?', options=[], answer='Yes',
            explanation='Synthetic example')
        response = self.client.post(self.answer_url, {
            'exercise_id': self.exercise.pk, 'answer': 'Hello',
            'round_key': round_key,
        })
        self.assertEqual(response.status_code, 409)
        self.assert_no_course_credit()

    def test_unchanged_bound_legacy_round_can_still_finish(self):
        round_key = self.opened_round()
        response = self.client.post(self.answer_url, {
            'exercise_id': self.exercise.pk, 'answer': 'Hello',
            'round_key': round_key,
        })
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()['correct'])
        self.assertTrue(LessonProgress.objects.filter(
            user=self.user, lesson=self.lesson).exists())

    def test_historical_direct_legacy_post_without_get_still_supported(self):
        # Do not break older MCQ-only integrations; structured V58 activities
        # still require a bound page signature.
        response = self.client.post(self.answer_url, {
            'exercise_id': self.exercise.pk, 'answer': 'Hello',
        })
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()['correct'])

    def test_lesson_instructions_changed_after_open_rejected_by_ajax_v107(self):
        round_key = self.opened_round()
        Lesson.objects.filter(pk=self.lesson.pk).update(content='Changed instructions')
        response = self.client.post(self.answer_url, {
            'exercise_id': self.exercise.pk, 'answer': 'Hello', 'round_key': round_key,
        })
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json().get('error_code'), 'stale_lesson')
        self.assert_no_course_credit()

    def test_approved_audio_changed_after_open_rejected_by_ssr_v107(self):
        from unittest.mock import patch
        Lesson.objects.filter(pk=self.lesson.pk).update(skill='listening', audio_text='Original recording')
        # Synthetic approval only: no claim of real audio playback.
        with patch('academy.audio_v78.approved_audio_url', return_value='/static/qa-only.wav'):
            round_key = self.opened_round()
            Lesson.objects.filter(pk=self.lesson.pk).update(audio_text='Replacement recording')
            response = self.client.post(self.lesson_url, {
                'round_key': round_key, f'answer_{self.exercise.pk}': 'Hello',
            })
        self.assertEqual(response.status_code, 409)
        self.assert_no_course_credit()

    def test_ssr_rechecks_approval_after_locked_admission_v107(self):
        from unittest.mock import patch
        Lesson.objects.filter(pk=self.lesson.pk).update(skill='listening', audio_text='Original recording')
        with patch('academy.audio_v78.approved_audio_url', return_value='/static/qa-only.wav'):
            round_key = self.opened_round()
        # Simulate approval being withdrawn between preflight and locked grading.
        with patch('academy.audio_v78.approved_audio_url', side_effect=['/static/qa-only.wav', '']):
            response = self.client.post(self.lesson_url, {
                'round_key': round_key, f'answer_{self.exercise.pk}': 'Hello',
            })
        self.assertEqual(response.status_code, 409)
        self.assert_no_course_credit()

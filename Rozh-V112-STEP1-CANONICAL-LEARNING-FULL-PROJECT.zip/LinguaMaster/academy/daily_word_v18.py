"""Word of the day: safe spelling check and one award per local calendar day.

No database calls here; the view is responsible for server-side authentication,
transactional XP awards, and published-course scope.
"""
import re
import unicodedata

DAILY_WORD_XP = 10
MAX_ANSWER_LENGTH = 200


def normalized_word(value):
    """Canonical Unicode and whitespace; preserve accents and meaningful casefolding."""
    return ' '.join(unicodedata.normalize('NFC', str(value or '')).split()).casefold()


def word_matches(value, target):
    if not isinstance(value, str) or len(value) > MAX_ANSWER_LENGTH:
        return False
    return bool(normalized_word(value)) and normalized_word(value) == normalized_word(target)


def daily_event_key(day):
    # Once per learner per local day ACROSS course switches, not per vocabulary id.
    return f'daily-word:{day.isoformat()}'


def daily_reward_access_allowed(profile, word_language_id):
    """Pure authorization gate for a *freshly fetched* Profile and chosen word.

    The caller must acquire the database Profile row lock and independently
    verify that the vocabulary item and selected course are still published.
    Legacy profiles without mandatory onboarding remain eligible after placement.
    """
    if (getattr(profile, 'onboarding_required', False)
            and not getattr(profile, 'onboarding_completed', False)):
        return False
    return bool(
        getattr(profile, 'placement_completed', False)
        and getattr(profile, 'preferred_language_id', None) is not None
        and profile.preferred_language_id == word_language_id
    )

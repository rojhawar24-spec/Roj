"""V47 Django HTTP integration checks; NOT PASS until Django runner executes."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .grammar_models import GrammarMastery
from .models import GrammarTopic, Language, Level, Profile


class SessionAndLearningAccessV47(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username='v47-learner', email='v47@example.invalid', password='SafeSyntheticPassword47!')
        self.language = Language.objects.create(code='nl', name='Dutch', slug='v47-dutch',
                                                description='', is_published=True)
        self.level = Level.objects.create(language=self.language, code='A0', order=0, description='Starter')
        self.topic = GrammarTopic.objects.create(
            level=self.level, slug='v47-sentence', title='Sentences', explanation='Sentence basics',
            examples=['Hello'], exceptions='', common_mistakes='',
            check_question='Choose Yes', check_options=['Yes', 'No'], check_answer='Yes', published=True)
        Profile.objects.filter(user=self.user).update(
            preferred_language=self.language, onboarding_required=False,
            onboarding_completed=True, placement_completed=True, ui_language='nl', xp=30)
        self.client.force_login(self.user)

    def test_active_learner_can_switch_to_sorani_without_losing_progress(self):
        response = self.client.post(reverse('switch_ui_language'), {'ui_language':'ckb'})
        self.assertEqual(response.status_code,302)
        profile=Profile.objects.get(user=self.user)
        self.assertEqual(profile.ui_language,'ckb')
        self.assertEqual(profile.preferred_language_id,self.language.pk)
        self.assertEqual(profile.xp,30)

    def test_missing_profile_public_home_revokes_session(self):
        Profile.objects.filter(user=self.user).delete()
        response=self.client.get(reverse('home'))
        self.assertEqual(response.status_code,200)
        self.assertNotIn('_auth_user_id',self.client.session)
        self.assertFalse(Profile.objects.filter(user=self.user).exists())

    def test_suspended_home_is_public_and_revokes_session(self):
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        response=self.client.get(reverse('home_ckb'))
        self.assertEqual(response.status_code,200)
        self.assertNotIn('_auth_user_id',self.client.session)
        self.assertNotContains(response, 'r27-student-frame')

    def test_missing_profile_private_routes_denied_not_500(self):
        Profile.objects.filter(user=self.user).delete()
        for name,args in (('unit',(999,)),('vocabulary',()),('arena',()),
                          ('grammar_library',()),('grammar',(self.topic.pk,)),('mistakes',())):
            with self.subTest(name=name):
                self.assertEqual(self.client.get(reverse(name,args=args)).status_code,403)

    def test_suspension_denies_private_gets(self):
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        for name,args in (('unit',(999,)),('vocabulary',()),('arena',()),
                          ('grammar_library',()),('grammar',(self.topic.pk,)),('mistakes',())):
            with self.subTest(name=name):
                self.assertEqual(self.client.get(reverse(name,args=args)).status_code,403)

    def test_suspended_interface_post_cannot_update_language(self):
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        response=self.client.post(reverse('switch_ui_language'), {'ui_language':'ar'})
        self.assertEqual(response.status_code,403)
        self.assertEqual(Profile.objects.get(user=self.user).ui_language,'nl')

    def test_quarantined_interface_post_cannot_update_language(self):
        Profile.objects.filter(user=self.user).update(legacy_review_required=True)
        response=self.client.post(reverse('switch_ui_language'), {'ui_language':'ckb'})
        self.assertEqual(response.status_code,403)
        self.assertEqual(Profile.objects.get(user=self.user).ui_language,'nl')

    def test_suspended_grammar_post_cannot_create_mastery(self):
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())
        response=self.client.post(reverse('grammar',args=[self.topic.pk]),{'answer':'Yes'})
        self.assertEqual(response.status_code,403)
        self.assertFalse(GrammarMastery.objects.filter(user=self.user,topic=self.topic).exists())

    def test_active_grammar_post_records_one_attempt(self):
        response=self.client.post(reverse('grammar',args=[self.topic.pk]),{'answer':'Yes'})
        self.assertEqual(response.status_code,302)
        progress=GrammarMastery.objects.get(user=self.user,topic=self.topic)
        self.assertEqual(progress.attempts,1)

    def test_revoked_course_cannot_get_or_post_grammar(self):
        Profile.objects.filter(user=self.user).update(preferred_language=None)
        get_response=self.client.get(reverse('grammar',args=[self.topic.pk]))
        self.assertIn(get_response.status_code,(403,404))
        response=self.client.post(reverse('grammar',args=[self.topic.pk]),{'answer':'Yes'})
        self.assertIn(response.status_code,(403,404))
        self.assertFalse(GrammarMastery.objects.filter(user=self.user,topic=self.topic).exists())

    def test_unpublished_topic_cannot_be_graded(self):
        GrammarTopic.objects.filter(pk=self.topic.pk).update(published=False)
        response=self.client.post(reverse('grammar',args=[self.topic.pk]),{'answer':'Yes'})
        self.assertIn(response.status_code,(403,404,409))
        self.assertFalse(GrammarMastery.objects.filter(user=self.user,topic=self.topic).exists())

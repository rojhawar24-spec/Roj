"""V44 integration tests. Must run on Django's isolated test database."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Language, Level, Unit, Lesson, LessonProgress, XPEvent

class V44DashboardIntegration(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user=get_user_model().objects.create_user('v44learner','v44@example.invalid','A-very-long-preview-passphrase!')
        cls.language=Language.objects.create(code='nl',slug='v44-dutch',name='Dutch',description='Dutch',is_published=True)
        cls.level=Level.objects.create(language=cls.language,code='A0',order=0,description='Starter')
        cls.unit=Unit.objects.create(level=cls.level,slug='v44-start',title='Verified first level',summary='Start',order=1,published=True)
        Lesson.objects.create(unit=cls.unit,slug='v44-lesson',title='Hello',skill='reading',content='Hallo',published=True)
        profile=cls.user.learning_profile
        profile.onboarding_completed=True
        profile.placement_completed=True
        profile.preferred_language=cls.language
        profile.save()

    def test_anonymous_private_and_uncached(self):
        response=self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code,302)
        self.assertIn('no-store',response.headers.get('Cache-Control',''))

    def test_genuine_route_no_mutation(self):
        self.client.force_login(self.user)
        response=self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'lm44-dashboard-page')
        self.assertContains(response,'lm44-quick-nav')
        self.assertContains(response,'Verified first level')
        self.assertContains(response,reverse('journey_play',args=[self.unit.pk]))
        self.assertFalse(LessonProgress.objects.filter(user=self.user).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_locked_not_linked(self):
        later=Unit.objects.create(level=self.level,slug='v44-later',title='Private locked stage',summary='Later',order=2,published=True)
        later.prerequisites.add(self.unit)
        Lesson.objects.create(unit=later,slug='v44-later-lesson',title='Later',skill='reading',content='Later',published=True)
        self.client.force_login(self.user)
        response=self.client.get(reverse('dashboard'))
        self.assertContains(response,'lm29-state-locked')
        self.assertNotContains(response,reverse('journey_play',args=[later.pk]))

    def test_four_languages(self):
        self.client.force_login(self.user)
        p=self.user.learning_profile
        for lang in ('nl','en','ckb','ar'):
            p.ui_language=lang
            p.save(update_fields=['ui_language'])
            response=self.client.get(reverse('dashboard'))
            self.assertEqual(response.status_code,200)
            self.assertContains(response,'lm44-quick-nav')
            self.assertContains(response,reverse('friends'))
            self.assertContains(response,reverse('leaderboard'))

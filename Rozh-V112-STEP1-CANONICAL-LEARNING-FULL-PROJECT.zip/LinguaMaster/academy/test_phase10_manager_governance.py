"""Phase 10 isolated Django integration cases: governance and publication audit.

These are real Django TestCase cases, not executed by source/AST validation.
Run only against Django's disposable test DB (settings_sandbox_v52).
"""
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.db.models.signals import post_save
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .manager_roles_v48 import MANAGER_GROUP
from .models import AuditEvent, Language, PlatformSettings


class ManagerSettingsGovernanceTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.owner = User.objects.create_superuser(
            username='p10-owner', email='p10-owner@example.invalid', password='TestOnly!p10owner'
        )
        self.manager = User.objects.create_user(
            username='p10-manager', email='p10-manager@example.invalid', password='TestOnly!p10manager'
        )
        self.learner = User.objects.create_user(
            username='p10-learner', email='p10-learner@example.invalid', password='TestOnly!p10learner'
        )
        Group.objects.get_or_create(name=MANAGER_GROUP)[0].user_set.add(self.manager)
        for user in (self.owner, self.manager):
            profile = user.learning_profile
            profile.email_verified_at = timezone.now()
            profile.totp_secret = 'JBSWY3DPEHPK3PXP'
            profile.save(update_fields=['email_verified_at', 'totp_secret'])
        self.config = PlatformSettings.load()
        self.config.ai_monthly_budget_eur = Decimal('27.00')
        self.config.organization_name = 'Rozh Example Operator'
        self.config.privacy_email = 'owner-privacy@example.invalid'
        self.config.public_registration_enabled = False
        self.config.save(update_fields=['ai_monthly_budget_eur','organization_name',
                                        'privacy_email','public_registration_enabled'])

    def act_as_manager(self, user):
        self.client.force_login(user)
        session = self.client.session
        session['mfa_verified_id'] = user.pk
        session.save()

    def test_delegated_manager_updates_only_ai_fields_not_owner_only_fields(self):
        self.act_as_manager(self.manager)
        observed = []
        def on_save(sender, instance, update_fields=None, **kwargs):
            if instance.pk == self.config.pk:
                observed.append(set(update_fields) if update_fields is not None else None)
        post_save.connect(on_save, sender=PlatformSettings, weak=False)
        try:
            response = self.client.post(reverse('manager'), {
                'ai_enabled': 'on',
                'ai_emergency_stop': '',
                'organization_name': 'Injected Unauthorised Name',
                'privacy_email': 'hijack@example.invalid',
                'public_registration_enabled': 'on',
                'ai_monthly_budget_eur': '9999.99',
            })
        finally:
            post_save.disconnect(on_save, sender=PlatformSettings)
        self.assertEqual(response.status_code, 302)
        self.config.refresh_from_db()
        self.assertTrue(self.config.ai_enabled)
        self.assertFalse(self.config.ai_emergency_stop)
        self.assertEqual(self.config.ai_monthly_budget_eur, Decimal('27.00'))
        self.assertEqual(self.config.organization_name, 'Rozh Example Operator')
        self.assertEqual(self.config.privacy_email, 'owner-privacy@example.invalid')
        self.assertFalse(self.config.public_registration_enabled)
        self.assertEqual(observed, [{'ai_enabled', 'ai_emergency_stop', 'updated_at'}])
        audit = AuditEvent.objects.get(action='platform_settings_updated', actor=self.manager)
        self.assertEqual(audit.metadata['changed_fields'], ['ai_emergency_stop', 'ai_enabled'])
        self.assertNotIn('hijack@example.invalid', str(audit.metadata))

    def test_invalid_manager_toggle_does_not_write_or_audit(self):
        self.act_as_manager(self.manager)
        self.config.ai_monthly_budget_eur = Decimal('0.00')
        self.config.save(update_fields=['ai_monthly_budget_eur'])
        response = self.client.post(reverse('manager'), {'ai_enabled': 'on'})
        self.assertEqual(response.status_code, 200)
        self.config.refresh_from_db()
        self.assertFalse(self.config.ai_enabled)
        self.assertFalse(AuditEvent.objects.filter(actor=self.manager,
                            action='platform_settings_updated').exists())

    def test_owner_can_update_operator_settings_and_audit_changed_fields(self):
        self.act_as_manager(self.owner)
        response = self.client.post(reverse('manager'), {
            'ai_enabled': '', 'ai_emergency_stop': 'on',
            'ai_daily_limit': '5', 'ai_monthly_limit': '50',
            'ai_monthly_budget_eur': '27.00',
            'ai_input_eur_per_million': '1.000',
            'ai_output_eur_per_million': '4.000',
            'ai_moderation_reserve_eur': '0.0020',
            'organization_name': 'Rozh New Operator',
            'privacy_email': 'new-privacy@example.invalid',
            'public_registration_enabled': 'on',
        })
        self.assertEqual(response.status_code, 302)
        self.config.refresh_from_db()
        self.assertEqual(self.config.organization_name, 'Rozh New Operator')
        self.assertEqual(self.config.privacy_email, 'new-privacy@example.invalid')
        self.assertTrue(self.config.public_registration_enabled)
        audit = AuditEvent.objects.get(actor=self.owner, action='platform_settings_updated')
        self.assertTrue({'organization_name','privacy_email','public_registration_enabled'}
                        .issubset(set(audit.metadata['changed_fields'])))
        self.assertNotIn('new-privacy@example.invalid', str(audit.metadata))

    def test_learner_denied_manager_config_change(self):
        self.client.force_login(self.learner)
        response = self.client.post(reverse('manager'), {
            'ai_enabled': 'on', 'ai_emergency_stop': '',
        })
        self.assertEqual(response.status_code, 403)
        self.config.refresh_from_db()
        self.assertFalse(self.config.ai_enabled)

    def test_content_publication_and_unpublication_have_separate_audit_events(self):
        self.act_as_manager(self.manager)
        add = reverse('manager_content_new', args=['language'])
        response = self.client.post(add, {
            'code': 'p10', 'slug': 'phase10-language', 'name': 'Phase 10',
            'description': 'Test language', 'is_published': 'on',
        })
        self.assertEqual(response.status_code, 302)
        language = Language.objects.get(code='p10')
        target = f'{language._meta.label}:{language.pk}'
        self.assertTrue(AuditEvent.objects.filter(
            actor=self.manager, action='manager_content_published', target=target).exists())
        response = self.client.post(reverse('manager_content_edit', args=['language',language.pk]), {
            'name': 'Phase 10', 'description': 'Test language',
        })
        self.assertEqual(response.status_code, 302)
        language.refresh_from_db()
        self.assertFalse(language.is_published)
        self.assertTrue(AuditEvent.objects.filter(
            actor=self.manager, action='manager_content_unpublished', target=target).exists())
        self.assertEqual(AuditEvent.objects.filter(
            actor=self.manager, action='manager_content_published', target=target).count(), 1)

    def test_manager_settings_get_is_read_only(self):
        self.act_as_manager(self.manager)
        previous = PlatformSettings.load().updated_at
        response = self.client.get(reverse('manager'))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(PlatformSettings.load().updated_at, previous)
        self.assertFalse(AuditEvent.objects.filter(action='platform_settings_updated').exists())

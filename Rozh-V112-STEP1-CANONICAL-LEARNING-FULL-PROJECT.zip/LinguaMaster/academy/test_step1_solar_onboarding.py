"""STEP 1 Django integration tests — executable on an isolated SQLite test database.
NOT RUN in this packaging environment: Django dependency unavailable; use Windows commands.
"""
import re
from unittest.mock import patch
from urllib.parse import urlsplit
from smtplib import SMTPException
from django.conf import settings
from django.contrib.auth import get_user_model
from django.core import mail
from django.core.cache import cache
from django.test import TestCase, Client, override_settings
from django.urls import reverse
from django.utils import timezone
from academy.email_verification_tokens import email_verification_token_generator
from academy.models import Language, OnboardingDraft, PlatformSettings
from academy.course_models import CourseEnrollment
from academy.models import LessonProgress

User = get_user_model()
MEMORY_MAILER = {'default': {'BACKEND': 'django.core.mail.backends.locmem.EmailBackend'}}

@override_settings(MAILERS=MEMORY_MAILER, SITE_URL='http://testserver')
class SolarStep1Tests(TestCase):
    PASS = 'Strong-Password-Example-2026!'

    def setUp(self):
        cache.clear()
        settings_obj = PlatformSettings.load()
        settings_obj.public_registration_enabled = True
        settings_obj.save(update_fields=['public_registration_enabled'])
        self.language = Language.objects.create(code='nl', name='Dutch', slug='step1-dutch',
                                                description='', is_published=True)

    def register(self, client=None, username='newlearner', email='new@example.test'):
        return (client or self.client).post(reverse('register'), {
            'username':username, 'email':email, 'password1':self.PASS,
            'age_confirmed':'on',
        })

    def test_off_mode_matches_immediate_signup_and_requires_new_onboarding(self):
        with override_settings(REQUIRE_EMAIL_VERIFICATION=False):
            response = self.register()
        user = User.objects.get(username='newlearner')
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response['Location'], reverse('onboarding'))
        self.assertTrue(user.is_active)
        self.assertTrue(user.learning_profile.onboarding_required)
        self.assertFalse(user.learning_profile.onboarding_completed)
        self.assertEqual(len(mail.outbox), 0)
        self.assertContains(self.client.get(reverse('onboarding')), 'Step 1 of 4')

    def test_on_mode_full_register_verify_login_onboard(self):
        with override_settings(REQUIRE_EMAIL_VERIFICATION=True):
            response = self.register()
            user = User.objects.get(username='newlearner')
            self.assertRedirects(response, reverse('registration_check_email'),
                                 fetch_redirect_response=False)
            self.assertFalse(user.is_active)
            self.assertTrue(user.learning_profile.onboarding_required)
            self.assertEqual(user.learning_profile.email_verification_version, 1)
            self.assertEqual(len(mail.outbox), 1)
            no_login = self.client.post(reverse('login'), {'email':user.email, 'password':self.PASS})
            self.assertNotIn('_auth_user_id', self.client.session)
            self.assertEqual(no_login.status_code, 200)
            verify_url = re.search(r'https?://[^\s]+/verify/[^\s]+',mail.outbox[0].body).group()
            path = urlsplit(verify_url).path
            self.assertEqual(self.client.get(path).status_code, 200)
            user.refresh_from_db(); self.assertFalse(user.is_active)  # GET must be inert
            self.assertRedirects(self.client.post(path), reverse('login'),
                                 fetch_redirect_response=False)
            user.refresh_from_db()
            self.assertTrue(user.is_active)
            self.assertIsNotNone(user.learning_profile.email_verified_at)
            signin = self.client.post(reverse('login'),{'email':user.email,'password':self.PASS})
            self.assertRedirects(signin, reverse('onboarding'), fetch_redirect_response=False)
            self.assertContains(self.client.get(reverse('onboarding')), 'Step 1 of 4')
            for step, choice in ((1,'ckb'),(2,str(self.language.pk)),(3,'beginner'),(4,'35')):
                r=self.client.post(reverse('onboarding'),{'step':step,'choice':choice})
                self.assertEqual(r.status_code,302)
            user.learning_profile.refresh_from_db()
            self.assertTrue(user.learning_profile.onboarding_completed)
            self.assertFalse(user.learning_profile.onboarding_required)
            self.assertEqual(user.learning_profile.daily_goal_xp,35)
            self.assertEqual(user.learning_profile.ui_language,'ckb')
            self.assertFalse(OnboardingDraft.objects.filter(user=user).exists())
            self.assertRedirects(self.client.get(reverse('onboarding')), reverse('play_hub'),
                                 fetch_redirect_response=False)

    def test_required_mode_transport_failure_keeps_pending_account_and_resend(self):
        with override_settings(REQUIRE_EMAIL_VERIFICATION=True):
            with patch('academy.views.send_mail', side_effect=SMTPException('offline')):
                response=self.register()
            self.assertRedirects(response,reverse('registration_check_email'),
                                 fetch_redirect_response=False)
            account=User.objects.get(username='newlearner')
            self.assertFalse(account.is_active)
            self.assertIsNone(account.learning_profile.email_verified_at)
            self.assertNotIn('_auth_user_id',self.client.session)
            # Clear recovery path exists; transport outcome is not publicly tied to identifier.
            self.assertContains(self.client.get(reverse('registration_check_email')), 'Resend')
            self.client.post(reverse('resend_verification'),{'email':account.email})
            self.assertEqual(len(mail.outbox),1)

    def test_required_mode_does_not_enumerate_duplicate_identifiers(self):
        with override_settings(REQUIRE_EMAIL_VERIFICATION=True):
            self.register()
            self.client.logout()
            r=self.register(username='anothernew',email='new@example.test')
            self.assertRedirects(r,reverse('registration_check_email'),fetch_redirect_response=False)
            self.assertFalse(User.objects.filter(username='anothernew').exists())
            self.assertNotIn('_auth_user_id',self.client.session)
            # Same public response regardless of new versus duplicate.
            self.assertNotIn('already registered',r.content.decode().lower())

    def test_existing_users_even_without_progress_never_forced(self):
        existing=User.objects.create_user('old_zero','old0@example.test',self.PASS)
        manager=User.objects.create_user('old_manager','manager@example.test',self.PASS,is_staff=True)
        owner=User.objects.create_superuser('old_owner','owner@example.test',self.PASS)
        demo=User.objects.create_user('old_demo','demo@example.test',self.PASS)
        for u in (existing,manager,owner,demo):
            state=u.learning_profile
            self.assertFalse(state.onboarding_required)
            self.assertFalse(state.onboarding_completed)
            client=Client();client.force_login(u)
            response=client.get(reverse('onboarding'))
            self.assertNotEqual(response.status_code,200)
            self.assertNotIn('onboarding',response.get('Location',''))
        client=Client();client.force_login(existing)
        self.assertRedirects(client.get('/'),'/courses/',fetch_redirect_response=False)

    def test_new_device_resumes_server_side_draft(self):
        with override_settings(REQUIRE_EMAIL_VERIFICATION=False):
            self.register()
        self.client.post(reverse('onboarding'),{'step':1,'choice':'ckb'})
        self.client.post(reverse('onboarding'),{'step':2,'choice':str(self.language.pk)})
        user=User.objects.get(username='newlearner')
        self.assertEqual(OnboardingDraft.objects.get(user=user).step,3)
        second=Client();second.force_login(user)
        self.assertContains(second.get(reverse('onboarding')), 'هەنگاوی 3 لە ٤')
        self.assertContains(second.get(reverse('onboarding')), 'dir="rtl"')

    def test_course_switch_cannot_bypass_new_onboarding(self):
        with override_settings(REQUIRE_EMAIL_VERIFICATION=False):
            self.register()
        response=self.client.post('/courses/nl/switch/',{'start':'A0'})
        self.assertRedirects(response, reverse('onboarding'),fetch_redirect_response=False)
        user=User.objects.get(username='newlearner')
        self.assertFalse(user.learning_profile.onboarding_completed)

    def test_goal_options_remain_10_20_35_50_and_invalid_is_rejected(self):
        with override_settings(REQUIRE_EMAIL_VERIFICATION=False):
            self.register()
        self.client.post(reverse('onboarding'),{'step':1,'choice':'en'})
        self.client.post(reverse('onboarding'),{'step':2,'choice':str(self.language.pk)})
        self.client.post(reverse('onboarding'),{'step':3,'choice':'beginner'})
        resp=self.client.get(reverse('onboarding'))
        for value in ('10','20','35','50'):
            self.assertContains(resp, f'value="{value}"')
        invalid=self.client.post(reverse('onboarding'),{'step':4,'choice':'999'})
        self.assertEqual(invalid.status_code,200)
        self.assertFalse(User.objects.get(username='newlearner').learning_profile.onboarding_completed)

    def test_keyboard_semantics_and_local_assets(self):
        with override_settings(REQUIRE_EMAIL_VERIFICATION=False):
            self.register()
        html=self.client.get(reverse('onboarding')).content.decode()
        self.assertIn('id="r52-progress"',html)
        self.assertIn('aria-valuetext=',html)
        self.assertIn('type="radio"',html)
        self.assertIn('href="#main"',html)
        self.assertIn('onboarding-solar-v1.css',html)
        self.assertNotIn('fonts.googleapis.com',html)
        self.assertNotIn('fonts.gstatic.com',html)

"""Only ephemeral AI tutor session state; no persisted learning data is touched."""


def clear_ai_history(request):
    """Clear both the bounded dialogue and its course/language binding."""
    request.session.pop('ai_v9_history', None)
    request.session.pop('ai_v9_course', None)

"""STEP 6 real Django integration tests. NEVER mark passed until actually run.
Requires full dependencies and isolated Django test database; not production.
"""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase, override_settings
from django.urls import reverse
from academy.models import PlatformSettings

User=get_user_model()

@override_settings(MAILERS={'default':{'BACKEND':'django.core.mail.backends.locmem.EmailBackend'}})
class SolarAtlasStep6AuthTests(TestCase):
    PASSWORD='LongPass-Valid-Step6!2026'
    def setUp(self):
        cache.clear()
        self.user=User.objects.create_user('step6reader','step6reader@example.test',self.PASSWORD)
        prof=self.user.learning_profile
        prof.onboarding_required=False
        prof.onboarding_completed=False
        prof.placement_completed=True
        prof.save(update_fields=['onboarding_required','onboarding_completed','placement_completed'])

    def test_locale_css_post_and_noindex(self):
        for code in ('nl','en','ckb','ar'):
            with self.subTest(locale=code):
                r=self.client.get(reverse('login'),{'ui':code,'next':'/play/'})
                self.assertEqual(r.status_code,200)
                self.assertContains(r,'solar-atlas-step6-auth.css')
                self.assertContains(r,'name="next" value="/play/"')
                self.assertContains(r,'name="csrfmiddlewaretoken"')
                self.assertContains(r,f'lang="{code}"')
                self.assertContains(r,'sa6-dawnline')
                self.assertContains(r,'noindex,nofollow')
                self.assertIn('no-store',r['Cache-Control'])
                self.assertContains(r, 'dir="rtl"' if code in ('ckb','ar') else 'dir="ltr"')

    def test_registration_ui_keeps_age_confirmation_and_localizes_policy(self):
        for email_required in (False,True):
            with self.subTest(email_required=email_required),self.settings(REQUIRE_EMAIL_VERIFICATION=email_required):
                r=self.client.get(reverse('register'),{'ui':'nl'})
                self.assertEqual(r.status_code,200)
                self.assertContains(r,'name="age_confirmed"')
                self.assertContains(r,'solar-atlas-step6-auth.css')
                text=r.content.decode()
                if email_required:self.assertIn('Verifieer het adres voordat je kunt inloggen.',text)
                else:self.assertIn('Je kunt meteen leren.',text)

    def test_invalid_next_cannot_leak_or_redirect_offsite(self):
        for destination in ('//evil.test/','https://evil.test/','/login/','/mfa/verify/'):
            with self.subTest(destination=destination):
                r=self.client.get(reverse('login'),{'next':destination})
                self.assertEqual(r.status_code,200)
                self.assertNotContains(r,'name="next" value="'+destination+'"')

    def test_login_failure_generic_and_accessible(self):
        for email in (self.user.email,'not-present-step6@example.test'):
            cache.clear()
            r=self.client.post(reverse('login'),{'email':email,'password':'Wrong-Pass'})
            self.assertEqual(r.status_code,200)
            self.assertContains(r,'role="alert"')
            self.assertContains(r,'data-auth-error-summary')
            self.assertNotIn('_auth_user_id',self.client.session)

    def test_existing_user_can_login_without_onboarding(self):
        r=self.client.post(reverse('login'),{'email':self.user.email,'password':self.PASSWORD})
        self.assertEqual(r.status_code,302)
        self.assertNotIn('/onboarding/',r['Location'])

    def test_password_reset_and_resend_are_real_forms(self):
        for route in ('password_reset','resend_verification'):
            with self.subTest(route=route):
                r=self.client.get(reverse(route),{'ui':'ckb'})
                self.assertEqual(r.status_code,200)
                self.assertContains(r,'name="csrfmiddlewaretoken"')
                self.assertContains(r,'solar-atlas-step6-auth.css')
                self.assertContains(r,'name="email"')
                self.assertContains(r,'lang="ckb"')

    def test_mfa_code_form_not_bypassed_by_new_skin(self):
        # A direct MFA endpoint must never mark an anonymous user as verified.
        r=self.client.get(reverse('mfa_verify'))
        self.assertIn(r.status_code,(302,403))
        self.assertNotIn('mfa_verified_id',self.client.session)

    def test_register_non_enumeration_setting_enabled(self):
        site=PlatformSettings.load();site.public_registration_enabled=True
        site.save(update_fields=['public_registration_enabled'])
        with self.settings(REQUIRE_EMAIL_VERIFICATION=True):
            a=self.client.post(reverse('register'),{'username':'step6new','email':'step6new@example.test','password1':self.PASSWORD,'password2':self.PASSWORD,'age_confirmed':'on'})
            self.assertEqual(a.status_code,302)
            new=User.objects.get(username='step6new')
            self.assertFalse(new.is_active)
            self.assertTrue(new.learning_profile.onboarding_required)
            self.assertEqual(a['Location'],reverse('registration_check_email'))
            self.client.logout()
            b=self.client.post(reverse('register'),{'username':'step6new','email':'step6new@example.test','password1':self.PASSWORD,'password2':self.PASSWORD,'age_confirmed':'on'})
            self.assertEqual(b.status_code,302)
            self.assertEqual(b['Location'],a['Location'])
            self.assertFalse(new.is_active)

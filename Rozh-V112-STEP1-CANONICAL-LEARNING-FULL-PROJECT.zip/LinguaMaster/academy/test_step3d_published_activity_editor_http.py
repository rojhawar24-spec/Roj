"""Step 3D Django ORM/HTTP QA only. NOT executable without a Django runtime.

Do not run against live user data; use isolated settings_local_qa test database.
"""
from django.contrib.auth import get_user_model
from django.forms.models import model_to_dict
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .admin import V58ExerciseForm, V58LessonForm
from .models import Language, Level, Unit, Lesson, Exercise, Profile


class PublishedActivityEditorHttpTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.owner=get_user_model().objects.create_superuser(
            username='step3d-owner', email='step3d-owner@example.invalid', password='QAOnly-StrongPassphrase-3D!')
        Profile.objects.filter(user=cls.owner).update(email_verified_at=timezone.now(),
            totp_secret='JBSWY3DPEHPK3PXP')
        language=Language.objects.create(code='nl',slug='step3d-dutch',name='QA Dutch',
                                         description='Isolated QA',is_published=True)
        level=Level.objects.create(language=language,code='A0',description='QA')
        unit=Unit.objects.create(level=level,slug='step3d-unit',title='QA',
                                 summary='Isolated QA',published=True)
        cls.lesson=Lesson.objects.create(unit=unit,slug='step3d-lesson',title='QA lesson',
            skill='grammar',content='Teaching content',published=False)
        cls.bad=Exercise.objects.create(lesson=cls.lesson,kind='word_matching',
            prompt='Match each word',options=[],answer='',explanation='Match meanings',activity_data={})

    def test_manager_cannot_publish_incomplete_matching_lesson(self):
        self.client.force_login(self.owner)
        session=self.client.session
        session['mfa_verified_id']=self.owner.pk
        session.save()
        url=reverse('manager_content_edit',args=['lesson',self.lesson.pk])
        response=self.client.post(url,{
            'title':self.lesson.title, 'skill':'grammar', 'content':'Teaching content',
            'audio_text':'','order':'0','published':'on'})
        self.assertEqual(response.status_code,200)
        self.lesson.refresh_from_db()
        self.assertFalse(self.lesson.published)
        self.assertContains(response,'Fix the authored exercises before publishing')

    def test_django_admin_form_also_blocks_incomplete_lesson(self):
        data=model_to_dict(self.lesson)
        data.update(published=True)
        form=V58LessonForm(data=data,instance=self.lesson)
        self.assertFalse(form.is_valid())
        self.assertIn('published',form.errors)

    def test_after_repair_admin_can_publish_lesson(self):
        self.bad.activity_data={'pairs':[{'left':'cat','right':'animal'},
                                        {'left':'red','right':'colour'}]}
        self.bad.save(update_fields=['activity_data'])
        data=model_to_dict(self.lesson)
        data.update(published=True)
        form=V58LessonForm(data=data,instance=self.lesson)
        self.assertTrue(form.is_valid(),form.errors)

    def test_admin_rejects_mcq_without_valid_answer_key(self):
        data=dict(lesson=self.lesson.pk,kind='mcq',prompt='Choose one',
                  options='["is", "are"]',answer='not-present',activity_data='{}',
                  explanation='Review the sentence',difficulty=2,order=0,content_version=1)
        form=V58ExerciseForm(data=data)
        self.assertFalse(form.is_valid())
        self.assertIn('The correct answer is missing',str(form.errors))

"""Heart timer, idempotency, recovery and real lesson request regressions."""
from datetime import datetime, timedelta, timezone as utc_timezone
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.db import connection
from django.test import TestCase
from django.test.utils import CaptureQueriesContext
from django.urls import reverse
from django.utils import timezone

from .heart_models import HeartBalance, HeartEvent
from .hearts import HeartEmpty, recover_for_mistake, snapshot, spend_for_answer
from .models import Exercise, Language, Lesson, LessonProgress, Level, MistakeRecord, Profile, Unit, XPEvent
from .ui import HEART_TEXT


class HeartTimerV10Tests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user('heart-timer')
        self.now = datetime(2026, 11, 7, 12, tzinfo=utc_timezone.utc)

    def state_at(self, now=None):
        with patch('academy.hearts.timezone.now', return_value=now or self.now):
            return snapshot(self.user)

    def test_legacy_user_is_initialized_with_five_and_full_read_does_not_update(self):
        state = self.state_at()
        self.assertEqual(state['remaining'], 5)
        self.assertEqual(state['next_in_seconds'], 0)
        self.assertIsNone(state['next_at'])
        self.assertEqual(HeartBalance.objects.filter(user=self.user).count(), 1)
        with CaptureQueriesContext(connection) as captured:
            self.state_at(self.now + timedelta(hours=1))
        self.assertFalse(any(query['sql'].lstrip().upper().startswith('UPDATE') for query in captured.captured_queries))

    def test_spend_starts_timer_and_replay_never_spends_again(self):
        with patch('academy.hearts.timezone.now', return_value=self.now):
            first = spend_for_answer(self.user, 'round:1:question:1')
            repeated = spend_for_answer(self.user, 'round:1:question:1')
        self.assertEqual(first['remaining'], 4)
        self.assertTrue(first['spent'])
        self.assertFalse(repeated['spent'])
        self.assertEqual(repeated['remaining'], 4)
        self.assertEqual(first['next_in_seconds'], 1800)
        self.assertEqual(HeartEvent.objects.filter(user=self.user).count(), 1)

    def test_partial_intervals_are_preserved_and_regeneration_caps_at_five(self):
        HeartBalance.objects.create(user=self.user, remaining=1, regenerated_at=self.now - timedelta(minutes=75))
        state = self.state_at()
        self.assertEqual(state['remaining'], 3)
        self.assertEqual(state['next_in_seconds'], 15 * 60)
        self.assertEqual(self.state_at(self.now + timedelta(minutes=15))['remaining'], 4)
        self.assertEqual(self.state_at(self.now + timedelta(days=10))['remaining'], 5)

    def test_new_debit_at_capacity_does_not_use_old_idle_timer(self):
        HeartBalance.objects.create(user=self.user, remaining=5, regenerated_at=self.now - timedelta(days=10))
        with patch('academy.hearts.timezone.now', return_value=self.now):
            state = spend_for_answer(self.user, 'fresh-debit')
        self.assertEqual(state['remaining'], 4)
        self.assertEqual(state['next_in_seconds'], 1800)
        self.assertEqual(self.state_at(self.now + timedelta(minutes=29, seconds=59))['remaining'], 4)
        self.assertEqual(self.state_at(self.now + timedelta(minutes=30))['remaining'], 5)

    def test_empty_balance_rejects_new_debit_and_replay_is_safe_at_zero(self):
        HeartBalance.objects.create(user=self.user, remaining=1, regenerated_at=self.now)
        with patch('academy.hearts.timezone.now', return_value=self.now):
            self.assertEqual(spend_for_answer(self.user, 'last')['remaining'], 0)
            self.assertFalse(spend_for_answer(self.user, 'last')['spent'])
            with self.assertRaises(HeartEmpty) as raised:
                spend_for_answer(self.user, 'new')
        self.assertEqual(raised.exception.state['remaining'], 0)
        self.assertEqual(raised.exception.state['next_in_seconds'], 1800)
        self.assertEqual(HeartEvent.objects.count(), 1)

    def test_future_clock_anchor_recovers_without_unbounded_wait(self):
        HeartBalance.objects.create(user=self.user, remaining=0, regenerated_at=self.now + timedelta(days=20))
        state = self.state_at()
        self.assertEqual(state['remaining'], 0)
        self.assertEqual(state['next_in_seconds'], 1800)
        self.assertEqual(self.state_at(self.now + timedelta(minutes=30))['remaining'], 1)

    def test_event_keys_are_user_scoped(self):
        other = get_user_model().objects.create_user('other-heart-timer')
        with patch('academy.hearts.timezone.now', return_value=self.now):
            self.assertTrue(spend_for_answer(self.user, 'same')['spent'])
            self.assertTrue(spend_for_answer(other, 'same')['spent'])
        self.assertEqual(HeartEvent.objects.count(), 2)

    def test_translations_have_parity(self):
        keys = set(HEART_TEXT['en'])
        for locale in ('nl', 'ckb', 'ar'):
            self.assertEqual(set(HEART_TEXT[locale]), keys)
            self.assertTrue(all(HEART_TEXT[locale].values()))


class HeartLessonV10Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user('heart-learner', 'hearts@example.org', 'StrongPassword!2026')
        cls.language = Language.objects.create(code='nl', name='Dutch', slug='dutch-hearts', description='Dutch', is_published=True)
        cls.level = Level.objects.create(language=cls.language, code='A0', description='Start')
        cls.unit = Unit.objects.create(level=cls.level, slug='heart-start', title='Start', summary='Start', published=True)
        cls.lesson = Lesson.objects.create(unit=cls.unit, slug='heart-lesson', title='Heart lesson', skill='grammar', content='A readable lesson.', published=True)
        cls.a = Exercise.objects.create(lesson=cls.lesson, kind='mcq', prompt='Hello?', options=['Hoi', 'Nee'], answer='Hoi', explanation='Hoi is a greeting.')
        cls.b = Exercise.objects.create(lesson=cls.lesson, kind='mcq', prompt='No?', options=['Nee', 'Hoi'], answer='Nee', explanation='Nee means no.')
        cls.short_lesson = Lesson.objects.create(unit=cls.unit, slug='heart-short', title='Short answer', skill='writing', content='Write hello.', published=True)
        cls.short = Exercise.objects.create(lesson=cls.short_lesson, kind='fill_blank', prompt='___ means hello.', answer='Hallo', explanation='Hallo is a greeting.')
        cls.self_lesson = Lesson.objects.create(unit=cls.unit, slug='heart-self', title='Self review', skill='speaking', content='Practice aloud.', published=True)
        profile = cls.user.learning_profile
        profile.preferred_language = cls.language
        profile.placement_completed = True
        profile.onboarding_completed = True
        profile.save()

    def setUp(self):
        cache.clear()
        self.client.force_login(self.user)

    def begin(self, lesson=None):
        lesson = lesson or self.lesson
        response = self.client.get(lesson.get_absolute_url())
        self.assertEqual(response.status_code, 200)
        return response.context['lesson_round_key']

    def answer(self, exercise, answer, token=None):
        data = {'exercise_id': exercise.pk, 'answer': answer}
        if token:
            data['round_key'] = token
        return self.client.post(reverse('lesson_answer', args=[exercise.lesson_id]), data)

    def empty(self):
        HeartBalance.objects.update_or_create(user=self.user, defaults={'remaining': 0, 'regenerated_at': timezone.now()})

    def test_wrong_question_spends_once_and_duplicate_does_not_repeat_mistake(self):
        token = self.begin()
        result = self.answer(self.a, 'Nee', token)
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.json()['hearts']['remaining'], 4)
        repeated = self.answer(self.a, 'Nee', token)
        self.assertEqual(repeated.status_code, 409)
        self.assertEqual(snapshot(self.user)['remaining'], 4)
        self.assertEqual(MistakeRecord.objects.get(user=self.user, exercise=self.a).wrong_count, 1)
        self.assertEqual(HeartEvent.objects.filter(kind='answer').count(), 1)

    def test_terminal_wrong_replay_is_safe_and_new_get_creates_a_new_round(self):
        token = self.begin(self.short_lesson)
        self.assertEqual(self.answer(self.short, 'Wrong', token).json()['hearts']['remaining'], 4)
        self.assertEqual(self.answer(self.short, 'Wrong', token).status_code, 409)
        self.assertEqual(snapshot(self.user)['remaining'], 4)
        token2 = self.begin(self.short_lesson)
        self.assertNotEqual(token2, token)
        self.assertEqual(self.answer(self.short, 'Wrong', token2).json()['hearts']['remaining'], 3)

    def test_correct_answer_preserves_hearts_and_server_completion(self):
        token = self.begin(self.short_lesson)
        result = self.answer(self.short, '  HALLO  ', token)
        self.assertEqual(result.status_code, 200)
        self.assertTrue(result.json()['completed'])
        self.assertEqual(result.json()['xp_awarded'], 20)
        self.assertEqual(result.json()['hearts']['remaining'], 5)
        self.assertEqual(HeartEvent.objects.count(), 0)

    def test_zero_blocks_correct_or_wrong_graded_answers_but_lesson_stays_readable(self):
        self.empty()
        response = self.client.get(self.short_lesson.get_absolute_url())
        self.assertContains(response, 'Write hello.')
        token = response.context['lesson_round_key']
        for answer in ('Hallo', 'Wrong'):
            result = self.answer(self.short, answer, token)
            self.assertEqual(result.status_code, 402)
            self.assertEqual(result.json()['error_code'], 'hearts_empty')
            self.assertEqual(result.json()['hearts']['remaining'], 0)
        self.assertFalse(LessonProgress.objects.filter(user=self.user).exists())
        self.assertEqual(XPEvent.objects.count(), 0)
        self.assertEqual(HeartEvent.objects.count(), 0)

    def test_zero_does_not_enable_ungraded_lesson_or_block_grammar_review_or_mistake_pages(self):
        self.empty()
        response = self.client.post(self.self_lesson.get_absolute_url(), {'self_check': 'yes'})
        self.assertEqual(response.status_code, 409)
        self.assertFalse(LessonProgress.objects.filter(user=self.user, lesson=self.self_lesson).exists())
        for url in ('/grammar/', '/mistakes/', '/hearts/'):
            self.assertEqual(self.client.get(url).status_code, 200, url)
        self.assertEqual(HeartEvent.objects.count(), 0)

    def test_forged_empty_and_stale_requests_do_not_consume_hearts(self):
        token = self.begin()
        self.assertEqual(self.answer(self.a, 'Not an option', token).status_code, 400)
        self.assertEqual(self.answer(self.a, '', token).status_code, 400)
        self.assertEqual(self.answer(self.a, 'Nee', '0' * 32).status_code, 409)
        result = self.client.post(reverse('lesson_answer', args=[self.lesson.pk]), {'exercise_id': self.short.pk, 'answer': 'Wrong', 'round_key': token})
        self.assertEqual(result.status_code, 404)
        self.assertEqual(snapshot(self.user)['remaining'], 5)
        self.assertEqual(MistakeRecord.objects.count(), 0)
        self.assertEqual(HeartEvent.objects.count(), 0)

    def test_ssr_batch_is_validated_before_any_heart_or_mistake_write(self):
        token = self.begin()
        result = self.client.post(self.lesson.get_absolute_url(), {'round_key': token, f'answer_{self.a.pk}': 'Nee', f'answer_{self.b.pk}': 'Forged'})
        self.assertEqual(result.status_code, 400)
        self.assertEqual(snapshot(self.user)['remaining'], 5)
        self.assertEqual(MistakeRecord.objects.count(), 0)
        self.assertEqual(HeartEvent.objects.count(), 0)

    def test_ssr_wrong_answer_and_replay_use_same_one_time_ledger(self):
        token = self.begin()
        payload = {'round_key': token, f'answer_{self.a.pk}': 'Nee', f'answer_{self.b.pk}': 'Nee'}
        self.assertEqual(self.client.post(self.lesson.get_absolute_url(), payload).status_code, 200)
        self.assertEqual(self.client.post(self.lesson.get_absolute_url(), payload).status_code, 200)
        self.assertEqual(snapshot(self.user)['remaining'], 4)
        self.assertEqual(HeartEvent.objects.filter(kind='answer').count(), 1)
        self.assertEqual(MistakeRecord.objects.get(user=self.user, exercise=self.a).wrong_count, 1)

    def test_ssr_zero_blocks_assessed_submission_without_granting_progress(self):
        self.empty()
        token = self.begin(self.short_lesson)
        result = self.client.post(self.short_lesson.get_absolute_url(), {'round_key': token, f'answer_{self.short.pk}': 'Hallo'})
        self.assertEqual(result.status_code, 402)
        self.assertFalse(LessonProgress.objects.filter(user=self.user).exists())

    def test_corrected_mistake_recovers_once_even_after_reopened(self):
        from django.utils import timezone
        HeartBalance.objects.create(user=self.user, remaining=2, regenerated_at=timezone.now())
        mistake = MistakeRecord.objects.create(user=self.user, exercise=self.a, corrected_at=timezone.now())
        self.assertTrue(recover_for_mistake(self.user, mistake)['recovered'])
        self.assertEqual(snapshot(self.user)['remaining'], 3)
        MistakeRecord.objects.filter(pk=mistake.pk).update(corrected_at=None)
        MistakeRecord.objects.filter(pk=mistake.pk).update(corrected_at=timezone.now())
        self.assertFalse(recover_for_mistake(self.user, mistake)['recovered'])
        self.assertEqual(snapshot(self.user)['remaining'], 3)

    def test_recovery_requires_owned_corrected_mistake_and_full_balance_consumes_eligibility(self):
        from django.utils import timezone
        other = get_user_model().objects.create_user('other-heart-user')
        foreign = MistakeRecord.objects.create(user=other, exercise=self.a, corrected_at=timezone.now())
        unresolved = MistakeRecord.objects.create(user=self.user, exercise=self.b)
        with self.assertRaises(ValueError):
            recover_for_mistake(self.user, foreign)
        with self.assertRaises(ValueError):
            recover_for_mistake(self.user, unresolved)
        fixed = MistakeRecord.objects.create(user=self.user, exercise=self.a, corrected_at=timezone.now())
        self.assertFalse(recover_for_mistake(self.user, fixed)['recovered'])
        spend_for_answer(self.user, 'later-question')
        self.assertFalse(recover_for_mistake(self.user, fixed)['recovered'])
        self.assertEqual(snapshot(self.user)['remaining'], 4)
        self.assertEqual(HeartEvent.objects.get(user=self.user, key=f'mistake:{fixed.pk}').delta, 0)

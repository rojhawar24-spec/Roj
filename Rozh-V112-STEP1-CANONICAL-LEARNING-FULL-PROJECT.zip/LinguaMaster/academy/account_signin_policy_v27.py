"""Shared fail-closed admission check for password login and MFA lifecycle.

This intentionally does NOT require verified email for ordinary local learners
when REQUIRE_EMAIL_VERIFICATION=False. It blocks account quarantine and
suspension independently of Django User.is_active, including inconsistent
legacy imports or a partially completed administration operation.
"""


def account_signin_permitted(user, profile):
    return bool(
        user is not None
        and getattr(user, 'is_active', False)
        and profile is not None
        and getattr(profile, 'suspended_at', None) is None
        and not getattr(profile, 'legacy_review_required', False)
    )

from django.conf import settings
from .studio_v15 import get_labels
from .design_v16 import for_request
from .design_v17 import for_request as desktop_labels
from .services import learning_level
from .interface_v45 import for_language as v45_labels
from .safe_profile_context_v46 import visible_learning_profile

AUTH_FLOW_ROUTES = frozenset(('login', 'register', 'registration_check_email', 'mfa_verify', 'resend_verification',
    'password_reset', 'password_reset_done', 'password_reset_confirm', 'password_reset_complete', 'verify_email'))

def site_settings(request):
    from .models import PlatformSettings
    cfg = PlatformSettings.load()
    profile = visible_learning_profile(request.user)
    private_prefixes = ('/play/','/tests/','/journey/','/onboarding/','/vocabulary/','/mistakes/','/arena/','/daily-chest/','/notifications/','/learn/','/lessons/','/dashboard/','/profile/','/friends/','/login/','/register/','/mfa/','/manager/','/account/','/ai-tutor/','/assessment/','/placement/','/review/','/secure-admin/','/skills/', '/resend-verification/', '/password-reset/', '/reset/', '/verify/', '/certificate/', '/weekly-review/', '/practice/', '/units/')
    private_prefixes += ('/ai/', '/gifts/', '/avatar/')
    return {'DESK': desktop_labels(request), 'DESK_XP_LEVEL': learning_level(profile.xp) if profile is not None else 1, 'N16':for_request(request), 'L15': get_labels(request), 'PUBLIC_SITE_URL': settings.SITE_URL, 'PROJECT_NAME':'Rozh',
            'AUTH_FLOW_PAGE': (not request.user.is_authenticated and
                              getattr(request.resolver_match, 'url_name', None) in AUTH_FLOW_ROUTES),
            'AI_VISIBLE': cfg.ai_enabled and not cfg.ai_emergency_stop,
            'N45': v45_labels(profile.ui_language if profile is not None else 'en'),
            'V74_LOCALE_BETA': bool((profile.ui_language if profile else request.session.get('public_ui_language')) in ('kmr', 'uk', 'fr', 'ku')),
            'PRIVATE_PAGE': request.path.startswith(private_prefixes)}

"""Original, limited German starter lessons; not a complete A0–C1 syllabus.

Explanations are in English. Examples and speech text are German. Speaking and
writing activities invite self-review and do not claim automated assessment.
"""


def mcq(prompt, options, answer, explanation):
    return {'kind': 'mcq', 'prompt': prompt, 'options': options,
            'answer': answer, 'explanation': explanation}


def short(prompt, answer, explanation):
    return {'kind': 'short', 'prompt': prompt, 'options': [],
            'answer': answer, 'explanation': explanation}


SEIN = (
    'Use sein (to be) to introduce a person, describe a state, or say where someone is. '
    'The present forms are ich bin, du bist, er/sie/es ist, wir sind, ihr seid, and sie/Sie sind. '
    'Choose the form for the subject: Ich bin Nora. Wir sind hier. The formal word for you is '
    'Sie, written with a capital S, and it takes sind even when you address one person. '
    'Use du with one person in an informal relationship; use ihr with several people informally. '
    'In a simple statement the subject usually comes before the verb. For a yes/no question, '
    'put the verb first: Bist du bereit? Sind Sie Frau Weber? A short answer can be Ja, ich bin bereit. '
    'German normally writes nouns with a capital letter, including names of occupations: Lehrer, '
    'Studentin. A plain occupation after sein commonly has no article: Er ist Lehrer. '
    'For this lesson, practise the verb forms as small complete sentences rather than translating '
    'one English word at a time. Hallo is an everyday greeting; Guten Morgen is used in the morning. '
    'Danke expresses thanks and is not a greeting.'
)
ARTICLES = (
    'A German noun has a grammatical gender. Learn the article with the noun: der Tisch '
    '(the table), die Tasche (the bag), das Buch (the book). Gender is part of the vocabulary '
    'and often cannot be predicted from meaning. This lesson uses the nominative: the noun '
    'as a sentence subject, or a description after sein. The definite singular articles are '
    'der for masculine, die for feminine, and das for neuter. To introduce one unspecified '
    'thing, use ein with masculine and neuter nouns and eine with feminine nouns: '
    'ein Tisch, eine Tasche, ein Buch. The definite plural article is die for all genders: '
    'die Tische, die Taschen, die Bücher. There is no ordinary indefinite plural article: '
    'Das sind Bücher means These are books. Nouns still need their own plural form; '
    'changing the article alone does not make them plural. In Das ist ein Buch, ein Buch '
    'describes what das is; it is not a direct object. German changes some articles in '
    'other grammatical cases, so these nominative forms must not be applied everywhere. '
    'For now, notice the article, noun, and verb together: Die Tasche ist neu. Die Taschen sind neu.'
)
PRESENT = (
    'Many German present-tense verbs have an infinitive ending in -en. Remove -en to find '
    'the stem, then add the ending for the subject. With wohnen the forms are ich wohne, '
    'du wohnst, er/sie/es wohnt, wir wohnen, ihr wohnt, and sie/Sie wohnen. The present tense '
    'can describe a habit or something happening now; context provides the difference. '
    'Wir lernen Deutsch can mean We learn German or We are learning German. '
    'In a declarative main clause, the conjugated verb normally occupies the second position. '
    'This is the second sentence element, not necessarily the second word. Compare '
    'Ich lerne heute Deutsch with Heute lerne ich Deutsch. If Heute begins the sentence, '
    'the subject follows the verb. A yes/no question starts with the conjugated verb: '
    'Wohnst du in Berlin? German does not add an English-style do. Some stems need a linking '
    'e for pronunciation: arbeiten gives du arbeitest, er arbeitet, and ihr arbeitet. '
    'Other common verbs, such as sein and haben, are irregular; this regular pattern is not '
    'a rule for every verb. Start by producing accurate, short sentences with wohnen and lernen.'
)

COURSE = {
    'code': 'de', 'name': 'German', 'slug': 'german',
    'description': (
        'An original German starter course with published A0 and A1 activities. '
        'Begin with introductions, nominative articles, and present-tense sentences. '
        'A2–C1 are planned course stages, not a completed curriculum. '
        'Explanations are currently in English; examples and audio text are German.'
    ),
    'units': [
        {
            'level': 'A0', 'slug': 'greetings-and-sein',
            'title': 'Hallo! Introduce yourself with sein',
            'summary': 'Greet someone, introduce a person, and choose bin, bist, ist or sind.',
            'outcomes': ['Introduce yourself in a short German sentence.',
                         'Match common subjects to the present forms of sein.',
                         'Identify a person and place in a short conversation.'],
            'explanation': SEIN,
            'examples': ['Hallo, ich bin Nora.', 'Du bist hier.', 'Er ist Lehrer.',
                         'Wir sind in Berlin.', 'Sind Sie Frau Weber?'],
            'exceptions': 'Sein is irregular. Formal Sie always takes sind; informal singular du takes bist.',
            'common_mistakes': 'Do not say ich ist or wir bin. Use ich bin and wir sind. Write formal Sie with a capital S.',
            'lessons': [
                {'skill': 'grammar', 'title': 'Meet the present forms of sein',
                 'content': SEIN,
                 'audio_text': 'Ich bin Nora. Du bist hier. Er ist Lehrer. Wir sind in Berlin. Sind Sie Frau Weber?',
                 'exercises': [
                     mcq('Choose the correct introduction.', ['Ich bin Nora.', 'Ich ist Nora.', 'Ich bist Nora.'],
                         'Ich bin Nora.', 'Ich takes bin: Ich bin Nora means I am Nora.'),
                     short('Complete with one form of sein: Du ___ hier.', 'bist',
                           'Informal singular du takes bist: Du bist hier.'),
                     mcq('Which question politely asks one person whether they are Mrs Weber?',
                         ['Sind Sie Frau Weber?', 'Bist Sie Frau Weber?', 'Ist Sie Frau Weber?'],
                         'Sind Sie Frau Weber?', 'Formal Sie takes sind, even when addressing one person. The verb comes first in this question.'),
                 ]},
                {'skill': 'reading', 'title': 'Read a first day in class',
                 'content': ('Read the German text. Identify who is speaking, where the people are, and which person is a teacher.\n\n'
                             'Hallo! Ich bin Nora. Ich bin neu hier. Das ist Amir. Er ist mein Freund. '
                             'Wir sind in Berlin. Amir ist Lehrer. Ich bin Studentin. Heute sind wir im Kurs. '
                             'Frau Weber ist unsere Lehrerin. Sie sagt: „Guten Morgen!“\n\n'
                             'neu = new; mein Freund = my friend; Studentin = female student; im Kurs = in the class.'),
                 'audio_text': 'Hallo! Ich bin Nora. Ich bin neu hier. Das ist Amir. Er ist mein Freund. Wir sind in Berlin. Amir ist Lehrer. Ich bin Studentin.',
                 'exercises': [
                     mcq('Who introduces herself at the start?', ['Nora', 'Amir', 'Frau Weber'], 'Nora',
                         'The narrator says Ich bin Nora, then Ich bin Studentin.'),
                     short('In which city are Nora and Amir? Copy the city name.', 'Berlin',
                           'Wir sind in Berlin tells us their current city.'),
                     mcq('Which sentence says that Amir is a teacher?',
                         ['Amir ist Lehrer.', 'Ich bin Studentin.', 'Er ist mein Freund.'], 'Amir ist Lehrer.',
                         'Lehrer means male teacher. Ist agrees with the singular name Amir.'),
                 ]},
                {'skill': 'listening', 'title': 'Listen for names and places',
                 'content': ('Play the German audio once for the overall meaning and again for the details. '
                             'Listen for the speakers’ city of origin and their location today. '
                             'Audio availability depends on the German voice installed on your device. '
                             'If playback is unavailable, practise by reading the transcript below.\n\n'
                             'Guten Morgen! Ich bin Sara. Ich bin aus Hamburg. Das ist Leon. '
                             'Wir sind heute in Berlin. Leon ist müde, aber ich bin bereit.\n\n'
                             'aus = from; heute = today; müde = tired; bereit = ready.'),
                 'audio_text': 'Guten Morgen! Ich bin Sara. Ich bin aus Hamburg. Das ist Leon. Wir sind heute in Berlin. Leon ist müde, aber ich bin bereit.',
                 'exercises': [
                     mcq('Where is Sara from?', ['Hamburg', 'Berlin', 'Bonn'], 'Hamburg',
                         'Sara says Ich bin aus Hamburg. Aus identifies where she is from.'),
                     short('Where are Sara and Leon today? Write the city.', 'Berlin',
                           'Wir sind heute in Berlin says where both people are today.'),
                     mcq('Who is tired?', ['Leon', 'Sara', 'Both people'], 'Leon',
                         'Leon ist müde means Leon is tired. Sara says she is ready.'),
                 ]},
                {'skill': 'speaking', 'title': 'Introduce yourself aloud',
                 'content': ('Say Hallo, ich bin ... with a real or invented first name. Add Ich bin hier and '
                             'Wir sind im Kurs. Practise Bist du bereit? and answer Ja, ich bin bereit. '
                             'Then read the example audio aloud and compare the words and rhythm. '
                             'Self-review: did you use bin with ich and sind with wir? Repeat once after correcting yourself. '
                             'This is self-reviewed speaking practice; pronunciation and proficiency are not independently assessed.'),
                 'audio_text': 'Hallo, ich bin Nora. Ich bin hier. Wir sind im Kurs. Bist du bereit? Ja, ich bin bereit.',
                 'exercises': []},
                {'skill': 'writing', 'title': 'Write three introductions',
                 'content': ('Write three short sentences in your notebook: one starting Ich bin, one with '
                             'an invented person’s name plus ist, and one starting Wir sind. Add a greeting. '
                             'Example: Hallo! Ich bin Nora. Amir ist hier. Wir sind in Berlin. '
                             'Check each subject–verb pair and the capital letters in names and nouns. '
                             'Confirm completion only after revising your sentences. This task is self-reviewed; '
                             'there is no independent grammar or writing score.'),
                 'audio_text': '', 'exercises': []},
            ],
            'vocabulary': [
                {'word': 'hallo', 'translation': 'hello', 'pronunciation': '/haˈloː/', 'example': 'Hallo, ich bin Nora.', 'emoji': '👋'},
                {'word': 'Guten Morgen', 'translation': 'good morning', 'pronunciation': '/ˈɡuːtn̩ ˈmɔʁɡn̩/', 'example': 'Guten Morgen, Frau Weber!', 'emoji': '☀️'},
                {'word': 'ich', 'translation': 'I', 'pronunciation': '/ɪç/', 'example': 'Ich bin bereit.', 'emoji': '🙋'},
                {'word': 'du', 'translation': 'you (one person, informal)', 'pronunciation': '/duː/', 'example': 'Du bist hier.', 'emoji': '🤝'},
                {'word': 'wir', 'translation': 'we', 'pronunciation': '/viːɐ̯/', 'example': 'Wir sind in Berlin.', 'emoji': '👥'},
                {'word': 'sein', 'translation': 'to be', 'pronunciation': '/zaɪ̯n/', 'example': 'Ich bin Studentin.', 'emoji': '🌱'},
            ],
        },
        {
            'level': 'A0', 'slug': 'nominative-articles',
            'title': 'Der, die, das: learn nouns with their articles',
            'summary': 'Use nominative der, die, das and ein/eine, then notice the plural die.',
            'outcomes': ['Recognize the gender of a noun from its dictionary article.',
                         'Choose an indefinite singular article in the nominative.',
                         'Distinguish singular and plural noun phrases.'],
            'explanation': ARTICLES,
            'examples': ['Der Tisch ist groß.', 'Die Tasche ist neu.', 'Das Buch ist klein.',
                         'Das ist eine Lampe.', 'Die Bücher sind neu.'],
            'exceptions': 'These are nominative forms only. Masculine ein becomes einen in the accusative; other cases are taught later. Noun plurals must be learned individually.',
            'common_mistakes': 'Do not infer noun gender from English. Say das Buch, not der Buch. Do not use ein before a plural: Bücher, not ein Bücher.',
            'lessons': [
                {'skill': 'grammar', 'title': 'Choose a nominative article',
                 'content': ARTICLES,
                 'audio_text': 'Der Tisch ist groß. Die Tasche ist neu. Das Buch ist klein. Das ist eine Lampe. Die Bücher sind neu.',
                 'exercises': [
                     mcq('Which is the standard dictionary phrase for “the book”?', ['das Buch', 'der Buch', 'die Buch'],
                         'das Buch', 'Buch is neuter: das Buch. Learn the noun and article together.'),
                     short('Complete with one word: Das ist ___ Tasche.', 'eine',
                           'Tasche is feminine. An indefinite feminine noun in the nominative takes eine.'),
                     mcq('Choose the definite plural phrase.', ['die Bücher', 'das Bücher', 'ein Bücher'],
                         'die Bücher', 'All definite plural nouns take die in the nominative. The plural of Buch is Bücher.'),
                 ]},
                {'skill': 'reading', 'title': 'Read the room description',
                 'content': ('Read the description and match each noun to its article.\n\n'
                             'Das ist ein Zimmer. Der Tisch ist groß. Die Tasche ist blau. '
                             'Das Buch ist neu. Ein Stuhl ist frei. Eine Lampe ist hell. '
                             'Die Bücher sind klein. Das Kind ist hier.\n\n'
                             'Zimmer = room; groß = large; blau = blue; neu = new; frei = free/available; hell = bright; klein = small.'),
                 'audio_text': 'Das ist ein Zimmer. Der Tisch ist groß. Die Tasche ist blau. Das Buch ist neu. Ein Stuhl ist frei. Eine Lampe ist hell. Die Bücher sind klein. Das Kind ist hier.',
                 'exercises': [
                     mcq('What is blue in the text?', ['die Tasche', 'der Tisch', 'das Buch'], 'die Tasche',
                         'Die Tasche ist blau means The bag is blue.'),
                     short('Copy the German plural noun in “Die Bücher sind klein.”', 'Bücher',
                           'Bücher is the plural of Buch. Its definite nominative article is die.'),
                     mcq('Which object is available?', ['ein Stuhl', 'eine Lampe', 'ein Buch'], 'ein Stuhl',
                         'Ein Stuhl ist frei means A chair is free or available.'),
                 ]},
                {'skill': 'listening', 'title': 'Hear articles and number',
                 'content': ('Listen for the articles and the difference between ist and sind. Play the German audio twice. '
                             'If your device has no German voice, read the transcript instead; this does not independently test listening ability.\n\n'
                             'Hier ist ein Tisch. Das ist eine Tasche. Das Buch ist neu. '
                             'Die Bücher sind alt. Die Lampe ist hell. Der Stuhl ist frei.\n\n'
                             'hier = here; alt = old. Notice that a single Buch is new while the plural Bücher are old.'),
                 'audio_text': 'Hier ist ein Tisch. Das ist eine Tasche. Das Buch ist neu. Die Bücher sind alt. Die Lampe ist hell. Der Stuhl ist frei.',
                 'exercises': [
                     mcq('Which phrase introduces a bag?', ['eine Tasche', 'ein Tasche', 'einen Tasche'], 'eine Tasche',
                         'You hear Das ist eine Tasche. Tasche is feminine, so the nominative indefinite article is eine.'),
                     short('Complete the phrase you hear: Die Bücher ___ alt.', 'sind',
                           'Bücher is plural, so the verb is sind.'),
                     mcq('What is bright?', ['die Lampe', 'der Stuhl', 'das Buch'], 'die Lampe',
                         'Die Lampe ist hell means The lamp is bright.'),
                 ]},
                {'skill': 'speaking', 'title': 'Name objects with their articles',
                 'content': ('Say der Tisch, die Tasche and das Buch. Then say a complete sentence for each: '
                             'Der Tisch ist groß. Die Tasche ist neu. Das Buch ist klein. '
                             'Change the last sentence to the plural: Die Bücher sind klein. '
                             'Self-review the article and the change from ist to sind. Listen again and repeat. '
                             'This is self-reviewed practice; your pronunciation is not automatically graded.'),
                 'audio_text': 'Der Tisch ist groß. Die Tasche ist neu. Das Buch ist klein. Die Bücher sind klein.',
                 'exercises': []},
                {'skill': 'writing', 'title': 'Describe an imagined room',
                 'content': ('Write four sentences about an imagined room in your notebook. Use der Tisch, '
                             'die Tasche, das Buch and eine Lampe. Choose adjectives from groß, klein, neu, hell. '
                             'Example: Das Buch ist neu. Check that each noun starts with a capital letter and '
                             'the article matches the noun. Add Die Bücher sind neu as a fifth plural sentence. '
                             'Revise before confirming completion. This self-reviewed activity does not certify grammatical accuracy.'),
                 'audio_text': '', 'exercises': []},
            ],
            'vocabulary': [
                {'word': 'Buch', 'translation': 'book (das Buch; plural: die Bücher)', 'pronunciation': '/buːx/', 'example': 'Das Buch ist neu.', 'emoji': '📘'},
                {'word': 'Tisch', 'translation': 'table (der Tisch; plural: die Tische)', 'pronunciation': '/tɪʃ/', 'example': 'Der Tisch ist groß.', 'emoji': '🪑'},
                {'word': 'Tasche', 'translation': 'bag (die Tasche; plural: die Taschen)', 'pronunciation': '/ˈtaʃə/', 'example': 'Die Tasche ist blau.', 'emoji': '👜'},
                {'word': 'Lampe', 'translation': 'lamp (die Lampe; plural: die Lampen)', 'pronunciation': '/ˈlampə/', 'example': 'Die Lampe ist hell.', 'emoji': '💡'},
                {'word': 'Kind', 'translation': 'child (das Kind; plural: die Kinder)', 'pronunciation': '/kɪnt/', 'example': 'Das Kind ist hier.', 'emoji': '🧒'},
                {'word': 'Stuhl', 'translation': 'chair (der Stuhl; plural: die Stühle)', 'pronunciation': '/ʃtuːl/', 'example': 'Ein Stuhl ist frei.', 'emoji': '🪑'},
            ],
            'rich': {
                'intro': 'German articles carry useful information. Learn each new noun as a small phrase, then practise that phrase in a complete sentence. This guide begins with the nominative rather than mixing all four cases at once.',
                'learning_goals': ['Recall the nominative singular articles der, die and das.',
                                   'Choose ein or eine when introducing one unspecified thing.',
                                   'Recognize definite plurals with die and avoid an indefinite plural ein.',
                                   'Explain why a description after sein is not a direct object.'],
                'sections': [
                    {'title': 'Gender belongs to the noun', 'body': 'Tisch is masculine, Tasche is feminine and Buch is neuter. These are grammatical categories. A table does not have a natural male gender, and the meaning of an English translation does not reliably predict a German article. Record der Tisch, not Tisch alone. Include the plural in your vocabulary notes: der Tisch – die Tische.'},
                    {'title': 'Known things and new things', 'body': 'Use a definite article when the listener can identify the thing: Das Buch ist neu. Use an indefinite article to introduce one unspecified thing: Das ist ein Buch. Context determines whether a thing is identifiable. A beginner can practise this as a two-step description: Das ist eine Tasche. Die Tasche ist blau.'},
                    {'title': 'Why these examples use the nominative', 'body': 'The nominative marks a sentence subject, as in Der Tisch ist groß. A noun phrase that identifies the subject after sein is also nominative: Das ist ein Tisch. Here ein Tisch is a predicate noun phrase, not an object. When you later learn Ich sehe einen Tisch, the masculine article changes because the phrase is an accusative object. Do not substitute that later form into Das ist ein Tisch.'},
                    {'title': 'Plural means more than changing the article', 'body': 'All definite nominative plurals use die, but their noun endings vary: die Tische, die Taschen, die Bücher. Some nouns change their vowel as well as their ending. There is no ordinary plural of ein meaning some: Das sind Bücher. A quantity can be added separately, as in zwei Bücher. Use sind with a plural subject: Die Bücher sind neu.'},
                ],
                'rule_tables': [
                    {'title': 'Nominative articles in useful phrases',
                     'columns': ['Gender', 'Definite singular', 'Indefinite singular', 'Definite plural'],
                     'rows': [['Masculine', 'der Tisch', 'ein Tisch', 'die Tische'],
                              ['Feminine', 'die Tasche', 'eine Tasche', 'die Taschen'],
                              ['Neuter', 'das Buch', 'ein Buch', 'die Bücher']],
                     'note': 'These are nominative forms. Other cases have different forms; noun plurals must be learned individually.'},
                    {'title': 'From one thing to several',
                     'columns': ['One', 'Several', 'What changes?'],
                     'rows': [['Das Buch ist neu.', 'Die Bücher sind neu.', 'article + noun + verb'],
                              ['Das ist eine Tasche.', 'Das sind Taschen.', 'no plural eine; sein becomes sind']],
                     'note': 'In the second example, das is a demonstrative pronoun rather than an article attached to Taschen.'},
                ],
                'sentence_patterns': [
                    {'label': 'Describe an identified thing', 'tokens': [{'text': 'Der Tisch', 'role': 'subject'}, {'text': 'ist', 'role': 'verb'}, {'text': 'groß.', 'role': 'other'}]},
                    {'label': 'Introduce one thing: predicate nominative after sein', 'tokens': [{'text': 'Das', 'role': 'subject'}, {'text': 'ist', 'role': 'verb'}, {'text': 'ein Buch.', 'role': 'other'}]},
                    {'label': 'Describe several things', 'tokens': [{'text': 'Die Bücher', 'role': 'subject'}, {'text': 'sind', 'role': 'verb'}, {'text': 'neu.', 'role': 'other'}]},
                ],
                'example_pairs': [
                    {'original': 'Das ist eine Tasche. Die Tasche ist blau.', 'translation': 'This is a bag. The bag is blue.', 'note': 'Eine introduces the bag; die refers back to the now identifiable bag.'},
                    {'original': 'Das Buch ist klein. Die Bücher sind klein.', 'translation': 'The book is small. The books are small.', 'note': 'The plural changes the article, the noun and the verb.'},
                    {'original': 'Das sind Bücher.', 'translation': 'These are books.', 'note': 'An indefinite plural normally has no article corresponding to ein.'},
                    {'original': 'Ein Stuhl ist frei.', 'translation': 'A chair is available.', 'note': 'Stuhl is masculine, so nominative singular uses ein.'},
                ],
                'common_traps': [
                    {'wrong': 'Der Buch ist neu.', 'correct': 'Das Buch ist neu.', 'why': 'Buch is neuter. Its nominative definite singular article is das.'},
                    {'wrong': 'Das ist ein Tasche.', 'correct': 'Das ist eine Tasche.', 'why': 'Tasche is feminine. Use eine in the nominative singular.'},
                    {'wrong': 'Das sind ein Bücher.', 'correct': 'Das sind Bücher.', 'why': 'Ein has no ordinary indefinite plural form. Bücher is already plural.'},
                    {'wrong': 'Die Bücher ist neu.', 'correct': 'Die Bücher sind neu.', 'why': 'A plural subject takes sind, not singular ist.'},
                ],
            },
        },
        {
            'level': 'A1', 'slug': 'regular-present-and-word-order',
            'title': 'Heute lerne ich: regular verbs and sentence order',
            'summary': 'Build everyday present-tense statements and questions with wohnen and lernen.',
            'outcomes': ['Form common regular present-tense verbs for ich, du and wir.',
                         'Keep the finite verb second after a fronted time phrase.',
                         'Ask a simple yes/no question without an English-style do.'],
            'explanation': PRESENT,
            'examples': ['Ich wohne in Köln.', 'Du wohnst in Berlin.', 'Wir lernen Deutsch.',
                         'Heute lerne ich Deutsch.', 'Wohnst du hier?', 'Er arbeitet heute.'],
            'exceptions': 'Some stems insert e, as in du arbeitest and er arbeitet. Irregular verbs such as sein have their own forms. The V2 pattern here describes declarative main clauses, not every clause type.',
            'common_mistakes': 'Do not write Heute ich lerne Deutsch. The verb is second: Heute lerne ich Deutsch. With du use wohnst, not wohne.',
            'lessons': [
                {'skill': 'grammar', 'title': 'Put the finite verb in its place',
                 'content': PRESENT,
                 'audio_text': 'Ich wohne in Köln. Du wohnst in Berlin. Wir lernen Deutsch. Heute lerne ich Deutsch. Wohnst du hier? Er arbeitet heute.',
                 'exercises': [
                     mcq('Choose the correct statement beginning with Heute.',
                         ['Heute lerne ich Deutsch.', 'Heute ich lerne Deutsch.', 'Heute lernen ich Deutsch.'],
                         'Heute lerne ich Deutsch.', 'Heute fills the first position. The finite verb lerne is second, followed by the subject ich.'),
                     short('Complete with one form of wohnen: Du ___ in Berlin.', 'wohnst',
                           'The stem wohn- takes -st with du: du wohnst.'),
                     mcq('Which is the ordinary yes/no question?', ['Wohnst du hier?', 'Du wohnst hier.', 'Do du wohnst hier?'],
                         'Wohnst du hier?', 'Place the conjugated verb before the subject. German does not add English do.'),
                 ]},
                {'skill': 'reading', 'title': 'Read about an ordinary morning',
                 'content': ('Read the text and find the actions, people and places.\n\n'
                             'Ich heiße Lea und wohne in Köln. Am Morgen lerne ich Deutsch. '
                             'Mein Bruder Tom arbeitet heute in Bonn. Wir spielen am Abend. '
                             'Tom hört gern Musik. Ich mache eine Pause. Morgen lernen wir zusammen.\n\n'
                             'am Morgen = in the morning; mein Bruder = my brother; am Abend = in the evening; '
                             'gern = with pleasure; eine Pause = a break; zusammen = together.'),
                 'audio_text': 'Ich heiße Lea und wohne in Köln. Am Morgen lerne ich Deutsch. Mein Bruder Tom arbeitet heute in Bonn. Wir spielen am Abend. Tom hört gern Musik. Ich mache eine Pause. Morgen lernen wir zusammen.',
                 'exercises': [
                     mcq('Where does Lea live?', ['Köln', 'Bonn', 'Berlin'], 'Köln',
                         'Lea says Ich ... wohne in Köln. Tom works in Bonn; that is a different detail.'),
                     short('Complete the sentence from the text: Morgen ___ wir zusammen.', 'lernen',
                           'The subject wir takes the infinitive-shaped present form lernen. Morgen comes first and the verb is second.'),
                     mcq('When do they play?', ['am Abend', 'am Morgen', 'Only tomorrow'], 'am Abend',
                         'Wir spielen am Abend means We play in the evening.'),
                 ]},
                {'skill': 'listening', 'title': 'Listen for a daily routine',
                 'content': ('Listen twice, first for the main situation and then for the details. '
                             'Your browser needs a German device voice. If audio is unavailable, use the transcript as reading practice.\n\n'
                             'Hallo, ich bin Emil. Ich wohne in Hamburg. Heute arbeite ich in Berlin. '
                             'Am Abend höre ich Musik. Morgen lernen wir Deutsch. Wir lernen zusammen.\n\n'
                             'Notice how the verb follows Heute, Am Abend and Morgen while the subject comes after the verb.'),
                 'audio_text': 'Hallo, ich bin Emil. Ich wohne in Hamburg. Heute arbeite ich in Berlin. Am Abend höre ich Musik. Morgen lernen wir Deutsch. Wir lernen zusammen.',
                 'exercises': [
                     mcq('Where does Emil work today?', ['Berlin', 'Hamburg', 'Köln'], 'Berlin',
                         'Heute arbeite ich in Berlin gives his work location today; Hamburg is where he lives.'),
                     short('Complete the heard phrase: Am Abend ___ ich Musik.', 'höre',
                           'Ich takes höre. The initial phrase Am Abend occupies the first position and höre follows it.'),
                     mcq('What will they learn tomorrow?', ['Deutsch', 'Musik', 'No subject is mentioned'], 'Deutsch',
                         'Morgen lernen wir Deutsch explicitly names German as the subject they study.'),
                 ]},
                {'skill': 'speaking', 'title': 'Change the start of your sentence',
                 'content': ('Say Ich lerne heute Deutsch. Now begin with Heute and say Heute lerne ich Deutsch. '
                             'Repeat with Wir lernen morgen and Morgen lernen wir. Ask Wohnst du hier? '
                             'Answer with an invented location: Ja, ich wohne in Berlin. '
                             'Check that the verb stays second in statements and comes first in the question. '
                             'Compare your words to the audio. This is self-reviewed speaking practice, not a pronunciation assessment.'),
                 'audio_text': 'Ich lerne heute Deutsch. Heute lerne ich Deutsch. Wir lernen morgen. Morgen lernen wir. Wohnst du hier? Ja, ich wohne in Berlin.',
                 'exercises': []},
                {'skill': 'writing', 'title': 'Write your daily routine',
                 'content': ('Write four short sentences in your notebook using lernen, wohnen, hören or spielen. '
                             'Start two with Ich or Wir, and start two with Heute or Morgen. '
                             'Example: Heute lerne ich Deutsch. Add one yes/no question beginning with a verb. '
                             'Check subject–verb endings, the second position of the finite verb in statements, '
                             'and noun capitalization. Correct your work before confirming completion. '
                             'This self-reviewed task does not receive an independent grammar score.'),
                 'audio_text': '', 'exercises': []},
            ],
            'vocabulary': [
                {'word': 'wohnen', 'translation': 'to live / reside', 'pronunciation': '/ˈvoːnən/', 'example': 'Ich wohne in Köln.', 'emoji': '🏠'},
                {'word': 'lernen', 'translation': 'to learn / study', 'pronunciation': '/ˈlɛʁnən/', 'example': 'Heute lerne ich Deutsch.', 'emoji': '📚'},
                {'word': 'arbeiten', 'translation': 'to work', 'pronunciation': '/ˈaʁbaɪ̯tn̩/', 'example': 'Er arbeitet heute in Bonn.', 'emoji': '💼'},
                {'word': 'machen', 'translation': 'to do / make', 'pronunciation': '/ˈmaxn̩/', 'example': 'Ich mache eine Pause.', 'emoji': '🛠️'},
                {'word': 'spielen', 'translation': 'to play', 'pronunciation': '/ˈʃpiːlən/', 'example': 'Wir spielen am Abend.', 'emoji': '🎲'},
                {'word': 'hören', 'translation': 'to hear / listen to', 'pronunciation': '/ˈhøːʁən/', 'example': 'Am Abend höre ich Musik.', 'emoji': '🎧'},
            ],
        },
    ],
}

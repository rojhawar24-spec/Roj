"""V86 Django HTTP security regression; requires isolated QA DB and Django.

These tests are NOT reported as passed unless manage.py test actually runs.
"""
from unittest.mock import patch

import pyotp
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.test import Client, TestCase
from django.urls import reverse

from .models import Profile


class Step2MFADisableReauthenticationHTTP(TestCase):
    PASSWORD = 'V86-Only-MFA-Strong-Password!'
    SECRET = 'JBSWY3DPEHPK3PXP'

    def setUp(self):
        User = get_user_model()
        self.user = User.objects.create_user(
            'v86learner', 'v86@example.invalid', self.PASSWORD)
        self.profile = Profile.objects.get(user=self.user)
        self.profile.totp_secret = self.SECRET
        self.profile.save(update_fields=['totp_secret'])
        self.client.force_login(self.user)

    def totp(self):
        return pyotp.TOTP(self.SECRET).now()

    def test_no_password_cannot_remove_mfa(self):
        response = self.client.post(reverse('mfa_disable'), {'code': self.totp()})
        self.assertEqual(response.status_code, 403)
        self.profile.refresh_from_db()
        self.assertTrue(self.profile.totp_secret)

    def test_wrong_password_with_correct_otp_denied(self):
        response = self.client.post(reverse('mfa_disable'), {
            'password': 'wrong', 'code': self.totp()})
        self.assertEqual(response.status_code, 403)
        self.profile.refresh_from_db()
        self.assertTrue(self.profile.totp_secret)

    def test_correct_password_with_wrong_otp_denied(self):
        response = self.client.post(reverse('mfa_disable'), {
            'password': self.PASSWORD, 'code': '000000'})
        self.assertEqual(response.status_code, 403)
        self.profile.refresh_from_db()
        self.assertTrue(self.profile.totp_secret)

    def test_correct_both_disables_non_privileged_mfa(self):
        response = self.client.post(reverse('mfa_disable'), {
            'password': self.PASSWORD, 'code': self.totp()})
        self.assertEqual(response.status_code, 302)
        self.profile.refresh_from_db()
        self.assertFalse(self.profile.totp_secret)
        self.assertEqual(self.client.session.get('mfa_verified_id'), None)

    def test_direct_permission_grant_blocks_disable(self):
        perm = Permission.objects.first()
        self.assertIsNotNone(perm)
        self.user.user_permissions.add(perm)
        response = self.client.post(reverse('mfa_disable'), {
            'password': self.PASSWORD, 'code': self.totp()})
        self.assertEqual(response.status_code, 403)
        self.profile.refresh_from_db()
        self.assertTrue(self.profile.totp_secret)

    def test_unauthorized_http_methods_are_rejected(self):
        for route in ('mfa_setup', 'mfa_verify', 'mfa_recovery'):
            with self.subTest(route=route):
                self.assertEqual(self.client.put(reverse(route), data='').status_code, 405)

    def test_password_form_present_and_not_prepopulated(self):
        response = self.client.get(reverse('profile'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'name="password"')
        self.assertContains(response, 'autocomplete="current-password"')
        self.assertNotContains(response, f'value="{self.PASSWORD}"')

    def test_mfa_disable_requires_csrf(self):
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        response = client.post(reverse('mfa_disable'), {
            'password': self.PASSWORD, 'code': self.totp()})
        self.assertEqual(response.status_code, 403)
        self.profile.refresh_from_db()
        self.assertTrue(self.profile.totp_secret)

"""V73 published-only daily calendar and actual last-week spelling practice.

No scheduler is needed: a row is frozen on the FIRST visit to the daily page
for this learner, course, and learner-local calendar date. The DB uniqueness
constraint plus Profile row locking handles concurrent requests. An unpublished
frozen word becomes unavailable rather than silently changing midday.
"""
from datetime import timedelta

from django.db import transaction
from django.utils import timezone

from .daily_word_v18 import normalized_word
from .models import DailyWordEntry, DailyWordWeeklySession, Profile, Vocabulary


def monday(day):
    return day - timedelta(days=day.weekday())


def last_complete_week(day):
    """Monday through Sunday of the last FULL week, using learner's local date."""
    current = monday(day)
    return current - timedelta(days=7), current - timedelta(days=1)


def _pick_fresh_word(user, course, day):
    """Avoid any previously seen *spelling* in this course-cycle until exhausted.

    Called under the Profile lock, inside an atomic transaction. The ordering
    and day + user seed don't rely on random state; the chosen word is persisted.
    """
    published = list(Vocabulary.objects.filter(published=True, level__language=course,
                         level__language__is_published=True).order_by('pk').values_list('pk', 'word'))
    if not published:
        return None, 1
    # Multiple CEFR entries can contain identical spellings: count as ONE word.
    unique = []
    spellings = set()
    for pk, word in published:
        normalized = normalized_word(word)
        if normalized and normalized not in spellings:
            spellings.add(normalized)
            unique.append((pk, normalized))
    if not unique:
        return None, 1
    previous = DailyWordEntry.objects.filter(user=user, course=course).order_by('-day', '-pk')
    latest = previous.first()
    cycle = latest.cycle if latest else 1
    used = set()
    for word in previous.filter(cycle=cycle, vocabulary__isnull=False).values_list('word_text', flat=True):
        used.add(normalized_word(word))
    available = [(pk, spelling) for pk, spelling in unique if spelling not in used]
    if not available:
        cycle += 1
        available = unique
        # Avoid the same word on two adjacent days at cycle boundary if possible.
        if latest and latest.vocabulary_id and len(available) > 1:
            last_spelling = normalized_word(latest.word_text)
            different = [row for row in available if row[1] != last_spelling]
            if different:
                available = different
    index = (day.toordinal() + user.pk) % len(available)
    return available[index][0], cycle


def daily_for_learner(user, course, day):
    """Persist exact per-day word assignment, or return None for empty course."""
    if not course or not course.is_published:
        return None
    with transaction.atomic():
        profile = Profile.objects.select_for_update().get(user=user)
        if profile.preferred_language_id != course.pk:
            return None
        # Repeat with cached GET, POST and page refresh; never replace silently.
        entry = DailyWordEntry.objects.filter(user=user, course=course, day=day).select_related('vocabulary__level__language').first()
        if entry is not None:
            return entry
        word_id, cycle = _pick_fresh_word(user, course, day)
        if word_id is None:
            return None
        word = Vocabulary.objects.get(pk=word_id)
        return DailyWordEntry.objects.create(user=user, course=course, day=day,
                 vocabulary_id=word_id, cycle=cycle, word_text=word.word,
                 meaning_text=word.translation, example_text=word.example,
                 pronunciation_text=word.pronunciation, emoji_text=word.emoji)


def published_daily_word(entry):
    if entry is None or entry.vocabulary_id is None:
        return None
    # Never show unpublished or course-mismatched content, even on a saved day.
    word = Vocabulary.objects.filter(pk=entry.vocabulary_id, published=True,
            level__language_id=entry.course_id,
            level__language__is_published=True).select_related('level__language').first()
    if word is not None:
        # In-memory fields are frozen on first view; manager edits never change
        # today's visible word, translation, example or expected spelling.
        word.word = entry.word_text
        word.translation = entry.meaning_text
        word.example = entry.example_text
        word.pronunciation = entry.pronunciation_text
        word.emoji = entry.emoji_text
    return word


def weekly_words(user, course, week_start):
    """Snapshot of successful last-week spellings for this course and learner."""
    seen = DailyWordEntry.objects.filter(user=user, course=course,
             day__gte=week_start - timedelta(days=7), day__lt=week_start,
             completed_at__isnull=False, vocabulary__published=True,
             vocabulary__level__language=course,
             vocabulary__level__language__is_published=True).select_related('vocabulary__level').order_by('day', 'pk')
    items = []
    used = set()
    for entry in seen:
        spelling = normalized_word(entry.word_text)
        if spelling not in used:
            used.add(spelling)
            items.append({'vocabulary_id':entry.vocabulary_id, 'word':entry.word_text,
                          'meaning':entry.meaning_text, 'emoji':entry.emoji_text,
                          'level_code':entry.vocabulary.level.code})
    return items


def weekly_for_learner(user, course, day):
    """One frozen weekly session per selected course and learner-local ISO week."""
    if not course or not course.is_published:
        return None
    week_start = monday(day)
    with transaction.atomic():
        profile = Profile.objects.select_for_update().get(user=user)
        if profile.preferred_language_id != course.pk:
            return None
        session = DailyWordWeeklySession.objects.filter(user=user, course=course,
                            week_start=week_start).first()
        if session is not None:
            return session
        items = weekly_words(user, course, week_start)
        if not items:
            return None
        return DailyWordWeeklySession.objects.create(user=user, course=course,
                         week_start=week_start, items=items)


def current_review_word(session):
    if not session or session.completed_at or session.position >= len(session.items):
        return None
    item = session.items[session.position]
    if not isinstance(item, dict):
        return None
    try:
        pk = int(item.get('vocabulary_id'))
    except (TypeError, ValueError):
        return None
    exists = Vocabulary.objects.filter(pk=pk, published=True,
                 level__language_id=session.course_id,
                 level__language__is_published=True).exists()
    return item if exists else None


WEEKLY_COPY = {
    'nl': {'title':'Wekelijkse herhaling','intro':'Herhaal de woorden die je vorige week zelf correct hebt geschreven.',
           'open':'Herhaal de woorden van vorige week','not_ready':'Er zijn nog geen afgeronde dagwoorden van vorige week voor deze cursus. Leer elke dag een woord en kom volgende week terug.',
           'course':'Kies eerst een cursus.','prompt':'Schrijf het woord bij deze betekenis','meaning':'Betekenis',
           'check':'Controleer antwoord','wrong':'Nog niet goed. Probeer het opnieuw.','right':'Goed! Volgend woord.',
           'finished':'Goed gedaan! Je hebt je wekelijkse herhaling voltooid.','done':'Je hebt deze week al herhaald.',
           'back':'Terug naar woord van de dag','progress':'Voortgang','no_reward':'Herhalingsoefening · geen extra XP of hartjes',
           'unavailable':'Een woord is niet meer gepubliceerd. De herhaling wordt veilig gestopt; vraag de manager om inhoud bij te werken.'},
    'en': {'title':'Weekly review','intro':'Practise the words you spelled correctly last week.',
           'open':'Review last week’s words','not_ready':'No completed daily words from last week in this course yet. Learn a word each day and return next week.',
           'course':'Choose a course first.','prompt':'Type the word that matches this meaning','meaning':'Meaning',
           'check':'Check answer','wrong':'Not quite. Try again.','right':'Correct! Next word.',
           'finished':'Great work! Your weekly review is complete.','done':'You already reviewed this week.',
           'back':'Back to word of the day','progress':'Progress','no_reward':'Practice only · no extra XP or hearts',
           'unavailable':'A word is no longer published. Review is paused; ask the manager to update the content.'},
    'ckb': {'title':'پێداچوونەوەی هەفتانە','intro':'ئەو وشانە دووبارە بنووسە کە هەفتەی ڕابردوو بە درستی نووسیوتن.',
           'open':'پێداچوونەوەی وشەکانی هەفتەی ڕابردوو','not_ready':'هێشتا وشەی تەواوکراوی هەفتەی ڕابردوو بۆ ئەم کۆرسە نییە. هەموو ڕۆژێک وشەیەک فێربە و هەفتەی داهاتوو بگەڕێوە.',
           'course':'سەرەتا کۆرسێک هەڵبژێرە.','prompt':'ئەو وشەیە بنووسە کە ئەم واتایەی هەیە','meaning':'واتا',
           'check':'وەڵامەکەت بپشکنە','wrong':'هێشتا ڕاست نییە. دووبارە هەوڵ بدە.','right':'ڕاستە! وشەی داهاتوو.',
           'finished':'ئافەرین! پێداچوونەوەی ئەم هەفتەیەت تەواو کرد.','done':'ئەم هەفتەیە پێداچوونەوەت تەواو کردووە.',
           'back':'گەڕانەوە بۆ وشەی ڕۆژ','progress':'پێشکەوتن','no_reward':'تەنها ڕاهێنان · هیچ XP یان دڵێکی زیادە نییە',
           'unavailable':'وشەیەک چیتر بڵاوکراوە نییە. پێداچوونەوە ڕاوەستاوە؛ داوا لە Manager بکە ناوەڕۆکەکە نوێ بکاتەوە.'},
    'ar': {'title':'المراجعة الأسبوعية','intro':'راجع الكلمات التي كتبتها بصورة صحيحة الأسبوع الماضي.',
           'open':'راجع كلمات الأسبوع الماضي','not_ready':'لا توجد كلمات يومية مكتملة من الأسبوع الماضي لهذه الدورة. تعلّم كلمة كل يوم وعُد الأسبوع المقبل.',
           'course':'اختر دورة أولاً.','prompt':'اكتب الكلمة التي تناسب هذا المعنى','meaning':'المعنى',
           'check':'تحقق من الإجابة','wrong':'ليست صحيحة بعد. حاول مجدداً.','right':'صحيح! الكلمة التالية.',
           'finished':'أحسنت! أكملت المراجعة الأسبوعية.','done':'أكملت مراجعتك هذا الأسبوع بالفعل.',
           'back':'العودة إلى كلمة اليوم','progress':'التقدم','no_reward':'تدريب فقط · دون XP أو قلوب إضافية',
           'unavailable':'لم تعد إحدى الكلمات منشورة. تم إيقاف المراجعة؛ اطلب من المدير تحديث المحتوى.'},
}


def weekly_labels(user):
    return WEEKLY_COPY.get(user.learning_profile.ui_language, WEEKLY_COPY['en'])


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'daily_calendar_v73', ['WEEKLY_COPY'])


WEEKLY_COPY['fr'].update(dict(title='Révision hebdomadaire',intro='Révisez les mots correctement écrits la semaine dernière.',open='Réviser les mots de la semaine dernière',not_ready='Aucun mot du jour terminé la semaine dernière pour ce cours. Apprenez un mot chaque jour et revenez la semaine prochaine.',course='Choisissez d’abord un cours.',prompt='Écrivez le mot correspondant à ce sens',meaning='Signification',check='Vérifier la réponse',wrong='Pas encore correct. Réessayez.',right='Correct ! Mot suivant.',finished='Bravo ! Votre révision hebdomadaire est terminée.',done='Vous avez déjà révisé cette semaine.',back='Retour au mot du jour',progress='Progression',no_reward='Exercice de révision · aucun XP ni cœur supplémentaire',unavailable='Un mot n’est plus publié. Révision interrompue ; demandez au gestionnaire de corriger le contenu.'))
WEEKLY_COPY['uk'].update(dict(title='Щотижневе повторення',intro='Повтори слова, які ти правильно написав минулого тижня.',open='Повторити слова минулого тижня',not_ready='У цьому курсі немає завершених слів дня за минулий тиждень. Вивчай слово щодня й повертайся наступного тижня.',course='Спочатку вибери курс.',prompt='Напиши слово з таким значенням',meaning='Значення',check='Перевірити відповідь',wrong='Ще не зовсім правильно. Спробуй знову.',right='Правильно! Наступне слово.',finished='Чудово! Тижневе повторення завершено.',done='Цього тижня ти вже все повторив.',back='До слова дня',progress='Прогрес',no_reward='Лише практика · без додаткових XP чи сердець',unavailable='Слово більше не опубліковане. Повторення зупинено; попроси менеджера оновити вміст.'))
WEEKLY_COPY['kmr'].update(dict(title='دووبارەکرنا هەفتانە',intro='پەیڤێن هەفتیا بوری کو تە ب دروستی نڤیسان دووبارە بکە.',open='پەیڤێن هەفتیا بوری دووبارە بکە',not_ready='هێشتا پەیڤێن تەواوکری یێن هەفتیا بوری نینن. هەر ڕۆژ پەیڤەکێ فێربە و هەفتیا داهاتی ڤەگەڕە.',course='سەرەتا کۆرسەکێ هەلبژێرە.',prompt='پەیڤا ئەڤ مانایێ بنڤیسە',meaning='مانا',check='وەڵامێ بپشکنە',wrong='هێشتا ڕاست نینە. دووبارە هەول بدە.',right='ڕاستە! پەیڤا داهاتی.',finished='ئافەرین! دووبارەکرنا هەفتانە تەواو کر.',done='ئەڤ هەفتیێ تە پێداچوونەوە کر.',back='زڤڕین بۆ پەیڤا ڕۆژێ',progress='پێشکەڤتن',no_reward='تەنها ڕاهێنان · XP یان دلێن زیادە نینن',unavailable='پەیڤەک چیتر بڵاوکری نینە. دووبارەکرن ڕاوەستیا؛ ژ بەڕێڤەبەری بخوازە ناڤەرۆکێ نوی بکەت.'))

"""Actual Django/SQLite or PostgreSQL integration scenarios for the Login release.

Run with an isolated test database; do not confuse these with offline source
checks. No real user accounts or SMTP provider are touched.
"""
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase, override_settings
from django.urls import reverse

from .models import Profile


@override_settings(MAILERS={'default':{'BACKEND':'django.core.mail.backends.locmem.EmailBackend'}})
class LoginV35IntegrationTests(TestCase):
    PASSWORD = 'Long-Unpredictable-Account-Password!2026'

    def setUp(self):
        cache.clear()
        self.user=get_user_model().objects.create_user(
            username='loginv35_learner', email='loginv35@example.test', password=self.PASSWORD
        )
        profile=self.user.learning_profile
        profile.placement_completed=True
        profile.onboarding_completed=True
        profile.save(update_fields=['placement_completed','onboarding_completed'])

    def test_many_valid_login_logout_cycles_do_not_lock_account(self):
        # Passwords accepted by Django never burn the failed-login budget.
        for n in range(14):
            identifier=self.user.email if n % 2 else self.user.username
            response=self.client.post(reverse('login'),{'email':identifier,'password':self.PASSWORD,'next':'/play/'})
            self.assertRedirects(response,'/play/',fetch_redirect_response=False)
            response=self.client.post(reverse('logout'))
            self.assertEqual(response.status_code,302)
        self.assertNotIn('_auth_user_id',self.client.session)

    def test_seven_failed_credentials_block_next_attempt_without_leaks(self):
        for n in range(7):
            identifier=self.user.email if n % 2 else self.user.username
            response=self.client.post(reverse('login'),{'email':identifier,'password':'wrong-password'})
            self.assertEqual(response.status_code,200)
        response=self.client.post(reverse('login'),{'email':self.user.email,'password':self.PASSWORD})
        self.assertEqual(response.status_code,429)
        self.assertEqual(response['Retry-After'],'900')
        self.assertContains(response,'name="csrfmiddlewaretoken"',status_code=429)
        self.assertContains(response,'data-auth-error-summary',status_code=429)
        self.assertNotIn('_auth_user_id',self.client.session)

    def test_mfa_disable_throttling_is_accessible_and_not_effective(self):
        self.client.force_login(self.user)
        profile=self.user.learning_profile
        profile.totp_secret='JBSWY3DPEHPK3PXP'
        profile.save(update_fields=['totp_secret'])
        with patch('academy.views.rate_limit',return_value=True):
            response=self.client.post(reverse('mfa_disable'),{'code':'000000'})
        self.assertEqual(response.status_code,429)
        self.assertEqual(response['Retry-After'],'900')
        self.assertContains(response,'role="alert"',status_code=429)
        self.assertContains(response,'/profile/',status_code=429)
        profile.refresh_from_db()
        self.assertTrue(profile.totp_secret)

    def test_mfa_disable_invalid_code_has_proper_feedback_without_removing_secret(self):
        self.client.force_login(self.user)
        profile=self.user.learning_profile
        profile.totp_secret='JBSWY3DPEHPK3PXP'
        profile.save(update_fields=['totp_secret'])
        response=self.client.post(reverse('mfa_disable'),{'code':'invalid-code'})
        self.assertEqual(response.status_code,403)
        self.assertContains(response,'role="alert"',status_code=403)
        profile.refresh_from_db()
        self.assertTrue(profile.totp_secret)

    def test_real_login_and_recovery_forms_all_have_one_css_bundle(self):
        for route in ('login','register','resend_verification','password_reset'):
            with self.subTest(route=route):
                response=self.client.get(reverse(route),{'ui':'ckb'})
                self.assertEqual(response.status_code,200)
                self.assertContains(response,'auth-v35-bundle.css')
                self.assertNotContains(response,'<link rel="stylesheet" href="/static/academy/auth-v26.css')
                self.assertContains(response,'lang="ckb"')
                self.assertContains(response,'dir="rtl"')
                self.assertContains(response,'csrfmiddlewaretoken')
                self.assertContains(response,'data-auth-submit')
                self.assertIn('no-store',response['Cache-Control'])

    def test_existing_eight_character_hash_remains_valid_and_uses_argon2(self):
        from django.contrib.auth.password_validation import validate_password
        from django.conf import settings
        candidate=get_user_model()(username='normallearner',email='normallearner@example.test')
        
        with self.assertRaises(Exception):
            validate_password('8uniQ!23',user=candidate)
        legacy=get_user_model().objects.create_user(username='legacy8',password='8uniQ!23')
        self.assertTrue(legacy.check_password('8uniQ!23'))
        self.assertEqual(settings.PASSWORD_HASHERS[0],'django.contrib.auth.hashers.Argon2PasswordHasher')

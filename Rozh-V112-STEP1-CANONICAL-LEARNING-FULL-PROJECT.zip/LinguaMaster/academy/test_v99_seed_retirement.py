"""Real Django integration tests. NOT counted as executed without Django runtime.

    python manage.py test academy.test_v99_seed_retirement --verbosity 2
"""
from io import StringIO

from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.test import TestCase

from academy.models import Language, Lesson, LessonProgress
from academy.starter_v10 import COURSE as EN
from academy.starter_de_v10 import COURSE as DE
from academy.starter_fr_v10 import COURSE as FR
from academy.management.commands.seed_curriculum import CURRICULUM as NL_SOURCE
from django.utils.text import slugify


class NewSeedExcludesUngradedExercises(TestCase):
    def test_all_four_language_new_seeds_have_no_ungraded_speaking_writing(self):
        call_command('seed_curriculum', stdout=StringIO())
        call_command('seed_languages_v10', stdout=StringIO())
        for code in ('nl', 'en', 'de', 'fr'):
            with self.subTest(course=code):
                self.assertFalse(Lesson.objects.filter(
                    unit__level__language__code=code,
                    skill__in=('speaking','writing'), published=True).exists())
                self.assertTrue(Lesson.objects.filter(
                    unit__level__language__code=code, skill='grammar',
                    published=True).exists())
                self.assertTrue(Lesson.objects.filter(
                    unit__level__language__code=code, skill='reading',
                    published=True).exists())


class RetireOldUngradedPages(TestCase):
    @classmethod
    def setUpTestData(cls):
        call_command('seed_curriculum', stdout=StringIO())
        call_command('seed_languages_v10', stdout=StringIO())
        cls.user = get_user_model().objects.create_user(
            username='v99-audit', email='v99@example.invalid', password='OnlyForTesting-2026')
        cls.to_retire = []
        for course in (EN, DE, FR):
            unit_data = course['units'][0]
            unit = (Language.objects.get(code=course['code'])
                    .levels.get(code=unit_data['level']).units.get(slug=unit_data['slug']))
            entry = next(x for x in unit_data['lessons'] if x['skill']=='speaking')
            lesson = Lesson.objects.create(
                unit=unit,slug='speaking',title=entry['title'],skill='speaking',
                content=entry['content'],audio_text=entry['audio_text'],order=4,published=True)
            cls.to_retire.append(lesson.pk)
            LessonProgress.objects.create(user=cls.user, lesson=lesson, score=0)
        dutch_topic = NL_SOURCE[0][2][0]
        title, explanation = dutch_topic[:2]
        nl_unit = (Language.objects.get(code='nl').levels.get(code='A0')
                   .units.get(slug=slugify(title)))
        dutch_content = ('Write four sentences about your own life using the lesson topic: '
                         + title + '.\n\nCheck the rule: ' + explanation + '\n\n'
                         'Read back your writing and correct any word-order, agreement or article mistakes. '
                         'Confirm completion only after reviewing your work.')
        dutch = Lesson.objects.create(
            unit=nl_unit,slug='writing',title='Write and revise',skill='writing',
            content=dutch_content,order=5,published=True)
        cls.to_retire.append(dutch.pk)
        # The old V99 prefix/suffix check incorrectly retired this Manager edit.
        cls.middle_edit = Lesson.objects.create(
            unit=nl_unit,slug='writing',title='Write and revise',skill='writing',
            content=dutch_content.replace('Check the rule: ', 'Manager edited the rule: '),
            order=8,published=True)
        cls.preserve = Lesson.objects.create(
            unit=nl_unit,slug='speaking',title='Speak with confidence',skill='speaking',
            content='Edited by Manager; never retire this authored content.',
            order=6,published=True)

    def test_dry_run_does_not_change_any_content_or_progress(self):
        out=StringIO()
        call_command('retire_starter_self_reviews',stdout=out)
        self.assertIn('DRY RUN; NO DATABASE CHANGES: 4',out.getvalue())
        self.assertEqual(Lesson.objects.filter(pk__in=self.to_retire,published=True).count(),4)
        self.assertEqual(LessonProgress.objects.filter(user=self.user).count(),3)

    def test_explicit_apply_unpublishes_only_exact_legacy_seeds(self):
        out=StringIO()
        call_command('retire_starter_self_reviews','--apply',stdout=out)
        self.assertIn('UNPUBLISHED: 4',out.getvalue())
        self.assertFalse(Lesson.objects.filter(pk__in=self.to_retire,published=True).exists())
        self.assertTrue(Lesson.objects.filter(pk=self.preserve.pk,published=True).exists())
        self.assertTrue(Lesson.objects.filter(pk=self.middle_edit.pk,published=True).exists())
        self.assertEqual(LessonProgress.objects.filter(user=self.user).count(),3)
        self.assertTrue(all(x==2 for x in Lesson.objects.filter(pk__in=self.to_retire)
                            .values_list('content_version',flat=True)))
        again=StringIO()
        call_command('retire_starter_self_reviews','--apply',stdout=again)
        self.assertIn('UNPUBLISHED: 0',again.getvalue())

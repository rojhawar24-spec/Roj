"""Rozh V18 Word-of-the-Day integration tests.

Run only with installed Django against Django's isolated TEST database:
    python manage.py test academy.test_daily_word_v18 --keepdb=False
These tests were authored for local execution; they are NOT run in the
release-building environment where Django is unavailable.
"""
from datetime import date
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Language, Level, Vocabulary, XPEvent, ReviewCard


class DailyWordV18Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            username='wordv18learner', email='wordv18@example.test', password='LocalOnly!Complex1234')
        cls.nl = Language.objects.create(code='nl', name='Nederlands', slug='v18-dutch', is_published=True)
        cls.fr = Language.objects.create(code='fr', name='Français', slug='v18-french', is_published=True)
        cls.dutch_level = Level.objects.create(language=cls.nl, code='A0', order=0)
        cls.french_level = Level.objects.create(language=cls.fr, code='A0', order=0)
        cls.dutch_word = Vocabulary.objects.create(
            level=cls.dutch_level, word='onderwerp', translation='subject',
            example='Dat is het onderwerp.', pronunciation='ON-duhr-werp', published=True)
        cls.french_word = Vocabulary.objects.create(
            level=cls.french_level, word='bonjour', translation='hello',
            example='Bonjour.', pronunciation='bon-zjoer', published=True)
        profile = cls.user.learning_profile
        profile.preferred_language = cls.nl
        profile.ui_language = 'nl'
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.save()

    def setUp(self):
        self.client.force_login(self.user)
        # Stable date so that all input variants see the same daily word.
        self.today_patch = patch('academy.services.user_localdate', return_value=date(2026, 11, 20))
        self.today_patch.start()
        self.addCleanup(self.today_patch.stop)

    def test_page_displays_word_translation_and_input(self):
        response = self.client.get(reverse('word'))
        self.assertEqual(response.status_code, 200)
        for expected in ('onderwerp', 'subject', 'name="answer"', 'csrfmiddlewaretoken'):
            self.assertContains(response, expected)
        self.assertNotContains(response, 'bonjour')

    def test_wrong_word_and_html_input_award_no_xp(self):
        for answer in ('subject', '', '<script>alert(1)</script>', '🚀', '-1', 'undefined'):
            response = self.client.post(reverse('word'), {'answer': answer})
            self.assertEqual(response.status_code, 200)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='daily_word').count(), 0)

    def test_long_post_rejected_without_reward(self):
        response = self.client.post(reverse('word'), {'answer': 'x' * 10001})
        self.assertEqual(response.status_code, 400)
        self.assertFalse(XPEvent.objects.filter(user=self.user, reason='daily_word').exists())

    def test_correct_awards_once_despite_double_submit(self):
        for _ in range(2):
            response = self.client.post(reverse('word'), {'answer': ' ONDERWERP '})
            self.assertEqual(response.status_code, 200)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='daily_word').count(), 1)
        self.assertTrue(ReviewCard.objects.filter(user=self.user, vocabulary=self.dutch_word).exists())
        self.user.learning_profile.refresh_from_db()
        self.assertEqual(self.user.learning_profile.xp, 10)

    def test_switching_language_same_day_cannot_repeat_reward(self):
        response = self.client.post(reverse('word'), {'answer': 'onderwerp'})
        self.assertEqual(response.status_code, 200)
        profile = self.user.learning_profile
        profile.preferred_language = self.fr
        profile.save(update_fields=['preferred_language'])
        response = self.client.post(reverse('word'), {'answer': 'bonjour'})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='daily_word').count(), 1)

    def test_new_day_can_award_again(self):
        self.client.post(reverse('word'), {'answer': 'onderwerp'})
        with patch('academy.services.user_localdate', return_value=date(2026, 11, 21)):
            response = self.client.post(reverse('word'), {'answer': 'onderwerp'})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='daily_word').count(), 2)

    def test_missing_course_cannot_earn(self):
        profile = self.user.learning_profile
        profile.preferred_language = None
        profile.save(update_fields=['preferred_language'])
        response = self.client.post(reverse('word'), {'answer': 'onderwerp'})
        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, 'bonjour')
        self.assertFalse(XPEvent.objects.filter(user=self.user, reason='daily_word').exists())

    def test_anonymous_cannot_earn(self):
        self.client.logout()
        response = self.client.post(reverse('word'), {'answer': 'onderwerp'})
        self.assertEqual(response.status_code, 200)
        self.assertFalse(XPEvent.objects.filter(reason='daily_word').exists())

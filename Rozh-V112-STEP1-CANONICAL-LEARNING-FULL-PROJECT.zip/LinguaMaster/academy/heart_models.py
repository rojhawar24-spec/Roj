"""Server-authoritative lesson hearts and an idempotent debit/recovery ledger."""
from django.conf import settings
from django.core.validators import MaxValueValidator
from django.db import models
from django.utils import timezone


class HeartBalance(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name='heart_balance')
    remaining = models.PositiveSmallIntegerField(default=5, validators=[MaxValueValidator(5)])
    regenerated_at = models.DateTimeField(default=timezone.now)

    class Meta:
        constraints = [models.CheckConstraint(condition=models.Q(remaining__gte=0, remaining__lte=5),
                                               name='hearts_between_zero_and_five')]

    def __str__(self):
        return f'{self.user_id}: {self.remaining}/5 hearts'


class HeartEvent(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                             related_name='heart_events')
    key = models.CharField(max_length=160)
    kind = models.CharField(max_length=8, choices=[('answer', 'Wrong answer'), ('recovery', 'Mistake corrected')])
    delta = models.SmallIntegerField()
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['user', 'key'], name='one_heart_event_per_user_key'),
            models.CheckConstraint(condition=models.Q(delta__gte=-1, delta__lte=1), name='heart_event_delta_bounded'),
        ]
        indexes = [models.Index(fields=['user', 'created_at'], name='heart_event_user_date')]

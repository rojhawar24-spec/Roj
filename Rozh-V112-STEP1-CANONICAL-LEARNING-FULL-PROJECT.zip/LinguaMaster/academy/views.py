"""SSR site, assessments, authentication, privacy, owner controls and SEO."""
import json
import secrets
import hashlib
import hmac
import base64
import io
import segno
import uuid
import logging
from smtplib import SMTPException
from datetime import timedelta
from django.conf import settings
from django import forms as django_forms
from django.contrib import messages
from django.contrib.auth import authenticate, get_user_model, login, logout
from django.contrib.auth.decorators import login_required
from .email_verification_tokens import email_verification_token_generator
from django.contrib.auth.views import PasswordResetView, PasswordResetDoneView, PasswordResetConfirmView, PasswordResetCompleteView
from django.core import signing
from django.core.mail import send_mail
from django.core.serializers.json import DjangoJSONEncoder
from django.db import transaction, connection, IntegrityError
from django.db.models import Count, Q, Sum
from django.http import Http404, HttpResponse, HttpResponseNotAllowed, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.encoding import force_bytes, force_str
from django.utils.safestring import mark_safe
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode, url_has_allowed_host_and_scheme
from django.views.decorators.http import require_GET, require_POST, require_safe, require_http_methods
from django.views.decorators.cache import never_cache
from django.views.decorators.debug import sensitive_post_parameters
from urllib.parse import urlsplit
from django.views.generic.base import View
import pyotp
from .models import (LEVELS,Language,Level,Unit,Lesson,Exercise,GrammarTopic,Vocabulary,Profile,LessonProgress,
                     Assessment,ReviewCard,DailyWordEntry,DailyWordWeeklySession,Friendship,Badge,BadgeAward,Certificate,ContentRevision,PlatformSettings,AIUsage,AuditEvent,XPEvent,MistakeRecord,DailyChest,AppNotification,ArenaRun,SkillPracticeAttempt)
from .forms import RegisterForm,LoginForm,MFACodeForm,ProfileForm,FriendForm,AIConfigurationForm,AITutorForm,OnboardingForm,PendingAccountPasswordResetForm
from .auth_security import verify_totp_step
from .account_signin_policy_v27 import account_signin_permitted
from .journey_policy_v39 import journey_round_allowed
from .review_policy_v36 import review_access_allowed
from .services import (rate_limit,rate_limit_exceeded,grade,allowed_unit,unit_lessons_done,level_units_passed,award_xp,save_review,issue_certificate,record_exercise_result,learning_level,daily_xp,user_localdate)
from .ai_service import AIUnavailable,tutor_reply
from .manager_roles_v48 import manager_only, has_manager_role, is_delegated_manager, verified_manager_session, has_privileged_assignments

User = get_user_model()
logger = logging.getLogger(__name__)

def audit(user,action,target,metadata=None):
    AuditEvent.objects.create(actor=user,action=action,target=str(target)[:160],metadata=metadata or {})


def owner_only(view):
    from functools import wraps
    @wraps(view)
    @login_required
    def inner(request,*args,**kwargs):
        if not request.user.is_superuser or not verified_manager_session(request):
            return HttpResponse('Owner access requires a superuser account and verified 2FA.',status=403)
        return view(request,*args,**kwargs)
    return inner


# Public homepage locale URLs are crawlable. Existing ?ui= links are retained
# as redirects, not indexed duplicates. Authenticated routing stays unchanged.
from .ui_languages_v74 import SUPPORTED_UI_LANGUAGES
HOME_LOCALES = SUPPORTED_UI_LANGUAGES
HOME_SEO = {
    'nl': ('Talen leren met Leer & Speel en grammatica | Rozh',
           'Leer talen stap voor stap met korte lessen, grammatica, luisteroefeningen en een eigen leerpad. Probeer gratis een voorbeeldles.'),
    'en': ('Learn languages with Learn & Play and grammar | Rozh',
           'Learn languages step by step with short lessons, grammar, listening practice and your own learning journey. Try a free sample lesson.'),
    'ckb': ('فێربوونی زمان بە وانە و گرامەر | Rozh',
            'بە هەنگاوە بچووکەکان زمان فێربە، گرامەر بخوێنە و پێشکەوتنت ببینە. وانەیەکی تاقیکردنەوە بەخۆڕایی تاقی بکەرەوە.'),
    'ar': ('تعلم اللغات بالدروس والقواعد | Rozh',
           'تعلم اللغات خطوة بخطوة مع دروس قصيرة وقواعد وتمارين استماع ومسار تعلم واضح. جرّب درسًا مجانيًا.'),
}
HOME_ACCESSIBILITY = {
    'nl': {'home':'Rozh — startpagina', 'navigation':'Hoofdnavigatie', 'language':'Kies de paginataal', 'skip':'Ga naar inhoud'},
    'en': {'home':'Rozh — home', 'navigation':'Main navigation', 'language':'Choose page language', 'skip':'Skip to content'},
    'ckb': {'home':'Rozh — پەڕەی سەرەتا', 'navigation':'ڕێنیشاندانی سەرەکی', 'language':'هەڵبژاردنی زمانی پەڕە', 'skip':'بڕۆ بۆ ناوەڕۆک'},
    'ar': {'home':'Rozh — الصفحة الرئيسية', 'navigation':'التنقل الرئيسي', 'language':'اختر لغة الصفحة', 'skip':'تخطي إلى المحتوى'},
}


@require_safe
def home(request, forced_locale=None):
    """Stable public localized home, preserving private learner routing."""
    if request.user.is_authenticated:
        # The public home must remain safe even for a migrated account with no
        # Profile, or an account suspended after its session was created. Do not
        # auto-recreate a Profile, expose private progress or route to a private
        # dashboard. This also matches the V46 live HTTP acceptance contract.
        current_user = User.objects.filter(pk=request.user.pk).first()
        profile = Profile.objects.filter(user_id=request.user.pk).first()
        if account_signin_permitted(current_user, profile):
            return _home_for_eligible_account(request, profile)
        # Invalidate the session, but render the public page instead of
        # redirecting or accidentally exposing signed-in template content.
        logout(request)

    return _render_public_home(request, forced_locale)


def _home_for_eligible_account(request, profile):
    """Preserve existing student and manager routing for eligible accounts."""
    if has_manager_role(request.user):
        # A live privileged role does not imply this browser session has
        # completed MFA. Send the person to the proper continuation flow
        # instead of redirecting them into a confusing 403 on /manager/.
        profile = request.user.learning_profile
        if not profile.totp_secret:
            return redirect('mfa_setup')
        if not verified_manager_session(request):
            return redirect('login')
        return redirect('manager')
    if profile.onboarding_required and not profile.onboarding_completed:
        return redirect('onboarding')
    if not profile.preferred_language_id and not profile.placement_completed:
        return redirect('courses')
    if not profile.placement_completed:
        return redirect('placement')
    return redirect('play_hub')


def _render_public_home(request, forced_locale=None):
    """Public SSR homepage; no private Profile or progress lookup is needed."""
    from .home_v23 import copy_for
    from .solar_landing_copy import copy_for as solar_copy_for
    from .auth_experience_v26 import visitor_language
    selected = request.GET.get('ui', '')
    if forced_locale in HOME_LOCALES:
        locale = forced_locale
        if request.session.get('public_ui_language') != locale:
            request.session['public_ui_language'] = locale
    elif selected in HOME_LOCALES:
        # Existing ?ui= links still work, but SEO URLs are canonical.
        visitor_language(request, default='nl')
        return redirect('home' if selected == 'nl' else 'home_'+selected)
    else:
        locale = visitor_language(request, default='nl')
        if locale != 'nl':
            return redirect('home_'+locale)

    labels = {'nl':'NL', 'en':'EN', 'ckb':'سۆرانی', 'kmr':'بادینی', 'ku':'Kurmancî', 'uk':'Українська', 'ar':'العربية', 'fr':'Français'}
    languages = Language.objects.filter(is_published=True).prefetch_related('levels')
    title, description = HOME_SEO[locale]
    url = reverse('home') if locale == 'nl' else reverse('home_'+locale)
    # Escape < to avoid script-breakout even if future copy contains markup.
    schema = {
        '@context':'https://schema.org', '@type':'WebApplication',
        'name':'Rozh', 'applicationCategory':'EducationalApplication',
        'operatingSystem':'Web', 'url':settings.SITE_URL+url,
        'description':description, 'inLanguage':locale,
    }
    return render(request, 'academy/home.html', {
        'languages':languages, 'H23':copy_for(locale), 'S5':solar_copy_for(locale),
        'H23_LOCALE_LABEL':labels[locale], 'HOME_PUBLIC':True,
        'HOME_ACCESSIBILITY':HOME_ACCESSIBILITY[locale],
        'HOME_SCHEMA_JSON':mark_safe(json.dumps(schema,ensure_ascii=False).replace('<',r'\u003c').replace('>',r'\u003e').replace('&',r'\u0026')),
        'UI_LANG':locale, 'UI_DIR':'rtl' if locale in ('ckb','ar') else 'ltr',
        'seo_title':title, 'seo_description':description, 'canonical_path':url,
    })


@require_safe
def home_en(request):
    return home(request, forced_locale='en')


@require_safe
def home_ckb(request):
    return home(request, forced_locale='ckb')


@require_safe
def home_ar(request):
    return home(request, forced_locale='ar')


@require_GET
def try_lesson(request):
    """Public, no-account, no-persistence Dutch A0 demo.

    All demo answers are necessarily client-visible. Never grant XP or CEFR
    progression from this route: authenticated lessons are server graded.
    """
    return render(request, 'academy/try_lesson.html', {
        'seo_title': 'Try a free Dutch mini-lesson',
        'seo_description': 'Play five original beginner Dutch exercises before creating an account.',
        'canonical_path': reverse('try_lesson'),
    })

def language_detail(request,slug):
    language=get_object_or_404(Language,slug=slug,is_published=True)
    levels=language.levels.prefetch_related('units')
    return render(request,'academy/language.html',{'language':language,'levels':levels,
        'seo_title':f'Learn {language.name}: lessons, grammar, practice', 'seo_description':language.description[:160],
        'canonical_path':language.get_absolute_url()})


def level_detail(request,slug,code):
    language=get_object_or_404(Language,slug=slug,is_published=True)
    level=get_object_or_404(Level,language=language,code__iexact=code)
    units=level.units.filter(published=True).prefetch_related('lessons')
    topics=level.grammar_topics.filter(published=True)
    from .assessment_availability_v105 import has_ready_assessment
    level_has_test = has_ready_assessment(level=level)
    return render(request,'academy/level.html',{'language':language,'level':level,'units':units,'topics':topics,
        'level_has_test':level_has_test,
        'canonical_path':level.get_absolute_url(),'seo_title':f'{language.name} {level.code} learning path',
        'seo_description':level.description[:160]})


@login_required
def unit_detail(request,pk):
    profile = Profile.objects.filter(user_id=request.user.pk).first()
    if not account_signin_permitted(request.user, profile):
        return HttpResponse('Account unavailable.', status=403)
    if profile.onboarding_required and not profile.onboarding_completed:
        return redirect('onboarding')
    unit=get_object_or_404(Unit.objects.select_related('level__language'),pk=pk,published=True,level__language__is_published=True)
    permitted=allowed_unit(request.user,unit)
    lessons=list(unit.lessons.filter(published=True).prefetch_related('exercises'))
    from .lesson_readiness_v96 import lesson_block_reason
    for entry in lessons:
        entry.v96_ready = lesson_block_reason(entry, course_code=unit.level.language.code,
            exercises=entry.exercises.all()) is None
    completed=set(LessonProgress.objects.filter(user=request.user,lesson__in=lessons).values_list('lesson_id',flat=True))
    from .journey_v11 import labels_for
    profile=request.user.learning_profile
    can_play=permitted and profile.placement_completed and profile.preferred_language_id==unit.level.language_id
    if can_play:
        from .journey_v11 import mixed_unit_block_reason
        can_play = mixed_unit_block_reason(unit) is None
    from .assessment_availability_v105 import has_ready_assessment
    has_unit_test = has_ready_assessment(unit=unit)
    from .lesson_unavailable_v96 import for_locale
    return render(request,'academy/unit.html',{'unit':unit,'lessons':lessons,'permitted':permitted,
        'R96':for_locale(profile.ui_language),
        'play_allowed':can_play,'JOURNEY_L':labels_for(request.user),
        'completed':completed,'ready':unit_lessons_done(request.user,unit),
        'has_unit_test':has_unit_test})

def _lesson_unavailable_page(request, lesson, reason):
    """Branded HTTP 409, never a white page; no progress/hearts/session changes."""
    from .lesson_unavailable_v96 import for_locale
    profile = request.user.learning_profile
    response = render(request, 'academy/lesson_unavailable_v96.html', {
        'lesson': lesson, 'unavailable_reason': reason,
        'R96': for_locale(profile.ui_language), 'noindex': True,
    }, status=409)
    response['Cache-Control'] = 'no-store, private'
    return response


def _locked_classic_lesson_admission(request, lesson):
    """Recheck a direct lesson POST from database rows before any XP/heart writes.

    Caller must already be inside transaction.atomic(). Lock in the same order
    across the SSR lesson form and the AJAX question route: Profile -> Unit ->
    Lesson -> Exercises. The initial GET/preflight check is never authorization
    for a later POST, because course, publication or account state may change.
    """
    profile = Profile.objects.select_for_update().filter(user=request.user).first()
    if profile is None:
        return None
    unit = (Unit.objects.select_for_update().select_related('level__language')
            .filter(pk=lesson.unit_id, published=True,
                    level__language__is_published=True).first())
    if unit is None:
        return None
    current_lesson = (Lesson.objects.select_for_update()
                      .filter(pk=lesson.pk, unit=unit, published=True).first())
    if current_lesson is None:
        return None
    user_active = User.objects.filter(pk=request.user.pk, is_active=True).exists()
    if not journey_round_allowed(profile, unit, user_active=user_active):
        return None
    if not allowed_unit(request.user, unit, profile=profile):
        return None
    return current_lesson, profile


@login_required
def lesson_detail(request,pk):
    profile = Profile.objects.filter(user=request.user).first()
    if profile is None:
        return HttpResponse('Account state incomplete.', status=403)
    if profile.onboarding_required and not profile.onboarding_completed:
        return redirect('onboarding')
    from .hearts import HeartEmpty, snapshot, spend_for_answer
    lesson=get_object_or_404(Lesson.objects.select_related('unit__level__language','unit__season'),pk=pk,published=True,
                              unit__published=True,unit__level__language__is_published=True)
    if not journey_round_allowed(profile, lesson.unit, user_active=request.user.is_active):
        return HttpResponse('This account or course is not available.', status=403)
    if not allowed_unit(request.user,lesson.unit):
        messages.error(request,'Complete the prerequisite unit test first.')
        return redirect('unit',pk=lesson.unit_id)
    # Shared canonical gate checks approval before any round/session/heart writes.
    exercises=list(lesson.exercises.all())
    from .lesson_readiness_v96 import lesson_block_reason
    from .lesson_activities_v58 import (public_activity, validate_answer, is_correct,
                                         lesson_content_fingerprint)
    reason = lesson_block_reason(lesson, exercises=exercises)
    if reason:
        return _lesson_unavailable_page(request, lesson, reason)
    signature_key = f'lesson_activity_signature_{lesson.pk}'
    round_session_key = f'lesson_round_{lesson.pk}'
    # A server-owned round token makes wrong-answer debits safe to replay.
    if request.method == 'GET':
        request.session[signature_key] = lesson_content_fingerprint(exercises, lesson=lesson)
        request.session.pop(f'lesson_answers_{lesson.pk}', None)
        # Explicit navigation starts a NEW round. Previously completed rounds
        # must not be reopened by replaying their old POST or AJAX payload.
        request.session.pop(f'lesson_completed_round_{lesson.pk}', None)
        request.session.pop(f'lesson_round_channel_{lesson.pk}', None)
        request.session[round_session_key] = secrets.token_hex(16)
    round_key = request.session.get(round_session_key)
    if not isinstance(round_key, str) or len(round_key) != 32:
        round_key = secrets.token_hex(16)
        request.session[round_session_key] = round_key
    supplied_round = request.POST.get('round_key', '') if request.method == 'POST' else ''
    # Step 3: every authored activity must submit its actual issued round.
    # Historical MCQ-only integrations are intentionally still supported.
    has_structured_activity = any(item.kind not in ('mcq', 'short') for item in exercises)
    if request.method == 'POST' and (
            (has_structured_activity and supplied_round != round_key)
            or (supplied_round and supplied_round != round_key)):
        return HttpResponse('This lesson round has expired. Reopen the lesson.', status=409)
    # Step 3G: never regrade an AJAX-checked question in a full SSR batch.
    # This is checked before any heart, XP or mistake database mutation.
    from .lesson_round_policy_step3c import round_channel_conflict
    if request.method == 'POST' and round_channel_conflict(
            request.session, lesson.pk, round_key, 'ssr'):
        return HttpResponse('This lesson round was graded one question at a time. Reopen the lesson.', status=409)
    # Successful rounds become immutable, even on the older SSR endpoint.
    # Only GET (the real "Start again" journey) may issue a fresh round.
    previously_completed = request.session.get(f'lesson_completed_round_{lesson.pk}')
    if (request.method == 'POST' and isinstance(previously_completed, dict) and
            previously_completed.get('key') == round_key):
        return HttpResponse('Lesson round already completed. Reopen the lesson.', status=409)
    feedback=[]
    blocked = False
    response_status = 200
    if request.method=='POST':
        if rate_limit(request,'lesson',40,3600,True): return HttpResponse('Too many submissions',status=429)
        # One outer transaction: if saving progress/XP fails, no hearts or
        # mistake edits from this submission may remain committed.
        with transaction.atomic():
            # Admission is checked again under row locks. A lesson that was
            # opened before suspension, course switch or unpublication must
            # never spend hearts, resolve mistakes or award XP on an old POST.
            admission = _locked_classic_lesson_admission(request, lesson)
            if admission is None:
                return HttpResponse('This lesson is no longer available. Reopen your current course.', status=403)
            lesson, profile = admission
            # Recheck the full canonical admission rule under locked admission.
            exercises = list(Exercise.objects.select_for_update()
                             .filter(lesson=lesson).order_by('order','pk'))
            reason = lesson_block_reason(lesson, exercises=exercises)
            if reason:
                return _lesson_unavailable_page(request, lesson, reason)
            # A visited classic lesson binds the complete authored question set
            # to its session, including legacy MCQ/short exercises. An editor
            # may change an answer without incrementing content_version; never
            # grade the old page against a newly edited question. Preserve the
            # historical direct-POST contract for old MCQ-only clients that did
            # not first load the lesson. V58 structured activities still require
            # a bound signature in every case.
            bound_signature = signature_key in request.session
            has_structured_activity = any(e.kind not in ('mcq', 'short') for e in exercises)
            if (bound_signature or has_structured_activity) and (
                    request.session.get(signature_key) != lesson_content_fingerprint(exercises, lesson=lesson)):
                return HttpResponse('Lesson content changed. Reopen the lesson.', status=409)
            if exercises:
                # Validate the entire batch before any debit, mistake or progress write.
                answer_keys = {f'answer_{exercise.pk}' for exercise in exercises}
                if any(key.startswith('answer_') and key not in answer_keys for key in request.POST):
                    return HttpResponse('Invalid lesson answer.', status=400)
                submissions = []
                for exercise in exercises:
                    submitted=request.POST.get(f'answer_{exercise.pk}','')
                    if not validate_answer(exercise, submitted, round_key):
                        return HttpResponse('Invalid lesson answer.', status=400)
                    submissions.append((exercise, submitted, is_correct(exercise, submitted, round_key)))
                from .lesson_batch_step3f import (
                    grade_ssr_batch, BatchHeartsExhausted, BatchReplayRejected)
                from .lesson_round_receipts_step3h import (
                    claim_round, finish_round, RoundReceiptConflict, RoundReceiptFinished)
                # A nested savepoint is essential: returning a 402 after some
                # wrong answers must not charge hearts or save partial mistakes.
                try:
                    with transaction.atomic():
                        # Step 3H: a DB row, not only a browser session flag,
                        # arbitrates overlapping AJAX and SSR submissions.
                        receipt = claim_round(user=request.user, lesson=lesson,
                                              round_key=round_key, channel='ssr')
                        correct, feedback = grade_ssr_batch(
                            submissions=submissions, user=request.user,
                            lesson_pk=lesson.pk, round_key=round_key,
                            snapshot=snapshot, spend_for_answer=spend_for_answer,
                            record_exercise_result=record_exercise_result,
                            heart_empty_exception=HeartEmpty)
                        candidate_score = round(100 * correct / len(exercises))
                        if has_structured_activity or candidate_score >= 70:
                            finish_round(receipt, score=candidate_score)
                except (RoundReceiptConflict, RoundReceiptFinished):
                    return HttpResponse('This round was already graded or used by another channel. Reopen the lesson.', status=409)
                except BatchHeartsExhausted:
                    blocked = True
                    correct = 0
                    feedback = []
                except BatchReplayRejected:
                    return HttpResponse('This question was already checked. Reopen the lesson.', status=409)
                score=round(100*correct/len(exercises)) if not blocked else 0
                if blocked:
                    response_status = 402
            else:
                # Defence in depth: no ungraded self-check can create progress.
                return _lesson_unavailable_page(request, lesson, 'activity')
            if not blocked and score>=70:
                with transaction.atomic():
                    progress,created=LessonProgress.objects.get_or_create(user=request.user,lesson=lesson,
                        defaults={'score':score,'content_version':lesson.content_version})
                    if created:
                        award_xp(request.user,20,reason='lesson',event_key=f'lesson:{lesson.pk}')
                        vocab_ids=set(Vocabulary.objects.filter(
                            level=lesson.unit.level,published=True).values_list('pk',flat=True))
                        if vocab_ids:
                            existing=set(ReviewCard.objects.filter(
                                user=request.user,vocabulary_id__in=vocab_ids
                            ).values_list('vocabulary_id',flat=True))
                            ReviewCard.objects.bulk_create(
                                [ReviewCard(user=request.user,vocabulary_id=vocab_id)
                                 for vocab_id in vocab_ids-existing],
                                ignore_conflicts=True, batch_size=500)
                messages.success(request,'Lesson complete. Great work!')
            elif not blocked:
                messages.error(request,'Score at least 70% to complete this lesson.')
            # Step 3G: claim the SSR channel only for an actually graded
            # batch. A 402/rejected batch keeps the round available to retry.
            if exercises and not blocked:
                from .lesson_round_policy_step3c import record_round_channel
                record_round_channel(request.session, lesson.pk, round_key, 'ssr')
            # Step 3C: a graded authored round is terminal whether it passed
            # or failed. Otherwise a learner could re-submit the *same* failed
            # batch with corrected answers and change the score without a new
            # round. Legacy MCQ/short failure retries remain compatible.
            if exercises and not blocked and (has_structured_activity or score >= 70):
                from .lesson_round_policy_step3c import seal_finished_round
                seal_finished_round(request.session, lesson.pk, round_key, score)
    finished=LessonProgress.objects.filter(user=request.user,lesson=lesson).exists()
    # Old templates retain this flag; self-review cannot issue new credit.
    self_review_saved = False  # Historical template compatibility; no new self-review credit.
    from .lesson_flow_v63 import for_language as flow_labels, next_step as flow_next_step
    flow = flow_labels(profile.ui_language)
    next_action = flow_next_step(request.user, lesson, profile=profile) if finished else None
    # Presentation metadata only: never changes grading, unlocks, XP or heart state.
    from .solar_atlas_step3 import lesson_presentation
    solar_lesson = lesson_presentation(lesson, request.user.learning_profile.ui_language)
    for item in exercises:
        item.v58 = public_activity(item, round_key) if item.kind not in ('mcq','short') else None
        item.answer_field_name = f'answer_{item.pk}'
    return render(request,'academy/lesson.html',{'lesson':lesson,'exercises':exercises,'finished':finished,
        'SOLAR_LESSON':solar_lesson,
        'feedback':feedback, 'self_review_saved':self_review_saved,
        'lesson_round_key':round_key, 'lesson_hearts':snapshot(request.user),
        'hearts_blocked':blocked, 'FLOW63':flow, 'FLOW63_NEXT':next_action}, status=response_status)


def grammar_library(request):
    topics=GrammarTopic.objects.filter(published=True,level__language__is_published=True).select_related('level__language')
    language_code=request.GET.get('language','')
    if not language_code and request.user.is_authenticated and request.user.learning_profile.preferred_language:
        language_code=request.user.learning_profile.preferred_language.code
    if language_code: topics=topics.filter(level__language__code=language_code)
    return render(request,'academy/grammar_library.html',{'topics':topics,'languages':Language.objects.filter(is_published=True),
        'seo_title':'Grammar explained, level by level','seo_description':'Examples, exceptions, typical mistakes and short grammar checks.'})


def grammar_detail(request,pk):
    topic=get_object_or_404(GrammarTopic.objects.select_related('level__language'),pk=pk,published=True,
                            level__language__is_published=True)
    feedback=None
    if request.method=='POST':
        feedback=(request.POST.get('answer','').casefold().strip()==topic.check_answer.casefold().strip())
    return render(request,'academy/grammar.html',{'topic':topic,'feedback':feedback,'canonical_path':topic.get_absolute_url(),
        'seo_title':f'{topic.title} — {topic.level.language.name} {topic.level.code}',
        'seo_description':topic.explanation[:160]})


def _daily_item(query, date=None):
    """Pick a stable daily item without loading an entire course into RAM."""
    date = date or timezone.localdate()
    total = query.count()
    if not total:
        return None
    # One successive position per calendar day; multiplying by 17 previously
    # made sets of 17 (or multiples of 17) repeat only one/two words forever.
    index = date.toordinal() % total
    return next(iter(query.order_by('id')[index:index + 1]), None)


@never_cache
@require_http_methods(["GET", "POST"])
def word_of_day(request):
    """V73: learner-local frozen daily word, one spelling and XP ONLY.

    Authenticated learners receive a DB-persisted daily assignment for their
    selected course. New content cannot change today's recorded assignment.
    No heart events are created on this path. XPEvent remains the only reward
    authority and its key is unique across course switches on a learner-day.
    """
    from .platform_v13 import labels_for
    from .daily_calendar_v73 import daily_for_learner, published_daily_word, weekly_labels
    from .services import user_localdate as learner_day
    from .daily_word_v18 import (DAILY_WORD_XP, MAX_ANSWER_LENGTH, daily_event_key,
                                 daily_reward_access_allowed, word_matches)

    language = request.user.learning_profile.preferred_language if request.user.is_authenticated else None
    vocab_qs = Vocabulary.objects.filter(published=True, level__language__is_published=True).select_related('level__language')
    topic_qs = GrammarTopic.objects.filter(published=True, level__language__is_published=True).select_related('level__language')
    if request.user.is_authenticated:
        if language is None or not language.is_published:
            vocab_qs, topic_qs = vocab_qs.none(), topic_qs.none()
        else:
            vocab_qs = vocab_qs.filter(level__language=language)
            topic_qs = topic_qs.filter(level__language=language)

    day = learner_day(request.user) if request.user.is_authenticated else timezone.localdate()
    entry = None
    if request.user.is_authenticated and language and language.is_published:
        entry = daily_for_learner(request.user, language, day)
        vocab = published_daily_word(entry)
    else:
        # Anonymous sample remains read-only and has no persisted word/XP.
        vocab = _daily_item(vocab_qs, day)
    topic = _daily_item(topic_qs, day)
    result = None
    new_reward = False
    key = daily_event_key(day)
    already_claimed = bool(request.user.is_authenticated and XPEvent.objects.filter(
        user=request.user, event_key=f'user:{request.user.pk}:{key}'
    ).exists())

    if request.method == 'POST':
        if rate_limit(request, 'daily-word', 30, 3600, True):
            return HttpResponse('Too many attempts. Please try again later.', status=429)
        submitted = request.POST.get('answer', '')
        if not isinstance(submitted, str) or len(submitted) > MAX_ANSWER_LENGTH:
            return HttpResponse('Answer too long.', status=400)
        if vocab is not None:
            result = word_matches(submitted, vocab.word)
            if result and request.user.is_authenticated and entry is not None:
                with transaction.atomic():
                    # Profile lock serializes course switching and the XP ledger.
                    profile = Profile.objects.select_for_update().get(user=request.user)
                    current = DailyWordEntry.objects.select_for_update().filter(
                        pk=entry.pk, user=request.user,
                        course_id=profile.preferred_language_id, day=day,
                        vocabulary_id=vocab.pk).first()
                    reward_authorized = (
                        current is not None
                        and daily_reward_access_allowed(profile, vocab.level.language_id)
                        and Language.objects.filter(pk=profile.preferred_language_id,
                                                    is_published=True).exists()
                        and Vocabulary.objects.filter(pk=vocab.pk, published=True,
                                  level__language_id=profile.preferred_language_id,
                                  level__language__is_published=True).exists()
                    )
                    if reward_authorized:
                        new_reward = award_xp(request.user, DAILY_WORD_XP, reason='daily_word',
                                              event_key=key, learning=True)
                        if current.completed_at is None:
                            current.completed_at = timezone.now()
                            current.save(update_fields=['completed_at'])
                        ReviewCard.objects.get_or_create(user=request.user, vocabulary=vocab)
                already_claimed = XPEvent.objects.filter(
                    user=request.user, event_key=f'user:{request.user.pk}:{key}'
                ).exists()

    from .grammar_v9 import _student_page
    daily_labels = labels_for(request)
    return render(request, 'academy/daily.html', {
        **_student_page(request, daily_labels['daily_word'], daily_labels['daily_intro']),
        'vocab': vocab, 'topic': topic, 'result': result,
        'daily_day': day, 'daily_xp_reward': DAILY_WORD_XP,
        'daily_reward_new': new_reward, 'daily_claimed': already_claimed,
        'D13': daily_labels, 'W73': weekly_labels(request.user) if request.user.is_authenticated else None,
        'course_selected': bool(language and language.is_published),
        'seo_title': 'Word of the day | Rozh',
        'seo_description': 'Learn one new daily word, practise spelling once, and review actual words weekly.',
        'canonical_path': reverse('word'),
        'noindex': request.user.is_authenticated,
    })


@never_cache
@login_required
@require_http_methods(["GET", "POST"])
def daily_weekly_review(request):
    """V73 weekly practice of learner's ACTUAL completed prior-week daily words.

    Exactly one DB-backed session per learner/course/ISO week; no XP or hearts.
    One server-checked answer advances one step; stale/replayed steps cannot
    skip words. The source set is frozen at the first visit in that week.
    """
    from .daily_calendar_v73 import (weekly_for_learner, weekly_labels,
                current_review_word, last_complete_week, monday)
    from .daily_word_v18 import MAX_ANSWER_LENGTH, word_matches
    from .services import user_localdate as learner_day
    from .grammar_v9 import _student_page
    locale = weekly_labels(request.user)
    course = request.user.learning_profile.preferred_language
    day = learner_day(request.user)
    source_start, source_end = last_complete_week(day)
    if not course or not course.is_published:
        return render(request, 'academy/daily_weekly_v73.html', {
            **_student_page(request, locale['title'], locale['intro']),
            'W73': locale, 'weekly_course_missing': True,
            'source_start': source_start, 'source_end': source_end,
        })
    session = weekly_for_learner(request.user, course, day)
    feedback = None
    if request.method == 'POST':
        if rate_limit(request, 'daily-weekly-spelling', 45, 3600, True):
            return HttpResponse('Too many weekly review attempts.', status=429)
        answer = request.POST.get('answer', '')
        if not isinstance(answer, str) or len(answer) > MAX_ANSWER_LENGTH:
            return HttpResponse('Answer too long.', status=400)
        try:
            posted_position = int(request.POST.get('position', '-1'))
        except (TypeError, ValueError):
            return HttpResponse('Invalid review position.', status=400)
        if session is None:
            return HttpResponse('No available weekly review.', status=409)
        with transaction.atomic():
            profile = Profile.objects.select_for_update().get(user=request.user)
            locked = DailyWordWeeklySession.objects.select_for_update().get(pk=session.pk, user=request.user)
            if (profile.preferred_language_id != course.pk or
                    not Language.objects.filter(pk=course.pk, is_published=True).exists() or
                    locked.week_start != monday(day)):
                return HttpResponse('Your course or week changed. Reload the page.', status=409)
            current = current_review_word(locked)
            if current is None or locked.completed_at:
                feedback = 'unavailable' if not locked.completed_at else 'done'
            elif posted_position != locked.position:
                return HttpResponse('Stale answer. Reload before continuing.', status=409)
            elif word_matches(answer, current['word']):
                locked.position += 1
                if locked.position == len(locked.items):
                    locked.completed_at = timezone.now()
                locked.save(update_fields=['position', 'completed_at'])
                feedback = 'correct'
            else:
                feedback = 'wrong'
        session.refresh_from_db()
    current_word = current_review_word(session)
    return render(request, 'academy/daily_weekly_v73.html', {
        **_student_page(request, locale['title'], locale['intro']),
        'W73': locale, 'weekly_session': session, 'weekly_word': current_word,
        'weekly_feedback': feedback, 'source_start': source_start, 'source_end': source_end,
        'seo_title': 'Weekly daily-word review | Rozh', 'noindex': True,
    })


@login_required
def review(request, weekly=False):
    # V71: retired Brain Training / flashcard screen. Keep old GET links safe;
    # V73 old GET /weekly-review/ forwards to the real weekly daily-word task.
    if request.method in ('GET', 'HEAD'):
        return redirect('daily_weekly_review' if weekly else 'word')

    if request.method == 'POST':
        if rate_limit(request, 'review-submit', 80, 3600, True):
            return HttpResponse('Review limit reached. Try again later.', status=429)
        try:
            quality = int(request.POST.get('quality', '-1'))
        except (ValueError, TypeError):
            quality = -1
        if quality not in range(6):
            return HttpResponse('Invalid recall score', status=400)
        with transaction.atomic():
            # Lock Profile before ReviewCard and XPEvent. Course switching and
            # reward paths use the same Profile-first serialization order.
            profile = Profile.objects.select_for_update().filter(user=request.user).first()
            course = (Language.objects.select_for_update()
                      .filter(pk=profile.preferred_language_id).first()
                      if profile is not None and profile.preferred_language_id else None)
            if not review_access_allowed(
                profile, user_active=request.user.is_active,
                course_published=bool(course and course.is_published),
            ):
                return HttpResponse('Finish your active course setup before reviewing.', status=403)
            # A card from an old course is NEVER authority to change a review
            # schedule or mint XP after the learner selects a different one.
            card = get_object_or_404(
                ReviewCard.objects.select_for_update(),
                user=request.user, pk=request.POST.get('card_id'),
                vocabulary__level__language_id=profile.preferred_language_id,
                vocabulary__published=True,
                vocabulary__level__language__is_published=True,
            )
            save_review(card, quality)
            if quality >= 3:
                # A review reward is once per card per LEARNER-local day, not
                # the web-server day (which may differ around midnight).
                award_xp(request.user, 2, reason='review',
                         event_key=f'review:{card.pk}:{user_localdate(request.user).isoformat()}')
        messages.success(request, 'Review scheduled.')
        return redirect('weekly_review' if weekly else 'review')

    # Unsupported verbs must never reach an old card review template.
    return HttpResponseNotAllowed(['GET', 'HEAD', 'POST'])

@login_required
def weekly_review(request):
    return review(request,weekly=True)


def _assessment_questions(unit=None,level=None,placement_mode=False,language=None):
    if placement_mode:
        from .placement_service import placement_questions
        return placement_questions(language)
    from .assessment_availability_v105 import ready_questions
    return ready_questions(unit=unit, level=level)


def _assessment_submission_allowed(request, kind, unit, level, profile):
    """Revalidate a submitted test under the caller's locked Profile row.

    The GET/pre-grade check is only a convenience. This is the authority for
    persisted attempts, mistakes, assessment XP and certificates. Profile lock
    serializes with course switches; course/content rows are checked afresh.
    """
    if ((profile.onboarding_required and not profile.onboarding_completed)
            or not profile.placement_completed):
        return False
    language_id = unit.level.language_id if kind == 'unit' else level.language_id
    if not language_id or profile.preferred_language_id != language_id:
        return False
    # Read under lock, not from an out-of-date request/ORM relation cache.
    live_language = Language.objects.select_for_update().filter(pk=language_id).first()
    if not live_language or not live_language.is_published:
        return False
    if kind == 'unit':
        live_unit = (Unit.objects.select_for_update().select_related('level')
                     .filter(pk=unit.pk, level_id=unit.level_id, published=True).first())
        return bool(live_unit and allowed_unit(request.user, live_unit, profile=profile)
                    and unit_lessons_done(request.user, live_unit))
    live_level = (Level.objects.select_for_update()
                  .filter(pk=level.pk, language_id=language_id).first())
    return bool(live_level and level_units_passed(request.user, live_level))


def _assessment_questions_unchanged(questions):
    """Fail safely if an educator unpublished/changed questions while grading."""
    question_ids = [question.pk for question in questions]
    # Lock teaching content in a stable order: Unit -> Lesson -> Exercise.
    # This prevents a concurrent unpublish/edit from slipping between our
    # eligibility check and the XP/certificate write.
    expected_units = {q.lesson.unit_id: q.lesson.unit.level_id for q in questions}
    live_units = {item.pk: item for item in Unit.objects.select_for_update()
                  .filter(pk__in=list(expected_units))}
    if (len(live_units) != len(expected_units)
            or any(not live_units[pk].published or live_units[pk].level_id != level_id
                   for pk, level_id in expected_units.items())):
        return False
    lesson_ids = {q.lesson_id for q in questions}
    live_lessons = {item.pk: item for item in Lesson.objects.select_for_update()
                    .filter(pk__in=list(lesson_ids))}
    if (len(live_lessons) != len(lesson_ids)
            or any(not live_lessons[q.lesson_id].published
                   or live_lessons[q.lesson_id].unit_id != q.lesson.unit_id
                   or live_lessons[q.lesson_id].skill != q.lesson.skill
                   or live_lessons[q.lesson_id].audio_text != q.lesson.audio_text
                   for q in questions)):
        return False
    current = {
        item.pk: item for item in Exercise.objects.select_for_update()
        .filter(pk__in=question_ids)
    }
    if len(current) != len(question_ids):
        return False
    fields = ('kind', 'lesson_id', 'answer', 'prompt', 'options', 'activity_data', 'explanation')
    from .assessment_policy_v103 import ASSESSMENT_KINDS, assessment_ready
    return all(q.kind in ASSESSMENT_KINDS and
               all(getattr(current[q.pk], field) == getattr(q, field) for field in fields) and
               assessment_ready(q, q.lesson.unit.level.language.code)
               for q in questions)


def _take_test(request,kind,unit=None,level=None):
    if request.method not in ('GET', 'HEAD', 'POST'):
        return HttpResponseNotAllowed(['GET', 'HEAD', 'POST'])
    if kind=='unit' and not (allowed_unit(request.user,unit) and unit_lessons_done(request.user,unit)):
        return HttpResponse('Complete all required lessons and prerequisites first.',status=403)
    if kind=='level':
        # A historical passed unit may be kept after switching language. It
        # must not authorize new XP/certificates for a different course or let
        # a partially onboarded learner bypass setup via the direct URL.
        profile = request.user.learning_profile
        if ((profile.onboarding_required and not profile.onboarding_completed)
                or not profile.placement_completed
                or profile.preferred_language_id != level.language_id
                or not level.language.is_published):
            return HttpResponse('Complete setup and select this course first.', status=403)
        if not level_units_passed(request.user, level):
            return HttpResponse('Pass all unit tests first.',status=403)
    from .assessment_policy_v103 import (assessment_responses, assessment_message,
                                        assessment_rows, assessment_snapshot, INDEXED_KINDS,
                                        assessment_audio_text, assessment_audio_url)
    from django.utils.crypto import constant_time_compare
    questions=_assessment_questions(unit,level)
    if not questions:
        return render(request,'academy/assessment.html',{'questions':[], 'unit':unit, 'level':level, 'kind':kind, 'assessment_unavailable':assessment_message(request.user.learning_profile.ui_language, unavailable=True)}, status=503)
    snapshot = assessment_snapshot(questions, request.user.pk, kind, unit.pk if unit else level.pk)
    for question in questions:
        question.assessment_rows = assessment_rows(question)
        if assessment_audio_text(question) is not None:
            question.assessment_audio = assessment_audio_url(question, question.lesson.unit.level.language.code)
            if not question.assessment_audio:
                return render(request,'academy/assessment.html',{'questions':[], 'unit':unit, 'level':level, 'kind':kind, 'assessment_unavailable':assessment_message(request.user.learning_profile.ui_language, unavailable=True)}, status=503)
    report=None
    if request.method=='POST':
        if rate_limit(request,'assessment',20,3600,True): return HttpResponse('Too many tests',status=429)
        supplied = request.POST.getlist('assessment_snapshot')
        # Indexed answers cannot be interpreted against a different edition of
        # the question. Legacy simple POST clients remain compatible.
        requires_snapshot = any(q.kind in INDEXED_KINDS or assessment_audio_text(q) is not None for q in questions)
        if ((requires_snapshot or supplied) and
                (len(supplied) != 1 or not constant_time_compare(supplied[0], snapshot))):
            return render(request,'academy/assessment.html',{'questions':questions, 'unit':unit, 'level':level, 'kind':kind, 'assessment_snapshot':snapshot, 'assessment_error':assessment_message(request.user.learning_profile.ui_language, unavailable=False)}, status=409)
        responses = assessment_responses(questions, request.POST)
        if responses is None:
            return render(request,'academy/assessment.html',{'questions':questions, 'unit':unit, 'level':level, 'kind':kind, 'assessment_snapshot':snapshot, 'assessment_error':assessment_message(request.user.learning_profile.ui_language, unavailable=False)}, status=400)
        graded=[(q,grade(q,responses[f'q_{q.pk}'])) for q in questions]
        correct=sum(passed for _,passed in graded)
        score=round(correct*100/len(questions))
        passed=score>=80
        with transaction.atomic():
            # The mistake ledger, assessment attempt, XP, and certificate are
            # one unit of work. A later failure must not leave a partial grade.
            current_profile = Profile.objects.select_for_update().get(user=request.user)
            if not _assessment_submission_allowed(request,kind,unit,level,current_profile):
                return HttpResponse('Assessment access changed. Choose the current course and try again.',status=403)
            if not _assessment_questions_unchanged(questions):
                return HttpResponse('Assessment content changed. Reload the test and try again.',status=409)
            for item,correct_answer in graded:
                if responses[f'q_{item.pk}']:
                    record_exercise_result(request.user,item,correct_answer)
            already_passed=Assessment.objects.filter(user=request.user,kind=kind,unit=unit,level=level,passed=True).exists()
            Assessment.objects.create(user=request.user,kind=kind,unit=unit,level=level,score=score,passed=passed,
                                      responses={str(q.pk):responses[f'q_{q.pk}'] for q in questions})
            if passed:
                if not already_passed:
                    award_xp(request.user,100 if kind=='level' else 40,reason='assessment',event_key=f'{kind}:{unit.pk if unit else level.pk}')
                if kind=='level' and not Certificate.objects.filter(user=request.user,level=level,revoked_at__isnull=True).exists():
                    issue_certificate(request.user,level)
        report={'score':score,'passed':passed}
    return render(request,'academy/assessment.html',{'questions':questions,'unit':unit,'level':level,'kind':kind,'report':report,'assessment_snapshot':snapshot})

@login_required
def assessment_unit(request,pk):
    # A withdrawn course may retain historic learner records, but may not
    # issue new assessment results, certificates or XP while unpublished.
    unit=get_object_or_404(Unit,pk=pk,published=True,level__language__is_published=True)
    return _take_test(request,'unit',unit=unit)

@login_required
def assessment_level(request,pk):
    level=get_object_or_404(Level,pk=pk,language__is_published=True)
    return _take_test(request,'level',level=level)

@login_required
def placement(request):
    from .courses_v10 import record_current_course
    from .placement_service import placement_result
    profile=request.user.learning_profile
    from .onboarding_copy_v52 import localized_copy
    placement_locale = profile.ui_language if profile.ui_language in ('en', 'nl', 'ckb', 'ar') else 'en'
    placement_copy = localized_copy(placement_locale)
    placement_skip = {'en': 'Start as a beginner instead', 'nl': 'Begin toch bij A0',
                      'ckb': 'لەبری ئەوە لە A0 دەست پێ بکە', 'ar': 'ابدأ من A0 بدلاً من ذلك'}[placement_locale]
    if profile.placement_completed:
        return redirect(_post_setup_destination(request))
    # V77: when a full teacher-reviewed bank exists, use the professional
    # 15-question flow; retain this legacy quiz only for old course compatibility.
    from .placement_adaptive_v77 import smart_placement_available
    if profile.preferred_language_id and smart_placement_available(profile.preferred_language):
        return redirect('smart_placement_v77')
    # A learner without a current, published course must choose a real course
    # before entering an assessment. Do not show an unanswerable quiz or use
    # a withdrawn language's questions. New signups still finish setup first.
    if profile.onboarding_required and not profile.onboarding_completed:
        return redirect('onboarding')
    if not profile.preferred_language_id or not profile.preferred_language.is_published:
        return redirect('courses')
    if request.method == 'POST' and request.POST.get('skip_placement') == '1':
        if rate_limit(request, 'placement-skip', 8, 3600, True):
            return HttpResponse('Too many attempts.', status=429)
        if not profile.preferred_language_id:
            return redirect('courses')
        from .courses_v10 import switch_course
        try:
            switch_course(request.user, profile.preferred_language, start_at_a0=True)
        except Language.DoesNotExist:
            return redirect('courses')
        return redirect(_post_setup_destination(request))
    questions=_assessment_questions(placement_mode=True,language=profile.preferred_language)
    if not questions:
        return render(request, 'academy/assessment.html', {
            'questions': [], 'kind': 'placement', 'report': None,
            'placement_unavailable': True, 'assessment_parent': 'academy/onboarding_shell_v52.html',
            'R52_placement_unavailable': placement_copy['placement_unavailable'],
            'R52_placement_skip': placement_skip, 'locale': placement_locale, 'L': placement_copy,
            'noindex': True,
        })
    report=None
    if request.method=='POST':
        if rate_limit(request,'placement',5,3600,True): return HttpResponse('Placement attempts exceeded',status=429)
        try:
            result=placement_result(questions,request.POST)
        except ValueError as exc:
            return HttpResponse(str(exc),status=400)
        score,band=result['score'],result['band']
        with transaction.atomic():
            current=Profile.objects.select_for_update().get(pk=profile.pk)
            if current.placement_completed:
                return redirect(_post_setup_destination(request))
            if current.preferred_language_id != profile.preferred_language_id:
                return HttpResponse('Your course changed. Reload the starting-point quiz.',status=409)
            profile=current
            level=next(q.lesson.unit.level for q in questions if q.lesson.unit.level.code==band)
            Assessment.objects.create(user=request.user,kind='placement',level=level,score=score,
                                      passed=True,responses=result['responses'])
            profile.placement_level=band
            profile.placement_completed=True
            profile.save(update_fields=['placement_level','placement_completed'])
            record_current_course(profile)
        report={'score':score,'band':band}
    destination = None
    if report:
        destination = _post_setup_destination(request)
    return render(request,'academy/assessment.html',{'questions':questions,'kind':'placement','report':report,
        'post_setup_destination':destination or reverse('play_hub'),
        'assessment_parent': 'academy/onboarding_shell_v52.html',
        'R52_placement_skip': placement_skip, 'locale': placement_locale, 'L': placement_copy,
        'noindex': True})



def _email_verification_url(request, user, destination=''):
    """Send localhost verification to the exact localhost origin used at signup.

    Cookies for localhost and 127.0.0.1 are separate. Linking to a different
    development host loses the pending registration session and causes a second
    login prompt. Production always uses the configured canonical SITE_URL.
    A user-supplied Host header can NEVER set production email links.
    """
    from urllib.parse import urlencode
    uid = urlsafe_base64_encode(force_bytes(user.pk))
    token = email_verification_token_generator.make_token(user)
    path = reverse('verify_email', args=[uid, token])
    site = settings.SITE_URL
    if settings.DEBUG:
        origin = request.build_absolute_uri('/')
        if urlsplit(origin).hostname in ('localhost', '127.0.0.1', '::1'):
            site = origin.rstrip('/')
    link = site + path
    destination = _safe_after_login(request, destination)
    if destination:
        link += '?' + urlencode({'next': destination})
    return link


@sensitive_post_parameters('password1')
def register(request):
    destination = _safe_after_login(request, request.POST.get('next', '') if request.method == 'POST' else request.GET.get('next', ''))
    config=PlatformSettings.load()
    if not config.public_registration_enabled:return HttpResponse('Registration is currently closed.',status=503)
    form=RegisterForm(request.POST or None)
    from .auth_experience_v26 import auth_context, apply_form_accessibility
    context=auth_context(request, form, destination, True)

    def render_registration(status=200):
        # Keep the real localized form, CSRF token and recovery navigation
        # visible even when too many attempts have been made.
        apply_form_accessibility(form)
        response = render(request, 'academy/auth.html', {
            'form': form, 'heading': 'Create your account', 'submit_label': 'Create account',
            'page_help': 'For privacy, this platform currently accepts learners aged 16 and above.',
            'next_destination': destination, 'seo_title': 'Create account', **context,
        }, status=status)
        if status == 429:
            response['Retry-After'] = '3600'
            response['Cache-Control'] = 'no-store'
        return response

    if request.method == 'POST' and rate_limit(request, 'register', 6, 3600):
        # Registration has a one-hour limit, unlike login's 15-minute limit.
        # Do not show login's incorrect '15 minutes' guidance here.
        from .auth_flow_v32 import FLOW_COPY
        from .auth_experience_v26 import visitor_language
        form.add_error(None, FLOW_COPY[visitor_language(request)]['try_later'])
        return render_registration(status=429)
    if request.method=='POST' and form.is_valid():
        email = form.cleaned_data['email']
        try:
            with transaction.atomic():
                # Keep case-insensitive duplicate checks under a row lock;
                # never activate or modify existing accounts via signup.
                locked_settings = PlatformSettings.objects.select_for_update().get(pk=config.pk)
                if not locked_settings.public_registration_enabled:
                    return HttpResponse('Registration is currently closed.', status=503)
                duplicate = (User.objects.filter(email__iexact=email).exists() or
                             User.objects.filter(username__iexact=form.cleaned_data['username']).exists())
                require_verification = settings.REQUIRE_EMAIL_VERIFICATION
                user = None if duplicate else User.objects.create_user(
                    username=form.cleaned_data['username'], email=email,
                    password=form.cleaned_data['password1'], is_active=not require_verification)
                if user is not None:
                    state = Profile.objects.select_for_update().get(user=user)
                    state.onboarding_required = True
                    if require_verification:
                        # Prevent old V40/V41 password-only recovery shortcut
                        # from activating an email-pending *new* registration.
                        state.email_verification_version = 1
                        state.save(update_fields=['onboarding_required', 'email_verification_version'])
                    else:
                        state.save(update_fields=['onboarding_required'])
        except IntegrityError:
            user = None
        if settings.REQUIRE_EMAIL_VERIFICATION:
            # Bind a *new* pending registration only to the browser that knows
            # its freshly chosen password. A link opened on a different device
            # still verifies ownership but requires an ordinary password login.
            # Do not keep a prior candidate when a duplicate signup was made.
            request.session.pop('registration_pending_user_id', None)
            # Do not carry the previous registration's destination into a new
            # attempt (including a duplicate or an attempt with no ?next=).
            request.session.pop('registration_pending_next', None)
            if user is not None:
                request.session.cycle_key()
                request.session['registration_pending_user_id'] = user.pk
            # Identical public response for new and duplicate identifiers.
            # Never reveal whether a submitted address/username was already used.
            # A mail transport failure is logged without the email/token.
            # Inactive pending users can request a new link with rate limits.
            if user is not None:
                try:
                    link = _email_verification_url(request, user, destination)
                    sent = send_mail('Confirm your Rozh email',
                                     f'Confirm your email within 24 hours: {link}',
                                     settings.DEFAULT_FROM_EMAIL, [user.email], fail_silently=False)
                    if sent != 1:
                        logger.error('Registration mailer did not accept message; user stays pending')
                except Exception as exc:
                    # Keep user inactive. Do not print addresses, links, or SMTP secrets.
                    logger.error('Registration email transport failed: %s', type(exc).__name__)
            if destination and user is not None:
                request.session['registration_pending_next'] = destination
            return redirect('registration_check_email')
        if user is not None:
            # Local default: retain the pre-existing immediate sign-in behavior.
            if destination:
                request.session['post_auth_next'] = destination
            login(request, user)
            request.session['mfa_verified_id'] = None
            return redirect(_after_sign_in(request, user))
        messages.info(request, context['A26']['generic_registration'])
        return redirect('login')
    return render_registration()


@require_GET
def registration_check_email(request):
    """Non-enumerating registration outcome; no account identifiers or tokens."""
    from .registration_experience import confirmation_copy
    from .auth_experience_v26 import visitor_language
    language = visitor_language(request)
    destination = _safe_after_login(request, request.session.get('registration_pending_next', ''))
    response = render(request, 'academy/registration_check_email.html', {
        'R40': confirmation_copy(language, settings.REQUIRE_EMAIL_VERIFICATION),
        'require_email_verification': settings.REQUIRE_EMAIL_VERIFICATION,
        'local_development': (settings.DEBUG and
            settings.MAILERS['default']['BACKEND'] == 'django.core.mail.backends.filebased.EmailBackend'),
        'PRIVATE_PAGE': True,
        'noindex': True,
        'seo_title': confirmation_copy(language, settings.REQUIRE_EMAIL_VERIFICATION)['title'],
        'next_destination': destination,
    })
    response['Cache-Control'] = 'no-store'
    response['Referrer-Policy'] = 'no-referrer'
    return response


def resend_verification(request):
    """A localized account-recovery screen with non-enumerating feedback."""
    from django import forms
    from .auth_flow_v32 import flow_context
    class EmailForm(forms.Form):
        email = forms.EmailField(max_length=150, widget=forms.EmailInput(attrs={
            'autocomplete': 'email', 'autocapitalize': 'none', 'spellcheck': 'false',
        }))
    form = EmailForm(request.POST or None, initial={'email':request.user.email} if request.user.is_authenticated else None)
    destination = _safe_after_login(request, request.POST.get('next', '') if request.method == 'POST' else request.GET.get('next', ''))
    context = flow_context(request, form, destination)

    def render_resend(status=200):
        from .auth_experience_v26 import apply_form_accessibility
        apply_form_accessibility(form)
        response = render(request, 'academy/auth_flow_v32.html', {
            **context, 'form': form, 'flow_title': context['F32']['resend_title'],
            'flow_desc': context['F32']['resend_desc'],
            'flow_action': context['F32']['resend_action'],
            'seo_title': context['F32']['resend_title'],
        }, status=status)
        if status == 429:
            response['Retry-After'] = '3600'
            response['Cache-Control'] = 'no-store'
        return response

    if request.method == 'POST':
        if rate_limit(request, 'resend-email', 4, 3600):
            form.add_error(None, context['F32']['try_later'])
            return render_resend(status=429)
        if form.is_valid():
            # Account-scoped protection prevents email flooding from changing IPs.
            if rate_limit(request, 'resend-email-address', 4, 3600,
                          account_identifier=form.cleaned_data['email']):
                form.add_error(None, context['F32']['try_later'])
                return render_resend(status=429)
            candidate = (User.objects.filter(
                email__iexact=form.cleaned_data['email'],
                is_staff=False, is_superuser=False,
                learning_profile__email_verified_at__isnull=True,
                learning_profile__suspended_at__isnull=True,
                learning_profile__legacy_review_required=False).first())
            if candidate:
                link = _email_verification_url(request, candidate, destination)
                try:
                    send_mail('Confirm your Rozh email', f'Confirm your email within 24 hours: {link}',
                              settings.DEFAULT_FROM_EMAIL, [candidate.email])
                except (OSError, SMTPException):
                    logger.error('Verification resend mail gateway failed; inspect SMTP health without logging message content')
            messages.success(request, context['F32']['resend_notice'])
            if request.user.is_authenticated:
                return redirect('profile')
            if destination:
                from urllib.parse import urlencode
                return redirect(reverse('login') + '?' + urlencode({'next': destination}))
            return redirect('login')
    return render_resend()


def _email_activation_permitted(user, profile):
    """An email link proves ownership, never authority to lift a suspension."""
    return bool(
        user and not user.is_staff and not user.is_superuser and profile
        and profile.email_verified_at is None
        and profile.suspended_at is None
        and not profile.legacy_review_required
    )


@require_http_methods(["GET", "POST"])
def verify_email(request, uidb64, token):
    """GET previews a token; CSRF-protected POST completes email ownership.

    Email-scanning bots may GET URLs. GET cannot change account state. Lock both
    user and profile on POST so a manager block cannot race activation.
    """
    from .auth_flow_v32 import FLOW_COPY
    from .auth_experience_v26 import visitor_language
    copy = FLOW_COPY[visitor_language(request)]
    raw_next = request.POST.get('next', '') if request.method == 'POST' else request.GET.get('next', '')
    destination = _safe_after_login(request, raw_next)
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.filter(pk=uid).first()
    except (ValueError, TypeError, OverflowError, UnicodeDecodeError):
        user = None
    profile = Profile.objects.filter(user=user).first() if user else None

    def finish_response(response):
        response['Cache-Control'] = 'no-store'
        response['Referrer-Policy'] = 'no-referrer'
        return response

    # A valid link sent before an owner block must not override that block.
    eligible = (_email_activation_permitted(user, profile)
                and email_verification_token_generator.check_token(user, token))
    if request.method == 'GET':
        if not eligible:
            messages.error(request, copy['verify_invalid'])
            return finish_response(redirect('login'))
        from .auth_flow_v32 import flow_context
        return finish_response(render(request, 'academy/verify_email_confirm.html', {
            **flow_context(request, destination=destination),
            'flow_title': copy['verify_title'],
            'flow_desc': copy['verify_confirm_desc'],
            'flow_action': copy['verify_confirm_action'],
            'next_destination': destination,
            'flow_back': copy['back_login'],
            'seo_title': copy['verify_title'],
        }))

    verified = False
    if user and eligible:
        with transaction.atomic():
            locked = User.objects.select_for_update().filter(pk=user.pk).first()
            locked_profile = (Profile.objects.select_for_update().filter(user=locked).first()
                              if locked else None)
            if (_email_activation_permitted(locked, locked_profile)
                    and email_verification_token_generator.check_token(locked, token)):
                locked_profile.email_verified_at = timezone.now()
                locked_profile.save(update_fields=['email_verified_at'])
                if not locked.is_active:
                    locked.is_active = True
                    locked.save(update_fields=['is_active'])
                verified = True
    if verified:
        try:
            send_mail('Welcome to Rozh',
                      'Your email is verified. Your learning path is ready.',
                      settings.DEFAULT_FROM_EMAIL, [user.email])
        except (OSError, SMTPException):
            logger.error('Welcome mail gateway failed; account verification remains successful')
        messages.success(request, copy['verify_success'])
        # This session already proved the password during registration (or
        # through a later pending-login attempt). Verification now proves email
        # ownership. Avoid another confusing password prompt for that browser.
        if request.session.get('registration_pending_user_id') == user.pk:
            request.session.pop('registration_pending_user_id', None)
            intended = destination or _safe_after_login(
                request, request.session.pop('registration_pending_next', ''))
            request.session.pop('registration_pending_next', None)
            if intended:
                request.session['post_auth_next'] = intended
            user.refresh_from_db()
            login(request, user)
            request.session['mfa_verified_id'] = None
            return finish_response(redirect(_after_sign_in(request, user)))
    else:
        messages.error(request, copy['verify_invalid'])
    if destination and verified:
        from urllib.parse import urlencode
        return finish_response(redirect(reverse('login') + '?' + urlencode({'next': destination})))
    return finish_response(redirect('login'))


def _safe_after_login(request, raw):
    """Never redirect a learner to an external or unsafe auth URL.

    Django's ?next= survives the sign-in screen and the TOTP step, but only
    local absolute-path destinations are accepted. Onboarding/placement still
    take priority for new learners.
    """
    if not isinstance(raw, str) or len(raw) > 1024 or not raw.startswith('/') or raw.startswith('//'):
        return ''
    if not url_has_allowed_host_and_scheme(raw, allowed_hosts={request.get_host()}, require_https=request.is_secure()):
        return ''
    path = urlsplit(raw).path
    if path.startswith(('/login/', '/logout/', '/register/', '/verify/', '/reset/',
                        '/password-reset/', '/mfa/', '/secure-admin/')):
        return ''
    return raw


# Only actual learner GET destinations may be resumed after signup/setup.
# An internal URL is not automatically a safe next step: a route can mutate
# data, initiate a checkout, or be reserved for staff and account recovery.
POST_SETUP_LEARNER_DESTINATIONS = frozenset({
    'play_hub', 'learn_path', 'dashboard', 'vocabulary', 'grammar_library',
    'grammar', 'mistakes', 'word', 'friends', 'leaderboard', 'profile',
    'avatar_studio', 'ai_tutor', 'review', 'weekly_review', 'arena',
    'chest', 'notifications', 'tests_hub_v16', 'skill_practice',
    'adaptive_practice', 'practice_hub', 'language', 'level', 'unit',
    'lesson', 'journey_play', 'assessment_unit', 'assessment_level',
})


def _post_setup_destination(request):
    """Consume a previously chosen learner page once, fail closed otherwise.

    After validating a same-origin absolute path, resolve the concrete Django
    route and only resume a documented learner GET page. This prevents an
    internal checkout/account action URL from becoming the first landing page.
    Original query parameters survive for approved pages.
    """
    from django.urls import Resolver404, resolve
    raw = request.session.pop('post_auth_next', '')
    intended = _safe_after_login(request, raw)
    if intended:
        try:
            match = resolve(urlsplit(intended).path)
        except Resolver404:
            pass
        else:
            if match.url_name in POST_SETUP_LEARNER_DESTINATIONS:
                return intended
    return reverse('play_hub')


def _after_sign_in(request, user):
    """Complete required onboarding before honoring any intended local page."""
    # All privileged accounts must enrol MFA before entering the platform.
    # Owner/admin page permissions still independently enforce the MFA session.
    if (user.is_staff or user.is_superuser or is_delegated_manager(user)) and not user.learning_profile.totp_secret:
        return 'mfa_setup'
    # Managers administer the platform; do not require a learner placement
    # quiz before showing the owner-only console. The destination remains
    # permission-checked by the manager view itself.
    if has_manager_role(user):
        request.session.pop('post_auth_next', None)
        return reverse('manager')
    if (user.learning_profile.onboarding_required and
            not user.learning_profile.onboarding_completed):
        return 'onboarding'
    if not user.learning_profile.preferred_language_id and not user.learning_profile.placement_completed:
        return 'courses'
    if not user.learning_profile.placement_completed:
        return 'placement'
    return _post_setup_destination(request)


@sensitive_post_parameters('password')
def login_view(request):
    destination=_safe_after_login(request, request.POST.get('next', '') if request.method=='POST' else request.GET.get('next',''))
    if not destination:
        destination = _safe_after_login(request, request.session.get('post_auth_next', ''))
    if request.user.is_authenticated:
        # Fail closed after a Profile was removed while a session remained valid.
        # In particular, a previously privileged account must not bypass MFA.
        current_profile = Profile.objects.filter(user=request.user).first()
        if not account_signin_permitted(request.user, current_profile):
            # Session authentication is not sufficient after administrative
            # quarantine/suspension, even if is_active remained True.
            logger.warning('Login session denied: account state is not eligible')
            logout(request)
            return redirect('login')
        # Upgrade an existing authenticated but unverified MFA session. This
        # occurs on session recovery or when a staff member adds MFA elsewhere.
        if destination:
            request.session['post_auth_next'] = destination
        if request.user.learning_profile.totp_secret and request.session.get('mfa_verified_id') != request.user.pk:
            from .pending_mfa_binding_step2 import try_start_pending_mfa
            if not try_start_pending_mfa(request.session, request.user, current_profile):
                # Invalid factor inventory: never bypass MFA or show HTTP 500.
                logger.warning('Existing session MFA state invalid; requiring sign-in')
                logout(request)
                return redirect('login')
            request.session.set_expiry(300)
            return redirect('mfa_verify')
        return redirect(_after_sign_in(request, request.user))
    form=LoginForm(request.POST or None)
    from .auth_experience_v26 import auth_context, apply_form_accessibility
    context = auth_context(request, form, destination, False)
    def render_login(status=200):
        # Keep the real accessible login form visible even when throttled;
        # never return an unstyled raw 429 that looks like a broken page.
        apply_form_accessibility(form)
        response = render(request, 'academy/auth.html', {
            'form': form, 'heading': 'Sign in', 'submit_label': 'Sign in',
            'page_help': 'Forgot your password?', 'link_url': reverse('password_reset'),
            'link_text': 'Reset password', 'next_destination': destination,
            'seo_title': context['A26']['signin'],
            # Only display local operator support on the loopback development
            # server. Public sign-in always shows the same generic response
            # regardless of whether an identifier exists or is held for review.
            'LOCAL_LOGIN_HELP': (settings.DEBUG and
                urlsplit(request.build_absolute_uri('/')).hostname in
                ('localhost', '127.0.0.1', '::1')),
            **context,
        }, status=status)
        if status == 429:
            response['Retry-After'] = '900'
        return response

    if request.method=='POST':
        if rate_limit_exceeded(request,'login-ip',12,900):
            form.add_error(None,context['A26']['rate_limited'])
            return render_login(status=429)
        if form.is_valid():
            identifier=form.cleaned_data['email'].strip()
            match=(User.objects.filter(email__iexact=identifier).first() or
                   User.objects.filter(username__iexact=identifier).first())
            account_key=f'user:{match.pk}' if match else f'unknown:{identifier}'
            if rate_limit_exceeded(request, 'login-account', 7, 900, account_identifier=account_key):
                form.add_error(None,context['A26']['rate_limited'])
                return render_login(status=429)
            # Django's ModelBackend performs a dummy password hash for unknown
            # usernames. Always call authenticate to mitigate timing enumeration.
            user=authenticate(request, username=match.username if match else identifier,
                              password=form.cleaned_data['password'])
            if user is not None:
                # A verified password is NOT enough to recover missing role,
                # suspension, verification or MFA state from an absent Profile.
                # Avoid RelatedObjectDoesNotExist/HTTP 500, and never create a
                # fresh default Profile that could erase those restrictions.
                current_profile = Profile.objects.filter(user=user).first()
                if not account_signin_permitted(user, current_profile):
                    # Reject stale administrative state after password proof,
                    # BEFORE session rotation, MFA initiation or authenticated
                    # user session creation. Keep a generic public response.
                    logger.warning('Sign-in denied: account state is not eligible')
                    form.add_error(None, context['A26']['auth_failed'])
                    return render_login(status=403)
                # Preserve a validated public UI locale across session rotation.
                # Flush protects against session fixation; keep that protection.
                public_locale = request.session.get('public_ui_language')
                request.session.flush()
                if public_locale in HOME_LOCALES:
                    request.session['public_ui_language'] = public_locale
                if destination:
                    request.session['post_auth_next']=destination
                if user.learning_profile.totp_secret:
                    from .pending_mfa_binding_step2 import try_start_pending_mfa
                    if not try_start_pending_mfa(request.session, user, current_profile):
                        logger.warning('Password accepted but stored MFA state invalid')
                        request.session.flush()
                        form.add_error(None, context['A26']['auth_failed'])
                        return render_login(status=403)
                    request.session.set_expiry(300)
                    return redirect('mfa_verify')
                login(request,user)
                request.session['mfa_verified_id']=None
                return redirect(_after_sign_in(request,user))
            # Migration convenience for V40/V41 learners who were left pending.
            # A proven password may open learning without an email link, but
            # legacy quarantine, suspension, and privileged accounts MUST stay
            # inactive. Keep the check inside a transaction to prevent races
            # with a manager block. Existing verified inactive accounts are
            # not reactivated by this shortcut.
            if (not settings.REQUIRE_EMAIL_VERIFICATION and match is not None
                    and not match.is_active and not (match.is_staff or match.is_superuser)):
                profile = Profile.objects.filter(user=match).first()
                if (_email_activation_permitted(match, profile) and
                        not profile.onboarding_required and
                        profile.email_verification_version == 0 and
                        match.check_password(form.cleaned_data['password'])):
                    with transaction.atomic():
                        locked = User.objects.select_for_update().get(pk=match.pk)
                        state = Profile.objects.select_for_update().get(user=locked)
                        if (_email_activation_permitted(locked, state) and
                                not state.onboarding_required and
                                state.email_verification_version == 0 and
                                locked.check_password(form.cleaned_data['password'])):
                            locked.is_active = True
                            locked.save(update_fields=['is_active'])
                            user = authenticate(request, username=locked.username,
                                                password=form.cleaned_data['password'])
                    if user is not None:
                        public_locale = request.session.get('public_ui_language')
                        request.session.flush()
                        if public_locale in HOME_LOCALES:
                            request.session['public_ui_language'] = public_locale
                        if destination:
                            request.session['post_auth_next'] = destination
                        login(request, user)
                        request.session['mfa_verified_id'] = None
                        return redirect(_after_sign_in(request, user))
            # Count *failed* credentials only. Correct logins must not burn a
            # learner's seven-attempt account budget or shared-IP budget.
            account_blocked = rate_limit(request, 'login-account', 7, 900,
                                         account_identifier=account_key)
            ip_blocked = rate_limit(request,'login-ip',12,900)
            if account_blocked or ip_blocked:
                form.add_error(None, context['A26']['rate_limited'])
                return render_login(status=429)
            form.add_error(None, context['A26']['auth_failed'])
    return render_login()


@sensitive_post_parameters('code')
@require_http_methods(['GET', 'POST'])
def mfa_verify(request):
    pk=request.session.get('pending_mfa_user_id')
    if not pk:return redirect('login')
    from .pending_mfa_binding_step2 import pending_mfa_matches, clear_pending_mfa
    user=User.objects.filter(pk=pk,is_active=True).first()
    profile=Profile.objects.filter(user=user).first() if user else None
    if (user is None or profile is None or not profile.totp_secret
            or profile.suspended_at is not None or profile.legacy_review_required
            or not pending_mfa_matches(request.session, user, profile)):
        clear_pending_mfa(request.session)
        return redirect('login')
    form=MFACodeForm(request.POST or None)
    from .auth_experience_v26 import auth_context, apply_form_accessibility
    context = auth_context(request, form, '', False)
    form.fields['code'].label=context['A26']['mfa_code_label']
    form.fields['code'].help_text=context['A26']['mfa_code_help']
    form.fields['code'].widget.attrs.update({'autocomplete':'one-time-code', 'inputmode':'text',
                                            'autocapitalize':'characters', 'spellcheck':'false'})
    def render_mfa(status=200):
        apply_form_accessibility(form)
        response = render(request, 'academy/mfa_verify.html', {
            'form': form, 'next_destination': request.session.get('post_auth_next', ''),
            'seo_title': context['A26']['mfa_heading'], **context,
        }, status=status)
        response['Cache-Control'] = 'no-store'
        if status == 429:
            response['Retry-After'] = '900'
        return response

    if request.method=='POST':
        # Probe the FAILED-attempt buckets first. A correct TOTP/recovery code
        # must not exhaust the eight-failure budget merely by signing in again.
        # If the shared cache fails, rate_limit_exceeded() fails closed.
        if (rate_limit_exceeded(request, 'mfa', 8, 900) or
                rate_limit_exceeded(request, 'mfa-account', 8, 900,
                                    account_identifier=f'user:{user.pk}')):
            form.add_error(None, context['A26']['rate_limited'])
            return render_mfa(status=429)
        if form.is_valid():
            code=form.cleaned_data['code']
            # Hold the row lock for both TOTP and recovery codes. OTP replay
            # must not succeed through two concurrent verification requests.
            with transaction.atomic():
                # Lock user first, matching the manager's user->profile order.
                # A suspension/role revocation after the password step must
                # not be bypassed with a still-valid TOTP/recovery code.
                locked_user=User.objects.select_for_update().get(pk=user.pk)
                profile=Profile.objects.select_for_update().filter(user=locked_user).first()
                still_eligible=(profile is not None and locked_user.is_active
                    and profile.suspended_at is None
                    and not profile.legacy_review_required
                    and pending_mfa_matches(request.session, locked_user, profile))
                if still_eligible and (locked_user.is_staff or locked_user.is_superuser
                        or is_delegated_manager(locked_user)):
                    from .manager_roles_v48 import privileged_account_eligible
                    still_eligible=privileged_account_eligible(locked_user, profile)
                matched=verify_totp_step(profile,code) if still_eligible else False
                if matched is False and still_eligible and len(code)==16:
                    from .recovery_code_consumption_step2 import consume_recovery_hashes
                    remaining=consume_recovery_hashes(profile.mfa_recovery_hashes, code, settings.SECRET_KEY)
                    if remaining is not None:
                        # In a malformed legacy DB, one recovery hash may occur
                        # more than once. Remove *all* copies atomically.
                        profile.mfa_recovery_hashes=remaining
                        profile.save(update_fields=['mfa_recovery_hashes'])
                        matched=True
                        audit(user,'recovery_code_used',user.pk)
            if not still_eligible:
                clear_pending_mfa(request.session)
                return redirect('login')
            if matched:
                login(request,locked_user)
                # An already-authenticated browser can complete its pending
                # second factor without Django login() rotating the session.
                # Rotate explicitly on privilege elevation so a pre-MFA
                # session cookie never remains valid after verification.
                request.session.cycle_key()
                clear_pending_mfa(request.session)
                request.session['mfa_verified_id']=user.pk
                request.session.set_expiry(None)
                return redirect(_after_sign_in(request,user))
        # Only an attempted, unsuccessful code is counted. A pending or
        # expired MFA session is handled above without logging a code.
        from .auth_audit_v13 import record_auth_event
        record_auth_event('mfa_failure', user=user)
        # Count unsuccessful verification only, including malformed codes.
        # Keep independent per-IP and per-account limits against distributed
        # guessing; both are checked even when one has just reached its limit.
        mfa_account_blocked = rate_limit(request,'mfa-account',8,900,
                                         account_identifier=f'user:{user.pk}')
        mfa_ip_blocked = rate_limit(request, 'mfa', 8, 900)
        if mfa_account_blocked or mfa_ip_blocked:
            form.add_error(None, context['A26']['rate_limited'])
            return render_mfa(status=429)
        form.add_error(None,context['A26']['mfa_failed'])
    return render_mfa()

@sensitive_post_parameters('password', 'code')
@login_required
@require_http_methods(['GET', 'POST'])
def mfa_setup(request):
    profile=Profile.objects.filter(user=request.user).first()
    if not account_signin_permitted(request.user, profile):
        logger.warning('MFA enrollment denied: account state is not eligible')
        logout(request)
        return redirect('login')
    if profile.totp_secret:
        if request.session.get('mfa_verified_id') != request.user.pk:
            from .pending_mfa_binding_step2 import try_start_pending_mfa
            if not try_start_pending_mfa(request.session, request.user, profile):
                logger.warning('MFA enrollment session state invalid; requiring sign-in')
                logout(request)
                return redirect('login')
            request.session.set_expiry(300)
            return redirect('mfa_verify')
        messages.info(request,'Two-factor authentication is already active.')
        return redirect('profile')
    secret=request.session.get('mfa_setup_secret')
    if not secret:
        secret=pyotp.random_base32()
        request.session['mfa_setup_secret']=secret
    # A valid, already-authenticated browser session is NOT sufficient to
    # register a new authentication factor (OWASP ASVS 5.0 V7.5.1).
    # Never cache a successful password check in the session.
    from .mfa_disable_policy_v86 import password_label
    from .mfa_enroll_policy_v87 import enrollment_error, verify_enrollment_password
    from .mfa_enroll_step_v88 import matched_enrollment_step
    form=MFACodeForm(request.POST or None)
    form.fields['password'] = django_forms.CharField(
        label=password_label(profile.ui_language), min_length=1, max_length=1024,
        strip=False, widget=django_forms.PasswordInput(attrs={
            'autocomplete':'current-password', 'maxlength':'1024'}))
    from .auth_flow_v32 import flow_context
    context = flow_context(request, form)
    form.fields['code'].label = context['A26']['mfa_code_label']
    form.fields['code'].help_text = context['A26']['mfa_code_help']
    form.fields['code'].widget.attrs.update({'autocomplete':'one-time-code', 'inputmode':'numeric',
                                              'pattern':'[0-9]{6}', 'maxlength':'6'})
    throttled = False
    if request.method=='POST':
        throttled = rate_limit(request,'mfa-setup',8,900,True)
        if throttled:
            form.add_error(None, context['F32']['try_later'])
        elif form.is_valid():
            # Fail without writing an MFA seed if password OR OTP is invalid.
            # The same generic message avoids disclosing which factor failed.
            password = form.cleaned_data['password']
            code = form.cleaned_data['code']
            # Verify the exact step, NOT merely whether this code falls
            # inside an accepted window. Store the matched step to prevent
            # reusing a future-step code after the time boundary moves.
            prechecked_step = (matched_enrollment_step(pyotp.TOTP(secret), code)
                if verify_enrollment_password(request.user, password) else None)
            if prechecked_step is None:
                form.add_error(None, enrollment_error(profile.ui_language))
            else:
                # Both account state and password are checked again while the
                # User -> Profile rows are locked. Account deactivation and
                # password changes racing the enrollment must not succeed.
                with transaction.atomic():
                    locked_user = User.objects.select_for_update().get(pk=request.user.pk)
                    locked_profile = Profile.objects.select_for_update().get(user=locked_user)
                    if not account_signin_permitted(locked_user, locked_profile):
                        request.session.pop('mfa_setup_secret', None)
                        logout(request)
                        return redirect('login')
                    if locked_profile.totp_secret:
                        request.session.pop('mfa_setup_secret', None)
                        messages.info(request, 'Two-factor authentication is already active.')
                        return redirect('profile')
                    # Recheck the OTP inside the locked transaction as
                    # well as the password. Never persist a stale/wrong step.
                    locked_step = matched_enrollment_step(pyotp.TOTP(secret), code)
                    if (not verify_enrollment_password(locked_user, password)
                            or locked_step is None or locked_step != prechecked_step):
                        form.add_error(None, enrollment_error(profile.ui_language))
                    else:
                        recovery_codes=[secrets.token_hex(8).upper() for _ in range(8)]
                        locked_profile.totp_secret=secret
                        locked_profile.mfa_last_totp_step=locked_step
                        locked_profile.mfa_recovery_hashes=[hmac.new(settings.SECRET_KEY.encode(),item.encode(),hashlib.sha256).hexdigest() for item in recovery_codes]
                        locked_profile.save(update_fields=['totp_secret','mfa_last_totp_step','mfa_recovery_hashes'])
                if not form.errors:
                    # MFA enrollment changes session assurance. Invalidate
                    # the pre-enrollment session identifier while retaining
                    # only the authenticated current session state.
                    request.session.cycle_key()
                    request.session['mfa_recovery_codes_once']=recovery_codes
                    request.session.pop('mfa_setup_secret',None)
                    request.session['mfa_verified_id']=request.user.pk
                    audit(request.user,'mfa_enabled',request.user.pk)
                    messages.success(request,'Two-factor authentication enabled.')
                    return redirect('mfa_recovery')
        elif not throttled:
            # Field-specific errors already show missing credentials; never
            # reveal whether the OTP alone was valid.
            form.add_error(None, enrollment_error(profile.ui_language))
    uri=pyotp.TOTP(secret).provisioning_uri(name=request.user.email,issuer_name='Rozh')
    stream=io.BytesIO()
    segno.make(uri,micro=False,error='m').save(stream,kind='svg',scale=5,border=2)
    qr_uri='data:image/svg+xml;base64,'+base64.b64encode(stream.getvalue()).decode('ascii')
    from .auth_experience_v26 import apply_form_accessibility
    apply_form_accessibility(form)
    response=render(request,'academy/mfa_setup.html',{'secret':secret,'uri':uri,'form':form,'qr_uri':qr_uri, **context},
                    status=429 if throttled else 200)
    response['Cache-Control']='no-store'
    if throttled:
        response['Retry-After']='900'
    return response

@login_required
@require_GET
def mfa_recovery(request):
    current_profile = Profile.objects.filter(user=request.user).first()
    if not account_signin_permitted(request.user, current_profile):
        # One-time recovery codes must not be displayed to a session that was
        # revoked after the MFA enrollment POST.
        logout(request)
        return redirect('login')
    codes=request.session.pop('mfa_recovery_codes_once',None)
    if not codes:return redirect('profile')
    from .auth_flow_v32 import flow_context
    response=render(request,'academy/mfa_recovery.html',{'codes':codes, **flow_context(request)})
    response['Cache-Control']='no-store'
    return response

@login_required
@sensitive_post_parameters('password', 'code')
@require_POST
def mfa_disable(request):
    # Verify account integrity BEFORE localized feedback or throttling:
    # authenticated templates can require the Profile context. Without this
    # check, a missing Profile could still trigger HTTP 500 on 403/429 paths.
    existing_profile = Profile.objects.filter(user=request.user).first()
    if not account_signin_permitted(request.user, existing_profile):
        logger.warning('MFA disable denied: account state is not eligible')
        logout(request)
        return redirect('login')
    # Superusers can exist without is_staff in legacy databases. Never let a
    # privileged account silently downgrade its MFA requirements.
    from .auth_experience_v26 import visitor_language
    from .auth_flow_v32 import FLOW_COPY
    copy = FLOW_COPY[visitor_language(request)]

    def feedback(message_key, status):
        response = render(request, 'academy/mfa_disable_feedback.html', {
            'feedback_heading': copy['mfa_disable_title'],
            'feedback_message': copy[message_key],
            'feedback_return': copy['mfa_disable_back'],
            'seo_title': copy['mfa_disable_title'],
        }, status=status)
        response['Cache-Control'] = 'no-store'
        if status == 429:
            response['Retry-After'] = '900'
        return response

    if has_privileged_assignments(request.user):
        return feedback('mfa_disable_privileged', 403)
    if rate_limit(request, 'mfa-disable', 6, 900, True):
        return feedback('try_later', 429)
    # Changing MFA is a sensitive account operation. Reauthenticate with
    # BOTH the current password and an unused TOTP, not a TOTP alone.
    # Never log either credential or echo it back to the form.
    code = request.POST.get('code', '')
    password = request.POST.get('password', '')
    from .mfa_disable_policy_v86 import verify_disable_credentials
    with transaction.atomic():
        # Lock User then Profile in the same order as mfa_verify and manager
        # account mutations, so a concurrent suspension/role change is caught.
        locked_user = User.objects.select_for_update().filter(pk=request.user.pk).first()
        profile = Profile.objects.select_for_update().filter(user=locked_user).first()
        if not account_signin_permitted(locked_user, profile):
            logger.warning('MFA disable denied: locked account state is not eligible')
            logout(request)
            return redirect('login')
        if has_privileged_assignments(locked_user):
            return feedback('mfa_disable_privileged', 403)
        if not verify_disable_credentials(locked_user, password, profile, code,
                                          verify_totp_step):
            return feedback('mfa_disable_invalid', 403)
        profile.totp_secret=''
        profile.mfa_last_totp_step=-1
        profile.mfa_recovery_hashes=[]
        profile.save(update_fields=['totp_secret','mfa_last_totp_step','mfa_recovery_hashes'])
    # MFA removal is another sensitive factor-state transition: the old
    # session identifier must not survive even for an ordinary learner.
    request.session.cycle_key()
    request.session['mfa_verified_id']=None
    audit(request.user,'mfa_disabled',request.user.pk)
    messages.success(request,'Two-factor authentication disabled.')
    return redirect('profile')

@login_required
@require_POST
def logout_view(request):
    # A new anonymous session must not inherit authentication state. Carry
    # across only the explicit public language preference.
    public_locale = request.session.get('public_ui_language')
    logout(request)
    if public_locale in HOME_LOCALES:
        request.session['public_ui_language'] = public_locale
    return redirect('home')

def _learning_path_data(user):
    """Compose the app path from actual database progress, not a hard-coded UI mockup."""
    profile = user.learning_profile
    language = profile.preferred_language
    # Never display a different course just because the selected course was
    # unpublished or the learner has not selected one. The student must choose
    # the new course explicitly; no progress or enrollment is modified here.
    if language is None or not language.is_published:
        return {'language': None, 'stages': [], 'next_url': None,
                'next_title': 'Choose a course', 'total_lessons': 0,
                'done_lessons': 0, 'progress_percent': 0}
    levels = list(Level.objects.filter(language=language).order_by('order').prefetch_related(
        'units__lessons__exercises', 'units__prerequisites'
    ))
    # Ignore historic completions for unpublished lessons or units; otherwise
    # the visible course may show >100% progress or an incorrect next lesson.
    completed = set(LessonProgress.objects.filter(
        user=user, lesson__unit__level__language=language,
        lesson__published=True, lesson__unit__published=True).values_list('lesson_id', flat=True))
    passed = set(Assessment.objects.filter(user=user, kind='unit', passed=True,
                unit__level__language=language).values_list('unit_id',flat=True))
    # Separate authored requirements from actually playable assessments.
    from .assessment_availability_v105 import unit_assessment_inventory
    required_test_ids, units_with_questions = unit_assessment_inventory(language.pk)
    passed_level_ids = set(Assessment.objects.filter(
        user=user, kind='level', passed=True, level__language=language
    ).values_list('level_id', flat=True))
    published_levels = [level for level in levels
                        if any(unit.published for unit in level.units.all())]
    # Same season gate is used here and in direct lesson/assessment URLs.
    # Pass existing batched progress sets to avoid N+1 queries with 100 seasons.
    from .season_unlock_v70 import access_for_user
    season_access = access_for_user(user, language.pk, levels=levels,
        completed_lesson_ids=completed, passed_unit_ids=passed,
        unit_test_ids=required_test_ids)
    from .lesson_readiness_v96 import lesson_block_reason
    stages, choices = [], []
    cefr_rank = {code: index for index, (code, _) in enumerate(LEVELS)}
    total_lessons = 0
    for level in levels:
        items = []
        for unit in level.units.all():
            if not unit.published:
                continue
            lessons = [lesson for lesson in unit.lessons.all() if lesson.published]
            if not lessons:
                continue
            ready_by_pk = {row.pk: lesson_block_reason(row, course_code=language.code,
                exercises=row.exercises.all()) is None for row in lessons}
            total_lessons += len(lessons)
            done = sum(1 for lesson in lessons if lesson.pk in completed)
            # Same policy as allowed_unit(user, unit), with preloaded result sets.
            unlocked = allowed_unit(user, unit, passed_unit_ids=passed,
                                    passed_level_ids=passed_level_ids,
                                    published_levels=published_levels,
                                    season_access=season_access)
            passed_test = unit.pk in passed
            if passed_test:
                state = 'done'
                # Completed nodes link to a published lesson for review,
                # not the old multi-panel unit overview.
                playable_review = next((row for row in lessons if ready_by_pk[row.pk]), None)
                url = playable_review.get_absolute_url() if playable_review else None
            elif not unlocked:
                state = 'locked'
                url = unit.get_absolute_url()
            elif done == len(lessons):
                # No unit-check link unless at least one canonical question is ready.
                # The lessons remain reviewable until the manager publishes one.
                state = 'test' if unit.pk in units_with_questions else 'pending_content'
                url = reverse('assessment_unit', args=[unit.pk]) if state == 'test' else None
            else:
                next_lesson = next(lesson for lesson in lessons if lesson.pk not in completed)
                if ready_by_pk[next_lesson.pk]:
                    state = 'active'
                    url = next_lesson.get_absolute_url()
                else:
                    state = 'pending_content'
                    url = None
            pending_note = {
                'nl':'De unittoets is nog niet gepubliceerd.',
                'en':'The unit test has not been published yet.',
                'ckb':'تاقیکردنەوەی ئەم بەشە هێشتا بڵاو نەکراوەتەوە.',
                'ar':'لم يُنشر اختبار هذه الوحدة بعد.',
            }.get(profile.ui_language, 'The unit test has not been published yet.')
            if state == 'pending_content' and done != len(lessons):
                pending_note = {
                    'nl':'De volgende les is in voorbereiding. De Manager moet de opname of oefening goedkeuren.',
                    'en':'The next lesson is being prepared. Audio or an exercise still needs editorial approval.',
                    'ckb':'وانەی داهاتوو لە ئامادەکردندایە. دەنگ یان ڕاهێنان پێویستی بە پەسەندکردنە.',
                    'ar':'الدرس التالي قيد الإعداد. يحتاج التسجيل أو التمرين إلى الموافقة.',
                }.get(profile.ui_language, 'The next lesson needs editorial approval.')
            item = {'unit':unit,'done':done,'total':len(lessons),
                    'percent':round(100*done/len(lessons)),'state':state,'url':url,
                    'pending_note':pending_note if state == 'pending_content' else '',
                    'passed_test':passed_test,
                    'lesson_nodes':[{'lesson':entry,'done':entry.pk in completed,
                        'available':unlocked and ready_by_pk[entry.pk],
                        'pending':not ready_by_pk[entry.pk],
                        'next':unlocked and ready_by_pk[entry.pk] and entry.pk not in completed and
                        entry.pk == next((row.pk for row in lessons if row.pk not in completed),None),
                        'url':entry.get_absolute_url() if unlocked and ready_by_pk[entry.pk] else None}
                        for entry in lessons]}
            items.append(item)
            if unlocked and state in ('active', 'test'):
                choices.append((cefr_rank.get(level.code, 0),
                    season_access.get(unit.season_id, {}).get('position', 1000000),
                    unit.order, unit.pk, item))
        if items or level.code in ('A0','A1','A2','B1','B2','C1'):
            from .experience_v9 import COPY
            chapter_titles = COPY.get(profile.ui_language, COPY['en'])['chapters']
            code_index = ['A0','A1','A2','B1','B2','C1'].index(level.code)
            stages.append({'level':level,'items':items,'chapter_title':chapter_titles[code_index],'planned':not items,
                           'exam_available':any(item['unit'].pk in units_with_questions for item in items),
                           'done':sum(i['done'] for i in items),
                           'total':sum(i['total'] for i in items)})
    placement_index = cefr_rank.get(profile.placement_level, 0)
    choices.sort(key=lambda choice: choice[:4])
    chosen = next((item for rank, _, _, _, item in choices if rank >= placement_index),
                  choices[0][4] if choices else None)
    # Single authoritative resume target, selected by the server and current placement.
    # Multiple unlocked units can exist; do not scroll to an arbitrary earlier unit.
    if chosen is not None:
        chosen['is_current'] = True
    return {'language':language,'stages':stages,'season_access':season_access,
            'next_url':chosen['url'] if chosen else None,
            'next_title':chosen['unit'].title if chosen else 'All available units complete',
            'total_lessons':total_lessons, 'done_lessons':len(completed),
            'progress_percent':round(100*len(completed)/total_lessons) if total_lessons else 0}


@login_required
def learn_path(request):
    profile = request.user.learning_profile
    if profile.onboarding_required and not profile.onboarding_completed:
        return redirect('onboarding')
    if not profile.placement_completed:
        return redirect('placement')
    route = _learning_path_data(request.user)
    for stage in route['stages']:
        stage['progress_percent'] = round(100 * stage['done'] / stage['total']) if stage['total'] else 0
    from .journey_v11 import labels_for
    from .solar_atlas_step2 import skin, for_language as solar_labels
    for number, stage in enumerate(route['stages']):
        stage['solar'] = skin(number)  # visual metadata only
    lang = request.user.learning_profile.ui_language
    return render(request, 'academy/learn_path_v20.html', {'route':route,'noindex':True,
                   'SOLAR': solar_labels(lang), 'JOURNEY_L': labels_for(request.user),
                   'seo_title':'My learning path'})


@login_required
@require_POST
@transaction.atomic
def lesson_answer(request, pk):
    """Server-grade a question; wrong answers spend one replay-safe lesson heart."""
    from .hearts import HeartEmpty, snapshot, spend_for_answer
    lesson = get_object_or_404(Lesson.objects.select_related('unit__level'), pk=pk,
                                published=True,unit__published=True,
                                unit__level__language__is_published=True)
    if not allowed_unit(request.user,lesson.unit):
        return JsonResponse({'error':'Finish your prerequisite unit first.'},status=403)
    if rate_limit(request,'lesson-check',120,3600,True):
        return JsonResponse({'error':'Too many submissions. Try again later.'},status=429)
    try:
        exercise_id = int(request.POST.get('exercise_id',''))
    except (ValueError,TypeError):
        return JsonResponse({'error':'Invalid question.'},status=400)
    admission = _locked_classic_lesson_admission(request, lesson)
    if admission is None:
        return JsonResponse({'error':'This lesson is no longer available.',
                             'error_code':'access_revoked'}, status=403)
    lesson, profile = admission
    exercise = get_object_or_404(Exercise.objects.select_for_update(), pk=exercise_id, lesson=lesson)
    current_exercises = list(Exercise.objects.filter(lesson=lesson).order_by('order','pk'))
    from .lesson_readiness_v96 import lesson_block_reason
    reason = lesson_block_reason(lesson, exercises=current_exercises)
    if reason:
        return JsonResponse({'error':'Lesson activity needs editorial review.',
                             'error_code':'audio_not_ready' if reason == 'audio' else 'activity_not_ready'},status=409)
    # Protect legacy MCQ/short rounds too, when their page was actually
    # opened and a content fingerprint stored. Old integrations posting
    # directly (without a prior GET) remain backward-compatible. Structured
    # V58 activities always require a matching opened-page signature.
    signature_key = f'lesson_activity_signature_{lesson.pk}'
    has_structured_activity = any(item.kind not in ('mcq', 'short') for item in current_exercises)
    if signature_key in request.session or has_structured_activity:
        from .lesson_activities_v58 import lesson_content_fingerprint
        if request.session.get(signature_key) != lesson_content_fingerprint(current_exercises, lesson=lesson):
            return JsonResponse({'error':'Lesson content changed. Reopen the lesson.',
                                 'error_code':'stale_lesson'},status=409)
    answer = request.POST.get('answer','')
    if not isinstance(answer,str) or not answer.strip() or len(answer)>300:
        return JsonResponse({'error':'Enter a valid answer of 1–300 characters.'},status=400)
    from .lesson_activities_v58 import validate_answer, is_correct
    if not validate_answer(exercise, answer, request.session.get(f'lesson_round_{lesson.pk}', '')):
        return JsonResponse({'error':'Choose or enter a valid answer.'},status=400)
    round_session_key = f'lesson_round_{lesson.pk}'
    round_key = request.session.get(round_session_key)
    supplied_round = request.POST.get('round_key', '')
    # Structured questions require the exact round sent by the opened page;
    # unlike old MCQ-only clients, absence is not a valid round identity.
    if ((has_structured_activity and supplied_round != round_key)
            or (supplied_round and supplied_round != round_key)):
        return JsonResponse({'error':'This lesson round has expired. Reopen the lesson.',
                             'error_code':'round_expired'}, status=409)
    if not isinstance(round_key, str) or len(round_key) != 32:
        round_key = secrets.token_hex(16)
        request.session[round_session_key] = round_key
    # A completed round is read-only. In particular, a replay of a *correct*
    # answer used to be able to resolve an outstanding MistakeRecord without
    # starting another round. Reject before grading, hearts or writes.
    completed_round = request.session.get(f'lesson_completed_round_{lesson.pk}', {})
    if isinstance(completed_round, dict) and completed_round.get('key') == round_key:
        return JsonResponse({
            'error': 'Lesson round already completed. Reopen the lesson.',
            'error_code': 'round_finished', 'completed': True,
            'finished': True, 'xp_awarded': 0,
            'score': completed_round.get('score'), 'hearts': snapshot(request.user),
        }, status=409)
    # Step 3G: a full SSR batch already graded on this round must not be
    # mixed with per-question AJAX answers (even after a failed legacy round).
    from .lesson_round_policy_step3c import round_channel_conflict
    if round_channel_conflict(request.session, lesson.pk, round_key, 'ajax'):
        return JsonResponse({
            'error':'This lesson round was graded as a full form. Reopen the lesson.',
            'error_code':'round_channel_conflict',
        }, status=409)
    key = f'lesson_answers_{lesson.pk}'
    from .lesson_round_receipts_step3h import (
        claim_round, check_answer_replay, save_answer, finish_round,
        RoundReceiptConflict, RoundReceiptFinished, RoundReceiptAnswerReplay)
    # A concurrent request may read an old browser session. The DB receipt is
    # authoritative and unique per learner/lesson/round, including correct
    # answers that do not generate a heart-debit event.
    state = snapshot(request.user)
    if state['empty']:
        return JsonResponse({'error':'No lesson hearts remain.', 'error_code':'hearts_empty',
                             'hearts':state, 'recovery_url':reverse('hearts')}, status=402)
    try:
        receipt = claim_round(user=request.user, lesson=lesson,
                              round_key=round_key, channel='ajax')
        check_answer_replay(receipt, exercise.pk)
    except (RoundReceiptConflict, RoundReceiptFinished, RoundReceiptAnswerReplay):
        return JsonResponse({'error':'This round or question was already graded. Reopen the lesson.',
                             'error_code':'round_already_recorded'}, status=409)
    # Session values are mirrored for older page code, never trusted for
    # deduplicating server writes. The DB row holds the accepted answer set.
    attempt = dict(receipt.answers)
    success = is_correct(exercise, answer, round_key)
    if not success:
        event_key = f'lesson:{lesson.pk}:round:{round_key}:question:{exercise.pk}'
        try:
            state = spend_for_answer(request.user, event_key)
        except HeartEmpty as empty:
            # The empty request must not commit a DB channel claim either.
            transaction.set_rollback(True)
            return JsonResponse({'error':'No lesson hearts remain.', 'error_code':'hearts_empty',
                                 'hearts':empty.state, 'recovery_url':reverse('hearts')}, status=402)
        if not state['spent']:
            transaction.set_rollback(True)
            return JsonResponse({'error':'This question was already checked. Reopen the lesson to try again.',
                                 'error_code':'answer_checked', 'hearts':state}, status=409)
    record_exercise_result(request.user, exercise, success)
    save_answer(receipt, exercise.pk, success)
    attempt = dict(receipt.answers)
    # The channel is locked only after an accepted, recorded answer.
    from .lesson_round_policy_step3c import record_round_channel
    record_round_channel(request.session, lesson.pk, round_key, 'ajax')
    request.session[key] = attempt
    request.session.modified = True
    all_ids = [str(i) for i in lesson.exercises.values_list('pk',flat=True)]
    finished = bool(all_ids) and all(q in attempt for q in all_ids)
    from .lesson_feedback_v101 import graded_solution
    reply = {'correct':success,'explanation':exercise.explanation,
             'solution': graded_solution(exercise, success),
             'finished':finished,'completed':False, 'xp_awarded':0, 'hearts':state}
    if finished:
        score = round(100 * sum(attempt[q] for q in all_ids)/len(all_ids))
        reply['score']=score
        reply['completed']=score >= 70
        if score>=70:
            with transaction.atomic():
                _,created = LessonProgress.objects.get_or_create(
                    user=request.user, lesson=lesson,
                    defaults={'score':score,'content_version':lesson.content_version}
                )
                if created:
                    reply['xp_awarded'] = 20 if award_xp(request.user,20,reason='lesson',event_key=f'lesson:{lesson.pk}') else 0
                    for word in Vocabulary.objects.filter(level=lesson.unit.level,published=True):
                        ReviewCard.objects.get_or_create(user=request.user,vocabulary=word)
            # The next link is computed AFTER server-side grading and crediting.
            # It never trusts a client-supplied destination or bypasses access.
            from .lesson_flow_v63 import next_step as flow_next_step
            action = flow_next_step(request.user, lesson, profile=profile)
            if action is not None:
                reply['next_action'] = action
        # Authored activities cannot retry a finished failed round in-place:
        # after a result, the learner must open a new round via GET. Historical
        # MCQ/short clients keep their established failed-round retry flow.
        if has_structured_activity or score >= 70:
            finish_round(receipt, score=score)
            from .lesson_round_policy_step3c import seal_finished_round
            seal_finished_round(request.session, lesson.pk, round_key, score)
        request.session.pop(key,None)
    return JsonResponse(reply)


@require_GET
def service_worker(request):
    """Root-scope PWA worker. Only offline app assets, NEVER private Django responses."""
    from pathlib import Path
    worker_path = settings.BASE_DIR/'academy'/'static'/'academy'/'service-worker.js'
    response=HttpResponse(worker_path.read_text(encoding='utf-8'),content_type='text/javascript; charset=utf-8')
    response['Cache-Control']='no-cache, max-age=0'
    response['Service-Worker-Allowed']='/'
    return response


@never_cache
@login_required
def dashboard(request):
    profile=request.user.learning_profile
    if profile.onboarding_required and not profile.onboarding_completed:
        return redirect('onboarding')
    if not profile.placement_completed:return redirect('placement')
    route = _learning_path_data(request.user)
    current_course = route['language']
    progress_qs = LessonProgress.objects.filter(user=request.user, lesson__published=True,
        lesson__unit__published=True, lesson__unit__level__language__is_published=True)
    due_qs = ReviewCard.objects.filter(user=request.user,due__lte=timezone.now(),
        vocabulary__published=True,vocabulary__level__language__is_published=True)
    mistake_qs = MistakeRecord.objects.filter(user=request.user,corrected_at__isnull=True,
        exercise__lesson__published=True,exercise__lesson__unit__published=True,
        exercise__lesson__unit__level__language__is_published=True)
    if current_course is not None:
        progress_qs=progress_qs.filter(lesson__unit__level__language=current_course)
        due_qs=due_qs.filter(vocabulary__level__language=current_course)
        mistake_qs=mistake_qs.filter(exercise__lesson__unit__level__language=current_course)
    else:
        progress_qs=progress_qs.none()
        due_qs=due_qs.none()
        mistake_qs=mistake_qs.none()
    progress=progress_qs.count()
    due=due_qs.count()
    mistakes_open=mistake_qs.count()
    certs=Certificate.objects.filter(user=request.user,revoked_at__isnull=True).select_related('level')
    badges=BadgeAward.objects.filter(user=request.user,revoked_at__isnull=True).select_related('badge')
    from .platform_v13 import labels_for
    from .services import user_localdate
    from .daily_calendar_v73 import daily_for_learner, published_daily_word
    today_word = (published_daily_word(daily_for_learner(request.user, current_course, user_localdate(request.user)))
                  if current_course else None)
    today_grammar = _daily_item(GrammarTopic.objects.filter(level__language=current_course, published=True,
        level__language__is_published=True), user_localdate(request.user)) if current_course else None
    from .experience_v9 import dashboard_details
    from .play_center_v12 import COPY as PLAY_COPY
    from .dashboard_v29 import for_language as dashboard_labels, learning_preview
    relevant_stage, dashboard_steps = learning_preview(route['stages'])
    from .dashboard_v30 import for_language as labels_v30, pick_worlds, next_game_url
    from .dashboard_v43 import for_language as labels_v43
    from .dashboard_v44 import for_language as labels_v44
    dashboard_course_ready = bool(route['language'] and profile.preferred_language_id == route['language'].pk)
    dashboard_worlds = pick_worlds(route['stages'], max_worlds=6, max_nodes=8) if dashboard_course_ready else []
    dashboard_next_play_url = next_game_url(route, reverse) if dashboard_course_ready else None
    if dashboard_next_play_url:
        active_item = next((item for stage in route['stages'] for item in stage['items']
                            if item.get('is_current') and item.get('state') == 'active'), None)
        if active_item is not None:
            from .journey_v11 import mixed_unit_block_reason
            if mixed_unit_block_reason(active_item['unit']):
                # The classic route already checked the next lesson's readiness.
                dashboard_next_play_url = active_item.get('url')
    return render(request,'academy/dashboard.html',{'V12_PLAY_TAGLINE':PLAY_COPY.get(profile.ui_language, PLAY_COPY['en'])['intro'], 'profile':profile,'completed_count':progress,'due':due,
        'daily_earned':daily_xp(request.user), 'app_level':learning_level(profile.xp),
        'level_fill':profile.xp%200, 'goal_percent':min(100,round(100*daily_xp(request.user)/max(profile.daily_goal_xp,1))),
        'mistakes_count':mistakes_open,
        'chest_ready':daily_xp(request.user)>=10,
        'chest_opened':DailyChest.objects.filter(user=request.user,day=user_localdate(request.user)).exists(),
        'unread_count':AppNotification.objects.filter(user=request.user,read_at__isnull=True).count(),
        'certs':certs,'badges':badges,'languages':Language.objects.filter(is_published=True),
        'route':route,'today_word':today_word,'today_grammar':today_grammar,'D13':labels_for(request),
        'dashboard_steps': dashboard_steps, 'dashboard_stage': relevant_stage,
        'dashboard_worlds':dashboard_worlds,
        'dashboard_course_ready':dashboard_course_ready,
        'dashboard_has_current':any(world['has_current'] for world in dashboard_worlds),
        'dashboard_next_play_url':dashboard_next_play_url,
        'N30':labels_v30(profile.ui_language),
        'N43':labels_v43(profile.ui_language),
        'N44':labels_v44(profile.ui_language),
        'N29': dashboard_labels(profile.ui_language),
        'noindex':True,**dashboard_details(request.user,route)})

@login_required
def profile(request):
    instance=request.user.learning_profile
    # ModelForm.is_valid() mutates `instance` during _post_clean. Capture the
    # persisted value BEFORE binding/validating the form, otherwise changing
    # the learning language may incorrectly keep the old placement level.
    previous_language_id=instance.preferred_language_id
    form=ProfileForm(request.POST or None,instance=instance)
    if request.method=='POST' and form.is_valid():
        new_language=form.cleaned_data['preferred_language']
        changed=previous_language_id != (new_language.pk if new_language else None)
        item=form.save(commit=False)
        if changed:
            item.placement_completed=False
            item.placement_level='A0'
        item.save()
        messages.success(request,'Preferences saved. Changing your learning language requires a new placement test.' if changed else 'Profile and consent settings saved.')
        return redirect('profile')
    from .mfa_disable_policy_v86 import password_label
    return render(request,'academy/profile.html', {
        'form': form, 'profile': instance,
        'mfa_password_label': password_label(instance.ui_language),
    })

@login_required
def friends(request):
    profile=request.user.learning_profile
    if not profile.social_opt_in:
        return render(request,'academy/friends.html',{'social_disabled':True})
    form=FriendForm(request.POST or None)
    if request.method=='POST':
        if rate_limit(request,'friend-request',12,3600,True):return HttpResponse('Friend request rate limit',status=429)
        if form.is_valid():
            other=User.objects.filter(email__iexact=form.cleaned_data['email'],is_active=True).first()
            if (other and other != request.user and other.learning_profile.social_opt_in
                    and other.learning_profile.email_verified_at is not None):
                if Friendship.objects.filter(from_user=other,to_user=request.user,status='blocked').exists():
                    messages.error(request,'Unable to send this request.')
                else:
                    Friendship.objects.get_or_create(from_user=request.user,to_user=other)
                    messages.success(request,'Friend request sent.')
            else: messages.error(request,'No eligible account found.')
    received=Friendship.objects.filter(to_user=request.user,status='pending').select_related('from_user')
    outgoing=Friendship.objects.filter(from_user=request.user,status='pending').select_related('to_user')
    accepted=Friendship.objects.filter(Q(from_user=request.user)|Q(to_user=request.user),status='accepted').select_related(
        'from_user__learning_profile','to_user__learning_profile')
    friend_data=[]
    for relation in accepted:
        other=relation.to_user if relation.from_user_id==request.user.pk else relation.from_user
        if other.learning_profile.social_opt_in and other.is_active:
            friend_data.append({'relation':relation,'user':other,'streak':other.learning_profile.streak,
                'last_activity':other.learning_profile.last_active_day})
    return render(request,'academy/friends.html',{'form':form,'received':received,'outgoing':outgoing,'friend_data':friend_data})

@login_required
@require_POST
def friend_action(request,pk,action):
    friendship=get_object_or_404(Friendship,pk=pk)
    if action in ('accept','reject') and friendship.to_user_id==request.user.pk and friendship.status=='pending':
        if action=='reject':friendship.delete()
        else:
            if request.user.learning_profile.social_opt_in:
                friendship.status='accepted';friendship.save(update_fields=['status'])
    elif action=='remove' and request.user.pk in (friendship.from_user_id,friendship.to_user_id):
        friendship.delete()
    elif action=='block' and friendship.to_user_id==request.user.pk:
        friendship.status='blocked';friendship.save(update_fields=['status'])
    else:return HttpResponse('Action not allowed.',status=403)
    return redirect('friends')


def leaderboard(request):
    from .rozh_social_ui import context as leaderboard_context
    return render(request,'academy/leaderboard.html',leaderboard_context(request))

@login_required
def ai_tutor(request):
    config=PlatformSettings.load()
    if not config.ai_enabled or config.ai_emergency_stop:
        raise Http404('AI tutor is not available')
    profile=request.user.learning_profile
    form=AITutorForm(request.POST or None)
    answer=None
    if request.method=='POST' and form.is_valid():
        if rate_limit(request,'ai',10,3600,True):return HttpResponse('AI rate limit exceeded',status=429)
        try: answer=tutor_reply(request.user,form.cleaned_data['question'],
                                profile.preferred_language.name if profile.preferred_language else 'Dutch')
        except AIUnavailable as exc: messages.error(request,str(exc))
    return render(request,'academy/ai.html',{'form':form,'answer':answer,'profile':profile,'config':config})

@never_cache
@manager_only
@require_http_methods(['GET','POST'])
def manager(request):
    from .manager_content_v48 import ManagerAIToggleForm

    form_class = AIConfigurationForm if request.user.is_superuser else ManagerAIToggleForm
    config = PlatformSettings.load()
    if request.method == 'POST':
        # Lock and reload *before* binding. A manager must never overwrite an
        # owner's privacy, budget, registration, or price settings with values
        # read earlier in another request. PostgreSQL enforces the row lock;
        # update_fields also protects unrelated columns on SQLite.
        with transaction.atomic():
            config = PlatformSettings.objects.select_for_update().get(pk=config.pk)
            previous_ai = (config.ai_enabled, config.ai_emergency_stop)
            form = form_class(request.POST, instance=config)
            editable_fields = tuple(form.fields)
            before = {name: getattr(config, name) for name in editable_fields}
            if form.is_valid():
                updated = form.save(commit=False)
                changed = sorted(name for name in editable_fields
                                 if before[name] != getattr(updated, name))
                # Do not call an unrestricted ModelForm.save(): that writes
                # ALL model columns, including fields delegated managers have
                # no permission to change.  auto_now requires updated_at.
                updated.save(update_fields=[*editable_fields, 'updated_at'])
                audit(request.user, 'platform_settings_updated', 'settings', {
                    'old_ai': list(previous_ai),
                    'new_ai': [updated.ai_enabled, updated.ai_emergency_stop],
                    'changed_fields': changed,
                })
                messages.success(request, 'Manager settings saved.')
                return redirect('manager')
    else:
        form = form_class(instance=config)
    since=timezone.now()-timedelta(days=30)
    from .content_audit import audit_published_content
    content_review=audit_published_content(max_issues=8)
    usage=AIUsage.objects.filter(created_at__gte=since)
    totals=usage.aggregate(estimated=Sum('actual_eur'),count=Count('pk'))
    popular=LessonProgress.objects.values('lesson__title').annotate(n=Count('id')).order_by('-n')[:7]
    active=LessonProgress.objects.filter(completed_at__gte=since).values('user_id').distinct().count()
    statuses=usage.values('status').annotate(n=Count('pk')).order_by('status')
    audit_log=AuditEvent.objects.select_related('actor')[:15]
    from .manager_i18n_v47 import for_user as manager_i18n
    return render(request,'academy/manager.html',{**manager_i18n(request.user), 'content_review':content_review,'form':form,'users_count':User.objects.count(),
        'active_count':active,'lesson_count':Lesson.objects.count(),'totals':totals,'popular':popular,
        'statuses':statuses,'audit_log':audit_log,'config':config,'R48_OWNER':request.user.is_superuser,
        'skill_speaking_30d':SkillPracticeAttempt.objects.filter(kind='speaking',created_at__gte=since).count(),
        'skill_writing_30d':SkillPracticeAttempt.objects.filter(kind='writing',created_at__gte=since).count(),
        'arena_30d':ArenaRun.objects.filter(started_at__gte=since).count(),
        'mistakes_open':MistakeRecord.objects.filter(corrected_at__isnull=True).count(),
        'chests_30d':DailyChest.objects.filter(opened_at__gte=since).count(),
        'goal_completions_30d':AppNotification.objects.filter(title='Daily goal achieved 🎯',created_at__gte=since).count(),
        })

@never_cache
@manager_only
@require_GET
def manager_users(request):
    term=request.GET.get('q','').strip()[:100]
    # Stable pagination is essential once the platform has more than 100
    # learners. Never silently drop users beyond a hard slice of 100.
    from django.core.paginator import Paginator
    users=User.objects.all().select_related('learning_profile').order_by('-date_joined','-pk')
    if term:users=users.filter(Q(email__icontains=term)|Q(username__icontains=term))
    page=Paginator(users,25).get_page(request.GET.get('page'))
    visible_ids=[member.pk for member in page.object_list]
    from .manager_i18n_v47 import for_user as manager_i18n
    return render(request,'academy/manager_users.html',{**manager_i18n(request.user),
        'users':page.object_list,'page':page,'term':term,'R48_OWNER':request.user.is_superuser,
        # Evaluate role membership only for this page, not the entire site.
        'R48_MANAGER_IDS':list(User.objects.filter(pk__in=visible_ids,groups__name='Rozh Managers')
                                .values_list('pk',flat=True).distinct()),
        'badges':Badge.objects.all(),
        'levels':Level.objects.select_related('language').all()})

@manager_only
@require_POST
@transaction.atomic
def manager_user_action(request,pk,action):
    # The delegated Manager can suspend/reinstate learners, never change roles,
    # delete users, approve legacy claims, or target privileged accounts.
    if not request.user.is_superuser and action not in ('block', 'unblock'):
        return HttpResponse('This action requires the platform owner.', status=403)
    other=get_object_or_404(User.objects.select_for_update(),pk=pk)
    # A delegated Manager may only act on ordinary learners.  An account
    # without is_staff can still have powerful direct or inherited Django
    # permissions; never let a Manager suspend/reactivate such an operator.
    if (other.pk == request.user.pk or other.is_superuser
            or (not request.user.is_superuser and has_privileged_assignments(other))):
        return HttpResponse('Cannot change a privileged account here.', status=403)
    # Users imported without Profile must remain untouched until reviewed.
    # In particular a block/unblock must not manufacture default security
    # state or crash with RelatedObjectDoesNotExist during a manager action.
    profile = Profile.objects.select_for_update().filter(user=other).first()
    if profile is None:
        logger.warning('Manager action denied: target has no Profile (user_id=%s)', other.pk)
        return HttpResponse('Account state incomplete; owner review required. No changes made.', status=409)
    if action=='block':
        if profile.suspended_at is None:
            profile.suspended_was_active = other.is_active
            profile.suspended_at = timezone.now()
            profile.email_verification_version += 1
            profile.save(update_fields=['suspended_at','suspended_was_active','email_verification_version'])
        other.is_active=False
    elif action=='approve_legacy':
        # Historical accounts are NEVER automatically enabled. The authorised
        # owner acknowledges ambiguity; the user must still prove email
        # ownership with a NEW token and use the normal password login.
        if (not profile.legacy_review_required or other.is_active
                or profile.suspended_at is not None
                or profile.email_verified_at is not None):
            messages.error(request, 'Account is not eligible for legacy review approval.')
            return redirect('manager_users')
        profile.legacy_review_required = False
        profile.email_verification_version += 1
        profile.save(update_fields=['legacy_review_required', 'email_verification_version'])
        audit(request.user, 'legacy_review_approved', other.pk)
        messages.success(request, 'Review released. Account remains INACTIVE until email verification.')
        return redirect('manager_users')
    elif action=='unblock':
        if profile.suspended_at is None:
            messages.error(request,'This account has not been suspended by a manager.')
            return redirect('manager_users')
        # Restore only the activation state saved at block time. Never
        # activate quarantined or previously inactive accounts; email proof
        # is still mandatory before promotion to staff.
        other.is_active = bool(profile.suspended_was_active
                               and profile.email_verified_at is not None
                               and not profile.legacy_review_required)
        profile.suspended_at = None
        profile.suspended_was_active = False
        profile.email_verification_version += 1
        profile.save(update_fields=['suspended_at','suspended_was_active','email_verification_version'])
    elif action=='promote':
        if (not other.is_active or profile.suspended_at is not None
                or profile.email_verified_at is None or profile.legacy_review_required):
            messages.error(request,'A suspended, unverified, or unreviewed user cannot become staff.')
            return redirect('manager_users')
        if not profile.totp_secret:
            messages.error(request,'User must enable 2FA before receiving staff role.')
            return redirect('manager_users')
        other.is_staff=True
    elif action=='demote':
        # Removing is_staff is not an effective permission revocation if
        # active direct or group grants remain.  In particular, a staff user
        # who also belongs to Rozh Managers could regain Manager access as a
        # delegated account after demotion.  Require explicit privilege cleanup
        # outside this limited web action rather than silently changing roles.
        if (other.groups.filter(name='Rozh Managers').exists()
                or other.user_permissions.exists()
                or other.groups.filter(permissions__isnull=False).exists()):
            return HttpResponse('Remove other role and permission grants before demoting staff.', status=409)
        other.is_staff=False
    elif action=='delete':
        audit(request.user,'user_deleted',other.pk)
        other.delete()
        messages.success(request,'Account deleted.')
        return redirect('manager_users')
    else:return HttpResponse('Invalid action',status=400)
    other.save(update_fields=['is_active','is_staff'])
    if action in ('promote', 'demote'):
        # Privilege changes must revoke authenticated sessions EVEN when the
        # target was never active during the transition. See V91 binding.
        from .privilege_revocation_v92 import revoke_user_sessions
        if revoke_user_sessions(other.pk) != 1:
            raise RuntimeError('Privilege change refused: target Profile is missing')
    audit(request.user,f'user_{action}',other.pk)
    messages.success(request,'Account updated.')
    return redirect('manager_users')

@owner_only
@require_POST
@transaction.atomic
def manager_award(request):
    user=get_object_or_404(User,pk=request.POST.get('user_id'))
    action=request.POST.get('action')
    target=request.POST.get('award_target','')
    try: kind,target_id=target.split(':',1); target_id=int(target_id)
    except (ValueError,TypeError):return HttpResponse('Invalid award selection',status=400)
    reason=request.POST.get('reason','Owner decision')[:200]
    if kind=='badge':
        badge=get_object_or_404(Badge,pk=target_id)
        award,created=BadgeAward.objects.get_or_create(user=user,badge=badge,defaults={'issued_by':request.user})
        if action=='revoke':award.revoked_at=timezone.now();award.revoke_reason=reason
        elif action=='grant':award.revoked_at=None;award.revoke_reason='';award.issued_by=request.user
        else:return HttpResponse('Unknown award action',status=400)
        award.save()
    elif kind=='certificate':
        level=get_object_or_404(Level,pk=target_id)
        if action=='grant':issue_certificate(user,level,issuer=request.user)
        elif action=='revoke':
            Certificate.objects.filter(user=user,level=level,revoked_at__isnull=True).update(revoked_at=timezone.now(),revoke_reason=reason)
        else:return HttpResponse('Unknown certificate action',status=400)
    else:return HttpResponse('Invalid award type',status=400)
    audit(request.user,f'{kind}_{action}',user.pk,{'item_id':target_id})
    messages.success(request,'Award action saved.')
    return redirect('manager_users')


def certificate(request,serial):
    certificate=get_object_or_404(Certificate.objects.select_related('level__language'),serial=serial)
    # Verification deliberately avoids exposing private email or account details.
    return render(request,'academy/certificate.html',{'certificate':certificate,
        'seo_title':'Learning certificate verification','noindex':True})


def privacy(request):
    cfg=PlatformSettings.load()
    return render(request,'academy/privacy.html',{'cfg':cfg,'seo_title':'Privacy and your data','noindex':False})


def terms(request):
    return render(request,'academy/terms.html',{'seo_title':'Terms of use'})


def how_it_works(request):
    return render(request,'academy/how_it_works.html',{'seo_title':'How structured language learning works'})

# Data portability is intentionally available to legacy accounts whose Profile
# was deleted or damaged. It must not, however, be downloadable merely because
# a browser still holds a session cookie. Require the current password for
# EVERY export; never cache an authorization flag in the session.
EXPORT_COPY_V49 = {
    'en': {'title': 'Download your learning data', 'explanation': 'This file contains private account and learning information. Confirm your current password before downloading it.', 'password': 'Current password', 'submit': 'Download my data', 'invalid': 'Password not accepted. No data was downloaded.', 'limited': 'Too many attempts. Please try again later.', 'back': 'Back to your profile'},
    'nl': {'title': 'Download je leergegevens', 'explanation': 'Dit bestand bevat persoonlijke account- en leergegevens. Bevestig je huidige wachtwoord voordat je het downloadt.', 'password': 'Huidig wachtwoord', 'submit': 'Mijn gegevens downloaden', 'invalid': 'Wachtwoord niet aanvaard. Er zijn geen gegevens gedownload.', 'limited': 'Te veel pogingen. Probeer later opnieuw.', 'back': 'Terug naar je profiel'},
    'ckb': {'title': 'داگرتنی داتای فێربوونت', 'explanation': 'ئەم فایلە زانیاریی تایبەتی ئەکاونت و فێربوونت لەخۆ دەگرێت. پێش داگرتن وشەی نهێنیی ئێستات پشتڕاست بکەوە.', 'password': 'وشەی نهێنیی ئێستا', 'submit': 'داتاکەم دابگرە', 'invalid': 'وشەی نهێنی قبووڵ نەکرا. هیچ داتایەک دانەگیرا.', 'limited': 'هەوڵەکان زۆر بوون. دواتر هەوڵ بدەوە.', 'back': 'گەڕانەوە بۆ پرۆفایل'},
    'ar': {'title': 'تنزيل بيانات تعلمك', 'explanation': 'يحتوي هذا الملف على معلومات خاصة بحسابك وتعلمك. أكد كلمة المرور الحالية قبل التنزيل.', 'password': 'كلمة المرور الحالية', 'submit': 'تنزيل بياناتي', 'invalid': 'لم تُقبل كلمة المرور. لم يتم تنزيل أي بيانات.', 'limited': 'محاولات كثيرة جدًا. حاول مرة أخرى لاحقًا.', 'back': 'العودة إلى ملفك الشخصي'},
}


@sensitive_post_parameters('password')
@login_required
@never_cache
@require_http_methods(['GET', 'POST'])
def data_export(request):
    language = Profile.objects.filter(user_id=request.user.pk).values_list('ui_language', flat=True).first()
    export_copy = EXPORT_COPY_V49.get(language, EXPORT_COPY_V49['en'])
    def export_form(status=200, error=''):
        response = render(request, 'academy/export_account_v49.html', {
            'E49': export_copy, 'export_error': error, 'noindex': True,
        }, status=status)
        response['Cache-Control'] = 'private, no-store, max-age=0'
        if status == 429:
            response['Retry-After'] = '900'
        return response
    if request.method == 'GET':
        return export_form()
    # Rate limit is checked before an expensive password hash and does not
    # consume attempts on a successful confirmation. A cache outage denies.
    if rate_limit_exceeded(request, 'private-export', 5, 900, True):
        return export_form(429, export_copy['limited'])
    if not request.user.check_password(request.POST.get('password', '')):
        blocked = rate_limit(request, 'private-export', 5, 900, True)
        return export_form(429 if blocked else 403,
                           export_copy['limited'] if blocked else export_copy['invalid'])
    from .models import (LearningPreferences, AvatarStyle, SocialGift, GrammarMastery,
                         AICreditWallet, AICreditPurchase, AICreditDebit)
    user=request.user
    from .models import CourseEnrollment, HeartBalance, HeartEvent, PhotoAttempt
    # Export the remaining data even if a legacy/imported account has no
    # Profile. Read-only access must never create a security-sensitive row.
    profile = Profile.objects.filter(user=user).first()
    profile_fields = ['avatar','bio','xp','streak','ui_language','daily_goal_xp',
                      'onboarding_required','onboarding_completed','preferred_language_id',
                      'placement_level','leaderboard_opt_in','social_opt_in',
                      'reminder_opt_in','summary_opt_in','ai_opt_in']
    data={
        'username':user.username,'email':user.email,'joined':user.date_joined,
        'profile':{key:getattr(profile,key) for key in profile_fields} if profile is not None else None,
        'completed_lessons':list(LessonProgress.objects.filter(user=user).values('lesson_id','score','completed_at')),
        'skills_practice':list(user.skill_attempts.values('kind','score','input_method','answer_length','created_at','vocabulary_id')),
        'assessments':list(Assessment.objects.filter(user=user).values('kind','score','passed','attempted_at','responses')),
        'reviews':list(ReviewCard.objects.filter(user=user).values('vocabulary_id','repetitions','due','last_quality')),
        'awards':list(BadgeAward.objects.filter(user=user).values('badge__name','granted_at','revoked_at')),
        'certificates':list(Certificate.objects.filter(user=user).values('serial','level__code','issued_at','revoked_at')),
        'friend_requests_sent':list(Friendship.objects.filter(from_user=user).values('to_user_id','status')),
        'friend_requests_received':list(Friendship.objects.filter(to_user=user).values('from_user_id','status')),
        'ai_usage':list(AIUsage.objects.filter(user=user).values('created_at','status','estimated_eur','actual_eur')),
        'xp_events':list(XPEvent.objects.filter(user=user).values('reason','amount','created_at')),
        'mistake_reviews':list(MistakeRecord.objects.filter(user=user).values('exercise_id','wrong_count','corrected_at','last_wrong_at')),
        'arena_runs':list(ArenaRun.objects.filter(user=user).values('level_id','score','earned_xp','started_at','finished_at')),
        'daily_chests':list(DailyChest.objects.filter(user=user).values('day','bonus_xp','opened_at')),
        'notifications':list(AppNotification.objects.filter(user=user).values('title','message','created_at','read_at')),
        'preferences':list(LearningPreferences.objects.filter(user=user).values('timezone_name','theme','reduce_motion','longest_streak')),
        'avatar_style':list(AvatarStyle.objects.filter(user=user).values('palette','accessory','updated_at')),
        'gifts_sent':list(SocialGift.objects.filter(sender=user).values('recipient_id','kind','sent_day','created_at')),
        'gifts_received':list(SocialGift.objects.filter(recipient=user).values('sender_id','kind','sent_day','created_at')),
        'grammar_progress':list(GrammarMastery.objects.filter(user=user).values('topic_id','attempts','correct','successful_days','reviewed_at','due_at')),
        'ai_wallet':list(AICreditWallet.objects.filter(user=user).values('balance','purchased','updated_at')),
        'ai_purchases':list(AICreditPurchase.objects.filter(user=user).values('id','status','credits','amount_cents','currency','created_at','paid_at')),
        'ai_credit_usage':list(AICreditDebit.objects.filter(user=user).values('usage_id','refunded','created_at')),
        'active_session_ai_conversation':request.session.get('ai_v9_history', []),
        'course_enrollments':list(CourseEnrollment.objects.filter(user=user).values('language__code','placement_level','placement_completed','joined_at','updated_at')),
        'heart_balance':list(HeartBalance.objects.filter(user=user).values('remaining','regenerated_at')),
        'heart_events':list(HeartEvent.objects.filter(user=user).values('key','delta','created_at')),
        'photo_practice':list(PhotoAttempt.objects.filter(user=user).values('language__code','image_key','correct','created_at')),

    }
    response=HttpResponse(json.dumps(data,cls=DjangoJSONEncoder,ensure_ascii=False),content_type='application/json')
    response['Content-Disposition']='attachment; filename="my-learning-data.json"'
    response['Cache-Control']='no-store'
    return response

@login_required
@never_cache
def delete_account(request):
    # This is a password-confirmed destructive action. Checking the failed-
    # attempt count BEFORE password verification prevents a stolen session
    # from unlimited password guesses. Cache errors fail closed.
    def deletion_throttled():
        messages.error(request, 'Too many account deletion attempts. Try again later.')
        response = render(request, 'academy/delete_account.html', status=429)
        response['Retry-After'] = '900'
        response['Cache-Control'] = 'no-store'
        return response

    if request.method == 'POST':
        if rate_limit_exceeded(request, 'delete-account', 5, 900, True):
            return deletion_throttled()
        password = request.POST.get('password', '')
        if not request.user.check_password(password):
            if rate_limit(request, 'delete-account', 5, 900, True):
                return deletion_throttled()
            messages.error(request, 'Password incorrect. Account was not deleted.')
        elif request.user.is_superuser:
            messages.error(request, 'Transfer ownership before deleting your superuser account.')
        else:
            user = request.user
            audit(user, 'user_self_deleted', user.pk)
            logout(request)
            user.delete()
            messages.success(request, 'Your account and learning records have been deleted. Limited security logs are retained temporarily.')
            return redirect('home')
    return render(request, 'academy/delete_account.html')


def robots(request):
    body=f'User-agent: *\nDisallow: /secure-admin/\nDisallow: /dashboard/\nDisallow: /profile/\nDisallow: /friends/\nDisallow: /account/\nDisallow: /ai-tutor/\nDisallow: /api/me/\nSitemap: {settings.SITE_URL}/sitemap.xml\n'
    return HttpResponse(body,content_type='text/plain')


def site_sitemap(request):
    from xml.sax.saxutils import escape
    paths=['/','/en/','/ckb/','/ar/','/try/','/grammar/','/word-of-the-day/','/how-it-works/','/privacy/','/terms/']
    paths+=list(Language.objects.filter(is_published=True).values_list('slug',flat=True))
    fixed=[]
    for path in paths:
        fixed.append('/languages/'+path+'/' if not path.startswith('/') else path)
    fixed += [level.get_absolute_url() for level in Level.objects.filter(language__is_published=True).select_related('language')]
    fixed += [topic.get_absolute_url() for topic in GrammarTopic.objects.filter(published=True,level__language__is_published=True)]
    xml='<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
    xml+=''.join('<url><loc>'+escape(settings.SITE_URL+path)+'</loc></url>\n' for path in fixed)
    xml+='</urlset>'
    return HttpResponse(xml,content_type='application/xml')


@never_cache
@require_safe
def health(request):
    # Liveness is intentionally independent of the database and MUST NOT be cached.
    return JsonResponse({'status':'ok'})


@never_cache
@require_safe
def ready(request):
    # Readiness checks are observational: GET /ready/ may never create a
    # PlatformSettings singleton or change persistent application state.
    # Avoid stale 200/503 responses in shared proxy caches.
    try:
        with connection.cursor() as cursor:
            cursor.execute('SELECT 1')
        config = (PlatformSettings.objects.filter(pk=1)
                  .only('organization_name', 'privacy_email').first())
        # A privacy email alone does not identify the controller. The old
        # seeded product name is a placeholder, not a legal operator name.
        controller = (config.organization_name or '').strip() if config else ''
        privacy_contact = bool(config and config.privacy_email)
        operator_identified = bool(controller and controller != 'LinguaMaster')
        passed = privacy_contact and operator_identified
        return JsonResponse({'ready': passed, 'database': 'ok',
            'privacy_contact_configured': privacy_contact,
            'operator_identity_configured': operator_identified},
            status=200 if passed else 503)
    except Exception:
        return JsonResponse({'ready':False,'database':'unavailable'},status=503)

class AccountFlowContextMixin:
    """Localize and mark every password recovery screen private."""
    flow_title_key = ''
    flow_desc_key = ''
    flow_action_key = ''

    def get_context_data(self, **kwargs):
        from .auth_flow_v32 import flow_context
        context = super().get_context_data(**kwargs)
        destination = _safe_after_login(self.request, self.request.GET.get('next', '') or
                                        self.request.session.get('post_auth_next', ''))
        extras = flow_context(self.request, context.get('form'), destination)
        context.update(extras)
        context['flow_title'] = extras['F32'][self.flow_title_key]
        context['flow_desc'] = extras['F32'][self.flow_desc_key]
        context['flow_action'] = extras['F32'].get(self.flow_action_key, '')
        context['seo_title'] = context['flow_title']
        # Local mail is stored in a private file outbox, not printed in the
        # terminal. Only show these instructions in isolated development.
        backend = settings.MAILERS['default']['BACKEND']
        context['LOCAL_CONSOLE_EMAIL'] = bool(
            settings.DEBUG and backend == 'django.core.mail.backends.filebased.EmailBackend'
            and urlsplit(settings.SITE_URL).hostname in ('localhost', '127.0.0.1')
        )
        return context


class RateLimitedResetView(AccountFlowContextMixin, PasswordResetView):
    form_class = PendingAccountPasswordResetForm
    template_name = 'academy/auth_flow_v32.html'
    email_template_name = 'academy/registration/password_reset_email.txt'
    subject_template_name = 'academy/registration/password_reset_subject.txt'
    success_url = '/password-reset/done/'
    flow_title_key = 'reset_title'
    flow_desc_key = 'reset_desc'
    flow_action_key = 'reset_action'

    def get(self, request, *args, **kwargs):
        destination = _safe_after_login(request, request.GET.get('next', ''))
        if destination:
            request.session['post_auth_next'] = destination
        return super().get(request, *args, **kwargs)

    def rate_limited_response(self):
        # Never show an unstyled text-only response for email recovery, and
        # avoid revealing whether the address exists through the error state.
        from .auth_flow_v32 import FLOW_COPY
        from .auth_experience_v26 import visitor_language
        form = self.get_form()
        form.add_error(None, FLOW_COPY[visitor_language(self.request)]['try_later'])
        response = self.render_to_response(self.get_context_data(form=form), status=429)
        response['Retry-After'] = '3600'
        response['Cache-Control'] = 'no-store'
        return response

    def post(self, request, *args, **kwargs):
        if rate_limit(request, 'reset-password', 5, 3600):
            return self.rate_limited_response()
        # Independent per-address protection without account enumeration.
        identifier = request.POST.get('email', '')[:254].strip().casefold()
        if identifier and rate_limit(request, 'reset-password-address', 5, 3600,
                                     account_identifier=identifier):
            return self.rate_limited_response()
        return super().post(request, *args, **kwargs)

    def form_valid(self, form):
        try:
            return super().form_valid(form)
        except (OSError, SMTPException):
            # Sending is synchronous today. Do not expose a different HTTP
            # outcome for an existing address when the SMTP server fails.
            # Operators must alert on these logs and repair email delivery.
            logger.error('Password reset mail gateway failed; inspect SMTP health without logging message content')
            return redirect(self.get_success_url())


class ResetDoneView(AccountFlowContextMixin, PasswordResetDoneView):
    template_name = 'academy/auth_flow_v32.html'
    flow_title_key = 'reset_done_title'
    flow_desc_key = 'reset_done_desc'


class ResetConfirmView(AccountFlowContextMixin, PasswordResetConfirmView):
    template_name = 'academy/auth_flow_v32.html'
    success_url = '/reset/done/'
    flow_title_key = 'reset_confirm_title'
    flow_desc_key = 'reset_confirm_desc'
    flow_action_key = 'reset_confirm_action'

    def form_valid(self, form):
        # Django updates the password first. Password changes invalidate older
        # email-verification tokens; issue a NEW link afterwards for eligible
        # pending accounts. The account remains inactive until explicit email
        # confirmation with CSRF-protected POST. Never send for suspended or
        # historically quarantined users.
        response = super().form_valid(form)
        user = self.user
        profile = Profile.objects.filter(user=user).first() if user else None
        if _email_activation_permitted(user, profile):
            link = _email_verification_url(self.request, user)
            try:
                send_mail('Confirm your Rozh email',
                          f'Your password was updated. Confirm your email within 24 hours: {link}',
                          settings.DEFAULT_FROM_EMAIL, [user.email])
            except (OSError, SMTPException):
                logger.error('Pending-account recovery mail gateway failed; inspect SMTP health without logging message content')
        return response

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if not context.get('validlink'):
            context['flow_title'] = context['F32']['reset_invalid_title']
            context['flow_desc'] = context['F32']['reset_invalid_desc']
            context['flow_secondary_url'] = reverse('password_reset')
            context['flow_secondary_text'] = context['F32']['again']
        return context


class ResetCompleteView(AccountFlowContextMixin, PasswordResetCompleteView):
    template_name = 'academy/auth_flow_v32.html'
    flow_title_key = 'reset_complete_title'
    flow_desc_key = 'reset_complete_desc'


def _adaptive_question_set(user, level, profile, *, lock=False):
    """Only sample accessible published units; lock teaching rows on POST.

    A level URL is not permission to practise all its units, particularly
    after prerequisites or the current course have changed. Every POST uses
    newly loaded rows, not the learner's earlier page or stale ORM cache.
    """
    units = Unit.objects.filter(level=level, published=True).order_by('pk')
    if lock:
        units = units.select_for_update()
    eligible = [unit.pk for unit in units
                if allowed_unit(user, unit, profile=profile)]
    if not eligible:
        return None
    lessons = Lesson.objects.filter(unit_id__in=eligible, published=True).order_by('pk')
    if lock:
        lessons = lessons.select_for_update()
    lesson_ids = [lesson.pk for lesson in lessons]
    if not lesson_ids:
        return [], 0
    recent = list(Assessment.objects.filter(user=user, level=level, kind='practice')
                  .order_by('-attempted_at').values_list('score', flat=True)[:5])
    target = min(5, level.order + 1)
    if recent and sum(recent) / len(recent) >= 80:
        target = min(5, target + 1)
    elif recent and sum(recent) / len(recent) < 60:
        target = max(1, target - 1)
    choices = Exercise.objects.filter(lesson_id__in=lesson_ids, kind='mcq',
                                      difficulty__lte=target).order_by('pk')
    if lock:
        choices = choices.select_for_update()
    questions = list(choices[:12])
    if not questions:
        fallback = Exercise.objects.filter(lesson_id__in=lesson_ids,
                                           kind='mcq').order_by('pk')
        if lock:
            fallback = fallback.select_for_update()
        questions = list(fallback[:12])
    return questions, target


@login_required
@require_http_methods(['GET', 'POST'])
def adaptive_practice(request, pk):
    """Adaptive practice: no cross-course grades, stale attempts or XP."""
    from .adaptive_policy_v41 import adaptive_practice_allowed
    level = get_object_or_404(Level.objects.select_related('language'), pk=pk,
                              language__is_published=True)
    profile = Profile.objects.filter(user=request.user).first()
    user_active = User.objects.filter(pk=request.user.pk, is_active=True).exists()
    if not adaptive_practice_allowed(profile, level, user_active=user_active):
        return HttpResponse('Finish setup and select this course first.', status=403)
    if request.method == 'POST' and rate_limit(request, 'adaptive', 20, 3600, True):
        return HttpResponse('Too many attempts', status=429)

    if request.method == 'POST':
        with transaction.atomic():
            # A manager block/course switch must serialize with practice writes.
            # Lock order: Profile -> Language -> Level -> Unit -> Lesson -> Exercise.
            profile = Profile.objects.select_for_update().filter(user=request.user).first()
            language = Language.objects.select_for_update().filter(pk=level.language_id).first()
            current_level = Level.objects.select_for_update().filter(
                pk=pk, language_id=level.language_id).first()
            user_active = User.objects.filter(pk=request.user.pk, is_active=True).exists()
            if not (language and language.is_published and current_level
                    and adaptive_practice_allowed(profile, current_level,
                                                  user_active=user_active)):
                return HttpResponse('Practice access has changed. Select your current course.', status=403)
            # The level was refetched without its language relation; pass the
            # separately locked published Language rather than trusting cache.
            current_level.language = language
            selection = _adaptive_question_set(request.user, current_level, profile, lock=True)
            if selection is None:
                return HttpResponse('Finish the prerequisite units first.', status=403)
            questions, target = selection
            if not questions:
                return HttpResponse('No practice exercises available.', status=503)
            answers = [request.POST.get(f'q_{question.pk}', '') for question in questions]
            if any(not isinstance(answer, str) or len(answer) > 300 for answer in answers):
                return HttpResponse('Invalid answer.', status=400)
            graded = [(question, grade(question, answer))
                      for question, answer in zip(questions, answers)]
            for (question, passed), answer in zip(graded, answers):
                if answer:
                    record_exercise_result(request.user, question, passed)
            score = round(100 * sum(passed for _, passed in graded) / len(questions))
            Assessment.objects.create(user=request.user, kind='practice',
                                      level=current_level, score=score, passed=score >= 80)
            report = {'score': score, 'passed': score >= 80}
    else:
        selection = _adaptive_question_set(request.user, level, profile)
        if selection is None:
            return HttpResponse('Finish the prerequisite units first.', status=403)
        questions, target = selection
        if not questions:
            return HttpResponse('No practice exercises available.', status=503)
        report = None

    return render(request, 'academy/assessment.html', {'kind': 'practice',
                  'level': level, 'questions': questions, 'report': report,
                  'difficulty': target})


# V74: explicit public page metadata for additional locales.
# V76: explicit public metadata, never infer C1 fluency from a beta UI locale.
HOME_SEO['ku'] = ('Zimanan bi dersên kurt fêr bibe | Rozh', 'Bi Rozh gav bi gav zimanekî fêr bibe; ders û rêziman bi rêya xwe.')
HOME_ACCESSIBILITY['ku'] = {'home':'Rûpela sereke ya Rozh','navigation':'Rêberiya sereke','language':'Zimanê rûpelê hilbijêre','skip':'Derbasî naverokê bibe'}
HOME_SEO.update({
 'fr': ('Apprendre les langues avec des leçons courtes | Rozh', 'Découvrez les langues avec des leçons courtes, la grammaire et un parcours à votre rythme.'),
 'uk': ('Вивчайте мови за короткими уроками | Rozh', 'Вивчайте мови крок за кроком з уроками, граматикою та власним навчальним шляхом.'),
 'kmr': ('فێربوونا زمانان ب وانەیێن کورت | Rozh', 'زمانان هەنگاڤ ب هەنگاڤ فێربە، ڕێزمانێ بخوینە و پێشکەڤتنا خۆ ببینە.'),
})
HOME_ACCESSIBILITY.update({
 'fr': {'home':'Accueil de Rozh','navigation':'Navigation principale','language':'Choisir la langue de la page','skip':'Aller au contenu'},
 'uk': {'home':'Головна Rozh','navigation':'Основна навігація','language':'Вибери мову сторінки','skip':'Перейти до вмісту'},
 'kmr': {'home':'پەڕا سەرەکی یا Rozh','navigation':'ڕێنیشاندانا سەرەکی','language':'زمانێ پەڕێ هەلبژێرە','skip':'بڕۆ بۆ ناڤەرۆکێ'},
})

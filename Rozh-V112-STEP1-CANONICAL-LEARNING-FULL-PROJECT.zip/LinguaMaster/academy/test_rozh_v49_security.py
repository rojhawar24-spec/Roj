"""V49 integration regressions. Django creates a separate disposable test DB."""
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.core.management import call_command
from django.core.management.base import CommandError
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .manager_roles_v48 import MANAGER_GROUP, verified_manager_session, is_delegated_manager
from .models import AuditEvent, Profile, Language, Level, Unit, Lesson, Exercise

class ManagerV49AccessTests(TestCase):
    def setUp(self):
        U=get_user_model()
        self.manager=U.objects.create_user('manager49', 'manager49@example.invalid', 'TestOnly-Manager49!')
        self.learner=U.objects.create_user('learner49', 'learner49@example.invalid', 'TestOnly-Learner49!')
        self.owner=U.objects.create_superuser('owner49', 'owner49@example.invalid', 'TestOnly-Owner49!')
        for user in (self.manager,self.learner,self.owner):
            profile=user.learning_profile
            profile.email_verified_at=timezone.now()
            profile.totp_secret='JBSWY3DPEHPK3PXP'
            profile.save(update_fields=['email_verified_at','totp_secret'])
        Group.objects.get_or_create(name=MANAGER_GROUP)[0].user_set.add(self.manager)

    def login_mfa(self,user):
        self.client.force_login(user)
        session=self.client.session
        session['mfa_verified_id']=user.pk
        session.save()

    def test_authorized_manager_can_read_real_audit_page_without_metadata(self):
        AuditEvent.objects.create(actor=self.learner,action='test_action',target='record-49',metadata={'token':'DO_NOT_SHOW_ME'})
        self.login_mfa(self.manager)
        response=self.client.get(reverse('manager_audit'))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'test_action')
        self.assertNotContains(response,'DO_NOT_SHOW_ME')
        self.assertEqual(self.client.post(reverse('manager_audit')).status_code,405)
        self.assertContains(self.client.get(reverse('manager')),'href="'+reverse('manager_audit')+'"')
        for i in range(34):
            AuditEvent.objects.create(actor=self.manager,action='page_test',target=str(i))
        page2=self.client.get(reverse('manager_audit')+'?page=2')
        self.assertEqual(page2.status_code,200)
        self.assertLessEqual(len(page2.context['events']),30)

    def test_email_verification_removed_denies_all_manager_routes_immediately(self):
        self.login_mfa(self.manager)
        self.assertEqual(self.client.get(reverse('manager')).status_code,200)
        profile=self.manager.learning_profile
        profile.email_verified_at=None
        profile.save(update_fields=['email_verified_at'])
        for name in ('manager','manager_audit','manager_users'):
            self.assertEqual(self.client.get(reverse(name)).status_code,403,name)
        self.assertEqual(self.client.post(reverse('manager_user_action',args=[self.learner.pk,'block'])).status_code,403)
        self.learner.refresh_from_db()
        self.assertTrue(self.learner.is_active)

    def test_quarantine_suspension_and_mfa_revocation_immediately_deny(self):
        self.login_mfa(self.manager)
        profile=self.manager.learning_profile
        for field,value in [('legacy_review_required',True),('suspended_at',timezone.now()),('totp_secret','')]:
            old=getattr(profile,field)
            setattr(profile,field,value)
            profile.save(update_fields=[field])
            self.assertEqual(self.client.get(reverse('manager')).status_code,403,field)
            setattr(profile,field,old)
            profile.save(update_fields=[field])
        self.assertEqual(self.client.get(reverse('manager')).status_code,200)

    def test_other_django_permissions_deny_manager_only_without_removing_them(self):
        self.login_mfa(self.manager)
        perm=Permission.objects.get(content_type__app_label='auth',codename='add_group')
        self.manager.user_permissions.add(perm)
        self.assertFalse(is_delegated_manager(self.manager))
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)
        self.manager.user_permissions.remove(perm)
        other,_=Group.objects.get_or_create(name='Other Privileged Group')
        other.permissions.add(perm)
        self.manager.groups.add(other)
        self.assertFalse(is_delegated_manager(self.manager))
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)
        self.assertTrue(other.permissions.filter(pk=perm.pk).exists())

    def test_provisioning_rejects_other_permissions_without_changes(self):
        self.manager.groups.clear()
        permission=Permission.objects.get(content_type__app_label='auth',codename='add_group')
        self.manager.user_permissions.add(permission)
        with self.assertRaises(CommandError):
            call_command('grant_rozh_manager','--username=manager49','--grant',verbosity=0)
        self.assertFalse(self.manager.groups.filter(name=MANAGER_GROUP).exists())

    def test_unblock_never_reactivates_after_email_proof_removed(self):
        self.login_mfa(self.manager)
        action=lambda value: reverse('manager_user_action',args=[self.learner.pk,value])
        self.assertEqual(self.client.post(action('block')).status_code,302)
        self.learner.refresh_from_db()
        self.assertFalse(self.learner.is_active)
        profile=self.learner.learning_profile
        profile.email_verified_at=None
        profile.save(update_fields=['email_verified_at'])
        self.assertEqual(self.client.post(action('unblock')).status_code,302)
        self.learner.refresh_from_db()
        self.assertFalse(self.learner.is_active)
        self.assertIsNone(profile.email_verified_at)

    def test_owner_must_remain_verified_and_mfa_enrolled(self):
        self.login_mfa(self.owner)
        self.assertEqual(self.client.get(reverse('manager')).status_code,200)
        profile=self.owner.learning_profile
        profile.email_verified_at=None
        profile.save(update_fields=['email_verified_at'])
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)

    def test_manager_cannot_save_an_mcq_with_wrong_answer_key(self):
        language=Language.objects.create(code='q49',slug='q49',name='Test Language',description='Test')
        level=Level.objects.create(language=language,code='A0',description='Entry level')
        unit=Unit.objects.create(level=level,slug='q49-unit',title='Test Unit',summary='Test')
        lesson=Lesson.objects.create(unit=unit,slug='q49-lesson',title='Test Lesson',skill='reading',content='Learning text')
        self.login_mfa(self.manager)
        response=self.client.post(reverse('manager_content_new',args=['exercise']),{
            'lesson':lesson.pk,'kind':'mcq','prompt':'Choose the correct answer',
            'options':'["yes","no"]','answer':'not-present', 'explanation':'Select yes',
            'difficulty':'2','order':'0'})
        self.assertEqual(response.status_code,200)
        self.assertEqual(Exercise.objects.filter(lesson=lesson).count(),0)
        self.assertContains(response,'The correct answer is missing from the options.')

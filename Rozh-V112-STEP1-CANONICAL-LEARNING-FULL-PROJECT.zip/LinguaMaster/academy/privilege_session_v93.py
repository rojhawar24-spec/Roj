"""Bind logins to the *effective* Django role and permission assignments.

V92 explicitly bumps a security revision in supported manager/admin role writes.
Those hooks cannot observe QuerySet.update(), raw SQL or third-party writers.
A request-time fingerprint catches privilege changes even when that revision
is not bumped. This is defense in depth, NOT a replacement for audit logging.

Queries use only the current authenticated user's related groups and grants;
no raw permission values are stored in the session. The fingerprint includes
permission codenames and content types, not only primary keys: changing an
existing Permission row in place must revoke active sessions as well.
"""
import hashlib
import hmac
import json

SESSION_PRIVILEGE_KEY = 'rozh_privilege_fingerprint_v93'


def privilege_fingerprint(user):
    if user is None or not getattr(user, 'is_authenticated', False):
        return None
    # Every group has one row, even without permissions (NULL permission PK).
    # Sorting makes the digest deterministic across database query plans.
    group_grants = list(user.groups.order_by('pk', 'permissions__pk').values_list(
        'pk', 'name', 'permissions__pk', 'permissions__codename',
        'permissions__content_type_id'
    ))
    direct_permission_ids = list(user.user_permissions.order_by('pk').values_list(
        'pk', 'codename', 'content_type_id'
    ))
    state = {
        'user_id': user.pk,
        'active': bool(user.is_active),
        'staff': bool(user.is_staff),
        'superuser': bool(user.is_superuser),
        'group_grants': group_grants,
        'direct_permissions': direct_permission_ids,
    }
    encoded = json.dumps(state, sort_keys=True, separators=(',', ':'), ensure_ascii=True)
    return hashlib.sha256(encoded.encode('utf-8')).hexdigest()


def session_matches_privilege(session, user):
    supplied = session.get(SESSION_PRIVILEGE_KEY)
    expected = privilege_fingerprint(user)
    return (isinstance(supplied, str) and expected is not None
            and len(supplied) == 64 and hmac.compare_digest(supplied, expected))

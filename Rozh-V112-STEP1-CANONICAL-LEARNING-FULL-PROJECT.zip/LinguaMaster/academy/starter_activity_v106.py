"""Normalize only bundled starter data on creation, never existing records."""
from .curriculum_policy_v99 import AUTO_GRADED_LEER_SPEEL_KINDS
from .lesson_activities_v58 import validate_activity


def starter_activity(source):
    row = dict(source)
    # The bundled historical short tasks request a bounded word or phrase.
    # No arbitrary Manager-authored free-writing content is converted here.
    if row['kind'] == 'short':
        row['kind'] = 'fill_blank'
        if '___' not in row['prompt']:
            if row['prompt'].count('...') == 1:
                row['prompt'] = row['prompt'].replace('...', '___', 1)
            else:
                row['prompt'] += ' ___'
    if row['kind'] not in AUTO_GRADED_LEER_SPEEL_KINDS:
        raise ValueError('Unsupported bundled starter activity')
    errors = validate_activity(row['kind'], row['prompt'], row.get('options', []),
                               row['answer'], row['explanation'], row.get('activity_data', {}))
    if errors:
        raise ValueError(errors[0])
    return row

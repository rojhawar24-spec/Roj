"""Stripe-hosted one-time credit purchases and a course-aware paid AI tutor."""
import hashlib
import hmac
import json
import os
import time
from decimal import Decimal
from urllib import request as urlrequest, error as urlerror
from urllib.parse import urlencode, urlparse
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import F
from django.http import Http404, HttpResponse, HttpResponseBadRequest
from django.shortcuts import redirect, render
from django.urls import path, reverse
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from .billing_models import AICreditWallet, AICreditPurchase, StripeWebhookReceipt
from .models import PlatformSettings, GrammarTopic, MistakeRecord, Profile
from .forms import AITutorForm
from .services import rate_limit
from .ai_service import AIUnavailable, tutor_reply
from .account_signin_policy_v27 import account_signin_permitted

TEXT = {
    'en': {'eyebrow':'YOUR LANGUAGE COACH', 'title':'A little help. A real step forward.', 'intro':'Ask about your lesson, practise a conversation or understand a mistake.', 'credits':'AI credits', 'buy':'Get credits', 'plans':'Your AI study pass', 'pack':'One-time credit pack', 'once':'One payment. No subscription.', 'credit_note':'One credit per successful reply. Unsuccessful or filtered replies return your credit.', 'privacy':'An external AI provider processes your question. Avoid personal information; verify explanations.', 'ask':'Ask your teacher', 'question':'Your question', 'placeholder':'Explain this rule with a short example…', 'consent':'Enable AI permission in your profile before asking.', 'profile':'Profile settings', 'none':'You need credits to ask the AI teacher.', 'off':'Credit purchases are currently unavailable. Your existing balance is preserved.', 'pending':'A payment return does not add credits. Your balance updates after payment is confirmed.', 'history':'Your conversation', 'clear':'Clear conversation', 'empty':'Start with a question or choose a practice prompt.', 'explain':'Explain a grammar rule', 'conversation':'Practise a short conversation', 'mistake':'Help me understand my mistake', 'you':'You', 'teacher':'AI teacher', 'level':'Learning stage', 'checkout':'Continue to secure payment', 'recent':'Recent purchases', 'paid':'Paid', 'waiting':'Awaiting payment', 'failed':'Not completed', 'no_purchases':'No purchases yet.', 'purchase_error':'Payment could not be started. Please try again later.', 'sent':'Your conversation has been cleared.', 'pack_label':'credits', 'credit_rule':'AI replies support learning; they do not certify your language level.', 'limit':'Questions must stay within the daily and monthly study limits.', 'back':'Back to teacher', 'token':'Your AI answer may contain mistakes.', 'busy':'Too many requests. Please try later.'},
    'nl': {'eyebrow':'JOUW TAALCOACH', 'title':'Een beetje hulp. Een echte stap vooruit.', 'intro':'Stel een vraag over je les, oefen een gesprek of begrijp je fout.', 'credits':'AI-credits', 'buy':'Credits kopen', 'plans':'Jouw AI-studiepas', 'pack':'Eenmalig creditpakket', 'once':'Eén betaling. Geen abonnement.', 'credit_note':'Eén credit per geslaagd antwoord. Bij een fout of geblokkeerd antwoord krijg je de credit terug.', 'privacy':'Een externe AI-aanbieder verwerkt je vraag. Deel geen persoonsgegevens en controleer de uitleg.', 'ask':'Vraag het je docent', 'question':'Jouw vraag', 'placeholder':'Leg deze regel uit met een kort voorbeeld…', 'consent':'Geef eerst toestemming voor AI in je profiel.', 'profile':'Profielinstellingen', 'none':'Je hebt credits nodig om de AI-docent iets te vragen.', 'off':'Credits kopen is momenteel niet beschikbaar. Je bestaande saldo blijft bewaard.', 'pending':'Terugkomen van de betaalpagina voegt geen credits toe. Je saldo verandert na bevestiging van de betaling.', 'history':'Jouw gesprek', 'clear':'Gesprek wissen', 'empty':'Begin met een vraag of kies een oefenopdracht.', 'explain':'Leg een grammaticaregel uit', 'conversation':'Oefen een kort gesprek', 'mistake':'Help me mijn fout te begrijpen', 'you':'Jij', 'teacher':'AI-docent', 'level':'Leerniveau', 'checkout':'Verder naar veilig betalen', 'recent':'Recente aankopen', 'paid':'Betaald', 'waiting':'Wacht op betaling', 'failed':'Niet afgerond', 'no_purchases':'Nog geen aankopen.', 'purchase_error':'De betaling kon niet worden gestart. Probeer het later opnieuw.', 'sent':'Je gesprek is gewist.', 'pack_label':'credits', 'credit_rule':'AI helpt je leren en bewijst je taalniveau niet.', 'limit':'De dagelijkse en maandelijkse gebruikslimieten blijven gelden.', 'back':'Terug naar docent', 'token':'Het AI-antwoord kan fouten bevatten.', 'busy':'Te veel aanvragen. Probeer het later opnieuw.'},
    'ckb': {'eyebrow':'ڕاهێنەری زمانی تۆ', 'title':'یارمەتییەکی کەم، هەنگاوێکی ڕاستەقینە.', 'intro':'پرسیار لە وانەکەت بکە، گفتوگۆ ڕاهێنان بکە یان هەڵەکەت تێبگە.', 'credits':'کردیتی AI', 'buy':'کردیت بکڕە', 'plans':'یاریدەدەری خوێندنی تۆ', 'pack':'پاکێتی کردیت بە یەک پارەدان', 'once':'یەک پارەدان؛ بێ بەشداریی مانگانە.', 'credit_note':'هەر وەڵامێکی سەرکەوتوو یەک کردیتە. ئەگەر وەڵامەکە شکستی هێنا یان ڕێگری لێکرا، کردیتەکەت دەگەڕێتەوە.', 'privacy':'دابینکەرێکی دەرەکیی AI پرسیارەکەت پرۆسێس دەکات. زانیاریی کەسی مەنووسە و ڕوونکردنەوەکان بپشکنە.', 'ask':'لە مامۆستاکەت بپرسە', 'question':'پرسیارەکەت', 'placeholder':'ئەم ڕێسایە بە نموونەیەکی کورت ڕوون بکەوە…', 'consent':'سەرەتا لە پرۆفایلەکەت ڕەزامەندی بۆ AI چالاک بکە.', 'profile':'ڕێکخستنەکانی پرۆفایل', 'none':'بۆ پرسیارکردن لە مامۆستای AI پێویستت بە کردیتە.', 'off':'ئێستا کڕینی کردیت بەردەست نییە. کردیتی ئێستات پارێزراوە.', 'pending':'گەڕانەوە لە پەڕەی پارەدان کردیت زیاد ناکات. دوای پشتڕاستکردنەوەی پارەدان، باڵانسەکەت نوێ دەبێتەوە.', 'history':'گفتوگۆکەت', 'clear':'گفتوگۆ بسڕەوە', 'empty':'بە پرسیارێک دەست پێ بکە یان ڕاهێنانێک هەڵبژێرە.', 'explain':'ڕێسایەکی ڕێزمان ڕوون بکەوە', 'conversation':'گفتوگۆیەکی کورت ڕاهێنان بکە', 'mistake':'یارمەتیم بدە هەڵەکەم تێبگەم', 'you':'تۆ', 'teacher':'مامۆستای AI', 'level':'ئاستی فێربوون', 'checkout':'بەردەوام بە بۆ پارەدانی پارێزراو', 'recent':'کڕینە نوێیەکان', 'paid':'پارەدراو', 'waiting':'چاوەڕوانی پارەدان', 'failed':'تەواو نەکراو', 'no_purchases':'هێشتا هیچ کڕینێک نییە.', 'purchase_error':'پارەدان دەستی پێ نەکرد. تکایە دواتر هەوڵ بدەوە.', 'sent':'گفتوگۆکەت سڕایەوە.', 'pack_label':'کردیت', 'credit_rule':'AI یارمەتیدەری فێربوونە؛ بڕوانامەی ئاستی زمان نییە.', 'limit':'سنووری ڕۆژانە و مانگانەی بەکارهێنان هەر دەمێنێت.', 'back':'بگەڕێوە بۆ مامۆستا', 'token':'وەڵامی AI لەوانەیە هەڵەی تێدا بێت.', 'busy':'داواکاری زۆرە. تکایە دواتر هەوڵ بدەوە.'},
    'ar': {'eyebrow':'مدربك اللغوي', 'title':'مساعدة صغيرة. خطوة حقيقية إلى الأمام.', 'intro':'اسأل عن درسك أو تدرب على محادثة أو افهم خطأك.', 'credits':'رصيد الذكاء الاصطناعي', 'buy':'شراء رصيد', 'plans':'مساعدك في الدراسة', 'pack':'حزمة رصيد بدفعة واحدة', 'once':'دفعة واحدة. دون اشتراك.', 'credit_note':'رصيد واحد لكل إجابة ناجحة. يُعاد الرصيد عند فشل الإجابة أو حجبها.', 'privacy':'يعالج مزود خارجي سؤالك. لا تشارك معلومات شخصية وتحقق من الشرح.', 'ask':'اسأل معلمك', 'question':'سؤالك', 'placeholder':'اشرح هذه القاعدة بمثال قصير…', 'consent':'فعّل موافقة الذكاء الاصطناعي في ملفك أولاً.', 'profile':'إعدادات الملف', 'none':'تحتاج إلى رصيد لسؤال المعلم.', 'off':'شراء الرصيد غير متاح حاليًا. رصيدك الحالي محفوظ.', 'pending':'العودة من صفحة الدفع لا تضيف رصيدًا. يتحدث الرصيد بعد تأكيد الدفع.', 'history':'محادثتك', 'clear':'مسح المحادثة', 'empty':'ابدأ بسؤال أو اختر تدريبًا.', 'explain':'اشرح قاعدة نحوية', 'conversation':'تدرب على محادثة قصيرة', 'mistake':'ساعدني على فهم خطئي', 'you':'أنت', 'teacher':'معلم الذكاء الاصطناعي', 'level':'مرحلة التعلم', 'checkout':'المتابعة إلى الدفع الآمن', 'recent':'المشتريات الأخيرة', 'paid':'مدفوع', 'waiting':'بانتظار الدفع', 'failed':'غير مكتمل', 'no_purchases':'لا توجد مشتريات بعد.', 'purchase_error':'تعذر بدء الدفع. حاول لاحقًا.', 'sent':'تم مسح المحادثة.', 'pack_label':'رصيد', 'credit_rule':'يساعدك الذكاء الاصطناعي على التعلم ولا يثبت مستواك اللغوي.', 'limit':'تبقى حدود الاستخدام اليومية والشهرية مطبقة.', 'back':'العودة إلى المعلم', 'token':'قد تحتوي إجابة الذكاء الاصطناعي على أخطاء.', 'busy':'طلبات كثيرة. حاول لاحقًا.'},
}


ERROR_TEXT = {
    'en':'The teacher could not answer this question. No credit was spent. Please try a language-learning question later.',
    'nl':'De docent kon deze vraag niet beantwoorden. Er is geen credit verbruikt. Probeer later een vraag over taal leren.',
    'ckb':'مامۆستا نەیتوانی ئەم پرسیارە وەڵام بداتەوە. هیچ کردیتێک بەکارنەهاتووە. دواتر پرسیارێک دەربارەی فێربوونی زمان بکە.',
    'ar':'تعذر على المعلم الإجابة عن هذا السؤال. لم يُستهلك أي رصيد. حاول لاحقًا بسؤال عن تعلم اللغة.',
}


def labels(request):
    return TEXT.get(request.user.learning_profile.ui_language, TEXT['en'])


def _setting(name, default=''):
    return getattr(settings, name, os.environ.get(name, default))


def payment_config():
    try:
        credits = int(_setting('AI_CREDIT_PACK_CREDITS', 50))
        amount = int(_setting('AI_CREDIT_PACK_AMOUNT_CENTS', 0))
    except (TypeError, ValueError):
        credits, amount = 0, 0
    cfg = {'secret':str(_setting('STRIPE_SECRET_KEY')), 'webhook_secret':str(_setting('STRIPE_WEBHOOK_SECRET')),
           'price_id':str(_setting('STRIPE_AI_PRICE_ID')), 'credits':credits, 'amount':amount,
           'currency':str(_setting('AI_CREDIT_CURRENCY', 'eur')).lower()}
    cfg['ready'] = (cfg['secret'].startswith(('sk_test_', 'sk_live_')) and cfg['webhook_secret'].startswith('whsec_')
                    and cfg['price_id'].startswith('price_') and 1 <= credits <= 10000 and 50 <= amount <= 100000
                    and cfg['currency'] == 'eur')
    return cfg


def _stripe_checkout(purchase, config):
    origin = settings.SITE_URL.rstrip('/')
    fields = {'mode':'payment', 'payment_method_types[0]':'card', 'line_items[0][price]':purchase.price_id,
              'line_items[0][quantity]':'1', 'client_reference_id':str(purchase.user_id),
              'metadata[purchase_id]':str(purchase.pk), 'metadata[credits]':str(purchase.credits),
              'success_url':origin + reverse('ai_plans') + '?payment=return',
              'cancel_url':origin + reverse('ai_plans') + '?payment=cancel'}
    req = urlrequest.Request('https://api.stripe.com/v1/checkout/sessions', data=urlencode(fields).encode(), method='POST',
          headers={'Authorization':'Bearer ' + config['secret'], 'Idempotency-Key':'linguamaster-ai-' + str(purchase.pk),
                   'Content-Type':'application/x-www-form-urlencoded', 'Stripe-Version':'2024-06-20'})
    with urlrequest.urlopen(req, timeout=18) as response:
        data = json.loads(response.read(131072))
    target = urlparse(data.get('url', ''))
    if target.scheme != 'https' or target.hostname != 'checkout.stripe.com' or not str(data.get('id','')).startswith('cs_'):
        raise ValueError('Unexpected checkout response')
    return data['id'], data['url']


@login_required
def ai_plans(request):
    # Refuse access to payment screens for accounts that have been revoked.
    # Existing paid credits are retained; no new checkout is initiated.
    current_user = get_user_model().objects.filter(pk=request.user.pk).first()
    current_profile = Profile.objects.filter(user_id=request.user.pk).first()
    if not account_signin_permitted(current_user, current_profile):
        return HttpResponse('Account access is currently restricted.', status=403)
    platform = PlatformSettings.load()
    if not platform.ai_enabled or platform.ai_emergency_stop:
        # OFF means no customer-facing AI pages, not merely a hidden navigation link.
        raise Http404('AI tutor is not available')
    cfg = payment_config()
    profile = request.user.learning_profile
    can_buy = cfg['ready'] and platform.ai_enabled and not platform.ai_emergency_stop and bool(settings.AI_API_KEY)
    balance = AICreditWallet.objects.filter(user=request.user).values_list('balance', flat=True).first() or 0
    return render(request, 'academy/ai_plans.html', {'T':labels(request), 'balance':balance, 'can_buy':can_buy,
        'pack_credits':cfg['credits'], 'pack_price':Decimal(cfg['amount']) / 100,
        'purchases':AICreditPurchase.objects.filter(user=request.user)[:10], 'teacher_available':platform.ai_enabled and not platform.ai_emergency_stop, 'payment_return':request.GET.get('payment') == 'return',
        'noindex':True})


@login_required
@require_POST
def ai_checkout(request):
    # Re-check account state before generating a paid Stripe checkout.
    current_user = get_user_model().objects.filter(pk=request.user.pk).first()
    current_profile = Profile.objects.filter(user_id=request.user.pk).first()
    if not account_signin_permitted(current_user, current_profile):
        return HttpResponse('Account access is currently restricted.', status=403)
    platform = PlatformSettings.load()
    if not platform.ai_enabled or platform.ai_emergency_stop:
        raise Http404('AI tutor is not available')
    cfg = payment_config()
    if not cfg['ready'] or not settings.AI_API_KEY:
        messages.error(request, labels(request)['off'])
        return redirect('ai_plans')
    if rate_limit(request, 'ai-checkout', 5, 3600, True):
        return HttpResponse(labels(request)['busy'], status=429)
    purchase = AICreditPurchase.objects.create(user=request.user, credits=cfg['credits'], amount_cents=cfg['amount'],
                                              price_id=cfg['price_id'], currency=cfg['currency'])
    try:
        session_id, checkout_url = _stripe_checkout(purchase, cfg)
        purchase.stripe_session_id = session_id
        purchase.save(update_fields=['stripe_session_id'])
    except (urlerror.URLError, TimeoutError, ValueError, TypeError, KeyError):
        purchase.status = 'failed'
        purchase.save(update_fields=['status'])
        messages.error(request, labels(request)['purchase_error'])
        return redirect('ai_plans')
    return redirect(checkout_url)


def verify_signature(body, header, secret, now=None):
    """Verify the exact bytes Stripe signed; tolerate multiple rotating v1 signatures."""
    if not secret or len(header) > 4096:
        return False
    fields = {}
    for fragment in header.split(','):
        key, _, value = fragment.partition('=')
        fields.setdefault(key, []).append(value)
    try:
        timestamp = int(fields.get('t', [''])[0])
    except ValueError:
        return False
    if abs((time.time() if now is None else now) - timestamp) > 300:
        return False
    expected = hmac.new(secret.encode(), str(timestamp).encode() + b'.' + body, hashlib.sha256).hexdigest()
    return any(hmac.compare_digest(expected.encode(), value.encode()) for value in fields.get('v1', []))


@csrf_exempt
@require_POST
def stripe_webhook(request):
    cfg = payment_config()
    if not cfg['ready']:
        return HttpResponse('Payments unavailable', status=503)
    if len(request.body) > 262144 or not verify_signature(request.body, request.headers.get('Stripe-Signature',''), cfg['webhook_secret']):
        return HttpResponseBadRequest('Invalid signature')
    try:
        event = json.loads(request.body)
        if not isinstance(event, dict) or not isinstance(event.get('id'), str) or not event['id'].startswith('evt_'):
            return HttpResponseBadRequest('Invalid event')
        if event.get('type') != 'checkout.session.completed':
            return HttpResponse('Ignored')
        data = event['data']['object']
        metadata = data['metadata']
        purchase_id = metadata['purchase_id']
        with transaction.atomic():
            purchase = AICreditPurchase.objects.select_for_update().get(pk=purchase_id)
            valid = (bool(purchase.stripe_session_id) and data.get('id') == purchase.stripe_session_id and data.get('mode') == 'payment'
                     and data.get('payment_status') == 'paid' and data.get('status') == 'complete'
                     and data.get('client_reference_id') == str(purchase.user_id)
                     and metadata.get('credits') == str(purchase.credits)
                     and type(data.get('amount_total')) is int and data['amount_total'] == purchase.amount_cents
                     and data.get('currency') == purchase.currency
                     and event.get('livemode') is cfg['secret'].startswith('sk_live_'))
            if not valid:
                return HttpResponseBadRequest('Payment details mismatch')
            receipt, created = StripeWebhookReceipt.objects.get_or_create(event_id=event['id'], defaults={'purchase':purchase})
            if not created:
                if receipt.purchase_id != purchase.pk:
                    return HttpResponseBadRequest('Event already used')
                return HttpResponse('Already processed')
            if purchase.status != 'paid':
                wallet, _ = AICreditWallet.objects.get_or_create(user=purchase.user)
                AICreditWallet.objects.filter(pk=wallet.pk).update(balance=F('balance') + purchase.credits,
                                                                  purchased=F('purchased') + purchase.credits,
                                                                  updated_at=timezone.now())
                purchase.status = 'paid'
                purchase.paid_at = timezone.now()
                purchase.save(update_fields=['status','paid_at'])
    except (ValueError, TypeError, KeyError, AttributeError, ValidationError, AICreditPurchase.DoesNotExist):
        return HttpResponseBadRequest('Invalid purchase')
    return HttpResponse('Payment confirmed')


def _course_context(profile, requested_topic='', requested_mistake=''):
    context = ''
    initial = ''
    if requested_topic.isdigit():
        topic = GrammarTopic.objects.filter(pk=requested_topic, published=True, level__language=profile.preferred_language,
                                             level__language__is_published=True).first()
        if topic:
            context = f'Published grammar topic: {topic.title}. Explanation: {topic.explanation[:1200]}'
            initial = f'Explain {topic.title} with two examples and one short exercise.'
    if requested_mistake.isdigit():
        mistake = MistakeRecord.objects.filter(pk=requested_mistake, user=profile.user, exercise__lesson__published=True,
                 exercise__lesson__unit__published=True, exercise__lesson__unit__level__language=profile.preferred_language,
                 exercise__lesson__unit__level__language__is_published=True).select_related('exercise').first()
        if mistake:
            question = mistake.exercise
            context = f'Practice question: {question.prompt[:500]}. Teacher explanation: {question.explanation[:1200]}'
            initial = 'Help me understand the rule behind this exercise, then ask a similar question.'
    return context, initial


@login_required
def ai_tutor(request):
    config = PlatformSettings.load()
    from .ai_privacy import clear_ai_history
    if not config.ai_enabled or config.ai_emergency_stop:
        clear_ai_history(request)
        raise Http404('AI tutor is not available')
    # The routed AI page must not expose a prior private chat after account
    # suspension or mandatory legacy review, even if a session still exists.
    current_user = get_user_model().objects.filter(pk=request.user.pk).first()
    profile = Profile.objects.filter(user_id=request.user.pk).first()
    if not account_signin_permitted(current_user, profile):
        clear_ai_history(request)
        return HttpResponse('Account access is currently restricted.', status=403)
    if not profile.ai_opt_in:
        clear_ai_history(request)
    text = labels(request)
    if request.method == 'POST' and request.POST.get('action') == 'clear':
        request.session.pop('ai_v9_history', None)
        messages.success(request, text['sent'])
        return redirect('ai_tutor')
    topic = request.POST.get('topic', '') if request.method == 'POST' else request.GET.get('topic', '')
    mistake = request.POST.get('mistake', '') if request.method == 'POST' else request.GET.get('mistake', '')
    context, initial = _course_context(profile, topic, mistake)
    form = AITutorForm(request.POST or None, initial={'question':initial})
    form.fields['question'].label = text['question']
    form.fields['question'].widget.attrs.update({'placeholder':text['placeholder'], 'rows':4})
    history = []
    if profile.ai_opt_in:
        course_key = f'{profile.preferred_language_id}:{profile.placement_level}:{profile.ui_language}'
        if request.session.get('ai_v9_course') != course_key:
            clear_ai_history(request)
            request.session['ai_v9_course'] = course_key
        history = request.session.get('ai_v9_history', [])
    if not isinstance(history, list):
        history = []
    history = [item for item in history[-6:] if isinstance(item, dict) and item.get('role') in ('user','assistant') and isinstance(item.get('content'), str)]
    if request.method == 'POST' and form.is_valid():
        if rate_limit(request, 'ai', 10, 3600, True):
            return HttpResponse(text['busy'], status=429)
        try:
            question = form.cleaned_data['question']
            answer = tutor_reply(request.user, question,
                       profile.preferred_language.name if profile.preferred_language else 'Dutch',
                       history=history, course_context=context)
            history = (history + [{'role':'user','content':question}, {'role':'assistant','content':answer}])[-6:]
            request.session['ai_v9_history'] = history
            target = reverse('ai_tutor')
            if context and topic.isdigit():
                target += '?' + urlencode({'topic':topic})
            elif context and mistake.isdigit():
                target += '?' + urlencode({'mistake':mistake})
            return redirect(target)
        except AIUnavailable:
            messages.error(request, ERROR_TEXT.get(profile.ui_language, ERROR_TEXT['en']))
    balance = AICreditWallet.objects.filter(user=request.user).values_list('balance', flat=True).first() or 0
    from .rozh2027 import student_shell_context
    return render(request, 'academy/ai.html', {
        **student_shell_context(request), 'shell_template':'academy/rozh2027_student_shell.html',
        'page_title':text['title'], 'T':text, 'form':form, 'profile':profile,
        'config':config, 'balance':balance, 'history':history,
        'topic_id':topic if context else '', 'mistake_id':mistake if context else '',
        'noindex':True,
    })


urlpatterns = [path('ai-tutor/', ai_tutor, name='ai_tutor'), path('ai/credits/', ai_plans, name='ai_plans'),
               path('ai/checkout/', ai_checkout, name='ai_checkout'), path('ai/webhook/stripe/', stripe_webhook, name='stripe_webhook')]


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'billing_v9', ['ERROR_TEXT', 'TEXT'])

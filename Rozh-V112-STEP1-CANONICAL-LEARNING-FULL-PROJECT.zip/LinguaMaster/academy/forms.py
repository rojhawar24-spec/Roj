import re
from django import forms
from django.contrib.auth import get_user_model, password_validation
from django.contrib.auth.forms import PasswordResetForm
from django.core.exceptions import ValidationError
from .models import Profile, PlatformSettings

class RegisterForm(forms.Form):
    username = forms.RegexField(regex=r'^[A-Za-z][A-Za-z0-9_.-]{2,29}$', max_length=30,
        label='Username', widget=forms.TextInput(attrs={'autocomplete':'username','autocapitalize':'none','spellcheck':'false'}), help_text='3–30 characters. Start with a letter; use letters, digits, dots, underscores or hyphens.')
    email = forms.EmailField(max_length=254,widget=forms.EmailInput(attrs={'autocomplete':'email','autocapitalize':'none','spellcheck':'false'}))
    def clean_username(self):
        value=self.cleaned_data['username'].strip()
        # Availability is checked only at submission, with a generic outcome.
        return value
    password1 = forms.CharField(label='Password', min_length=8, max_length=128, widget=forms.PasswordInput(attrs={'autocomplete':'new-password', 'minlength':'8', 'maxlength':'128'}), strip=False)
    age_confirmed = forms.BooleanField(label='I confirm that I am at least 16 years old', required=True)
    def clean_email(self):
        email = self.cleaned_data['email'].strip().lower()
        if len(email)>150:
            raise ValidationError('Email must be 150 characters or fewer')
        return email
    def clean(self):
        cleaned = super().clean()
        first = cleaned.get('password1')
        if first:
            try:
                User = get_user_model()
                candidate = User(username=cleaned.get('username', ''), email=cleaned.get('email', ''))
                password_validation.validate_password(first, user=candidate)
            except ValidationError as exc:
                self.add_error('password1', exc)
        return cleaned


class PendingAccountPasswordResetForm(PasswordResetForm):
    """Reset only verified-mail accounts, never addresses typed at easy signup.

    Immediate learner access is NOT proof of email ownership. Sending reset
    tokens to unverified addresses would allow the actual mailbox owner to
    control someone else's account. Legacy quarantined/suspended users cannot
    bypass manager review via password reset. The response is non-enumerating.
    """

    def get_users(self, email):
        User = get_user_model()
        address_field = User.get_email_field_name()
        candidates = User._default_manager.filter(**{address_field + '__iexact': email})
        import unicodedata
        def norm(value):
            return unicodedata.normalize('NFKC', str(value or '')).casefold()
        for user in candidates:
            try:
                profile = user.learning_profile
            except Profile.DoesNotExist:
                continue
            if (not user.has_usable_password() or
                    profile.suspended_at is not None or
                    profile.legacy_review_required or
                    norm(getattr(user, address_field)) != norm(email)):
                continue
            if profile.email_verified_at is not None and user.is_active:
                yield user

class LoginForm(forms.Form):
    email = forms.CharField(label='Email or username', max_length=254,widget=forms.TextInput(attrs={'autocomplete':'username','autocapitalize':'none','spellcheck':'false'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'autocomplete':'current-password'}))

class MFACodeForm(forms.Form):
    code = forms.RegexField(r'^(?:[0-9]{6}|[A-Fa-f0-9]{16})$',max_length=16,
        help_text='Six-digit authenticator code or a one-time 16-character recovery code')

class ProfileForm(forms.ModelForm):
    class Meta:
        model=Profile
        fields=['avatar','bio','ui_language','daily_goal_xp','preferred_language','leaderboard_opt_in','social_opt_in','reminder_opt_in','summary_opt_in','ai_opt_in']
    def __init__(self,*args,**kwargs):
        from .models import Language
        super().__init__(*args,**kwargs)
        self.fields['preferred_language'].queryset=Language.objects.filter(is_published=True).order_by('name')
    def clean_avatar(self):
        value=self.cleaned_data['avatar']
        # Do not add an owl to the new LinguaMaster identity; preserve legacy profiles.
        if value == '🦉' and self.instance.pk and self.instance.avatar == value:
            return value
        if value not in ['🎓','📚','⭐','🌍','🚀','🌱','🌿','💎']:
            raise ValidationError('Choose a supported avatar emoji')
        return value

class AIConfigurationForm(forms.ModelForm):
    class Meta:
        model=PlatformSettings
        fields=['ai_enabled','ai_emergency_stop','ai_daily_limit','ai_monthly_limit','ai_monthly_budget_eur',
                'ai_input_eur_per_million','ai_output_eur_per_million','ai_moderation_reserve_eur',
                'organization_name','privacy_email','public_registration_enabled']
    def clean(self):
        data=super().clean()
        if data.get('ai_enabled') and not data.get('ai_emergency_stop') and data.get('ai_monthly_budget_eur',0)<=0:
            self.add_error('ai_monthly_budget_eur','Set a positive budget before enabling live AI')
        return data

class FriendForm(forms.Form):
    email=forms.EmailField(help_text='Enter the email of a user who enabled social features')

class AITutorForm(forms.Form):
    question=forms.CharField(max_length=1800,widget=forms.Textarea(attrs={'rows':4,'placeholder':'Ask for an explanation or example…'}))


class OnboardingForm(forms.Form):
    ui_language=forms.ChoiceField(choices=Profile.UI_LANGUAGES,label='App language')
    preferred_language=forms.ModelChoiceField(queryset=None,label='Language to learn',empty_label=None)
    daily_goal_xp=forms.TypedChoiceField(choices=Profile.DAILY_GOALS,coerce=int,label='Daily XP goal')
    def __init__(self,*args,**kwargs):
        from .models import Language
        super().__init__(*args,**kwargs)
        self.fields['preferred_language'].queryset=Language.objects.filter(is_published=True).order_by('name')

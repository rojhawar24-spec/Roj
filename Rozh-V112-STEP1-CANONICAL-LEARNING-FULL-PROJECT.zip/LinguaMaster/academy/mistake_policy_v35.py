"""Fail-closed student admission policy for correcting lesson mistakes.

This does not authorize a mistake ID by itself: the view additionally locks
and scopes the MistakeRecord to the learner's CURRENT published course.
"""


def mistake_retry_allowed(profile, *, user_active, course_published):
    return bool(
        profile is not None
        and user_active
        and course_published
        and profile.preferred_language_id is not None
        and profile.placement_completed
        and (not profile.onboarding_required or profile.onboarding_completed)
        and profile.suspended_at is None
        and not profile.legacy_review_required
    )

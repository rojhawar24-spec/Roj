"""Server-graded, repeatable visual vocabulary without XP or heart farming."""
import secrets
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import HttpResponse, HttpResponseBadRequest
from django.shortcuts import redirect,render
from django.urls import path
from django.utils.crypto import constant_time_compare
from django.views.decorators.http import require_http_methods
from .services import rate_limit
from .visual_models import PhotoAttempt
from .practice_access_v48 import eligible_practice_profile

WORDS={
    'en':{'coffee':'coffee','books':'a book','train':'a train','forest':'a forest'},
    'nl':{'coffee':'koffie','books':'een boek','train':'een trein','forest':'een bos'},
    'de':{'coffee':'Kaffee','books':'ein Buch','train':'ein Zug','forest':'ein Wald'},
    'fr':{'coffee':'du café','books':'un livre','train':'un train','forest':'une forêt'},
}
SCENES={
    'en':{'coffee':'Cups on a café table, surrounded by plants.','books':'Someone reading outdoors at sunset.','train':'A locomotive pulling carriages on railway tracks.','forest':'Trees beside a quiet lake, with mountains behind.'},
    'nl':{'coffee':'Kopjes op een cafétafel, tussen groene planten.','books':'Iemand leest buiten bij zonsondergang.','train':'Een locomotief trekt wagons over het spoor.','forest':'Bomen langs een rustig meer met bergen op de achtergrond.'},
    'ckb':{'coffee':'کوپەکان لەسەر مێزی کافێیەک لە نێوان ڕووەکەکان.','books':'کەسێک لە دەرەوە لە کاتی ئاوابوونی خۆر دەخوێنێتەوە.','train':'شەمەندەفەرێک واگۆنەکان بە ڕێگای ئاسندا ڕادەکێشێت.','forest':'دارەکان لە تەنیشت دەریاچەیەکی ئارام بە چیا لە پاشەوە.'},
    'ar':{'coffee':'أكواب على طاولة مقهى بين النباتات.','books':'شخص يقرأ في الخارج عند الغروب.','train':'قاطرة تسحب عربات على سكة حديدية.','forest':'أشجار بجوار بحيرة هادئة وخلفها جبال.'},
}
TEXT={
 'en':dict(eyebrow='SEE IT. REMEMBER IT.',title='A picture. A new word.',intro='Connect what you see with the language you are learning.',question='Which word matches this picture?',check='Check my answer',next='Next picture',correct='Well spotted!',retry='Look again, then remember the word.',answer='The word to remember',note='Free practice. No hearts are lost and no XP is awarded.',back='Practice studio',missing='Choose English, Dutch, German or French to practise with pictures.',choose='Choose a course',progress='Your photo practice',attempts='attempts',credit='Photography: Unsplash',listen='Listen to the word',alt='Picture description',replay='This picture was already checked. Continue to the next one.'),
 'nl':dict(eyebrow='ZIEN. BEGRIJPEN. ONTHOUDEN.',title='Een beeld. Een nieuw woord.',intro='Verbind wat je ziet met de taal die je leert.',question='Welk woord past bij deze foto?',check='Controleer mijn antwoord',next='Volgende foto',correct='Goed gezien!',retry='Kijk nog eens en onthoud het woord.',answer='Het woord om te onthouden',note='Gratis oefenen. Je verliest geen hartjes en krijgt hier geen XP.',back='Oefenruimte',missing='Kies Engels, Nederlands, Duits of Frans om met foto’s te oefenen.',choose='Kies een cursus',progress='Jouw foto-oefeningen',attempts='pogingen',credit='Fotografie: Unsplash',listen='Luister naar het woord',alt='Beschrijving van de foto',replay='Deze foto is al gecontroleerd. Ga verder met de volgende.'),
 'ckb':dict(eyebrow='ببینە. تێبگە. لە یاد بگرە.',title='وێنەیەک. وشەیەکی نوێ.',intro='ئەوەی دەیبینیت بە زمانی فێربوونەکەتەوە ببەستەوە.',question='کام وشە لەگەڵ ئەم وێنەیە دەگونجێت؟',check='وەڵامەکەم بپشکنە',next='وێنەی داهاتوو',correct='باش بینیت!',retry='دووبارە سەیر بکە و وشەکە لە یاد بگرە.',answer='وشەکە لە یاد بگرە',note='ڕاهێنان بەخۆڕاییە. دڵت لەدەست ناچێت و لێرە XP وەرناگریت.',back='شوێنی ڕاهێنان',missing='ئینگلیزی، هۆڵەندی، ئەڵمانی یان فەرەنسی هەڵبژێرە بۆ ڕاهێنان بە وێنە.',choose='کۆرس هەڵبژێرە',progress='ڕاهێنانی وێنەکانت',attempts='هەوڵ',credit='وێنەکان: Unsplash',listen='گوێ لە وشەکە بگرە',alt='وەسفی وێنە',replay='ئەم وێنەیە پێشتر پشکنراوە. بڕۆ بۆ وێنەی داهاتوو.'),
 'ar':dict(eyebrow='شاهد. افهم. تذكر.',title='صورة. وكلمة جديدة.',intro='اربط ما تراه باللغة التي تتعلمها.',question='أي كلمة تناسب هذه الصورة؟',check='تحقق من إجابتي',next='الصورة التالية',correct='أحسنت الملاحظة!',retry='انظر مجددًا وتذكر الكلمة.',answer='الكلمة لتتذكرها',note='تدريب مجاني. لا تفقد قلوبًا ولا تحصل هنا على XP.',back='مساحة التدريب',missing='اختر الإنجليزية أو الهولندية أو الألمانية أو الفرنسية للتدرب بالصور.',choose='اختر دورة',progress='تدريباتك بالصور',attempts='محاولات',credit='الصور: Unsplash',listen='استمع للكلمة',alt='وصف الصورة',replay='تم فحص هذه الصورة بالفعل. انتقل إلى التالية.'),
}


@login_required
@require_http_methods(['GET','POST'])
def practice(request):
    profile=eligible_practice_profile(request.user)
    if profile is None:
        return HttpResponse('Your learning account is not available for practice.', status=403)
    locale=profile.ui_language if profile.ui_language in TEXT else 'en'
    text=TEXT[locale]
    language=profile.preferred_language
    if not language or not language.is_published or language.code not in WORDS:
        return render(request,'academy/photos.html',{'P':text,'noindex':True})
    code=language.code
    key=f'photo_round_{language.pk}'
    result_key=f'photo_result_{language.pk}'
    catalogue=list(WORDS[code])
    result=request.session.get(result_key)
    if not isinstance(result,dict) or result.get('image_key') not in catalogue:
        result=None
    target=request.session.get(key)
    if not isinstance(target,dict) or target.get('image_key') not in catalogue or not isinstance(target.get('nonce'),str):
        count=PhotoAttempt.objects.filter(user=request.user,language=language).count()
        target={'image_key':catalogue[count%len(catalogue)],'nonce':secrets.token_urlsafe(18)}
        request.session[key]=target
    if request.method=='POST':
        if rate_limit(request,'photo-practice',60,3600,True):return HttpResponse('Too many attempts',status=429)
        if request.POST.get('action')=='next':
            # A replayed Next action must not invalidate a fresh, unanswered round.
            if result is None:
                return HttpResponseBadRequest('Check this picture before continuing.')
            request.session.pop(result_key,None)
            request.session.pop(key,None)
            return redirect('photo_practice')
        if result:
            messages.info(request,text['replay'])
            return redirect('photo_practice')
        nonce=request.POST.get('round','')
        if not constant_time_compare(nonce,target['nonce']):
            return HttpResponseBadRequest('This picture round has expired.')
        answer=request.POST.get('answer','')
        if answer not in WORDS[code].values():return HttpResponseBadRequest('Choose one of the displayed words.')
        with transaction.atomic():
            current=eligible_practice_profile(request.user, for_update=True)
            if current is None:
                return HttpResponse('Your learning account is not available for practice.', status=403)
            if current.preferred_language_id != language.pk:
                return HttpResponse('Your course changed. Start a new picture round.', status=409)
            # Read current publication state after the Profile lock, not only
            # the cached related model fetched before this request's write.
            if not language.__class__.objects.filter(pk=language.pk, is_published=True).exists():
                return HttpResponse('Your course is no longer published.', status=409)
            correct=answer==WORDS[code][target['image_key']]
            attempt,_=PhotoAttempt.objects.get_or_create(round_key=f'u{request.user.pk}:{target["nonce"]}',
                defaults={'user':request.user,'language':language,'image_key':target['image_key'],'correct':correct})
        request.session[result_key]={'image_key':target['image_key'],'correct':attempt.correct}
        return redirect('photo_practice')
    image_key=result['image_key'] if result else target['image_key']
    return render(request,'academy/photos.html',{'P':text,'language':language,
        'image_path':f'academy/photos/{image_key}.jpg','scene':SCENES[locale][image_key],
        'options':list(WORDS[code].values()),'round':target['nonce'],'result':result,
        'answer_word':WORDS[code][image_key] if result else '',
        'attempts':PhotoAttempt.objects.filter(user=request.user,language=language).count(),'noindex':True})


urlpatterns=[path('skills/photos/',practice,name='photo_practice')]


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'photo_v10', ['TEXT'])

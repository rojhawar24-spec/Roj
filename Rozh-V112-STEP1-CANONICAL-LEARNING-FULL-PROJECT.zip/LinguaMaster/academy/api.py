from rest_framework import generics, serializers, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.exceptions import ValidationError, PermissionDenied
from django.contrib.auth import get_user_model
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from .account_signin_policy_v27 import account_signin_permitted
from .api_progress_paging import InvalidProgressPage, parse_progress_page
from .models import Language,Level,Unit,Lesson,LessonProgress,Profile

class LanguageSerializer(serializers.ModelSerializer):
    class Meta: model=Language; fields=['id','name','code','slug','description']
class LevelSerializer(serializers.ModelSerializer):
    class Meta: model=Level; fields=['id','code','description','language']
class UnitSerializer(serializers.ModelSerializer):
    class Meta: model=Unit; fields=['id','slug','title','summary','outcomes','level','order']
class LessonSerializer(serializers.ModelSerializer):
    """Public catalog metadata, never lesson bodies or listening transcripts.

    The public /api/lessons/ listing is intentionally accessible anonymously,
    so do not expose lesson.content or lesson.audio_text here. A student must
    use a separately authorized lesson route to access protected learning
    material. Adding new fields requires an explicit privacy review.
    """
    class Meta:
        model = Lesson
        fields = ['id', 'title', 'skill', 'unit', 'order']
        read_only_fields = fields

class LanguagesAPI(generics.ListAPIView):
    queryset=Language.objects.filter(is_published=True)
    serializer_class=LanguageSerializer
class LevelsAPI(generics.ListAPIView):
    queryset=Level.objects.filter(language__is_published=True)
    serializer_class=LevelSerializer
class UnitsAPI(generics.ListAPIView):
    queryset=Unit.objects.filter(published=True,level__language__is_published=True)
    serializer_class=UnitSerializer
class LessonsAPI(generics.ListAPIView):
    queryset=Lesson.objects.filter(published=True,unit__published=True,unit__level__language__is_published=True)
    serializer_class=LessonSerializer
@method_decorator(never_cache, name='dispatch')
class ProgressAPI(APIView):
    # Private endpoint: no user_id from query strings, URLs, or a stale session.
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        # A session can outlive suspension, mandatory account review, or a
        # missing legacy profile. Re-read BOTH records before touching private
        # progress. Fail closed without creating or mutating any account data.
        current_user = get_user_model().objects.filter(pk=request.user.pk).first()
        profile = Profile.objects.filter(user_id=request.user.pk).first()
        if not account_signin_permitted(current_user, profile):
            raise PermissionDenied('Account access is currently restricted.')
        try:
            limit, offset = parse_progress_page(request.query_params)
        except InvalidProgressPage as exc:
            raise ValidationError({'pagination': str(exc)}) from exc
        completions = LessonProgress.objects.filter(user_id=current_user.pk)
        total = completions.count()
        # Stable ordering is essential for clients following next_offset.
        lesson_ids = list(completions.order_by('lesson_id').values_list('lesson_id', flat=True)[offset:offset + limit])
        next_offset = offset + len(lesson_ids)
        return Response({
            'xp': profile.xp,
            'streak': profile.streak,
            'completed_lessons': total,
            'lesson_ids': lesson_ids,
            'limit': limit,
            'offset': offset,
            'has_more': next_offset < total,
            'next_offset': next_offset if next_offset < total else None,
        })

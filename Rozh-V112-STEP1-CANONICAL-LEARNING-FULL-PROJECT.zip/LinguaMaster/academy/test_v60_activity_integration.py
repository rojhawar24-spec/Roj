"""V60 real Django ORM tests; run only against Django's disposable test database.

The builder cannot claim these tests passed unless a Django runtime executed them.
"""
import json
from django.db import connection
from django.test import TestCase
from .models import Language, Level, Unit, Lesson, Exercise
from .lesson_activities_v58 import (
    ready, public_activity, validate_answer, is_correct,
    lesson_content_fingerprint, _shuffled,
)


class V60ActivityORMIntegration(TestCase):
    @classmethod
    def setUpTestData(cls):
        language = Language.objects.create(code='en', name='English', slug='v60-en',
                                           description='QA only', is_published=True)
        level = Level.objects.create(language=language, code='A0',
                                     description='QA level', order=0)
        unit = Unit.objects.create(level=level, slug='v60-unit', title='QA Unit',
                                   summary='Only for disposable QA', published=True)
        cls.lesson = Lesson.objects.create(unit=unit, slug='v60-lesson',
                                           title='QA Lesson', skill='grammar',
                                           content='Synthetic test-only lesson', published=True)

    def make_exercise(self, **overrides):
        fields = dict(lesson=self.lesson, kind='mcq', prompt='Choose the correct word',
                      options=['am', 'is', 'are'], answer='is',
                      explanation='He/she/it is.', difficulty=2,
                      activity_data={}, content_version=1)
        fields.update(overrides)
        return Exercise.objects.create(**fields)

    def test_migration_0014_activity_column_exists_in_real_test_database(self):
        table = Exercise._meta.db_table
        with connection.cursor() as cursor:
            names = {c.name for c in connection.introspection.get_table_description(cursor, table)}
        self.assertIn('activity_data', names)

    def test_persisted_choice_grades_server_side_and_does_not_publish_answer(self):
        exercise = self.make_exercise()
        exercise.refresh_from_db()
        self.assertTrue(ready(exercise))
        self.assertEqual(exercise.options, ['am', 'is', 'are'])
        self.assertTrue(validate_answer(exercise, 'is', 'v60round'))
        self.assertTrue(is_correct(exercise, 'is', 'v60round'))
        self.assertFalse(is_correct(exercise, 'am', 'v60round'))
        shown = public_activity(exercise, 'v60round')
        self.assertNotIn('answer', shown)
        self.assertNotIn('activity_data', shown)

    def test_persisted_matching_roundtrip_and_wrong_answer(self):
        pairs = [{'left': 'cat', 'right': 'animal'},
                 {'left': 'red', 'right': 'colour'},
                 {'left': 'run', 'right': 'verb'}]
        exercise = self.make_exercise(kind='word_matching',
                options=[], answer='', activity_data={'pairs': pairs})
        exercise.refresh_from_db()
        self.assertTrue(ready(exercise))
        shown = public_activity(exercise, 'round-v60')
        self.assertNotIn('pairs', shown)
        self.assertNotIn('answer', shown)
        order = _shuffled(list(range(3)), f'round-v60:match:{exercise.pk}')
        correct = json.dumps([order.index(i) for i in range(3)])
        self.assertTrue(is_correct(exercise, correct, 'round-v60'))
        bad = json.dumps([order.index(i) for i in (1, 2, 0)])
        self.assertFalse(is_correct(exercise, bad, 'round-v60'))

    def test_editorial_update_without_version_bump_invalidates_round(self):
        exercise = self.make_exercise()
        before = lesson_content_fingerprint([exercise])
        # Simulate a raw import that bypasses Manager's version increment.
        Exercise.objects.filter(pk=exercise.pk).update(explanation='Updated educational explanation')
        exercise.refresh_from_db()
        self.assertEqual(exercise.content_version, 1)
        self.assertNotEqual(before, lesson_content_fingerprint([exercise]))

    def test_editorial_order_and_difficulty_changes_also_invalidate_round(self):
        exercise = self.make_exercise()
        for field, value in (('difficulty', 3), ('order', 2)):
            old = lesson_content_fingerprint([exercise])
            Exercise.objects.filter(pk=exercise.pk).update(**{field: value})
            exercise.refresh_from_db()
            self.assertNotEqual(old, lesson_content_fingerprint([exercise]))

"""Login-only V30 hardening integration tests. Run in a fully installed Django environment.

They are NOT an offline test substitute; require Django, pyotp, and database migrations.
"""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.db import connection
from django.test import TestCase
from django.urls import reverse
from academy.models import Profile
import pyotp

User = get_user_model()


class HardenedLoginTests(TestCase):
    def setUp(self):
        cache.clear()
        self.password = 'Valid-Very-Long-Password-2026!'
        self.user = User.objects.create_user(username='login_v31', email='login-v31@example.org', password=self.password)
        profile = self.user.learning_profile
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.save(update_fields=['onboarding_completed', 'placement_completed'])

    def test_login_page_is_accessible_localized_and_private(self):
        for locale in ('nl', 'en', 'ckb', 'ar'):
            with self.subTest(locale=locale):
                response = self.client.get(reverse('login'), {'ui': locale, 'next': '/grammar/'})
                self.assertEqual(response.status_code, 200)
                self.assertContains(response, 'auth-v35-bundle.css')
                self.assertContains(response, f'lang="{locale}"')
                self.assertContains(response, 'name="next" value="/grammar/"')
                self.assertIn('no-store', response['Cache-Control'])

    def test_existing_user_and_unknown_user_share_public_login_failure(self):
        for identifier in (self.user.email, 'absent-user@example.org'):
            with self.subTest(identifier=identifier):
                response = self.client.post(reverse('login'), {'email': identifier, 'password': 'invalid-password'})
                self.assertEqual(response.status_code, 200)
                self.assertContains(response, 'auth-error-summary')
                self.assertContains(response, 'role="alert"')
        self.assertFalse('_auth_user_id' in self.client.session)

    def test_username_email_account_aliases_share_same_rate_limit(self):
        for attempt in range(7):
            identifier = self.user.username if attempt % 2 else self.user.email
            response = self.client.post(reverse('login'), {'email': identifier, 'password': 'invalid-password'})
            self.assertEqual(response.status_code, 200)
        blocked = self.client.post(reverse('login'), {'email': self.user.email, 'password': 'invalid-password'})
        self.assertEqual(blocked.status_code, 429)
        self.assertContains(blocked, 'auth-error-summary', status_code=429)
        self.assertContains(blocked, 'name="csrfmiddlewaretoken"', status_code=429)
        self.assertEqual(blocked['Retry-After'], '900')

    def test_untrusted_next_is_rejected_and_valid_feature_is_kept(self):
        bad = self.client.post(reverse('login'), {'email': self.user.email, 'password': self.password,
                                                  'next': '//example.com/admin'})
        self.assertEqual(bad.status_code, 302)
        self.assertNotIn('example.com', bad['Location'])
        self.client.logout()
        response = self.client.post(reverse('login'), {'email': self.user.email, 'password': self.password,
                                                      'next': '/grammar/'})
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response['Location'], '/grammar/')

    def test_mfa_seed_is_encrypted_in_database(self):
        seed = pyotp.random_base32()
        profile = self.user.learning_profile
        profile.totp_secret = seed
        profile.save(update_fields=['totp_secret'])
        with connection.cursor() as cursor:
            cursor.execute('SELECT totp_secret FROM academy_profile WHERE id = %s', [profile.pk])
            raw = cursor.fetchone()[0]
        self.assertTrue(raw.startswith('enc:v1:'))
        self.assertNotIn(seed, raw)
        profile.refresh_from_db()
        self.assertEqual(profile.totp_secret, seed)

    def test_mfa_requires_fresh_code_and_preserves_redirect(self):
        profile = self.user.learning_profile
        profile.totp_secret = pyotp.random_base32()
        profile.save(update_fields=['totp_secret'])
        response = self.client.post(reverse('login'), {'email': self.user.username, 'password': self.password,
                                                       'next': '/grammar/'})
        self.assertEqual(response['Location'], reverse('mfa_verify'))
        code = pyotp.TOTP(profile.totp_secret).now()
        verified = self.client.post(reverse('mfa_verify'), {'code': code})
        self.assertEqual(verified.status_code, 302)
        self.assertEqual(verified['Location'], '/grammar/')
        # Start a distinct login in the same OTP step: a used code must not work again.
        self.client.logout()
        self.client.post(reverse('login'), {'email': self.user.email, 'password': self.password})
        replay = self.client.post(reverse('mfa_verify'), {'code': code})
        self.assertEqual(replay.status_code, 200)
        self.assertContains(replay, 'auth-error-summary')

    def test_staff_is_not_owner(self):
        self.user.is_staff = True
        self.user.save(update_fields=['is_staff'])
        self.client.force_login(self.user)
        session = self.client.session
        session['mfa_verified_id'] = self.user.pk
        session.save()
        self.assertEqual(self.client.get(reverse('manager')).status_code, 403)

    def test_owner_needs_mfa_for_manager(self):
        self.user.is_staff = True
        self.user.is_superuser = True
        self.user.save(update_fields=['is_staff', 'is_superuser'])
        self.client.force_login(self.user)
        self.assertEqual(self.client.get(reverse('manager')).status_code, 403)

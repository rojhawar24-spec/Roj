"""A small, safe template bridge for preapproved static Rozh audio."""
from django import template
from academy.audio_v78 import approved_audio_url
register = template.Library()

@register.filter(name='rozh_audio_url')
def rozh_audio_url(text, course_code):
    return approved_audio_url(text, course_code)


# Text-only explanations for missing *approved* audio; no fake device voice.
# These are provisional UI translations awaiting native-speaking editorial QA.
MISSING_AUDIO_MESSAGES = {
    'nl': 'Deze luisteroefening heeft nog geen goedgekeurde opname. De audio is niet beschikbaar.',
    'en': 'This listening activity has no approved recording yet. Audio is unavailable.',
    'de': 'Für diese Hörübung gibt es noch keine freigegebene Aufnahme. Audio ist nicht verfügbar.',
    'fr': "Cet exercice d’écoute ne dispose pas encore d’un enregistrement validé. L’audio est indisponible.",
    'uk': 'Для цієї вправи ще немає перевіреного аудіозапису. Аудіо недоступне.',
    'ar': 'لا يوجد تسجيل صوتي معتمد لهذا التمرين حتى الآن. الصوت غير متاح.',
    'ckb': 'هێشتا تۆمارێکی دەنگی پەسەندکراو بۆ ئەم ڕاهێنانە نییە. دەنگ بەردەست نییە.',
    'kmr': 'هێشتا تۆمارەکا دەنگی یا پەسەندکری بۆ ڤێ ڕاهێنانێ نینە. دەنگ نەبەردەستە.',
    'ku': 'Ji bo vê xebatê hêj tomarek dengî ya pejirandî tune ye. Deng ne berdest e.',
}

@register.filter(name='rozh_audio_missing_message')
def rozh_audio_missing_message(locale):
    return MISSING_AUDIO_MESSAGES.get(locale, MISSING_AUDIO_MESSAGES['en'])

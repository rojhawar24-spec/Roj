import json
from django import template
from django.utils.safestring import mark_safe
from django.utils.html import json_script
register=template.Library()

@register.filter
def contains(container,value):
    return value in container

@register.filter
def answer_name(exercise):
    return f'q_{exercise.pk}'

@register.filter
def field_name(exercise):
    return f'answer_{exercise.pk}'

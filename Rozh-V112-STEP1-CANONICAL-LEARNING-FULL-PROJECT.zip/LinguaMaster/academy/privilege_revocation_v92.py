"""Invalidate authenticated sessions after supported role/permission changes.

V91 sessions are bound to Profile.email_verification_version. A role change
without revision bump could otherwise turn an already signed-in learner into
a Manager without fresh credentials. F() is atomic under concurrent edits.

Call this inside the same transaction as the role mutation. QuerySet.update
and raw SQL used OUTSIDE these supported paths are not automatically audited.
"""
from django.db.models import F
from .models import Profile


def revoke_user_sessions(user_id):
    """Return rows changed; 0 means a missing Profile (caller must fail closed)."""
    if user_id is None or isinstance(user_id, bool):
        raise ValueError('A real user id is required to invalidate sessions')
    return Profile.objects.filter(user_id=user_id).update(
        email_verification_version=F('email_verification_version') + 1
    )


def revoke_group_members_sessions(group):
    """Invalidate current members after owner edits group grants or its name."""
    if group is None or group.pk is None:
        raise ValueError('A saved group is required')
    user_ids = group.user_set.values('pk')
    return Profile.objects.filter(user_id__in=user_ids).update(
        email_verification_version=F('email_verification_version') + 1
    )

"""Grammar toolkit UI labels, not grammar content; interface-language only."""
VISUAL_LABELS = {
 'en': {'toolkit':'Visual grammar toolkit','description':'Learn the rule visually, then try a short practice.','example_a':'Example A','example_b':'Example B','try_it':'Try it yourself','answer':'Your answer','check':'Check answer','right':'Correct. You understood the pattern.','wrong':'Not yet. Review the example and try again.','reset':'Start again','add':'Add word','remove':'Remove last','hint':'Hint','practice_note':'Practice here is for learning only. XP and mastery are unchanged.','open':'Explore the visual guide','contents':'Visual guide'},
 'nl': {'toolkit':'Visuele grammaticagids','description':'Begrijp de regel met een diagram en oefen daarna zelf.','example_a':'Voorbeeld A','example_b':'Voorbeeld B','try_it':'Probeer het zelf','answer':'Jouw antwoord','check':'Controleer','right':'Goed! Je begrijpt het patroon.','wrong':'Nog niet. Bekijk het voorbeeld en probeer opnieuw.','reset':'Opnieuw beginnen','add':'Woord toevoegen','remove':'Laatste woord weghalen','hint':'Tip','practice_note':'Deze oefening is om te leren. XP en beheersing veranderen niet.','open':'Bekijk de visuele gids','contents':'Visuele gids'},
 'ckb': {'toolkit':'ڕێنمایی بینراوی ڕێزمان','description':'بە وێنەی ڕێکخراوە ڕێساکە تێبگە، پاشان خۆت ڕاهێنان بکە.','example_a':'نموونەی A','example_b':'نموونەی B','try_it':'خۆت تاقی بکەوە','answer':'وەڵامەکەت','check':'وەڵامەکەم بپشکنە','right':'دروستە! لە شێوازەکە تێگەیشتوویت.','wrong':'هێشتا نا. نموونەکە ببینە و دووبارە هەوڵ بدە.','reset':'دەستپێکردنەوە','add':'وشە زیاد بکە','remove':'دوایین وشە لاببە','hint':'ئامۆژگاری','practice_note':'ئەم ڕاهێنانە تەنها بۆ فێربوونە؛ XP و پێشکەوتن ناگۆڕێت.','open':'ڕێنمایی بینراوی ببینە','contents':'ڕێنمایی بینراوی'},
 'ar': {'toolkit':'دليل القواعد المرئي','description':'افهم القاعدة بصريًا ثم تدرّب بنفسك.','example_a':'المثال أ','example_b':'المثال ب','try_it':'جرّب بنفسك','answer':'إجابتك','check':'تحقق','right':'صحيح! لقد فهمت النمط.','wrong':'ليس بعد. راجع المثال ثم حاول مرة أخرى.','reset':'ابدأ من جديد','add':'أضف كلمة','remove':'احذف الكلمة الأخيرة','hint':'تلميح','practice_note':'هذا تدريب للتعلم فقط؛ لا يغيّر نقاط الخبرة أو الإتقان.','open':'عرض الدليل المرئي','contents':'الدليل المرئي'},
}

# V57: consistent local labels for interactive explanation disclosures.
for _locale, _label in {'en':'Show explanation', 'nl':'Bekijk uitleg', 'ckb':'ڕوونکردنەوە ببینە', 'ar':'عرض الشرح'}.items():
    VISUAL_LABELS[_locale]['reveal'] = _label


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'grammar_visual_labels_v17', ['VISUAL_LABELS'])

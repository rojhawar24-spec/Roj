"""V45 integration tests. Run only with Django's separate test database."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Language, Level, Unit, Lesson, PlatformSettings

class ThreeZoneV45DjangoTests(TestCase):
 @classmethod
 def setUpTestData(cls):
  cls.user=get_user_model().objects.create_user('v45learner','v45@example.invalid','V45-safe-preview-passphrase-long')
  language=Language.objects.create(code='nl',slug='v45-dutch',name='Dutch',description='Dutch',is_published=True)
  level=Level.objects.create(language=language,code='A0',order=0,description='Starter')
  cls.unit=Unit.objects.create(level=level,slug='v45-first',title='Verified course unit',summary='Real unit',order=1,published=True)
  Lesson.objects.create(unit=cls.unit,slug='v45-lesson',title='First real lesson',skill='reading',content='Hallo',published=True)
  p=cls.user.learning_profile;p.preferred_language=language;p.placement_completed=True;p.onboarding_completed=True;p.save()
 def test_private_dashboard_auth(self):
  response=self.client.get(reverse('dashboard'))
  self.assertEqual(response.status_code,302)
 def test_right_menu_and_real_season(self):
  self.client.force_login(self.user)
  page=self.client.get(reverse('dashboard'))
  self.assertEqual(page.status_code,200)
  self.assertContains(page,'lm45-tools-rail')
  self.assertContains(page,'lm45-seasons-preview')
  self.assertContains(page,'Verified course unit')
  self.assertContains(page,reverse('grammar_library'))
  self.assertContains(page,reverse('play_hub'))
 def test_ai_owner_flag_on_off_immediately(self):
  self.client.force_login(self.user)
  cfg=PlatformSettings.load()
  cfg.ai_enabled=False;cfg.ai_emergency_stop=True;cfg.save(update_fields=['ai_enabled','ai_emergency_stop'])
  self.assertNotContains(self.client.get(reverse('dashboard')),'lm45-ai-first')
  cfg.ai_enabled=True;cfg.ai_emergency_stop=False;cfg.save(update_fields=['ai_enabled','ai_emergency_stop'])
  self.assertContains(self.client.get(reverse('dashboard')),'lm45-ai-first')
  cfg.ai_emergency_stop=True;cfg.save(update_fields=['ai_emergency_stop'])
  self.assertNotContains(self.client.get(reverse('dashboard')),'lm45-ai-first')
 def test_play_hub_winding_uses_real_units(self):
  self.client.force_login(self.user)
  page=self.client.get(reverse('play_hub'))
  self.assertEqual(page.status_code,200)
  self.assertContains(page,'lm45-winding-path')
  self.assertContains(page,'Verified course unit')
 def test_four_ui_languages(self):
  self.client.force_login(self.user)
  p=self.user.learning_profile
  for lang in ('nl','en','ckb','ar'):
   p.ui_language=lang;p.save(update_fields=['ui_language'])
   self.assertContains(self.client.get(reverse('dashboard')),'lm45-tools-rail')

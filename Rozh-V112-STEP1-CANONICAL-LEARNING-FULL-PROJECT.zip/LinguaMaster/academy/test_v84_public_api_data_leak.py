"""V84 step 1: Django integration regression for public catalog disclosure.

Run only with an isolated disposable test database; never use production data.
"""
from django.test import TestCase
from django.urls import reverse

from .models import Language, Level, Unit, Lesson


class PublicLessonApiDisclosureTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        lang = Language.objects.create(name='Dutch', slug='dutch', code='nl',
                                       description='Test course', is_published=True)
        level = Level.objects.create(language=lang, code='A0', description='Test level', order=0)
        unit = Unit.objects.create(level=level, slug='demo', title='Public demo',
                                   summary='Visible summary', published=True)
        cls.visible = Lesson.objects.create(
            unit=unit, slug='listening-demo', title='Public listing title',
            skill='listening', content='PRIVATE_LESSON_BODY_V84',
            audio_text='SECRET_LISTENING_TRANSCRIPT_V84', published=True,
        )
        cls.draft = Lesson.objects.create(
            unit=unit, slug='draft', title='DRAFT_NEVER_PUBLIC_V84',
            skill='listening', content='DRAFT_BODY_V84',
            audio_text='DRAFT_AUDIO_V84', published=False,
        )

    def test_unauthenticated_list_exposes_metadata_only(self):
        response = self.client.get('/api/lessons/')
        self.assertEqual(response.status_code, 200)
        payload = response.json()
        # Paged and unpaged DRF list responses are both supported.
        rows = payload.get('results', []) if isinstance(payload, dict) else payload
        matching = [row for row in rows if row['id'] == self.visible.pk]
        self.assertEqual(len(matching), 1)
        self.assertEqual(matching[0]['title'], 'Public listing title')
        self.assertEqual(set(matching[0]), {'id', 'title', 'skill', 'unit', 'order'})
        self.assertNotIn('PRIVATE_LESSON_BODY_V84', response.content.decode())
        self.assertNotIn('SECRET_LISTENING_TRANSCRIPT_V84', response.content.decode())
        self.assertNotIn('DRAFT_NEVER_PUBLIC_V84', response.content.decode())

    def test_catalog_serializer_never_exposes_protected_fields_to_logged_in_users(self):
        from django.contrib.auth import get_user_model
        user = get_user_model().objects.create_user('learner_v84', password='TestOnlyPass#123')
        self.client.force_login(user)
        response = self.client.get('/api/lessons/')
        self.assertEqual(response.status_code, 200)
        self.assertNotIn('SECRET_LISTENING_TRANSCRIPT_V84', response.content.decode())
        self.assertNotIn('PRIVATE_LESSON_BODY_V84', response.content.decode())

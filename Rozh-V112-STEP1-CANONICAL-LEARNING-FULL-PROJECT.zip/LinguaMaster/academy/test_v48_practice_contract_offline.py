"""Source and isolated helper checks; intentionally do not claim live Django PASS."""
import ast
import unittest
from pathlib import Path
from types import SimpleNamespace

BASE = Path(__file__).parent

class Query:
    def __init__(self, value): self.value=value
    def select_related(self,*a):return self
    def select_for_update(self): return self
    def filter(self, **kwargs):return self
    def first(self):return self.value
    def exists(self):return bool(self.value)

class ProfileManager:
    def __init__(self,profile):self.profile=profile
    def select_related(self,*a):return Query(self.profile)

class ProfileGateV48Offline(unittest.TestCase):
    def setUp(self):
        tree=ast.parse((BASE/'practice_access_v48.py').read_text(encoding='utf-8'))
        fn=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='eligible_practice_profile')
        self.ns={'Profile':SimpleNamespace(objects=ProfileManager(None)),
            'get_user_model':lambda:SimpleNamespace(_default_manager=Query(True))}
        exec(compile(ast.Module(body=[fn],type_ignores=[]),'<actual v48 gate>','exec'),self.ns)
        self.user=SimpleNamespace(pk=1,is_authenticated=True)

    def make_profile(self,**overrides):
        fields=dict(suspended_at=None,legacy_review_required=False,
                    onboarding_required=True,onboarding_completed=True,placement_completed=True)
        fields.update(overrides)
        self.ns['Profile'].objects=ProfileManager(SimpleNamespace(**fields))

    def gate(self):return self.ns['eligible_practice_profile'](self.user)
    def test_01_active_profile_allowed(self):self.make_profile();self.assertIsNotNone(self.gate())
    def test_02_legacy_account_no_wizard_allowed(self):
        self.make_profile(onboarding_required=False,onboarding_completed=False);self.assertIsNotNone(self.gate())
    def test_03_missing_profile_denied(self):self.assertIsNone(self.gate())
    def test_04_suspended_denied(self):self.make_profile(suspended_at='now');self.assertIsNone(self.gate())
    def test_05_review_denied(self):self.make_profile(legacy_review_required=True);self.assertIsNone(self.gate())
    def test_06_incomplete_wizard_denied(self):self.make_profile(onboarding_completed=False);self.assertIsNone(self.gate())
    def test_07_incomplete_placement_denied(self):self.make_profile(placement_completed=False);self.assertIsNone(self.gate())
    def test_08_anonymous_denied(self):self.make_profile();self.user.is_authenticated=False;self.assertIsNone(self.gate())
    def test_09_inactive_database_denied(self):
        self.make_profile();self.ns['get_user_model']=lambda:SimpleNamespace(_default_manager=Query(False));self.assertIsNone(self.gate())
    def test_10_row_lock_flag_supported(self):
        self.make_profile();self.assertIsNotNone(self.ns['eligible_practice_profile'](self.user,for_update=True))

class ViewWriteContractV48(unittest.TestCase):
    def test_11_listening_rechecks_with_atomic(self):
        s=(BASE/'skill_practice.py').read_text(encoding='utf-8')
        self.assertIn('with transaction.atomic():',s)
        self.assertIn('eligible_practice_profile(request.user, for_update=True)',s)
        self.assertIn('active_target = Vocabulary.objects.select_for_update()',s)
    def test_12_photos_rechecks_with_atomic(self):
        s=(BASE/'photo_v10.py').read_text(encoding='utf-8')
        self.assertIn('with transaction.atomic():',s)
        self.assertIn('eligible_practice_profile(request.user, for_update=True)',s)
        self.assertLess(s.index('current=eligible_practice_profile(request.user, for_update=True)'),s.index('PhotoAttempt.objects.get_or_create'))
    def test_13_both_views_guard_get(self):
        for name in ('photo_v10.py','skill_practice.py'):
            s=(BASE/name).read_text(encoding='utf-8')
            self.assertIn('eligible_practice_profile(request.user)',s)
            self.assertIn('status=403',s)
    def test_14_no_new_xp_on_low_stakes_practice(self):
        for name in ('photo_v10.py','skill_practice.py'):
            s=(BASE/name).read_text(encoding='utf-8')
            self.assertNotIn('award_xp(',s)
    def test_15_rejects_unpublished_course(self):
        s=(BASE/'photo_v10.py').read_text(encoding='utf-8')
        self.assertIn('is_published=True',s)
        s=(BASE/'skill_practice.py').read_text(encoding='utf-8')
        self.assertIn('level__language__is_published=True',s)

if __name__=='__main__':unittest.main()

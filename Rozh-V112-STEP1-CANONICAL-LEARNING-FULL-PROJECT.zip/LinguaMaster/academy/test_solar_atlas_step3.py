"""STEP 3 regression tests — run only on an isolated Django test database.

Not a production fixture: do not import actual account or course records.
"""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse

from .models import Exercise, Language, Lesson, LessonProgress, Level, LearningSeason, Profile, Unit, XPEvent
from .solar_atlas_step3 import COPY, THEMES, lesson_presentation


class SolarLessonStep3Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user('step3-student', 'step3@example.invalid', 'StrongPassword!2026')
        cls.language = Language.objects.create(code='nl', name='Dutch', slug='step3-dutch', description='Dutch', is_published=True)
        cls.level = Level.objects.create(language=cls.language, code='A0', description='Start', order=0)
        cls.season = LearningSeason.objects.create(level=cls.level, slug='step3-season', title='My published season',
                                                   theme='dawn', published=True, order=0)
        cls.unit = Unit.objects.create(level=cls.level, season=cls.season, slug='step3-unit',
                                       title='Greetings', summary='First words', published=True)
        cls.lesson = Lesson.objects.create(unit=cls.unit, slug='step3-lesson', title='First words',
                                           skill='reading', content='Original visible lesson content.', published=True)
        cls.exercise = Exercise.objects.create(lesson=cls.lesson, kind='mcq', prompt='Choose a greeting?',
                                               options=['Hallo', 'Dag'], answer='Hallo', explanation='Hallo is a greeting.')
        profile = cls.user.learning_profile
        profile.preferred_language = cls.language
        profile.placement_completed = True
        profile.onboarding_completed = True
        profile.save()

    def setUp(self):
        cache.clear()
        self.client.force_login(self.user)

    def test_real_template_uses_the_same_server_endpoint_and_new_css(self):
        response = self.client.get(reverse('lesson', args=[self.lesson.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'solar-atlas-step3.css')
        self.assertContains(response, 'solar-lesson solar-theme-dawn')
        self.assertContains(response, 'My published season')
        self.assertContains(response, 'id="lessonProgress" max="100" value="10"')
        self.assertContains(response, 'id="lessonFeedback" role="status"')
        self.assertContains(response, 'id="practiceError" class="app-form-message" role="alert"')
        self.assertContains(response, reverse('lesson_answer', args=[self.lesson.pk]))
        self.assertContains(response, 'Original visible lesson content.')
        self.assertNotContains(response, 'name="correct_answer"')

    def test_sorani_rtl_and_other_locales(self):
        for code in ('nl', 'en', 'ckb', 'ar'):
            with self.subTest(locale=code):
                Profile.objects.filter(user=self.user).update(ui_language=code)
                response = self.client.get(reverse('lesson', args=[self.lesson.pk]))
                self.assertEqual(response.status_code, 200)
                self.assertContains(response, COPY[code]['eyebrow'])
                self.assertContains(response, 'dir="rtl"' if code in ('ckb', 'ar') else 'dir="ltr"')

    def test_unpublished_season_name_is_not_exposed(self):
        self.season.published = False
        self.season.title = 'PRIVATE MANAGER DRAFT TITLE'
        self.season.save(update_fields=['published','title'])
        response = self.client.get(reverse('lesson', args=[self.lesson.pk]))
        self.assertNotContains(response, 'PRIVATE MANAGER DRAFT TITLE')

    def test_server_grades_and_awards_xp_only_once(self):
        self.client.get(reverse('lesson', args=[self.lesson.pk]))
        url = reverse('lesson_answer', args=[self.lesson.pk])
        response = self.client.post(url, {'exercise_id':self.exercise.pk, 'answer':'Hallo'})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()['correct'])
        self.assertTrue(response.json()['completed'])
        self.assertEqual(response.json()['xp_awarded'], 20)
        self.assertEqual(LessonProgress.objects.filter(user=self.user, lesson=self.lesson).count(), 1)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='lesson').count(), 1)
        repeat = self.client.post(url, {'exercise_id':self.exercise.pk, 'answer':'Hallo'})
        self.assertEqual(repeat.status_code, 200)
        self.assertEqual(repeat.json()['xp_awarded'], 0)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='lesson').count(), 1)

    def test_presentation_helpers_have_no_model_side_effects(self):
        for code in ('nl','en','ckb','ar'):
            self.assertTrue(lesson_presentation(self.lesson,code)['copy']['focus'])
        self.assertEqual(THEMES['coast'], 'river')
        self.assertEqual(LessonProgress.objects.filter(user=self.user).count(), 0)

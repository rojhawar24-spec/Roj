"""Django integration verification for V43. Run on an isolated test database."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Language, Level, Unit, Lesson, LessonProgress, XPEvent


class V43DashboardBrowserResponseTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user('v43learner', 'v43@example.org', 'A-long-strong-dash-passphrase!')
        cls.language = Language.objects.create(code='nl', slug='v43-nl', name='Dutch', description='Dutch', is_published=True)
        cls.level = Level.objects.create(language=cls.language, code='A0', order=0, description='A0')
        cls.unit = Unit.objects.create(level=cls.level, slug='v43-first', title='Real learner station', summary='Start', order=1, published=True)
        Lesson.objects.create(unit=cls.unit, slug='v43-lesson', title='Learn this', skill='reading', content='Hallo', published=True)
        profile=cls.user.learning_profile
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.preferred_language = cls.language
        profile.save()

    def test_anonymous_dashboard_redirects_to_login_without_caching(self):
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code,302)
        self.assertIn('login', response.url)
        self.assertIn('no-store', response.headers.get('Cache-Control',''))

    def test_authorized_dashboard_no_store_and_real_learner_route(self):
        self.client.force_login(self.user)
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code,200)
        self.assertIn('no-store', response.headers.get('Cache-Control',''))
        self.assertContains(response,'lm43-dashboard-page')
        self.assertContains(response,'lm43-map-legend')
        self.assertContains(response,'Real learner station')
        self.assertContains(response,reverse('journey_play',args=[self.unit.pk]))
        self.assertFalse(LessonProgress.objects.filter(user=self.user).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_locked_unit_never_exposes_player_url(self):
        later = Unit.objects.create(level=self.level, slug='v43-second-locked', title='Locked station', summary='Later', order=2, published=True)
        later.prerequisites.add(self.unit)
        Lesson.objects.create(unit=later,slug='v43-locked-lesson', title='Later',skill='reading',content='Later', published=True)
        self.client.force_login(self.user)
        response = self.client.get(reverse('dashboard'))
        self.assertContains(response,'lm29-state-locked')
        self.assertNotContains(response,reverse('journey_play',args=[later.pk]))

    def test_all_four_interface_locales_render_navigation(self):
        self.client.force_login(self.user)
        profile=self.user.learning_profile
        for lang in ('nl','en','ckb','ar'):
            profile.ui_language=lang
            profile.save(update_fields=['ui_language'])
            response=self.client.get(reverse('dashboard'))
            self.assertEqual(response.status_code,200)
            self.assertContains(response,reverse('friends'))
            self.assertContains(response,reverse('leaderboard'))

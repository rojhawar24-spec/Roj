"""Private heart balance and clear, free recovery routes."""
from math import ceil

from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.urls import path
from django.views.decorators.http import require_GET

from .hearts import snapshot
from .heart_spelling_v72 import labels_for, _published_words, _eligible_profile, MAX_REWARDS_24H
from .models import Profile
from .navigation_v67 import safe_student_return_path
from .heart_models import HeartEvent
from django.utils import timezone
from datetime import timedelta


@login_required
@require_GET
def hearts(request):
    state = snapshot(request.user)
    profile = _eligible_profile(request.user)
    has_words = bool(profile and profile.preferred_language_id and
                     len(_published_words(profile.preferred_language_id)) >= 5)
    limit_reached = (HeartEvent.objects.filter(user=request.user, kind='recovery',
        key__startswith='spelling:', delta=1, created_at__gte=timezone.now() - timedelta(hours=24)).count()
        >= MAX_REWARDS_24H)
    return_to = safe_student_return_path(request.GET.get('next')) or '/play/'
    return render(request, 'academy/hearts.html', {
        'heart_state': state, 'heart_icons': [number < state['remaining'] for number in range(state['capacity'])],
        'wait_minutes': ceil(state['next_in_seconds'] / 60), 'noindex': True,
        'H72': labels_for(request.user), 'H72_AVAILABLE': has_words and state['empty'] and not limit_reached,
        'H72_HAS_WORDS': has_words, 'H72_LIMIT': limit_reached, 'H72_RETURN': return_to,
    })


urlpatterns = [path('hearts/', hearts, name='hearts')]

"""Real Django HTTP regression tests. Run only against disposable QA test DB.

These tests are included in the release but are NOT asserted to have run in the
build environment when Django is absent.
"""
from datetime import date
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Language, Level, Profile, ReviewCard, Vocabulary, XPEvent


class DailyWordAuthorizationV25Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            username='v25_word_learner', email='v25word@example.invalid',
            password='V25-Local-QA-Only!')
        cls.nl = Language.objects.create(code='nl', slug='v25-nl', name='Dutch', is_published=True)
        cls.fr = Language.objects.create(code='fr', slug='v25-fr', name='French', is_published=True)
        cls.a0_nl = Level.objects.create(language=cls.nl, code='A0', order=0)
        cls.a0_fr = Level.objects.create(language=cls.fr, code='A0', order=0)
        cls.word_nl = Vocabulary.objects.create(
            level=cls.a0_nl, word='hallo', translation='hello',
            pronunciation='', example='Hallo!', published=True)
        cls.word_fr = Vocabulary.objects.create(
            level=cls.a0_fr, word='bonjour', translation='hello',
            pronunciation='', example='Bonjour!', published=True)
        Profile.objects.filter(user=cls.user).update(
            preferred_language=cls.nl, onboarding_required=True,
            onboarding_completed=True, placement_completed=True, placement_level='A0')

    def setUp(self):
        self.client.force_login(self.user)
        date_patch = patch('academy.services.user_localdate', return_value=date(2026, 11, 21))
        date_patch.start()
        self.addCleanup(date_patch.stop)

    def _assert_no_mutation(self):
        self.assertFalse(XPEvent.objects.filter(user=self.user, reason='daily_word').exists())
        self.assertFalse(ReviewCard.objects.filter(user=self.user).exists())
        self.assertEqual(Profile.objects.get(user=self.user).xp, 0)

    def test_authorized_answer_awards_once_and_saves_card(self):
        for _ in range(2):
            self.assertEqual(self.client.post(reverse('word'), {'answer': 'HALLO'}).status_code, 200)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='daily_word').count(), 1)
        self.assertEqual(Profile.objects.get(user=self.user).xp, 10)
        self.assertEqual(ReviewCard.objects.filter(user=self.user, vocabulary=self.word_nl).count(), 1)

    def test_incomplete_onboarding_denies_credit_and_card(self):
        Profile.objects.filter(user=self.user).update(onboarding_completed=False)
        self.assertEqual(self.client.post(reverse('word'), {'answer': 'hallo'}).status_code, 200)
        self._assert_no_mutation()

    def test_placement_revoked_denies_credit_and_card(self):
        Profile.objects.filter(user=self.user).update(placement_completed=False)
        self.assertEqual(self.client.post(reverse('word'), {'answer': 'hallo'}).status_code, 200)
        self._assert_no_mutation()

    def test_course_switch_during_spelling_check_denies_stale_word(self):
        def switch_during_answer(answer, target):
            Profile.objects.filter(user=self.user).update(preferred_language=self.fr)
            return True
        with patch('academy.daily_word_v18.word_matches', side_effect=switch_during_answer):
            response = self.client.post(reverse('word'), {'answer': 'hallo'})
        self.assertEqual(response.status_code, 200)
        self._assert_no_mutation()

    def test_word_unpublished_during_spelling_check_denies_credit(self):
        def unpublish_during_answer(answer, target):
            Vocabulary.objects.filter(pk=self.word_nl.pk).update(published=False)
            return True
        with patch('academy.daily_word_v18.word_matches', side_effect=unpublish_during_answer):
            response = self.client.post(reverse('word'), {'answer': 'hallo'})
        self.assertEqual(response.status_code, 200)
        self._assert_no_mutation()

    def test_course_unpublished_during_spelling_check_denies_credit(self):
        def unpublish_during_answer(answer, target):
            Language.objects.filter(pk=self.nl.pk).update(is_published=False)
            return True
        with patch('academy.daily_word_v18.word_matches', side_effect=unpublish_during_answer):
            response = self.client.post(reverse('word'), {'answer': 'hallo'})
        self.assertEqual(response.status_code, 200)
        self._assert_no_mutation()

    def test_switch_after_first_reward_does_not_award_again(self):
        self.assertEqual(self.client.post(reverse('word'), {'answer': 'hallo'}).status_code, 200)
        Profile.objects.filter(user=self.user).update(preferred_language=self.fr)
        self.assertEqual(self.client.post(reverse('word'), {'answer': 'bonjour'}).status_code, 200)
        self.assertEqual(Profile.objects.get(user=self.user).xp, 10)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='daily_word').count(), 1)

    def test_anonymous_can_practise_without_credit(self):
        self.client.logout()
        self.assertEqual(self.client.post(reverse('word'), {'answer': 'hallo'}).status_code, 200)
        self._assert_no_mutation()

    def test_revoked_account_does_not_claim_false_already_earned(self):
        Profile.objects.filter(user=self.user).update(placement_completed=False)
        response = self.client.post(reverse('word'), {'answer': 'hallo'})
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.context['daily_claimed'])
        self.assertFalse(response.context['daily_reward_new'])
        self._assert_no_mutation()

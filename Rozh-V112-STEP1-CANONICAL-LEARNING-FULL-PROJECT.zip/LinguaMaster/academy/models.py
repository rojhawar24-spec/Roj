"""Teaching, assessment, social, governance, and privacy domain models."""
import uuid
import os
from decimal import Decimal
from django.conf import settings
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models
from django.utils import timezone

LEVELS = [('A0','A0 · Pre-A1'), ('A1','A1'), ('A2','A2'), ('B1','B1'), ('B2','B2'), ('C1','C1')]
SKILLS = [('reading','Reading'),('listening','Listening'),('speaking','Speaking'),('writing','Writing'),('grammar','Grammar')]

from .auth_security import EncryptedTOTPField

class Language(models.Model):
    code = models.CharField(max_length=8, unique=True)
    name = models.CharField(max_length=80)
    slug = models.SlugField(unique=True)
    description = models.TextField()
    is_published = models.BooleanField(default=False)
    content_version = models.PositiveIntegerField(default=1)
    def __str__(self): return self.name
    def get_absolute_url(self): return f'/languages/{self.slug}/'

class Level(models.Model):
    language = models.ForeignKey(Language, on_delete=models.CASCADE, related_name='levels')
    code = models.CharField(max_length=2, choices=LEVELS)
    description = models.TextField()
    order = models.PositiveSmallIntegerField(default=0)
    content_version = models.PositiveIntegerField(default=1)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['language','code'], name='unique_language_level')]
        ordering = ['order']
    def __str__(self): return f'{self.language} {self.code}'
    def get_absolute_url(self): return f'/languages/{self.language.slug}/{self.code.lower()}/'

class Unit(models.Model):
    level = models.ForeignKey(Level, on_delete=models.CASCADE, related_name='units')
    season = models.ForeignKey('LearningSeason', on_delete=models.SET_NULL, related_name='units', null=True, blank=True)
    slug = models.SlugField(max_length=100)
    title = models.CharField(max_length=160)
    summary = models.TextField()
    outcomes = models.JSONField(default=list)
    prerequisites = models.ManyToManyField('self', symmetrical=False, blank=True)
    order = models.PositiveIntegerField(default=0)
    published = models.BooleanField(default=False)
    content_version = models.PositiveIntegerField(default=1)
    class Meta:
        ordering = ['order','id']
        constraints = [models.UniqueConstraint(fields=['level','slug'], name='unique_level_unit')]
    def clean(self):
        from django.core.exceptions import ValidationError
        super().clean()
        if self.season_id and self.level_id and self.season.level_id != self.level_id:
            raise ValidationError({'season': 'Season and unit must belong to the same CEFR level.'})
    def __str__(self): return self.title
    def get_absolute_url(self): return f'/units/{self.pk}/' 

class Lesson(models.Model):
    unit = models.ForeignKey(Unit, on_delete=models.CASCADE, related_name='lessons')
    slug = models.SlugField()
    title = models.CharField(max_length=160)
    skill = models.CharField(max_length=12, choices=SKILLS)
    content = models.TextField(help_text='Plain text; never rendered as trusted HTML')
    audio_text = models.TextField(blank=True, help_text='Text to synthesize using the device voice')
    order = models.PositiveIntegerField(default=0)
    published = models.BooleanField(default=False)
    content_version = models.PositiveIntegerField(default=1)
    class Meta:
        ordering = ['order','id']
        constraints = [models.UniqueConstraint(fields=['unit','slug'],name='unique_unit_lesson')]
    def __str__(self): return self.title
    def get_absolute_url(self): return f'/lessons/{self.pk}/'

class Exercise(models.Model):
    from .lesson_activities_v58 import ALL_KIND_CHOICES as KINDS
    lesson = models.ForeignKey(Lesson,on_delete=models.CASCADE,related_name='exercises')
    kind = models.CharField(max_length=24,choices=KINDS,default='mcq')
    prompt = models.TextField()
    options = models.JSONField(default=list,blank=True)
    answer = models.CharField(max_length=300, blank=True)
    activity_data = models.JSONField(default=dict, blank=True, help_text='V58: type-specific authored data; see editor guidance. No learner answers stored here.')
    explanation = models.TextField()
    difficulty = models.PositiveSmallIntegerField(default=2, validators=[MinValueValidator(1),MaxValueValidator(5)])
    content_version = models.PositiveIntegerField(default=1)
    order = models.PositiveSmallIntegerField(default=0)
    class Meta:
        ordering = ['order','pk']

class GrammarTopic(models.Model):
    level = models.ForeignKey(Level,on_delete=models.CASCADE,related_name='grammar_topics')
    slug = models.SlugField(max_length=100)
    title = models.CharField(max_length=140)
    explanation = models.TextField()
    examples = models.JSONField(default=list)
    exceptions = models.TextField()
    common_mistakes = models.TextField()
    audio_text = models.TextField(blank=True)
    check_question = models.TextField()
    check_options = models.JSONField(default=list)
    check_answer = models.CharField(max_length=180)
    published = models.BooleanField(default=False)
    content_version = models.PositiveIntegerField(default=1)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['level','slug'],name='unique_level_grammar')]
    def __str__(self): return self.title
    def get_absolute_url(self): return f'/grammar/{self.pk}/'

class Vocabulary(models.Model):
    level = models.ForeignKey(Level,on_delete=models.CASCADE,related_name='vocabulary')
    word = models.CharField(max_length=120)
    translation = models.CharField(max_length=200)
    pronunciation = models.CharField(max_length=200)
    example = models.TextField()
    word_family = models.CharField(max_length=300, blank=True)
    usage_notes = models.TextField(blank=True)
    emoji = models.CharField(max_length=8,default='📖')
    content_version = models.PositiveIntegerField(default=1)
    published = models.BooleanField(default=False)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['level','word'],name='unique_level_word')]
    def __str__(self): return self.word

class Profile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name='learning_profile')
    preferred_language = models.ForeignKey(Language,on_delete=models.SET_NULL,null=True,blank=True)
    from .ui_languages_v74 import LANGUAGE_CHOICES
    UI_LANGUAGES = list(LANGUAGE_CHOICES)
    DAILY_GOALS = [(10,'Casual · 10 XP'),(20,'Regular · 20 XP'),(35,'Serious · 35 XP'),(50,'Intense · 50 XP')]
    ui_language = models.CharField(max_length=3, choices=UI_LANGUAGES, default='en')
    daily_goal_xp = models.PositiveSmallIntegerField(choices=DAILY_GOALS, default=20)
    # Existing accounts (including staff/manager/demo) inherit False; only NEW
    # self-registered learner accounts explicitly opt in to the one-time wizard.
    onboarding_required = models.BooleanField(default=False)
    onboarding_completed = models.BooleanField(default=False)
    placement_completed = models.BooleanField(default=False)
    placement_level = models.CharField(max_length=2,choices=LEVELS,default='A0')
    avatar = models.CharField(max_length=8, default='🎓')  # emoji; no risky user file uploads
    bio = models.CharField(max_length=160,blank=True)
    xp = models.PositiveIntegerField(default=0)
    coins = models.PositiveIntegerField(default=0)  # earned in immutable CoinEvent ledger
    streak = models.PositiveIntegerField(default=0)
    last_active_day = models.DateField(null=True,blank=True)
    leaderboard_opt_in = models.BooleanField(default=False)
    social_opt_in = models.BooleanField(default=False)
    reminder_opt_in = models.BooleanField(default=False)
    summary_opt_in = models.BooleanField(default=False)
    last_reminder_sent = models.DateField(null=True,blank=True)
    last_summary_sent = models.DateField(null=True,blank=True)
    ai_opt_in = models.BooleanField(default=False)
    # TOTP seeds are encrypted before storage; historical plaintext is migrated.
    totp_secret = EncryptedTOTPField(max_length=255,blank=True)
    mfa_last_totp_step = models.BigIntegerField(default=-1)
    mfa_recovery_hashes = models.JSONField(default=list,blank=True)
    email_verified_at = models.DateTimeField(null=True,blank=True)
    # Suspension is independent of email ownership. Verification may never clear it.
    suspended_at = models.DateTimeField(null=True, blank=True)
    # A manager unblock restores only the activation state present at suspension.
    suspended_was_active = models.BooleanField(default=False)
    # Historical inactive/unverified account whose prior manager-block status
    # cannot be reconstructed after audit logs expire. Requires owner review.
    # New registrations are not quarantined (False by default).
    legacy_review_required = models.BooleanField(default=False)
    # Monotonic version ensures old verification URLs cannot revive following a
    # manager block, unblock, or explicit legacy-review approval.
    email_verification_version = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self): return self.user.get_username()

class OnboardingDraft(models.Model):
    """Private, per-account wizard progress. Profile is committed only at the end."""
    id = models.BigAutoField(primary_key=True, serialize=False)
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name='onboarding_draft')
    step = models.PositiveSmallIntegerField(default=1)
    ui_language = models.CharField(max_length=3, blank=True, default='')
    preferred_language = models.ForeignKey(Language, on_delete=models.SET_NULL,
                                           null=True, blank=True)
    start_choice = models.CharField(max_length=12, blank=True, default='')
    daily_goal_xp = models.PositiveSmallIntegerField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)


class LessonProgress(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    lesson = models.ForeignKey(Lesson,on_delete=models.CASCADE)
    completed_at = models.DateTimeField(default=timezone.now)
    score = models.PositiveSmallIntegerField(default=0)
    content_version = models.PositiveIntegerField(default=1)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['user','lesson'],name='one_lesson_completion')]

class Assessment(models.Model):
    KINDS = [('unit','Unit test'),('level','Level test'),('placement','Placement test'),('practice','Adaptive practice')]
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    kind = models.CharField(max_length=12,choices=KINDS)
    unit = models.ForeignKey(Unit,on_delete=models.CASCADE,null=True,blank=True)
    level = models.ForeignKey(Level,on_delete=models.CASCADE,null=True,blank=True)
    score = models.PositiveSmallIntegerField(default=0)
    passed = models.BooleanField(default=False)
    attempted_at = models.DateTimeField(default=timezone.now)
    responses = models.JSONField(default=dict)
    class Meta:
        indexes = [models.Index(fields=['user','kind','passed'],name='assessment_usr_kind_idx')]

class DailyWordEntry(models.Model):
    """Learner-local, per-course daily assignment. First view freezes the word."""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='daily_word_entries')
    course = models.ForeignKey(Language, on_delete=models.CASCADE, related_name='daily_word_entries')
    day = models.DateField()
    vocabulary = models.ForeignKey(Vocabulary, on_delete=models.SET_NULL, null=True, related_name='daily_assignments')
    cycle = models.PositiveIntegerField(default=1)
    word_text = models.CharField(max_length=120, default='')
    meaning_text = models.CharField(max_length=200, default='')
    example_text = models.TextField(blank=True, default='')
    pronunciation_text = models.CharField(max_length=200, blank=True, default='')
    emoji_text = models.CharField(max_length=8, default='📖')
    first_seen_at = models.DateTimeField(default=timezone.now)
    completed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['user', 'course', 'day'], name='unique_daily_word_course_day')]
        indexes = [models.Index(fields=['user', 'course', 'day'], name='daily_word_user_week_idx')]


class DailyWordWeeklySession(models.Model):
    """One once-weekly spelling session, containing a frozen prior-week snapshot."""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='daily_weekly_sessions')
    course = models.ForeignKey(Language, on_delete=models.CASCADE, related_name='daily_weekly_sessions')
    week_start = models.DateField()
    items = models.JSONField(default=list)
    position = models.PositiveSmallIntegerField(default=0)
    completed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['user', 'course', 'week_start'], name='unique_daily_weekly_session')]


class ReviewCard(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    vocabulary = models.ForeignKey(Vocabulary,on_delete=models.CASCADE)
    repetitions = models.PositiveSmallIntegerField(default=0)
    interval_days = models.PositiveIntegerField(default=1)
    ease = models.FloatField(default=2.5)
    due = models.DateTimeField(default=timezone.now)
    last_quality = models.PositiveSmallIntegerField(default=0)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['user','vocabulary'],name='one_review_card')]
        indexes = [models.Index(fields=['user','due'],name='review_due_idx')]

class Friendship(models.Model):
    STATES = [('pending','Pending'),('accepted','Accepted'),('blocked','Blocked')]
    from_user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name='friendships_sent')
    to_user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name='friendships_received')
    status = models.CharField(max_length=8,choices=STATES,default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['from_user','to_user'],name='unique_friend_request'),
                       models.CheckConstraint(condition=~models.Q(from_user=models.F('to_user')),name='cannot_friend_self')]

class Badge(models.Model):
    TIERS = [('gold','Gold'),('platinum','Platinum'),('diamond','Diamond')]
    slug = models.SlugField(unique=True)
    name = models.CharField(max_length=100)
    tier = models.CharField(max_length=12,choices=TIERS)
    description = models.TextField()
    xp_threshold = models.PositiveIntegerField(default=0)
    def __str__(self): return self.name

class BadgeAward(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name='badge_awards')
    badge = models.ForeignKey(Badge,on_delete=models.PROTECT)
    granted_at = models.DateTimeField(default=timezone.now)
    issued_by = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.SET_NULL,null=True,blank=True,related_name='+')
    revoked_at = models.DateTimeField(null=True,blank=True)
    revoke_reason = models.CharField(max_length=200,blank=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['user','badge'],name='one_badge_award')]

class Certificate(models.Model):
    serial = models.UUIDField(default=uuid.uuid4,unique=True,editable=False)
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name='certificates')
    level = models.ForeignKey(Level,on_delete=models.PROTECT)
    issued_at = models.DateTimeField(default=timezone.now)
    issued_by = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.SET_NULL,null=True,blank=True,related_name='+')
    revoked_at = models.DateTimeField(null=True,blank=True)
    revoke_reason = models.CharField(max_length=200,blank=True)
    verified_learning = models.BooleanField(default=True,help_text='Platform course completion, NOT formal CEFR accreditation')
    class Meta:
        indexes = [models.Index(fields=['user','level'],name='cert_usr_level_idx')]

class ContentRevision(models.Model):
    model_label = models.CharField(max_length=80)
    object_pk = models.PositiveIntegerField()
    version = models.PositiveIntegerField()
    editor = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.SET_NULL,null=True,blank=True)
    timestamp = models.DateTimeField(default=timezone.now)
    snapshot = models.JSONField()
    class Meta:
        ordering = ['-timestamp']

class PlatformSettings(models.Model):
    """Owner-only settings. Singleton id=1 (created on first manager visit)."""
    ai_enabled = models.BooleanField(default=False)
    ai_emergency_stop = models.BooleanField(default=True)
    ai_daily_limit = models.PositiveSmallIntegerField(default=5)
    ai_monthly_limit = models.PositiveSmallIntegerField(default=50)
    ai_monthly_budget_eur = models.DecimalField(max_digits=9,decimal_places=2,default=Decimal('0.00'))
    ai_input_eur_per_million = models.DecimalField(max_digits=9,decimal_places=3,default=Decimal('1.000'))
    ai_output_eur_per_million = models.DecimalField(max_digits=9,decimal_places=3,default=Decimal('4.000'))
    ai_moderation_reserve_eur = models.DecimalField(max_digits=8,decimal_places=4,default=Decimal('0.0020'))
    organization_name = models.CharField(max_length=120,default='LinguaMaster')
    privacy_email = models.EmailField(blank=True)
    public_registration_enabled = models.BooleanField(default=True)
    updated_at = models.DateTimeField(auto_now=True)
    @classmethod
    def load(cls): return cls.objects.get_or_create(pk=1, defaults={'privacy_email':os.environ.get('PUBLIC_PRIVACY_EMAIL','')})[0]

class AIUsage(models.Model):
    STATES = [('reserved','Reserved'),('blocked','Moderation blocked'),('ok','Completed'),('error','Failed')]
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.SET_NULL,null=True,blank=True)
    created_at = models.DateTimeField(default=timezone.now)
    status = models.CharField(max_length=10,choices=STATES,default='reserved')
    estimated_eur = models.DecimalField(max_digits=9,decimal_places=4,default=0)
    actual_eur = models.DecimalField(max_digits=9,decimal_places=4,default=0)
    prompt_sha256 = models.CharField(max_length=64)
    input_tokens = models.PositiveIntegerField(default=0)
    output_tokens = models.PositiveIntegerField(default=0)
    model_name = models.CharField(max_length=100)
    reason_code = models.CharField(max_length=80,blank=True)
    class Meta:
        indexes = [models.Index(fields=['user','created_at'],name='ai_usage_usr_date_idx'),models.Index(fields=['created_at','status'],name='ai_usage_date_status_idx')]

class AuditEvent(models.Model):
    actor = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.SET_NULL,null=True,blank=True)
    action = models.CharField(max_length=100)
    target = models.CharField(max_length=160)
    created_at = models.DateTimeField(default=timezone.now)
    metadata = models.JSONField(default=dict)
    class Meta:
        ordering = ['-created_at']


class XPEvent(models.Model):
    """Immutable earning history. Unique event_key prevents double rewards."""
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name='xp_events')
    reason = models.CharField(max_length=24)
    amount = models.PositiveSmallIntegerField(validators=[MinValueValidator(1),MaxValueValidator(250)])
    event_key = models.CharField(max_length=100,unique=True)
    created_at = models.DateTimeField(default=timezone.now)
    class Meta:
        indexes = [models.Index(fields=['user','created_at'],name='xpevent_user_date_idx')]

class SeasonGift(models.Model):
    """Manager-controlled per-course CEFR-season chest (no external payments)."""
    level = models.OneToOneField(Level, on_delete=models.CASCADE, related_name='season_gift')
    enabled = models.BooleanField(default=True)
    emoji = models.CharField(max_length=8, default='🎁')
    bonus_xp = models.PositiveSmallIntegerField(default=50, validators=[MaxValueValidator(250)])
    bonus_coins = models.PositiveIntegerField(default=100, validators=[MaxValueValidator(5000)])
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'{self.level} • {self.bonus_xp} XP + {self.bonus_coins} coins'


class SeasonGiftClaim(models.Model):
    """One irreversible server-issued award per learner and course season."""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='season_gifts_claimed')
    level = models.ForeignKey(Level, on_delete=models.PROTECT, related_name='season_gift_claims')
    xp_awarded = models.PositiveSmallIntegerField(default=0)
    coins_awarded = models.PositiveIntegerField(default=0)
    claimed_at = models.DateTimeField(default=timezone.now)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['user', 'level'], name='one_season_gift_claim')]
        indexes = [models.Index(fields=['user', 'claimed_at'], name='season_gift_claim_usr_idx')]


class CoinEvent(models.Model):
    """Append-only earned-coin evidence; shop spending will add debit events later."""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='coin_events')
    key = models.CharField(max_length=100)
    amount = models.PositiveIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5000)])
    reason = models.CharField(max_length=24, default='season')
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['user', 'key'], name='unique_coin_event_per_user')]
        indexes = [models.Index(fields=['user', 'created_at'], name='coin_event_user_date_idx')]


class MistakeRecord(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name='mistakes')
    exercise = models.ForeignKey(Exercise,on_delete=models.CASCADE)
    wrong_count = models.PositiveIntegerField(default=1)
    corrected_at = models.DateTimeField(null=True,blank=True)
    last_wrong_at = models.DateTimeField(default=timezone.now)
    class Meta:
        constraints=[models.UniqueConstraint(fields=['user','exercise'],name='one_mistake_per_exercise')]
        indexes=[models.Index(fields=['user','corrected_at'],name='mistake_user_open_idx')]

class ArenaRun(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name='arena_runs')
    level = models.ForeignKey(Level,on_delete=models.CASCADE)
    started_at = models.DateTimeField(default=timezone.now)
    deadline = models.DateTimeField()
    finished_at = models.DateTimeField(null=True,blank=True)
    question_ids = models.JSONField(default=list)
    responses = models.JSONField(default=dict)
    score = models.PositiveSmallIntegerField(default=0)
    earned_xp = models.PositiveSmallIntegerField(default=0)
    class Meta:
        indexes=[models.Index(fields=['user','started_at'],name='arena_user_date_idx')]

class DailyChest(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name='daily_chests')
    day = models.DateField()
    bonus_xp = models.PositiveSmallIntegerField(default=10)
    opened_at = models.DateTimeField(default=timezone.now)
    class Meta:
        constraints=[models.UniqueConstraint(fields=['user','day'],name='one_daily_chest')]

class AppNotification(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name='notifications')
    event_key = models.CharField(max_length=120,unique=True)
    title = models.CharField(max_length=100)
    message = models.CharField(max_length=260)
    created_at = models.DateTimeField(default=timezone.now)
    read_at = models.DateTimeField(null=True,blank=True)
    class Meta:
        ordering=['-created_at']


class SkillPracticeAttempt(models.Model):
    """Privacy-minimized exercise attempts, never a certified language assessment."""
    KIND_CHOICES = [('speaking', 'Speaking'), ('writing', 'Writing'), ('listening', 'Listening')]
    INPUT_METHODS = [('microphone', 'Browser recognition'), ('typed', 'Typed text')]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='skill_attempts')
    vocabulary = models.ForeignKey(Vocabulary, on_delete=models.SET_NULL, null=True, blank=True)
    kind = models.CharField(max_length=10, choices=KIND_CHOICES)
    score = models.PositiveSmallIntegerField(validators=[MinValueValidator(0), MaxValueValidator(100)])
    input_method = models.CharField(max_length=10, choices=INPUT_METHODS, default='typed')
    answer_length = models.PositiveSmallIntegerField(default=0)
    created_at = models.DateTimeField(default=timezone.now)
    class Meta:
        indexes = [models.Index(fields=['user','created_at'], name='skill_practice_usr_dt_idx')]


# Keep feature models in focused modules while registering them with Django.
from .social_models import SocialGift, AvatarStyle
from .grammar_models import GrammarMastery
from .progress_models import LearningPreferences
from .billing_models import AICreditWallet, AICreditPurchase, AICreditDebit, StripeWebhookReceipt
from .grammar_rich_models import GrammarArticle
from .course_models import CourseEnrollment
from .heart_models import HeartBalance, HeartEvent
from .visual_models import PhotoAttempt


class LearningSeason(models.Model):
    """Editable season group, with V70 published-sequence access checks.

    Units in a subsequent published season of the SAME CEFR band unlock only
    after the preceding season's published levels/units are complete. Existing
    CEFR placement, level exam and explicit unit prerequisite gates still apply.
    Unassigned units retain legacy progression and are never deleted.
    """
    # Match the explicit id in migration 0011; do not generate an unnecessary 0012.
    id = models.BigAutoField(primary_key=True, serialize=False)
    THEMES = [('coast','Coast'),('grove','Grove'),('dawn','Dawn'),('sky','Sky')]
    level = models.ForeignKey(Level, on_delete=models.PROTECT, related_name='rozh_seasons')
    slug = models.SlugField(max_length=100)
    title = models.CharField(max_length=140)
    description = models.CharField(max_length=240, blank=True)
    order = models.PositiveIntegerField(default=0)
    theme = models.CharField(max_length=12, choices=THEMES, default='coast')
    published = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ('level__language_id','level__order','order','pk')
        constraints = [models.UniqueConstraint(fields=('level','slug'),name='unique_rozh_level_season_slug')]
    def __str__(self):
        return f'{self.level} — {self.title}'


# V77: dedicated educator-reviewed adaptive placement bank and private attempts.
from .placement_models_v77 import PlacementBankItem, PlacementRun

# Step 3H durable round receipts: authoritative across overlapping HTTP sessions.
from .lesson_round_models_step3h import LessonRoundReceipt

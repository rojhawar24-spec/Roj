"""Real app missions: onboarding, vocabulary, mistake repair, timed Arena, chest and notifications.
Public learning content belongs in the existing academy models. Every rewarded action is validated on the server.
"""
import secrets
from datetime import timedelta
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Q
from django.http import HttpResponse, HttpResponseBadRequest
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST, require_GET
from .models import (Language,Level,Exercise,Vocabulary,ReviewCard,LessonProgress,MistakeRecord,Assessment,
                     ArenaRun,DailyChest,AppNotification,XPEvent,Profile)
from .forms import OnboardingForm
from .services import rate_limit, grade, award_xp, daily_xp, learning_level, record_exercise_result, user_localdate, learning_day_bounds
from .chest_policy_v34 import chest_claim_allowed
from .account_signin_policy_v27 import account_signin_permitted

LEVEL_ORDER=['A0','A1','A2','B1','B2','C1']

def arena_unlocked_index(user,language,*,profile=None):
    """Placement unlocks that band; passing a level test unlocks the next band.

    A supplied locked Profile is authoritative even when user.learning_profile
    was cached before another transaction changed the student's course.
    """
    if profile is None:
        profile=user.learning_profile
    highest=LEVEL_ORDER.index(profile.placement_level) if profile.placement_level in LEVEL_ORDER else 0
    passed=Assessment.objects.filter(user=user,kind='level',passed=True,level__language=language).values_list('level__code',flat=True)
    for code in passed:
        if code in LEVEL_ORDER:highest=max(highest,min(5,LEVEL_ORDER.index(code)+1))
    return highest


def arena_run_authorized(user, run, *, profile=None):
    """Enforce CURRENT course and prerequisites for every Arena request.

    An ArenaRun is historical state, not a durable permission grant. Switching
    courses, revoking onboarding/placement, or locking the level must invalidate
    an unsubmitted run without deleting it or altering the user's progress.
    """
    if profile is None:
        profile = user.learning_profile
    if (profile.onboarding_required and not profile.onboarding_completed) or not profile.placement_completed:
        return False
    if profile.preferred_language_id != run.level.language_id:
        return False
    if not run.level.language.is_published or run.level.code not in LEVEL_ORDER:
        return False
    return LEVEL_ORDER.index(run.level.code) <= arena_unlocked_index(
        user, run.level.language, profile=profile)


# V52: dedicated account-scoped, four-screen onboarding; legacy three-field form retired.
from .onboarding_v52 import onboarding, ready as onboarding_ready_v52

@login_required
@require_GET
def vocabulary_library(request):
    """Read-only published vocabulary for the learner's selected course.

    Never resurrect the retired vocabulary-save mutation or expose unpublished
    words. Pagination keeps the library usable for large dictionaries.
    """
    from django.core.paginator import Paginator
    from django.db.models import Q
    from .rozh2027 import student_shell_context
    from .rozh_vocabulary_ui import for_language
    profile = Profile.objects.filter(user_id=request.user.pk).first()
    if not account_signin_permitted(request.user, profile):
        return HttpResponse('Account unavailable.', status=403)
    language = profile.preferred_language
    shell = student_shell_context(request)
    ui = for_language(shell['R27_LANG'])
    level = request.GET.get('level', '').upper()[:2]
    if level not in LEVEL_ORDER: level = ''
    query = request.GET.get('q', '').strip()[:80]
    rows = Vocabulary.objects.none()
    if language and language.is_published:
        rows = Vocabulary.objects.filter(published=True, level__language=language,
            level__language__is_published=True).select_related('level').order_by('level__order', 'word', 'pk')
        if level: rows = rows.filter(level__code=level)
        if query: rows = rows.filter(Q(word__icontains=query)|Q(translation__icontains=query)|Q(example__icontains=query))
    page = Paginator(rows, 24).get_page(request.GET.get('page'))
    return render(request, 'academy/rozh2027_vocabulary.html', {
        **shell, 'VOCAB_UI':ui, 'page_title':shell['R27']['vocab'],
        'page_description':ui['intro'],
        'vocab_items':page, 'vocab_language':language, 'vocab_level':level,
        'vocab_query':query, 'vocab_levels':LEVEL_ORDER, 'noindex':True,
        'seo_title':'Vocabulary | Rozh',
    })

@login_required
@require_POST
def vocabulary_save(request,pk):
    """Never mutate old review data through a retired POST endpoint."""
    return HttpResponse('This feature has been retired.', status=410)

@login_required
def mistakes(request):
    if request.method=='POST':
        if rate_limit(request,'mistake-review',40,3600,True):return HttpResponse('Too many answers.',status=429)
        with transaction.atomic():
            mistake=get_object_or_404(MistakeRecord.objects.select_for_update().select_related('exercise'),
                                      pk=request.POST.get('mistake_id'),user=request.user,
                                      corrected_at__isnull=True,exercise__lesson__published=True,
                                      exercise__lesson__unit__published=True,
                                      exercise__lesson__unit__level__language__is_published=True)
            choice=request.POST.get('answer','')[:300]
            if mistake.exercise.kind=='mcq' and choice not in mistake.exercise.options:
                return HttpResponseBadRequest('Choose one of the provided answers.')
            correct=grade(mistake.exercise,choice)
            record_exercise_result(request.user,mistake.exercise,correct)
            if correct:
                credited = award_xp(request.user,5,reason='mistake',event_key=f'mistake:{mistake.pk}')
                if credited:
                    messages.success(request,'Mistake repaired! +5 XP (first correction only).')
                else:
                    messages.success(request,'Mistake repaired!')
            else:
                messages.error(request,'Not yet. Try again; the explanation is shown in your lesson.')
        return redirect('mistakes')
    pending=MistakeRecord.objects.filter(user=request.user,corrected_at__isnull=True,
                    exercise__lesson__published=True,exercise__lesson__unit__published=True,
                    exercise__lesson__unit__level__language__is_published=True).select_related('exercise__lesson').order_by('-wrong_count','last_wrong_at')
    count=pending.count()
    current=pending.first()
    resolved=MistakeRecord.objects.filter(user=request.user,corrected_at__isnull=False).count()
    return render(request,'academy/mistakes.html',{'pending':count,'resolved':resolved,'current':current,'noindex':True})

@login_required
def arena(request):
    profile=Profile.objects.filter(user_id=request.user.pk).first()
    if not account_signin_permitted(request.user, profile):
        return HttpResponse('Account unavailable.', status=403)
    if profile.onboarding_required and not profile.onboarding_completed:
        return redirect('onboarding')
    if not profile.placement_completed:
        return redirect('placement')
    language=(profile.preferred_language if profile.preferred_language and profile.preferred_language.is_published
              else None)
    levels=list(Level.objects.filter(language=language,language__is_published=True).order_by('order')) if language else []
    max_index=arena_unlocked_index(request.user,language)
    stages=[]
    for level in levels:
        unlocked=LEVEL_ORDER.index(level.code)<=max_index
        pool=Exercise.objects.filter(lesson__unit__level=level,lesson__published=True,
                    lesson__unit__published=True,kind='mcq').count()
        stages.append({'level':level,'unlocked':unlocked,'questions':pool})
    latest=ArenaRun.objects.filter(user=request.user,finished_at__isnull=False).select_related('level').order_by('-finished_at').first()
    day_start,day_end=learning_day_bounds(request.user,user_localdate(request.user))
    rewarded_today=ArenaRun.objects.filter(user=request.user,started_at__gte=day_start,
                                         started_at__lt=day_end,earned_xp__gt=0).count()
    return render(request,'academy/arena.html',{'stages':stages,'latest':latest,'rewarded_today':rewarded_today,'noindex':True})

@login_required
@require_POST
@transaction.atomic
def arena_start(request):
    if rate_limit(request,'arena-start',12,3600,True):return HttpResponse('Arena start limit reached.',status=429)
    # Use the same serialization point as switching courses and paying Arena XP.
    # An in-flight start must see one consistent current course and placement.
    profile=Profile.objects.select_for_update().get(user=request.user)
    if (profile.onboarding_required and not profile.onboarding_completed) or not profile.placement_completed:
        return HttpResponse('Complete onboarding and placement before Arena.',status=403)
    level=get_object_or_404(Level,pk=request.POST.get('level_id'),language=profile.preferred_language,
                            language__is_published=True)
    if (level.code not in LEVEL_ORDER or
            LEVEL_ORDER.index(level.code)>arena_unlocked_index(request.user,profile.preferred_language,profile=profile)):
        return HttpResponse('This level is not unlocked.',status=403)
    pool=list(Exercise.objects.filter(lesson__unit__level=level,lesson__published=True,
               lesson__unit__published=True,kind='mcq').order_by('pk')[:50])
    if len(pool)<3:return HttpResponse('This level needs at least three published multiple-choice questions.',status=503)
    chosen=secrets.SystemRandom().sample(pool,k=min(5,len(pool)))
    now=timezone.now()
    run=ArenaRun.objects.create(user=request.user,level=level,started_at=now,
          deadline=now+timedelta(seconds=90),question_ids=[item.pk for item in chosen])
    return redirect('arena_run',pk=run.pk)

@login_required
def arena_run(request,pk):
    run=get_object_or_404(ArenaRun.objects.select_related('level__language'),pk=pk,user=request.user)
    if not arena_run_authorized(request.user, run):
        return HttpResponse('This Arena round is no longer available in your current course.', status=403)
    questions=list(Exercise.objects.filter(
        pk__in=run.question_ids,kind='mcq',lesson__published=True,
        lesson__unit__published=True,lesson__unit__level=run.level,
        lesson__unit__level__language__is_published=True))
    by_id={q.pk:q for q in questions}
    questions=[by_id[pk] for pk in run.question_ids if pk in by_id]
    if len(questions)!=len(run.question_ids):return HttpResponse('A quiz question is unavailable.',status=503)
    remaining=max(0,int((run.deadline-timezone.now()).total_seconds()))
    if request.method=='POST':
        if rate_limit(request,'arena-answer',20,3600,True):return HttpResponse('Too many submissions.',status=429)
        # Validate ALL submitted choices before ANY database mutation. Returning
        # HttpResponseBadRequest inside atomic() would otherwise COMMIT writes.
        answers={}
        for question in questions:
            raw=request.POST.get(f'q_{question.pk}','')
            if len(raw)>300 or (raw and raw not in question.options):
                return HttpResponseBadRequest('Invalid quiz answer.')
            answers[str(question.pk)]=raw
        with transaction.atomic():
            # Shared per-user row is the serialization point for the daily cap.
            # Lock it BEFORE the ArenaRun row to keep reward lock ordering stable.
            locked_profile = Profile.objects.select_for_update().get(user=request.user)
            run=ArenaRun.objects.select_for_update().get(pk=run.pk,user=request.user)
            # Recheck INSIDE the same transaction after taking the Profile lock.
            # Course switching takes this lock as well: the submission can
            # never pay out from a stale profile read made before the switch.
            if not arena_run_authorized(request.user, run, profile=locked_profile):
                return HttpResponse('This Arena round is no longer available in your current course.', status=403)
            if run.finished_at:return redirect('arena_result',pk=run.pk)
            current_question_ids = set(Exercise.objects.filter(
                pk__in=run.question_ids, kind='mcq', lesson__published=True,
                lesson__unit__published=True, lesson__unit__level=run.level,
                lesson__unit__level__language__is_published=True,
            ).values_list('pk', flat=True))
            if current_question_ids != set(run.question_ids):
                return HttpResponse('An Arena question was withdrawn. Start a new round.', status=503)
            # No XP for late answers; still store a truthful result.
            on_time=timezone.now()<=run.deadline
            correct=0
            for question in questions:
                submitted=answers[str(question.pk)]
                passed=grade(question,submitted)
                correct+=int(passed)
                if submitted: record_exercise_result(request.user,question,passed)
            run.score=round(100*correct/len(questions))
            run.finished_at=timezone.now()
            run.responses=answers
            today=user_localdate(request.user)
            day_start,day_end=learning_day_bounds(request.user,today)
            today_rewards=ArenaRun.objects.filter(
                user=request.user,started_at__gte=day_start,started_at__lt=day_end,
                earned_xp__gt=0).exclude(pk=run.pk).count()
            if on_time and run.score>=80 and today_rewards<3:
                if award_xp(request.user,30,reason='arena',event_key=f'arena:{run.pk}'):
                    run.earned_xp=30
            run.save(update_fields=['score','finished_at','responses','earned_xp'])
        return redirect('arena_result',pk=run.pk)
    return render(request,'academy/arena_run.html',{'run':run,'questions':questions,'seconds':remaining,'noindex':True})

@login_required
def arena_result(request,pk):
    run=get_object_or_404(ArenaRun,pk=pk,user=request.user,finished_at__isnull=False)
    return render(request,'academy/arena_result.html',{'run':run,'noindex':True})

class ChestRewardConflict(Exception):
    """Prevent a chest row from being committed without a matching XP award."""


@login_required
def chest(request):
    # No fake claim button for a locked account or an archived course.
    profile = Profile.objects.select_related('preferred_language').filter(user=request.user).first()
    if profile is None:
        return HttpResponse('Learning profile unavailable.', status=403)
    today = user_localdate(request.user)
    earned = daily_xp(request.user, today)
    opened = DailyChest.objects.filter(user=request.user, day=today).first()
    day_start, day_end = learning_day_bounds(request.user, today)
    completed_lessons = LessonProgress.objects.filter(
        user=request.user, completed_at__gte=day_start, completed_at__lt=day_end,
    ).count()
    reviewed = XPEvent.objects.filter(
        user=request.user, reason='review', created_at__gte=day_start, created_at__lt=day_end,
    ).count()
    eligible = chest_claim_allowed(
        profile, user_active=request.user.is_active,
        course_published=bool(profile.preferred_language and profile.preferred_language.is_published),
    )
    return render(request, 'academy/chest.html', {
        'earned': earned, 'goal': profile.daily_goal_xp,
        'opened': opened, 'ready': earned >= 10 and eligible,
        'completed_lessons': completed_lessons, 'reviewed': reviewed, 'noindex': True,
    })


@login_required
@require_POST
def chest_open(request):
    if rate_limit(request, 'chest', 10, 3600, True):
        return HttpResponse('Too many attempts.', status=429)
    try:
        with transaction.atomic():
            # Profile first: the same serialization point used by course
            # switching and other rewards. Then lock its published course.
            profile = Profile.objects.select_for_update().filter(user=request.user).first()
            if profile is None or not profile.preferred_language_id:
                return HttpResponse('Complete course setup before claiming a chest.', status=403)
            language = (Language.objects.select_for_update()
                        .filter(pk=profile.preferred_language_id).first())
            if not chest_claim_allowed(
                profile, user_active=request.user.is_active,
                course_published=bool(language and language.is_published),
            ):
                return HttpResponse('This chest is unavailable for the current account or course.', status=403)
            # Use the SAME local day for eligibility and the immutable reward
            # key. Do not use a stale date computed before the Profile lock.
            today = user_localdate(request.user)
            if daily_xp(request.user, today) < 10:
                messages.error(request, 'Earn 10 learning XP before opening today’s chest.')
                return redirect('chest')
            chest, created = DailyChest.objects.get_or_create(
                user=request.user, day=today, defaults={'bonus_xp': 10},
            )
            if created:
                # If the durable XP key exists but the chest row does not,
                # roll back the new chest row rather than show phantom success.
                if not award_xp(request.user, 10, reason='chest',
                                event_key=f'chest:{today}', learning=False):
                    raise ChestRewardConflict()
                messages.success(request, 'Chest opened: +10 bonus XP!')
            else:
                messages.info(request, 'You already opened today’s chest.')
    except ChestRewardConflict:
        return HttpResponse('This chest reward was already credited.', status=409)
    return redirect('chest')


def _notifications_account_allowed(request, *, lock=False):
    """Re-evaluate account revocation before private notification access.

    A login session is not a permanent authorization grant. For read-receipt
    mutations, lock Profile first to serialize with Manager suspension/review.
    Never create a missing Profile as a side effect of reading notifications.
    """
    profiles = Profile.objects.select_for_update() if lock else Profile.objects
    profile = profiles.filter(user_id=request.user.pk).first()
    current_user = get_user_model().objects.filter(pk=request.user.pk).first()
    return account_signin_permitted(current_user, profile)


@login_required
@require_GET
def notifications(request):
    if not _notifications_account_allowed(request):
        return HttpResponse('Account access is currently restricted.', status=403)
    notes=AppNotification.objects.filter(user_id=request.user.pk)[:40]
    return render(request,'academy/notifications.html',{'notes':notes,'noindex':True})


@login_required
@require_POST
@transaction.atomic
def notifications_read(request):
    # Guard UNDER THE PROFILE LOCK, before marking any record as read.
    if not _notifications_account_allowed(request, lock=True):
        return HttpResponse('Account access is currently restricted.', status=403)
    AppNotification.objects.filter(user_id=request.user.pk,read_at__isnull=True).update(read_at=timezone.now())
    return redirect('notifications')

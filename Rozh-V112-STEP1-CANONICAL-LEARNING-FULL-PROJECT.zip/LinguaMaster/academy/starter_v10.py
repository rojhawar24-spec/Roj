"""Original, limited English starter material and a Dutch companion article.

Explanations use English. Course examples and speech text use the target language.
These are starter activities, not a complete or accredited A0–C1 syllabus.
"""


def question(prompt, options, answer, explanation):
    return {'kind': 'mcq', 'prompt': prompt, 'options': options,
            'answer': answer, 'explanation': explanation}


def short(prompt, answer, explanation):
    return {'kind': 'short', 'prompt': prompt, 'options': [],
            'answer': answer, 'explanation': explanation}


def lesson(skill, title, content, audio_text='', exercises=()):
    return {'skill': skill, 'title': title, 'content': content,
            'audio_text': audio_text, 'exercises': list(exercises)}


def word(text, translation, pronunciation, example, emoji):
    return {'word': text, 'translation': translation, 'pronunciation': pronunciation,
            'example': example, 'emoji': emoji}


BE_EXPLANATION = (
    'Use the present forms of be to introduce people, describe a state and say where someone is. '
    'Use I am, you are, he/she/it is, and we/they are. The subject normally comes before be in a statement: '
    'I am a student. In a yes/no question, put be before the subject: Are you a student? '
    'To make a negative, put not after be: She is not tired. '
    'English usually needs a stated subject, even when your first language permits leaving it out. '
    'The pronoun I always has a capital letter. For a singular countable job or role, use a/an: '
    'He is a teacher. There is no a/an with an adjective alone: He is friendly.'
)

BE_RICH = {
    'intro': 'A first conversation needs only a few useful patterns. Learn be as a small family of forms, then use it to describe yourself, ask about someone else and politely check information.',
    'learning_goals': ['Choose am, is or are for a stated subject.',
                       'Introduce yourself with a name, role and location.',
                       'Form a short yes/no question and a negative without do.'],
    'sections': [
        {'title': 'Say who someone is, how they feel or where they are',
         'body': 'Be joins a subject to information about it. Compare identity (I am Noor), a role (She is a student), a state (We are ready) and a place (They are at school). The information after be can be a name, a noun phrase, an adjective or a place phrase. Do not add a second ordinary present-tense verb directly after be: I learn English and I am happy are two different structures.'},
        {'title': 'Keep the subject and match the form',
         'body': 'Use I am; he, she and it is; you, we and they are. You takes are for one person and for more than one person. English statements normally keep a subject: I am ready, rather than Am ready. A name can replace a pronoun: Noor is ready. Two people joined with and normally take are: Noor and Adam are ready.'},
        {'title': 'Questions and short answers',
         'body': 'Move be in front of the subject to ask a yes/no question: You are new becomes Are you new? No form of do is needed. Answer Yes, I am or No, I am not. In a positive short answer, keep the full be form: Yes, she is. Avoid Yes, she’s as a complete short answer. With a question word, use Where are you? or Who is that?'},
        {'title': 'Negatives, contractions and natural introductions',
         'body': 'Put not after be: I am not late; he is not here; they are not tired. In ordinary speech and informal writing, I am becomes I’m, you are becomes you’re, and she is becomes she’s. Is not can become isn’t; are not can become aren’t. Full forms are useful when first learning the pattern. Say I am a teacher for a job, but I am Belgian for a nationality adjective. In the exercises, type only the requested missing word.'},
    ],
    'rule_tables': [
        {'title': 'Present forms of be', 'columns': ['Subject', 'Statement', 'Negative', 'Question'],
         'rows': [['I', 'I am ready.', 'I am not ready.', 'Am I ready?'],
                  ['you', 'You are ready.', 'You are not ready.', 'Are you ready?'],
                  ['he / she / it', 'She is ready.', 'She is not ready.', 'Is she ready?'],
                  ['we', 'We are ready.', 'We are not ready.', 'Are we ready?'],
                  ['they', 'They are ready.', 'They are not ready.', 'Are they ready?']],
         'note': 'You uses are for both one person and several people.'},
        {'title': 'Add the right kind of information', 'columns': ['Meaning', 'Example', 'Notice'],
         'rows': [['Name', 'I am Noor.', 'No article before a personal name.'],
                  ['Role', 'I am a student.', 'Use a/an with a singular countable role.'],
                  ['Feeling', 'I am happy.', 'No article before this adjective.'],
                  ['Place', 'I am at school.', 'Learn at school as a useful place phrase.']]},
    ],
    'sentence_patterns': [
        {'label': 'Statement: subject + be + information', 'tokens': [{'text': 'She', 'role': 'subject'}, {'text': 'is', 'role': 'verb'}, {'text': 'a teacher.', 'role': 'other'}]},
        {'label': 'Question: be + subject + information', 'tokens': [{'text': 'Are', 'role': 'verb'}, {'text': 'you', 'role': 'subject'}, {'text': 'at school?', 'role': 'place'}]},
        {'label': 'Negative: subject + be + not + information', 'tokens': [{'text': 'We', 'role': 'subject'}, {'text': 'are', 'role': 'verb'}, {'text': 'not', 'role': 'other'}, {'text': 'late.', 'role': 'other'}]},
    ],
    'example_pairs': [
        {'original': 'I am a student.', 'translation': 'I study as a learner.', 'note': 'Student is a singular countable role, so use a.'},
        {'original': 'My name is Noor.', 'translation': 'Noor is the name I use.', 'note': 'The subject is my name, so the verb is is.'},
        {'original': 'Are you from Belgium?', 'translation': 'Is Belgium the country you come from?', 'note': 'The question begins with are.'},
        {'original': 'They are not at home.', 'translation': 'They are somewhere else.', 'note': 'Not follows are; at home describes location.'},
    ],
    'common_traps': [
        {'wrong': 'I is a student.', 'correct': 'I am a student.', 'why': 'I takes am, not is.'},
        {'wrong': 'Do you are tired?', 'correct': 'Are you tired?', 'why': 'Questions with be put be before the subject and do not use do.'},
        {'wrong': 'She is teacher.', 'correct': 'She is a teacher.', 'why': 'A singular countable job or role normally needs a/an.'},
        {'wrong': 'We not are late.', 'correct': 'We are not late.', 'why': 'Not comes after the form of be.'},
    ],
}


COURSE = {
    'code': 'en', 'name': 'English', 'slug': 'english',
    'description': 'An original English starter course with guided A0 and A1 activities. Read short conversations, hear device speech, study clear grammar and practise on your own. The A2–C1 curriculum is still being developed; this is not a complete CEFR course.',
    'units': [
        {
            'level': 'A0', 'slug': 'introductions-with-be', 'title': 'Hello — introduce yourself',
            'summary': 'Use I am, you are and she is in a first conversation. Ask a simple question and explain who you are.',
            'outcomes': ['Introduce yourself with a name and role.', 'Match am, is and are to a subject.', 'Ask where someone is from.'],
            'explanation': BE_EXPLANATION,
            'examples': ['Hello, I am Noor.', 'You are a student.', 'Are you from Belgium?', 'She is not tired.'],
            'exceptions': 'Be is irregular. You takes are even when speaking to one person. In positive short answers use the full form: Yes, I am, rather than Yes, I’m.',
            'common_mistakes': 'Avoid I is and you am. Use a/an with a singular countable role: I am a student. Do not use do with a simple be question: Are you ready?',
            'rich': BE_RICH,
            'lessons': [
                lesson('grammar', 'Meet am, is and are', BE_EXPLANATION, 'I am Noor. You are a student. She is a teacher. We are ready.', [
                    question('Complete: I ___ a student.', ['am', 'is', 'are'], 'am', 'The present form of be with I is am: I am a student.'),
                    short('Type only the missing word: She ___ a teacher.', 'is', 'She takes is. A teacher describes her role.'),
                    question('Which question asks about someone’s country?', ['Are you from Belgium?', 'You from are Belgium.', 'Do you are from Belgium?'], 'Are you from Belgium?', 'Place are before you. Be questions do not need do.'),
                ]),
                lesson('reading', 'A first day at class', 'Read the whole exchange before answering.\n\nNoor: Hello. I am Noor. I am a student.\nAdam: Hi, Noor. My name is Adam. I am a teacher.\nNoor: Are you from Belgium?\nAdam: No, I am from Canada. Are you new here?\nNoor: Yes, I am.\n\nFollow each name carefully: Noor studies and Adam teaches. From introduces the country someone comes from. Use information in this exchange rather than guessing from the names.', 'Hello. I am Noor. I am a student. My name is Adam. I am a teacher. I am from Canada.', [
                    question('Who is the student?', ['Noor', 'Adam', 'Both people'], 'Noor', 'Noor says I am a student. Adam says he is a teacher.'),
                    short('Type only the country Adam is from.', 'Canada', 'Adam says No, I am from Canada. Belgium appears in the question, not his answer.'),
                    question('What does My name is Adam tell you?', ['His name', 'His age', 'His home address'], 'His name', 'My name is introduces the name a person uses.'),
                ]),
                lesson('listening', 'Listen for who and where', 'Play the audio using the listen button. Listen once for the people and a second time for their locations. You can replay it. The transcript below is available as support, so this is guided listening rather than a secure listening examination.\n\nHello. I am Maya. I am at home. My friend Leo is at school. We are not tired. We are ready to learn.\n\nDevice speech depends on an installed English voice; if no voice is available, read the transcript aloud yourself.', 'Hello. I am Maya. I am at home. My friend Leo is at school. We are not tired. We are ready to learn.', [
                    question('Where is Maya?', ['At home', 'At school', 'At work'], 'At home', 'Maya says I am at home. Leo is the person at school.'),
                    short('Type only the name of the person at school.', 'Leo', 'The audio says My friend Leo is at school.'),
                    question('How do Maya and Leo feel?', ['Ready to learn', 'Too tired to learn', 'Angry'], 'Ready to learn', 'They are not tired and are ready to learn.'),
                ]),
                lesson('speaking', 'Say your own introduction', 'Say three short sentences: Hello, I am ___. I am a ___. I am from ___. You may invent a name, role and country instead of sharing personal details. Then ask an imaginary partner: Are you a student? Answer Yes, I am or No, I am not. Listen to the model and repeat it slowly. Check that you used am with I and are before you in the question. This task records self-reviewed participation; it does not score pronunciation or verify speaking proficiency.', 'Hello, I am Noor. I am a student. I am from Belgium. Are you a student? Yes, I am.'),
                lesson('writing', 'Write a tiny profile', 'Write four sentences in your own notes: give a fictional name, a role, a country and one negative description. Model: I am Noor. I am a student. I am from Belgium. I am not tired. Start each sentence with a capital letter and end it with a full stop. Underline am in every sentence. Check that student has a before it and that I is capitalized. This is self-reviewed writing, without independent grammar grading or XP for a verified writing skill.'),
            ],
            'vocabulary': [
                word('hello', 'a greeting', '/həˈləʊ/', 'Hello, I am Noor.', '👋'),
                word('student', 'a person who studies', '/ˈstjuːdənt/', 'I am a student.', '🎓'),
                word('teacher', 'a person who teaches', '/ˈtiːtʃə/', 'Adam is a teacher.', '📚'),
                word('ready', 'prepared to begin', '/ˈredi/', 'We are ready to learn.', '✅'),
                word('home', 'the place where someone lives', '/həʊm/', 'I am at home.', '🏠'),
                word('friend', 'a person you like and know well', '/frend/', 'Leo is my friend.', '🤝'),
            ],
        },
        {
            'level': 'A0', 'slug': 'a-an-and-plural-things', 'title': 'Everyday things — a, an and plurals',
            'summary': 'Name objects with a/an, recognize more than one thing and use this is or these are.',
            'outcomes': ['Choose a or an by the next sound.', 'Recognize a regular plural.', 'Describe one or several familiar objects.'],
            'explanation': 'Use a or an before a singular countable noun when you introduce one nonspecific thing: a book, an apple. Choose by sound: an apple begins with a vowel sound, while a university begins with a consonant /j/ sound. To talk about more than one, many nouns add -s: book → books. Nouns ending in -s, -sh, -ch or -x often add -es: box → boxes. Some plurals are irregular, such as child → children. Do not put a/an before a plural. Use this is for one nearby object and these are for several: This is a book. These are books.',
            'examples': ['This is a book.', 'This is an apple.', 'These are two boxes.', 'I have three books.'],
            'exceptions': 'A/an depends on sound, not spelling: an hour, a university. Irregular plurals such as children need individual practice. Uncountable nouns such as water do not normally take a/an in their basic meaning.',
            'common_mistakes': 'Avoid an book, a apples and two box. Say a book, apples and two boxes. These takes are, not is.',
            'lessons': [
                lesson('grammar', 'One thing or several?', 'A and an introduce one countable thing. Choose a before a consonant sound and an before a vowel sound: a bag, an apple. For two or more, use a plural: two bags, three apples. Box becomes boxes. Do not add a/an to a plural. Use This is a bag for one object and These are bags for several. Learn nouns together with an example, because irregular plurals and sound-based article choices need practice.', 'This is a bag. This is an apple. These are two boxes.', [
                    question('Choose the phrase for one apple.', ['an apple', 'a apple', 'an apples'], 'an apple', 'Apple starts with a vowel sound and refers to one countable thing.'),
                    short('Type the plural of box.', 'boxes', 'Box adds -es to make the plural boxes.'),
                    question('Choose the correct sentence for several books.', ['These are books.', 'These is book.', 'This are a books.'], 'These are books.', 'These and are refer to several things. A/an cannot introduce a plural.'),
                ]),
                lesson('reading', 'What is in the bag?', 'Read the short description.\n\nThis is my bag. In the bag, I have a book, an apple and two pens. The book is blue. The apple is green. The pens are black. I also have three boxes at home.\n\nNotice that a and an describe one item. Two pens and three boxes are plural groups. Colours help identify the objects, but the colour does not change the plural ending. Re-read the description before answering the questions.', 'In my bag, I have a book, an apple and two pens. The book is blue. The apple is green. The pens are black.', [
                    question('How many pens are in the bag?', ['Two', 'One', 'Three'], 'Two', 'The description says two pens.'),
                    short('Type only the colour of the apple.', 'green', 'The apple is green. Blue describes the book.'),
                    question('Where are the three boxes?', ['At home', 'In the bag', 'At school'], 'At home', 'The final sentence puts the three boxes at home.'),
                ]),
                lesson('listening', 'Count the objects', 'Play the audio and listen for the numbers before the object names. Replay it and identify the singular object. The transcript is provided for accessible guided practice: On the table, there are three books, two bags and an orange. The books are red. The bags are blue. The orange is small. Device speech uses an English voice when one is available. If listening is unavailable, follow the transcript and notice the final -s sounds yourself.', 'On the table, there are three books, two bags and an orange. The books are red. The bags are blue. The orange is small.', [
                    question('Which object appears only once?', ['An orange', 'Books', 'Bags'], 'An orange', 'An orange is singular. There are three books and two bags.'),
                    short('Type only the colour of the bags.', 'blue', 'The recording says The bags are blue.'),
                    question('Where are the objects?', ['On the table', 'Under the bed', 'In the garden'], 'On the table', 'The first phrase is On the table.'),
                ]),
                lesson('speaking', 'Point and describe', 'Choose three safe objects near you, or imagine a bag, an apple and two books. Say This is a bag. This is an apple. These are books. Repeat the model and then change one noun or number. Ask yourself whether the noun is singular or plural and whether a/an matches its first sound. Say the final -s clearly without forcing one identical sound for every word. This is a self-review exercise; no independent pronunciation score is awarded.', 'This is a bag. This is an apple. These are books. These are two pens.'),
                lesson('writing', 'Make a little inventory', 'In your own notes, describe four fictional objects on a desk. Use one sentence with a, one with an, one plural ending in -s and one plural ending in -es. Model: This is a pen. This is an apple. These are books. These are boxes. Check is with this and are with these. Check that no plural has a or an before it. Confirm completion after reviewing the four sentences yourself; this activity is not independently graded.'),
            ],
            'vocabulary': [
                word('book', 'pages joined together for reading', '/bʊk/', 'This is a book.', '📘'),
                word('apple', 'a round fruit', '/ˈæpəl/', 'I have an apple.', '🍎'),
                word('bag', 'a container for carrying things', '/bæɡ/', 'The book is in my bag.', '🎒'),
                word('pen', 'an instrument for writing', '/pen/', 'These are two pens.', '🖊️'),
                word('box', 'a container with flat sides', '/bɒks/', 'I have three boxes.', '📦'),
                word('table', 'a piece of furniture with a flat top', '/ˈteɪbəl/', 'The books are on the table.', '🪑'),
            ],
        },
        {
            'level': 'A1', 'slug': 'simple-present-daily-routines', 'title': 'Daily routines — the simple present',
            'summary': 'Describe repeated activities, use the he/she -s ending, and ask questions with do or does.',
            'outcomes': ['Describe a simple daily routine.', 'Use a base verb after does and does not.', 'Find times and activities in a short routine.'],
            'explanation': 'Use the simple present for habits and repeated activities: I work every day. With I, you, we and they, use the base verb. With he, she and it, most verbs add -s: she works, he reads. Some spelling changes apply: go → goes, study → studies. In questions, use do with I/you/we/they and does with he/she/it: Does she work here? After does, use the base form work, not works. Negatives use do not or does not plus the base form: He does not work on Sunday. This pattern differs from be questions, which do not need do.',
            'examples': ['I work at home.', 'She reads every evening.', 'Does he work on Saturday?', 'He does not work on Sunday.'],
            'exceptions': 'Be is different: Are you ready?, not Do you be ready? Have becomes has with he/she/it in statements. The present continuous for actions happening now is a separate structure.',
            'common_mistakes': 'Avoid she work and does she works. Say she works in a statement, but does she work in a question. After does not, keep the base form: does not read.',
            'lessons': [
                lesson('grammar', 'Habits with work and read', 'Compare I work with she works. A third-person singular subject normally adds -s in a simple-present statement. A question uses do or does before the subject: Do you work here? Does she work here? After does, the main verb returns to its base form. A negative follows the same rule: She does not work here. Time expressions such as every day or on Monday help show a routine. These exercises practise regular verbs; be follows its own question and negative patterns.', 'I work every day. She works every day. Does she work here? She does not work on Sunday.', [
                    short('Type only the missing word: He ___ every evening. (read)', 'reads', 'He is third-person singular, so read becomes reads in this statement.'),
                    question('Choose the correct question.', ['Does she work here?', 'Does she works here?', 'Do she working here?'], 'Does she work here?', 'Use does with she and the base verb work after it.'),
                    question('Choose the correct negative.', ['He does not work on Sunday.', 'He does not works on Sunday.', 'He not work on Sunday.'], 'He does not work on Sunday.', 'Does not is followed by the base form work.'),
                ]),
                lesson('reading', 'Maya’s weekday', 'Read about a repeated weekday routine.\n\nMaya works in a library. She starts work at nine. She reads messages in the morning. At twelve, she eats lunch with a friend. She walks home at five. In the evening, she studies English. She does not work on Sunday.\n\nFollow the time expressions and activities. Starts, reads, eats, walks and studies match she. Does not work uses the base form because does already carries the third-person marking.', 'Maya works in a library. She starts work at nine. She eats lunch at twelve. She walks home at five. She does not work on Sunday.', [
                    question('Where does Maya work?', ['In a library', 'In a hospital', 'In a café'], 'In a library', 'The first sentence says Maya works in a library.'),
                    short('Type only the time in words: Maya starts work at ___.', 'nine', 'She starts work at nine. Type the requested word, not a full sentence.'),
                    question('Which day does Maya not work?', ['Sunday', 'Monday', 'Friday'], 'Sunday', 'The final sentence says she does not work on Sunday.'),
                ]),
                lesson('listening', 'Listen to Leo’s routine', 'Listen for a person’s habit, rather than what is happening right now. Play the audio twice if needed. Accessible transcript: Leo lives near a park. He walks in the park every morning. He starts work at eight. After work, he cooks dinner. He does not watch television in the evening. He reads a book. Notice lives, walks, starts, cooks and reads with he. Device speech is a practice aid and may vary by browser; this transcript-supported activity is not a formal listening assessment.', 'Leo lives near a park. He walks in the park every morning. He starts work at eight. After work, he cooks dinner. He does not watch television in the evening. He reads a book.', [
                    question('What does Leo do every morning?', ['He walks in the park.', 'He watches television.', 'He cooks dinner.'], 'He walks in the park.', 'The recording connects walks in the park to every morning.'),
                    short('Type only the time in words: He starts work at ___.', 'eight', 'Leo starts at eight, according to the recording.'),
                    question('What does Leo do in the evening?', ['He reads a book.', 'He starts work.', 'He watches television.'], 'He reads a book.', 'He does not watch television; the following sentence says he reads a book.'),
                ]),
                lesson('speaking', 'Tell a partner about a routine', 'Say three sentences about a fictional person’s routine using reads, works or walks. Then change the person to I and repeat with the base forms read, work and walk. Ask Does she work on Sunday? and answer No, she does not. Listen to the model, then replace the activity with your own. Check the -s in statements and the base form after does. Completion records your self-reviewed practice only; it does not measure fluent conversation or pronunciation.', 'She works in a library. She walks home. She reads in the evening. Does she work on Sunday? No, she does not.'),
                lesson('writing', 'Create a simple weekly routine', 'Write five sentences about a fictional person in your own notes: two regular habits, one time, one negative with does not and one question with does. Model: Noor works at home. She reads every evening. She starts at nine. She does not work on Sunday. Does she walk to work? Check that statements use -s with she but that work and walk stay in the base form after does. This writing task is self-reviewed; a check mark is participation rather than an assessed CEFR level.'),
            ],
            'vocabulary': [
                word('work', 'to do a job or a task', '/wɜːk/', 'I work at home.', '💼'),
                word('read', 'to understand written words', '/riːd/', 'She reads a book every evening.', '📖'),
                word('walk', 'to move on foot', '/wɔːk/', 'He walks in the park.', '🚶'),
                word('morning', 'the early part of a day', '/ˈmɔːnɪŋ/', 'I read in the morning.', '🌅'),
                word('evening', 'the later part of a day before night', '/ˈiːvnɪŋ/', 'She studies in the evening.', '🌆'),
                word('library', 'a place to read or borrow books', '/ˈlaɪbrəri/', 'Maya works in a library.', '🏛️'),
            ],
        },
    ],
}


DUTCH_WORD_ORDER_RICH = {
    'intro': 'A Dutch main statement has a useful anchor: the conjugated verb occupies the second constituent position. You can begin with a person or with a time phrase while keeping that anchor in place.',
    'learning_goals': ['Find the conjugated verb in a short Dutch main clause.',
                       'Move a time phrase to the front while keeping verb-second order.',
                       'Distinguish a statement from a yes/no question.'],
    'sections': [
        {'title': 'Second position means the second chunk, not the second word',
         'body': 'In Ik leer vandaag Nederlands, ik is the first constituent and leer is the second. In Vandaag leer ik Nederlands, vandaag is first and leer remains second. A longer expression also counts as one constituent: Morgen om negen uur leer ik Nederlands. The phrase morgen om negen uur contains several words, but the verb is still in the second structural position. Start with short examples before building longer sentences.'},
        {'title': 'Front a time phrase and put the subject after the verb',
         'body': 'Begin with Ik werk vandaag thuis. To emphasize the time, move vandaag to the front: Vandaag werk ik thuis. Do not leave ik before werk after moving vandaag, because that would put the verb in third position. This subject–verb reversal is often called inversion. The same pattern works with a place phrase: In Gent woont mijn vriend. Mijn vriend is the subject, and woont is the conjugated verb.'},
        {'title': 'Ask a yes/no question with the verb first',
         'body': 'A yes/no question usually begins with the conjugated verb: Werk je vandaag? or Komt Noor morgen? This is different from a statement beginning with a time phrase: Vandaag werk je. With jij or je as the subject after the verb, a regular present-tense form normally drops its added -t: jij werkt, but werk jij? Keep the -t with hij: werkt hij? This beginner pattern concerns subject je, not every occurrence of the word je.'},
        {'title': 'Keep main clauses separate from subordinate clauses',
         'body': 'This guide covers ordinary declarative main clauses and simple yes/no questions. A subordinate clause with omdat follows another pattern: Ik blijf thuis omdat ik ziek ben. Do not move ben into second position inside that omdat clause. When a subordinate clause comes first, it counts as a whole first constituent for the following main clause: Omdat ik ziek ben, blijf ik thuis. Learn that later pattern after the short statements here feel comfortable.'},
    ],
    'rule_tables': [
        {'title': 'The main-clause anchor', 'columns': ['First constituent', 'Conjugated verb', 'Subject if needed', 'Rest'],
         'rows': [['Ik', 'leer', '—', 'vandaag Nederlands.'],
                  ['Vandaag', 'leer', 'ik', 'Nederlands.'],
                  ['Morgen om negen uur', 'werk', 'ik', 'thuis.'],
                  ['In Gent', 'woont', 'mijn vriend', 'sinds januari.']],
         'note': 'The dash means the subject is already in the first position.'},
        {'title': 'Statement and question', 'columns': ['Subject', 'Statement', 'Yes/no question'],
         'rows': [['ik', 'Ik werk vandaag.', 'Werk ik vandaag?'],
                  ['jij', 'Jij werkt vandaag.', 'Werk jij vandaag?'],
                  ['hij', 'Hij werkt vandaag.', 'Werkt hij vandaag?'],
                  ['wij', 'Wij werken vandaag.', 'Werken wij vandaag?']],
         'note': 'The added -t drops with subject jij/je after the verb; it stays with hij.'},
    ],
    'sentence_patterns': [
        {'label': 'Subject first', 'tokens': [{'text': 'Ik', 'role': 'subject'}, {'text': 'leer', 'role': 'verb'}, {'text': 'vandaag', 'role': 'time'}, {'text': 'Nederlands.', 'role': 'object'}]},
        {'label': 'Time first, subject after the verb', 'tokens': [{'text': 'Vandaag', 'role': 'time'}, {'text': 'leer', 'role': 'verb'}, {'text': 'ik', 'role': 'subject'}, {'text': 'Nederlands.', 'role': 'object'}]},
        {'label': 'A yes/no question', 'tokens': [{'text': 'Werk', 'role': 'verb'}, {'text': 'jij', 'role': 'subject'}, {'text': 'morgen', 'role': 'time'}, {'text': 'thuis?', 'role': 'place'}]},
    ],
    'example_pairs': [
        {'original': 'Ik leer vandaag Nederlands.', 'translation': 'I am studying Dutch today.', 'note': 'Ik is the first constituent; leer is the conjugated verb.'},
        {'original': 'Vandaag leer ik Nederlands.', 'translation': 'Today I am studying Dutch.', 'note': 'The time expression comes first, so ik follows leer.'},
        {'original': 'Morgen werken we thuis.', 'translation': 'Tomorrow we are working at home.', 'note': 'We takes the plural form werken.'},
        {'original': 'Werk jij morgen thuis?', 'translation': 'Are you working at home tomorrow?', 'note': 'The question starts with werk. Subject jij follows it, so the added -t is absent.'},
    ],
    'common_traps': [
        {'wrong': 'Vandaag ik leer Nederlands.', 'correct': 'Vandaag leer ik Nederlands.', 'why': 'After the fronted time phrase, the conjugated verb comes before the subject.'},
        {'wrong': 'Morgen werkt wij thuis.', 'correct': 'Morgen werken wij thuis.', 'why': 'Inversion does not remove agreement: wij still takes werken.'},
        {'wrong': 'Werkt jij hier?', 'correct': 'Werk jij hier?', 'why': 'The added -t drops when jij is the subject after a regular present-tense verb.'},
        {'wrong': 'Ik blijf thuis omdat ik ben ziek.', 'correct': 'Ik blijf thuis omdat ik ziek ben.', 'why': 'The omdat clause is subordinate and does not use the ordinary main-clause verb-second pattern.'},
    ],
}

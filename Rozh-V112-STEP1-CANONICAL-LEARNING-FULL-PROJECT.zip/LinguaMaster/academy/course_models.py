"""Per-course starting points; activity and XP remain in existing learning records."""
from django.conf import settings
from django.db import models
from django.utils import timezone


class CourseEnrollment(models.Model):
    STAGES = [(code, code) for code in ('A0', 'A1', 'A2', 'B1', 'B2', 'C1')]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='course_enrollments')
    language = models.ForeignKey('academy.Language', on_delete=models.CASCADE, related_name='enrollments')
    placement_completed = models.BooleanField(default=False)
    placement_level = models.CharField(max_length=2, choices=STAGES, default='A0')
    joined_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['joined_at', 'pk']
        constraints = [models.UniqueConstraint(fields=['user', 'language'], name='one_enrollment_per_course')]

    def __str__(self):
        return f'{self.user_id}: {self.language.code} {self.placement_level}'

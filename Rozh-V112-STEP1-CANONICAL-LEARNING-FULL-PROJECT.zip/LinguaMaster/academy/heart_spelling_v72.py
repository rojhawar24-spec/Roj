"""V72: five distinct published course words, five correct spellings each.

A recovery run is bound to the authenticated user's Django server-side session;
word answers and rewards are never accepted from untrusted client counters.
The existing HeartEvent unique ledger and HeartBalance row lock prevent replay.
"""
import secrets
import unicodedata
from datetime import timedelta

from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.urls import path, reverse
from django.utils import timezone
from django.views.decorators.http import require_http_methods, require_POST

from .heart_models import HeartEvent
from .hearts import CAPACITY, _balance_locked, _state, snapshot
from .models import Profile, Vocabulary
from .navigation_v67 import safe_student_return_path
from .services import rate_limit

SESSION_KEY = 'rozh_spelling_recovery_v72'
WORDS_PER_TASK = 5
REPETITIONS_PER_WORD = 5
TOTAL = WORDS_PER_TASK * REPETITIONS_PER_WORD
MAX_AGE_SECONDS = 2 * 60 * 60
MAX_REWARDS_24H = 12

LABELS = {
    'nl': {
        'title': 'Verdien een hartje', 'intro': 'Schrijf 5 verschillende woorden elk 5 keer correct. Na 25 juiste antwoorden verdien je 1 hartje.',
        'start': 'Start schrijfoefening', 'hearts_empty': 'Je hartjes zijn op!',
        'word': 'Woord', 'of': 'van', 'repeat': 'Herhaling', 'prompt': 'Schrijf dit woord', 'check': 'Controleer',
        'progress': 'Correct geschreven', 'error': 'Nog niet correct. Probeer opnieuw.',
        'done': 'Goed gedaan! Je hebt de schrijfoefening voltooid.', 'earned': 'Je hebt 1 hartje verdiend!',
        'full': 'Je hartjes zijn inmiddels vol. De oefening is voltooid, maar je krijgt geen extra hartje boven de limiet.',
        'no_reward': 'Je hebt deze beloning al ontvangen, of je hebt de herstelgrens bereikt.',
        'missing': 'Voor deze cursus zijn nog geen 5 verschillende gepubliceerde woorden beschikbaar. Vraag de beheerder om meer woorden.',
        'switch': 'Je cursus is veranderd. Start de oefening opnieuw.',
        'expired': 'De oefening is verlopen. Start opnieuw.',
        'back': 'Terug naar hartjes', 'resume': 'Verder met mijn les', 'home': 'Terug naar Leer & Speel',
        'limit': 'Vandaag zijn de oefenbeloningen al gebruikt. Wacht tot je hartjes vanzelf herstellen.',
        'ready': 'Je hebt nog hartjes. Deze oefening is bedoeld voor wanneer je geen hartjes meer hebt.',
    },
    'en': {
        'title': 'Earn a heart', 'intro': 'Write 5 different words correctly 5 times each. After 25 correct answers, earn 1 heart.',
        'start': 'Start writing practice', 'hearts_empty': 'You are out of hearts!',
        'word': 'Word', 'of': 'of', 'repeat': 'Repetition', 'prompt': 'Write this word', 'check': 'Check answer',
        'progress': 'Correct spellings', 'error': 'Not quite right. Try again.',
        'done': 'Well done! You finished the writing practice.', 'earned': 'You earned 1 heart!',
        'full': 'Your hearts are now full. Practice completed, with no reward above the heart limit.',
        'no_reward': 'This reward was already claimed, or you have reached the practice limit.',
        'missing': 'This course needs at least 5 different published vocabulary words. Ask the manager to add more.',
        'switch': 'Your course changed. Please start again.',
        'expired': 'This practice has expired. Please start again.',
        'back': 'Back to hearts', 'resume': 'Resume my lesson', 'home': 'Back to Learn & Play',
        'limit': 'You have reached today’s practice reward limit. Your hearts will still regenerate.',
        'ready': 'You still have hearts. This activity is for when your hearts reach zero.',
    },
    'ckb': {
        'title': 'وەرگرتنی یەک دڵ', 'intro': '٥ وشەی جیاواز هەر یەکەیان ٥ جار بە درستی بنووسە. دوای ٢٥ وەڵامی ڕاست یەک دڵ وەردەگریت.',
        'start': 'دەستپێکردنی ڕاهێنانی نووسین', 'hearts_empty': 'دڵەکانت تەواو بوون!',
        'word': 'وشە', 'of': 'لە', 'repeat': 'دووبارەکردنەوە', 'prompt': 'ئەم وشەیە بنووسە', 'check': 'پشکنینی وەڵام',
        'progress': 'نووسینی ڕاست', 'error': 'هێشتا ڕاست نییە. دووبارە هەوڵ بدە.',
        'done': 'زۆر باشە! ڕاهێنانەکەت تەواو کرد.', 'earned': 'یەک دڵت وەرگرت!',
        'full': 'دڵەکانت ئێستا پڕن. ڕاهێنانەکە تەواو بوو، بەڵام لە سنووری دڵ زیاتر نادرێت.',
        'no_reward': 'ئەم پاداشتە پێشتر وەرگیراوە یان گەیشتوویتە سنووری ڕاهێنان.',
        'missing': 'ئەم کۆرسە هێشتا ٥ وشەی بڵاوکراوەی جیاوازی نییە. بەڕێوەبەر پێویستە وشە زیاد بکات.',
        'switch': 'کۆرسەکەت گۆڕاوە. ڕاهێنانەکە دووبارە دەست پێ بکە.',
        'expired': 'کاتی ڕاهێنانەکە تەواو بوو. دووبارە دەست پێ بکە.',
        'back': 'گەڕانەوە بۆ دڵەکان', 'resume': 'گەڕانەوە بۆ وانەکەم', 'home': 'گەڕانەوە بۆ فێربە و یاری بکە',
        'limit': 'ئەمڕۆ سنووری پاداشتی ڕاهێنانت پڕ بووە. دڵەکانت بە خۆکار دەگەڕێنەوە.',
        'ready': 'هێشتا دڵت هەیە. ئەم ڕاهێنانە بۆ کاتی تەواوبوونی دڵەکانە.',
    },
    'ar': {
        'title': 'اكسب قلبًا', 'intro': 'اكتب 5 كلمات مختلفة، كل كلمة 5 مرات صحيحة. بعد 25 إجابة صحيحة تحصل على قلب واحد.',
        'start': 'ابدأ تمرين الكتابة', 'hearts_empty': 'نفدت قلوبك!',
        'word': 'كلمة', 'of': 'من', 'repeat': 'التكرار', 'prompt': 'اكتب هذه الكلمة', 'check': 'تحقق من الإجابة',
        'progress': 'إجابات صحيحة', 'error': 'ليست صحيحة بعد. حاول مجددًا.',
        'done': 'أحسنت! أكملت تمرين الكتابة.', 'earned': 'ربحت قلبًا واحدًا!',
        'full': 'قلوبك ممتلئة الآن. انتهى التمرين لكن لا تمنح قلوب فوق الحد الأقصى.',
        'no_reward': 'حصلت على هذه المكافأة مسبقًا أو بلغت حد التمارين.',
        'missing': 'لا توجد 5 كلمات منشورة مختلفة في هذه الدورة بعد. اطلب من المدير إضافة المزيد.',
        'switch': 'تغيرت دورتك. ابدأ التمرين من جديد.',
        'expired': 'انتهت صلاحية التمرين. ابدأ مجددًا.',
        'back': 'العودة إلى القلوب', 'resume': 'متابعة درسي', 'home': 'العودة إلى التعلّم واللعب',
        'limit': 'وصلت إلى حد مكافآت التمارين لهذا اليوم. ستتجدد قلوبك تلقائيًا.',
        'ready': 'ما زالت لديك قلوب. هذا التمرين مخصص عند نفاد القلوب.',
    },
}


def labels_for(user):
    language = getattr(getattr(user, 'learning_profile', None), 'ui_language', 'en')
    return LABELS.get(language, LABELS['en'])


def _normalized(text):
    """Match orthography, ignoring casing and extra whitespace, not accents."""
    return ' '.join(unicodedata.normalize('NFC', text).strip().split()).casefold()


def _eligible_profile(user):
    if not user.is_active:
        return None
    return (Profile.objects.select_related('preferred_language').filter(user=user,
            suspended_at__isnull=True, legacy_review_required=False,
            placement_completed=True).first())


def _published_words(course_id):
    """Only approved, readable vocabulary from the chosen published course."""
    records = (Vocabulary.objects.filter(level__language_id=course_id,
                    level__language__is_published=True, published=True)
               .order_by('pk').values_list('pk', 'word')[:1500])
    seen = set()
    result = []
    for pk, word in records:
        candidate = _normalized(word)
        if not candidate or len(word) > 80 or candidate in seen:
            continue
        if any(ord(character) < 32 for character in word):
            continue
        result.append(pk)
        seen.add(candidate)
    return result


def _resume_path(request):
    path = request.POST.get('next', '') if request.method == 'POST' else request.GET.get('next', '')
    return safe_student_return_path(path) or reverse('play_hub')


def _valid_run(request, profile):
    state = request.session.get(SESSION_KEY)
    if not isinstance(state, dict) or state.get('course_id') != profile.preferred_language_id:
        return None
    if not isinstance(state.get('token'), str) or len(state['token']) != 36:
        return None
    if (not isinstance(state.get('position'), int) or isinstance(state.get('position'), bool)
            or not 0 <= state['position'] <= TOTAL):
        return None
    if not isinstance(state.get('words'), list) or len(state['words']) != WORDS_PER_TASK:
        return None
    if len(set(state['words'])) != WORDS_PER_TASK or not all(type(pk) is int and pk > 0 for pk in state['words']):
        return None
    if not isinstance(state.get('started'), (int, float)) or not (0 <= timezone.now().timestamp() - state['started'] < MAX_AGE_SECONDS):
        return None
    return state


def _award(user, token):
    """Award +1 at most once per server-created run, within capacity and safety cap."""
    now = timezone.now()
    key = f'spelling:{token}'
    with transaction.atomic():
        balance = _balance_locked(user, now)
        if HeartEvent.objects.filter(user=user, key=key).exists():
            return _state(balance, now), 'no_reward'
        if HeartEvent.objects.filter(user=user, kind='recovery', key__startswith='spelling:', delta=1,
                                    created_at__gte=now - timedelta(hours=24)).count() >= MAX_REWARDS_24H:
            return _state(balance, now), 'limit'
        recovered = balance.remaining < CAPACITY
        if recovered:
            balance.remaining += 1
            if balance.remaining == CAPACITY:
                balance.regenerated_at = now
            balance.save(update_fields=['remaining', 'regenerated_at'])
        # Ledger entry is unique per token and enforces replay safety.
        HeartEvent.objects.create(user=user, key=key, kind='recovery', delta=int(recovered), created_at=now)
        return _state(balance, now), 'earned' if recovered else 'full'


def _render(request, state, labels, error=''):
    position = state['position']
    complete = position >= TOTAL
    word_index = min(position // REPETITIONS_PER_WORD, WORDS_PER_TASK-1)
    vocabulary = None
    if not complete:
        vocabulary = (Vocabulary.objects.filter(
            pk=state['words'][word_index], published=True,
            level__language_id=state['course_id'], level__language__is_published=True)
            .select_related('level__language').first())
        if vocabulary is None:
            request.session.pop(SESSION_KEY, None)
            return redirect('hearts')
    return render(request, 'academy/hearts_spelling_v72.html', {
        'H72': labels, 'challenge': state, 'item': vocabulary,
        'completed': complete, 'step': position + 1, 'total': TOTAL,
        'word_number': word_index + 1, 'word_total': WORDS_PER_TASK,
        'repeat_number': position % REPETITIONS_PER_WORD + 1,
        'repeat_total': REPETITIONS_PER_WORD, 'percent': round(100 * position / TOTAL),
        'error': error, 'result': labels.get(state.get('result', ''), ''),
        'resume': safe_student_return_path(state.get('return_to')) or reverse('play_hub'),
        'course_code': getattr(getattr(request.user.learning_profile, 'preferred_language', None), 'code', 'nl'),
        'noindex': True, 'seo_title': labels['title'] + ' | Rozh',
    })


@login_required
@require_POST
def start(request):
    if rate_limit(request, 'v72-heart-start', 24, 3600, True):
        return HttpResponse('Too many practice starts.', status=429)
    profile = _eligible_profile(request.user)
    if profile is None or not profile.preferred_language_id or not profile.preferred_language.is_published:
        return HttpResponse('Current learning course unavailable.', status=403)
    hearts = snapshot(request.user)
    if not hearts['empty']:
        return redirect('hearts')
    if (HeartEvent.objects.filter(user=request.user, kind='recovery', key__startswith='spelling:', delta=1,
                                 created_at__gte=timezone.now() - timedelta(hours=24)).count() >= MAX_REWARDS_24H):
        return redirect('hearts')
    # Continue the existing task rather than losing earned spelling progress.
    old = _valid_run(request, profile)
    if old is not None and old['position'] < TOTAL:
        return redirect('heart_spelling')
    words = _published_words(profile.preferred_language_id)
    if len(words) < WORDS_PER_TASK:
        return redirect('hearts')
    selected = secrets.SystemRandom().sample(words, WORDS_PER_TASK)
    token = secrets.token_hex(18)
    request.session[SESSION_KEY] = {
        'token': token, 'words': selected, 'position': 0,
        'course_id': profile.preferred_language_id,
        'started': int(timezone.now().timestamp()),
        'return_to': _resume_path(request),
    }
    return redirect('heart_spelling')


@login_required
@require_http_methods(['GET', 'POST'])
def spell(request):
    profile = _eligible_profile(request.user)
    if profile is None:
        return HttpResponse('This learning account is unavailable.', status=403)
    state = _valid_run(request, profile)
    if state is None:
        request.session.pop(SESSION_KEY, None)
        return redirect('hearts')
    labels = labels_for(request.user)
    if request.method == 'GET' or state['position'] >= TOTAL:
        return _render(request, state, labels)
    if rate_limit(request, 'v72-heart-answer', 180, 3600, True):
        return HttpResponse('Too many practice submissions.', status=429)
    submitted_token = request.POST.get('token', '')
    submitted_position = request.POST.get('position', '')
    if submitted_token != state['token'] or submitted_position != str(state['position']):
        return HttpResponse('The exercise has already advanced. Reload the page.', status=409)
    expected_id = state['words'][state['position'] // REPETITIONS_PER_WORD]
    expected = (Vocabulary.objects.filter(pk=expected_id, published=True,
                level__language_id=state['course_id'], level__language__is_published=True)
                .values_list('word', flat=True).first())
    if not expected:
        request.session.pop(SESSION_KEY, None)
        return redirect('hearts')
    answer = request.POST.get('answer', '')
    if not isinstance(answer, str) or len(answer) > 120 or _normalized(answer) != _normalized(expected):
        return _render(request, state, labels, error=labels['error'])
    state['position'] += 1
    if state['position'] == TOTAL:
        _, result = _award(request.user, state['token'])
        state['result'] = result
    request.session[SESSION_KEY] = state
    # Post/Redirect/Get prevents accidental browser resubmits.
    return redirect('heart_spelling')


urlpatterns = [
    path('hearts/spelling/start/', start, name='heart_spelling_start'),
    path('hearts/spelling/', spell, name='heart_spelling'),
]


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'heart_spelling_v72', ['LABELS'])


LABELS['fr'].update(dict(title='Gagner un cœur',intro='Écrivez 5 mots différents correctement 5 fois chacun. Après 25 réponses correctes, gagnez 1 cœur.',start='Commencer l’exercice d’écriture',hearts_empty='Vous n’avez plus de cœurs !',word='Mot',of='sur',repeat='Répétition',prompt='Écrivez ce mot',check='Vérifier',progress='Réponses correctes',error='Pas encore correct. Réessayez.',done='Bravo ! Exercice terminé.',earned='Vous avez gagné un cœur !',full='Vos cœurs sont déjà au maximum : aucun cœur supplémentaire.',no_reward='Récompense déjà obtenue ou limite atteinte.',missing='Ce cours nécessite 5 mots différents publiés. Demandez au gestionnaire d’en ajouter.',switch='Votre cours a changé. Recommencez.',expired='Exercice expiré. Recommencez.',back='Retour aux cœurs',resume='Reprendre ma leçon',home='Retour à Apprendre et jouer',limit='Limite quotidienne atteinte. Les cœurs se régénèrent aussi automatiquement.',ready='Vous avez encore des cœurs. Cet exercice est réservé aux cœurs épuisés.'))
LABELS['uk'].update(dict(title='Зароби серце',intro='Напиши 5 різних слів правильно по 5 разів. За 25 правильних написань отримай 1 серце.',start='Почати письмову вправу',hearts_empty='Серця закінчилися!',word='Слово',of='з',repeat='Повторення',prompt='Напиши це слово',check='Перевірити',progress='Правильних написань',error='Не зовсім правильно. Спробуй ще раз.',done='Чудово! Вправу завершено.',earned='Ти заробив одне серце!',full='У тебе вже максимальна кількість сердець. Додаткове серце не надається.',no_reward='Нагороду вже отримано або досягнуто межі.',missing='Для цього курсу потрібно 5 різних опублікованих слів. Попроси менеджера їх додати.',switch='Курс змінився. Почни вправу знову.',expired='Час вправи минув. Почни знову.',back='Повернутися до сердець',resume='Продовжити мій урок',home='Повернутися до навчання',limit='Досягнуто щоденного ліміту. Серця також відновлюються автоматично.',ready='У тебе ще є серця. Ця вправа призначена для випадку, коли їх не залишилося.'))
LABELS['kmr'].update(dict(title='دلەکێ بەدەست بینە',intro='٥ پەیڤێن جیاواز هەر ئێک ٥ جار ب دروستی بنڤیسە. پشتی ٢٥ نڤیسینێن ڕاست دلەکێ وەربگرە.',start='دەست ب ڕاهێنانا نڤیسینێ بکە',hearts_empty='دلێن تە تەواو بوون!',word='پەیڤ',of='ژ',repeat='دووبارەکرن',prompt='ئەڤ پەیڤێ بنڤیسە',check='بپشکنە',progress='نڤیسینێن ڕاست',error='هێشتا ڕاست نینە. دووبارە هەول بدە.',done='ئافەرین! ڕاهێنان تەواو کر.',earned='تە دلەک وەرگرت!',full='دلێن تە پڕن. دلیێن زیادە نادرێن.',no_reward='ئەڤ خەلاتە پێشتر وەرگیرا یان سنوور تەواو بوو.',missing='ئەڤ کۆرس پێدڤی ب ٥ پەیڤێن جیاواز یێن بڵاوکری هەیە.',switch='کۆرسا تە گوهۆڕی. دووبارە دەست پێ بکە.',expired='دەمێ ڕاهێنانێ تەواو بوو. دووبارە دەست پێ بکە.',back='زڤڕین بۆ دلان',resume='بەردەوام بە ل وانەیا من',home='زڤڕین بۆ فێربوونێ',limit='سنوورێ خەلاتا ڕۆژانە تەواو بوو. دل ب خۆکار دزڤڕن.',ready='هێشتا دلێن تە هەنە. ئەڤ ڕاهێنان بۆ دەمێ دل تەواو دبنە.'))

"""V92 actual Django tests. NOT counted as passed until executed.

Uses the isolated config.settings_local_qa and Django's test database.
"""
from types import SimpleNamespace
from django.contrib import admin
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.management import call_command
from django.test import TestCase, RequestFactory, Client
from django.urls import reverse
from django.utils import timezone
from .admin import OwnerUserAdmin, OwnerGroupAdmin
from .manager_roles_v48 import MANAGER_GROUP
from .models import Profile
from .session_revocation_v91 import SESSION_STATE_VERSION_KEY


class SupportedPrivilegeChangeRevocationTests(TestCase):
    PWD = 'V92-Only-Strong-Password-For-QA!'

    def setUp(self):
        U=get_user_model()
        self.owner=U.objects.create_superuser(username='v92_owner',email='v92_owner@example.invalid',password=self.PWD)
        self.target=U.objects.create_user(username='v92_target',email='v92_target@example.invalid',password=self.PWD)
        for account in (self.owner,self.target):
            profile=Profile.objects.get(user=account)
            profile.email_verified_at=timezone.now()
            profile.totp_secret='JBSWY3DPEHPK3PXP'
            profile.save(update_fields=['email_verified_at','totp_secret'])
        self.old_client=Client()
        self.old_client.force_login(self.target)

    def assert_old_session_revoked(self):
        response=self.old_client.get(reverse('dashboard'))
        self.assertEqual(response.status_code,302)
        self.assertNotIn('_auth_user_id',self.old_client.session)

    def test_grant_manager_command_revokes_pregrant_session(self):
        call_command('grant_rozh_manager',username=self.target.username,grant=True)
        self.assertGreater(Profile.objects.get(user=self.target).email_verification_version,0)
        self.assert_old_session_revoked()

    def test_revoke_manager_command_revokes_previous_session(self):
        group=Group.objects.get_or_create(name=MANAGER_GROUP)[0]
        self.target.groups.add(group)
        self.old_client.force_login(self.target)
        call_command('grant_rozh_manager',username=self.target.username,revoke=True)
        self.assert_old_session_revoked()

    def test_owner_promote_revokes_pregrant_session(self):
        owner_client=Client();owner_client.force_login(self.owner)
        sess=owner_client.session;sess['mfa_verified_id']=self.owner.pk;sess.save()
        response=owner_client.post(reverse('manager_user_action',args=[self.target.pk,'promote']))
        self.assertEqual(response.status_code,302)
        self.target.refresh_from_db();self.assertTrue(self.target.is_staff)
        self.assert_old_session_revoked()

    def test_owner_demote_revokes_active_session(self):
        self.target.is_staff=True;self.target.save(update_fields=['is_staff'])
        self.old_client.force_login(self.target)
        owner_client=Client();owner_client.force_login(self.owner)
        sess=owner_client.session;sess['mfa_verified_id']=self.owner.pk;sess.save()
        response=owner_client.post(reverse('manager_user_action',args=[self.target.pk,'demote']))
        self.assertEqual(response.status_code,302)
        self.target.refresh_from_db();self.assertFalse(self.target.is_staff)
        self.assert_old_session_revoked()

    def test_owner_user_admin_edit_revokes_sessions(self):
        model_admin=OwnerUserAdmin(get_user_model(),admin.site)
        form=SimpleNamespace(instance=self.target,save_m2m=lambda:None)
        model_admin.save_related(RequestFactory().post('/secure-admin/'),form,[],change=True)
        self.assert_old_session_revoked()

    def test_owner_group_admin_edit_revokes_all_members(self):
        group=Group.objects.create(name='v92-editor-group')
        self.target.groups.add(group)
        model_admin=OwnerGroupAdmin(Group,admin.site)
        form=SimpleNamespace(instance=group,save_m2m=lambda:None)
        model_admin.save_related(RequestFactory().post('/secure-admin/'),form,[],change=True)
        self.assert_old_session_revoked()

    def test_new_user_admin_form_does_not_force_a_revision(self):
        model_admin=OwnerUserAdmin(get_user_model(),admin.site)
        form=SimpleNamespace(instance=self.target,save_m2m=lambda:None)
        before=Profile.objects.get(user=self.target).email_verification_version
        model_admin.save_related(RequestFactory().post('/secure-admin/'),form,[],change=False)
        self.assertEqual(Profile.objects.get(user=self.target).email_verification_version,before)

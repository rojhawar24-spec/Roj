"""Shared interface copy and real dashboard metrics for the V9 experience."""
from django.db.models import Count, Q
from .models import LessonProgress, Friendship
from .services import current_streak

COPY = {
 'en': {
  'eyebrow':'A LITTLE EVERY DAY', 'greeting':'Good to see you', 'intro':'Your next small step starts here.',
  'next':'YOUR NEXT LESSON', 'hero':'A new day. A little more fluent.', 'hero_note':'Build real confidence, one lesson at a time.',
  'continue':'Continue learning', 'choose':'Choose your course', 'course':'Course progress', 'path':'Your learning journey',
  'full_path':'Explore the path', 'day_plan':'Make today count', 'daily_goal':'Your daily goal', 'goal_done':'Daily goal complete. Beautiful work!',
  'goal_note':'Learning XP counts towards your daily goal.', 'review':'Words to remember', 'review_note':'A little review makes it stick.',
  'mistakes':'Turn mistakes into progress', 'mistakes_note':'Try again, with a better explanation.', 'ready':'ready to review', 'fix':'to revisit',
  'week':'Your week, one day at a time', 'weekly_xp':'learning XP this week', 'streak':'day streak', 'longest':'Longest streak',
  'skills':'Build all your skills', 'skills_note':'Completed activities in this course.', 'reading':'Reading', 'listening':'Listening',
  'speaking':'Speaking', 'writing':'Writing', 'grammar':'Grammar', 'activity_note':'Activity counts show participation, not a verified proficiency score.',
  'friends_title':'Better together', 'friends_note':'Encourage a friend. Celebrate a small win.', 'friends_cta':'Find your friends', 'friends_count':'friends learning with you',
  'xp_level':'XP level', 'xp_note':'Your XP level tracks activity. A0–C1 describes your course stage.', 'next_level':'XP to the next level',
  'library':'Your grammar companion', 'library_note':'Clear rules, real examples, and quick checks from A0 to C1.', 'library_cta':'Explore grammar',
  'no_course':'Choose a published course to begin.', 'no_next':'You finished the available units. Review what you learned.',
  'active_course':'Current course', 'practice':'Practice', 'days':'days', 'empty_week':'Your first learning session starts your week.',
  'new':'New', 'chapter':'Chapter', 'chapters':['First steps','Everyday essentials','Find your voice','Make connections','Express your ideas','Precision & nuance'],
  'guide':'Guidebook', 'course_stage':'Course stage', 'check':'Level check', 'unit':'Unit', 'lessons':'lessons',
  'complete':'Complete', 'locked':'Finish the previous unit first', 'test':'Unit check ready', 'start':'Ready to learn',
  'path_help':'Follow the lessons, practise, and pass each unit check. Move at your own pace.',
  'sidebar':'YOUR LEARNING SPACE', 'tools':'EXPLORE & CONNECT', 'brand_line':'MAKE WORDS YOUR WORLD', 'skip':'Skip to content', 'install':'Install app',
 },
 'nl': {
  'eyebrow':'ELKE DAG EEN BEETJE', 'greeting':'Fijn dat je er bent', 'intro':'Je volgende kleine stap begint hier.',
  'next':'JOUW VOLGENDE LES', 'hero':'Een nieuwe dag. Een beetje vloeiender.', 'hero_note':'Bouw zelfvertrouwen op, één les tegelijk.',
  'continue':'Verder leren', 'choose':'Kies je cursus', 'course':'Cursusvoortgang', 'path':'Jouw leerreis',
  'full_path':'Bekijk het leerpad', 'day_plan':'Maak vandaag het verschil', 'daily_goal':'Jouw dagdoel', 'goal_done':'Dagdoel behaald. Goed gedaan!',
  'goal_note':'Leer-XP telt mee voor je dagdoel.', 'review':'Woorden om te onthouden', 'review_note':'Even herhalen, langer onthouden.',
  'mistakes':'Maak van fouten vooruitgang', 'mistakes_note':'Probeer opnieuw, met een duidelijke uitleg.', 'ready':'klaar om te herhalen', 'fix':'om te verbeteren',
  'week':'Jouw week, dag voor dag', 'weekly_xp':'leer-XP deze week', 'streak':'dagen op rij', 'longest':'Langste streak',
  'skills':'Ontwikkel al je vaardigheden', 'skills_note':'Voltooide activiteiten in deze cursus.', 'reading':'Lezen', 'listening':'Luisteren',
  'speaking':'Spreken', 'writing':'Schrijven', 'grammar':'Grammatica', 'activity_note':'Activiteiten tonen deelname, geen onafhankelijk getoetst taalniveau.',
  'friends_title':'Samen kom je verder', 'friends_note':'Moedig een vriend aan. Vier een kleine overwinning.', 'friends_cta':'Naar je vrienden', 'friends_count':'vrienden leren met je mee',
  'xp_level':'XP-level', 'xp_note':'Je XP-level meet activiteit. A0–C1 geeft je cursusfase aan.', 'next_level':'XP tot het volgende level',
  'library':'Jouw grammaticagids', 'library_note':'Heldere regels, echte voorbeelden en korte oefeningen van A0 tot C1.', 'library_cta':'Ontdek grammatica',
  'no_course':'Kies een gepubliceerde cursus om te beginnen.', 'no_next':'Je hebt de beschikbare units afgerond. Herhaal wat je hebt geleerd.',
  'active_course':'Huidige cursus', 'practice':'Oefenen', 'days':'dagen', 'empty_week':'Je eerste leersessie zet je week in beweging.',
  'new':'Nieuw', 'chapter':'Hoofdstuk', 'chapters':['Eerste stappen','De dagelijkse basis','Vind je stem','Leg verbindingen','Druk je ideeën uit','Precisie & nuance'],
  'guide':'Lesgids', 'course_stage':'Cursusfase', 'check':'Niveautoets', 'unit':'Unit', 'lessons':'lessen',
  'complete':'Voltooid', 'locked':'Rond eerst de vorige unit af', 'test':'Unittoets klaar', 'start':'Klaar om te leren',
  'path_help':'Volg de lessen, oefen en haal de unittoetsen. Leer op jouw tempo.',
  'sidebar':'JOUW LEEROMGEVING', 'tools':'ONTDEKKEN & SAMEN LEREN', 'brand_line':'MAAK TAAL JOUW WERELD', 'skip':'Ga naar de inhoud', 'install':'App installeren',
 },
 'ckb': {
  'eyebrow':'هەموو ڕۆژێک هەنگاوێک', 'greeting':'خۆشحاڵین کە لێرەیت', 'intro':'هەنگاوی داهاتووت لێرە دەست پێ دەکات.',
  'next':'وانەی داهاتووت', 'hero':'ڕۆژێکی نوێ. هەنگاوێک بۆ ڕەوانتر قسەکردن.', 'hero_note':'بە هەر وانەیەک متمانە بە خۆت بەهێز بکە.',
  'continue':'بەردەوام بە لە فێربوون', 'choose':'کۆرسەکەت هەڵبژێرە', 'course':'پێشکەوتنی کۆرس', 'path':'گەشتی فێربوونت',
  'full_path':'ڕێڕەوەکە ببینە', 'day_plan':'ئەمڕۆ هەنگاوێک بنێ', 'daily_goal':'ئامانجی ئەمڕۆت', 'goal_done':'ئامانجی ئەمڕۆت بەدەست هێنا. ئافەرین!',
  'goal_note':'XPی فێربوون بۆ ئامانجی ڕۆژانەت هەژمار دەکرێت.', 'review':'وشەکان لە یاد بگرە', 'review_note':'کەمێک پێداچوونەوە بۆ یادگرتنێکی درێژتر.',
  'mistakes':'لە هەڵەکانت فێربە', 'mistakes_note':'بە ڕوونکردنەوەیەکی باشتر دووبارە هەوڵ بدە.', 'ready':'ئامادەن بۆ پێداچوونەوە', 'fix':'بۆ چاککردن',
  'week':'هەفتەکەت، ڕۆژ بە ڕۆژ', 'weekly_xp':'XPی فێربوون لەم هەفتەیە', 'streak':'ڕۆژ بەردەوام', 'longest':'درێژترین ستریک',
  'skills':'هەموو تواناکانت پەرە پێ بدە', 'skills_note':'چالاکییە تەواوکراوەکانی ئەم کۆرسە.', 'reading':'خوێندنەوە', 'listening':'گوێگرتن',
  'speaking':'قسەکردن', 'writing':'نووسین', 'grammar':'ڕێزمان', 'activity_note':'ژمارەی چالاکییەکان بەشداری پیشان دەدات، نەک ئاستێکی سەلمێنراوی زمان.',
  'friends_title':'پێکەوە باشترە', 'friends_note':'هانی هاوڕێیەک بدە. پێشکەوتنێکی بچووک پیرۆز بکە.', 'friends_cta':'هاوڕێکانت ببینە', 'friends_count':'هاوڕێ لەگەڵت فێر دەبن',
  'xp_level':'ئاستی XP', 'xp_note':'ئاستی XP چالاکی پیشان دەدات. A0–C1 قۆناغی کۆرسەکەتە.', 'next_level':'XP بۆ ئاستی داهاتوو',
  'library':'ڕێبەری ڕێزمانت', 'library_note':'ڕێسای ڕوون، نموونەی بەسوود و ڕاهێنانی کورت لە A0 تا C1.', 'library_cta':'ڕێزمان ببینە',
  'no_course':'کۆرسێکی بڵاوکراوە هەڵبژێرە بۆ دەستپێکردن.', 'no_next':'یەکە بەردەستەکانت تەواو کرد. پێداچوونەوە بە فێربوونەکەت بکە.',
  'active_course':'کۆرسی ئێستا', 'practice':'ڕاهێنان', 'days':'ڕۆژ', 'empty_week':'یەکەم دانیشتنی فێربوونت هەفتەکەت دەست پێ دەکات.',
  'new':'نوێ', 'chapter':'بەش', 'chapters':['هەنگاوە سەرەتاییەکان','بنەمای ژیانی ڕۆژانە','دەنگی خۆت بدۆزەوە','پەیوەندی دروست بکە','بیرۆکەکانت دەرببڕە','وردی و مانای ورد'],
  'guide':'ڕێبەر', 'course_stage':'قۆناغی کۆرس', 'check':'تاقیکردنەوەی ئاست', 'unit':'یەکە', 'lessons':'وانە',
  'complete':'تەواوبوو', 'locked':'سەرەتا یەکەی پێشوو تەواو بکە', 'test':'تاقیکردنەوەی یەکە ئامادەیە', 'start':'ئامادەی فێربوون',
  'path_help':'وانەکان بخوێنە، ڕاهێنان بکە و تاقیکردنەوەی یەکەکان تێپەڕێنە. بە پێی توانای خۆت فێربە.',
  'sidebar':'ژینگەی فێربوونت', 'tools':'دۆزینەوە و پەیوەندی', 'brand_line':'زمان بکە بە جیهانی خۆت', 'skip':'بڕۆ بۆ ناوەڕۆک', 'install':'دامەزراندنی ئەپ',
 },
 'ar': {
  'eyebrow':'خطوة صغيرة كل يوم', 'greeting':'سعداء بعودتك', 'intro':'خطوتك الصغيرة التالية تبدأ هنا.',
  'next':'درسك التالي', 'hero':'يوم جديد. وطلاقة أكبر.', 'hero_note':'ابنِ ثقتك بنفسك، درسًا بعد درس.',
  'continue':'تابع التعلم', 'choose':'اختر دورتك', 'course':'تقدم الدورة', 'path':'رحلتك التعليمية',
  'full_path':'شاهد المسار', 'day_plan':'اجعل لليوم أثرًا', 'daily_goal':'هدفك اليومي', 'goal_done':'حققت هدف اليوم. أحسنت!',
  'goal_note':'نقاط التعلم تحتسب نحو هدفك اليومي.', 'review':'كلمات لتتذكرها', 'review_note':'مراجعة قصيرة وذاكرة أقوى.',
  'mistakes':'حوّل الأخطاء إلى تقدم', 'mistakes_note':'حاول مجددًا، مع شرح أوضح.', 'ready':'جاهزة للمراجعة', 'fix':'للتصحيح',
  'week':'أسبوعك، يومًا بعد يوم', 'weekly_xp':'نقاط تعلم هذا الأسبوع', 'streak':'أيام متتالية', 'longest':'أطول سلسلة',
  'skills':'طوّر كل مهاراتك', 'skills_note':'الأنشطة المكتملة في هذه الدورة.', 'reading':'القراءة', 'listening':'الاستماع',
  'speaking':'التحدث', 'writing':'الكتابة', 'grammar':'القواعد', 'activity_note':'الأعداد تعكس المشاركة، وليست تقييمًا مستقلاً لمستوى اللغة.',
  'friends_title':'معًا أفضل', 'friends_note':'شجّع صديقًا واحتفل بخطوة صغيرة.', 'friends_cta':'شاهد أصدقاءك', 'friends_count':'أصدقاء يتعلمون معك',
  'xp_level':'مستوى XP', 'xp_note':'مستوى XP يعكس نشاطك. A0–C1 تصف مرحلة دورتك.', 'next_level':'نقطة للمستوى التالي',
  'library':'رفيقك في القواعد', 'library_note':'قواعد واضحة وأمثلة واختبارات قصيرة من A0 إلى C1.', 'library_cta':'اكتشف القواعد',
  'no_course':'اختر دورة منشورة لتبدأ.', 'no_next':'أكملت الوحدات المتاحة. راجع ما تعلمته.',
  'active_course':'الدورة الحالية', 'practice':'التدريب', 'days':'أيام', 'empty_week':'جلسة التعلم الأولى تبدأ أسبوعك.',
  'new':'جديد', 'chapter':'الفصل', 'chapters':['الخطوات الأولى','أساسيات الحياة اليومية','اعثر على صوتك','كوّن علاقات','عبّر عن أفكارك','الدقة والفروق الدقيقة'],
  'guide':'الدليل', 'course_stage':'مرحلة الدورة', 'check':'اختبار المستوى', 'unit':'الوحدة', 'lessons':'دروس',
  'complete':'مكتمل', 'locked':'أكمل الوحدة السابقة أولاً', 'test':'اختبار الوحدة جاهز', 'start':'جاهز للتعلم',
  'path_help':'تابع الدروس وتدرب واجتز اختبارات الوحدات. تعلم بالوتيرة المناسبة لك.',
  'sidebar':'مساحتك التعليمية', 'tools':'اكتشف وتواصل', 'brand_line':'اجعل اللغة عالمك', 'skip':'انتقل إلى المحتوى', 'install':'تثبيت التطبيق',
 },
}

for _language, _extra in {
    'en': {'privacy':'Privacy', 'terms':'Terms', 'cert_note':'Learning certificates are not accredited exams'},
    'nl': {'privacy':'Privacy', 'terms':'Voorwaarden', 'cert_note':'Leercertificaten zijn geen erkende examens'},
    'ckb': {'privacy':'تایبەتمەندی', 'terms':'مەرجەکان', 'cert_note':'بڕوانامەی فێربوون تاقیکردنەوەی فەرمی نییە'},
    'ar': {'privacy':'الخصوصية', 'terms':'الشروط', 'cert_note':'شهادات التعلم ليست اختبارات معتمدة'},
}.items():
    COPY[_language].update(_extra)


def interface_context(request):
    from .safe_profile_context_v46 import visible_learning_profile
    profile = visible_learning_profile(request.user)
    lang = profile.ui_language if profile is not None else 'en'
    ctx = {'V9': COPY.get(lang, COPY['en'])}
    if profile is not None:
        ctx['live_streak'] = current_streak(profile)
        # Optional styling does not create records on every page request.
        from .social_models import AvatarStyle
        ctx['avatar_style'] = AvatarStyle.objects.filter(user=request.user).first()
    return ctx


def dashboard_details(user, route):
    from .progress_v9 import dashboard_progress
    labels = COPY.get(user.learning_profile.ui_language, COPY['en'])
    course = route['language']
    totals = dict(LessonProgress.objects.filter(user=user, lesson__unit__level__language=course,
        lesson__published=True, lesson__unit__published=True).values('lesson__skill').annotate(total=Count('pk')).values_list('lesson__skill','total'))
    icons = {'reading':'📖', 'listening':'🎧', 'grammar':'🧩'}
    friends = Friendship.objects.filter(Q(from_user=user,to_user__learning_profile__social_opt_in=True) |
        Q(to_user=user,from_user__learning_profile__social_opt_in=True), status='accepted').count() if user.learning_profile.social_opt_in else 0
    progress = dashboard_progress(user)
    return {'journey':progress, 'skills':[{'key':key,'title':labels[key],'icon':icon,'count':totals.get(key,0)} for key,icon in icons.items()],
            'friend_count':friends, 'xp_remaining':200-user.learning_profile.xp%200}


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'experience_v9', ['COPY'])

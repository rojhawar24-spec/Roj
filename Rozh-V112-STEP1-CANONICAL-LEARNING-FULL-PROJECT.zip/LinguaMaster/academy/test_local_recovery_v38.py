"""Regression for local owner-reviewed recovery. Separate Django test database."""
from io import StringIO
from types import SimpleNamespace
from unittest.mock import patch
from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.core.management.base import CommandError
from django.db.models import Q
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from academy.models import AuditEvent
from academy.email_verification_tokens import email_verification_token_generator


@override_settings(DEBUG=True, SITE_URL='http://127.0.0.1:3000',
                   MAILERS={'default':{'BACKEND':'django.core.mail.backends.locmem.EmailBackend'}})
class LocalAccountRecoveryV38Tests(TestCase):
    def setUp(self):
        self.password='A-Random-Passphrase-2026!'
        self.user = get_user_model().objects.create_user(
            'user38', 'user38@example.test', self.password, is_active=False)
        self.profile = self.user.learning_profile
        self.profile.legacy_review_required=True
        self.profile.save(update_fields=['legacy_review_required'])

    def run_review(self, email='user38@example.test', phrase='REVIEW user38'):
        with (patch('academy.management.commands.review_local_legacy_account._require_local_operator_context'),
              patch('academy.management.commands.review_local_legacy_account.sys.stdin', new=SimpleNamespace(isatty=lambda:True)),
              patch('builtins.input', side_effect=[email, phrase])):
            return call_command('review_local_legacy_account', username=self.user.username,
                                approve_legacy=True, stdout=StringIO())

    def test_preflight_is_read_only(self):
        with patch('academy.management.commands.review_local_legacy_account._require_local_operator_context'):
            call_command('review_local_legacy_account', username='user38', check_only=True,
                         stdout=StringIO())
        self.user.refresh_from_db(); self.profile.refresh_from_db()
        self.assertFalse(self.user.is_active)
        self.assertTrue(self.profile.legacy_review_required)
        self.assertEqual(self.profile.email_verification_version,0)

    def test_explicit_review_only_releases_hold_not_login_or_password(self):
        self.run_review()
        self.user.refresh_from_db(); self.profile.refresh_from_db()
        self.assertFalse(self.user.is_active)
        self.assertIsNone(self.profile.email_verified_at)
        self.assertFalse(self.profile.legacy_review_required)
        self.assertEqual(self.profile.email_verification_version,1)
        self.assertTrue(self.user.check_password(self.password))
        self.assertFalse(self.user.is_staff)
        self.assertFalse(self.user.is_superuser)
        self.assertTrue(AuditEvent.objects.filter(action='local_legacy_review_approved',target=str(self.user.pk)).exists())

    def test_wrong_email_or_confirmation_never_releases_hold(self):
        for email,phrase in [('wrong@example.test','REVIEW user38'),
                             ('user38@example.test','REVIEW someoneelse')]:
            with self.subTest(email=email,phrase=phrase):
                with self.assertRaises(CommandError): self.run_review(email,phrase)
                self.profile.refresh_from_db()
                self.assertTrue(self.profile.legacy_review_required)
                self.assertEqual(self.profile.email_verification_version,0)

    def test_noninteractive_approval_denied(self):
        with (patch('academy.management.commands.review_local_legacy_account._require_local_operator_context'),
              patch('academy.management.commands.review_local_legacy_account.sys.stdin', new=SimpleNamespace(isatty=lambda:False))):
            with self.assertRaises(CommandError):
                call_command('review_local_legacy_account', username='user38',
                             approve_legacy=True, stdout=StringIO())
        self.profile.refresh_from_db()
        self.assertTrue(self.profile.legacy_review_required)

    def test_manager_suspension_never_released(self):
        self.profile.suspended_at=timezone.now()
        self.profile.save(update_fields=['suspended_at'])
        with self.assertRaises(CommandError): self.run_review()
        self.profile.refresh_from_db()
        self.assertTrue(self.profile.legacy_review_required)
        self.assertIsNotNone(self.profile.suspended_at)

    def test_inactive_previously_verified_never_released(self):
        self.profile.email_verified_at=timezone.now()
        self.profile.save(update_fields=['email_verified_at'])
        with self.assertRaises(CommandError): self.run_review()

    def test_no_privileged_account_can_use_local_recovery(self):
        self.user.is_staff=True; self.user.save(update_fields=['is_staff'])
        with self.assertRaises(CommandError): self.run_review()

    def test_full_review_change_password_verify_then_normal_login(self):
        self.run_review()
        self.user.refresh_from_db(); self.profile.refresh_from_db()
        # The normal Django changepassword CLI performs the same hashing.
        self.user.set_password('New-Strong-Learner-Password-38!')
        self.user.save(update_fields=['password'])
        uid=urlsafe_base64_encode(force_bytes(self.user.pk))
        token=email_verification_token_generator.make_token(self.user)
        url=reverse('verify_email',args=[uid,token])
        self.assertEqual(self.client.get(url).status_code,200)
        self.user.refresh_from_db()
        self.assertFalse(self.user.is_active)
        with patch('academy.views.send_mail'):
            self.assertEqual(self.client.post(url).status_code,302)
        self.user.refresh_from_db(); self.profile.refresh_from_db()
        self.assertTrue(self.user.is_active)
        self.assertIsNotNone(self.profile.email_verified_at)
        self.assertFalse(self.profile.legacy_review_required)
        self.assertEqual(self.client.post(reverse('login'), {
            'email':'user38','password':'New-Strong-Learner-Password-38!'
        }).status_code,302)

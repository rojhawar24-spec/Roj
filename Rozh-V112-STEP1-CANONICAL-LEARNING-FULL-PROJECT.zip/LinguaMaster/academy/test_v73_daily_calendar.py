"""V73 isolated Django tests: run against Django's disposable TEST database only.

python manage.py test academy.test_v73_daily_calendar academy.test_daily_word_v18 \
    academy.test_v25_daily_word_authorization --noinput
"""
from datetime import date, timedelta
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import TestCase, Client
from django.urls import reverse

from .models import (DailyWordEntry, DailyWordWeeklySession, Language,
                     Level, Vocabulary, XPEvent, Profile, ReviewCard)


class DailyCalendarV73Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user('v73_daily_student', password='OnlyForTest!A73')
        cls.nl = Language.objects.create(name='Dutch', code='nl', slug='v73-dutch', is_published=True)
        cls.fr = Language.objects.create(name='French', code='fr', slug='v73-french', is_published=True)
        cls.level_nl = Level.objects.create(language=cls.nl, code='A0', order=0)
        cls.level_fr = Level.objects.create(language=cls.fr, code='A0', order=0)
        cls.words = [Vocabulary.objects.create(level=cls.level_nl, word=w, translation=t,
                        pronunciation='', example='A learning example.', published=True)
                     for w, t in [('appel', 'apple'), ('huis', 'house'), ('boek','book'),
                                  ('tafel','table'), ('water', 'water'), ('fiets','bike'),
                                  ('lopen','walk')]]
        cls.other = Vocabulary.objects.create(level=cls.level_fr, word='bonjour',
                      translation='hello', pronunciation='', example='', published=True)
        Profile.objects.filter(user=cls.user).update(preferred_language=cls.nl,
                 ui_language='nl', placement_completed=True, onboarding_completed=True)

    def setUp(self):
        self.client.force_login(self.user)
        self.day = date(2026, 11, 21)
        self.day_patch = patch('academy.services.user_localdate', return_value=self.day)
        self.day_patch.start()
        self.addCleanup(self.day_patch.stop)

    def test_first_get_freezes_word_and_manager_add_cannot_change_it(self):
        response = self.client.get(reverse('word'))
        self.assertEqual(response.status_code, 200)
        entry = DailyWordEntry.objects.get(user=self.user, course=self.nl, day=self.day)
        before = entry.word_text
        self.assertIn(before, response.content.decode('utf8'))
        Vocabulary.objects.create(level=self.level_nl, word='nieuwword', translation='new',
                                  pronunciation='', example='', published=True)
        self.assertEqual(self.client.get(reverse('word')).status_code, 200)
        self.assertEqual(DailyWordEntry.objects.get(user=self.user, course=self.nl, day=self.day).pk, entry.pk)
        self.assertEqual(DailyWordEntry.objects.get(pk=entry.pk).word_text, before)
        self.assertEqual(DailyWordEntry.objects.filter(user=self.user, course=self.nl, day=self.day).count(),1)

    def test_manager_edit_does_not_change_word_translation_or_award(self):
        self.client.get(reverse('word'))
        entry = DailyWordEntry.objects.get(user=self.user, day=self.day)
        original = entry.word_text
        original_meaning = entry.meaning_text
        Vocabulary.objects.filter(pk=entry.vocabulary_id).update(word='manager-edited', translation='CHANGED')
        response = self.client.get(reverse('word'))
        self.assertContains(response, original)
        self.assertContains(response, original_meaning)
        self.assertNotContains(response, 'manager-edited')
        self.client.post(reverse('word'), {'answer':original})
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='daily_word').count(),1)
        self.assertIsNotNone(DailyWordEntry.objects.get(pk=entry.pk).completed_at)

    def test_seven_days_unique_until_course_is_exhausted(self):
        seen=[]
        for n in range(7):
            with patch('academy.services.user_localdate', return_value=self.day+timedelta(days=n)):
                self.client.get(reverse('word'))
            seen.append(DailyWordEntry.objects.get(user=self.user, course=self.nl,
                                    day=self.day+timedelta(days=n)).word_text)
        self.assertEqual(len(set(seen)),7)
        with patch('academy.services.user_localdate', return_value=self.day+timedelta(days=7)):
            self.client.get(reverse('word'))
        self.assertEqual(DailyWordEntry.objects.get(user=self.user, course=self.nl,
                                    day=self.day+timedelta(days=7)).cycle,2)

    def test_daily_xp_only_once_and_no_hearts_reward(self):
        self.client.get(reverse('word'))
        word = DailyWordEntry.objects.get(user=self.user, day=self.day).word_text
        from .models import HeartEvent
        start = HeartEvent.objects.filter(user=self.user).count()
        for _ in range(3):
            r=self.client.post(reverse('word'), {'answer':word})
            self.assertEqual(r.status_code,200)
        self.assertEqual(XPEvent.objects.filter(user=self.user,reason='daily_word').count(),1)
        self.assertEqual(Profile.objects.get(user=self.user).xp,10)
        self.assertEqual(HeartEvent.objects.filter(user=self.user).count(),start)
        self.assertEqual(DailyWordEntry.objects.filter(user=self.user,completed_at__isnull=False).count(),1)

    def test_wrong_answer_does_not_mark_daily_word_completed(self):
        self.client.get(reverse('word'))
        self.client.post(reverse('word'), {'answer':'niets-correct'})
        self.assertFalse(DailyWordEntry.objects.filter(user=self.user,completed_at__isnull=False).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user,reason='daily_word').exists())

    def test_missing_course_and_unpublished_word_never_award(self):
        self.client.get(reverse('word'))
        entry=DailyWordEntry.objects.get(user=self.user,day=self.day)
        Vocabulary.objects.filter(pk=entry.vocabulary_id).update(published=False)
        self.client.post(reverse('word'),{'answer':entry.word_text})
        self.assertFalse(XPEvent.objects.filter(user=self.user,reason='daily_word').exists())
        self.assertFalse(DailyWordEntry.objects.get(pk=entry.pk).completed_at)

    def test_switch_course_same_day_keeps_xp_once_and_separate_history(self):
        self.client.get(reverse('word'))
        word=DailyWordEntry.objects.get(user=self.user,day=self.day).word_text
        self.client.post(reverse('word'),{'answer':word})
        Profile.objects.filter(user=self.user).update(preferred_language=self.fr)
        self.client.post(reverse('word'),{'answer':'bonjour'})
        self.assertEqual(XPEvent.objects.filter(user=self.user,reason='daily_word').count(),1)
        self.assertEqual(DailyWordEntry.objects.filter(user=self.user,day=self.day).count(),2)

    def _completed_history(self):
        # Previous complete week for Saturday Nov 21: Nov 9-15.
        start=date(2026,11,9)
        for i, w in enumerate(self.words):
            DailyWordEntry.objects.create(user=self.user,course=self.nl,day=start+timedelta(days=i),
                vocabulary=w,word_text=w.word,meaning_text=w.translation,emoji_text=w.emoji,
                completed_at=__import__('django').utils.timezone.now())

    def test_weekly_review_uses_only_real_last_week_completed_words(self):
        self._completed_history()
        response=self.client.get(reverse('daily_weekly_review'))
        self.assertEqual(response.status_code,200)
        session=DailyWordWeeklySession.objects.get(user=self.user,course=self.nl)
        self.assertEqual(len(session.items),7)
        self.assertEqual(session.week_start,date(2026,11,16))
        self.assertNotIn('bonjour',response.content.decode('utf8'))
        # Only meaning, not answer, is shown for the first challenge.
        self.assertContains(response, session.items[0]['meaning'])
        self.assertNotContains(response, f'>{session.items[0]["word"]}</')

    def test_weekly_25_answers_cannot_be_spoofed_and_once_per_week(self):
        self._completed_history()
        self.client.get(reverse('daily_weekly_review'))
        session=DailyWordWeeklySession.objects.get(user=self.user,course=self.nl)
        wrong=self.client.post(reverse('daily_weekly_review'),{'position':0,'answer':'wrong!'})
        self.assertEqual(wrong.status_code,200)
        session.refresh_from_db();self.assertEqual(session.position,0)
        for n,item in enumerate(session.items):
            r=self.client.post(reverse('daily_weekly_review'),{'position':n,'answer':item['word']})
            self.assertEqual(r.status_code,200)
        session.refresh_from_db()
        self.assertEqual(session.position,7)
        self.assertIsNotNone(session.completed_at)
        replay=self.client.post(reverse('daily_weekly_review'),{'position':0,'answer':session.items[0]['word']})
        self.assertEqual(replay.status_code,200)
        self.assertEqual(DailyWordWeeklySession.objects.filter(user=self.user,course=self.nl).count(),1)
        self.assertFalse(XPEvent.objects.filter(user=self.user, reason='review').exists())

    def test_weekly_stale_request_does_not_skip_steps(self):
        self._completed_history()
        self.client.get(reverse('daily_weekly_review'))
        session=DailyWordWeeklySession.objects.get(user=self.user,course=self.nl)
        first=session.items[0]['word']
        self.client.post(reverse('daily_weekly_review'),{'position':0,'answer':first})
        replay=self.client.post(reverse('daily_weekly_review'),{'position':0,'answer':first})
        self.assertEqual(replay.status_code,409)
        self.assertEqual(DailyWordWeeklySession.objects.get(pk=session.pk).position,1)

    def test_weekly_empty_if_no_completed_words_and_preserves_v71_removal(self):
        response=self.client.get(reverse('daily_weekly_review'))
        self.assertEqual(response.status_code,200)
        self.assertFalse(DailyWordWeeklySession.objects.filter(user=self.user).exists())
        self.assertNotContains(response,'BRAIN TRAINING')
        self.assertEqual(self.client.get(reverse('review')).status_code,302)
        legacy=self.client.get(reverse('weekly_review'))
        self.assertRedirects(legacy,reverse('daily_weekly_review'))
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_weekly_never_uses_draft_or_another_course_and_csrf_protected(self):
        self._completed_history()
        other=DailyWordEntry.objects.create(user=self.user, course=self.fr,
             day=date(2026,11,10),vocabulary=self.other,word_text='bonjour',
             meaning_text='hello', completed_at=__import__('django').utils.timezone.now())
        self.client.get(reverse('daily_weekly_review'))
        session=DailyWordWeeklySession.objects.get(user=self.user,course=self.nl)
        self.assertNotIn(other.vocabulary_id,[i['vocabulary_id'] for i in session.items])
        # Explicit CSRF-enforcing client: valid authenticated POST without token rejected.
        strict=Client(enforce_csrf_checks=True)
        strict.force_login(self.user)
        r=strict.post(reverse('daily_weekly_review'),{'position':0,'answer':session.items[0]['word']})
        self.assertEqual(r.status_code,403)

"""Actual Django TestCase contracts for Phase 4; run ONLY in disposable test DB.

NOT validated until scripts/phase4_local_student_runtime.py succeeds.
"""
from urllib.parse import parse_qs, urlsplit

from django.contrib.auth import get_user_model
from django.test import Client, TestCase
from django.urls import reverse
from .models import Language, Level, Vocabulary


class VocabularyStudentUXTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.student=get_user_model().objects.create_user('phase4-student','phase4@example.invalid','Test passphrase only 2026')
        cls.en=Language.objects.create(code='en',name='English',slug='phase4-en',description='',is_published=True)
        cls.nl=Language.objects.create(code='nl',name='Dutch',slug='phase4-nl',description='',is_published=True)
        cls.a0=Level.objects.create(language=cls.en,code='A0',order=0,description='Start')
        cls.a1=Level.objects.create(language=cls.en,code='A1',order=1,description='Next')
        cls.other_level=Level.objects.create(language=cls.nl,code='A0',order=0,description='Other')
        for n in range(27):
            Vocabulary.objects.create(level=cls.a0,word=f'hello{n:02}',translation=f'greeting-{n}',
                  pronunciation='heh-low',example=f'hello{n:02} friend',published=True)
        Vocabulary.objects.create(level=cls.a0,word='never-see-this-unpublished',translation='private',
                                 pronunciation='',example='',published=False)
        Vocabulary.objects.create(level=cls.other_level,word='other-language-only',translation='other',
                                 pronunciation='',example='',published=True)
        profile=cls.student.learning_profile
        profile.preferred_language=cls.en
        profile.ui_language='nl'
        profile.save(update_fields=['preferred_language','ui_language'])

    def setUp(self):
        self.client.force_login(self.student)

    def test_shared_student_shell_active_nav_and_no_legacy_shell(self):
        response=self.client.get(reverse('vocabulary'))
        self.assertEqual(response.status_code,200)
        self.assertTemplateUsed(response,'academy/rozh2027_student_shell.html')
        self.assertContains(response,'r54-vocabulary-mode')
        self.assertContains(response,'r27-student-frame')
        self.assertContains(response,'href="/vocabulary/" aria-current="page"')
        self.assertNotContains(response,'class="app-sidebar"')
        self.assertContains(response,'27')
        self.assertNotContains(response,'never-see-this-unpublished')
        self.assertNotContains(response,'other-language-only')

    def test_search_level_and_pagination_are_kept(self):
        response=self.client.get(reverse('vocabulary'), {'q':'hello', 'level':'A0', 'page':2})
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.context['vocab_items'].number,2)
        self.assertContains(response,'page=1&amp;level=A0&amp;q=hello',html=False)
        self.assertContains(response,'hello26')
        self.assertNotContains(response,'hello00')

    def test_empty_results_have_filter_reset(self):
        response=self.client.get(reverse('vocabulary'), {'q':'no-such-word'})
        self.assertContains(response,'Geen woorden gevonden met deze filters.')
        self.assertContains(response,reverse('vocabulary'))

    def test_four_language_copy_and_rtl(self):
        profile=self.student.learning_profile
        for locale in ('nl','en','ckb','ar'):
            profile.ui_language=locale
            profile.save(update_fields=['ui_language'])
            response=self.client.get(reverse('vocabulary'))
            self.assertEqual(response.status_code,200,locale)
            self.assertContains(response,f'lang="{locale}"')
            self.assertContains(response,'dir="rtl"' if locale in ('ckb','ar') else 'dir="ltr"')
            self.assertContains(response,'r54-vocab-search')
            self.assertContains(response,'aria-current="page"')

    def test_logged_out_user_cannot_browse_private_vocabulary(self):
        self.client.logout()
        response=self.client.get(reverse('vocabulary'))
        self.assertEqual(response.status_code,302)
        self.assertIn(reverse('login'),response['Location'])

    def test_switch_from_vocabulary_keeps_sanitized_filters_and_never_external_host(self):
        endpoint=reverse('switch_ui_language')
        response=self.client.post(endpoint, {'ui_language':'ckb','return_to':'vocabulary',
                                            'vocab_query':'hello & goodbye','vocab_level':'A0','vocab_page':'2'})
        self.assertEqual(response.status_code,302)
        parsed=urlsplit(response.url)
        self.assertEqual(parsed.path,reverse('vocabulary'))
        self.assertFalse(parsed.netloc)
        self.assertEqual(parse_qs(parsed.query),{'q':['hello & goodbye'],'level':['A0'],'page':['2']})
        profile=self.student.learning_profile
        profile.refresh_from_db()
        self.assertEqual(profile.ui_language,'ckb')
        response=self.client.post(endpoint,{'ui_language':'nl','return_to':'https://attacker.invalid/',
                 'vocab_query':'secret','vocab_level':'A0','vocab_page':'2'})
        self.assertEqual(response.url,reverse('play_hub'))

    def test_invalid_paging_and_level_cannot_enter_redirect(self):
        response=self.client.post(reverse('switch_ui_language'),{'ui_language':'en',
                 'return_to':'vocabulary','vocab_query':'ok','vocab_level':'invalid',
                 'vocab_page':'999999999999999999999999'})
        self.assertEqual(response.url,reverse('vocabulary')+'?q=ok')

    def test_invalid_language_and_csrf_still_blocked(self):
        old=self.student.learning_profile.ui_language
        response=self.client.post(reverse('switch_ui_language'),{'ui_language':'xx','return_to':'vocabulary'})
        self.assertEqual(response.status_code,400)
        self.student.learning_profile.refresh_from_db()
        self.assertEqual(self.student.learning_profile.ui_language,old)
        secured=Client(enforce_csrf_checks=True)
        secured.force_login(self.student)
        self.assertEqual(secured.post(reverse('switch_ui_language'),
                           {'ui_language':'nl','return_to':'vocabulary'}).status_code,403)

    def test_rendering_library_does_not_change_xp_or_create_lessons(self):
        profile=self.student.learning_profile
        xp=profile.xp
        self.client.get(reverse('vocabulary'),{'q':'hello'})
        profile.refresh_from_db()
        self.assertEqual(profile.xp,xp)

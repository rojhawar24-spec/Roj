"""Phase 1 Django integration regressions; disposable Django test DB only.

No live email, external services, or real existing accounts. Execute with
  python manage.py test academy.test_phase1_auth_journey --settings=config.settings_sandbox_v52
This suite must be RUN in an installed Django environment before release approval.
"""
import re
from urllib.parse import urlsplit

import pyotp
from django.contrib.auth import get_user_model
from django.core import mail
from django.core.cache import cache
from django.test import Client, TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from .models import Language, PlatformSettings

User = get_user_model()


@override_settings(
    MAILERS={'default': {'BACKEND': 'django.core.mail.backends.locmem.EmailBackend'}},
    SITE_URL='http://testserver',
)
class Phase1RegistrationFlowTests(TestCase):
    PASSWORD = 'UniqueLongPassword2026!'

    def setUp(self):
        cache.clear()
        settings = PlatformSettings.load()
        settings.public_registration_enabled = True
        settings.save(update_fields=['public_registration_enabled'])

    def register(self, username='phase1_user', email='phase1@example.test', destination='/grammar/'):
        return self.client.post(reverse('register'), {
            'username': username, 'email': email, 'password1': self.PASSWORD,
            'age_confirmed': 'on', 'next': destination,
        })

    def verification_path(self):
        url = re.search(r'https?://[^\s]+/verify/[^\s]+', mail.outbox[0].body)
        self.assertIsNotNone(url)
        return urlsplit(url.group()).path

    @override_settings(REQUIRE_EMAIL_VERIFICATION=True)
    def test_new_user_stays_inactive_until_verification_then_same_browser_signs_in(self):
        self.assertRedirects(self.register(), reverse('registration_check_email'), fetch_redirect_response=False)
        learner = User.objects.get(username='phase1_user')
        self.assertFalse(learner.is_active)
        self.assertNotIn('_auth_user_id', self.client.session)
        self.assertEqual(self.client.session.get('registration_pending_user_id'), learner.pk)
        url = self.verification_path()
        self.assertEqual(self.client.get(url).status_code, 200)
        learner.refresh_from_db()
        self.assertFalse(learner.is_active)   # GET is read-only, email scanners cannot activate
        response = self.client.post(url, {'next': '/grammar/'})
        self.assertRedirects(response, reverse('onboarding'), fetch_redirect_response=False)
        self.assertEqual(int(self.client.session['_auth_user_id']), learner.pk)
        self.assertNotIn('registration_pending_user_id', self.client.session)
        self.assertEqual(self.client.session.get('post_auth_next'), '/grammar/')
        learner.refresh_from_db()
        self.assertTrue(learner.is_active)
        self.assertIsNotNone(learner.learning_profile.email_verified_at)
        self.assertEqual(self.client.post(url).status_code, 302)   # token is one-time

    @override_settings(REQUIRE_EMAIL_VERIFICATION=True)
    def test_different_browser_must_still_supply_password_after_email_verification(self):
        self.register()
        learner = User.objects.get(username='phase1_user')
        verification_url = self.verification_path()
        second_browser = Client()
        self.assertEqual(second_browser.get(verification_url).status_code, 200)
        result = second_browser.post(verification_url)
        self.assertRedirects(result, reverse('login'), fetch_redirect_response=False)
        self.assertNotIn('_auth_user_id', second_browser.session)
        learner.refresh_from_db()
        self.assertTrue(learner.is_active)
        self.assertIsNotNone(learner.learning_profile.email_verified_at)

    @override_settings(REQUIRE_EMAIL_VERIFICATION=True)
    def test_duplicate_registration_cannot_inherit_pending_session_owner(self):
        self.register()
        pending = User.objects.get(username='phase1_user')
        self.assertEqual(self.client.session.get('registration_pending_user_id'), pending.pk)
        self.register(username='other_name', email='phase1@example.test')
        self.assertNotIn('registration_pending_user_id', self.client.session)
        self.assertFalse(User.objects.filter(username='other_name').exists())

    @override_settings(REQUIRE_EMAIL_VERIFICATION=True)
    def test_strict_mode_disables_legacy_password_only_activation(self):
        previous = User.objects.create_user(
            'old_pending', 'old_pending@example.test', self.PASSWORD, is_active=False,
        )
        state = previous.learning_profile
        state.onboarding_required = False
        state.save(update_fields=['onboarding_required'])
        reply = self.client.post(reverse('login'), {'email': previous.email, 'password': self.PASSWORD})
        self.assertEqual(reply.status_code, 200)
        previous.refresh_from_db()
        self.assertFalse(previous.is_active)
        self.assertNotIn('_auth_user_id', self.client.session)

    @override_settings(REQUIRE_EMAIL_VERIFICATION=False)
    def test_local_compatibility_keeps_legacy_password_only_activation(self):
        previous = User.objects.create_user(
            'old_local', 'old_local@example.test', self.PASSWORD, is_active=False,
        )
        state = previous.learning_profile
        state.onboarding_required = False
        state.save(update_fields=['onboarding_required'])
        reply = self.client.post(reverse('login'), {'email': previous.email, 'password': self.PASSWORD})
        self.assertEqual(reply.status_code, 302)
        previous.refresh_from_db()
        self.assertTrue(previous.is_active)
        self.assertEqual(int(self.client.session['_auth_user_id']), previous.pk)


@override_settings(REQUIRE_EMAIL_VERIFICATION=False)
class Phase1PostSetupJourneyTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = User.objects.create_user('phase1_path', 'phase1-path@example.test', 'UniqueLongPassword2026!')
        profile = self.user.learning_profile
        profile.onboarding_required = False
        profile.onboarding_completed = True
        profile.placement_completed = False
        profile.save(update_fields=['onboarding_required', 'onboarding_completed', 'placement_completed'])
        self.language = Language.objects.create(code='nl', name='Dutch', slug='phase1-dutch',
                                                description='', is_published=True)
        profile.preferred_language = self.language
        profile.save(update_fields=['preferred_language'])
        self.client.force_login(self.user)

    def set_intent(self, intended):
        session = self.client.session
        session['post_auth_next'] = intended
        session.save()

    def test_skip_placement_preserves_original_feature_one_time(self):
        self.set_intent('/grammar/')
        response = self.client.post(reverse('placement'), {'skip_placement': '1'})
        self.assertRedirects(response, '/grammar/', fetch_redirect_response=False)
        self.assertNotIn('post_auth_next', self.client.session)
        self.user.learning_profile.refresh_from_db()
        self.assertTrue(self.user.learning_profile.placement_completed)

    def test_skip_placement_rejects_external_or_privileged_intents(self):
        for destination in ('//other.example/steal', 'https://other.example/', '/manager/'):
            with self.subTest(destination=destination):
                profile = self.user.learning_profile
                profile.placement_completed = False
                profile.save(update_fields=['placement_completed'])
                self.set_intent(destination)
                answer = self.client.post(reverse('placement'), {'skip_placement': '1'})
                self.assertRedirects(answer, reverse('play_hub'), fetch_redirect_response=False)
                self.assertNotIn('post_auth_next', self.client.session)

    def test_already_placed_learner_consumes_saved_intent(self):
        profile = self.user.learning_profile
        profile.placement_completed = True
        profile.save(update_fields=['placement_completed'])
        self.set_intent('/grammar/')
        result = self.client.get(reverse('placement'))
        self.assertRedirects(result, '/grammar/', fetch_redirect_response=False)
        self.assertNotIn('post_auth_next', self.client.session)


@override_settings(REQUIRE_EMAIL_VERIFICATION=False)
class Phase1MFABoundaryTests(TestCase):
    PASSWORD = 'UniqueLongPassword2026!'

    def setUp(self):
        cache.clear()
        self.user = User.objects.create_user('phase1_mfa', 'phase1-mfa@example.test', self.PASSWORD)
        profile = self.user.learning_profile
        profile.totp_secret = pyotp.random_base32()
        profile.save(update_fields=['totp_secret'])
        response = self.client.post(reverse('login'), {'email': self.user.username, 'password': self.PASSWORD})
        self.assertRedirects(response, reverse('mfa_verify'), fetch_redirect_response=False)
        self.assertEqual(self.client.session.get('pending_mfa_user_id'), self.user.pk)

    def test_pending_mfa_cannot_resume_after_quarantine(self):
        state = self.user.learning_profile
        state.legacy_review_required = True
        state.save(update_fields=['legacy_review_required'])
        answer = self.client.get(reverse('mfa_verify'))
        self.assertRedirects(answer, reverse('login'), fetch_redirect_response=False)
        self.assertNotIn('pending_mfa_user_id', self.client.session)
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_pending_mfa_cannot_resume_after_suspension_even_if_account_active(self):
        state = self.user.learning_profile
        state.suspended_at = timezone.now()
        state.save(update_fields=['suspended_at'])
        answer = self.client.get(reverse('mfa_verify'))
        self.assertRedirects(answer, reverse('login'), fetch_redirect_response=False)
        self.assertNotIn('pending_mfa_user_id', self.client.session)
        self.assertNotIn('_auth_user_id', self.client.session)

"""V46 Django integration tests. Must be executed on a Django-equipped machine.

TestCase uses Django's separate test database, never the user's live accounts.
"""
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.test import TestCase
from django.urls import reverse
from .models import Language, Level, LearningSeason, Unit, Vocabulary, Profile


class Rozh2027IntegrationTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.language = Language.objects.create(code='nl', slug='dutch-v46', name='Dutch', description='Test language', is_published=True)
        cls.level = Level.objects.create(language=cls.language, code='A0', description='Starting', order=0)
        cls.user = get_user_model().objects.create_user(username='v46learner', email='v46@example.invalid', password='V46TestStrongPassphrase_7', is_active=True)
        profile, _ = Profile.objects.get_or_create(user=cls.user)
        profile.preferred_language = cls.language
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.save()

    def test_optional_season_and_existing_units(self):
        season = LearningSeason.objects.create(level=self.level, slug='home', title='At home', published=True)
        unit = Unit.objects.create(level=self.level, slug='v46-one', title='Greetings', summary='Say hello', published=True, season=season)
        unit.full_clean()
        self.assertEqual(unit.season_id, season.pk)
        self.assertEqual(LearningSeason.objects.filter(level=self.level).count(), 1)

    def test_wrong_cefr_season_rejected(self):
        another = Level.objects.create(language=self.language, code='A1', description='Next', order=1)
        season = LearningSeason.objects.create(level=another, slug='new', title='Next', published=True)
        unit = Unit(level=self.level, slug='bad-assignment', title='Mismatch', summary='Mismatch', season=season)
        with self.assertRaises(ValidationError):
            unit.full_clean()

    def test_vocabulary_is_private_and_published_only(self):
        url = reverse('vocabulary')
        self.assertEqual(self.client.get(url).status_code, 302)
        Vocabulary.objects.create(level=self.level, word='goed', translation='good', pronunciation='', example='Een goede dag.', published=True)
        Vocabulary.objects.create(level=self.level, word='hiddenword', translation='hidden', pronunciation='', example='', published=False)
        self.client.force_login(self.user)
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'goed')
        self.assertNotContains(response, 'hiddenword')
        self.assertEqual(self.client.post(url).status_code, 405)

    def test_student_denied_owner_dashboard(self):
        self.client.force_login(self.user)
        self.assertEqual(self.client.get(reverse('manager')).status_code, 403)

"""Read-only Rozh presentation of trusted course progress. No XP or unlocking writes."""
from collections import OrderedDict
from django.db.models import Q
from .models import LearningSeason, Unit, BadgeAward, Friendship
from .services import learning_level
from .rozh_v53_ui import LABELS as R53_LABELS, build_path_nodes, unit_title, course_name

COPY = {
 'nl': dict(skip='Naar hoofdinhoud',play='Leer & Speel',grammar='Grammatica',vocab='Vocabulaire',word='Woord van de dag',mistakes='Mijn fouten',friends='Vrienden',rank='Ranglijst',ai='AI Teacher',profile='Mijn profiel',settings='Instellingen',logout='Uitloggen',menu='Menu',level='Level',streak='Streak',hearts='Hearts',coins='Coins',xp='XP',daily='Dagdoel',learn='Verder leren',seasons='Seizoenen',season='Seizoen',change='Kies een taal',completed='Afgerond',current='Huidige les',available='Beschikbaar',locked='Vergrendeld',start='Start les',repeat='Herhaal les',test='Start toets',lessons='lessen',no_content='Nog geen gepubliceerde lessen',welcome='Welkom terug',growth='Jouw leerreis',progress='Voortgang',badges='Badges',next='Volgende stap',open='Bekijk alle niveaus',today='Vandaag',more='Andere leerfuncties',journey='Jouw leerroute',interface_language='Interfacetaal',apply='Toepassen',theme_to_dark='Schakel naar donkere modus',theme_to_light='Schakel naar lichte modus'),
 'en': dict(skip='Skip to content',play='Learn & Play',grammar='Grammar',vocab='Vocabulary',word='Word of the day',mistakes='My mistakes',friends='Friends',rank='Leaderboard',ai='AI Teacher',profile='My profile',settings='Settings',logout='Log out',menu='Menu',level='Level',streak='Streak',hearts='Hearts',coins='Coins',xp='XP',daily='Daily goal',learn='Continue learning',seasons='Seasons',season='Season',change='Change language',completed='Completed',current='Current lesson',available='Available',locked='Locked',start='Start lesson',repeat='Review lesson',test='Take test',lessons='lessons',no_content='No published lessons yet',welcome='Welcome back',growth='Your learning journey',progress='Progress',badges='Badges',next='Your next step',open='Explore all levels',today='Today',more='More learning tools',journey='Your learning path',interface_language='Interface language',apply='Apply',theme_to_dark='Switch to dark mode',theme_to_light='Switch to light mode'),
 'ckb': dict(skip='بڕۆ بۆ ناوەڕۆک',play='فێربە و یاری بکە',grammar='ڕێزمان',vocab='وشەکان',word='وشەی ڕۆژ',mistakes='هەڵەکانم',friends='هاوڕێیان',rank='پلەبەندی',ai='مامۆستای زیرەک',profile='پرۆفایلم',settings='ڕێکخستنەکان',logout='دەرچوون',menu='مێنیو',level='ئاست',streak='زنجیرە',hearts='دڵەکان',coins='سکەکان',xp='XP',daily='ئامانجی ڕۆژانە',learn='بەردەوام بە',seasons='وەرزەکان',season='وەرز',change='گۆڕینی زمان',completed='تەواوبوو',current='وانەی ئێستا',available='بەردەستە',locked='داخراوە',start='دەستپێکردن',repeat='دووبارەکردنەوە',test='تاقیکردنەوە',lessons='وانە',no_content='هێشتا وانەی بڵاوکراوە نییە',welcome='بەخێربێیتەوە',growth='ڕێگای فێربوونت',progress='پێشکەوتن',badges='نیشانەکان',next='هەنگاوی داهاتوو',open='هەموو ئاستەکان ببینە',today='ئەمڕۆ',more='ئامرازەکانی تر',journey='ڕێگای فێربوونت',interface_language='زمانی ڕووکاری وێبسایت',apply='جێبەجێکردن',theme_to_dark='گۆڕین بۆ دۆخی تاریک',theme_to_light='گۆڕین بۆ دۆخی ڕووناک'),
 'ar': dict(skip='انتقل إلى المحتوى',play='تعلّم والعب',grammar='القواعد',vocab='المفردات',word='كلمة اليوم',mistakes='أخطائي',friends='الأصدقاء',rank='المتصدرون',ai='المعلم الذكي',profile='ملفي الشخصي',settings='الإعدادات',logout='تسجيل الخروج',menu='القائمة',level='المستوى',streak='السلسلة',hearts='القلوب',coins='العملات',xp='XP',daily='الهدف اليومي',learn='متابعة التعلم',seasons='المواسم',season='موسم',change='تغيير اللغة',completed='مكتمل',current='الدرس الحالي',available='متاح',locked='مغلق',start='بدء الدرس',repeat='مراجعة الدرس',test='ابدأ الاختبار',lessons='دروس',no_content='لا توجد دروس منشورة بعد',welcome='مرحباً بعودتك',growth='رحلتك التعليمية',progress='التقدم',badges='الشارات',next='خطوتك التالية',open='عرض جميع المستويات',today='اليوم',more='أدوات تعلم أخرى',journey='مسارك التعليمي',interface_language='لغة الواجهة',apply='تطبيق',theme_to_dark='التبديل إلى الوضع الداكن',theme_to_light='التبديل إلى الوضع الفاتح'),
}

def seasons_for(route, lang="en"):
    """Separate presentation seasons from CEFR. Never alter item.state/game_url."""
    stage_list = route.get('stages', [])
    level_ids = [stage['level'].pk for stage in stage_list]
    published = list(LearningSeason.objects.filter(level_id__in=level_ids, published=True).order_by('level_id','order','pk'))
    seasons_by_level = {}
    for season in published:
        seasons_by_level.setdefault(season.level_id, []).append(season)
    unit_ids = [item['unit'].pk for stage in stage_list for item in stage['items']]
    assignments = dict(Unit.objects.filter(pk__in=unit_ids).values_list('pk','season_id'))
    groups = []
    for stage in stage_list:
        level = stage['level']
        seasons = seasons_by_level.get(level.pk, [])
        real_season_ids = {s.pk for s in seasons}
        mapping = OrderedDict((s.pk,[]) for s in seasons)
        mapping[None]=[]
        for item in stage['items']:
            sid = assignments.get(item['unit'].pk)
            mapping[sid if sid in real_season_ids else None].append(item)
        for season in seasons:
            items = mapping[season.pk]
            if items:
                groups.append(_entry(stage, items, season.title, season.description, season.theme, f's{s.pk}'))
        if mapping[None] or not seasons:
            groups.append(_entry(stage, mapping[None], stage['chapter_title'], level.description, 'coast', f'l{level.pk}'))
    season_access = route.get('season_access', {})
    for index, group in enumerate(groups):
        # Unassigned CEFR groups get distinct presentation themes; curated
        # LearningSeason themes remain exactly as their managers published them.
        group['visual_theme'] = group['theme'] if group['anchor'].startswith('s') else ('coast', 'grove', 'dawn', 'sky')[index % 4]
        group['path_nodes'] = build_path_nodes(group['items'], lang)
        group['display_title'] = unit_title(group['title'], lang)
        group['index'] = index + 1
        season_id = int(group['anchor'][1:]) if group['anchor'].startswith('s') else None
        access = season_access.get(season_id, {}) if season_id else {}
        group['season_locked'] = bool(access) and not access['open']
        group['season_complete'] = (access.get('complete', False) if access else
            bool(group['items']) and all(item['state'] == 'done' for item in group['items']))
        group['prev_anchor'] = f"season-{groups[index-1]['anchor']}" if index else ''
        group['next_anchor'] = f"season-{groups[index+1]['anchor']}" if index+1 < len(groups) else ''
    # Focus on the actual current step, or the earliest unfinished accessible
    # season; when the course is complete, show its last accessible season.
    focus = next((g for g in groups if g['current'] and not g['season_locked']), None)
    if focus is None:
        focus = next((g for g in groups if not g['season_locked'] and not g['season_complete']), None)
    if focus is None:
        focus = next((g for g in reversed(groups) if not g['season_locked']), None)
    if focus is None and groups:
        focus = groups[0]
    for group in groups:
        group['focused'] = group is focus
    return groups

def _entry(stage, items, title, description, theme, key):
    total = sum(max(0, item['total']) for item in items)
    done = sum(max(0, item['done']) for item in items)
    return dict(anchor=key, title=title, description=description, theme=theme,
        level=stage['level'], items=items, done=done, total=total,
        percent=round(done*100/total) if total else 0,
        current=any(x.get('is_current') for x in items),
        planned=not bool(items), stage=stage)

def student_shell_context(request):
    """Minimal read-only context for secondary pages using the same student shell.

    Unlike the learning-path context this does not load seasons, lesson progress,
    friends or rewards just to display shared navigation.
    """
    profile = request.user.learning_profile
    lang = profile.ui_language if profile.ui_language in COPY else 'en'
    return {
        'R27': COPY[lang], 'R53': R53_LABELS[lang],
        'R53_COURSE_NAME': course_name(profile.preferred_language, lang),
        'R27_LANG': lang,
    }


def student_context(request, route, today_earned, daily_target):
    profile = request.user.learning_profile
    xp = int(profile.xp)
    daily_target=max(1,int(daily_target))
    lang = profile.ui_language if profile.ui_language in COPY else 'en'
    seasons = seasons_for(route, lang)
    # Use only first-party flags actually present in the shipped static assets.
    # New courses without a registered flag render the globe fallback instead
    # of a guessed or mismatched national flag.
    language = route.get('language')
    course_code = getattr(language, 'code', None)
    flags = {'nl', 'en', 'de', 'fr'}
    course_flag = f'academy/flags/{course_code}.svg' if course_code in flags else ''
    days_label = {'nl': 'dagen', 'en': 'days', 'ckb': 'ڕۆژ', 'kmr':'ڕۆژ', 'ku':'roj', 'uk':'днів', 'fr':'jours', 'ar': 'أيام'}[lang]
    pending_note = next((item['pending_note']
                         for stage in route.get('stages', []) for item in stage.get('items', [])
                         if item.get('pending_note')), '')
    return dict(R27=COPY[lang], R53=R53_LABELS[lang], R27_SEASONS=seasons,
        R67_PENDING_NOTICE=pending_note,
        R53_HAS_CURRENT_SEASON=any(season['focused'] for season in seasons),
        R53_TOTAL=route.get('total_lessons', 0), R53_DONE=route.get('done_lessons', 0),
        R53_PERCENT=route.get('progress_percent', 0),
        R53_COURSE_NAME=course_name(route.get('language'), lang),
        R54_COURSE_FLAG=course_flag, R54_DAYS_LABEL=days_label,
        R53_NEXT_TITLE=unit_title(route.get('next_title') or '', lang),
        R27_XP_PERCENT=round((xp%200)*100/200), R27_XP_REMAINING=200-xp%200,
        R27_LEVEL=learning_level(xp), R27_DAILY_PERCENT=min(100,round(today_earned*100/daily_target)),
        R27_DAILY_XP=today_earned, R27_DAILY_TARGET=daily_target,
        R27_BADGES=BadgeAward.objects.filter(user=request.user, revoked_at__isnull=True).count(),
        R27_FRIENDS=Friendship.objects.filter(status='accepted').filter(
            Q(from_user=request.user)|Q(to_user=request.user)).count(),
        R27_LANG=lang)


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'rozh2027', ['COPY'])

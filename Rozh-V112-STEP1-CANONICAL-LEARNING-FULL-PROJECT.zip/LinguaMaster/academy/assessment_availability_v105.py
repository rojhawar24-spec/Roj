"""Shared published assessment inventory and readiness for learner navigation.

Required tests and playable tests are distinct: invalid authored questions
must not turn a required assessment into an optional one.
"""
from .assessment_policy_v103 import ASSESSMENT_KINDS, assessment_ready


def assessment_candidates(*, unit=None, level=None, language_id=None):
    from .models import Exercise
    qs = Exercise.objects.filter(lesson__published=True,
        lesson__unit__published=True, lesson__unit__level__language__is_published=True,
        kind__in=ASSESSMENT_KINDS)
    if unit is not None:
        qs = qs.filter(lesson__unit=unit)
    if level is not None:
        qs = qs.filter(lesson__unit__level=level)
    if language_id is not None:
        qs = qs.filter(lesson__unit__level__language_id=language_id)
    return qs


def ready_questions(*, unit=None, level=None, limit=12):
    if limit <= 0:
        return []
    selected = []
    for question in assessment_candidates(unit=unit, level=level).select_related(
            'lesson__unit__level__language').order_by('lesson__unit__order','id').iterator(chunk_size=100):
        if assessment_ready(question, question.lesson.unit.level.language.code):
            selected.append(question)
            if len(selected) >= limit:
                break
    return selected


def has_ready_assessment(*, unit=None, level=None):
    return bool(ready_questions(unit=unit, level=level, limit=1))


def unit_assessment_inventory(language_id):
    """One streamed query: (required IDs, playable IDs). No learner writes."""
    required, playable = set(), set()
    for question in assessment_candidates(language_id=language_id).select_related(
            'lesson__unit__level__language').order_by('lesson__unit_id','id').iterator(chunk_size=100):
        unit_id = question.lesson.unit_id
        required.add(unit_id)
        if unit_id not in playable and assessment_ready(question, question.lesson.unit.level.language.code):
            playable.add(unit_id)
    return required, playable

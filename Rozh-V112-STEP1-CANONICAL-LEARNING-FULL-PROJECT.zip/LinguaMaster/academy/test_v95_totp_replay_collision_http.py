"""V95 Django integration tests. NOT executed without installed Django.

Run only with config.settings_local_qa against a disposable database.
"""
from unittest.mock import patch
from django.contrib.auth import get_user_model
from django.db import transaction
from django.test import TestCase

from .auth_security import verify_totp_step
from .models import Profile

class CollidingTOTP:
    interval = 30
    def __init__(self, accepted):
        self.accepted = accepted
    def verify(self, code, for_time=None, valid_window=99):
        assert valid_window == 0
        return code == '654321' and int(for_time) // 30 in self.accepted

class MFAReplayCollisionDatabaseTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            'v95_test_learner', 'v95@example.invalid', 'Temporary-Test-Password-91!')
        self.profile = Profile.objects.get(user=self.user)
        self.profile.totp_secret = 'JBSWY3DPEHPK3PXP'
        self.profile.mfa_last_totp_step = 98
        self.profile.save(update_fields=['totp_secret','mfa_last_totp_step'])

    def attempt(self, now, accepted=(100,101), code='654321'):
        with patch('academy.auth_security.pyotp.TOTP',return_value=CollidingTOTP(accepted)):
            with patch('academy.mfa_enroll_step_v88.time.time',return_value=now):
                with transaction.atomic():
                    locked = Profile.objects.select_for_update().get(pk=self.profile.pk)
                    return verify_totp_step(locked, code)

    def test_collision_consumes_latest_real_database_step(self):
        self.assertTrue(self.attempt(3000))
        self.assertEqual(
            Profile.objects.get(pk=self.profile.pk).mfa_last_totp_step,101)

    def test_code_cannot_be_reused_after_clock_advances(self):
        self.assertTrue(self.attempt(3000))
        self.assertFalse(self.attempt(3030))
        self.assertEqual(
            Profile.objects.get(pk=self.profile.pk).mfa_last_totp_step,101)

    def test_invalid_token_does_not_mutate_database(self):
        self.assertFalse(self.attempt(3000,code='000000'))
        self.assertEqual(
            Profile.objects.get(pk=self.profile.pk).mfa_last_totp_step,98)

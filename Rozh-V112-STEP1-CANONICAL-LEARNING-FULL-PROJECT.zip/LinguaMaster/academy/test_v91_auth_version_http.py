"""V91 integration regressions; PENDING until real Django is available.

Only isolated config.settings_local_qa SQLite. These are NOT counted as PASS
by packaging and offline lint scripts.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .models import Profile
from .session_revocation_v91 import SESSION_STATE_VERSION_KEY


class SignedInSessionRevisionTests(TestCase):
    PASSWORD = 'V91-disposable-test-password-only!'

    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username='v91_learner', email='v91@example.invalid', password=self.PASSWORD
        )
        self.profile = Profile.objects.get(user=self.user)
        self.client.force_login(self.user)

    def test_signin_signal_binds_database_version(self):
        self.assertEqual(self.client.session.get(SESSION_STATE_VERSION_KEY),
                         self.profile.email_verification_version)

    def test_account_revision_bump_expires_session_even_if_account_is_eligible(self):
        self.profile.email_verification_version += 1
        self.profile.save(update_fields=['email_verification_version'])
        response = self.client.get(reverse('dashboard'))
        self.assertRedirects(response, reverse('login'), fetch_redirect_response=False)
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_block_and_unblock_without_intermediate_request_still_revoke(self):
        # Mirrors the exact monotonic revision changes made in manager_user_action.
        self.profile.suspended_at = timezone.now()
        self.profile.email_verification_version += 1
        self.profile.save(update_fields=['suspended_at', 'email_verification_version'])
        self.profile.suspended_at = None
        self.profile.email_verification_version += 1
        self.profile.save(update_fields=['suspended_at', 'email_verification_version'])
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 302)
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_old_session_missing_version_is_not_silently_upgraded(self):
        session = self.client.session
        session.pop(SESSION_STATE_VERSION_KEY, None)
        session.save()
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 302)
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_api_returns_401_after_account_revision(self):
        Profile.objects.filter(user=self.user).update(email_verification_version=8)
        response = self.client.get('/api/me/progress/')
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.json(), {'detail': 'Authentication required.'})
        self.assertEqual(response['Cache-Control'], 'no-store')
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_public_page_remains_accessible_after_revocation(self):
        Profile.objects.filter(user=self.user).update(email_verification_version=8)
        response = self.client.get(reverse('privacy'))
        self.assertEqual(response.status_code, 200)
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_fresh_login_after_revocation_works(self):
        Profile.objects.filter(user=self.user).update(email_verification_version=8)
        self.client.get(reverse('dashboard'))
        response = self.client.post(reverse('login'), {
            'email': self.user.email, 'password': self.PASSWORD,
        })
        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.client.session.get(SESSION_STATE_VERSION_KEY), 8)
        self.assertIn('_auth_user_id', self.client.session)

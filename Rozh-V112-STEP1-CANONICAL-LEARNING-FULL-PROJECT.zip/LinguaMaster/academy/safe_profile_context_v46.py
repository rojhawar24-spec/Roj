"""Fail-closed, read-only profile access for shared template context.

Legacy/migrated accounts may have a valid User row but no related Profile.
Context processors render on public pages too, and must never raise a 500 or
initialize private learning state for an ineligible account.

This helper is for *display only*. Views still enforce authorization themselves.
"""

def visible_learning_profile(user):
    if not getattr(user, 'is_authenticated', False) or not getattr(user, 'is_active', False):
        return None
    # The reverse OneToOne descriptor raises RelatedObjectDoesNotExist,
    # which is a subclass of AttributeError. getattr's default handles it.
    profile = getattr(user, 'learning_profile', None)
    if (profile is None or getattr(profile, 'suspended_at', None) is not None
            or getattr(profile, 'legacy_review_required', False)):
        return None
    return profile

"""V24 real-Django test cases: an Arena round never outlives course authorization.

Run only with isolated config.settings_local_qa via TEST-ROZH-STAP11.ps1.
These tests are NOT considered passed until Django is actually available.
"""
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse

from .app_features import arena_run_authorized
from .models import ArenaRun, Assessment, Exercise, Language, Lesson, Level, Profile, Unit, XPEvent, MistakeRecord


class ArenaCourseAuthorizationV24Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            username='v24_arena_learner', email='v24-arena@example.invalid',
            password='V24-Local-Test-Only-2026!')
        cls.other = get_user_model().objects.create_user(
            username='v24_arena_other', email='v24-other@example.invalid',
            password='V24-Other-Test-Only-2026!')
        cls.nl = Language.objects.create(code='nl', name='Dutch', slug='v24-nl', is_published=True)
        cls.en = Language.objects.create(code='en', name='English', slug='v24-en', is_published=True)
        cls.a0 = Level.objects.create(language=cls.nl, code='A0', order=0)
        cls.a1 = Level.objects.create(language=cls.nl, code='A1', order=1)
        cls.english_a0 = Level.objects.create(language=cls.en, code='A0', order=0)
        for level, prefix in ((cls.a0, 'a0'), (cls.a1, 'a1')):
            unit = Unit.objects.create(level=level, slug='v24-'+prefix,
                                       title='V24 '+prefix, summary='V24 QA',
                                       order=1, published=True)
            lesson = Lesson.objects.create(unit=unit, slug='v24-'+prefix,
                                           title='V24 '+prefix, skill='grammar',
                                           content='V24 QA', order=1, published=True)
            for i in range(3):
                Exercise.objects.create(lesson=lesson, kind='mcq',
                                        prompt='Choose correct '+str(i),
                                        options=['Yes', 'No'], answer='Yes',
                                        explanation='Correct', order=i)
        profile = cls.user.learning_profile
        profile.preferred_language = cls.nl
        profile.placement_completed = True
        profile.placement_level = 'A0'
        profile.onboarding_required = False
        profile.onboarding_completed = True
        profile.save(update_fields=['preferred_language', 'placement_completed',
                                    'placement_level', 'onboarding_required', 'onboarding_completed'])

    def setUp(self):
        cache.clear()
        self.client.force_login(self.user)

    def _profile(self, **fields):
        profile = Profile.objects.get(user=self.user)
        for key, value in fields.items():
            setattr(profile, key, value)
        profile.save(update_fields=list(fields))
        return profile

    def _start(self, level=None):
        level = level or self.a0
        response = self.client.post(reverse('arena_start'), {'level_id': level.pk})
        self.assertEqual(response.status_code, 302)
        return ArenaRun.objects.get(user=self.user, finished_at__isnull=True)

    def _answer(self, run):
        return self.client.post(reverse('arena_run', args=[run.pk]),
                                {f'q_{pk}': 'Yes' for pk in run.question_ids})

    def _no_award_or_mutation(self, run):
        run.refresh_from_db()
        self.assertIsNone(run.finished_at)
        self.assertEqual(run.earned_xp, 0)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='arena').count(), 0)
        self.assertEqual(MistakeRecord.objects.filter(user=self.user).count(), 0)

    def test_active_selected_course_can_finish_and_awards_once(self):
        run = self._start()
        self.assertEqual(self.client.get(reverse('arena_run', args=[run.pk])).status_code, 200)
        response = self._answer(run)
        self.assertEqual(response.status_code, 302)
        run.refresh_from_db()
        self.assertEqual((run.score, run.earned_xp), (100, 30))
        self._answer(run)
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='arena').count(), 1)

    def test_switch_course_revokes_old_round_get_and_post(self):
        run = self._start()
        changed = self.client.post(reverse('course_switch', args=['en']), {'start':'A0'})
        self.assertEqual(changed.status_code, 302)
        self.assertEqual(self.client.get(reverse('arena_run', args=[run.pk])).status_code, 403)
        self.assertEqual(self._answer(run).status_code, 403)
        self._no_award_or_mutation(run)

    def test_onboarding_revoked_after_start_denies_submission(self):
        run = self._start()
        self._profile(onboarding_required=True, onboarding_completed=False)
        self.assertEqual(self.client.get(reverse('arena_run', args=[run.pk])).status_code, 403)
        self.assertEqual(self._answer(run).status_code, 403)
        self._no_award_or_mutation(run)

    def test_placement_revoked_after_start_denies_submission(self):
        run = self._start()
        self._profile(placement_completed=False)
        self.assertEqual(self._answer(run).status_code, 403)
        self._no_award_or_mutation(run)

    def test_level_downgrade_revokes_higher_round(self):
        self._profile(placement_level='A1')
        run = self._start(self.a1)
        self._profile(placement_level='A0')
        self.assertEqual(self._answer(run).status_code, 403)
        self._no_award_or_mutation(run)

    def test_archived_course_revokes_existing_round(self):
        run = self._start()
        self.nl.is_published = False
        self.nl.save(update_fields=['is_published'])
        self.assertEqual(self._answer(run).status_code, 403)
        self._no_award_or_mutation(run)

    def test_withdrawn_question_denies_round_without_xp(self):
        run = self._start()
        Exercise.objects.filter(pk=run.question_ids[0]).delete()
        self.assertEqual(self._answer(run).status_code, 503)
        self._no_award_or_mutation(run)

    def test_result_history_remains_visible_after_switch(self):
        run = self._start()
        self.assertEqual(self._answer(run).status_code, 302)
        self.client.post(reverse('course_switch', args=['en']), {'start':'A0'})
        self.assertEqual(self.client.get(reverse('arena_result', args=[run.pk])).status_code, 200)

    def test_locked_profile_overrules_stale_cached_profile(self):
        run = self._start()
        # Deliberately fill the cache on the original User object before an
        # independent DB write simulates a course switch in another request.
        stale = self.user.learning_profile
        self.assertEqual(stale.preferred_language_id, self.nl.pk)
        Profile.objects.filter(user=self.user).update(preferred_language=self.en)
        locked = Profile.objects.get(user=self.user)
        self.assertFalse(arena_run_authorized(self.user, run, profile=locked))
        self._no_award_or_mutation(run)

    def test_another_user_cannot_access_round_or_result(self):
        run = self._start()
        self.client.force_login(self.other)
        self.assertEqual(self.client.get(reverse('arena_run', args=[run.pk])).status_code, 404)
        self.assertEqual(self.client.post(reverse('arena_run', args=[run.pk])).status_code, 404)
        self.assertEqual(self.client.get(reverse('arena_result', args=[run.pk])).status_code, 404)

    def test_other_course_cannot_be_started(self):
        self.assertEqual(self.client.post(reverse('arena_start'),
                                          {'level_id': self.english_a0.pk}).status_code, 404)
        self.assertFalse(ArenaRun.objects.filter(user=self.user).exists())

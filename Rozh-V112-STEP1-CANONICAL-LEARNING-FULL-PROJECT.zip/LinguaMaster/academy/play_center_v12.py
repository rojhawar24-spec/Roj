"""Optional mixed-game experience alongside the existing classic lessons."""
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render
from django.urls import reverse
from django.views.decorators.http import require_GET


COPY = {
    'nl': {'label':'Leer & Speel', 'title':'Speel een level. Leer echte taal.',
           'intro':'Kies een sectie en start een gevarieerde ronde. Je gewone lessen, grammatica en oefenruimte blijven apart beschikbaar.',
           'course':'Huidige leertaal', 'change':'Andere taal kiezen', 'section':'Sectie', 'level':'Level',
           'lessons':'lessen', 'ready':'Speel dit level', 'done':'Opnieuw spelen',
           'locked':'Eerst vorige level afronden', 'assessment':'Doe de unittoets',
           'back':'Naar alle lessen', 'practice':'Naar de oefenruimte',
           'progress':'Cursusvoortgang', 'empty':'Er zijn nog geen speelbare levels gepubliceerd.',
           'missing':'Selecteer eerst een gepubliceerde cursus.',
           'player_level':'Jouw XP-level', 'wallet':'Munten', 'season_gift':'Seizoenscadeau', 'reward_ready':'Je hebt de seizoentoets gehaald! Open je cadeau.', 'reward_claim':'Claim cadeau', 'reward_claimed':'Cadeau ontvangen', 'reward_locked':'Voltooi de levels en haal de seizoentoets om je cadeau te openen.', 'season_exam':'Doe de seizoentoets', 'earn':'Te verdienen', 
           'note':'XP en toegang worden op de server gecontroleerd.'},
    'en': {'label':'LEARN & PLAY', 'title':'Play a level. Learn real language.',
           'intro':'Choose a section and play a mixed challenge. Your ordinary lessons, grammar and practice space remain separate.',
           'course':'Current learning language', 'change':'Change language', 'section':'Section', 'level':'Level',
           'lessons':'lessons', 'ready':'Play this level', 'done':'Play again',
           'locked':'Finish the previous level first', 'assessment':'Take the unit check',
           'back':'All lessons', 'practice':'Practice hub',
           'progress':'Course progress', 'empty':'No playable levels have been published yet.',
           'missing':'Select a published course to begin.',
           'player_level':'Your XP level', 'wallet':'Coins', 'season_gift':'Season gift', 'reward_ready':'You passed the season test! Open your gift.', 'reward_claim':'Claim gift', 'reward_claimed':'Gift collected', 'reward_locked':'Finish the levels and pass the season test to open the gift.', 'season_exam':'Take season test', 'earn':'To earn', 
           'note':'XP and access are checked by the server.'},
    'ckb': {'label':'فێربە و یاری بکە', 'title':'یاری بکە، زمانی ڕاستەقینە فێربە.',
           'intro':'بەشێک هەڵبژێرە و چەند جۆر پرسیارێک یاری بکە. وانە و ڕێزمان و ڕاهێنانەکانت بە جیا ماونەتەوە.',
           'course':'زمانی فێربوونی ئێستا', 'change':'زمان بگۆڕە', 'section':'بەش', 'level':'ئاست',
           'lessons':'وانە', 'ready':'ئەم ئاستە یاری بکە', 'done':'دووبارە یاری بکە',
           'locked':'سەرەتا ئاستی پێشوو تەواو بکە', 'assessment':'تاقیکردنەوەی یەکە بکە',
           'back':'هەموو وانەکان', 'practice':'ڕاهێنان',
           'progress':'پێشکەوتنی کۆرس', 'empty':'هێشتا ئاستی یاریکردن بڵاو نەکراوەتەوە.',
           'missing':'سەرەتا کۆرسێکی بڵاوکراوە هەڵبژێرە.',
           'player_level':'ئاستی XP ـی تۆ', 'wallet':'سکە', 'season_gift':'دیاریی وەرز', 'reward_ready':'لە تاقیکردنەوەی وەرز دەرچوویت! دیارییەکەت بکەرەوە.', 'reward_claim':'وەرگرتنی دیاری', 'reward_claimed':'دیاری وەرگیرا', 'reward_locked':'ئاستەکان تەواو بکە و لە تاقیکردنەوەی وەرز دەرچۆ بۆ کردنەوەی دیاری.', 'season_exam':'تاقیکردنەوەی وەرز', 'earn':'دیاری', 
           'note':'XP و دەستگەیشتن لە سێرڤەرەوە پشکنین دەکرێن.'},
    'ar': {'label':'تعلّم والعب', 'title':'العب مستوى وتعلّم لغة حقيقية.',
           'intro':'اختر قسمًا واستمتع بأسئلة متنوعة. تبقى الدروس التقليدية والقواعد والتدريبات متاحة بشكل منفصل.',
           'course':'لغة التعلم الحالية', 'change':'تغيير اللغة', 'section':'القسم', 'level':'المستوى',
           'lessons':'دروس', 'ready':'العب هذا المستوى', 'done':'العب مجددًا',
           'locked':'أكمل المستوى السابق أولًا', 'assessment':'اختبار الوحدة',
           'back':'جميع الدروس', 'practice':'مساحة التدريب',
           'progress':'تقدم الدورة', 'empty':'لا توجد مستويات منشورة قابلة للعب بعد.',
           'missing':'اختر دورة منشورة أولًا.',
           'player_level':'مستوى XP الخاص بك', 'wallet':'العملات', 'season_gift':'هدية الموسم', 'reward_ready':'نجحت في اختبار الموسم! افتح هديتك.', 'reward_claim':'احصل على الهدية', 'reward_claimed':'تم استلام الهدية', 'reward_locked':'أكمل المستويات واجتز اختبار الموسم لفتح الهدية.', 'season_exam':'اختبار الموسم', 'earn':'المكافأة', 
           'note':'تُتحقَّق النقاط والصلاحيات على الخادم.'},
}


# Interface copy only. The entire journey, user progress and reward eligibility
# continue to be determined by the Django server and existing permission checks.
JOURNEY24_COPY = {
    'nl': {'eyebrow':'JOUW TAALAVONTUUR', 'headline':'Jouw weg. Jouw tempo.',
      'lead':'Ga verder waar je was, ontdek je volgende level en groei stap voor stap.',
      'continue':'Verder spelen', 'find_me':'Mijn volgende level', 'change':'Wissel van taal',
      'current':'Jij bent hier', 'done':'Afgerond', 'ready':'Klaar om te spelen',
      'locked':'Nog vergrendeld', 'planned':'Nog niet beschikbaar', 'chapter':'WERELD',
      'worlds':'Ontdek je werelden', 'worlds_note':'Volg het slingerende pad van links naar rechts. Elk level heeft een echte opdracht.',
      'course':'Mijn cursus', 'steps':'Levels', 'lesson_progress':'Lessen afgerond',
      'course_progress':'Totale voortgang', 'next_quest':'Jouw volgende avontuur',
      'up_next':'KLAAR VOOR DE VOLGENDE STAP', 'start_here':'Start hier',
      'unlock':'Rond eerst het vorige level af', 'coming':'Er staan nog geen gepubliceerde levels in deze wereld.',
      'keep_learning':'Ga verder met je avontuur', 'select_language':'Kies een taal om te beginnen',
      'legend':'Zo werkt het pad', 'challenge':'Leveltoets', 'more_lessons':'Bekijk de lessen',
      'map_label':'Leerroute met levels', 'level_done':'Level voltooid', 'focus':'Je eerstvolgende stap',
      'extra':'Andere manieren om te oefenen', 'back_top':'Terug naar boven'},
    'en': {'eyebrow':'YOUR LANGUAGE ADVENTURE', 'headline':'Your path. Your pace.',
      'lead':'Pick up where you left off, discover your next level, and grow step by step.',
      'continue':'Continue playing', 'find_me':'My next level', 'change':'Change language',
      'current':'You are here', 'done':'Completed', 'ready':'Ready to play',
      'locked':'Still locked', 'planned':'Not available yet', 'chapter':'WORLD',
      'worlds':'Explore your worlds', 'worlds_note':'Follow the winding path from side to side. Every level leads to a real learning activity.',
      'course':'My course', 'steps':'Levels', 'lesson_progress':'Lessons completed',
      'course_progress':'Overall progress', 'next_quest':'Your next adventure',
      'up_next':'READY FOR YOUR NEXT STEP', 'start_here':'Start here',
      'unlock':'Finish the previous level to unlock', 'coming':'There are no published levels in this world yet.',
      'keep_learning':'Continue your adventure', 'select_language':'Choose a language to begin',
      'legend':'How the path works', 'challenge':'Level test', 'more_lessons':'See the lessons',
      'map_label':'Learning route with levels', 'level_done':'Level complete', 'focus':'Your next step',
      'extra':'Other ways to practise', 'back_top':'Back to top'},
    'ckb': {'eyebrow':'گەشتی فێربوونی زمانی تۆ', 'headline':'ڕێگای تۆ، بە خێرایی خۆت.',
      'lead':'لەو شوێنەی ماویتەوە بەردەوام بە، ئاستی دواتر بدۆزەوە و هەنگاو بە هەنگاو پێش بکەوە.',
      'continue':'بەردەوامبوون لە یاری', 'find_me':'ئاستی دواترم', 'change':'گۆڕینی زمان',
      'current':'تۆ لێرەیت', 'done':'تەواوبوو', 'ready':'ئامادەی یاریکردن',
      'locked':'هێشتا قوفڵە', 'planned':'هێشتا بەردەست نییە', 'chapter':'جیهان',
      'worlds':'جیهانەکانت بدۆزەوە', 'worlds_note':'بەدواداچوونی ڕێگای پێچاوپێچ بکە. هەر ئاستێک ڕاهێنانێکی ڕاستەقینەی هەیە.',
      'course':'کۆرسی من', 'steps':'ئاستەکان', 'lesson_progress':'وانە تەواوبووەکان',
      'course_progress':'پێشکەوتنی گشتی', 'next_quest':'گەشتی دواترت',
      'up_next':'ئامادەی هەنگاوی دواتر', 'start_here':'لێرە دەست پێ بکە',
      'unlock':'سەرەتا ئاستی پێشوو تەواو بکە', 'coming':'هێشتا هیچ ئاستێکی بڵاوکراوە لەم جیهانەدا نییە.',
      'keep_learning':'بەردەوام بە لە گەشتەکەت', 'select_language':'زمانێک هەڵبژێرە بۆ دەستپێکردن',
      'legend':'ڕێگاکە چۆن کار دەکات', 'challenge':'تاقیکردنەوەی ئاست', 'more_lessons':'بینینی وانەکان',
      'map_label':'ڕێڕەوی فێربوون و ئاستەکان', 'level_done':'ئاست تەواوبوو', 'focus':'هەنگاوی دواترت',
      'extra':'ڕێگاکانی تری ڕاهێنان', 'back_top':'گەڕانەوە بۆ سەرەوە'},
    'ar': {'eyebrow':'رحلتك لتعلم اللغة', 'headline':'طريقك. وبالسرعة التي تناسبك.',
      'lead':'تابع من حيث توقفت، واكتشف مستواك التالي وتقدم خطوة بخطوة.',
      'continue':'تابع اللعب', 'find_me':'مستواي التالي', 'change':'تغيير اللغة',
      'current':'أنت هنا', 'done':'مكتمل', 'ready':'جاهز للعب',
      'locked':'مغلق حاليًا', 'planned':'غير متاح بعد', 'chapter':'العالم',
      'worlds':'استكشف عوالمك', 'worlds_note':'اتبع الطريق المتعرج من جانب إلى آخر، فكل مستوى يقدم نشاطًا تعليميًا حقيقيًا.',
      'course':'دورتي', 'steps':'المستويات', 'lesson_progress':'دروس مكتملة',
      'course_progress':'التقدم الكلي', 'next_quest':'مغامرتك التالية',
      'up_next':'جاهز للخطوة التالية', 'start_here':'ابدأ من هنا',
      'unlock':'أكمل المستوى السابق لفتحه', 'coming':'لا توجد مستويات منشورة في هذا العالم بعد.',
      'keep_learning':'تابع مغامرتك', 'select_language':'اختر لغة للبدء',
      'legend':'كيف يعمل المسار', 'challenge':'اختبار المستوى', 'more_lessons':'عرض الدروس',
      'map_label':'مسار التعلم مع المستويات', 'level_done':'اكتمل المستوى', 'focus':'خطوتك التالية',
      'extra':'طرق أخرى للتدرب', 'back_top':'العودة إلى الأعلى'},
}


@login_required
@require_GET
def play_hub(request):
    profile = request.user.learning_profile
    # Completing placement is not the same as completing the four-step
    # onboarding. Legacy/partially migrated accounts can have placement=True
    # while onboarding is still required: never skip their saved draft.
    if profile.onboarding_required and not profile.onboarding_completed:
        return redirect('onboarding')
    if not profile.placement_completed:
        return redirect('placement')
    # Import at request time to avoid a view-module import cycle.
    from .views import _learning_path_data
    # Without a current published course, do not present games that play_level
    # would immediately reject (the generic course path has a fallback course).
    if not profile.preferred_language_id or not profile.preferred_language.is_published:
        route = {'language':None, 'stages':[], 'progress_percent':0}
    else:
        route = _learning_path_data(request.user)
    for stage in route['stages']:
        for item in stage['items']:
            if item['state'] == 'locked':
                item['game_url'] = None
            elif item['state'] == 'test':
                item['game_url'] = reverse('assessment_unit', args=[item['unit'].pk])
            elif item['state'] == 'active':
                # Follow the authored lesson sequence, not the old mixed-unit entry.
                item['game_url'] = item['url']
            elif item['state'] == 'done':
                # A finished unit opens its first real published lesson for review.
                # Keep the original /journey/levels/ URL available for bookmarks.
                authored_first = (item['unit'].lessons.filter(published=True)
                                  .order_by('order', 'pk').first())
                item['game_url'] = item.get('url') if authored_first else None
            else:
                # Pending audio/editorial review is NOT a playable next lesson.
                item['game_url'] = None
    # V63: the primary Learn & Play continue action opens the next real
    # authored lesson directly (or its unlocked unit test), rather than
    # the legacy mixed-unit game. Keep old mixed URLs for compatibility.
    route['next_url'] = next((item['url']
        for stage in route['stages'] for item in stage['items']
        if item.get('is_current') and item['state'] in ('active', 'test') and item.get('url')), None)
    # Batch season status queries, avoiding N+1 per course and keeping GET read-only.
    from .models import Assessment, SeasonGift, SeasonGiftClaim
    from .services import learning_level, level_units_passed
    from .season_gifts_v14 import DEFAULT_XP, DEFAULT_COINS
    ids = [stage['level'].pk for stage in route['stages']]
    passed = set(Assessment.objects.filter(user=request.user, kind='level',
                 level_id__in=ids, passed=True).values_list('level_id', flat=True))
    claimed = set(SeasonGiftClaim.objects.filter(user=request.user,
                  level_id__in=ids).values_list('level_id', flat=True))
    gifts = {gift.level_id: gift for gift in SeasonGift.objects.filter(level_id__in=ids)}
    for stage in route['stages']:
        level = stage['level']
        gift = gifts.get(level.pk)
        stage['progress_percent'] = round(100 * stage['done'] / stage['total']) if stage['total'] else 0
        stage['gift_enabled'] = gift.enabled if gift else True
        stage['gift_icon'] = gift.emoji if gift else '🎁'
        stage['gift_xp'] = gift.bonus_xp if gift else DEFAULT_XP
        stage['gift_coins'] = gift.bonus_coins if gift else DEFAULT_COINS
        stage['gift_claimed'] = level.pk in claimed
        stage['gift_ready'] = level.pk in passed and stage['gift_enabled'] and not stage['gift_claimed']
        stage['exam_ready'] = bool(stage.get('exam_available') and level.pk not in passed and
                                   level_units_passed(request.user, level))
        stage['exam_url'] = reverse('assessment_level', args=[level.pk])
    # A single real resume target; no placeholder progress and no extra database writes.
    next_item = next((item for stage in route['stages'] for item in stage['items']
                      if item.get('is_current') and item['state'] != 'locked'), None)
    for stage in route['stages']:
        stage['is_current'] = any(item.get('is_current') for item in stage['items'])
        stage['passed_units'] = sum(1 for item in stage['items'] if item['state'] == 'done')
    lang = profile.ui_language if profile.ui_language in COPY else 'en' 
    # Nova v18 shows real first-party data only. Privacy controls on leaderboards
    # still apply; unpublished course content must never be previewed here.
    from .design_v18 import for_request as nova_labels
    from .models import Profile, Vocabulary, LessonProgress, MistakeRecord, Language
    from .services import daily_xp, learning_day_bounds, user_localdate
    from .daily_calendar_v73 import daily_for_learner, published_daily_word
    today = user_localdate(request.user)
    earned = daily_xp(request.user)
    daily_target = max(1, profile.daily_goal_xp)
    # Match the same per-student calendar day used by daily_xp. Date casts
    # are based on the server timezone and can miscount near midnight/DST.
    # Withdrawn content and another course never inflate today's quest.
    day_start, next_day_start = learning_day_bounds(request.user, today)
    completed_today = LessonProgress.objects.filter(
        user=request.user, lesson__published=True, lesson__unit__published=True,
        lesson__unit__level__language=route['language'],
        lesson__unit__level__language__is_published=True,
        completed_at__gte=day_start, completed_at__lt=next_day_start,
    ).count()
    mistakes_due = MistakeRecord.objects.filter(user=request.user, corrected_at__isnull=True).count()
    word = (published_daily_word(daily_for_learner(request.user, route['language'], today))
            if route['language'] is not None else None)
    leaders = Profile.objects.filter(leaderboard_opt_in=True,
                     user__is_active=True).select_related('user').order_by('-xp', 'user_id')[:3]
    from .rozh2027 import student_context
    r27 = student_context(request, route, earned, daily_target)
    from .solar_atlas_step2 import decorate, for_language as solar_labels
    decorate(r27['R27_SEASONS'])  # presentation-only; never change access or XP
    r27['SOLAR'] = solar_labels(lang)
    from .hearts import snapshot
    from .heart_spelling_v72 import labels_for, _published_words
    r27['HEART_V72_HAS_WORDS'] = bool(profile.preferred_language_id and
        profile.preferred_language.is_published and len(_published_words(profile.preferred_language_id)) >= 5)
    r27['HEART_V72_STATE'] = snapshot(request.user)
    r27['HEART_V72_TEXT'] = labels_for(request.user)
    return render(request, 'academy/rozh2027_play.html', {**r27, 
        'route':route, 'PLAY':COPY[lang], 'J24':JOURNEY24_COPY[lang],
        'J24_CURRENT':next_item, 'noindex':True,
        'xp_level':learning_level(profile.xp), 'coins':profile.coins,
        'NOVA':nova_labels(request), 'NOVA_EARNED':earned,
        'NOVA_TARGET':daily_target, 'NOVA_GOAL_PERCENT':min(100, round(earned * 100 / daily_target)),
        'NOVA_LESSONS_TODAY':completed_today, 'NOVA_LESSON_PERCENT':min(100,completed_today*50),
        'NOVA_MISTAKES':mistakes_due, 'NOVA_WORD':word,
        'NOVA_LEADERS':leaders, 'NOVA_LANGUAGES':Language.objects.filter(is_published=True).order_by('name')[:4],
        'seo_title':'Learn & Play | Rozh',
    })



# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'play_center_v12', ['COPY', 'JOURNEY24_COPY'])

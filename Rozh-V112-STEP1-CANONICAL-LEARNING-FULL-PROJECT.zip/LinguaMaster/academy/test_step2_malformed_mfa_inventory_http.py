"""True Django HTTP tests for corrupt MFA state, to run in isolated CI.

Must not be marked PASS without actual Django and disposable database.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse
from .models import Profile

@override_settings(REQUIRE_EMAIL_VERIFICATION=False)
class MalformedMFAInventoryHTTP(TestCase):
    PASSWORD='Step2-QA-InvalidInventory-Password!'
    def setUp(self):
        self.user=get_user_model().objects.create_user(
            username='step2_bad_factors',email='step2_bad_factors@example.invalid',
            password=self.PASSWORD)
        self.profile=Profile.objects.get(user=self.user)
        self.profile.totp_secret='JBSWY3DPEHPK3PXP'
        self.profile.mfa_recovery_hashes='corrupt-recovery-list'
        self.profile.save(update_fields=['totp_secret','mfa_recovery_hashes'])

    def test_password_correct_corrupt_factors_denies_without_http500(self):
        response=self.client.post(reverse('login'),{
            'email':self.user.email,'password':self.PASSWORD})
        self.assertEqual(response.status_code,403)
        self.assertNotIn('_auth_user_id',self.client.session)
        self.assertNotIn('pending_mfa_user_id',self.client.session)

    def test_authenticated_unverified_session_does_not_bypass_corruption(self):
        self.client.force_login(self.user)
        session=self.client.session
        session['mfa_verified_id']=None
        session.save()
        response=self.client.get(reverse('login'))
        self.assertEqual(response.status_code,302)
        self.assertEqual(response.url,reverse('login'))
        self.assertNotIn('_auth_user_id',self.client.session)

    def test_mfa_setup_does_not_http500_or_bypass_corruption(self):
        self.client.force_login(self.user)
        session=self.client.session
        session['mfa_verified_id']=None
        session.save()
        response=self.client.get(reverse('mfa_setup'))
        self.assertEqual(response.status_code,302)
        self.assertEqual(response.url,reverse('login'))
        self.assertNotIn('_auth_user_id',self.client.session)

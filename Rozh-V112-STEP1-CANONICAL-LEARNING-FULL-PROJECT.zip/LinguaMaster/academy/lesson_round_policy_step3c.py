"""One-way terminal state for a *finished* authored lesson round.

A failed authored round is finished just as a passed one is: retry must open a
fresh page/round. Historical direct-POST MCQ/short integrations deliberately
retain their previous failure retry behavior until those clients migrate.
This helper does not award XP, grade, query the DB, or generate new tokens.
"""


def seal_finished_round(session, lesson_pk, round_key, score):
    """Mark a completed question batch terminal (pass OR fail), in session.

    Call only after all questions have been graded, without heart depletion,
    and after DB writes have succeeded. The caller owns the transaction.
    """
    if not isinstance(round_key, str) or len(round_key) != 32 or any(
        c not in '0123456789abcdef' for c in round_key
    ):
        raise ValueError('A issued hexadecimal round key is required.')
    if type(score) is not int or not 0 <= score <= 100:
        raise ValueError('An integer score of 0–100 is required.')
    session[f'lesson_completed_round_{lesson_pk}'] = {'key': round_key, 'score': score}


def _round_channel_key(lesson_pk):
    return f'lesson_round_channel_{lesson_pk}'


def round_channel_conflict(session, lesson_pk, round_key, channel):
    """A round cannot mix the complete SSR batch with per-question AJAX.

    One channel may submit multiple times for legacy retries, but using the
    other channel would regrade earlier answers and corrupt heart/mistake
    accounting. A newly issued GET round has a different key.
    """
    if channel not in ('ssr', 'ajax'):
        raise ValueError('Unknown lesson grading channel.')
    existing = session.get(_round_channel_key(lesson_pk))
    return (isinstance(existing, dict) and existing.get('key') == round_key
            and existing.get('channel') in ('ssr', 'ajax')
            and existing['channel'] != channel)


def record_round_channel(session, lesson_pk, round_key, channel):
    """Record a graded submission only after the DB-backed result succeeds.

    Do not record rejected/depleted-heart submissions, because those do not
    have a scored result. The caller saves the session normally.
    """
    if not isinstance(round_key, str) or len(round_key) != 32 or any(
            digit not in '0123456789abcdef' for digit in round_key):
        raise ValueError('A server-issued round key is required.')
    if channel not in ('ssr', 'ajax') or round_channel_conflict(
            session, lesson_pk, round_key, channel):
        raise ValueError('Cannot grade the same round in two channels.')
    session[_round_channel_key(lesson_pk)] = {'key': round_key, 'channel': channel}

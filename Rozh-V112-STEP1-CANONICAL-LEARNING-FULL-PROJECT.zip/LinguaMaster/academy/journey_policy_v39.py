"""Fail-closed policy for both GET and POST of the mixed Journey player.

Keep the authorization predicate dependency-free so it is tested even when
Django is unavailable. This does not replace database profile locking or the
unit prerequisite checks in the view.
"""


def journey_round_allowed(profile, unit, *, user_active):
    """Reject old-course rounds and revoked accounts before side effects."""
    if not user_active or profile is None or unit is None:
        return False
    if getattr(profile, 'suspended_at', None) is not None:
        return False
    if getattr(profile, 'legacy_review_required', False):
        return False
    if getattr(profile, 'onboarding_required', False) and not getattr(profile, 'onboarding_completed', False):
        return False
    if not getattr(profile, 'placement_completed', False):
        return False
    level = getattr(unit, 'level', None)
    language = getattr(level, 'language', None)
    return bool(
        getattr(profile, 'preferred_language_id', None) is not None
        and getattr(profile, 'preferred_language_id', None) == getattr(level, 'language_id', None)
        and getattr(unit, 'published', False)
        and getattr(language, 'is_published', False)
    )

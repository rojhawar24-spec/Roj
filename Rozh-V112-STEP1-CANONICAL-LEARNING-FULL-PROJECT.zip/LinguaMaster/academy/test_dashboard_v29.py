"""V29 dashboard integration coverage, run with `python manage.py test academy.test_dashboard_v29`.

These tests execute Django and its test database. They do not run in source-only QA.
"""
from html.parser import HTMLParser

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Language, Lesson, LessonProgress, Level, PlatformSettings, Unit, XPEvent


class _LockedUnitLinkParser(HTMLParser):
    """Count links only inside displayed locked checkpoint list items."""
    def __init__(self):
        super().__init__()
        self.inside_locked_unit = False
        self.locked_items = 0
        self.links = 0

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'li':
            self.inside_locked_unit = 'lm29-state-locked' in attrs.get('class', '').split()
            if self.inside_locked_unit:
                self.locked_items += 1
        if tag == 'a' and self.inside_locked_unit:
            self.links += 1

    def handle_endtag(self, tag):
        if tag == 'li':
            self.inside_locked_unit = False


class DashboardV29IntegrationTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            username='dashboard29', password='StrongPassword!2026', email='dashboard29@example.org'
        )
        cls.language = Language.objects.create(
            name='Dutch', code='nl', slug='dashboard29-dutch',
            description='Dutch course', is_published=True,
        )
        level = Level.objects.create(language=cls.language, code='A0', order=0, description='Starter')
        cls.open_unit = Unit.objects.create(
            level=level, slug='dashboard29-open', title='Say hello',
            summary='Your first Dutch words', order=1, published=True,
        )
        cls.lesson = Lesson.objects.create(
            unit=cls.open_unit, slug='dashboard29-greetings', title='Greetings',
            skill='reading', content='Dag!', published=True,
        )
        cls.locked_unit = Unit.objects.create(
            level=level, slug='dashboard29-locked', title='Next steps',
            summary='A later unit', order=2, published=True,
        )
        cls.locked_unit.prerequisites.add(cls.open_unit)
        Lesson.objects.create(
            unit=cls.locked_unit, slug='dashboard29-second-lesson',
            title='Second lesson', skill='reading', content='Tot ziens!', published=True,
        )
        profile = cls.user.learning_profile
        profile.onboarding_completed = True
        profile.placement_completed = True
        profile.preferred_language = cls.language
        profile.ui_language = 'nl'
        profile.save()

    def test_anonymous_dashboard_is_private(self):
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 302)
        self.assertIn('/login/', response['Location'])

    def test_dashboard_shows_real_next_lesson_and_no_awards_on_get(self):
        self.client.force_login(self.user)
        before = XPEvent.objects.filter(user=self.user).count()
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'lm29-dashboard-shell')
        self.assertContains(response, 'Say hello')
        self.assertContains(response, reverse('lesson', args=[self.lesson.pk]))
        self.assertEqual(XPEvent.objects.filter(user=self.user).count(), before)
        self.assertFalse(LessonProgress.objects.filter(user=self.user).exists())

    def test_locked_checkpoint_has_no_clickable_child(self):
        self.client.force_login(self.user)
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 200)
        parser = _LockedUnitLinkParser()
        parser.feed(response.content.decode('utf-8'))
        self.assertGreater(parser.locked_items, 0)
        self.assertEqual(parser.links, 0)
        self.assertContains(response, 'lm29-route-locked')

    def test_ai_hidden_when_disabled_and_sorani_labels_available(self):
        config = PlatformSettings.load()
        config.ai_enabled = False
        config.save(update_fields=['ai_enabled'])
        profile = self.user.learning_profile
        profile.ui_language = 'ckb'
        profile.save(update_fields=['ui_language'])
        self.client.force_login(self.user)
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'بەخێربێیتەوە')
        self.assertNotContains(response, 'class="lm29-tile lm29-tile-ai"')

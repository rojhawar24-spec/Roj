"""Database integration checks; run in isolated Django QA only."""
from io import StringIO
from unittest.mock import patch
from django.core.management import call_command
from django.test import TestCase
from academy.models import Lesson, Exercise
from academy.dutch_listening_v111 import listening_quiz


class DutchListeningSeedTests(TestCase):
    @patch('academy.audio_v78.approved_audio_url', return_value='')
    def test_seed_uses_all_authored_questions_without_publishing_unapproved_audio(self, _):
        call_command('seed_curriculum', stdout=StringIO())
        lessons = Lesson.objects.filter(unit__level__language__code='nl', skill='listening')
        self.assertEqual(lessons.count(), 18)
        self.assertFalse(lessons.filter(published=True).exists())
        for lesson in lessons:
            q = lesson.exercises.get(order=1)
            expected = listening_quiz(lesson.audio_text)
            for field, value in expected.items():
                self.assertEqual(getattr(q, field), value)

    @patch('academy.audio_v78.approved_audio_url', return_value='')
    def test_reseed_never_overwrites_editor_question(self, _):
        call_command('seed_curriculum', stdout=StringIO())
        q = Exercise.objects.filter(lesson__unit__level__language__code='nl', lesson__skill='listening').first()
        q.prompt = 'Manager-edited question'
        q.save(update_fields=['prompt'])
        call_command('seed_curriculum', stdout=StringIO())
        q.refresh_from_db()
        self.assertEqual(q.prompt, 'Manager-edited question')

"""Django integration regressions for independent suspension and verification.

All cases use Django's isolated TEST database. No production accounts modified.
"""
from io import StringIO
from unittest.mock import patch
from django.contrib.auth import get_user_model
from academy.email_verification_tokens import email_verification_token_generator
from django.core import mail
from django.core.cache import cache
from django.core.management import call_command
from django.core.management.base import CommandError
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from academy.models import Profile


@override_settings(MAILERS={'default':{'BACKEND':'django.core.mail.backends.locmem.EmailBackend'}})
class SuspensionVerificationTests(TestCase):
    def setUp(self):
        cache.clear()
        User = get_user_model()
        self.owner = User.objects.create_superuser('owner-v35', 'owner-v35@example.test', 'UniquePass!Owner2026')
        self.owner_profile = self.owner.learning_profile
        self.owner_profile.email_verified_at = timezone.now()
        self.owner_profile.totp_secret = 'JBSWY3DPEHPK3PXP'
        self.owner_profile.save(update_fields=['email_verified_at','totp_secret'])
        self.learner = User.objects.create_user('learner-v35', 'learner-v35@example.test', 'UniquePass!Learner2026')
        self.profile = self.learner.learning_profile
        self.profile.email_verified_at = timezone.now()
        self.profile.save(update_fields=['email_verified_at'])

    def manager(self, action):
        self.client.force_login(self.owner)
        session = self.client.session
        session['mfa_verified_id'] = self.owner.pk
        session.save()
        return self.client.post(reverse('manager_user_action', args=[self.learner.pk, action]))

    def token_url(self):
        uid = urlsafe_base64_encode(force_bytes(self.learner.pk))
        return reverse('verify_email', args=[uid, email_verification_token_generator.make_token(self.learner)])

    def test_blocked_verified_user_cannot_request_or_consume_email_link(self):
        self.assertEqual(self.manager('block').status_code, 302)
        self.learner.refresh_from_db(); self.profile.refresh_from_db()
        self.assertFalse(self.learner.is_active)
        self.assertIsNotNone(self.profile.suspended_at)
        self.client.logout()
        mail.outbox.clear()
        self.assertEqual(self.client.post(reverse('resend_verification'), {'email': self.learner.email}).status_code, 302)
        self.assertEqual(len(mail.outbox), 0)
        link = self.token_url()
        self.assertEqual(self.client.get(link).status_code, 302)
        self.assertEqual(self.client.post(link).status_code, 302)
        self.learner.refresh_from_db()
        self.assertFalse(self.learner.is_active)

    def test_token_issued_before_block_does_not_reactivate_user(self):
        self.learner.is_active = False
        self.learner.save(update_fields=['is_active'])
        # Simulate an originally unverified account with a real token.
        self.profile.email_verified_at = None
        self.profile.save(update_fields=['email_verified_at'])
        before_block = self.token_url()
        self.assertEqual(self.manager('block').status_code, 302)
        self.client.logout()
        self.assertEqual(self.client.get(before_block).status_code, 302)
        self.assertEqual(self.client.post(before_block).status_code, 302)
        self.learner.refresh_from_db()
        self.assertFalse(self.learner.is_active)

    def test_manager_unblock_restores_only_prior_activation(self):
        self.manager('block')
        self.assertEqual(self.manager('unblock').status_code, 302)
        self.learner.refresh_from_db(); self.profile.refresh_from_db()
        self.assertTrue(self.learner.is_active)
        self.assertIsNone(self.profile.suspended_at)

    def test_unverified_user_block_then_unblock_remains_unverified(self):
        self.learner.is_active = False
        self.learner.save(update_fields=['is_active'])
        self.profile.email_verified_at = None
        self.profile.save(update_fields=['email_verified_at'])
        self.manager('block'); self.manager('unblock')
        self.learner.refresh_from_db(); self.profile.refresh_from_db()
        self.assertFalse(self.learner.is_active)
        self.assertIsNone(self.profile.email_verified_at)
        self.assertIsNone(self.profile.suspended_at)
        self.client.logout()
        self.assertEqual(self.client.post(reverse('resend_verification'), {'email': self.learner.email}).status_code, 302)
        self.assertEqual(len(mail.outbox), 1)

    def test_non_suspended_pending_user_cannot_be_unblocked_without_email(self):
        self.learner.is_active = False
        self.learner.save(update_fields=['is_active'])
        self.profile.email_verified_at = None
        self.profile.save(update_fields=['email_verified_at'])
        self.assertEqual(self.manager('unblock').status_code, 302)
        self.learner.refresh_from_db()
        self.assertFalse(self.learner.is_active)

    def test_get_preview_does_not_activate_legitimate_new_account(self):
        self.learner.is_active = False
        self.learner.save(update_fields=['is_active'])
        self.profile.email_verified_at = None
        self.profile.save(update_fields=['email_verified_at'])
        link = self.token_url()
        preview = self.client.get(link)
        self.assertEqual(preview.status_code, 200)
        self.assertContains(preview, 'csrfmiddlewaretoken')
        self.assertIn('no-store', preview['Cache-Control'])
        self.assertEqual(preview['Referrer-Policy'], 'no-referrer')
        self.learner.refresh_from_db()
        self.assertFalse(self.learner.is_active)
        with patch('academy.views.send_mail'):
            verified = self.client.post(link)
        self.assertEqual(verified.status_code, 302)
        self.learner.refresh_from_db(); self.profile.refresh_from_db()
        self.assertTrue(self.learner.is_active)
        self.assertIsNotNone(self.profile.email_verified_at)
        self.assertEqual(self.client.post(link).status_code, 302)
        self.assertTrue(self.learner.is_active)

    def test_inactive_previously_verified_without_marker_never_reverified(self):
        self.learner.is_active = False
        self.learner.save(update_fields=['is_active'])
        self.profile.suspended_at = None
        self.profile.save(update_fields=['suspended_at'])
        self.client.logout()
        mail.outbox.clear()
        self.client.post(reverse('resend_verification'), {'email': self.learner.email})
        self.assertEqual(len(mail.outbox), 0)
        self.assertEqual(self.client.post(self.token_url()).status_code, 302)
        self.learner.refresh_from_db()
        self.assertFalse(self.learner.is_active)

    def test_local_verification_helper_rejects_suspended_account(self):
        self.manager('block')
        with override_settings(DEBUG=True, SITE_URL='http://127.0.0.1:3000'):
            from unittest.mock import patch as mock_patch
            with mock_patch('academy.management.commands.local_verification_link.Path.is_file', return_value=True):
                with self.assertRaises(CommandError):
                    call_command('local_verification_link', username=self.learner.username,
                                 stdout=StringIO())

    def test_public_home_grammar_and_word_are_not_gated(self):
        self.client.logout()
        page = self.client.get(reverse('home'))
        self.assertEqual(page.status_code, 200)
        html = page.content.decode()
        self.assertIn('href="/grammar/"', html)
        self.assertIn('href="/word-of-the-day/"', html)
        self.assertNotIn('href="/login/?next=/grammar/"', html)

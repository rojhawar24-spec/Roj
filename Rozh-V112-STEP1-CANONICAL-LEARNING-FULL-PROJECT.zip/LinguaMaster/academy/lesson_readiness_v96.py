"""Read-only, fail-closed learner availability check for authored lessons.

Do not conflate published=True with playable=True. No audio synthesis, XP,
progression mutation, bypass of editorial approval, or DB writes are performed.
"""


def classic_mcq_blocked(exercises):
    """Reject impossible MCQs using the same editorial rule as mixed/assessment.

    Full five-kind admission is handled by lesson_block_reason below.
    """
    from .mixed_policy_v102 import canonical_mcq_errors
    return any(row.kind == 'mcq' and canonical_mcq_errors(
        row.prompt, row.options, row.answer, row.explanation,
        getattr(row, 'activity_data', {})) for row in exercises)


def lesson_block_reason(lesson, *, course_code=None, exercises=None):
    """Return 'audio', 'activity', or None; use this before issuing lesson URLs."""
    from .mixed_policy_v102 import canonical_lesson_block_reason
    def approved_audio_url(text, locale):
        from .audio_v78 import approved_audio_url as lookup
        return lookup(text, locale)
    code = course_code or lesson.unit.level.language.code
    if exercises is None:
        exercises = lesson.exercises.all()
    return canonical_lesson_block_reason(lesson, exercises, code, audio_lookup=approved_audio_url)

"""V96 live Django/SQLite tests; must be run in isolated test DB, not offline."""
from io import StringIO
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.test import TestCase
from django.urls import reverse

from .lesson_flow_v63 import next_step
from .models import Language, Level, Unit, Lesson, Exercise, Profile, LessonProgress, XPEvent


class UnapprovedListeningV96HTTPTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            username='v96-lesson-student', password='V96-Test-Only-Not-Real!999')
        cls.lang = Language.objects.create(code='nl', name='Dutch V96',
            slug='v96-dutch-audio', description='QA only', is_published=True)
        cls.level = Level.objects.create(language=cls.lang, code='A0', order=0,
            description='QA only')
        cls.unit = Unit.objects.create(level=cls.level, slug='v96-first',
            title='Audio QA Unit', summary='Test', order=1, published=True)
        cls.first = Lesson.objects.create(unit=cls.unit, slug='grammar', title='Grammar',
            skill='grammar', content='QA grammar', order=1, published=True)
        cls.unready = Lesson.objects.create(unit=cls.unit, slug='listening', title='Listening',
            skill='listening', content='QA listening', audio_text='No verified audio asset',
            order=2, published=True)
        cls.third = Lesson.objects.create(unit=cls.unit, slug='speaking', title='Speaking',
            skill='speaking', content='QA speaking', order=3, published=True)
        Exercise.objects.create(lesson=cls.first, kind='mcq', prompt='Ready?',
            options=['Yes','No'], answer='Yes', explanation='Yes', order=1)
        Exercise.objects.create(lesson=cls.unready, kind='mcq', prompt='Listen?',
            options=['Yes','No'], answer='Yes', explanation='No audio', order=1)
        Profile.objects.filter(user=cls.user).update(preferred_language=cls.lang,
            placement_completed=True, onboarding_required=False, onboarding_completed=True,
            suspended_at=None, legacy_review_required=False)

    def setUp(self):
        self.client.force_login(self.user)

    def test_direct_lesson_three_uses_branded_409_not_plain_white_page(self):
        response = self.client.get(reverse('lesson', args=[self.unready.pk]))
        self.assertEqual(response.status_code, 409)
        self.assertTemplateUsed(response, 'academy/lesson_unavailable_v96.html')
        self.assertContains(response, 'Deze les is nog niet klaar', status_code=409)
        self.assertContains(response, reverse('play_hub'), status_code=409)
        self.assertNotContains(response, 'No verified audio asset', status_code=409)
        self.assertEqual(response.headers.get('Cache-Control'), 'no-store, private')

    def test_sorani_block_message_is_rtl_and_has_return_path(self):
        Profile.objects.filter(user=self.user).update(ui_language='ckb')
        response = self.client.get(reverse('lesson', args=[self.unready.pk]))
        self.assertEqual(response.status_code, 409)
        self.assertContains(response, 'ئەم وانەیە هێشتا ئامادە نییە', status_code=409)
        self.assertContains(response, 'dir="rtl"', status_code=409)

    def test_next_action_never_points_to_unapproved_listening(self):
        self.assertIsNone(next_step(self.user, self.first))

    def test_learning_path_does_not_issue_dead_link(self):
        response = self.client.get(reverse('play_hub'))
        self.assertEqual(response.status_code, 200)
        self.assertIsNone(response.context['route']['stages'][0]['items'][0]['lesson_nodes'][1]['url'])
        self.assertIn('pending_content', [node['state']
            for season in response.context['R27_SEASONS']
            for node in season['path_nodes']])

    def test_unit_page_does_not_link_to_unready_lesson(self):
        response = self.client.get(reverse('unit', args=[self.unit.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, reverse('lesson', args=[self.unready.pk]))
        self.assertContains(response, 'Deze les is nog niet klaar')
        self.assertNotContains(response, reverse('journey_play', args=[self.unit.pk]))

    def test_mixed_level_409_has_useful_navigation(self):
        response = self.client.get(reverse('journey_play', args=[self.unit.pk]))
        self.assertEqual(response.status_code, 409)
        self.assertTemplateUsed(response, 'academy/lesson_unavailable_v96.html')
        self.assertContains(response, reverse('play_hub'), status_code=409)

    def test_repair_dry_run_never_modifies_content(self):
        before=LessonProgress.objects.filter(user=self.user).count()
        out=StringIO()
        call_command('repair_listening_publication', stdout=out)
        self.unready.refresh_from_db()
        self.assertTrue(self.unready.published)
        self.assertIn('DRY RUN',out.getvalue())
        self.assertEqual(LessonProgress.objects.filter(user=self.user).count(), before)

    def test_opt_in_repair_unpublishes_only_unready_listening(self):
        out=StringIO()
        call_command('repair_listening_publication', '--apply', stdout=out)
        self.unready.refresh_from_db()
        self.first.refresh_from_db()
        self.third.refresh_from_db()
        self.assertFalse(self.unready.published)
        self.assertTrue(self.first.published)
        self.assertTrue(self.third.published)
        self.assertIn('UNPUBLISHED',out.getvalue())
        self.assertEqual(next_step(self.user, self.first)['url'], reverse('lesson', args=[self.third.pk]))
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_audio_approval_required_for_published_content(self):
        # The catalog is initially empty. Patching the approval function only
        # simulates an editorially reviewed recording in a disposable test DB.
        with patch('academy.audio_v78.approved_audio_url', return_value='/static/approved.wav'):
            self.assertEqual(next_step(self.user, self.first)['url'],
                             reverse('lesson', args=[self.unready.pk]))
            response = self.client.get(reverse('lesson', args=[self.unready.pk]))
            self.assertEqual(response.status_code, 200)

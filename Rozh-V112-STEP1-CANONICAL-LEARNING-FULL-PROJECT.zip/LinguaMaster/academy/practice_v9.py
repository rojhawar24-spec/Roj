"""A mobile-accessible home for all practice tools, backed by the active course."""
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.urls import path, reverse
from django.utils import timezone

from .grammar_models import GrammarMastery
from .models import AppNotification, MistakeRecord, ReviewCard, Vocabulary


TEXT = {
    'en': {
        'eyebrow': 'YOUR PRACTICE STUDIO', 'title': 'Practice your skills.',
        'intro': 'A little repetition today. More confidence tomorrow.',
        'active_course': 'Active course', 'choose_course': 'Choose a learning language in your profile.',
        'choose': 'Choose a course', 'focus': 'A GOOD NEXT STEP', 'start': 'Start practising',
        'focus_review': 'Bring familiar words back to mind.',
        'focus_mistakes': 'Turn your last mistakes into progress.',
        'focus_grammar': 'Give a grammar rule another look.',
        'focus_learn': 'Ready for something new?', 'focus_learn_note': 'Continue your course, then return here to practise.',
        'foundation': 'Build your foundation', 'foundation_note': 'Understand it. Recall it. Use it.',
        'daily_word': 'Word of the day', 'daily_word_note': 'Learn and practise today’s word.',
        'mistakes': 'Mistake practice', 'mistakes_note': 'See why an answer works and give it another try.',
        'grammar': 'Grammar library', 'grammar_note': 'Clear rules, useful examples and short checks.',
        'vocabulary': 'Vocabulary', 'vocabulary_note': 'Find words and save them to your review deck.',
        'due': 'ready to review', 'to_fix': 'to practise', 'published_words': 'published words',
        'voice': 'Listen and learn', 'voice_note': 'Train your listening skills with short examples.',
        'speaking': 'Speaking', 'speaking_note': 'Listen, repeat and compare your transcript.',
        'writing': 'Writing', 'writing_note': 'Build a sentence and check its form.',
        'ai': 'AI teacher', 'ai_note': 'Level-aware help with paid credits. Check availability and your balance.',
        'open': 'Open', 'discover': 'Play & discover', 'arena': 'Arena', 'arena_note': 'A timed learning challenge',
        'chest': 'Daily chest', 'chest_note': 'Check your learning reward',
        'leaderboard': 'Leaderboard', 'leaderboard_note': 'Your optional XP ranking',
        'notifications': 'Notifications', 'notifications_note': 'Your updates and celebrations',
        'unread': 'unread', 'honest_note': 'Practice feedback supports learning. It is not a certified CEFR assessment.',
    },
    'nl': {
        'eyebrow': 'JOUW OEFENRUIMTE', 'title': 'Oefen je vaardigheden.',
        'intro': 'Vandaag een beetje herhalen. Morgen meer vertrouwen.',
        'active_course': 'Actieve cursus', 'choose_course': 'Kies je leertaal in je profiel.',
        'choose': 'Kies een cursus', 'focus': 'EEN GOEDE VOLGENDE STAP', 'start': 'Begin met oefenen',
        'focus_review': 'Haal bekende woorden terug in je geheugen.',
        'focus_mistakes': 'Maak van je laatste fouten vooruitgang.',
        'focus_grammar': 'Bekijk een grammaticaregel opnieuw.',
        'focus_learn': 'Klaar voor iets nieuws?', 'focus_learn_note': 'Ga verder met je cursus en kom hier terug om te oefenen.',
        'foundation': 'Bouw aan je basis', 'foundation_note': 'Begrijpen. Onthouden. Gebruiken.',
        'daily_word': 'Woord van de dag', 'daily_word_note': 'Leer en oefen het woord van vandaag.',
        'mistakes': 'Fouten oefenen', 'mistakes_note': 'Begrijp waarom een antwoord klopt en probeer opnieuw.',
        'grammar': 'Grammaticabibliotheek', 'grammar_note': 'Heldere regels, handige voorbeelden en korte oefeningen.',
        'vocabulary': 'Woordenschat', 'vocabulary_note': 'Zoek woorden en bewaar ze om te herhalen.',
        'due': 'klaar om te herhalen', 'to_fix': 'om te oefenen', 'published_words': 'gepubliceerde woorden',
        'voice': 'Luister en leer', 'voice_note': 'Oefen je luistervaardigheid met korte voorbeelden.',
        'speaking': 'Spreken', 'speaking_note': 'Luister, spreek na en vergelijk je transcript.',
        'writing': 'Schrijven', 'writing_note': 'Maak een zin en controleer de vorm.',
        'ai': 'AI-leraar', 'ai_note': 'Hulp op jouw niveau met betaalde credits. Bekijk beschikbaarheid en saldo.',
        'open': 'Openen', 'discover': 'Spelen en ontdekken', 'arena': 'Arena', 'arena_note': 'Een leeruitdaging op tijd',
        'chest': 'Dagelijkse kist', 'chest_note': 'Bekijk je leerbeloning',
        'leaderboard': 'Ranglijst', 'leaderboard_note': 'Je optionele XP-rangschikking',
        'notifications': 'Meldingen', 'notifications_note': 'Je updates en behaalde doelen',
        'unread': 'ongelezen', 'honest_note': 'Oefenfeedback helpt je leren. Het is geen gecertificeerde ERK-beoordeling.',
    },
    'ckb': {
        'eyebrow': 'شوێنی ڕاهێنانەکەت', 'title': 'کارامەییەکانت ڕاهێنان بکە.',
        'intro': 'ئەمڕۆ کەمێک دووبارەکردنەوە. سبەی دڵنیایی زیاتر.',
        'active_course': 'کۆرسی چالاک', 'choose_course': 'زمانی فێربوون لە پرۆفایلەکەت هەڵبژێرە.',
        'choose': 'کۆرسێک هەڵبژێرە', 'focus': 'هەنگاوێکی باشی داهاتوو', 'start': 'دەست بە ڕاهێنان بکە',
        'focus_review': 'وشە ئاشناکان بخەرەوە بیرت.',
        'focus_mistakes': 'هەڵەکانت بکە بە دەرفەتی پێشکەوتن.',
        'focus_grammar': 'پێداچوونەوە بە ڕێسایەکی ڕێزماندا بکە.',
        'focus_learn': 'ئامادەیت بۆ شتێکی نوێ؟', 'focus_learn_note': 'کۆرسەکەت بەردەوام بکە و بۆ ڕاهێنان بگەڕێوە ئێرە.',
        'foundation': 'بنەماکانت بەهێز بکە', 'foundation_note': 'تێبگە. لەبیرت بێت. بەکاری بهێنە.',
        'daily_word': 'وشەی ڕۆژ', 'daily_word_note': 'وشەی ئەمڕۆ فێربە و ڕاهێنانی لەسەر بکە.',
        'mistakes': 'ڕاهێنان لەسەر هەڵەکان', 'mistakes_note': 'هۆکاری دروستیی وەڵامەکە تێبگە و دووبارە هەوڵ بدە.',
        'grammar': 'کتێبخانەی ڕێزمان', 'grammar_note': 'ڕێسای ڕوون، نموونەی بەسوود و ڕاهێنانی کورت.',
        'vocabulary': 'فەرهەنگ', 'vocabulary_note': 'وشە بدۆزەوە و بۆ پێداچوونەوە پاشەکەوتی بکە.',
        'due': 'ئامادە بۆ پێداچوونەوە', 'to_fix': 'بۆ ڕاهێنان', 'published_words': 'وشەی بڵاوکراوە',
        'voice': 'گوێ بگرە و فێربە', 'voice_note': 'بە نموونەی کورتی دەنگی ڕاهێنانی گوێگرتن بکە.',
        'speaking': 'قسەکردن', 'speaking_note': 'گوێ بگرە، دووبارە بکەوە و دەقەکەت بەراورد بکە.',
        'writing': 'نووسین', 'writing_note': 'ڕستەیەک بنووسە و شێوەکەی بپشکنە.',
        'ai': 'مامۆستای AI', 'ai_note': 'یارمەتی بەپێی ئاستت بە کردیتی پارەدراو. بەردەستبوون و باڵانسەکەت ببینە.',
        'open': 'کردنەوە', 'discover': 'یاری و دۆزینەوە', 'arena': 'ئارێنا', 'arena_note': 'ڕکابەریی فێربوون بە کاتی دیاریکراو',
        'chest': 'سندووقی ڕۆژانە', 'chest_note': 'پاداشتی فێربوونەکەت ببینە',
        'leaderboard': 'پلەبەندی', 'leaderboard_note': 'پلەبەندیی XPی هەڵبژاردەیی',
        'notifications': 'ئاگادارییەکان', 'notifications_note': 'نوێکاری و سەرکەوتنەکانت',
        'unread': 'نەخوێندراوە', 'honest_note': 'پێداچوونەوەی ڕاهێنان یارمەتیدەری فێربوونە. هەڵسەنگاندنی پەسەندکراوی CEFR نییە.',
    },
    'ar': {
        'eyebrow': 'مساحة تدريبك', 'title': 'تدرّب على مهاراتك.',
        'intro': 'مراجعة بسيطة اليوم. ثقة أكبر غدًا.',
        'active_course': 'الدورة الحالية', 'choose_course': 'اختر لغة التعلم من ملفك.',
        'choose': 'اختر دورة', 'focus': 'خطوة تالية مفيدة', 'start': 'ابدأ التدريب',
        'focus_review': 'استعد الكلمات المألوفة في ذاكرتك.',
        'focus_mistakes': 'حوّل أخطاءك الأخيرة إلى تقدم.',
        'focus_grammar': 'ألقِ نظرة جديدة على قاعدة لغوية.',
        'focus_learn': 'مستعد لشيء جديد؟', 'focus_learn_note': 'تابع دورتك ثم عد إلى هنا للتدريب.',
        'foundation': 'ابنِ أساسك', 'foundation_note': 'افهم. تذكّر. استخدم.',
        'daily_word': 'كلمة اليوم', 'daily_word_note': 'تعلّم كلمة اليوم وتدرّب عليها.',
        'mistakes': 'تدريب على الأخطاء', 'mistakes_note': 'افهم سبب صحة الإجابة ثم حاول مجددًا.',
        'grammar': 'مكتبة القواعد', 'grammar_note': 'قواعد واضحة وأمثلة مفيدة وتدريبات قصيرة.',
        'vocabulary': 'المفردات', 'vocabulary_note': 'اعثر على كلمات واحفظها للمراجعة.',
        'due': 'جاهز للمراجعة', 'to_fix': 'للتدريب', 'published_words': 'كلمات منشورة',
        'voice': 'استمع وتعلّم', 'voice_note': 'درّب مهارة الاستماع بأمثلة قصيرة.',
        'speaking': 'التحدث', 'speaking_note': 'استمع وكرّر وقارن النص المنسوخ.',
        'writing': 'الكتابة', 'writing_note': 'اكتب جملة وتحقق من بنيتها.',
        'ai': 'معلّم الذكاء الاصطناعي', 'ai_note': 'مساعدة حسب مستواك بأرصدة مدفوعة. تحقق من التوفر والرصيد.',
        'open': 'فتح', 'discover': 'العب واكتشف', 'arena': 'الساحة', 'arena_note': 'تحدٍ تعليمي بوقت محدد',
        'chest': 'الصندوق اليومي', 'chest_note': 'تحقق من مكافأة التعلم',
        'leaderboard': 'الترتيب', 'leaderboard_note': 'ترتيب XP اختياري',
        'notifications': 'الإشعارات', 'notifications_note': 'تحديثاتك وإنجازاتك',
        'unread': 'غير مقروء', 'honest_note': 'تساعدك ملاحظات التدريب على التعلم. وهي ليست تقييمًا معتمدًا لمستوى CEFR.',
    },
}


@login_required
def practice_hub(request):
    profile = request.user.learning_profile
    language = profile.preferred_language
    language = language if language and language.is_published else None
    labels = TEXT.get(profile.ui_language, TEXT['en'])
    now = timezone.now()
    due_words = ReviewCard.objects.filter(user=request.user, due__lte=now,
        vocabulary__published=True, vocabulary__level__language=language,
        vocabulary__level__language__is_published=True).count() if language else 0
    mistakes = MistakeRecord.objects.filter(user=request.user, corrected_at__isnull=True,
        exercise__lesson__published=True, exercise__lesson__unit__published=True,
        exercise__lesson__unit__level__language=language,
        exercise__lesson__unit__level__language__is_published=True).count() if language else 0
    due_grammar = GrammarMastery.objects.filter(user=request.user, due_at__lte=now,
        topic__published=True, topic__level__language=language,
        topic__level__language__is_published=True).count() if language else 0
    words = Vocabulary.objects.filter(published=True, level__language=language,
        level__language__is_published=True).count() if language else 0
    unread = AppNotification.objects.filter(user=request.user, read_at__isnull=True).count()
    focus = {'title': labels['focus_learn'], 'note': labels['focus_learn_note'],
             'url': reverse('learn_path'), 'icon': '✦'}
    if mistakes:
        focus = {'title': labels['focus_mistakes'], 'note': f"{mistakes} {labels['to_fix']}",
                 'url': reverse('mistakes'), 'icon': '↺'}
    elif due_grammar:
        focus = {'title': labels['focus_grammar'], 'note': f"{due_grammar} {labels['due']}",
                 'url': reverse('grammar_library') + '?status=due', 'icon': 'Aa'}
    return render(request, 'academy/practice_hub.html', {
        'P': labels, 'language': language, 'focus': focus, 'due_words': due_words,
        'mistakes': mistakes, 'due_grammar': due_grammar, 'word_count': words,
        'unread_count': unread, 'noindex': True, 'seo_title': labels['eyebrow'],
    })


urlpatterns = [path('practice/', practice_hub, name='practice_hub')]


# V74: seven-language locale bridge. Untranslated copy remains explicitly English until reviewed.
from .ui_languages_v74 import extend_localized_maps as _v74_extend_localized_maps
_v74_extend_localized_maps(globals(), 'practice_v9', ['TEXT'])

"""REAL PostgreSQL TransactionTestCase concurrency gate; NOT run offline.

Execute only under config.settings_postgres_qa on a disposable GitHub Actions
PostgreSQL service. Separate thread connections test the DB's actual locking,
unique constraints, AJAX replay handling and XP/heart/mistake idempotency.
"""
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
import os

from django.contrib.auth import get_user_model
from django.db import close_old_connections, connection, connections, transaction
from django.test import Client, TransactionTestCase
from django.urls import reverse
from django.utils import timezone

from .heart_models import HeartBalance, HeartEvent
from .lesson_round_models_step3h import LessonRoundReceipt
from .lesson_round_receipts_step3h import (
    RoundReceiptAnswerReplay, RoundReceiptConflict, RoundReceiptFinished,
    claim_round, finish_round, save_answer,
)
from .models import (Exercise, Language, Lesson, LessonProgress, Level,
                     MistakeRecord, Profile, Unit, XPEvent)


class PostgresConcurrentRoundTests(TransactionTestCase):
    """TransactionTestCase permits committed writes visible across DB threads."""

    def setUp(self):
        # Broad SQLite academy regression deliberately skips PG-only cases;
        # under actual PostgreSQL an absent CI opt-in is a hard FAILURE.
        # The strict Phase J runner also refuses skips in the targeted PG job.
        if connection.vendor != 'postgresql':
            self.skipTest('Only real PostgreSQL runs concurrency cases')
        self.assertEqual(os.environ.get('GITHUB_ACTIONS'), 'true',
                         'PostgreSQL runtime gate requires GitHub Actions')
        self.assertEqual(os.environ.get('ROZH_PG_QA_ONLY'), '1',
                         'PostgreSQL runtime gate must not silently skip')
        self.assertEqual(connection.settings_dict['NAME'], 'test_rozh_qa_step3')
        self.user = get_user_model().objects.create_user(
            username='step3i-postgres-learner', password='DisposableStep3I!2026')
        self.language = Language.objects.create(
            code='en', name='Step3I QA English', slug='step3i-en',
            description='Disposable concurrency test language', is_published=True)
        level = Level.objects.create(language=self.language, code='A0', order=0,
                                     description='Disposable QA')
        unit = Unit.objects.create(level=level, slug='step3i-unit',
                                   title='Step3I Unit', summary='QA', published=True)
        self.lesson = Lesson.objects.create(unit=unit, slug='step3i-lesson',
            title='Step3I Lesson', skill='grammar', published=True,
            content='Disposable QA only')
        self.exercise = Exercise.objects.create(lesson=self.lesson,
            kind='mcq', options=['yes','no'], prompt='Type yes?', answer='yes', explanation='QA', order=1)
        Profile.objects.filter(user=self.user).update(
            preferred_language=self.language, placement_completed=True,
            onboarding_required=False, onboarding_completed=True,
            suspended_at=None, legacy_review_required=False)
        HeartBalance.objects.update_or_create(user=self.user,
            defaults={'remaining': 5, 'regenerated_at': timezone.now()})

    def _parallel(self, tasks):
        gate = Barrier(len(tasks))
        def run(task):
            close_old_connections()
            try:
                gate.wait(timeout=15)
                return task()
            finally:
                connections.close_all()
        with ThreadPoolExecutor(max_workers=len(tasks)) as pool:
            futures = [pool.submit(run, task) for task in tasks]
            return [future.result(timeout=45) for future in futures]

    def _db_round(self, *, channel, key, action):
        try:
            with transaction.atomic():
                receipt = claim_round(user=self.user, lesson=self.lesson,
                                      round_key=key, channel=channel)
                if action == 'answer':
                    save_answer(receipt, self.exercise.pk, True)
                elif action == 'finish':
                    finish_round(receipt, score=100)
                else:
                    raise AssertionError('Unexpected QA action')
            return 'accepted'
        except (RoundReceiptAnswerReplay, RoundReceiptConflict, RoundReceiptFinished):
            return 'rejected'

    def test_two_correct_ajax_claims_single_receipt(self):
        key = 'a' * 32
        outcomes = self._parallel([
            lambda: self._db_round(channel='ajax', key=key, action='answer'),
            lambda: self._db_round(channel='ajax', key=key, action='answer'),
        ])
        self.assertCountEqual(outcomes, ['accepted', 'rejected'])
        receipt = LessonRoundReceipt.objects.get(user=self.user, lesson=self.lesson,
                                                 round_key=key)
        self.assertEqual(receipt.answers, {str(self.exercise.pk): True})
        self.assertEqual(LessonRoundReceipt.objects.filter(user=self.user,
            lesson=self.lesson, round_key=key).count(), 1)

    def test_ajax_ssr_race_claims_exactly_one_channel(self):
        key = 'b' * 32
        outcomes = self._parallel([
            lambda: self._db_round(channel='ajax', key=key, action='answer'),
            lambda: self._db_round(channel='ssr', key=key, action='finish'),
        ])
        self.assertCountEqual(outcomes, ['accepted', 'rejected'])
        receipt = LessonRoundReceipt.objects.get(user=self.user, lesson=self.lesson,
                                                 round_key=key)
        self.assertIn(receipt.channel, ('ajax', 'ssr'))
        self.assertEqual(bool(receipt.answers), receipt.channel == 'ajax')
        self.assertEqual(receipt.finished_at is not None, receipt.channel == 'ssr')

    def test_two_ssr_finish_attempts_exactly_one_final(self):
        key = 'c' * 32
        outcomes = self._parallel([
            lambda: self._db_round(channel='ssr', key=key, action='finish'),
            lambda: self._db_round(channel='ssr', key=key, action='finish'),
        ])
        self.assertCountEqual(outcomes, ['accepted', 'rejected'])
        receipt = LessonRoundReceipt.objects.get(user=self.user, lesson=self.lesson,
                                                 round_key=key)
        self.assertEqual(receipt.score, 100)
        self.assertIsNotNone(receipt.finished_at)

    def _browser_pair(self):
        original = Client()
        original.force_login(self.user)
        lesson_url = reverse('lesson', args=[self.lesson.pk])
        page = original.get(lesson_url)
        self.assertEqual(page.status_code, 200)
        key = page.context['lesson_round_key']
        clients = [Client(), Client()]
        for client in clients:
            client.cookies.update(original.cookies)
        return clients, key

    def _two_ajax_requests(self, answer):
        clients, key = self._browser_pair()
        url = reverse('lesson_answer', args=[self.lesson.pk])
        def action(client):
            response = client.post(url, {'exercise_id': self.exercise.pk,
                                         'round_key': key, 'answer': answer})
            return response.status_code
        return self._parallel([lambda c=client: action(c) for client in clients]), key

    def test_two_correct_http_posts_award_xp_once(self):
        statuses, key = self._two_ajax_requests('yes')
        self.assertCountEqual(statuses, [200, 409])
        self.assertEqual(LessonRoundReceipt.objects.filter(user=self.user,
            lesson=self.lesson, round_key=key).count(), 1)
        self.assertEqual(LessonProgress.objects.filter(user=self.user,
            lesson=self.lesson).count(), 1)
        self.assertEqual(XPEvent.objects.filter(user=self.user,
            reason='lesson').count(), 1)
        self.assertEqual(Profile.objects.get(user=self.user).xp, 20)
        self.assertFalse(HeartEvent.objects.filter(user=self.user,kind='answer').exists())

    def test_two_wrong_http_posts_spend_one_heart(self):
        statuses, key = self._two_ajax_requests('no')
        self.assertCountEqual(statuses, [200, 409])
        self.assertEqual(LessonRoundReceipt.objects.filter(user=self.user,
            lesson=self.lesson, round_key=key).count(), 1)
        self.assertEqual(HeartEvent.objects.filter(user=self.user,
            kind='answer').count(), 1)
        self.assertEqual(HeartBalance.objects.get(user=self.user).remaining, 4)
        self.assertEqual(MistakeRecord.objects.get(user=self.user,
            exercise=self.exercise).wrong_count, 1)
        self.assertFalse(XPEvent.objects.filter(user=self.user, reason='lesson').exists())

"""Real Django HTTP tests, only against an isolated disposable test DB.

These tests must not be counted in offline unit test totals.
"""
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .manager_roles_v48 import MANAGER_GROUP
from .models import AuditEvent


class ManagerPermissionBoundaryHTTPTests(TestCase):
    def setUp(self):
        User=get_user_model()
        self.owner=User.objects.create_superuser('v28owner','owner-v28@example.invalid','TestOnlyOwnerV28!')
        self.manager=User.objects.create_user('v28manager','manager-v28@example.invalid','TestOnlyManagerV28!')
        self.target=User.objects.create_user('v28target','target-v28@example.invalid','TestOnlyTargetV28!')
        self.staff=User.objects.create_user('v28staff','staff-v28@example.invalid','TestOnlyStaffV28!',is_staff=True)
        self.permission=Permission.objects.filter(content_type__app_label='auth').first()
        assert self.permission is not None
        Group.objects.get_or_create(name=MANAGER_GROUP)[0].user_set.add(self.manager)
        for user in (self.owner,self.manager,self.target,self.staff):
            profile=user.learning_profile
            profile.email_verified_at=timezone.now()
            profile.totp_secret='JBSWY3DPEHPK3PXP'
            profile.save(update_fields=['email_verified_at','totp_secret'])

    def actor(self,user):
        self.client.force_login(user)
        session=self.client.session
        session['mfa_verified_id']=user.pk
        session.save()

    def do(self,user,action):
        return self.client.post(reverse('manager_user_action',args=[user.pk,action]))

    def test_delegated_manager_denied_direct_permission_target(self):
        self.target.user_permissions.add(self.permission)
        self.actor(self.manager)
        self.assertEqual(self.do(self.target,'block').status_code,403)
        self.target.refresh_from_db();self.assertTrue(self.target.is_active)
        self.assertFalse(AuditEvent.objects.filter(actor=self.manager,action='user_block').exists())

    def test_delegated_manager_denied_group_permission_target(self):
        group=Group.objects.create(name='v28-operators')
        group.permissions.add(self.permission)
        self.target.groups.add(group)
        self.actor(self.manager)
        self.assertEqual(self.do(self.target,'block').status_code,403)
        self.target.refresh_from_db();self.assertTrue(self.target.is_active)

    def test_delegated_manager_denied_manager_role_target(self):
        self.target.groups.add(Group.objects.get(name=MANAGER_GROUP))
        self.actor(self.manager)
        self.assertEqual(self.do(self.target,'block').status_code,403)

    def test_ordinary_student_group_remains_manageable(self):
        self.target.groups.add(Group.objects.create(name='v28-learners'))
        self.actor(self.manager)
        self.assertEqual(self.do(self.target,'block').status_code,302)
        self.target.refresh_from_db();self.assertFalse(self.target.is_active)

    def test_owner_demote_denies_lingering_manager_membership(self):
        self.staff.groups.add(Group.objects.get(name=MANAGER_GROUP))
        self.actor(self.owner)
        self.assertEqual(self.do(self.staff,'demote').status_code,409)
        self.staff.refresh_from_db();self.assertTrue(self.staff.is_staff)
        self.assertFalse(AuditEvent.objects.filter(actor=self.owner,action='user_demote').exists())

    def test_owner_demote_denies_lingering_direct_permissions(self):
        self.staff.user_permissions.add(self.permission)
        self.actor(self.owner)
        self.assertEqual(self.do(self.staff,'demote').status_code,409)
        self.staff.refresh_from_db();self.assertTrue(self.staff.is_staff)

    def test_owner_demote_denies_lingering_group_permissions(self):
        group=Group.objects.create(name='v28-staff-access');group.permissions.add(self.permission)
        self.staff.groups.add(group)
        self.actor(self.owner)
        self.assertEqual(self.do(self.staff,'demote').status_code,409)
        self.staff.refresh_from_db();self.assertTrue(self.staff.is_staff)

    def test_owner_demote_plain_staff_still_succeeds(self):
        self.actor(self.owner)
        self.assertEqual(self.do(self.staff,'demote').status_code,302)
        self.staff.refresh_from_db();self.assertFalse(self.staff.is_staff)
        self.assertTrue(AuditEvent.objects.filter(actor=self.owner,action='user_demote').exists())

    def test_manager_cannot_demote_even_plain_staff(self):
        self.actor(self.manager)
        self.assertEqual(self.do(self.staff,'demote').status_code,403)
        self.staff.refresh_from_db();self.assertTrue(self.staff.is_staff)

    def test_manager_post_without_mfa_denied(self):
        self.client.force_login(self.manager)
        self.assertEqual(self.do(self.target,'block').status_code,403)
        self.target.refresh_from_db();self.assertTrue(self.target.is_active)

    def test_manager_block_via_get_denied(self):
        self.actor(self.manager)
        self.assertEqual(self.client.get(reverse('manager_user_action',args=[self.target.pk,'block'])).status_code,405)
        self.target.refresh_from_db();self.assertTrue(self.target.is_active)

"""V87 Django HTTP integration tests, NOT counted until manage.py test runs.

Use config.settings_local_qa and disposable database only; never real accounts.
"""
import pyotp
from django.contrib.auth import get_user_model
from django.test import Client, TestCase
from django.urls import reverse

from .models import Profile


class V87MFAEnrollmentReauthenticationHTTP(TestCase):
    PASSWORD = 'V87-QA-Only-Strong-Passphrase!'

    def setUp(self):
        self.user = get_user_model().objects.create_user(
            'v87learner', 'v87@example.invalid', self.PASSWORD)
        self.client.force_login(self.user)
        page = self.client.get(reverse('mfa_setup'))
        self.assertEqual(page.status_code, 200)
        self.secret = self.client.session['mfa_setup_secret']

    def otp(self):
        return pyotp.TOTP(self.secret).now()

    def assert_not_enrolled(self):
        self.assertFalse(Profile.objects.get(user=self.user).totp_secret)
        self.assertNotIn('mfa_recovery_codes_once', self.client.session)

    def test_password_field_present_and_not_prepopulated(self):
        page = self.client.get(reverse('mfa_setup'))
        self.assertContains(page, 'name="password"')
        self.assertContains(page, 'autocomplete="current-password"')
        self.assertNotContains(page, f'value="{self.PASSWORD}"')

    def test_valid_otp_without_password_cannot_enable_factor(self):
        r = self.client.post(reverse('mfa_setup'), {'code': self.otp()})
        self.assertEqual(r.status_code, 200)
        self.assert_not_enrolled()

    def test_valid_otp_with_wrong_password_cannot_enable_factor(self):
        r = self.client.post(reverse('mfa_setup'), {
            'code': self.otp(), 'password': 'invalid'})
        self.assertEqual(r.status_code, 200)
        self.assert_not_enrolled()

    def test_valid_password_with_wrong_otp_cannot_enable_factor(self):
        r = self.client.post(reverse('mfa_setup'), {
            'code': '000000', 'password': self.PASSWORD})
        self.assertEqual(r.status_code, 200)
        self.assert_not_enrolled()

    def test_correct_password_and_otp_enables_factor(self):
        r = self.client.post(reverse('mfa_setup'), {
            'code': self.otp(), 'password': self.PASSWORD})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(r['Location'], reverse('mfa_recovery'))
        self.assertEqual(Profile.objects.get(user=self.user).totp_secret, self.secret)
        self.assertEqual(len(self.client.session['mfa_recovery_codes_once']), 8)

    def test_csrf_token_required_for_enrollment(self):
        client = Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        page = client.get(reverse('mfa_setup'))
        secret = client.session['mfa_setup_secret']
        self.assertEqual(page.status_code, 200)
        r = client.post(reverse('mfa_setup'), {
            'code': pyotp.TOTP(secret).now(), 'password': self.PASSWORD})
        self.assertEqual(r.status_code, 403)
        self.assert_not_enrolled()

    def test_wrong_method_rejected(self):
        self.assertEqual(self.client.put(reverse('mfa_setup'), data='').status_code, 405)
        self.assert_not_enrolled()

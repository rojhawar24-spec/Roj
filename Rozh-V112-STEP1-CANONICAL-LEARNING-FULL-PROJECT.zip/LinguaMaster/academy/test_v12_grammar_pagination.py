"""Django integration tests for V12 grammar paging. Requires an isolated TEST DB."""
from copy import deepcopy
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .grammar_models import GrammarMastery
from .grammar_rich_models import GrammarArticle
from .models import GrammarTopic, Language, Level
from .test_grammar_v10 import ARTICLE


class GrammarPaginationV12Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.course = Language.objects.create(code='nl', name='Dutch', slug='v12-dutch',
                                             description='Dutch', is_published=True)
        cls.other_course = Language.objects.create(code='fr', name='French', slug='v12-french',
                                                   description='French', is_published=True)
        cls.level = Level.objects.create(language=cls.course, code='A0', order=0, description='Start')
        cls.other_level = Level.objects.create(language=cls.other_course, code='A0', order=0,
                                               description='French basics')
        cls.user = get_user_model().objects.create_user('v12_grammar_learner', password='S3cureTest!123')
        cls.other = get_user_model().objects.create_user('v12_grammar_other', password='S3cureTest!123')
        for user in (cls.user, cls.other):
            profile = user.learning_profile
            profile.preferred_language = cls.course
            profile.onboarding_completed = True
            profile.placement_completed = True
            profile.save()

    def setUp(self):
        self.client.force_login(self.user)

    def _topic(self, n, level=None, title=None):
        return GrammarTopic.objects.create(level=level or self.level, slug=f'v12-topic-{n}',
            title=title or f'Unit {n:03d}', explanation='Explain the rule carefully.',
            examples=['Example.'], exceptions='None.', common_mistakes='None.',
            check_question='Which?', check_options=['One', 'Two'], check_answer='One', published=True)

    def test_pages_are_stable_and_course_scoped(self):
        items = [self._topic(i) for i in range(53)]
        foreign = self._topic(9999, level=self.other_level)
        for page_number, expected in [(1, items[:24]), (2, items[24:48]), (3, items[48:])]:
            response = self.client.get(reverse('grammar_library'), {'page': page_number})
            self.assertEqual(response.status_code, 200)
            self.assertEqual([card['topic'].pk for card in response.context['cards']],
                             [topic.pk for topic in expected])
            self.assertEqual(response.context['topic_total'], len(items))
            self.assertEqual(response.context['grammar_page'].paginator.num_pages, 3)
            self.assertNotIn(foreign.pk,
                             [card['topic'].pk for card in response.context['cards']])

    def test_all_statuses_due_and_course_wide_totals(self):
        fresh = self._topic(1)
        zero_progress = self._topic(2)
        practising = self._topic(3)
        mastered = self._topic(4)
        due_mastered = self._topic(5)
        GrammarMastery.objects.create(user=self.user, topic=zero_progress)
        GrammarMastery.objects.create(user=self.user, topic=practising, attempts=1, correct=0,
                                      successful_days=0)
        GrammarMastery.objects.create(user=self.user, topic=mastered, attempts=3, correct=3,
                                      successful_days=3, due_at=timezone.now()+timedelta(days=3))
        GrammarMastery.objects.create(user=self.user, topic=due_mastered, attempts=3, correct=3,
                                      successful_days=3, due_at=timezone.now()-timedelta(hours=1))
        GrammarMastery.objects.create(user=self.other, topic=fresh, attempts=4, correct=4,
                                      successful_days=3, due_at=timezone.now()-timedelta(days=1))
        expectations = {
            'new': {fresh.pk, zero_progress.pk},
            'practising': {practising.pk},
            'mastered': {mastered.pk, due_mastered.pk},
            'due': {due_mastered.pk},
        }
        for status, ids in expectations.items():
            response = self.client.get(reverse('grammar_library'), {'status': status})
            self.assertEqual(response.status_code, 200)
            self.assertEqual({card['topic'].pk for card in response.context['cards']}, ids)
            self.assertEqual(response.context['topic_total'], 5)
            self.assertEqual(response.context['remembered_total'], 2)
            self.assertEqual(response.context['due_total'], 1)

    def test_featured_guide_remains_first_rich_topic_on_page_two(self):
        items = [self._topic(i) for i in range(30)]
        GrammarArticle.objects.create(topic=items[2], content=deepcopy(ARTICLE))
        GrammarArticle.objects.create(topic=items[28], content=deepcopy(ARTICLE))
        response = self.client.get(reverse('grammar_library'), {'page': 2})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.context['cards']), 6)
        self.assertEqual(response.context['featured_guide']['topic'].pk, items[2].pk)
        self.assertTrue(response.context['featured_guide']['rich'])

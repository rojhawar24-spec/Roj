"""V45 live Django tests; deliberately NOT counted as passed until run with Django.

Run in the disposable phase17 sandbox or TEST-ROZH-DJANGO-V33.ps1.
No external API, paid endpoint, SMTP or production database is contacted.
"""
from django.contrib.auth import get_user_model
from django.core.exceptions import PermissionDenied
from django.test import TestCase, Client
from django.urls import reverse
from django.utils import timezone

from .courses_v10 import switch_course
from .models import Language, Profile
from .progress_models import LearningPreferences


class AccountBoundaryHTTPV45(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username='v45-learner', email='v45@example.invalid', password='StrongExample!2026'
        )
        self.dutch = Language.objects.create(code='nl', name='Dutch', slug='v45-nl',
                                              description='QA Dutch', is_published=True)
        self.english = Language.objects.create(code='en', name='English', slug='v45-en',
                                                description='QA English', is_published=True)
        Profile.objects.filter(user=self.user).update(
            preferred_language=self.dutch, onboarding_required=False,
            onboarding_completed=True, placement_completed=True,
            legacy_review_required=False, suspended_at=None,
        )
        self.client.force_login(self.user)

    def _suspend(self):
        Profile.objects.filter(user=self.user).update(suspended_at=timezone.now())

    def test_active_profile_and_appearance_are_accessible(self):
        self.assertEqual(self.client.get(reverse('profile')).status_code, 200)
        self.assertEqual(self.client.post(reverse('appearance_preferences'), {'theme':'dark'}).status_code, 200)
        pref = LearningPreferences.objects.get(user=self.user)
        self.assertEqual(pref.theme, 'dark')

    def test_suspended_session_cannot_read_profile_or_courses(self):
        self._suspend()
        self.assertEqual(self.client.get(reverse('profile')).status_code, 403)
        self.assertEqual(self.client.get(reverse('courses')).status_code, 403)

    def test_suspended_session_cannot_update_appearance(self):
        self._suspend()
        before = LearningPreferences.objects.filter(user=self.user).values_list('theme', flat=True).first()
        self.assertEqual(self.client.post(reverse('appearance_preferences'), {'theme':'dark'}).status_code, 403)
        after = LearningPreferences.objects.filter(user=self.user).values_list('theme', flat=True).first()
        self.assertEqual(before, after)

    def test_suspended_session_cannot_update_profile(self):
        self._suspend()
        self.assertEqual(self.client.post(reverse('profile'), {'avatar':'🎓','bio':'changed',
               'ui_language':'nl','daily_goal_xp':'20','preferred_language':self.english.pk}).status_code,403)
        self.assertEqual(Profile.objects.get(user=self.user).preferred_language_id, self.dutch.pk)

    def test_suspended_session_cannot_switch_course(self):
        self._suspend()
        self.assertEqual(self.client.post(reverse('course_switch',args=['en']), {'start':'A0'}).status_code, 403)
        self.assertEqual(Profile.objects.get(user=self.user).preferred_language_id, self.dutch.pk)

    def test_review_required_cannot_write_or_read_preferences(self):
        Profile.objects.filter(user=self.user).update(legacy_review_required=True)
        self.assertEqual(self.client.get(reverse('profile')).status_code,403)
        self.assertEqual(self.client.post(reverse('appearance_preferences'), {'theme':'light'}).status_code,403)
        self.assertEqual(self.client.post(reverse('course_switch',args=['en']), {'start':'A0'}).status_code,403)

    def test_direct_switch_helper_denies_revoked_account(self):
        self._suspend()
        with self.assertRaises(PermissionDenied):
            switch_course(self.user,self.english,start_at_a0=True)
        self.assertEqual(Profile.objects.get(user=self.user).preferred_language_id,self.dutch.pk)

    def test_normal_course_switch_remains_available(self):
        response=self.client.post(reverse('course_switch',args=['en']),{'start':'A0'})
        self.assertEqual(response.status_code,302)
        self.assertEqual(Profile.objects.get(user=self.user).preferred_language_id,self.english.pk)

    def test_regular_student_is_not_a_manager(self):
        self.assertEqual(self.client.get(reverse('manager')).status_code,403)

    def test_csrf_protection_still_blocks_state_changes(self):
        client=Client(enforce_csrf_checks=True)
        client.force_login(self.user)
        self.assertEqual(client.post(reverse('appearance_preferences'), {'theme':'dark'}).status_code,403)
        self.assertEqual(client.post(reverse('course_switch',args=['en']), {'start':'A0'}).status_code,403)

    def test_data_from_another_user_cannot_be_switched_via_url(self):
        stranger=get_user_model().objects.create_user('v45-second')
        other = Profile.objects.get(user=stranger)
        other.preferred_language=self.dutch
        other.save(update_fields=['preferred_language'])
        self.client.post(reverse('course_switch',args=['en']),{'start':'A0'})
        self.assertEqual(Profile.objects.get(user=stranger).preferred_language_id,self.dutch.pk)

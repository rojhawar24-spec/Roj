"""Django integration tests: run on the Windows environment with dependencies installed."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .models import Language, Level, Vocabulary, XPEvent, ReviewCard
from .platform_v13 import COPY


class PlatformV13Tests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            username='v13-learner', email='v13@example.test', password='SecureTestPassword!2026')
        cls.dutch = Language.objects.create(code='nl', name='Nederlands', slug='v13-nl', is_published=True)
        cls.french = Language.objects.create(code='fr', name='Français', slug='v13-fr', is_published=True)
        cls.hidden_language = Language.objects.create(code='xx', name='Hidden', slug='v13-hidden', is_published=False)
        cls.nl_level = Level.objects.create(language=cls.dutch, code='A0', order=0)
        cls.fr_level = Level.objects.create(language=cls.french, code='A0', order=0)
        cls.hidden_level = Level.objects.create(language=cls.hidden_language, code='A0', order=0)
        cls.nl_word = Vocabulary.objects.create(level=cls.nl_level, word='hallo', translation='hello',
            pronunciation='ha-lo', example='Hallo iedereen.', emoji='👋', published=True)
        cls.fr_word = Vocabulary.objects.create(level=cls.fr_level, word='bonjour', translation='hello',
            pronunciation='bon-zjoer', example='Bonjour.', emoji='👋', published=True)
        cls.hidden_word = Vocabulary.objects.create(level=cls.hidden_level, word='secretword', translation='hidden',
            pronunciation='secret', example='Hidden.', published=True)
        cls.unpublished_word = Vocabulary.objects.create(level=cls.nl_level, word='draftword', translation='draft',
            pronunciation='draft', example='Draft.', published=False)
        profile = cls.user.learning_profile
        profile.preferred_language = cls.dutch
        profile.ui_language = 'nl'
        profile.placement_completed = True
        profile.save()

    def setUp(self):
        self.client.force_login(self.user)

    def test_dashboard_is_one_hub_for_all_core_modules(self):
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code,200)
        for route in ('play_hub','learn_path','grammar_library','mistakes','word'):
            self.assertContains(response,reverse(route))
        self.assertContains(response,'hallo')
        self.assertNotContains(response,'bonjour')
        self.assertNotContains(response,'draftword')
        self.assertNotContains(response,'secretword')
        self.assertContains(response,'Alles om een taal te leren')

    def test_daily_page_shows_only_published_word_in_active_course(self):
        response = self.client.get(reverse('word'))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'hallo')
        for forbidden in ('bonjour','draftword','secretword'):
            self.assertNotContains(response,forbidden)
        self.assertContains(response,'Woord van de dag')

    def test_daily_word_uses_target_spelling_and_awards_once(self):
        wrong = self.client.post(reverse('word'), {'answer':'hello'})
        self.assertEqual(wrong.status_code, 200)
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())
        response = self.client.post(reverse('word'), {'answer':'hallo'})
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'+10 XP')
        self.assertEqual(XPEvent.objects.filter(user=self.user, reason='daily_word').count(),1)
        self.assertTrue(ReviewCard.objects.filter(user=self.user,vocabulary=self.nl_word).exists())

    def test_no_selected_course_never_displays_another_course_word(self):
        profile=self.user.learning_profile
        profile.preferred_language=None
        profile.save(update_fields=['preferred_language'])
        response=self.client.get(reverse('word'))
        self.assertEqual(response.status_code,200)
        self.assertNotContains(response,'bonjour')
        self.assertNotContains(response,'hallo')
        self.assertContains(response,reverse('courses'))

    def test_sorani_interface_is_present_with_RTL(self):
        profile=self.user.learning_profile
        profile.ui_language='ckb'
        profile.save(update_fields=['ui_language'])
        response=self.client.get(reverse('dashboard'))
        self.assertContains(response,'هەموو شتێک بۆ فێربوونی زمان')
        self.assertContains(response,'dir="rtl"')
        self.assertEqual(set(COPY['nl']),set(COPY['ckb']))

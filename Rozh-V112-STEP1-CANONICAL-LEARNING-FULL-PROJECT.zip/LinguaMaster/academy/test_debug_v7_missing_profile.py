"""Django integration regressions for accounts with missing Profile rows.

RUN ONLY with the isolated Django runner. These tests are not marked PASS until
an actual Django runtime executes them in a disposable database.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Profile


class MissingProfileAuthenticationTests(TestCase):
    def setUp(self):
        self.password = 'StrongSynthetic!94'
        self.user = get_user_model().objects.create_user(
            username='debug_v7_learner', email='debugv7@example.invalid',
            password=self.password,
        )
        Profile.objects.filter(user=self.user).delete()

    def test_valid_password_missing_profile_returns_controlled_denial(self):
        response = self.client.post(reverse('login'), {
            'email': self.user.email, 'password': self.password,
        })
        self.assertEqual(response.status_code, 403)
        self.assertFalse(Profile.objects.filter(user=self.user).exists())
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_logged_in_home_missing_profile_clears_session(self):
        self.client.force_login(self.user)
        response = self.client.get(reverse('home'))
        # The public homepage is available, but the invalid session is revoked.
        self.assertEqual(response.status_code, 200)
        self.assertNotIn('_auth_user_id', self.client.session)
        self.assertFalse(Profile.objects.filter(user=self.user).exists())

    def test_existing_login_session_missing_profile_clears_session(self):
        self.client.force_login(self.user)
        response = self.client.get(reverse('login'))
        self.assertRedirects(response, reverse('login'), fetch_redirect_response=False)
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_mfa_setup_missing_profile_fails_closed(self):
        self.client.force_login(self.user)
        response = self.client.get(reverse('mfa_setup'))
        self.assertRedirects(response, reverse('login'), fetch_redirect_response=False)
        self.assertFalse(Profile.objects.filter(user=self.user).exists())

    def test_privileged_missing_profile_cannot_sign_in(self):
        self.user.is_staff = True
        self.user.is_superuser = True
        self.user.save(update_fields=['is_staff', 'is_superuser'])
        response = self.client.post(reverse('login'), {
            'email': self.user.email, 'password': self.password,
        })
        self.assertEqual(response.status_code, 403)
        self.assertNotIn('_auth_user_id', self.client.session)
        self.assertFalse(Profile.objects.filter(user=self.user).exists())

"""Requires a REAL isolated Django DB: DO NOT claim these tests pass offline."""
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.test import Client, TestCase
from django.urls import reverse
from .privilege_session_v93 import SESSION_PRIVILEGE_KEY
from .models import Profile


class PrivilegeMutationRevocationIntegrationTests(TestCase):
    PASSWORD = 'V93-Clean-QA-Password-Not-Used-In-Production!'

    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username='v93_student', email='v93_student@example.invalid',
            password=self.PASSWORD)
        self.client = Client()
        self.client.force_login(self.user)

    def assert_session_revoked(self):
        response = self.client.get(reverse('dashboard'))
        self.assertIn(response.status_code, (301,302))
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_new_login_contains_fingerprint(self):
        self.assertEqual(len(self.client.session[SESSION_PRIVILEGE_KEY]),64)

    def test_unchanged_session_stays_authenticated(self):
        self.client.get(reverse('dashboard'))
        self.assertIn('_auth_user_id',self.client.session)

    def test_direct_orm_update_staff_grant_revokes_session(self):
        get_user_model().objects.filter(pk=self.user.pk).update(is_staff=True)
        self.assert_session_revoked()

    def test_direct_orm_update_superuser_grant_revokes_session(self):
        get_user_model().objects.filter(pk=self.user.pk).update(is_superuser=True)
        self.assert_session_revoked()

    def test_direct_group_membership_add_revokes_session(self):
        group = Group.objects.create(name='v93_qa_group')
        self.user.groups.add(group)  # deliberately bypass V92 owner actions
        self.assert_session_revoked()

    def test_direct_permission_add_revokes_session(self):
        permission = Permission.objects.order_by('pk').first()
        self.assertIsNotNone(permission)
        self.user.user_permissions.add(permission)
        self.assert_session_revoked()

    def test_group_permission_add_revokes_session(self):
        group = Group.objects.create(name='v93_qa_group')
        self.user.groups.add(group)
        self.client.force_login(self.user)
        permission = Permission.objects.order_by('pk').first()
        self.assertIsNotNone(permission)
        group.permissions.add(permission)
        self.assert_session_revoked()

    def test_group_rename_revokes_session(self):
        group = Group.objects.create(name='v93_qa_group')
        self.user.groups.add(group)
        self.client.force_login(self.user)
        Group.objects.filter(pk=group.pk).update(name='v93_renamed_group')
        self.assert_session_revoked()

    def test_pre_v93_session_without_fingerprint_is_revoked(self):
        session=self.client.session
        session.pop(SESSION_PRIVILEGE_KEY,None)
        session.save()
        self.assert_session_revoked()

    def test_anonymous_admin_redirect_has_security_headers(self):
        # Anonymous callers must be sent to login, not merely denied with any
        # of several unrelated status codes; the redirect must not be cached.
        response=Client().get('/secure-admin/')
        self.assertEqual(response.status_code,302)
        self.assertEqual(response['Location'],reverse('login'))
        self.assertIn('Content-Security-Policy',response)
        self.assertIn('X-Frame-Options',response)
        self.assertIn('no-store',response['Cache-Control'])

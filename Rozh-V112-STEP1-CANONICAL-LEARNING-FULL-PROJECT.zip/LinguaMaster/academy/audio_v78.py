"""V78: vetted, self-hosted clips take precedence over device text-to-speech.

No web calls, no API keys, no synthesis from incoming user text. Only offline,
editor-approved prerecorded assets may be returned to templates. Silence / missing
assets do not become fabricated audio. Interface and course locales are separate.
"""
import hashlib
import json
import re
from pathlib import Path

from django.contrib.staticfiles import finders
from django.templatetags.static import static

# This list is wider than the four currently published/seeded course languages:
# the additional locales are prepared, NOT promised to have any voice yet.
LANGUAGE_LOCALES = {
    'nl': 'nl-BE', 'en': 'en-GB', 'de': 'de-DE', 'fr': 'fr-FR',
    'uk': 'uk-UA', 'ar': 'ar', 'ckb': 'ckb', 'kmr': 'kmr-Arab', 'ku': 'kmr-Latn',
}
_AUDIO_ROOT = 'academy/audio-v78/clips/'
_CATALOG_FILE = Path(__file__).resolve().parent / 'static' / 'academy' / 'audio-v78' / 'catalog.json'
_DIGEST = re.compile(r'^[a-f0-9]{64}$')


def text_key(text, locale):
    """Full (non-truncated) hash of exact approved utterance and its language."""
    if not isinstance(text, str) or not text.strip() or len(text) > 2000:
        return ''
    if locale not in LANGUAGE_LOCALES:
        return ''
    return hashlib.sha256((locale + '\n' + text).encode('utf-8')).hexdigest()


def approved_audio_url(text, locale):
    """Fail closed: no catalog, mismatched metadata, or missing audio => no URL."""
    key = text_key(text, locale)
    if not key:
        return ''
    try:
        catalog = json.loads(_CATALOG_FILE.read_text(encoding='utf-8'))
        if catalog.get('format_version') != 1:
            return ''
        entry = catalog.get('clips', {}).get(key)
        if not isinstance(entry, dict) or entry.get('key') != key:
            return ''
        if entry.get('language') != locale or entry.get('reviewed') is not True or entry.get('audio_quality_review_required') is not False:
            return ''
        path = entry.get('path', '')
        if not isinstance(path, str) or not re.fullmatch(
            r'academy/audio-v78/clips/(?:nl|en|de|fr|uk|ar|ckb|kmr|ku)/[a-f0-9]{64}\.(?:mp3|wav)', path
        ):
            return ''
        if path not in (_AUDIO_ROOT + locale + '/' + key + '.mp3',
                        _AUDIO_ROOT + locale + '/' + key + '.wav'):
            return ''
        # Do not accept a catalog that points to files that were never produced.
        located = finders.find(path)
        if not located or not isinstance(located, str):
            return ''
        if not _DIGEST.fullmatch(entry.get('sha256', '')):
            return ''
        # Verify bytes too; an altered approved audio asset must fail closed.
        digest = hashlib.sha256()
        with open(located, 'rb') as source:
            for block in iter(lambda: source.read(1 << 20), b''):
                digest.update(block)
        if digest.hexdigest() != entry['sha256']:
            return ''
        return static(path)
    except (OSError, ValueError, TypeError, AttributeError):
        return ''

"""V30 Django integration tests — must run against a real test database."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from .dashboard_v30 import pick_worlds
from .models import Language,Level,Unit,Lesson,Exercise,LessonProgress,XPEvent
from .services import allowed_unit

class V30LearnerJourneyTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user=get_user_model().objects.create_user('v30user','v30@example.org','StrongPassword!2026')
        cls.language=Language.objects.create(code='nl',slug='v30-nl',name='Dutch',description='Dutch',is_published=True)
        cls.other=Language.objects.create(code='fr',slug='v30-fr',name='French',description='French',is_published=True)
        cls.level=Level.objects.create(language=cls.language,code='A0',order=0,description='A0')
        cls.unit=Unit.objects.create(level=cls.level,slug='v30-unit',title='My real first lesson',summary='Start',order=1,published=True)
        cls.lesson=Lesson.objects.create(unit=cls.unit,slug='v30-lesson',title='Welcome',skill='reading',content='Hallo',published=True)
        cls.exercise=Exercise.objects.create(lesson=cls.lesson,kind='mcq',prompt='Hello?',options=['Hallo','Nee'],answer='Hallo',explanation='Hallo')
        profile=cls.user.learning_profile
        profile.onboarding_completed=True
        profile.preferred_language=cls.language
        profile.placement_completed=False
        profile.save()

    def setUp(self):
        self.client.force_login(self.user)

    def test_no_direct_legacy_lesson_or_answer_before_placement(self):
        self.assertFalse(allowed_unit(self.user,self.unit))
        response=self.client.get(reverse('lesson',args=[self.lesson.pk]))
        self.assertEqual(response.status_code,302)
        response=self.client.post(reverse('lesson_answer',args=[self.lesson.pk]), {'exercise_id':self.exercise.pk,'answer':'Hallo'})
        self.assertEqual(response.status_code,403)
        self.assertFalse(LessonProgress.objects.filter(user=self.user).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user).exists())

    def test_other_selected_language_cannot_unlock_this_course(self):
        p=self.user.learning_profile
        p.placement_completed=True
        p.preferred_language=self.other
        p.save(update_fields=['placement_completed','preferred_language'])
        self.assertFalse(allowed_unit(self.user,self.unit))
        self.assertEqual(self.client.post(reverse('lesson_answer',args=[self.lesson.pk]), {'exercise_id':self.exercise.pk,'answer':'Hallo'}).status_code,403)

    def test_dashboard_can_resume_game_and_read_only(self):
        p=self.user.learning_profile
        p.placement_completed=True
        p.save(update_fields=['placement_completed'])
        response=self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'lm30-dashboard-shell')
        self.assertContains(response,reverse('journey_play',args=[self.unit.pk]))
        self.assertContains(response,'My real first lesson')
        self.assertEqual(LessonProgress.objects.filter(user=self.user).count(),0)
        self.assertEqual(XPEvent.objects.filter(user=self.user).count(),0)
        self.assertTrue(allowed_unit(self.user,self.unit))

    def test_locked_prerequisite_never_has_direct_learner_link(self):
        p=self.user.learning_profile
        p.placement_completed=True
        p.save(update_fields=['placement_completed'])
        later=Unit.objects.create(level=self.level,slug='v30-locked',title='Locked',summary='Locked',order=2,published=True)
        later.prerequisites.add(self.unit)
        Lesson.objects.create(unit=later,slug='v30-later-lesson',title='Later',skill='reading',content='Later',published=True)
        response=self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code,200)
        self.assertContains(response,'lm29-state-locked')
        self.assertNotContains(response,reverse('journey_play',args=[later.pk]))

    def test_anonymous_dashboard_redirected_to_login(self):
        self.client.logout()
        response=self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code,302)
        self.assertIn('login',response.url)

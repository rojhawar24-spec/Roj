"""Regression tests for the four failures/errors reported by the V17 Windows run.

Run: python manage.py test academy.test_v17_four_errors --verbosity 1
This file uses Django's normal isolated test database, not production data.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .journey_v11 import _challenges
from .models import Language, Level, Unit, Lesson, Exercise


class V17FourErrorsTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            username='fourfix-user', email='fourfix@example.org',
            password='SafeTestPassword!2026')
        cls.language = Language.objects.create(
            name='Dutch', code='nl', slug='fourfix-dutch', is_published=True)
        cls.level = Level.objects.create(language=cls.language, code='A0', order=0)
        cls.unit = Unit.objects.create(
            level=cls.level, slug='fourfix-greetings', title='Greetings',
            order=1, published=True)
        grammar = Lesson.objects.create(
            unit=cls.unit, slug='fourfix-grammar', title='Greetings',
            order=1, skill='grammar', audio_text='Hallo ik ben Sam.',
            content='Learn greetings', published=True)
        Exercise.objects.create(
            lesson=grammar, kind='mcq', prompt='Which is a greeting?',
            options=['Hallo', 'Nee'], answer='Hallo')
        profile = cls.user.learning_profile
        profile.placement_completed = True
        profile.onboarding_completed = True
        profile.preferred_language = cls.language
        profile.ui_language = 'nl'
        profile.save()

    def setUp(self):
        self.client.force_login(self.user)

    def test_v13_dashboard_title_is_visible_in_nl(self):
        page = self.client.get(reverse('dashboard'))
        self.assertEqual(page.status_code, 200)
        self.assertContains(page, 'Alles om een taal te leren')

    def test_v13_dashboard_title_is_visible_in_sorani(self):
        profile = self.user.learning_profile
        profile.ui_language = 'ckb'
        profile.save(update_fields=['ui_language'])
        page = self.client.get(reverse('dashboard'))
        self.assertEqual(page.status_code, 200)
        self.assertContains(page, 'هەموو شتێک بۆ فێربوونی زمان')
        self.assertContains(page, 'dir="rtl"')

    def test_v11_path_has_expected_level_label_and_play_url(self):
        page = self.client.get(reverse('play_hub'))
        self.assertEqual(page.status_code, 200)
        self.assertContains(page, 'Level 1')
        self.assertContains(page, reverse('journey_play', args=[self.unit.pk]))

    def test_v102_word_order_uses_authored_tokens_without_synthetic_wordbank(self):
        lesson = self.unit.lessons.first()
        Exercise.objects.create(lesson=lesson,kind='word_order',prompt='Order the words.',
            options=['Hallo','ik','ben','Sam.'],answer='Hallo ik ben Sam.',explanation='Review word order.')
        rounds = _challenges(self.unit, '0123456789abcdef0123456789abcdef')
        banks = [q for q in rounds if q['type'] == 'word_order']
        self.assertEqual(len(banks),1)
        self.assertEqual(len(banks[0]['tokens']),4)
        self.assertEqual({tile['text'] for tile in banks[0]['tokens']},{'Hallo','ik','ben','Sam.'})
        self.assertNotIn('wordbank',{q['type'] for q in rounds})

"""Step 3F live HTTP/SQLite tests. Written but NOT run without installed Django.

They must be executed against Django's disposable QA database before release.
"""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .heart_models import HeartBalance, HeartEvent
from .models import (Language, Level, Unit, Lesson, Exercise,
                     MistakeRecord, LessonProgress, Profile, XPEvent)


class Step3FAtomicClassicLessonHTTPTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = get_user_model().objects.create_user(
            username='step3f-learner', password='Step3fSynthetic!357')
        cls.language = Language.objects.create(
            code='en', name='Step 3F English', slug='step3f-english',
            description='QA only', is_published=True)
        cls.level = Level.objects.create(language=cls.language, code='A0',
                                         order=0, description='QA beginner')
        cls.unit = Unit.objects.create(level=cls.level, slug='step3f-unit',
            title='Step 3F QA', summary='Disposable DB test', published=True)
        cls.lesson = Lesson.objects.create(unit=cls.unit, slug='step3f-lesson',
            title='Step 3F QA lesson', skill='grammar', published=True,
            content='Synthetic questions, never public learning content')
        cls.first = Exercise.objects.create(lesson=cls.lesson, kind='mcq', options=['yes','no'],
            prompt='Question one', answer='yes', explanation='Synthetic explanation', order=1)
        cls.second = Exercise.objects.create(lesson=cls.lesson, kind='mcq', options=['yes','no'],
            prompt='Question two', answer='yes', explanation='Synthetic explanation', order=2)
        Profile.objects.filter(user=cls.user).update(
            preferred_language=cls.language, placement_completed=True,
            onboarding_required=False, onboarding_completed=True,
            suspended_at=None, legacy_review_required=False)

    def setUp(self):
        self.client.force_login(self.user)
        self.url = reverse('lesson', args=[self.lesson.pk])
        resp = self.client.get(self.url)
        self.assertEqual(resp.status_code, 200)
        self.round = resp.context['lesson_round_key']
        HeartBalance.objects.update_or_create(user=self.user,
            defaults={'remaining': 1, 'regenerated_at': timezone.now()})

    def submit(self, a, b):
        return self.client.post(self.url, {
            'round_key': self.round,
            f'answer_{self.first.pk}': a,
            f'answer_{self.second.pk}': b})

    def test_insufficient_hearts_rejects_without_any_partial_debits_or_mistakes(self):
        res = self.submit('no', 'no')
        self.assertEqual(res.status_code, 402)
        balance = HeartBalance.objects.get(user=self.user)
        self.assertEqual(balance.remaining, 1)
        self.assertFalse(HeartEvent.objects.filter(user=self.user, kind='answer').exists())
        self.assertFalse(MistakeRecord.objects.filter(user=self.user).exists())
        self.assertFalse(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())
        self.assertFalse(XPEvent.objects.filter(user=self.user, reason='lesson').exists())

    def test_rejected_batch_can_retry_and_complete_with_new_valid_answers(self):
        self.assertEqual(self.submit('no', 'no').status_code, 402)
        result = self.submit('yes', 'yes')
        self.assertEqual(result.status_code, 200)
        self.assertTrue(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())
        self.assertEqual(HeartBalance.objects.get(user=self.user).remaining, 1)
        self.assertFalse(HeartEvent.objects.filter(user=self.user,kind='answer').exists())

    def test_replayed_precharged_answer_is_rejected_without_mutation(self):
        HeartEvent.objects.create(user=self.user,
            key=f'answer:lesson:{self.lesson.pk}:round:{self.round}:question:{self.first.pk}',
            kind='answer', delta=-1)
        res = self.submit('no', 'yes')
        self.assertEqual(res.status_code, 409)
        self.assertEqual(HeartBalance.objects.get(user=self.user).remaining, 1)
        self.assertFalse(MistakeRecord.objects.filter(user=self.user).exists())
        self.assertFalse(LessonProgress.objects.filter(user=self.user,lesson=self.lesson).exists())

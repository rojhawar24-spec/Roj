"""Read-only five-kind mixed round preparation. Never discard required content."""
from .curriculum_policy_v99 import AUTO_GRADED_LEER_SPEEL_KINDS
from .lesson_activities_v58 import student_ready, validate_activity


def canonical_exercise_block_reason(row, course_code):
    """One canonical question admission rule; old kinds remain stored, not playable."""
    if row.kind not in AUTO_GRADED_LEER_SPEEL_KINDS:
        return 'activity'
    if row.kind == 'mcq':
        return 'activity' if canonical_mcq_errors(row.prompt, row.options, row.answer,
                       row.explanation, getattr(row, 'activity_data', {})) else None
    if not student_ready(row, course_code):
        return 'audio' if row.kind == 'listening' else 'activity'
    return None


def canonical_lesson_block_reason(lesson, exercises, course_code, *, audio_lookup):
    """One admission rule for navigation, classic, mixed and editorial checks."""
    rows = list(exercises)
    if lesson.skill == 'listening' and not audio_lookup(lesson.audio_text, course_code):
        return 'audio'
    if not rows:
        return 'activity'
    for row in rows:
        reason = canonical_exercise_block_reason(row, course_code)
        if reason:
            return reason
    return None


def mixed_block_reason(lessons, exercises, course_code, *, audio_lookup):
    """Return a reason before a round is created or graded; no partial rounds."""
    if not lessons:
        return 'activity'
    by_lesson = {lesson.pk: [] for lesson in lessons}
    for row in exercises:
        if row.lesson_id not in by_lesson:
            return 'activity'
        by_lesson[row.lesson_id].append(row)
    for lesson in lessons:
        reason = canonical_lesson_block_reason(lesson, by_lesson[lesson.pk], course_code,
                                               audio_lookup=audio_lookup)
        if reason:
            return reason
    return None


def editorial_kind_choices(choices, existing_kind=None):
    """New authored items have five choices; an old item remains editable in place."""
    allowed = set(AUTO_GRADED_LEER_SPEEL_KINDS)
    if existing_kind:
        allowed.add(existing_kind)
    return [(value, label) for value, label in choices if value == '' or value in allowed]


def publication_has_canonical_exercises(kinds):
    kinds = tuple(kinds)
    return bool(kinds) and all(kind in AUTO_GRADED_LEER_SPEEL_KINDS for kind in kinds)


def canonical_mcq_errors(prompt, options, answer, explanation, data):
    """Legacy MCQs may omit feedback, but never have an invalid choice key."""
    errors = validate_activity('mcq', prompt, options, answer, explanation, data)
    optional = 'Write a useful explanation for feedback (at most 2000 characters).'
    if isinstance(explanation, str) and not explanation.strip():
        errors = [message for message in errors if message != optional]
    return errors

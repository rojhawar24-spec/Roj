"""Private, minimal results from photo vocabulary practice; no uploaded photos."""
from django.conf import settings
from django.db import models
from django.utils import timezone


class PhotoAttempt(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name='photo_attempts')
    language = models.ForeignKey('academy.Language',on_delete=models.CASCADE)
    image_key = models.CharField(max_length=20)
    correct = models.BooleanField(default=False)
    round_key = models.CharField(max_length=100,unique=True)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        indexes=[models.Index(fields=['user','language','created_at'],name='photo_user_course_idx')]

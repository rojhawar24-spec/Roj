"""Five hearts: regenerate one per 30 minutes; never accept client balances."""
from datetime import timedelta
from math import ceil

from django.db import transaction
from django.utils import timezone

from .heart_models import HeartBalance, HeartEvent

CAPACITY = 5
REGENERATION_MINUTES = 30
INTERVAL = timedelta(minutes=REGENERATION_MINUTES)


class HeartEmpty(Exception):
    def __init__(self, state):
        super().__init__('No lesson hearts remain.')
        self.state = state


def _balance_locked(user, now):
    balance, _ = HeartBalance.objects.get_or_create(user=user, defaults={'regenerated_at': now})
    balance = HeartBalance.objects.select_for_update().get(pk=balance.pk)
    changed = []
    # A skewed future anchor must not freeze a learner's timer indefinitely.
    if balance.regenerated_at > now:
        balance.regenerated_at = now
        changed.append('regenerated_at')
    if balance.remaining < CAPACITY:
        intervals = max(0, int((now - balance.regenerated_at) // INTERVAL))
        if intervals:
            balance.remaining = min(CAPACITY, balance.remaining + intervals)
            balance.regenerated_at = now if balance.remaining == CAPACITY else balance.regenerated_at + intervals * INTERVAL
            changed = ['remaining', 'regenerated_at']
    if changed:
        balance.save(update_fields=changed)
    return balance


def _state(balance, now):
    missing = CAPACITY - balance.remaining
    next_at = balance.regenerated_at + INTERVAL if missing else None
    full_at = balance.regenerated_at + missing * INTERVAL if missing else None
    next_seconds = max(0, ceil((next_at - now).total_seconds())) if next_at else 0
    return {
        'remaining': balance.remaining, 'capacity': CAPACITY,
        'next_in_seconds': next_seconds,
        'next_at': next_at.isoformat() if next_at else None,
        'full_at': full_at.isoformat() if full_at else None,
        'regeneration_minutes': REGENERATION_MINUTES,
        'empty': balance.remaining == 0, 'full': balance.remaining == CAPACITY,
    }


def snapshot(user):
    """Read current hearts, persisting only initialization or elapsed regeneration."""
    now = timezone.now()
    with transaction.atomic():
        balance = _balance_locked(user, now)
        return _state(balance, now)


def spend_for_answer(user, event_key):
    """Debit a validated wrong answer once; callers must grade before calling."""
    if not isinstance(event_key, str) or not event_key or len(event_key) > 150:
        raise ValueError('A bounded server-generated heart event key is required.')
    key = 'answer:' + event_key
    now = timezone.now()
    empty_state = None
    with transaction.atomic():
        balance = _balance_locked(user, now)
        if HeartEvent.objects.filter(user=user, key=key).exists():
            return {**_state(balance, now), 'spent': False}
        if balance.remaining == 0:
            empty_state = _state(balance, now)
        else:
            if balance.remaining == CAPACITY:
                balance.regenerated_at = now
            balance.remaining -= 1
            balance.save(update_fields=['remaining', 'regenerated_at'])
            HeartEvent.objects.create(user=user, key=key, kind='answer', delta=-1, created_at=now)
            return {**_state(balance, now), 'spent': True}
    # Raise after leaving the transaction, retaining legitimate timer updates.
    raise HeartEmpty(empty_state)


def recover_for_mistake(user, mistake):
    """Recover at most one heart per owned, corrected mistake, including reopened ones."""
    from .models import MistakeRecord
    if not MistakeRecord.objects.filter(pk=mistake.pk, user=user, corrected_at__isnull=False).exists():
        raise ValueError('Only an owned, corrected mistake can recover a heart.')
    now = timezone.now()
    key = f'mistake:{mistake.pk}'
    with transaction.atomic():
        balance = _balance_locked(user, now)
        if HeartEvent.objects.filter(user=user, key=key).exists():
            return {**_state(balance, now), 'recovered': False}
        recovered = balance.remaining < CAPACITY
        if recovered:
            balance.remaining += 1
            if balance.remaining == CAPACITY:
                balance.regenerated_at = now
            balance.save(update_fields=['remaining', 'regenerated_at'])
        # Even at capacity, consume the one-time recovery eligibility.
        HeartEvent.objects.create(user=user, key=key, kind='recovery', delta=int(recovered), created_at=now)
        return {**_state(balance, now), 'recovered': recovered}

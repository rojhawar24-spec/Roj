"""V20 STEP7 Django HTTP smoke tests — run ONLY against a disposable Django TEST database.

Execute in a fresh extracted ZIP with config.settings_local_qa:
  python manage.py test academy.test_v20_step7_auth_smoke --noinput -v 2

Django TestCase creates its own temporary test database; these tests never need
live Stripe/AI/SMTP or an existing learner database. Not validated by an
offline-only source audit.
"""
import pyotp
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.cache import cache
from django.test import Client, TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from .manager_roles_v48 import MANAGER_GROUP
from .models import Language, LessonProgress, XPEvent

User = get_user_model()


@override_settings(REQUIRE_EMAIL_VERIFICATION=False)
class Step7RealHttpAuthSmokeTests(TestCase):
    PASSWORD = 'Step7-Only-Unique-Password-2026!'
    MFA_SECRET = 'JBSWY3DPEHPK3PXP'

    @classmethod
    def setUpTestData(cls):
        cls.course = Language.objects.create(
            name='Dutch', code='nl', slug='step7-dutch',
            description='Temporary smoke-test course', is_published=True,
        )
        cls.student = User.objects.create_user(
            'step7_student', 'step7student@example.invalid', cls.PASSWORD,
        )
        student_profile = cls.student.learning_profile
        student_profile.preferred_language = cls.course
        student_profile.placement_completed = True
        student_profile.onboarding_completed = True
        student_profile.onboarding_required = False
        student_profile.email_verified_at = timezone.now()
        student_profile.save()

        cls.manager = User.objects.create_user(
            'step7_manager', 'step7manager@example.invalid', cls.PASSWORD,
        )
        manager_profile = cls.manager.learning_profile
        manager_profile.email_verified_at = timezone.now()
        manager_profile.totp_secret = cls.MFA_SECRET
        manager_profile.save()
        manager_group, _ = Group.objects.get_or_create(name=MANAGER_GROUP)
        cls.manager.groups.add(manager_group)

    def setUp(self):
        cache.clear()

    def test_student_real_password_login_and_learning_page(self):
        response = self.client.post(reverse('login'), {
            'email': self.student.username, 'password': self.PASSWORD,
        })
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse('play_hub'))
        self.assertEqual(int(self.client.session['_auth_user_id']), self.student.pk)
        page = self.client.get(reverse('play_hub'))
        self.assertEqual(page.status_code, 200)
        self.assertEqual(XPEvent.objects.filter(user=self.student).count(), 0)
        self.assertEqual(LessonProgress.objects.filter(user=self.student).count(), 0)
        self.assertIn('no-store', page.get('Cache-Control', ''))

    def test_student_cannot_gain_manager_access_with_forged_session_flag(self):
        self.client.force_login(self.student)
        session = self.client.session
        session['mfa_verified_id'] = self.student.pk
        session.save()
        for name in ('manager', 'manager_users', 'manager_audit'):
            with self.subTest(name=name):
                self.assertEqual(self.client.get(reverse(name)).status_code, 403)
        self.assertEqual(self.client.get('/secure-admin/').status_code, 302)

    def test_manager_password_alone_never_opens_manager(self):
        response = self.client.post(reverse('login'), {
            'email': self.manager.username, 'password': self.PASSWORD,
        })
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse('mfa_verify'))
        self.assertEqual(self.client.session['pending_mfa_user_id'], self.manager.pk)
        self.assertNotIn('_auth_user_id', self.client.session)
        self.assertEqual(self.client.get(reverse('manager')).status_code, 302)
        self.assertEqual(self.client.get('/secure-admin/').status_code, 302)

    def test_manager_mfa_proves_role_and_role_revocation_blocks_access(self):
        first = self.client.post(reverse('login'), {
            'email': self.manager.username, 'password': self.PASSWORD,
        })
        self.assertEqual(first.status_code, 302)
        code = pyotp.TOTP(self.MFA_SECRET).now()
        second = self.client.post(reverse('mfa_verify'), {'code': code})
        self.assertEqual(second.status_code, 302)
        self.assertEqual(second.url, reverse('manager'))
        self.assertEqual(self.client.session.get('mfa_verified_id'), self.manager.pk)
        self.assertEqual(self.client.get(reverse('manager')).status_code, 200)
        self.assertEqual(self.client.get('/secure-admin/').status_code, 302)
        self.manager.groups.clear()
        self.assertEqual(self.client.get(reverse('manager')).status_code, 403)
        self.assertEqual(self.client.get(reverse('manager_users')).status_code, 403)

    def test_cross_site_login_post_rejected_without_csrf(self):
        browser = Client(enforce_csrf_checks=True)
        self.assertEqual(browser.get(reverse('login')).status_code, 200)
        response = browser.post(reverse('login'), {
            'email': self.student.username, 'password': self.PASSWORD,
        })
        self.assertEqual(response.status_code, 403)
        self.assertNotIn('_auth_user_id', browser.session)

    def test_wrong_password_does_not_create_login_session(self):
        response = self.client.post(reverse('login'), {
            'email': self.student.username, 'password': 'wrong_password',
        })
        self.assertIn(response.status_code, (200, 403, 429))
        self.assertNotIn('_auth_user_id', self.client.session)

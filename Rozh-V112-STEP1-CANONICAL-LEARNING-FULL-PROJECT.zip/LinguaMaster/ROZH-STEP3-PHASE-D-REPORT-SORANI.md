# Rozh — هەنگاوی ٣، بەشی D (V95)

**بەشی D لە offline و Chromium تاقیکراوە، نەک Django HTTP/SQLite. هەنگاوی ٣ هێشتا تەواو نییە.**

## کێشەی سەرەکی

Django Manager پێشتر ڕێگەی دەدا وانەیەکی draft کە تێیدا ١٣-جۆری چالاکیی ناتەواو هەبوو بکرێتە published. قوتابی لە ڕێگای `/lessons/` دەتوانی HTTP 409 ببینێت. Django Admin ـیش لە فورمی Exerciseدا بۆ MCQ/short پشکنینی ڕێکخراوی وەڵامەکانی Manager ـی نەکردبوو.

## چاککردنەوەکان

1. `academy/lesson_activities_v58.py`: فانکشنی هاوبەشی `published_lesson_activity_errors` دۆخی داتای هەموو چالاکییە نوێیەکان دەپشکنێت، بەتایبەتی Matching pairs، tile order، وێنەی ناوخۆ، `image_alt` و Listening ـی دەنگی پەسەندکراو. `mcq` و `short` بە شێوازی کۆنی خۆیان ماونەوە و لەم پێش‌پشکنینەدا دووبارە هەڵسەنگاندن ناکرێن.
2. `academy/manager_content_v48.py`: نوێکردنەوە یان بڵاوکردنەوەی وانەیەک کە تێیدا چالاکییە نوێیەک هەڵەی هەیە ڕەت دەکرێتەوە، پێش گۆڕینی DB. Draft ـەکە دەکرێت چاک بکرێت.
3. `academy/admin.py`: فورمی Django Admin بۆ Lesson هەمان publication gate بەکاردەهێنێت؛ فورمی Exercise ـی Admin MCQ/short ـیش هەمان سەرەکییەکانی وەڵامی نادروست و ئاپشنەکان دەپشکنێت.
4. `scripts/test_step3d_publish_guard_offline.py`: ١٢ تاقیکردنەوەی unit/contract، لەوانە fixture بۆ هەموو ١٣ جۆر، داتای ناتەواو، دەنگی نەپەسەندکراو و ڕێگای هەردوو editor.
5. `academy/test_step3d_published_activity_editor_http.py`: ٤ تاقیکردنەوەی Django TestCase ـی نوێ تۆمارکراون، **بەڵام ڕانەکراون**؛ پێویستیان بە Django و SQLite ـی جیاکراوەی QA هەیە.

## ئەنجامی پشکنینی ئێستا

- ١٦/١٦ کۆمەڵەی تاقیکردنەوەی offline/Chromium و ١٤٧/١٤٧ حاڵەتی ژمێردراو: PASS.
- ٦١٦ فایلی Python AST و ٤٣ فایلی JavaScript `node --check`: هیچ هەڵەی syntax نەدۆزرایەوە.
- ZIP ـی پاک، فایلەکان بە SHA-256، migration ـەکان پارێزراون، هیچ DB/.env/.venv ـی ڕاستەقینە نییە.

## هێشتا ماوە

- Django HTTP و SQLite Integration، تاقیکردنەوەی ئەنجامی ڕاستەقینە لە قوتابی، پشکنینی زمانەکان بە مرۆڤ، و پەسەندکردنی قوتابخانە/production.
- هەنگاوی ٢ هێشتا بەهۆی نەکراوەی تاقیکردنەوەی Django بە تەواو پشتڕاست نەکراوە.

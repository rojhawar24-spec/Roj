# Non-destructive Django test runner. Uses a dedicated Django test DB,
# NOT the normal Rozh db.sqlite3. Stop the webserver before running.
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
# Never permit a full test run from a folder containing real local data.
foreach ($blocked in @('.env', 'db.sqlite3', '.env.production')) {
    if (Test-Path -LiteralPath (Join-Path $PSScriptRoot $blocked)) {
        throw "REFUSED: $blocked detected. Extract the QA ZIP to a NEW empty folder."
    }
}
$env:ROZH_LOCAL_QA_ONLY = '1'
$env:DJANGO_SETTINGS_MODULE = 'config.settings_local_qa'
$env:DJANGO_DEBUG = '1'
$env:USE_SQLITE = '1'
$env:SITE_URL = 'http://127.0.0.1:3000'
$env:DJANGO_ALLOWED_HOSTS = '127.0.0.1,localhost,testserver'
$env:EMAIL_BACKEND = 'django.core.mail.backends.filebased.EmailBackend'
$env:REQUIRE_EMAIL_VERIFICATION = '0'
# Never inherit live API/SMTP/Stripe/Redis secrets in this disposable QA test run.
foreach ($key in @('AI_API_KEY', 'STRIPE_SECRET_KEY', 'STRIPE_WEBHOOK_SECRET', 'BUILD_STATIC_MANIFEST', 'TRUST_PROXY', 'EMAIL_HOST', 'EMAIL_HOST_PASSWORD', 'REDIS_URL', 'REDIS_CACHE_URL', 'REDIS_BROKER_URL')) {
    Remove-Item -Path ("Env:" + $key) -ErrorAction SilentlyContinue
}
$python = Join-Path $PSScriptRoot '.venv-qa\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $python)) { throw 'Run START-ROZH-TEST.ps1 first.' }
& $python manage.py test academy --verbosity 2
if ($LASTEXITCODE -ne 0) { throw "QA tests failed (exit code $LASTEXITCODE)." }
Write-Host '[OK] Django tests passed. This does not certify production.'

# Windows PowerShell 5.1+; ONLY isolated .rozh-local-test SQLite.
# Default = read-only audit. -Apply = explicit unpublish of unready listening.
param([switch]$Apply)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
foreach ($blocked in @('.env', '.env.local', 'db.sqlite3', 'db.sqlite3-wal', 'db.sqlite3-shm', '.env.production')) {
    if (Test-Path -LiteralPath (Join-Path $PSScriptRoot $blocked)) {
        throw "REFUSED: $blocked present. This command may run ONLY in a separate QA project folder."
    }
}
$python = Join-Path $PSScriptRoot '.venv-qa\Scripts\python.exe'
$qaRoot = Join-Path $PSScriptRoot '.rozh-local-test'
$db = Join-Path $qaRoot 'rozh-test.sqlite3'
if (-not (Test-Path -LiteralPath $python -PathType Leaf)) { throw 'Run START-ROZH-TEST.ps1 in this isolated folder first.' }
if (-not (Test-Path -LiteralPath $db -PathType Leaf)) { throw 'Isolated QA SQLite database not found. No production DB will be used.' }
# Process-only QA settings, aligned with START-ROZH-TEST.ps1.
$env:ROZH_LOCAL_QA_ONLY = '1'
$env:DJANGO_SETTINGS_MODULE = 'config.settings_local_qa'
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:DJANGO_DEBUG = '1'
$env:USE_SQLITE = '1'
$env:REQUIRE_EMAIL_VERIFICATION = '0'
$env:SITE_URL = 'http://127.0.0.1:3000'
$env:DJANGO_ALLOWED_HOSTS = '127.0.0.1,localhost,testserver'
$env:EMAIL_BACKEND = 'django.core.mail.backends.filebased.EmailBackend'
foreach ($key in @('DATABASE_URL', 'POSTGRES_URL', 'POSTGRES_DB', 'POSTGRES_USER', 'POSTGRES_PASSWORD', 'POSTGRES_HOST', 'POSTGRES_PORT',
                   'PGHOST', 'PGPORT', 'PGUSER', 'PGPASSWORD', 'PGDATABASE', 'POSTGRES_SSLROOTCERT',
                   'AI_API_KEY', 'OPENAI_API_KEY', 'STRIPE_SECRET_KEY', 'STRIPE_WEBHOOK_SECRET',
                   'BUILD_STATIC_MANIFEST', 'TRUST_PROXY', 'EMAIL_HOST', 'EMAIL_HOST_PASSWORD', 'EMAIL_HOST_USER',
                   'EMAIL_PORT', 'EMAIL_USE_SSL', 'EMAIL_USE_TLS', 'REDIS_URL', 'REDIS_CACHE_URL', 'REDIS_BROKER_URL')) {
    Remove-Item -Path ('Env:' + $key) -ErrorAction SilentlyContinue
}
& $python manage.py check
if ($LASTEXITCODE -ne 0) { throw 'Django config check failed; QA DB untouched.' }
if ($Apply) {
    # Stop local server before backing up. A live SQLite WAL is deliberately refused.
    foreach ($suffix in @('-wal', '-shm')) {
        if (Test-Path -LiteralPath ($db + $suffix)) {
            throw 'Stop START-ROZH-TEST.ps1 (Ctrl+C) first; active SQLite WAL/SHM detected.'
        }
    }
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
    $backup = Join-Path $qaRoot ("V96-BEFORE-LISTENING-REPAIR-$stamp.sqlite3")
    if (Test-Path -LiteralPath $backup) { throw 'Backup target exists; no changes made.' }
    $backupCode = 'import sqlite3,sys; source=sqlite3.connect(sys.argv[1]); target=sqlite3.connect(sys.argv[2]); source.backup(target); target.close(); source.close()'
    & $python -c $backupCode $db $backup
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $backup -PathType Leaf)) {
        throw 'SQLite backup failed; repair not started.'
    }
    Write-Host "QA backup created: $backup"
    & $python manage.py repair_listening_publication --apply
} else {
    Write-Host 'READ-ONLY AUDIT; nothing will be changed.'
    & $python manage.py repair_listening_publication
}
if ($LASTEXITCODE -ne 0) { throw 'Listening QA audit or repair failed. Inspect output; do not assume success.' }
Write-Host 'Done. No lesson audio was fabricated or automatically approved.'

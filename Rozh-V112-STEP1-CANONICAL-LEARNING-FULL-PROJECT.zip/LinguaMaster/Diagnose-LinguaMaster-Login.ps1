﻿# Read-only local authentication diagnostic. Never paste your password into chat or command arguments.
[CmdletBinding()]
param([switch]$VerifyPassword)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
. (Join-Path $PSScriptRoot 'scripts\Set-LinguaMasterLocalEnv.ps1')
$python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
    throw 'Python virtual environment missing. Install LinguaMaster first.'
}
[string[]]$argsForPython = @('manage.py','diagnose_local_login')
if ($VerifyPassword) { $argsForPython += '--verify-password' }
& $python @argsForPython
if ($LASTEXITCODE -ne 0) { throw "Local diagnosis failed (exit $LASTEXITCODE)." }

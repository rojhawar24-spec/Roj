# Rozh V57 — Visual Grammar System: 100 Componenten

**Scope:** uitbreiding van herbruikbare visuele uitleg voor bestaande en toekomstige grammaticaonderwerpen; geen nieuwe lessen gepubliceerd.

## Belangrijke architectuur

- **100 herkenbare componenttypes in 10 categorieën**, gebouwd boven op **10 veilige renderlay-outs**. De 100 zijn dus geen 100 volledig onafhankelijke JavaScript-apps, maar 100 benoemde lesvormen die een consistent visueel systeem delen.
- De **42 bestaande V17-types blijven leesbaar** en oudere artikelen migreren niet verplicht.
- Elke `GrammarArticle.content` in Django JSONField bewaart alleen de gebruikte componenten. Er is geen limiet van 100 lessen of 100 seizoenen; de artikelen zijn per grammaticaonderwerp opgeslagen.
- De beheerder kan **per artikel maximaal 24 visuele blokken** aanmaken (bestaand beveiligingslimiet) en kiest wat relevant is. Geen 100 kaarten tegelijk in de leerlingpagina.
- Nieuwe inhoud moet de auteur zelf schrijven en opslaan; de V57-managereditor voegt **geen nepvragen, voorbeeldtekst of automatisch gepubliceerde lessen** toe.
- Alle velden worden gebonden en gevalideerd via `rich_schema.normalize_article`; Django output escapt HTML. Geen inline author-HTML, externe afbeeldingen, API, audio, XP of databasewijzigingen.
- Voor alle bestaande Grammatica A0–C1-cursussen: dezelfde componentbibliotheek, ongeacht de taal van de inhoud. Gebruik `dir=auto` waar mogelijk; ook Sorani/Arabisch is ondersteund.

## Alle 100 componenten

| Nr. | Categorie | Naam | Type ID | Layout |
|---:|---|---|---|---|
| 1 | Cards & Callout Blocks | Regelkaart | `rule_card` | `note` |
| 2 | Cards & Callout Blocks | Onthoud-blok | `remember_block` | `note` |
| 3 | Cards & Callout Blocks | Tipkaart | `tip_card` | `note` |
| 4 | Cards & Callout Blocks | Infokaart | `info_card` | `note` |
| 5 | Cards & Callout Blocks | Voorbeeldkaart | `example_card` | `note` |
| 6 | Cards & Callout Blocks | Waarschuwingskaart | `warning_card` | `note` |
| 7 | Cards & Callout Blocks | Uitzonderingskaart | `exception_card` | `note` |
| 8 | Cards & Callout Blocks | Veelgemaakte-foutkaart | `common_error_card` | `note` |
| 9 | Cards & Callout Blocks | Correctiekaart | `correction_card` | `note` |
| 10 | Cards & Callout Blocks | Samenvattingskaart | `summary_card` | `note` |
| 11 | Colors & Highlights | Color-coded Sentences | `color_coded_sentence` | `tokens` |
| 12 | Colors & Highlights | Keyword Highlight | `keyword_highlight` | `tokens` |
| 13 | Colors & Highlights | Verb Highlight | `verb_highlight` | `tokens` |
| 14 | Colors & Highlights | Subject Highlight | `subject_highlight` | `tokens` |
| 15 | Colors & Highlights | Object Highlight | `object_highlight` | `tokens` |
| 16 | Colors & Highlights | Sentence Chunking | `sentence_chunking` | `tokens` |
| 17 | Colors & Highlights | Color Legend | `color_legend` | `tokens` |
| 18 | Colors & Highlights | Underline Annotation | `underline_annotation` | `tokens` |
| 19 | Colors & Highlights | Grammar Tags | `grammar_tags` | `tokens` |
| 20 | Colors & Highlights | Word Group Highlight | `word_group_highlight` | `tokens` |
| 21 | Grammar Tables | Grammaticatabel | `grammar_table` | `table` |
| 22 | Grammar Tables | Conjugation Table | `conjugation_table` | `table` |
| 23 | Grammar Tables | Verb Forms Table | `verb_forms_table` | `table` |
| 24 | Grammar Tables | Pronoun Table | `pronoun_table` | `table` |
| 25 | Grammar Tables | Article Table | `article_table` | `table` |
| 26 | Grammar Tables | Singular / Plural Table | `singular_plural_table` | `table` |
| 27 | Grammar Tables | Tense Comparison Table | `tense_comparison_table` | `table` |
| 28 | Grammar Tables | Word Order Table | `word_order_table` | `table` |
| 29 | Grammar Tables | Exception Table | `exception_table` | `table` |
| 30 | Grammar Tables | Quick Reference Table | `quick_reference_table` | `table` |
| 31 | Diagrams & Schemas | Word Order Diagram | `word_order_diagram` | `tokens` |
| 32 | Diagrams & Schemas | Sentence Structure Diagram | `sentence_structure_diagram` | `tokens` |
| 33 | Diagrams & Schemas | Sentence Breakdown | `sentence_breakdown` | `tokens` |
| 34 | Diagrams & Schemas | Grammar Flowchart | `grammar_flowchart` | `steps` |
| 35 | Diagrams & Schemas | Decision Tree | `decision_tree` | `steps` |
| 36 | Diagrams & Schemas | Mind Map | `mind_map` | `steps` |
| 37 | Diagrams & Schemas | Tree Diagram | `tree_diagram` | `steps` |
| 38 | Diagrams & Schemas | Arrow Diagram | `arrow_diagram` | `steps` |
| 39 | Diagrams & Schemas | Sentence Pattern Diagram | `sentence_pattern_diagram` | `tokens` |
| 40 | Diagrams & Schemas | Grammar Relationship Map | `grammar_relationship_map` | `steps` |
| 41 | Timelines | Verb Timeline | `verb_timeline` | `steps` |
| 42 | Timelines | Past–Present–Future Timeline | `past_present_future_timeline` | `steps` |
| 43 | Timelines | Tense Timeline | `tense_timeline` | `steps` |
| 44 | Timelines | Continuous Action Timeline | `continuous_action_timeline` | `steps` |
| 45 | Timelines | Completed Action Timeline | `completed_action_timeline` | `steps` |
| 46 | Timelines | Event Sequence Diagram | `event_sequence_diagram` | `steps` |
| 47 | Timelines | Time Marker Chart | `time_marker_chart` | `steps` |
| 48 | Timelines | Duration Diagram | `duration_diagram` | `steps` |
| 49 | Timelines | Frequency Scale | `frequency_scale` | `steps` |
| 50 | Timelines | Tense Overview | `tense_overview` | `steps` |
| 51 | Comparisons | Before / After | `before_after` | `compare` |
| 52 | Comparisons | Correct vs Incorrect | `correct_vs_incorrect` | `compare` |
| 53 | Comparisons | Side-by-Side Comparison | `side_by_side_comparison` | `compare` |
| 54 | Comparisons | Translation Comparison | `translation_comparison` | `compare` |
| 55 | Comparisons | Formal vs Informal | `formal_informal` | `compare` |
| 56 | Comparisons | Singular vs Plural | `singular_vs_plural` | `compare` |
| 57 | Comparisons | Positive vs Negative | `positive_vs_negative` | `compare` |
| 58 | Comparisons | Question vs Statement | `question_vs_statement` | `compare` |
| 59 | Comparisons | Similar Rules Comparison | `similar_rules_comparison` | `compare` |
| 60 | Comparisons | Common Mistakes Gallery | `common_mistakes_gallery` | `compare` |
| 61 | Explanation Blocks | Learning Objective | `learning_objective` | `note` |
| 62 | Explanation Blocks | Simple Rule Explanation | `simple_rule_explanation` | `note` |
| 63 | Explanation Blocks | Step-by-Step Explanation | `step_by_step_explanation` | `steps` |
| 64 | Explanation Blocks | Detailed Rule Explanation | `detailed_rule_explanation` | `note` |
| 65 | Explanation Blocks | Grammar Formula | `grammar_formula` | `tokens` |
| 66 | Explanation Blocks | Rule Breakdown | `rule_breakdown` | `steps` |
| 67 | Explanation Blocks | Pattern Explanation | `pattern_explanation` | `note` |
| 68 | Explanation Blocks | Exception Explorer | `exception_explorer` | `note` |
| 69 | Explanation Blocks | Grammar Definition | `grammar_definition` | `note` |
| 70 | Explanation Blocks | Key Point Summary | `key_point_summary` | `note` |
| 71 | Examples & Context | Example Sentence | `example_sentence` | `note` |
| 72 | Examples & Context | Translated Example | `translated_example` | `compare` |
| 73 | Examples & Context | Contextual Example | `contextual_example` | `note` |
| 74 | Examples & Context | Everyday Usage Card | `everyday_usage_card` | `note` |
| 75 | Examples & Context | Sentence Breakdown Card | `sentence_breakdown_card` | `tokens` |
| 76 | Examples & Context | Grammar in Context | `grammar_in_context` | `note` |
| 77 | Examples & Context | Meaning Comparison | `meaning_comparison` | `compare` |
| 78 | Examples & Context | Usage Note | `usage_note` | `note` |
| 79 | Examples & Context | Multiple Examples Grid | `multiple_examples_grid` | `table` |
| 80 | Examples & Context | Real-Life Sentence Card | `real_life_sentence_card` | `note` |
| 81 | Remember & Review | Remember This | `remember_this` | `note` |
| 82 | Remember & Review | Golden Rule | `golden_rule` | `note` |
| 83 | Remember & Review | Memory Trick | `memory_trick` | `note` |
| 84 | Remember & Review | Mnemonic Card | `mnemonic_card` | `note` |
| 85 | Remember & Review | Key Takeaway | `key_takeaway` | `note` |
| 86 | Remember & Review | Cheat Sheet | `cheat_sheet` | `table` |
| 87 | Remember & Review | Rule Recap | `rule_recap` | `note` |
| 88 | Remember & Review | Important Reminder | `important_reminder` | `note` |
| 89 | Remember & Review | Pattern Recognition Guide | `pattern_recognition_guide` | `tokens` |
| 90 | Remember & Review | Mini Summary | `mini_summary` | `note` |
| 91 | Interactive Explanation UI | Accordion Explanation | `accordion_explanation` | `accordion` |
| 92 | Interactive Explanation UI | Expandable Rule | `expandable_rule` | `accordion` |
| 93 | Interactive Explanation UI | Tooltip | `tooltip` | `tooltip` |
| 94 | Interactive Explanation UI | Grammar Tabs | `grammar_tabs` | `tabs` |
| 95 | Interactive Explanation UI | Flip Card | `flip_card` | `flip` |
| 96 | Interactive Explanation UI | Interactive Word Highlight | `interactive_word_highlight` | `tokens` |
| 97 | Interactive Explanation UI | Clickable Sentence Breakdown | `clickable_sentence_breakdown` | `tokens` |
| 98 | Interactive Explanation UI | Visual Grammar Glossary | `visual_grammar_glossary` | `glossary` |
| 99 | Interactive Explanation UI | Expandable Example | `expandable_example` | `accordion` |
| 100 | Interactive Explanation UI | Rule Explorer | `rule_explorer` | `tabs` |

## Veilig JSON-schema per lay-out

| Layout | Vereiste velden |
|---|---|
| `note` | `type`, `title`, `body` |
| `tokens` | `type`, `title`, `tokens: [{text, role}]` |
| `table` | `type`, `title`, `columns: [text]`, `rows: [[text]]`, optional `note` |
| `compare` | `type`, `title`, `left`, `right`, optional `explanation` |
| `steps` | `type`, `title`, `items: [text]`, optional `note` |
| `accordion` | `type`, `title`, `entries: [{title, body}]` |
| `tabs` | `type`, `title`, `entries: [{title, body}]` |
| `glossary` | `type`, `title`, `entries: [{title, body}]` |
| `flip` | `type`, `title`, `front`, `back` |
| `tooltip` | `type`, `title`, `term`, `definition` |

Tokenrollen zijn beperkt tot `subject`, `verb`, `object`, `time`, `place`, `connector`, `other`. Tabs en glossary vereisen ten minste 2 items. Accordions vereisen 1 item. Tabellen bevatten maximaal 6 kolommen en 24 rijen. Velden accepteren alleen platte tekst; URL’s, scripts, CSS en willekeurige objectvelden worden afgewezen.

## Werken met de Manager

1. Open een bestaand of nieuw grammaticaonderwerp in de beveiligde Manager/Django Admin. Kies het bijbehorende gepubliceerde niveau en de juiste cursus.
2. Bij Visual grammar article: zoek op componentnaam, of filter de categorie. Kies de vorm en vul *jouw* titel en leerinhoud in.
3. Controleer de kleine live preview. Klik **Toevoegen aan les**; het blok verschijnt in het bestaande JSONField, maar is **nog niet opgeslagen**.
4. Bewaar met de reeds bestaande Django Admin-knop. Publiceer het onderwerp pas nadat je alle leerinhoud hebt gecontroleerd.
5. De leerling ziet uitsluitend de blokken van dat specifieke onderwerp; oudere onderwerpen zonder V57-blokken blijven zoals ze waren.

## Korte JSON-voorbeeldstructuur (alleen documentatie, niet in de database)

```json
{
  "visual_blocks": [
    {
      "type": "rule_card",
      "title": "De regel",
      "body": "Use am with I, is with she/he/it, are with you/we/they."
    },
    {
      "type": "grammar_tabs",
      "title": "Compare forms",
      "entries": [
        {
          "title": "I",
          "body": "I am happy."
        },
        {
          "title": "She",
          "body": "She is happy."
        }
      ]
    }
  ]
}
```

## Operationele aandachtspunten

- Voorafgaand aan productie: voer Django-tests, migratiechecks, echte admin-save, bestaande lesson/XP flows en account-/autorisatiechecks in de Windows/Docker-omgeving uit.
- Laat voor Sorani/Arabische lessen een moedertaalspreker de tekst en directionele volgorde controleren.
- Gebruik in Manager liever niet alle 24 blokken tegelijk. Visuele uitleg moet de les korter en begrijpelijker maken.
- V57 heeft **geen** AI API, geen betaalfunctie, geen nieuwe audio-/spreekcomponenten en geen automatische contentcreatie.

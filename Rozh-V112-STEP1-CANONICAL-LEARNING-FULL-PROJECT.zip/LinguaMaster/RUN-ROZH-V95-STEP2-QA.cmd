@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN-ROZH-V95-STEP2-QA.ps1" %*
exit /b %ERRORLEVEL%

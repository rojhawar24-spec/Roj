# Rozh — هەنگاوی ٣، بەشی F (V95)

**دۆخ: Phase F لە تاقیکردنەوەی offline/Chromium سەرکەوتووە. Django HTTP/Database هێشتا تاقی نەکراوە. هەنگاوی ٣ تەواو نییە.**

## کێشەی دۆزراوە

لە ڕێگای فۆڕمی کۆنی وانە (`lesson_detail` / SSR)، ئەگەر فێرخواز چەند وەڵامی هەڵە بنێرێت و لە ناو هەمان ناردندا دڵەکانی تەواو بن، وەڵامی HTTP 402 دەدرایەوە، بەڵام توانای ئەوە هەبوو کەمکردنەوەی دڵ و هەندێک MistakeRecord ـی پێشوو لە داتابەیس بمێننەوە. هۆکارەکە گەڕانەوە/شکاندنی loop لە ناو `transaction.atomic()` بوو؛ ئەوە بەخۆی savepoint rollback ناکات.

## چاککردنەوەکان

1. `academy/lesson_batch_step3f.py`: نمرەدانی هەموو وەڵامەکانی SSR بە فانکشنی تاقیکراوە جیاکراوەتەوە. کەمی دڵ یان دوبارە debit ـی هەمان Round بە exception ـی تایبەت نیشان دەدرێت.
2. `academy/views.py`: فانکشنەکە لەناو `transaction.atomic()` ـی ناوخۆیی جێبەجێ دەکرێت. Exception ـەکان **لە دەرەوەی savepoint** دەگیرێن، بۆ ئەوەی هەموو کەمکردنەوەی دڵ و تۆماری هەڵەی نیوەچڵ rollback بکرێت؛ 402 بۆ کەمی دڵ و 409 بۆ replay.
3. `scripts/test_step3f_atomic_batch_offline.py`: ١٠ تاقیکردنەوەی ڕاستەوخۆی فانکشنی کۆد بە داتابەیسی ساختەی transactional، لەوانە کەمی دڵ، replay، rollback ـی هەڵە، و نمرەی درست.
4. `academy/test_step3f_ssr_batch_atomic_http.py`: ٣ تاقیکردنەوەی Django TestCase بۆ SQLite ـی جیاکراوە، **هێشتا ڕانەکراون**.
5. `scripts/test_v40_classic_lesson_admission_offline.py`: مەرجی کۆنی بەستنەوەی `admission` پێش هەر debit/mistake هەر پارێزراوە؛ تاقیکردنەوەکە ئێستا شوێنی فانکشنی نوێ دەگرێت.

## ئەنجامی بەڵگەدار

- ١٨/١٨ کۆمەڵەی offline/Chromium؛ ١٦٦/١٦٦ تاقیکردنەوە: PASS.
- ٦٢٠ فایلی Python بە AST و ٤٣ فایلی JavaScript بە `node --check`: بێ هەڵەی syntax.
- ZIP ـی پاک لە کۆپییەکی تازەدا بەراوردی SHA-256 و دووبارە regression پشکنین دەکرێت.
- `python manage.py check --settings=config.settings_local_qa`: **FAIL** بە `ModuleNotFoundError: No module named 'django'`؛ Django HTTP/Database **NOT RUN**.

## هێشتا ماوە

- ئەنجامی ڕاستەقینەی Django TestCase ـە نوێکان و هەموو academy regression لە SQLite؛ پاشان PostgreSQL ئەگەر پڕۆدکشن بەکاری بهێنێت.
- پشکنینی هەموو ١٣ چالاکی لە Browser، دەستگەیشتنەوە، زمانەکان و داتای ڕاستەقینەی فێرخواز.
- هیچ DB/.env/.venv ـی ڕاستەقینە یان ZIP ـی کۆن لەم ZIP ـەدا نییە؛ بۆ قوتابخانە/production پەسەند نەکراوە.

**ئەم ZIP ـە تەنها Phase F ـی پڕۆژەی تەواوە، نەک پەسەندکردنی کۆتاییی هەنگاوی ٣ یان هەنگاوی ٢.**

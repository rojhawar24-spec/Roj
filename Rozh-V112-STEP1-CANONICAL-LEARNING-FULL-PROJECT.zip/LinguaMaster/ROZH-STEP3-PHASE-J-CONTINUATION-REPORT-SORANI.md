# Rozh — هەنگاوی ٣، بەشی J (بەردەوامی، QA Isolation)

**ژمارەی بەشە ماوەکان: ٣ = J، K، L.** J هێشتا داخراو نییە؛ پاش J دوو بەش ماون. لە کۆی ١٠ هەنگاوی سەرەکی، ئێستا لە هەنگاوی ٣ داین، و ٧ هەنگاوی سەرەکی دوای ئەمە ماون. هەنگاوی ٢یش هێشتا تەواوی پشکنینی Django ـی نییە.

## کێشەی پێش چاککردنەوە

- فۆڵدەری هەبووی `.rozh-local-test` بە POSIX mode ـی `0755` یان `0777` دەتوانرا قبوڵ بکرێت؛ ئەمە ڕێگە دەدات بە خوێندنەوە یان دەستکاریی ناو QA لەلایەن ئەکاونتی تری سیستمەکە.
- `settings_local_qa.py` فۆڵدەری نامەکانی تاقیکردنەوە بە ڕێگای `QA_ROOT / 'emails'` بەکاردەهێنا، بەبێ ئەوەی پێشتر پشکنینی symlink/permissions بۆ ئەو فۆڵدەرە بکات. Mail backend ـی فایل دەتوانێت symlink ـێکی لە پێشدا دانراو بەدوادا بچێت و نامەی تاقیکردنەوە لە دەرەوەی QA root بنووسێت.

## چی چاککرا

- `config/qa_filesystem_safety.py`: فۆڵدەری QA و mailbox دەبێت real directory بن؛ symlink/junction ڕەت دەکرێت، لە POSIX مالکەکە دەبێت هەمان بەکارهێنەر بێت و مۆڵەتەکان owner-only بن.
- `config/settings_local_qa.py`: بە `create_local_qa_mailbox(QA_ROOT)` فۆڵدەری QA mail پێش بەکارهێنان بە شێوەی پارێزراو ئامادە دەکرێت؛ لە شکستی پشکنین، Django QA startup ڕەت دەکرێت.
- ٨ تاقیکردنەوەی نوێی ڕاستەوخۆی filesystem، و زیادکردنیان بۆ Windows QA runner و GitHub Actions.
- `ROZH-STEP3-FIXED-REMAINING-STEPS.json`: پێشکەوتنی بەشی J نوێکرایەوە، بەبێ گۆڕینی ژمارەی ماوەکان.

## بەڵگە

پێش چاککردنەوە: تاقیکردنەوەی نوێ شکستی هێنا (root mode و maildir protection). دوای چاککردنەوە: **٨/٨ پاس**. لەگەڵ ٣٧٣ تاقیکردنەوەی پێشوو، کۆی **٣٨١/٣٨١ Offline/Browser** لە **٣٣ کۆمەڵە** تێپەڕیوە. هاشەکان و دووبارە ڕانکردنی کۆپیی تازە لە فایلێکی Verification ـی دەرەکی تۆمار دەکرێت.

**نەکراوە:** Django `manage.py check`, migration 0019، Django HTTP/SQLite و PostgreSQL concurrency لەم ژینگەیەدا، چونکە Django و psycopg دانەمەزراون. تەنانەت تاقیکردنەوەی offline ـی سەرکەوتووش جێگرەوەی ئەم بەڵگەیانە نییە. لە Windows ـدا native ACL ـەکان بە تایبەتی پشتڕاست نەکراون.

**حکمی ئێستا:** Phase J **ناتەواو**؛ هەنگاوی ٣ **ناتەواو**؛ School/Production **پەسەند نەکراوە**. 

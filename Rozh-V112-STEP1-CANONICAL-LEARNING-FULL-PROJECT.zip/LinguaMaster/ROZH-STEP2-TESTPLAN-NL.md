# Rozh V95 — stap 2 QA-kandidaat (NIET goedgekeurd)

Dit pakket is **geen V96-release** en **geen bewijs dat Django-tests zijn geslaagd**.
De broncode en migraties zijn gebaseerd op V95; alleen testcode en de
geïsoleerde QA-voorzieningen zijn aangescherpt.

## Wat moet echt slagen?

1. De exact gespecificeerde Django- en andere Python-afhankelijkheden installeren.
2. `manage.py check`, gevolgd door `makemigrations --check --dry-run`.
3. Gerichte Django HTTP/SQLite-tests van Login, MFA, Manager, CSRF, Session en toegang.
4. De volledige `academy` Django-regressiesuite (niet alleen de selectieve securitytests).
5. Daarna op een echte geïsoleerde stagingomgeving: live browser, PostgreSQL,
   concurrency, caching, externe systemen en privacy/security-review.

Een groene offline-test is **niet** gelijk aan (3)-(5). Een groene GitHub Action
verifieert uitsluitend de gedraaide suite op disposable SQLite; niet productie.

## A. Windows (uitgepakte kopie, zonder privébestanden)

Open PowerShell in `LinguaMaster` en voer uit:

```powershell
cmd /c .\RUN-ROZH-V95-STEP2-QA.cmd
```

Er wordt alleen `.venv-qa` plus `.rozh-local-test` voor testgebruik gebruikt.
De runner weigert een bestaande `.env` en `db.sqlite3`. De tests hebben een
internetverbinding nodig voor het installeren van de officiële dependencies.
Een niet-nul exitcode is **niet geslaagd**. Stuur dan alleen de foutoutput,
zonder echte sleutels of gegevens van leerlingen.

## B. GitHub Actions (alternatief wanneer lokaal Django niet installeert)

Gebruik een **privé-repository** met de inhoud van de map `LinguaMaster` als
repository-root (dus `manage.py` direct bovenaan). Publiceer nooit `.env`,
`.rozh-local-test`, echte databases of sleutels. Open GitHub → Actions →
`Rozh Step 2 - isolated Django/SQLite QA` → Run workflow. De workflow wordt
niet automatisch uitgevoerd, vereist geen repositorysecrets en schrijft alleen
naar een tijdelijke testdatabase binnen de runner.

De workflow is in dit bouwmilieu **niet gedraaid**. Ook een succesvolle run zou
nog geen PostgreSQL-, MFA-apparaat-, real-browser- of productiecertificering zijn.

## Specifieke technische wijzigingen in dit QA-kandidaat

- Oude Manager-test bijgewerkt: na role revocation moet een bestaande sessie
  verdwijnen en naar Login omleiden, niet enkel 403 tonen.
- QA settings weigeren geërfde externe database-, SMTP-, proxy- en AI-gegevens
  vóór import van standaard settings.
- Test-TOTP-sleutel wordt nieuw aangemaakt met POSIX mode 0600.
- Celery wordt naar memory broker en eager uitvoering geforceerd.
- Windows QA-runner wist geërfde mail/static/proxy-instellingen en voert na
  de gerichte Django-suite de volledige `academy` suite uit.
- Er zijn lokale broncontroles toegevoegd; die bewijzen géén Django HTTP-gedrag.

**Stap 2 blijft OPEN** tot de echte uitvoer geanalyseerd, fouten opgelost en
alle noodzakelijke browser- en databasecontroles gedaan zijn.

## Hervatte STEP 2 — volledige academy-suite zonder vals groen

De brede Django-suite draait voortaan met
`--testrunner=scripts.step2_full_regression_gate.Step2FullRegressionRunner`
op zowel Windows als de Linux-CI-runner. Deze runner controleert expliciet dat
16 kritieke Login/MFA/Manager/Session/CSRF/API-HTTP-testmodules daadwerkelijk
zijn **verzameld** en de gehele academy-collectie is **uitgevoerd**. Een lege,
onvolledige of onverwacht overgeslagen testsuite krijgt **geen PASS**.

De volledige academy-suite onder SQLite bevat **precies vijf** bewust overgeslagen
PostgreSQL-only concurrencytests. De runner staat *uitsluitend* die vijf exacte
cases met hun expliciete reden toe, omdat hun echte PostgreSQL-uitvoering apart
in de CI-job `django-postgres-concurrency` wordt afgedwongen.

`python scripts/test_step2_full_regression_gate_offline.py` controleert het gedrag
van deze runner zonder Django. De offline-check bewijst niet dat de echte
Django-regressiesuite groen is. **STEP 2 blijft OPEN** tot de echte volledige
Django/SQLite, browser, migratie en de benodigde andere runtimecontroles zijn
uitgevoerd en beoordeeld.

## V95 / stap 2 — binding van wachtwoordfase aan MFA-challenge

Een MFA-pending sessie krijgt voortaan een opaque hash van de door Django
ondertekende gebruikers-auth-hash, account-state-revisie en effectieve
permissie-fingerprint. Voor de MFA-GET/POST en opnieuw binnen de database
rijvergrendeling moet de huidige toestand overeenkomen met die van de
wachtwoordfase. Na wachtwoordreset, account-revisie of rechtenwijziging wordt
de oude pending challenge geweigerd en uit de sessie verwijderd. Alleen
de geslaagde password-login of een reeds geauthenticeerd MFA-continuatiepad
mag de binding aanmaken. Dit verandert geen productieaccount of database.

Nieuwe Django HTTP-scenario's: `academy.test_step2_pending_mfa_binding_http`
(**NOT RUN** in de bouwomgeving). Pure-Python tests en isolated view
behavior tests zijn wel offline uitgevoerd. De 5 eerder benoemde runtime QA
onderdelen van stap 2 blijven OPEN.


## V95 – MFA-factorinventaris aan lopende wachtwoordchallenge koppelen (stap 2)

- De MFA-proof bindt nu de TOTP-secret en de gehashte herstelcodeset, naast
  wachtwoordauthenticatie, accountrevisie en effectieve bevoegdheden.
- Een geheimrotatie, nieuwe herstelcodes of elders verbruikte herstelcode
  maakt een wachtende MFA-challenge ongeldig en vereist opnieuw aanmelden.
- De volgorde van herstelcode-hashes maakt niet uit; ongeldige opslag van
  tweede-factorstatus wordt fail-closed afgewezen.
- De proof is een HMAC onder Django's sleutelafgeleide session-auth hash;
  er worden geen factor-geheimen aan de browsersessie toegevoegd.
- Offline: `python scripts/test_step2_pending_mfa_binding_offline.py` (16 tests).
- Echte Django HTTP-tests staan in
  `academy.test_step2_pending_mfa_binding_http` (8 tests), **NIET UITGEVOERD**
  in de huidige omgeving. Verplicht onderdeel van CI/Windows QA.
- Stap 2 en fase J blijven OPEN tot alle echte runtime-gates slagen.


## V95 — Herstelcode met dubbele hash eenmalig verbruiken (stap 2)

- Vastgesteld via bronanalyse: de oude MFA-verificatie deed bij een match
  `remaining.remove(digest)`, waardoor een dubbele hash in een beschadigde
  of legacy recovery-code-lijst kon achterblijven voor hergebruik.
- Nieuwe pure helper `academy/recovery_code_consumption_step2.py` verifieert
  exact 16 hex-tekens en digestopslag, vergelijkt elk element met HMAC-SHA256
  en verwijdert **alle** identieke matches atomair via bestaande Profile-rijlock.
- Ongewijzigde en niet-passende hashes blijven intact. Ongeldige opslag
  en foute codes leveren geen MFA-succes op; geen plaintext codes in logs.
- TDD: nieuw offline script faalde eerst wegens ontbrekende helper, na fix
  11/11 regressietests PASS; totaal 36 scripts / 377 getelde tests PASS.
- Twee echte Django/SQLite HTTP-tests in
  `academy.test_step2_recovery_duplicates_http` zijn **NIET UITGEVOERD**.
  Vereist in GitHub Actions/Windows doelgericht en in volledige academysuite.
- Beoordeling: Step 2 OPEN; Phase J OPEN; production NOT APPROVED.


## Stap 2 finale preflight — corrupte MFA-factorinventaris en live Chromium-gate

Een ongeldige recovery-hashlijst laat de drie pending-MFA-startpunten nu
fail-closed antwoorden in plaats van een verwachte RuntimeError als HTTP 500
terug te geven. Een anonieme wachtwoordlogin geeft een generieke 403 zonder
authsessie; bestaande ingelogde gebruikers worden uitgelogd en naar login
teruggestuurd. Onverwachte code-/databasefouten worden NIET onderdrukt.

Django HTTP-tests `academy.test_step2_malformed_mfa_inventory_http` zijn
opgenomen in gerichte én volledige suites; niet lokaal uitgevoerd. CI voert
nu ook `scripts.step2_live_browser_qa` uit tegen een ECHTE Django LiveServer
met Chromium (360px NL/EN, Sorani RTL, keyboard, CSRF login, MFA, sessierotatie)
vóór de Linux-runtime-evidence-receipt. Hiervoor installeert CI een tijdelijk
Playwright-pakket en browser; geen productie-afhankelijkheid.

LET OP: geen 100% acceptatie zonder echte dependency-installatie, Django/DB
regressie, Chromium, PostgreSQL, Windows ACL en handmatige accessibility en
staging review. 39 offline scripts/403 getelde checks zijn niet hetzelfde.

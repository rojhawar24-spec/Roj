"""Disposable LOCAL ONLY Rozh QA settings.

Never use for a public deployment. All database writes use a dedicated SQLite
file; the ordinary db.sqlite3 and production PostgreSQL remain untouched.
"""
import os
from pathlib import Path
import secrets
from django.core.exceptions import ImproperlyConfigured

if os.environ.get('ROZH_LOCAL_QA_ONLY') != '1':
    raise ImproperlyConfigured('Rozh QA requires ROZH_LOCAL_QA_ONLY=1.')
if os.environ.get('DJANGO_DEBUG') != '1' or os.environ.get('USE_SQLITE') != '1':
    raise ImproperlyConfigured('Rozh QA requires DEBUG=1 and USE_SQLITE=1.')
if os.environ.get('SITE_URL') != 'http://127.0.0.1:3000':
    raise ImproperlyConfigured('Rozh QA may run on http://127.0.0.1:3000 only.')
if os.environ.get('DJANGO_ALLOWED_HOSTS') != '127.0.0.1,localhost,testserver':
    raise ImproperlyConfigured('Rozh QA must use loopback hosts only.')

# Fail BEFORE importing ordinary settings: those settings parse SMTP,
# database, proxy and static-build environment variables. An inherited
# production configuration must never be used by an isolated QA run.
FORBIDDEN_QA_ENV = (
    'DATABASE_URL', 'POSTGRES_URL', 'POSTGRES_DB', 'POSTGRES_USER',
    'POSTGRES_PASSWORD', 'POSTGRES_HOST', 'POSTGRES_PORT', 'PGHOST',
    'PGUSER', 'PGPASSWORD', 'PGDATABASE', 'REDIS_URL', 'REDIS_BROKER_URL',
    'REDIS_CACHE_URL', 'EMAIL_HOST', 'EMAIL_HOST_PASSWORD',
    'EMAIL_HOST_USER', 'AI_API_KEY', 'OPENAI_API_KEY', 'STRIPE_SECRET_KEY',
    'STRIPE_WEBHOOK_SECRET', 'TRUST_PROXY', 'POSTGRES_SSLROOTCERT',
)
if any(os.environ.get(name) for name in FORBIDDEN_QA_ENV):
    raise ImproperlyConfigured('Rozh QA refuses inherited production service credentials or endpoints.')
if os.environ.get('EMAIL_BACKEND', '') not in ('', 'django.core.mail.backends.filebased.EmailBackend'):
    raise ImproperlyConfigured('Rozh QA refuses inherited nonlocal EMAIL_BACKEND.')
if os.environ.get('BUILD_STATIC_MANIFEST') == '1':
    raise ImproperlyConfigured('Rozh QA refuses production static manifest mode.')

from .settings import *  # noqa: F401,F403 - controlled local derivation

if not DEBUG:
    raise ImproperlyConfigured('Rozh QA refuses DEBUG=0.')

from .qa_filesystem_safety import (
    QAFileSafetyError, create_local_qa_root, create_local_qa_mailbox,
    load_or_create_local_qa_secret, create_local_qa_database_file,
)
try:
    QA_ROOT = create_local_qa_root(BASE_DIR)
except QAFileSafetyError as exc:
    raise ImproperlyConfigured(str(exc)) from exc
try:
    QA_DB = create_local_qa_database_file(QA_ROOT)
except (QAFileSafetyError, OSError) as exc:
    raise ImproperlyConfigured('QA database file is not safely isolated.') from exc
NORMAL_DB = (BASE_DIR / 'db.sqlite3').resolve()
if QA_DB == NORMAL_DB or QA_DB.parent != QA_ROOT:
    raise ImproperlyConfigured('QA database path is not isolated.')
try:
    QA_SECRET = load_or_create_local_qa_secret(QA_ROOT)
    QA_MAIL_DIR = create_local_qa_mailbox(QA_ROOT)
except (QAFileSafetyError, OSError, UnicodeError) as exc:
    raise ImproperlyConfigured('Could not securely load isolated QA key.') from exc
SECRET_KEY = QA_SECRET
LINGUAMASTER_TOTP_KEY = QA_SECRET

DATABASES = {'default': {'ENGINE': 'django.db.backends.sqlite3', 'NAME': QA_DB}}
SITE_URL = 'http://127.0.0.1:3000'
ALLOWED_HOSTS = ['127.0.0.1', 'localhost', 'testserver']
REQUIRE_EMAIL_VERIFICATION = False
AI_API_KEY = ''  # No paid AI calls in offline QA.
# Keep test mail within the local disposable directory; no SMTP delivery.
MAILERS = {'default': {'BACKEND': 'django.core.mail.backends.filebased.EmailBackend',
                       'OPTIONS': {'file_path': str(QA_MAIL_DIR)}}}
# No external Redis service required in QA.
CACHES = {'default': {'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
                      'LOCATION': 'rozh-qa-local-only'}}
CELERY_BROKER_URL = 'memory://'
CELERY_RESULT_BACKEND = None
CELERY_TASK_ALWAYS_EAGER = True
CELERY_TASK_EAGER_PROPAGATES = True

# Force development defaults regardless of existing shell proxy settings.
SECURE_SSL_REDIRECT = False
SESSION_COOKIE_SECURE = False
CSRF_COOKIE_SECURE = False
SECURE_HSTS_SECONDS = 0
SECURE_PROXY_SSL_HEADER = None

"""Local V50 migration rehearsal: never use the user's original SQLite database."""
from .settings import *  # noqa: F401,F403 -- preserve actual project settings and secrets
from django.core.exceptions import ImproperlyConfigured
from pathlib import Path
from urllib.parse import urlsplit
import os

_provided = os.environ.get('ROZH_V50_SANDBOX_DB', '').strip()
if not _provided:
    raise ImproperlyConfigured('V50 sandbox database path missing; refusing to use the original database.')
_sandbox = Path(_provided).expanduser().resolve()
_original = (BASE_DIR / 'db.sqlite3').resolve()
_site = urlsplit(SITE_URL)
if (not DEBUG or os.environ.get('USE_SQLITE') != '1' or
        _site.scheme != 'http' or _site.hostname not in ('127.0.0.1', 'localhost') or
        _sandbox.name != 'rozh-v50-sandbox.sqlite3' or _sandbox == _original or
        _original in _sandbox.parents or not _sandbox.is_file()):
    raise ImproperlyConfigured('V50 rehearsal requires a separate existing sandbox.sqlite3 under local DEBUG+loopback.')
DATABASES = {'default': {'ENGINE': 'django.db.backends.sqlite3', 'NAME': _sandbox}}

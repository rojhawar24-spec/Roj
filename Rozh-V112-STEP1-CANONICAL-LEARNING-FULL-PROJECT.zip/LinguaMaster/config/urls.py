from django.contrib import admin
from django.urls import include, path
from academy.views import site_sitemap
urlpatterns = [
    path('secure-admin/', admin.site.urls),
    path('api/', include('academy.api_urls')),
    path('', include('academy.urls')),
]
admin.site.site_header = 'Rozh secure content management'
admin.site.site_title = 'Rozh'

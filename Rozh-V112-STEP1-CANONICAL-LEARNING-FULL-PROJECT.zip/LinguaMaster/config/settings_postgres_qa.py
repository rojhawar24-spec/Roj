"""Disposable PostgreSQL CI QA ONLY; never point this at customer data.

Inherits the pre-import service/credential refusal and local-only overrides from
settings_local_qa; only the database backend is changed for transaction tests.
A fixed loopback host and fixed disposable database/user mean a supplied
DATABASE_URL, PGHOST or production service cannot redirect this connection.
"""
import os
from django.core.exceptions import ImproperlyConfigured

if os.environ.get('GITHUB_ACTIONS') != 'true' or os.environ.get('ROZH_PG_QA_ONLY') != '1':
    raise ImproperlyConfigured('PostgreSQL QA may run ONLY in opted-in GitHub Actions.')
qa_password = os.environ.get('ROZH_QA_PG_PASSWORD', '')
if len(qa_password) < 18 or qa_password.strip() != qa_password:
    raise ImproperlyConfigured('An ephemeral CI-only PostgreSQL password is required.')

from .settings_local_qa import *  # noqa: F401,F403 - includes production-service refusal

# Never substitute environment-supplied remote connection settings.
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'rozh_qa_step3',
        'USER': 'rozh_qa',
        'PASSWORD': qa_password,
        'HOST': '127.0.0.1',
        'PORT': '5432',
        'CONN_MAX_AGE': 0,
        'OPTIONS': {'connect_timeout': 5},
        'TEST': {'NAME': 'test_rozh_qa_step3'},
    }
}
# Only the same disposable mail/cache/AI/no-proxy configuration as local QA.

"""Secure settings: fail closed in production; SQLite only when explicitly requested."""
import os
from pathlib import Path
from urllib.parse import urlparse
from django.core.exceptions import ImproperlyConfigured

BASE_DIR = Path(__file__).resolve().parent.parent
DEBUG = os.environ.get('DJANGO_DEBUG', '0') == '1'
# On production, email ownership is mandatory regardless of a stray env override.
# Locally the default is OFF so an unconfigured SMTP server never locks learners out.
# Invalid values must not quietly disable a required security control.
_require_email_raw = os.environ.get('REQUIRE_EMAIL_VERIFICATION', '').strip().lower()
if _require_email_raw not in ('', '0', '1', 'false', 'true', 'off', 'on', 'no', 'yes'):
    raise ImproperlyConfigured('REQUIRE_EMAIL_VERIFICATION must be a boolean value')
REQUIRE_EMAIL_VERIFICATION = (not DEBUG) or _require_email_raw in ('1', 'true', 'on', 'yes')
SECRET_KEY = os.environ.get('DJANGO_SECRET_KEY', '')
# Optional stable, separately managed encryption key for MFA seeds. Keep across deploys.
LINGUAMASTER_TOTP_KEY = os.environ.get('LINGUAMASTER_TOTP_KEY', '')
if not SECRET_KEY:
    if DEBUG:
        SECRET_KEY = 'development-only-insecure-change-before-deployment'
    else:
        raise ImproperlyConfigured('DJANGO_SECRET_KEY is required with DEBUG=0')
ALLOWED_HOSTS = [x.strip() for x in os.environ.get('DJANGO_ALLOWED_HOSTS', 'localhost,127.0.0.1' if DEBUG else '').split(',') if x.strip()]
if '*' in ALLOWED_HOSTS and not DEBUG:
    raise ImproperlyConfigured('Wildcard ALLOWED_HOSTS is not allowed in production')
if not ALLOWED_HOSTS:
    raise ImproperlyConfigured('DJANGO_ALLOWED_HOSTS must be set')
SITE_URL = os.environ.get('SITE_URL', 'http://localhost:8000' if DEBUG else '').rstrip('/')
if not SITE_URL or (not DEBUG and not SITE_URL.startswith('https://')):
    raise ImproperlyConfigured('Set SITE_URL to your HTTPS public domain')
SITE_DOMAIN = urlparse(SITE_URL).hostname
# Enforce the essential public origin/key invariants before Django serves requests.
# These guards apply only to DEBUG=0 and do not touch local SQLite/accounts.
if not DEBUG:
    from .deployment_validation import (
        ProductionConfigurationError, validate_production_secret_key,
        validate_production_site_url,
    )
    try:
        validate_production_secret_key(SECRET_KEY)
        validate_production_site_url(SITE_URL, ALLOWED_HOSTS)
    except ProductionConfigurationError as exc:
        raise ImproperlyConfigured(str(exc)) from exc
CSRF_TRUSTED_ORIGINS = [SITE_URL]
INSTALLED_APPS = [
    'django.contrib.admin', 'django.contrib.auth', 'django.contrib.contenttypes',
    'django.contrib.sessions', 'django.contrib.messages', 'django.contrib.staticfiles',
    'django.contrib.sitemaps', 'rest_framework', 'academy',
]
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    # Outer security headers wrap *all* account and admin denials, including
    # early redirects, so private responses are never returned unprotected.
    'academy.middleware.SecurityHeadersMiddleware',
    'academy.middleware.AccountStateMiddleware',
    'academy.middleware.AdminMFAMiddleware',
]
ROOT_URLCONF = 'config.urls'
TEMPLATES = [{'BACKEND':'django.template.backends.django.DjangoTemplates', 'DIRS':[], 'APP_DIRS':True,
              'OPTIONS':{'context_processors':['django.template.context_processors.debug','django.template.context_processors.request',
                        'django.contrib.auth.context_processors.auth','django.contrib.messages.context_processors.messages',
                        'academy.context_processors.site_settings','academy.ui.app_locale',
                        'academy.progress_v9.appearance_context','academy.experience_v9.interface_context',
                        'academy.courses_v10.course_context','academy.experience_v10.context']}}]
WSGI_APPLICATION = 'config.wsgi.application'
ASGI_APPLICATION = 'config.asgi.application'
if os.environ.get('USE_SQLITE') == '1':
    if not DEBUG:
        raise ImproperlyConfigured('SQLite is restricted to DEBUG=1')
    DATABASES = {'default':{'ENGINE':'django.db.backends.sqlite3','NAME':BASE_DIR/'db.sqlite3'}}
else:
    DATABASES = {'default':{'ENGINE':'django.db.backends.postgresql', 'NAME':os.environ.get('POSTGRES_DB','linguamaster'),
         'USER':os.environ.get('POSTGRES_USER','lingua'), 'PASSWORD':os.environ.get('POSTGRES_PASSWORD',''),
         'HOST':os.environ.get('POSTGRES_HOST','127.0.0.1'), 'PORT':os.environ.get('POSTGRES_PORT','5432'),
         'CONN_MAX_AGE':60, 'OPTIONS':{
             'sslmode':os.environ.get('POSTGRES_SSLMODE','prefer'),
             **({'sslrootcert':os.environ['POSTGRES_SSLROOTCERT']}
                if os.environ.get('POSTGRES_SSLROOTCERT') else {}),
         }}}
# An external production database must authenticate the server identity.
if not DEBUG and os.environ.get('POSTGRES_SSLMODE') != 'verify-full':
    raise ImproperlyConfigured('Production PostgreSQL requires POSTGRES_SSLMODE=verify-full')
if not DEBUG and not os.environ.get('POSTGRES_SSLROOTCERT'):
    raise ImproperlyConfigured('Set POSTGRES_SSLROOTCERT to the provider-issued PostgreSQL CA file')
if not DEBUG and not os.environ.get('POSTGRES_HOST'):
    raise ImproperlyConfigured('Set POSTGRES_HOST to your managed PostgreSQL hostname')
if os.environ.get('USE_SQLITE') == '1':
    CACHES = {'default':{'BACKEND':'django.core.cache.backends.locmem.LocMemCache','LOCATION':'local-dev'}}
else:
    CACHES = {'default':{'BACKEND':'django_redis.cache.RedisCache', 'LOCATION':os.environ.get('REDIS_CACHE_URL') or os.environ.get('REDIS_URL','redis://127.0.0.1:6379/0'),
        'OPTIONS':{'CLIENT_CLASS':'django_redis.client.DefaultClient'}}}
SESSION_ENGINE = 'django.contrib.sessions.backends.cached_db' if not DEBUG else 'django.contrib.sessions.backends.db'
AUTH_PASSWORD_VALIDATORS = [
    {'NAME':'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME':'django.contrib.auth.password_validation.MinimumLengthValidator','OPTIONS':{'min_length':8}},
    {'NAME':'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME':'django.contrib.auth.password_validation.NumericPasswordValidator'},
]
PASSWORD_HASHERS = ['django.contrib.auth.hashers.Argon2PasswordHasher','django.contrib.auth.hashers.PBKDF2PasswordHasher']
LANGUAGE_CODE = 'en'
TIME_ZONE = 'Europe/Brussels'
USE_I18N = True
USE_TZ = True
STATIC_URL = '/static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'
# Local development and Django tests should resolve PWA assets directly from
# academy/static/ without requiring a prior collectstatic build.
# Production still requires hashed assets and a collectstatic manifest.
# Docker's image build sets BUILD_STATIC_MANIFEST=1 to generate that manifest
# even while using its isolated DEBUG=1 build environment.
_STATIC_MANIFEST_REQUIRED = (not DEBUG) or os.environ.get('BUILD_STATIC_MANIFEST') == '1'
STORAGES = {
    'default': {'BACKEND': 'django.core.files.storage.FileSystemStorage'},
    'staticfiles': {
        'BACKEND': (
            'whitenoise.storage.CompressedManifestStaticFilesStorage'
            if _STATIC_MANIFEST_REQUIRED
            else 'django.contrib.staticfiles.storage.StaticFilesStorage'
        )
    },
}
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
PASSWORD_RESET_TIMEOUT = 86400
LOGIN_URL = '/login/'
LOGIN_REDIRECT_URL = '/dashboard/'
LOGOUT_REDIRECT_URL = '/'
# Django 6.1.3 MAILERS: avoid deprecated EMAIL_* settings while keeping
# existing Windows .env variable names for user configuration compatibility.
# Do not use console.EmailBackend: it prints one-time verification URLs to logs.
_MAIL_SMTP = 'django.core.mail.backends.smtp.EmailBackend'
_MAIL_FILE = 'django.core.mail.backends.filebased.EmailBackend'
_MAIL_MEMORY = 'django.core.mail.backends.locmem.EmailBackend'
_MAIL_BACKEND = os.environ.get('EMAIL_BACKEND', '').strip() or (
    _MAIL_SMTP if (os.environ.get('EMAIL_HOST') or not DEBUG) else _MAIL_FILE
)
if _MAIL_BACKEND not in (_MAIL_SMTP, _MAIL_FILE, _MAIL_MEMORY):
    raise ImproperlyConfigured('Unsupported email backend; configure SMTP or the local private mailbox')
if not DEBUG and _MAIL_BACKEND != _MAIL_SMTP:
    raise ImproperlyConfigured('Production needs an SMTP transactional mailer')
DEFAULT_FROM_EMAIL = os.environ.get('DEFAULT_FROM_EMAIL', 'Rozh <no-reply@localhost>' if DEBUG else '')
if _MAIL_BACKEND == _MAIL_SMTP:
    _mail_host = os.environ.get('EMAIL_HOST', '').strip()
    if not _mail_host or not DEFAULT_FROM_EMAIL:
        raise ImproperlyConfigured('Set EMAIL_HOST and DEFAULT_FROM_EMAIL for SMTP')
    _use_ssl = os.environ.get('EMAIL_USE_SSL', '0').strip().lower() in ('1', 'true', 'yes', 'on')
    _use_tls = os.environ.get('EMAIL_USE_TLS', '0' if _use_ssl else '1').strip().lower() in ('1', 'true', 'yes', 'on')
    if _use_ssl and _use_tls:
        raise ImproperlyConfigured('EMAIL_USE_SSL and EMAIL_USE_TLS are mutually exclusive')
    if not DEBUG and not (_use_ssl or _use_tls):
        raise ImproperlyConfigured('Production SMTP must use TLS or SSL')
    try:
        _mail_port = int(os.environ.get('EMAIL_PORT', '465' if _use_ssl else '587'))
        _mail_timeout = int(os.environ.get('EMAIL_TIMEOUT', '12'))
    except ValueError:
        raise ImproperlyConfigured('EMAIL_PORT and EMAIL_TIMEOUT must be integers') from None
    if not (1 <= _mail_port <= 65535 and 1 <= _mail_timeout <= 120):
        raise ImproperlyConfigured('Invalid EMAIL_PORT or EMAIL_TIMEOUT')
    MAILERS = {'default': {'BACKEND': _MAIL_SMTP, 'OPTIONS': {
        'host': _mail_host, 'port': _mail_port,
        'username': os.environ.get('EMAIL_HOST_USER', ''),
        'password': os.environ.get('EMAIL_HOST_PASSWORD', ''),
        'use_tls': _use_tls, 'use_ssl': _use_ssl, 'timeout': _mail_timeout,
    }}}
elif _MAIL_BACKEND == _MAIL_FILE:
    # A mail is stored as private mail content, NOT emitted as a terminal log.
    # Keep this directory outside staticfiles and out of all release ZIPs.
    MAILERS = {'default': {'BACKEND': _MAIL_FILE,
        'OPTIONS': {'file_path': BASE_DIR / '.private-email-outbox'}}}
else:
    # Explicit dev-only in-memory backend for isolated runs; no real delivery.
    MAILERS = {'default': {'BACKEND': _MAIL_MEMORY}}
# Cache and task broker must be separate in the provided production Compose.
# REDIS_URL remains a backwards-compatible fallback for existing operators.
CELERY_BROKER_URL = os.environ.get('REDIS_BROKER_URL') or os.environ.get('REDIS_URL','redis://127.0.0.1:6379/0')
CELERY_RESULT_BACKEND = None
CELERY_TASK_IGNORE_RESULT = True
CELERY_BEAT_SCHEDULE = {
    'daily-learning-reminders': {'task':'academy.tasks.send_opted_reminders','schedule':60*60*24},
    'weekly-digests': {'task':'academy.tasks.send_weekly_digest','schedule':60*60*24*7},
    'expire-retained-logs': {'task':'academy.tasks.purge_expired_logs','schedule':60*60*24},
}
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES':['rest_framework.authentication.SessionAuthentication'],
    'DEFAULT_PERMISSION_CLASSES':['rest_framework.permissions.IsAuthenticatedOrReadOnly'],
    'DEFAULT_THROTTLE_CLASSES':['rest_framework.throttling.AnonRateThrottle','rest_framework.throttling.UserRateThrottle'],
    'DEFAULT_THROTTLE_RATES':{'anon':'60/hour','user':'600/hour'},
}
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_REFERRER_POLICY = 'strict-origin-when-cross-origin'
X_FRAME_OPTIONS = 'DENY'
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = 'Lax'
CSRF_COOKIE_SAMESITE = 'Lax'
SESSION_COOKIE_SECURE = not DEBUG
CSRF_COOKIE_SECURE = not DEBUG
SECURE_SSL_REDIRECT = not DEBUG
SECURE_HSTS_SECONDS = 31536000 if not DEBUG else 0
SECURE_HSTS_INCLUDE_SUBDOMAINS = not DEBUG
SECURE_HSTS_PRELOAD = False  # never preload before domain/subdomain validation
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO','https') if os.environ.get('TRUST_PROXY') == '1' else None
FILE_UPLOAD_MAX_MEMORY_SIZE = 2_000_000
DATA_UPLOAD_MAX_MEMORY_SIZE = 2_000_000
DATA_UPLOAD_MAX_NUMBER_FIELDS = 250
AI_API_KEY = os.environ.get('AI_API_KEY', '')
AI_MODEL = os.environ.get('AI_MODEL', 'gpt-4.1-mini')
AI_API_BASE = 'https://api.openai.com/v1'  # pinned provider endpoint, no user-selected URL
AI_TIMEOUT_SECONDS = 18
PRIVACY_LOG_RETENTION_DAYS = 90
AUDIT_LOG_RETENTION_DAYS = 365

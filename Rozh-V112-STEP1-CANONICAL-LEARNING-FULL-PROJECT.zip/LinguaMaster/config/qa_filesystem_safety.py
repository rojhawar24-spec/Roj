"""Fail-closed local QA storage for secrets and disposable databases.

No Django dependency: these checks are exercised with the actual functions
by stdlib unittest before an ORM / PostgreSQL service is available.
"""
import os
import secrets
import stat
from pathlib import Path


class QAFileSafetyError(ValueError):
    """Refuse a QA path that could escape the local disposable folder."""


def _is_link_or_junction(path):
    path = Path(path)
    return path.is_symlink() or bool(getattr(path, 'is_junction', lambda: False)())


def _require_private_directory(directory, label):
    """Refuse public/foreign-owned writable QA directories on POSIX.

    Windows ACL analysis needs a separate native audit; symbolic links and
    junctions are still rejected on both platforms.
    """
    info = directory.stat(follow_symlinks=False)
    if not stat.S_ISDIR(info.st_mode):
        raise QAFileSafetyError(f'{label} must be a real directory.')
    if os.name == 'posix':
        if info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) & 0o077:
            raise QAFileSafetyError(f'{label} must be owner-only and owner-controlled.')


def create_local_qa_root(base_dir):
    """Never accept a symlink or Windows junction as the writable QA root."""
    base = Path(base_dir).resolve(strict=True)
    candidate = base / '.rozh-local-test'
    if _is_link_or_junction(candidate):
        raise QAFileSafetyError('Refusing linked or junction QA directory.')
    try:
        candidate.mkdir(mode=0o700, exist_ok=True)
    except OSError as exc:
        raise QAFileSafetyError('Cannot create isolated QA directory.') from exc
    if _is_link_or_junction(candidate) or not candidate.is_dir():
        raise QAFileSafetyError('QA directory must be a real directory.')
    _require_private_directory(candidate, 'QA directory')
    resolved = candidate.resolve(strict=True)
    if resolved.parent != base or resolved != candidate:
        raise QAFileSafetyError('QA directory escaped the project root.')
    return resolved


def create_local_qa_mailbox(qa_root):
    """Keep verification/recovery QA emails inside a private real directory.

    File-based Django mail backends will otherwise follow a pre-planted
    `emails` symlink and may write messages outside the disposable QA folder.
    """
    root = Path(qa_root)
    if _is_link_or_junction(root) or not root.is_dir():
        raise QAFileSafetyError('QA root for test email is not a real directory.')
    _require_private_directory(root, 'QA directory')
    candidate = root / 'emails'
    if _is_link_or_junction(candidate):
        raise QAFileSafetyError('Refusing linked QA mailbox.')
    try:
        candidate.mkdir(mode=0o700, exist_ok=True)
    except OSError as exc:
        raise QAFileSafetyError('Cannot create isolated QA mailbox.') from exc
    if _is_link_or_junction(candidate) or not candidate.is_dir():
        raise QAFileSafetyError('QA mailbox must be a real directory.')
    _require_private_directory(candidate, 'QA mailbox')
    resolved = candidate.resolve(strict=True)
    if resolved.parent != root or resolved != candidate:
        raise QAFileSafetyError('QA mailbox escaped QA root.')
    return resolved


def load_or_create_local_qa_secret(qa_root):
    """Never read a linked secret; create new test secrets with owner permissions.

    The file is read through its opened descriptor, not a later path lookup;
    O_NOFOLLOW prevents symbolic-link races on supporting platforms.
    O_NONBLOCK prevents a pre-planted FIFO from hanging QA startup.
    """
    path = Path(qa_root) / 'qa-secret.key'
    if _is_link_or_junction(path):
        raise QAFileSafetyError('Refusing linked QA secret.')
    nofollow = getattr(os, 'O_NOFOLLOW', 0)
    nonblock = getattr(os, 'O_NONBLOCK', 0)
    read_flags = os.O_RDONLY | nofollow | nonblock
    try:
        fd = os.open(path, read_flags)
    except FileNotFoundError:
        try:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | nofollow, 0o600)
        except FileExistsError:
            if _is_link_or_junction(path):
                raise QAFileSafetyError('Refusing linked QA secret after concurrent creation.')
            fd = os.open(path, read_flags)
        else:
            with os.fdopen(fd, 'w', encoding='ascii') as output:
                output.write(secrets.token_urlsafe(64))
            fd = os.open(path, read_flags)
    except OSError as exc:
        raise QAFileSafetyError('QA secret is not readable safely.') from exc
    try:
        meta = os.fstat(fd)
        if not stat.S_ISREG(meta.st_mode):
            raise QAFileSafetyError('QA secret must be a regular file.')
        if os.name == 'posix':
            if meta.st_uid != os.getuid():
                raise QAFileSafetyError('QA secret is not owned by the QA user.')
            if stat.S_IMODE(meta.st_mode) & 0o077:
                raise QAFileSafetyError('QA secret has overly broad permissions.')
        if meta.st_nlink != 1:
            raise QAFileSafetyError('QA secret must not be hardlinked.')
        # Generated QA keys are 86 ASCII bytes. Bound existing file reads; an
        # oversized pre-planted file must not consume arbitrary memory.
        if not 50 <= meta.st_size <= 512:
            raise QAFileSafetyError('QA secret file size is invalid.')
        with os.fdopen(fd, 'r', encoding='ascii') as handle:
            fd = None
            secret = handle.read().strip()
    finally:
        if fd is not None:
            os.close(fd)
    if len(secret) < 50:
        raise QAFileSafetyError('QA secret is invalid or incomplete.')
    return secret


def create_local_qa_database_file(qa_root):
    """Prepare only the dedicated QA SQLite file, refusing linked/special files.

    A path that resolves inside QA is not sufficient: a hardlink to a normal
    database can have the same filename in the QA folder yet share its inode.
    We open with O_EXCL when creating and O_NOFOLLOW/O_NONBLOCK when checking.
    The directory must be private. Existing database bytes are never replaced.

    A native Windows ACL audit and protection from concurrent same-user path
    replacement at the later SQLite open remain separate release gates.
    """
    root = Path(qa_root)
    if _is_link_or_junction(root) or not root.is_dir():
        raise QAFileSafetyError('QA database root must be a real directory.')
    _require_private_directory(root, 'QA directory')
    path = root / 'rozh-test.sqlite3'
    if _is_link_or_junction(path):
        raise QAFileSafetyError('Refusing linked or junction QA database.')
    nofollow = getattr(os, 'O_NOFOLLOW', 0)
    nonblock = getattr(os, 'O_NONBLOCK', 0)
    binary = getattr(os, 'O_BINARY', 0)
    try:
        # Exclusive creation cannot follow a previously planted symlink.
        # The empty file is a supported SQLite starting state.
        try:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | nofollow | binary, 0o600)
        except FileExistsError:
            if _is_link_or_junction(path):
                raise QAFileSafetyError('Refusing linked QA database after concurrent creation.')
            fd = os.open(path, os.O_RDONLY | nofollow | nonblock | binary)
    except QAFileSafetyError:
        raise
    except OSError as exc:
        raise QAFileSafetyError('QA database file could not be checked safely.') from exc
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode):
            raise QAFileSafetyError('QA database must be a regular file.')
        if info.st_nlink != 1:
            raise QAFileSafetyError('QA database must not be hardlinked.')
        if os.name == 'posix':
            if info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) & 0o077:
                raise QAFileSafetyError('QA database must be private and owner-controlled.')
    finally:
        os.close(fd)
    if _is_link_or_junction(path):
        raise QAFileSafetyError('QA database path changed to a link.')
    return path

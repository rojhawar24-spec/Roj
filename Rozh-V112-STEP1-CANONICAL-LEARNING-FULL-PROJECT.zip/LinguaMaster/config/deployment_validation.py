"""Pure deployment configuration checks, deliberately independent of Django.

Protects production startup against placeholder/weak secrets and invalid SITE_URL
values. These checks cannot measure secret entropy or certify a deployment.
"""
from urllib.parse import urlsplit


class ProductionConfigurationError(ValueError):
    """Unsafe production configuration."""


def validate_production_secret_key(value: str) -> None:
    if not isinstance(value, str) or len(value) < 50:
        raise ProductionConfigurationError(
            'Production DJANGO_SECRET_KEY must be a stable, random secret of at least 50 characters'
        )
    lowered = value.casefold()
    if any(token in lowered for token in (
        'development-only', 'change-me', 'changeme', 'example', 'placeholder',
        'your-secret', 'insert-secret', 'password',
    )) or len(set(value)) < 10:
        raise ProductionConfigurationError('Production DJANGO_SECRET_KEY looks like a placeholder or low-diversity value')


def validate_production_site_url(site_url: str, allowed_hosts: list[str]) -> None:
    try:
        parsed = urlsplit(site_url)
        hostname = parsed.hostname
        port = parsed.port  # Force validation for malformed ports.
    except ValueError as exc:
        raise ProductionConfigurationError('Invalid production SITE_URL') from exc
    if (parsed.scheme != 'https' or not hostname or parsed.username is not None or
            parsed.password is not None or parsed.query or parsed.fragment or
            parsed.path not in ('', '/') or not parsed.netloc or port == 0):
        raise ProductionConfigurationError('Production SITE_URL must be a clean HTTPS site origin')
    host = hostname.casefold().rstrip('.')
    if (host in ('localhost', 'example.com', 'example.org', 'example.net') or
            host.endswith(('.invalid', '.test', '.localhost', '.example'))):
        raise ProductionConfigurationError('Production SITE_URL must use a real configured public hostname')
    # Django's leading-dot syntax accepts both apex and subdomains.
    hosts = [h.casefold().rstrip('.') for h in allowed_hosts]
    if not any(host == h or (h.startswith('.') and
                             (host == h[1:] or host.endswith(h))) for h in hosts):
        raise ProductionConfigurationError('SITE_URL hostname must be covered by DJANGO_ALLOWED_HOSTS')

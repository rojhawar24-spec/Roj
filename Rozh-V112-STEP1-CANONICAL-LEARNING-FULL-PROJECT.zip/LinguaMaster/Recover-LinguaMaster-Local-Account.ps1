﻿# Guided, local-only recovery for an existing learner account.
# Never disables verification, bypasses a manager suspension or removes MFA.
[CmdletBinding()]
param([string]$Username = 'roj', [switch]$ChangePassword)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
. (Join-Path $PSScriptRoot 'scripts\Set-LinguaMasterLocalEnv.ps1')
$python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
    throw 'Python virtual environment missing. Start LinguaMaster locally first.'
}
if ([string]::IsNullOrWhiteSpace($Username)) { throw 'Specify a username.' }
Write-Host '[LOGIN RECOVERY] Existing local account only. No public/admin bypass.'
Write-Host '[1/4] Checking account status and safeguards...'
& $python 'manage.py' 'review_local_legacy_account' '--username' $Username '--check-only'
if ($LASTEXITCODE -ne 0) { throw 'Account preflight failed. Read the actual error above.' }
Write-Host '[2/4] If the old account has a historical review hold, explicit operator approval is needed.'
Write-Host 'The program may ask for the existing email and an exact REVIEW confirmation.'
& $python 'manage.py' 'review_local_legacy_account' '--username' $Username '--approve-legacy'
if ($LASTEXITCODE -ne 0) { throw 'Account review was denied or aborted; no security bypass attempted.' }
if ($ChangePassword) {
    Write-Host '[3/4] Enter a NEW password twice when Django prompts; input stays hidden.'
    & $python 'manage.py' 'changepassword' $Username
    if ($LASTEXITCODE -ne 0) { throw 'Password change failed. No new email link issued.' }
} else {
    Write-Host '[3/4] Existing password retained. Use -ChangePassword if it does not work.'
}
Write-Host '[4/4] Creating a FRESH normal email verification link if needed...'
& $python 'manage.py' 'local_verification_link' '--username' $Username
if ($LASTEXITCODE -ne 0) { throw 'Verification not possible; see the account state above.' }
Write-Host 'Start the site; open the private link in the same browser, click Confirm email, then Sign in.'
Write-Host 'If login is still refused, run Diagnose-LinguaMaster-Login.ps1 -VerifyPassword.'
Write-Host 'Never share a password, email-verification link, or MFA recovery code.'

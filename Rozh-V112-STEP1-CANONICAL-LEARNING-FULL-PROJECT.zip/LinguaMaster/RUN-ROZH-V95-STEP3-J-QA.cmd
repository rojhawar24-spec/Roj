@echo off
setlocal
cd /d "%~dp0"
call "%~dp0RUN-ROZH-V95-STEP2-QA.cmd" %*
exit /b %ERRORLEVEL%

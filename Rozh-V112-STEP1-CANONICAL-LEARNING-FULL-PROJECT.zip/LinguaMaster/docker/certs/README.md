# PostgreSQL CA trust anchor — keep private deployment configuration out of the release

Place your managed PostgreSQL provider's authentic public CA certificate in
`docker/certs/postgres-ca.crt` on the deployment host. **Do not** use a certificate
copied from an untrusted chat or generated for the wrong server. Set `POSTGRES_HOST`
to the DNS name on that server certificate (hostname validation is mandatory).
Never store private keys in this folder. Do not commit `.crt`/`.pem` or `.env`.
The Compose service refuses to start unless this file is present.

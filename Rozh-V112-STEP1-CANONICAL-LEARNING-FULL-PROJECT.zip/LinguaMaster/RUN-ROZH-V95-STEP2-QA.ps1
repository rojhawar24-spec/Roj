# Rozh V95 STEP 2: disposable, real Django/SQLite integration QA.
# Windows PowerShell 5.1+. No production accounts, secrets or database.
# This script does NOT mark a failed/blocked HTTP test as passing.
param([switch]$ReinstallDependencies)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

foreach ($blocked in @('.env','.env.local','.env.production','db.sqlite3','db.sqlite3-wal','db.sqlite3-shm')) {
    if (Test-Path -LiteralPath (Join-Path $PSScriptRoot $blocked)) {
        throw "REFUSED: $blocked found. Extract a NEW full-project ZIP into an empty folder."
    }
}
if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'manage.py'))) {
    throw 'REFUSED: manage.py missing.'
}
# Native Windows ACL isolation must be established BEFORE Django writes QA files.
$aclGate = Join-Path $PSScriptRoot 'scripts\qa_windows_acl_preflight.ps1'
& $aclGate -Mode Prepare
# Remove credentials inherited from the host shell. Never reach production services.
foreach ($key in @('DATABASE_URL','POSTGRES_URL','POSTGRES_DB','POSTGRES_USER','POSTGRES_PASSWORD',
    'POSTGRES_HOST','POSTGRES_PORT','PGHOST','PGUSER','PGPASSWORD','PGDATABASE','PGPORT',
    'AI_API_KEY','OPENAI_API_KEY','STRIPE_SECRET_KEY','STRIPE_WEBHOOK_SECRET','REDIS_URL',
    'REDIS_CACHE_URL','REDIS_BROKER_URL','EMAIL_HOST','EMAIL_HOST_PASSWORD','EMAIL_HOST_USER',
    'EMAIL_PORT','EMAIL_USE_SSL','EMAIL_USE_TLS','EMAIL_BACKEND','DEFAULT_FROM_EMAIL',
    'BUILD_STATIC_MANIFEST','TRUST_PROXY','POSTGRES_SSLROOTCERT','AI_MODEL',
    'LINGUAMASTER_TOTP_KEY','DJANGO_SECRET_KEY')) {
    Remove-Item -Path ("Env:" + $key) -ErrorAction SilentlyContinue
}
$env:ROZH_LOCAL_QA_ONLY='1'
$env:DJANGO_SETTINGS_MODULE='config.settings_local_qa'
$env:DJANGO_DEBUG='1'
$env:USE_SQLITE='1'
$env:SITE_URL='http://127.0.0.1:3000'
$env:DJANGO_ALLOWED_HOSTS='127.0.0.1,localhost,testserver'
$env:PYTHONDONTWRITEBYTECODE='1'
$env:PYTHONPATH=$PSScriptRoot
$python = Join-Path $PSScriptRoot '.venv-qa\Scripts\python.exe'
$install = $ReinstallDependencies.IsPresent
if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
    $created = $false
    $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($launcher) {
        foreach ($version in @('-3.13','-3.14','-3.12','-3.15')) {
            $candidateOk = $false
            $savedPreference = $ErrorActionPreference
            try {
                $ErrorActionPreference = 'Continue'
                & $launcher.Source $version 'scripts\check_python_version_v46.py' 2>$null | Out-Null
                $candidateOk = ($LASTEXITCODE -eq 0)
            } catch { $candidateOk = $false }
            finally { $ErrorActionPreference = $savedPreference }
            if ($candidateOk) {
                & $launcher.Source $version -m venv '.venv-qa'
                if ($LASTEXITCODE -ne 0) { throw 'Disposable venv creation failed.' }
                $created = $true
                break
            }
        }
    }
    if (-not $created) {
        foreach ($alias in @('python.exe','python3.exe')) {
            $candidate = Get-Command $alias -ErrorAction SilentlyContinue
            if (-not $candidate) { continue }
            $candidateOk = $false
            $savedPreference = $ErrorActionPreference
            try {
                $ErrorActionPreference = 'Continue'
                & $candidate.Source 'scripts\check_python_version_v46.py' 2>$null | Out-Null
                $candidateOk = ($LASTEXITCODE -eq 0)
            } catch { $candidateOk = $false }
            finally { $ErrorActionPreference = $savedPreference }
            if ($candidateOk) {
                & $candidate.Source -m venv '.venv-qa'
                if ($LASTEXITCODE -ne 0) { throw 'Disposable venv creation failed.' }
                $created = $true
                break
            }
        }
    }
    if (-not $created) { throw 'No compatible Python 3.12-3.15 runtime found.' }
    $install = $true
}
function Run-QAPython([string[]]$PythonArgs) {
    & $python @PythonArgs
    if ($LASTEXITCODE -ne 0) {
        throw "STEP 2 QA FAILED/BLOCKED (exit $LASTEXITCODE). No HTTP PASS claimed."
    }
}
if (-not $install) {
    & $python -c 'import django, rest_framework, pyotp, segno; print("Django", django.get_version())'
    if ($LASTEXITCODE -ne 0) { $install = $true }
}
if ($install) {
    Write-Host '[1/7] Install exact project dependencies in .venv-qa (internet required).'
    Run-QAPython -PythonArgs @('-m','pip','install','-r','requirements.txt')
}
Write-Host '[2/7] Offline source-backed boundary tests.'
Run-QAPython -PythonArgs @('scripts\test_v27_account_admission_offline.py')
Run-QAPython -PythonArgs @('scripts\test_login_v32_offline.py')
Run-QAPython -PythonArgs @('scripts\test_v90_account_boundary_offline.py')
Run-QAPython -PythonArgs @('scripts\test_v91_session_version_offline.py')
Run-QAPython -PythonArgs @('scripts\test_v91_login_signal_offline.py')
Run-QAPython -PythonArgs @('scripts\test_v92_privilege_revocation_offline.py')
Run-QAPython -PythonArgs @('scripts\test_v93_privilege_fingerprint_offline.py')
Run-QAPython -PythonArgs @('scripts\test_v93_denial_headers_offline.py')
Run-QAPython -PythonArgs @('scripts\test_v94_permission_metadata_offline.py')
Run-QAPython -PythonArgs @('scripts\test_v95_totp_verify_replay_offline.py')
Run-QAPython -PythonArgs @('scripts\test_v85_step2_access_policy_offline.py')
Run-QAPython -PythonArgs @('scripts\test_step2_qa_isolation_offline.py')
Run-QAPython -PythonArgs @('scripts\test_step2_full_regression_gate_offline.py')
Run-QAPython -PythonArgs @('scripts\test_step2_pending_mfa_binding_offline.py')
Run-QAPython -PythonArgs @('scripts\test_step2_recovery_dedup_offline.py')
Run-QAPython -PythonArgs @('scripts\test_step2_malformed_mfa_inventory_offline.py')
Run-QAPython -PythonArgs @('scripts\test_step2_live_browser_gate_offline.py')
Run-QAPython -PythonArgs @('scripts\test_step3h_durable_round_offline.py')
Run-QAPython -PythonArgs @('scripts\test_step3i_postgres_gate_offline.py')
Run-QAPython -PythonArgs @('scripts\test_step3j_qa_filesystem_safety_offline.py')
Run-QAPython -PythonArgs @('scripts\test_step3j_mailbox_permissions_offline.py')
Run-QAPython -PythonArgs @('scripts\test_step3j_qa_secret_descriptor_safety_offline.py')
Run-QAPython -PythonArgs @('scripts\test_step3j_qa_database_path_offline.py')
Run-QAPython -PythonArgs @('scripts\test_step3j_real_runtime_gates_offline.py')
Run-QAPython -PythonArgs @('scripts\test_step3j_strict_runtime_gates_offline.py')
Write-Host '[3/7] Django configuration and migrations checks.'
Run-QAPython -PythonArgs @('manage.py','check','--settings=config.settings_local_qa')
Run-QAPython -PythonArgs @('manage.py','makemigrations','--check','--dry-run','--settings=config.settings_local_qa')
Run-QAPython -PythonArgs @('manage.py','migrate','--noinput','--settings=config.settings_local_qa')
Run-QAPython -PythonArgs @('scripts\verify_step3j_migration_0019.py')
& $aclGate -Mode Verify
Write-Host '[4/7] HTTP + isolated disposable SQLite tests.'
Run-QAPython -PythonArgs @('manage.py','test',
    'academy.test_step2_pending_mfa_binding_http',
    'academy.test_step2_recovery_duplicates_http',
    'academy.test_step2_malformed_mfa_inventory_http',
    'academy.test_v95_totp_replay_collision_http',
    'academy.test_v94_permission_metadata_http',
    'academy.test_v93_privilege_fingerprint_http',
    'academy.test_v92_privilege_revocation_http',
    'academy.test_v91_auth_version_http',
    'academy.test_v90_account_boundary_http',
    'academy.test_v89_mfa_session_rotation_http',
    'academy.test_v88_mfa_enrollment_totp_step_http',
    'academy.test_v87_mfa_enroll_reauth_http',
    'academy.test_v86_step2_mfa_disable_http',
    'academy.test_v85_step2_auth_http',
    'academy.test_v84_public_api_data_leak',
    'academy.test_v47_session_grammar_http',
    'academy.test_v46_missing_profile_http',
    'academy.test_phase11_mfa_enrollment',
    'academy.test_login_v32',
    '--settings=config.settings_local_qa','--verbosity','2',
    '--testrunner=scripts.step3j_strict_test_runner.PhaseJStrictTestRunner')
Write-Host '[5/7] Step 3 round ledger, grading and cross-channel HTTP/SQLite regression.'
Run-QAPython -PythonArgs @('manage.py','test',
    'academy.test_step3h_durable_round_receipts_http',
    'academy.test_step3g_mixed_channels_http',
    'academy.test_step3f_ssr_batch_atomic_http',
    'academy.test_step3c_finished_failed_round_http',
    '--settings=config.settings_local_qa','--verbosity','2',
    '--testrunner=scripts.step3j_strict_test_runner.PhaseJStrictTestRunner')
Write-Host '[6/7] Targeted tests passed. Running fail-closed full academy regression suite.'
Run-QAPython -PythonArgs @('manage.py','test','academy','--settings=config.settings_local_qa','--verbosity','2',
    '--testrunner=scripts.step2_full_regression_gate.Step2FullRegressionRunner')
& $aclGate -Mode Verify
Write-Host '[7/7] Step 2 + Step 3 targeted and full academy Django tests plus Windows ACL checks PASSED on isolated SQLite. PostgreSQL is a separate CI gate; NOT production certified.'

# Rozh — هەنگاوی ٣، بەشی A (لەسەر V95)

**دۆخ: دەستپێکراوە؛ هێشتا تەواو نییە.** ئەم ZIP ـە کۆپییەکی تەواوی پڕۆژەیە بۆ تاقیکردنەوە، نەک وەشانی production.

## ١٣ چالاکیی هەبوو

لە V58ەوە کۆدی ١٣ جۆری چالاکی هەیە: Multiple Choice، Sentence Builder، Picture Match، Fill in the Blank، Word Matching، Listening، True/False، Spelling، Word Order، Find the Mistake، Memory Match، Choose the Image و Complete the Conversation.

ئەم کۆدە لە V95داش پارێزراوە. ئەمە واتە ناگرێتەوە کە ١٣ جۆرەکە بە Django HTTP/Database تەواو تاقیکراون یان ٩٠٠ وانەی ڕاستەقینە دروستکراون.

## چاککردنەوەکانی ئەم بەشە

1. لە هەردوو ڕێگای کلاسیکی `/lessons/<id>/` (POST/SSR و AJAX)، چالاکییە ساختەییە نوێیەکان `round_key` ـی ڕاستی سێشن داوا دەکەن. بۆ MCQ/short ـی کۆن دۆخی پشتیوانی پارێزراوە.
2. ڕیزبەندی هەڵبژاردەکانی Picture Match، Listening و Complete the Conversation بۆ هەر Round بە شێوەی deterministic تێکەڵ دەکرێت. Find the Mistake و True/False بە هۆی مانای فێرکارییەوە ڕیزبەندییان پارێزراوە.
3. Choose the Image دوو هەڵبژاردە بە هەمان پەڕگەی وێنە قبوڵ ناکات؛ چونکە وەڵامی فێرخواز ناڕوون دەکات.
4. ٩ تاقیکردنەوەی offline و ٦ تاقیکردنەوەی HTTP/SQLite لەسەر هەمان بابەت نووسراون. ئەو ٦ تاقیکردنەوەی Django هێشتا بەڕاستی ڕانەکراون.

## ئەنجامی پشکنین

- ١٠/١٠ کۆمەڵەی offline/Chromium سەرکەوتوون؛ ٩٣ تاقیکردنەوە بە ژمارە.
- Python AST: ٦٠٩ فایل بەبێ هەڵە؛ JavaScript Node syntax ـەکان بەبێ هەڵە.
- فایلەکانی V95: ٩٢٧ فایل بەبێ گۆڕان پارێزراون؛ ٢ فایل چاککراون و دوو تاقیکردنەوە زیادکراون، هەروەها ڕاپۆرت و manifest.
- لە ژینگەی ئێستادا Django دانەمەزراوە؛ بۆیە هیچ test ـی Django HTTP/SQLite و شایستەیی قوتابخانە بە سەرکەوتوو نەژمێردراوە.

## کارە ماوەکان

پێویستە تاقیکردنەوەی ڕاستەقینەی Django ـی هەموو ١٣ چالاکی لە هەردوو ڕێگادا ئەنجام بدرێت، بە زمانی RTL و مۆبایل، پشکنینی Manager content editor و فێرکاری، جیاکردنەوەی مۆڵەت و ئەنجامی ڕاستەقینەی فێرخواز. هەنگاوی ٢ش هێشتا پشتڕاستکردنەوەی Django/Database ـی نەکراوە.

بۆ Windows، لە کۆپییەکی پاکی فۆڵدەری LinguaMaster، `cmd /c .\RUN-ROZH-V95-STEP2-QA.cmd` ڕابکە؛ ئەو runner ـە پێویستە هەموو Django academy regression ـەکانیش ڕابکات. لە داتابەیسی ڕاستەقینە بەکاری مەهێنە.

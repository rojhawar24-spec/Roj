# Rozh V96 — چارەسەری پەڕەی سپی لە Leer & Speel /lessons/3/

## هۆکاری ڕاستەقینە
- `seed_curriculum` و `seed_languages_v10` پێشتر وانەکانی گوێگرتن بە `published=True` دروست دەکردن، ئەگەرچی هیچ دەنگی پەسەندکراویان نەبوو.
- کاتالۆگی `academy/static/academy/audio-v78/catalog.json` تەنها `"clips": {}` ـە: **٠ دەنگی پەسەندکراو**.
- دوگمەی «Volgende» دەتوانی ببێتە لینک بۆ ئەو وانەیە. `lesson_detail` لە GET دا تەنها دەقی HTTP 409 دەدا، و پەڕەکە سپی دەبوو.

## چاکسازییەکان
1. پشکنینی یەکگرتووی ئامادەبوونی ناوەڕۆک بۆ Listening و ڕاهێنانە پەسەندنەکراوەکان، بەبێ گۆڕینی XP یان Progress.
2. «Volgende les»، Learning Path، Play Hub و پەڕەی Unit لینک بۆ وانەی نائامادە نادەن؛ دۆخی ئامادەکاری بە ڕوونی نیشان دەدرێت.
3. لینکی ڕاستەوخۆ بۆ وانەی Listening ـی بڵاوکراوە بەبێ دەنگ، لەبری پەڕەی سپی، پەڕەی Rozh بە HTTP 409، دوو دوگمەی گەڕانەوە و ڕوونکردنەوەی گونجاو بە هۆڵەندی/سۆرانی/ئینگلیزی/عەرەبی نیشان دەدات.
4. Mixed/journey وانی گوێگرتنی بێ پەسەندی ڕاگیرا و ئەو ڕێگەیەش پەڕەی ڕوونی هەیە.
5. Seed ـی وانە نوێی گوێگرتن بەبێ دەنگی پەسەندکراو وەک Draft هەڵدەگیرێت؛ دانە پێشووییەکانی بەکارهێنەر بە خۆکار ناگۆڕدرێن.
6. `repair_listening_publication` بۆ پشکنینی بەبێ گۆڕانکاری؛ تەنها بە `--apply` وەک Draft دەیکات. هیچ XP، دڵ، هەژمار یان Progress ناسڕدرێتەوە.
7. `CHECK-ROZH-V96-LISTENING-QA.ps1` بۆ Windows: هەوڵی ئەوە دەدات تەنها QA SQLite بەکاربهێنێت و پێش `-Apply` وێنەیەکی پاشەکەوتی SQLite دروست بکات.

## پشکنین
- لە فۆڵدەری کۆد: **٤٣/٤٣ سکریپتی offline و Chromium سەرکەوتوو**، **٤٤٩ تاقیکردنەوەی ژمێردراو**.
- **٣ تاقیکردنەوەی Chromium ـی ڕاستەقینە** بۆ نموونەی HTML/CSS ـی چاکسازییەکە سەرکەوتن (desktop، Sorani RTL 360px، keyboard). ئەمانە وێبسایتی تەواوی Django نین.
- **٩ تاقیکردنەوەی نوێی Django HTTP** ئامادە کراون، بەڵام Django لەم ژینگەیەدا نییە و نەتاقی کراونەوە.
- PostgreSQL، Windows ACL، وێبسایتی Django LiveServer و تاقیکردنەوەی دەستی Screen Reader هێشتا نەکراون. **بۆ production پەسەند نەکراوە**.

## لە Windows چۆن تاقی بکەیت؟
1. ZIP ـی نوێ بە تەواوی لە **فۆڵدەرێکی تازە و بەتاڵ** بکەرەوە. `.env`، `db.sqlite3` و داتابەیسی راستەقینە تێکەڵ مەکە.
2. PowerShell لە ناو `LinguaMaster` بکەرەوە:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\START-ROZH-TEST.ps1
```

3. لە `http://127.0.0.1:3000/login/` بچۆ ژوورەوە، Leer & Speel تاقی بکەوە؛ Listening ـی بێ دەنگی پەسەندکراو نابێت وەک وانەی ئامادە دەرکەوێت.
4. بۆ **داتابەیسی QA کۆن لە هەمان کۆپی تازەی کۆد**، دوای ڕاگرتنی سێرڤەر بە Ctrl+C تەنها پشکنینی خوێندنەوە ئەنجام بدە:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\CHECK-ROZH-V96-LISTENING-QA.ps1
```

5. پاش بینینی لیستی وانە نائامادەکان و دڵنیابوون لەوەی تەنها QA ـە، بە ڕەزامەندیی خۆت بۆ Draft کردنیان:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\CHECK-ROZH-V96-LISTENING-QA.ps1 -Apply
```

**ئاگاداری:** ئەو فرمانە هەرگیز لەسەر production جێبەجێ مەکە؛ دوای جێبەجێکردن QA پاشەکەوتی SQLite دروست دەبێت. دەنگی ڕاستەقینەی پەسەندکراو هێشتا پێویستە لەلایەن مامۆستا/Manager ـەوە زیاد و پشکنراو بێت، ناکرێت ساختەی بکەین.

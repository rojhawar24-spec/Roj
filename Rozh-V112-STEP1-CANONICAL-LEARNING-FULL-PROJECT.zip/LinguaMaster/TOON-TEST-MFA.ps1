# Shows current 6-digit codes for disposable local QA accounts ONLY.
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$env:ROZH_LOCAL_QA_ONLY = '1'
$env:DJANGO_SETTINGS_MODULE = 'config.settings_local_qa'
$env:DJANGO_DEBUG = '1'
$env:USE_SQLITE = '1'
$env:SITE_URL = 'http://127.0.0.1:3000'
$env:DJANGO_ALLOWED_HOSTS = '127.0.0.1,localhost,testserver'
$python = Join-Path $PSScriptRoot '.venv-qa\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $python)) { throw 'Run START-ROZH-TEST.ps1 first.' }
& $python -m scripts.qa_local_show_mfa
if ($LASTEXITCODE -ne 0) { throw 'Could not display test MFA codes.' }

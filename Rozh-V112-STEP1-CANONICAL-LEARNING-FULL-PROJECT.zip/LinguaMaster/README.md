## V77 — Adaptive 15-question placement foundation (provisional; NO fake levels)

- New `/placement/smart/` route shows **exactly 15 one-at-a-time, server-graded questions** once a teacher-reviewed bank for the chosen published course is ready. Difficulty adjusts using previous answers; 4 reading, 3 listening, 3 grammar, 3 vocabulary and 2 *controlled* writing items. Speaking and spontaneous composition remain unassessed.
- Course-specific gate: **60 approved items minimum (2 per stage/skill across A0–C1)** including real self-hosted listening audio. **No fabricated quiz content is shipped.** If missing, onboarding does not offer placement, and the student can begin at A0.
- Learner sees a **provisional, non-validated estimate** plus uncertainty, then explicitly chooses the suggested level or A0. Existing lessons, Seasons, XP, Hearts and old progress are NOT falsely marked completed. There is no official CEFR certificate or psychometrically calibrated CAT claim.
- Manager-authoring model in protected Django Admin, database-backed resumption, 15-step server validation, content fingerprints, CSRF, transaction locking, throttles and once-only confirmation. **Only additive migration 0018**, all prior 17 migrations untouched.
- `RUN-ROZH-V77-INTEGRATION.cmd`: isolate and run real Django/SQLite tests on Windows after dependency installation. Not run here: live Django/ORM/Edge, teacher item calibration and psychometric validation are still **NOT VERIFIED**. See `V77-SMART-PLACEMENT-NL.md` and `V77-RAPPORT-SORANI.md`.
- Plan B 900 lessons/20,000 vocabulary items/365 daily words remains postponed by user request.

## V75 — Grammar CMS & Manager audit (current source release)

- Safe MFA-gated visual GrammarArticle editor and preview: Manager → Grammar CMS → open grammar topic → **Visual Grammar**.
- Preview is validation-only and does NOT save, grade, award XP/hearts or publish anything.
- Save writes validated plain-text rich JSON, ContentRevision and AuditEvent, with optimistic version locking.
- Fixed seven-language Dashboard import assertion found while running broader offline regression.
- Plan B 900 lessons/20,000 vocabulary items/365 daily content schedule deliberately postponed, no content generated.
- `RUN-ROZH-V75-INTEGRATION.cmd` runs an isolated disposable Django QA copy once .venv-qa requirements are available.
- **NOT production ready:** live Django/ORM/Windows Edge was not verified in this builder.

## Rozh V74 — Seven interface languages (beta localization)

- Core interface language selector now offers **Sorani `ckb`**, **Badini `kmr` (Arabic-script RTL)**, **Ukrainian `uk`**, **Dutch `nl`**, **English `en`**, **Arabic `ar`** and **French `fr`**.
- New locale public routes, login, onboarding, Student and Manager selectors plus essential navigation translations. Added locales are **BETA**, not full translation: see `V74-TRANSLATION-STATUS.md` and `V74-TRANSLATION-STATUS-CKB.md`.
- Preserve all 15 V73 migrations; new additive `0016` changes profile interface-language choices only. No student or course data migration.
- For isolated local Django checks use `RUN-ROZH-V74-INTEGRATION.cmd` in a disposable V74 copy after creating `.venv-qa`. Do not migrate personal databases or reuse a production `.env`.
- Daily Word V73 (one spelling, XP only), weekly actual words, and V72 Leer & Speel heart recovery (5 different words × 5 correct spellings → 1 heart) remain separate and unchanged.

# Rozh V73 — Daily word + real once-weekly review (complete project)

**V73:** one published vocabulary word per learner-local calendar day in the
selected course, frozen on the first visit (including spelling/meaning after
Manager edits); no repeated spelling until all currently published unique
spellings in that course have been seen. One correct spelling = **10 XP only**,
no hearts, with the existing once-per-learner-local-day XPEvent protection.
The course dashboard, Learn & Play preview and daily page show the same frozen
word. If today's word is unpublished/deleted, it is **not** secretly replaced
midday; the course needs published content. A small word pool cannot promise
365 genuinely different words; Manager must publish enough distinct content.

**True weekly review:** `/word-of-the-day/weekly/` offers one spelling session
per ISO calendar week for the selected course, based **only on the daily words
correctly completed in the preceding fully finished Monday–Sunday week**.
It snapshots the actual learned word and meaning, verifies each answer on the
server, allows retries and saves completion; **no extra XP or hearts**. The old
Brain Training flashcards stay removed; the old `/weekly-review/` bookmark
redirects to the new weekly task, while historical ReviewCard POST compatibility
and data are retained.

**Additive migration 0015 is REQUIRED** for two new tables; all earlier 14
migrations remain byte-identical. Migrate only in an isolated testing copy first.
For real Django/SQLite testing, use `RUN-ROZH-V73-INTEGRATION.cmd` in a clean
extracted copy, after `.venv-qa` is installed; this runner makes a disposable
copy, rejects private `.env` and DB files, checks migration parity and executes
real Django tests. Neither live Django/Windows Edge nor production PostgreSQL
was validated in the build environment. See `V73-DAILY-WEEKLY-NL.md` and
`V73-RAPPORT-SORANI.md`.

---

# Rozh V72 — Heart recovery (complete project)

**Newest change:** At zero hearts in Leer & Speel / lesson / Hearts, earn **+1 heart** by writing **5 different published course words, 5 correct repetitions each (25 total)**. Reward is server-owned, logged once via HeartEvent, capped, and the learner may resume the original lesson. `Woord van de dag` remains one correct writing for XP only (never hearts). See `V72-HEART-RECOVERY-NL.md` and `V72-RAPPORT-SORANI.md`.

**Safe tests:** run `RUN-ROZH-V72-INTEGRATION.cmd` only in an isolated QA copy with `.venv-qa`; do not use a real `.env`/DB. Django/Edge integration must be verified on the user's machine.

---

# Rozh V69 — Readability and contrast repairs (full project)

**Full source project built from V68, with additional targeted readability repairs.** This is a safe review/QA release, **not production approval**. Previous phases V63–V67 include the new learner flow, Visual Grammar improvements, typography, light/dark and routing fixes. The active code, original logo, all 14 migrations and the learning/manager system are intentionally preserved.

## Test locally on Windows without touching personal data

1. Extract the **full V69 ZIP into a new empty directory**. Never overwrite any older or live Rozh folder and **never unzip the historical archive over it**.
2. Open PowerShell in `LinguaMaster` and check `py -3.15 --version` (or another supported 3.12–3.15 interpreter).
3. Run `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\START-ROZH-TEST.ps1` to use the **isolated** `.venv-qa` and `.rozh-local-test/` environment. The first start needs internet for dependencies. The local test server binds `127.0.0.1:3000`.
4. After closing the local server with Ctrl+C, run `RUN-ROZH-V68-INTEGRATION.cmd` (the existing isolated integration runner, retained unchanged) for isolated Django migration, auth, manager, payments, lessons and routing tests. This launcher uses **a newly copied disposable SQLite directory**, and reports **NOT VERIFIED** if dependencies are missing or any test fails.
5. The focused dependency-free code test is `py -3.15 -m unittest scripts.test_v69_contrast_offline -v` from the extracted project. No Django required for this smaller check.

## Runtime source map

- `academy/`: learning content, auth, Manager, 13 learning activities, Visual Grammar, real XP/Hearts, current templates and assets; 14 migrations retained.
- `config/`: Django settings, URLs, production protections and local isolated QA settings.
- `scripts/`: security checks, older compatibility tests and isolated QA runners. A version number in an active module is **not** proof it can be deleted.
- `V57-VISUAL-GRAMMAR-100-CATALOG-NL.md`, `V58-13-ACTIVITY-CATALOG-NL.md`: authoring references.
- `docs/`, `docker/`: operator and deployment documentation.
- `scripts/init_env.py`: one-time safe creation of a PRIVATE operator .env for production. It never overwrites a file. An incomplete configuration is **NOT READY** and cannot be deployed. Django itself does **not** automatically load .env.

Historical V60–V67 audit summaries, manifests and temporary report documents are in a **separate optional ZIP** (`Rozh-V68-HISTORICAL-RELEASE-DOCS.zip`), not the active source. Do not unpack this into the application. Old test scripts that are referenced by compatibility tests are intentionally retained.

## What this release actually verifies

Legacy static Python/JS/CSS/route/source tests and the safety contracts are documented in `V68-FINAL-AUDIT-NL.md` and the external JSON verification. Do not interpret static checks as running Django, a penetration test, real payments, SMTP delivery, PostgreSQL migrations, all browser clicks or production readiness. Real Windows/Edge tests, full end-to-end flows and security review are required before public launch. No actual .env, customer database, passwords, user uploads, private certificates or venv were shipped.

## V69 — The screenshot-reported dark-mode text failure

This release addresses the verified `Woord van de dag` contrast errors visible in user-supplied screenshots, especially nearly invisible navy text on navy cards and nearly white text on a light example card. The root cause was the legacy `--app-*` variables remaining light-themed inside the new student shell. The daily page also loaded legacy CSS links late in its body, after the theme override. The fix synchronizes old-widget palette variables with V66 explicit-theme tokens, adds page-specific foreground/background contrast for daily examples, challenges and labels, and moves daily page styles into the head before the theme override. It does not touch user data, lessons, rewards, or authentication.

In **offline browser fixtures**, 15 representative text samples across 4 UI languages, 2 themes and 4 viewport widths pass a 4.5:1 contrast threshold (32 V69 cases; 32 original V68 baseline cases used for comparison). An additional 96 mock-browser regression cases across six UI surfaces showed no new overflow or JS errors. These are **not real authenticated Django/browser integration tests**. For details see `V69-READABILITY-AUDIT-NL.md`, `V69-READABILITY-AUDIT-SORANI.md` and the external V69 verification JSON.

After extracting V69 into a **new** empty directory, start that copy, and use `Ctrl+F5` in Edge to refresh cached CSS. Do not unzip on top of an older or live folder.

## V71 — Brain Training retired

The separate flashcard review screen and its entry-point cards were removed from student UI. `/review/` and `/weekly-review/` GET now redirect to the existing Word of the Day page for old bookmarks; historic ReviewCard data and POST protections remain. This does **not** implement the requested new weekly review of actual daily words or the 5× typing for +1 heart. See `V71-BRAIN-TRAINING-REMOVAL-NL.md`.


## V76 — Kurdish grouped onboarding language picker (beta)

See `V76-TRANSLATION-STATUS.md` and `V76-RELEASE-NOTES-SORANI.md`.
New language selector groups Sorani, Badini and Kurmanji under one Kurdish card;
adds a local Ukrainian SVG flag and a Latin Kurmanji UI locale (`ku`).
The three Kurdish locales remain separately stored. Additive `0017` migration.
For real Django checks in an isolated copy run `RUN-ROZH-V76-INTEGRATION.cmd`
from an independent folder with dependencies installed in `.venv-qa`.
No production DB, private `.env`, progress or published content is included.
The 15-question calibrated placement test is a **future** phase, not part of V76.

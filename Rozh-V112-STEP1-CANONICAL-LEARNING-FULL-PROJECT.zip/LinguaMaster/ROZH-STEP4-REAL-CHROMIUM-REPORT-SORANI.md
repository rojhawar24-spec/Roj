# Rozh V95 — هەنگاوی ٤: پشکنینی Chromium ـی ڕاستەقینە بۆ Learning Path

**دۆخ:** هەنگاوی ٤ `IN PROGRESS`؛ هەنگاوی ٢ `OPEN`؛ هەنگاوی ٣/J `OPEN`؛ Production `NOT APPROVED`.

## چاکسازییەکانی ئەم وەشانە

١. **دۆخی وەرز:** لە هەڵبژاردەکانی ١٠٠ وەرزدا ناونیشانی وەک «وەرز 75 لە 100» پیشان دەدرێت. وشەی «لە / van / of» لە وەرگێڕانی هەمان ڕووکارەوە دێت، نەک دەقی سەخت نووسراوی ئینگلیزی.
٢. **Accessibility:** دوگمەکانی Previous/Next/My Season وەک گرووپی ناودار (`role="group"`) دەناسرێن. فۆکەسی کیبۆرد لە گۆڕینی وەرزدا نامێنێتەوە لە شوێنی هەڵە.
٣. **پشکنینی browser:** سکریپتی `scripts/test_step4_season_navigation_chromium.py` لە Chromium ـی ڕاستەقینەدا JavaScript و CSS ـی **خودی پڕۆژەکە** لەگەڵ نموونەیەکی HTML ـی جیاکراوە تاقی دەکاتەوە. پشکنینەکان: ١٠٠ وەرز، گۆڕینی خێرا، 360px، سۆرانی RTL، Light/Dark، کۆنتراستی دەقی دوگمە >= 4.5، فۆکەسی کیبۆرد، لینکە ڕاستەوخۆکان، دۆخی Locked، و fallback ـی بێ JavaScript.
٤. **GitHub Actions:** تاقیکردنەوەی Chromium ـی هەنگاوی ٤ پاش دامەزراندنی Playwright و Chromium و پێش تۆمارکردنی بەڵگەی CI زیاد کرا؛ نەبوونی Chromium بە `skip` ناڕوات.
٥. **پاراستنی کارەکانی پێشوو:** هیچ مۆدێل، migration، مۆڵەتی وانە، XP، Login/MFA، لوگۆ، یان فایلی تایبەتی بەکارهێنەر نەگۆڕاوە.

## ئەنجامی جێبەجێکراو

- **٤١/٤١** سکریپت سەرکەوتوون.
- **٤١٩** تاقیکردنەوەی ژمێردراو سەرکەوتوون، لەوانە **١٤** Node.js بۆ وەرزەکان، **١١** Chromium browser لەسەر HTML ـی جیاکراوە، **٤** پشکنینی ڕێکخستنی CI.
- تاقیکردنەوەی Chromium ـی 360px RTL و Light/Dark لە خۆی ئەم ژینگەیەدا **ڕانراوە** (نەک تەنها ئامادەکراوە).
- هەموو فایلەکانی وەشانی پێشوو پارێزراون؛ ZIP و هاشەکان بەپێی manifest پشتڕاست دەکرێنەوە.

## سنووری ئەم بەڵگەیە

**ئەو ١١ تاقیکردنەوەیە لە Chromium ـی ڕاستەقینەدا جێبەجێ بوون، بەڵام پەڕەکە HTML fixture ـێکی جیاکراوەیە؛ نەک وێبسایتی Django لەسەر DB.** لەبەر نەبوونی Django لەم ژینگەیەدا، پشکنینی واقعی Django HTTP، migration، 100-season server rendering، دەستگەیشتن بە وانە، Screen Reader، Windows ACL، PostgreSQL و staging هێشتا `NOT RUN` ـن. ئەمە پشتڕاستکردنەوەی تەواوی WCAG 2.2 AA نییە.

## چی ماوە لە هەنگاوی ٤؟

١. پشکنینی ڕاستەقینەی Django HTTP بۆ ١٠٠ وەرز و مۆڵەتی وانەکان.
٢. پشکنینی browser لەسەر **پەڕەی واقعی Django** لە 360px و Sorani RTL / Light و Dark.
٣. پشکنینی دەستی کیبۆرد، Screen Reader و WCAG 2.2 AA لە ڕووکارە واقعییەکە.
٤. پشکنینی performance بۆ ١٠٠ وەرز لەسەر ئامێری نوێنەرایەتی بەکارهێنەران.

**هەنگاوی ٢:** هێشتا ٥ گرووپی تاقیکردنەوەی runtime ماون. **هەنگاوی ٣/J:** ٥ دەروازەی runtime ماون. **دوای هەنگاوی ٤:** ٦ هەنگاوی سەرەکی (٥ تا ١٠). هەنگاوی ٤ هێشتا تەواو نییە.

### تاقیکردنەوەی خۆت

لە ناو `LinguaMaster`، کاتێک Python، Node و Playwright/Chromium دامەزرابن:

```powershell
node scripts/test_step4_season_navigation_offline.js
python scripts/test_step4_season_navigation_chromium.py
```

بۆ پشکنینی واقعی Django و CI، workflow ـی `.github/workflows/rozh-step2-qa.yml` لە GitHub Actions لە repository ـێکی **تایبەتی و پاک** بەکاربهێنە؛ `.env` و داتابەیسی ڕاستەقینە مەخەرە ناو repository.

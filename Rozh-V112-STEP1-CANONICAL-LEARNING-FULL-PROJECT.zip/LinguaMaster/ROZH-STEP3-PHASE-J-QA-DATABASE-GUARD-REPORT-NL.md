# Rozh V95 — Fase J vervolg: geïsoleerde SQLite QA-database

**Basis:** de volledige `Rozh-V95-STEP3-PHASE-J-QA-SECRET-GUARD-FULL-PROJECT.zip`.

## Resultaat

De testdatabase `rozh-test.sqlite3` wordt vanaf deze versie voorbereid door een
nieuwe `create_local_qa_database_file` helper, uitgevoerd bij het inladen van
`config/settings_local_qa.py`. Een pad dat *binnen* de testmap lijkt te liggen
was onvoldoende: een hardlink zou feitelijk naar hetzelfde database-inode
kunnen verwijzen als een andere lokale database. Ook symlinks binnen de testmap
waren niet expliciet verboden.

De nieuwe preflight controleert:

- QA-basismap is een echte private map (POSIX owner-only).
- Nieuwe database wordt met exclusieve creatie (mode `0600` op POSIX) aangemaakt.
- Bestaande database moet een echt regulier bestand zijn, zonder hardlinks of
  symbolische links/junctions en met veilige eigenaar/bestandsrechten op POSIX.
- `O_NONBLOCK` voorkomt dat een FIFO het opstarten blokkeert.
- Bestaande veilige database-inhoud blijft bewaard; een standaard Python SQLite
  connectie kan de nieuw voorbereide QA-database lezen en schrijven.
- De Windows QA-runner en CI offline preflight voeren de nieuwe tests uit.

**TDD-bewijs:** vóór de codewijziging: 9 tests mislukt (2 assertions, 7 errors).
Na de codewijziging en extra SQLite-compatibiliteitstest: **10/10 tests geslaagd**.
De oudere offline-broncontracttest is aangepast om de nieuwe echte helper en
bestandspad te verifiëren in plaats van het oude inline pad te vereisen.

## Regressie

- **26/26** geselecteerde offline/browser-testscripts geslaagd.
- **284** door unittest getelde tests geslaagd.
- **2** script-style tests zonder gerapporteerd `Ran N tests`-aantal geslaagd.
- Dit is geen bewijs van werkende Django HTTP-endpoints.

## Nog nodig voordat fase J gereed is — precies 5 verificatiepoorten

1. `manage.py check` en `makemigrations --check --dry-run` met echte dependencies.
2. Migratie 0019 daadwerkelijk uitvoeren op een verse, geïsoleerde testdatabase.
3. Volledige Django HTTP/SQLite integratie- en regressietests uitvoeren.
4. PostgreSQL 17 concurrency-tests uitvoeren in de geïsoleerde CI-omgeving.
5. Native Windows ACL's en de QA-runner valideren op een schone Windows-pc.

Deze vijf punten zijn **niet uitgevoerd** in de huidige omgeving. Django en
psycopg ontbreken. De helper is een extra bestandscontrole, niet een
Windows-ACL-garantie en niet bestand tegen onbeperkte gelijktijdige wijzigingen
door dezelfde OS-gebruiker tussen check en het latere openen door SQLite.

## Exacte planning

- **Nog 3 fasen van hoofdstap 3:** J (bezig), K en L (niet gestart).
- **Na J:** nog 2 fasen (K, L).
- **Hoofdstappen:** 3 van 10 is lopend; na 3 nog 7 hoofdstappen (4–10).
- Hoofdstap 2 heeft ook nog niet alle echte Django-verificatie.
- **Productie/school goedgekeurd: NEE.**

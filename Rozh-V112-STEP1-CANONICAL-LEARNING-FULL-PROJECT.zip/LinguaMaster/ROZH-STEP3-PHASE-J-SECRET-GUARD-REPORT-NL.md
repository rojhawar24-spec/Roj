# Rozh V95 — Step 3 / Phase J: QA secret descriptor hardening

**Status:** Phase J remains IN PROGRESS. K and L remain NOT STARTED. This is an isolated QA candidate, not school/production authorization.

## Changes (starting from the latest Phase-J mailbox full-project archive)

- `config/qa_filesystem_safety.py`: read the QA key descriptor with nonblocking read flags where available; reject nonregular secret files without a FIFO-induced hang, reject hardlinked secrets, enforce same-user ownership on POSIX, and bound existing secret file size to 50–512 bytes before reading. Existing private generated keys remain stable.
- `scripts/test_step3j_qa_secret_descriptor_safety_offline.py`: four behavioral cases covering FIFO, hardlink, oversized file and key stability. Before fix: 3 failures / 1 pass. After fix: 4 passes.
- `RUN-ROZH-V95-STEP2-QA.ps1` and `.github/workflows/rozh-step2-qa.yml`: run the added test as part of the offline security preflight.
- `scripts/test_step3_presentation_offline.py`: fix a standalone test-loader bug by importing `academy.solar_atlas_step3` as a package; no production presentation behavior changed.
- `ROZH-STEP3-FIXED-REMAINING-STEPS.json`: record new evidence while preserving J, K and L as the three remaining phases.

## Checks performed on this exact worktree

- 25 selected offline/browser scripts passed; 274 tests reported by unittest, plus 2 script-style smoke checks without an official `Ran N tests` counter.
- Newly added secret descriptor suite 4/4 pass; previous local QA filesystem and mailbox suites 18/18 pass.
- Original source ZIP CRC verified, source SHA-256 matched recorded previous verification.
- All project Python files parsed as AST and all JavaScript files checked using Node.js (see external verification JSON for measured totals).
- A fresh complete ZIP is checked against its included SHA-256 file manifest (verification JSON outside the archive).

## Not performed — hard release gates still open

- `python manage.py check`, `makemigrations --check`, migration `0019` application, Django HTTP and SQLite integration, and PostgreSQL concurrency: NOT EXECUTED. The environment has no Django/psycopg installed and package installation failed due to DNS/network unavailability.
- Native Windows ACL behavior not verified. No production external service or real learner database was connected.
- The broader previous 381-test run is historical evidence from the input ZIP; this output claims only the tests actually rerun above.

## Next required execution to close J

In a NEW disposable checkout with Python and the pinned `requirements.txt` dependencies available, run `RUN-ROZH-V95-STEP2-QA.ps1` on Windows and the manually dispatched `.github/workflows/rozh-step2-qa.yml` pipeline (the latter includes an isolated PostgreSQL 17 service). Capture actual passing Django, migration, SQLite HTTP, PostgreSQL concurrency and Windows isolation evidence. Keep J open until all these gates pass.

# Rozh — لیستی وەرگرتنی کۆتایی هەنگاوی ٤ (Learning Path)

**دۆخی ئێستا:** تەنها تاقیکردنەوەکانی offline و Chromium fixture سەرکەوتوون. **هیچ یەک لە ٤ گرووپی کۆتایی بە فەرمی پەسەند نەکراوە.**

## ١. Django HTTP / ١٠٠ وەرز — نەکراوە

- ژینگەی جیاکراوەی QA، هەرگیز داتابەیسی بەکارهێنەران بەکارمەهێنە.
- `python manage.py check --settings=config.settings_local_qa`
- `python manage.py makemigrations --check --dry-run --settings=config.settings_local_qa`
- `python manage.py test academy.test_step4_learning_path_100_seasons_http --settings=config.settings_local_qa --verbosity 2 --testrunner=scripts.step3j_strict_test_runner.PhaseJStrictTestRunner`
- پشکنینی سێرڤەر: ١٠٠ وەرز، وەرزی ٧٥ وەک focus، وەرزی قوفڵکراو بەبێ لینکی وانە، و ڕەتکردنەوەی داواکاریی وانەی قوفڵکراو.
- بەڵگە: CI job log، commit SHA، test count، ٠ failed/٠ unexpected skipped.

## ٢. پەڕەی واقعی Django لە Chromium — نەکراوە

- `python -m pip install -r requirements.txt`
- `python -m pip install playwright==1.57.0`
- `python -m playwright install --with-deps chromium`
- `python manage.py test scripts.step4_live_learning_path_browser_qa --settings=config.settings_local_qa --verbosity 2`
- جێبەجێکردنی ڕاستەقینە لە GitHub Actions `django-integration` دوای دامەزراندنی browser و پێش ڕاپۆرتی CI.
- بۆ 360px و سۆرانی RTL، هەر ١٠٠ وەرز، ١ panel، لینکەکانی قوفڵ، My Season، Deep link، Light/Dark و فۆکەسی کیبۆرد بپشکنە.
- بەڵگە: URL ـی CI run، test log، screenshots لە پەڕەی واقعی (نەک fixture).

## ٣. WCAG 2.2 AA / Screen Reader — نەکراوە

- لە Windows بە NVDA + Firefox/Chrome: ناوی هەڵبژێری وەرز، ژمارەی وەرز، status، دۆخی locked، لە Next/Previous/My Season دوای ناچالاکبوونی دوگمە فۆکەس لەدەست نەچێت.
- لە macOS/iOS بە VoiceOver + Safari: هەمان ڕەفتار و پشتگیری RTL.
- لە 360px و 200% zoom: هیچ دوگمە/دەق تێکەنەچێت، فۆکەس دیار بێت، tab order ڕاست بێت.
- Contrast ـی دەقەکان و کۆنترۆڵەکان، target size، تێنەگەیشتنی تەنها بە ڕەنگ، reduced-motion.
- Automated AX-tree و CSS contrast تەنها یارمەتیدەرن؛ جێگرەوەی پشکنینی دەستی Screen Reader نین.
- بەڵگە: check sheet، video/screenshots، ناوی browser و screen reader، ٠ کێشەی critical.

## ٤. Performance لە ئامێری نوێنەرایەتی — نەکراوە

- لە لاپتۆپێکی مامناوەند و مۆبایلێکی مامناوەند ١٠٠ وەرز بەڕاستی بار بکە.
- Chrome Performance/Lighthouse بۆ load، layout، memory، Core Web Vitals بەژێر سێناریۆیەکی دیاریکراو.
- گۆڕینی ٢٠ وەرزی جیاواز و گەڕانەوە بۆ ٧٥؛ هیچ قەتیبوون یان ڕەشبوونی شاشە، گەورەبوونی memory، یان horizontal overflow قبوڵ نییە.
- پشکنینی Chromium fixture لە CI synthetic ـە؛ وەک ئەنجامی ئامێری واقعی تۆمار ناکرێت.
- بەڵگە: device model، OS/browser، CPU throttling، screenshots و profile trace.

## بڕیاری داخستن

`step4_complete=true` تەنها کاتێک دابنێ کە هەموو ٤ گرووپەکە بە بەڵگەی ڕاستەقینە PASS بن. هەنگاوەکانی ٢ و ٣ بەخۆکاری تەواو نابن. Production approval پێویستی بە پشکنینی سەربەخۆی خۆی هەیە.

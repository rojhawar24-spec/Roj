# Step 3H — nieuwe migratie en Django-acceptatietests (23 november 2026)

**STATUS: KANDIDAAT, niet goedgekeurd voor productie.** De release bevat
`academy/migrations/0019_lesson_round_receipt_step3h.py` (additieve tabel met een
unieke `(user, lesson, round_key)`-constraint) en echte Django-tests in
`academy/test_step3h_durable_round_receipts_http.py`. De migratie en deze tests
zijn in de bouwomgeving **NIET** met Django uitgevoerd.

Pak de volledige ZIP uit in een **nieuwe, lege map**, ga naar `LinguaMaster`
en voer `cmd /c .\RUN-ROZH-V95-STEP2-QA.cmd` uit. De runner gebruikt
uitsluitend `.rozh-local-test/` en de Django-testdatabase, controleert
`makemigrations --check --dry-run` en voert de nieuwe Step 3H-tests plus de
volledige academy-testsuite uit. Er moet internet voor de dependency-installatie
zijn. Gebruik nooit een echte `.env` of productiegegevens bij QA. Voor gebruik
van de release met bestaande gebruikers is eerst een apart geautoriseerd en
getest migratieplan voor hun omgeving noodzakelijk.

De geïsoleerde SQLite-tests bewijzen niet automatisch dezelfde race-condities
onder PostgreSQL; voer daarnaast gelijktijdige-request/staging-tests uit.

---

# ACTUELE STATUS: Rozh V95 / stap 2 QA-kandidaat

**NIET af / NIET productiegoedgekeurd.** Zie `ROZH-STEP2-TESTPLAN-NL.md`.
Voer op een schone Windows-kopie `cmd /c .\RUN-ROZH-V95-STEP2-QA.cmd`
uit voor echte Django/SQLite-tests. Een alternatief is de handmatige GitHub
Actions-workflow in een privé-repository. Geen van beide is in de bouwomgeving
uitgevoerd. Testresultaten zijn geen productiecertificering.

---

# Rozh V68 — Veilig lokaal testen (Windows)

**Gebruik uitsluitend een nieuwe, uitgepakte kopie van de FULL PROJECT ZIP**. Gebruik geen echte `.env`, `db.sqlite3`, klantgegevens of bestaande installatie.

Open PowerShell in de map `LinguaMaster` en voer eerst `py -3.15 --version` uit. Python 3.12–3.15 is ondersteund door de startcontrole; project-dependencies kunnen eigen beperkingen hebben.

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\START-ROZH-TEST.ps1
```

Het script weigert een kopie met een echte `.env` of normale `db.sqlite3`. Het maakt een geïsoleerde `.venv-qa` en `.rozh-local-test/` aan en toont bij succes de lokale URL `http://127.0.0.1:3000/login/`. Bij de eerste keer is internet nodig voor de dependencies. Sluit de server met Ctrl+C.

Daarna kun je in dezelfde schone extractie `RUN-ROZH-V68-INTEGRATION.cmd` uitvoeren. Die test Django/SQLite op **een aparte tijdelijke kopie**, controleert migraties en een selectie login, Manager, leerlessen, route-rechten en betaalpolicy. Ontbrekende Django-dependencies of fouten zijn **NOT VERIFIED/FAIL**, niet PASS.

Voor de kleine broncontrole, zonder Django:

```powershell
py -3.15 -m unittest scripts.test_v68_final_cleanup_offline -v
```

**Let op:** De optionele historische archief-ZIP is NIET het project en mag NIET over het project worden uitgepakt. Productie-PostgreSQL, echte mailaflevering, externe AI/Stripe en volledige browsersessies zijn hierdoor niet geverifieerd.

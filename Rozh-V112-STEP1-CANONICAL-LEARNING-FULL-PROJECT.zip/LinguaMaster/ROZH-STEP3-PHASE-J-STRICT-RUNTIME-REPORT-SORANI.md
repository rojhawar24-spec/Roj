# Rozh V95 — هەنگاوی ٣، بەشی J: دەروازەی تاقیکردنەوەی سختگیر

**دۆخ: J هێشتا بە فەرمی تەواو نەبووە.** هەموو پشکنینەکانی offline/browser ی ئەم وەشانە سەرکەوتوون، بەڵام جێبەجێکردنی ڕاستەقینەی Django/SQLite، migration 0019، PostgreSQL 17 و Windows ACL لەم ژینگەیەدا نەکراوە.

## چی نوێ کرا؟

- `scripts/step3j_strict_test_runner.py`: تاقیکردنەوەی گرنگی Django کە صفر تاقیکردنەوە ڕابکات، هەر مۆدیولێکی داواکراو نەتوانێت test بدۆزێتەوە، یان هەر test ـێک بە `skip` تێپەڕێت، بە ناتەواوی/شکست هەژمار دەکات، نەک سەرکەوتن.
- `academy/test_step3i_postgres_concurrency_http.py`: لە broad SQLite regression ـدا PostgreSQL-only test بەڕوونی skip دەکات؛ بەڵام لە PostgreSQL ـی ڕاستەقینە، ئەگەر CI opt-in نەبێت بە هەڵە ڕەت دەبێتەوە. لە job ـی PostgreSQL ـیش strict runner هەر skip ـێک ڕەت دەکات.
- `.github/workflows/rozh-step2-qa.yml`: تاقیکردنەوە گرنگەکانی Ubuntu/SQLite و PostgreSQL بە strict test runner دەخاتە کار؛ تاقیکردنەوەی نوێی offline پێش runtime جێبەجێ دەکات.
- `RUN-ROZH-V95-STEP2-QA.ps1`: دوو کۆمەڵە تاقیکردنەوەی گرنگ لە Windows بە strict runner جێبەجێ دەکات و تاقیکردنەوەی نوێی offline ـیش زیادکراوە.
- `scripts/test_step3j_strict_runtime_gates_offline.py`: تاقیکردنەوەی ئاکاری دەروازەی نوێ بەبێ پێویستی بە Django.
- `scripts/test_step3i_postgres_gate_offline.py`: پشکنینی پێشووی PostgreSQL لەگەڵ دەروازەیەکی fail-closed ـی نوێ هاوتا کراوە.

## ئەنجامی تاقیکردنەوەکان

- **٢٩ لە ٢٩ سکریپت سەرکەوتوو**، **٣٠٠ تاقیکردنەوەی ژمێردراو**. دوو smoke test ـی سەرکەوتوو ژمارەی unittest ـیان نییە.
- Python AST، Node JavaScript syntax، پێکهاتەی GitHub Actions YAML، ئاستی پاراستنی داتابەیسی QA و SHA-256 ی هەموو فایلەکان پشکنراون.
- هەموو ٩٩٠ فایلی ZIP ـی پێشوو پارێزراون؛ بەشێکی زۆریان وەک خۆیان ماونەتەوە.
- پشکنینی `django` بەهۆی نەبوونی پەکێجی Django سەرنەکەوت؛ `pip index versions Django` ـیش پەکێجی گونجاوی نەدۆزییەوە. PostgreSQL و Windows runtime لەم ژینگەیەدا نییە.

## داخستنی بەشی J — تەنها بە بەڵگە

١. Django system check و makemigrations parity لە ژینگەی QA ی ڕاستەقینە.
٢. جێبەجێکردنی migration 0019 و پشکنینی خشتە و unique constraint لە داتابەیسی جیای QA.
٣. تاقیکردنەوەی Django HTTP/SQLite و full academy regression.
٤. تاقیکردنەوەی PostgreSQL 17 concurrency (دوبارەکردنەوەی هەمان پەیام، XP، hearts).
٥. تاقیکردنەوەی ڕاستەقینەی Windows ACL و Django/SQLite.

هەموویان پێویستە لە GitHub Actions بەرز بکرێنەوە و ئەنجامی هەرسێ job ـی `django-integration`، `django-postgres-concurrency` و `windows-acl-and-sqlite` سەرکەوتوو بێت. دواتر `phase-j-gate` دەبێت سەرکەوتوو بێت. **هەموو فایلەکانی ZIP ـەکە لە ڕیشەی repository (شوێنی `manage.py`) بخە؛ ناو فۆڵدەری دووەم مەیانخە.**

لەسەر Windows لە ZIP ـی پاکدا `RUN-ROZH-V95-STEP3-J-QA.cmd` جێبەجێ بکە. پەکێجەکانی `requirements.txt` پێویستە بەردەست بن. ئەمە جێگرەوەی PostgreSQL CI نییە.

## ژمارەی ماوەکان

- بەشی J: **٥ دەروازەی runtime** هێشتا بەڵگەی PASS ـی ڕاستەقینەیان نییە.
- هەنگاوی ٣: **٣ بەش (J, K, L)**، دوای داخستنی J **٢ بەش** دەمێنێت.
- هەنگاوە سەرەکییەکان: ئێستا لە **٣ لە ١٠**، هەنگاوە سەرەکییە ماوەکان لەگەڵ ئێستا **٨**، دوای تەواوبوونی ٣ **٧**.
- **Production/School: پەسەند نەکراوە**.

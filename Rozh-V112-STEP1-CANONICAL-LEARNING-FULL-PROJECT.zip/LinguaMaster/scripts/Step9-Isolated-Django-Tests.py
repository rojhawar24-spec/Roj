"""Django regression runner that refuses to use the live/local Rozh database.

Must be launched from an extracted COPY, not from an operational deployment.
Django 6.1.3 and requirements must be installed beforehand in a NEW test venv.
No .env file is loaded. No user's SQLite file is read or modified.

python scripts/Step9-Isolated-Django-Tests.py
python scripts/Step9-Isolated-Django-Tests.py --all
"""
import os
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
if Path.cwd().resolve() != ROOT.resolve():
    raise SystemExit('Run from the project root of a separately extracted test copy.')
if (ROOT / '.env').exists() or (ROOT / 'db.sqlite3').exists():
    raise SystemExit('Refusing: a local .env or db.sqlite3 exists in this test copy.')
if sys.argv[1:] not in ([], ['--all']):
    raise SystemExit('Supported arguments: none, or --all')

# Override potentially inherited environment BEFORE Django imports settings.
# No account credentials, SMTP server, production Postgres or cache is used.
os.environ.update(
    DJANGO_SETTINGS_MODULE='config.settings',
    DJANGO_DEBUG='1',
    USE_SQLITE='1',
    REQUIRE_EMAIL_VERIFICATION='0',
    DJANGO_ALLOWED_HOSTS='localhost,127.0.0.1,testserver',
    SITE_URL='http://testserver',
    DJANGO_SECRET_KEY='ROZH-STEP9-EPHEMERAL-TEST-ONLY-NOT-FOR-DEPLOYMENT',
    LINGUAMASTER_TOTP_KEY='',
    EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend',
    DEFAULT_FROM_EMAIL='Rozh Test <noreply@example.test>',
)

with tempfile.TemporaryDirectory(prefix='rozh_step9_isolated_sqlite_') as directory:
    target = (Path(directory) / 'step9.sqlite3').resolve()
    import django
    if django.get_version() != '6.1.3':
        raise SystemExit('Expected Django 6.1.3; got ' + django.get_version())
    from django.conf import settings
    settings.DATABASES['default']['ENGINE'] = 'django.db.backends.sqlite3'
    settings.DATABASES['default']['NAME'] = str(target)
    if (settings.DATABASES['default']['ENGINE'] != 'django.db.backends.sqlite3'
        or Path(settings.DATABASES['default']['NAME']).resolve() != target
        or not str(target).startswith(str(Path(directory).resolve()) + os.sep)):
        raise SystemExit('Unsafe DB target; refusing to run.')
    django.setup()
    from django.db import connections
    if Path(connections['default'].settings_dict['NAME']).resolve() != target:
        raise SystemExit('Django connection is not isolated. REFUSING.')
    from django.core.management import call_command
    print('ISOLATED TEST DATABASE:', target)
    print('Django:', django.get_version())
    print('EMAIL VERIFICATION DEFAULT: OFF; TestCase also exercises ON via override_settings')
    call_command('check')
    labels = ['academy'] if sys.argv[1:] == ['--all'] else [
        'academy.test_step1_solar_onboarding',
        'academy.test_solar_atlas_step2',
        'academy.test_solar_atlas_step3',
        'academy.test_solar_atlas_step4',
        'academy.test_solar_atlas_step5',
        'academy.test_solar_atlas_step6',
        'academy.test_solar_atlas_step7',
        'academy.test_rozh_v47_manager',
        'academy.test_rozh_v48_manager_role',
    ]
    # Uses a Django-managed temporary TEST DB, not target or user's database.
    result = call_command('test', *labels, verbosity=2, interactive=False, keepdb=False)
    print('PASSED: isolated Django tests against temporary SQLite')

"""Operator-triggered, LOCAL-only test learner. No raw password output/logging.
Not a Manager, not an administrator, not a verified email owner.
"""
import argparse
import getpass
import os
import re
import sys
from pathlib import Path
from urllib.parse import urlsplit


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--username', default='rozh_demo_2026')
    args = parser.parse_args()
    username = args.username.strip()
    if not re.fullmatch(r'rozh_demo_[a-z0-9_]{2,30}', username):
        raise SystemExit('[STOP] Demo username must start with rozh_demo_ followed by 2-30 lowercase letters/numbers/underscores.')
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
    import django
    django.setup()
    from django.conf import settings
    from django.contrib.auth import get_user_model
    from django.contrib.auth.password_validation import validate_password
    from django.core.exceptions import ValidationError
    from django.db import transaction
    from academy.models import Profile
    site = urlsplit(settings.SITE_URL)
    cfg = settings.DATABASES['default']
    if (not settings.DEBUG or site.scheme != 'http' or
            site.hostname not in ('localhost', '127.0.0.1') or
            cfg['ENGINE'] != 'django.db.backends.sqlite3' or
            Path(cfg['NAME']).resolve() != (Path(settings.BASE_DIR) / 'db.sqlite3').resolve()):
        raise SystemExit('[STOP] Refused outside actual local DEBUG+loopback SQLite project.')
    if not sys.stdin.isatty():
        raise SystemExit('[STOP] An interactive local terminal is required for hidden password entry.')
    User = get_user_model()
    if User.objects.filter(username__iexact=username).exists():
        raise SystemExit('[STOP] This username already exists; the account was NOT changed. Choose another rozh_demo_ name.')
    email = username + '@example.invalid'
    if User.objects.filter(email__iexact=email).exists():
        raise SystemExit('[STOP] Example email collision; choose another username.')
    print('New LOCAL test LEARNER; NOT a Manager or Django Admin.')
    print('Choose a unique password (at least 8 characters). Hidden while typing.')
    first = getpass.getpass('Password: ')
    second = getpass.getpass('Repeat password: ')
    if not first or first != second:
        raise SystemExit('[STOP] Passwords do not match; account was NOT created.')
    candidate = User(username=username, email=email)
    try:
        validate_password(first, user=candidate)
    except ValidationError:
        raise SystemExit('[STOP] Password failed Django password policy; account was NOT created.') from None
    with transaction.atomic():
        if User.objects.filter(username__iexact=username).exists():
            raise SystemExit('[STOP] Username was taken; account was NOT changed.')
        user = User.objects.create_user(username=username, email=email, password=first, is_active=True,
                                        is_staff=False, is_superuser=False)
        profile, _ = Profile.objects.get_or_create(user=user)
        if profile.legacy_review_required or profile.suspended_at or profile.email_verified_at:
            raise RuntimeError('Unexpected test-account state; transaction rolled back.')
    del first, second
    print('[PASS] Created ONE active, nonprivileged local learner with a hashed password.')
    print('Username: ' + username)
    print('Password: the private password you just entered (never printed).')
    print('Sign in at http://127.0.0.1:3000/login/')
    print('Email is a non-deliverable .invalid address, unverified; no password recovery or Manager privileges.')
    print('Existing accounts, passwords, XP, manager roles and learning progress were not modified.')


if __name__ == '__main__':
    main()

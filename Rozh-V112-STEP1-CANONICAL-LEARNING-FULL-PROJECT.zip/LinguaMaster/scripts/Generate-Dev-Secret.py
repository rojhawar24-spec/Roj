"""Generate a temporary development key. Keep output private and out of logs."""
from secrets import token_urlsafe
if __name__ == '__main__':
    print(token_urlsafe(48))

"""ONLY an empty, disposable Docker PostgreSQL database at localhost:55432.

NEVER run against production, a populated DB, or any database with a different
name/port/host. Read the PowerShell instructions before running.
"""
import os

if os.environ.get('DJANGO_DEBUG') != '1' or os.environ.get('USE_SQLITE') != '0':
    raise RuntimeError('Must explicitly set DJANGO_DEBUG=1 and USE_SQLITE=0')
if (os.environ.get('POSTGRES_DB') != 'rozh_step1_rehearsal' or
    os.environ.get('POSTGRES_HOST') != '127.0.0.1' or
    os.environ.get('POSTGRES_PORT') != '55432'):
    raise RuntimeError('Unsafe PostgreSQL target: must be localhost:55432/rozh_step1_rehearsal')

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
import django
django.setup()
from django.db import connection, connections
from django.db.migrations.executor import MigrationExecutor
from django.contrib.auth.hashers import make_password

if connection.vendor != 'postgresql':
    raise RuntimeError('This script must run on PostgreSQL')
with connection.cursor() as cur:
    cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE'")
    present = [r[0] for r in cur.fetchall()]
    if present:
        raise RuntimeError('The PostgreSQL database is NOT EMPTY: refusing to migrate')

before=('academy','0012_onboarding_draft_v52')
after=('academy','0013_onboarding_required_solar')
try:
    executor=MigrationExecutor(connection)
    executor.migrate([before])
    old_state=executor.loader.project_state([before]).apps
    old_user=old_state.get_model('auth','User')
    old_profile=old_state.get_model('academy','Profile')
    u=old_user.objects.create(username='step1_postgres_legacy', password=make_password('testonly'), is_active=True)
    old_profile.objects.create(user_id=u.pk, xp=48, streak=3, onboarding_completed=False)
    executor=MigrationExecutor(connection)
    executor.migrate([after])
    from academy.models import Profile
    row=Profile.objects.get(user_id=u.pk)
    assert row.onboarding_required is False and row.xp==48 and row.streak==3 and not row.onboarding_completed
    print('PASSED: PostgreSQL forward 0012->0013, historical progress unchanged')
    executor=MigrationExecutor(connection)
    executor.migrate([before])
    executor=MigrationExecutor(connection)
    historical=executor.loader.project_state([before]).apps.get_model('academy','Profile')
    assert historical.objects.get(user_id=u.pk).xp==48
    print('PASSED: PostgreSQL backward 0013->0012, historical progress unchanged')
    executor=MigrationExecutor(connection)
    executor.migrate([after])
    print('PASSED: PostgreSQL reapply 0013 (disposable test DB only)')
finally:
    connections.close_all()

"""V85 role/route declaration audit; NOT a live request/security scan."""
import ast
import json
from pathlib import Path
R=Path(__file__).resolve().parent.parent
reqs=[
 ('academy/views.py','manager', {'manager_only',"require_http_methods(['GET', 'POST'])"}),
 ('academy/views.py','manager_users',{'manager_only','require_GET'}),
 ('academy/views.py','manager_user_action',{'manager_only','require_POST','transaction.atomic'}),
 ('academy/views.py','manager_award',{'owner_only','require_POST','transaction.atomic'}),
 ('academy/manager_content_v48.py','content_list',{'manager_only','require_GET'}),
 ('academy/manager_content_v48.py','content_edit',{'manager_only',"require_http_methods(['GET', 'POST'])"}),
 ('academy/manager_content_v48.py','audit_log_page',{'manager_only','require_GET'}),
 ('academy/manager_grammar_v75.py','grammar_article_editor',{'manager_only'}),
 ('academy/manager_readiness_v79.py','manager_ai',{'manager_only',"require_http_methods(['GET', 'POST'])"}),
 ('academy/manager_readiness_v79.py','readiness',{'manager_only',"require_http_methods(['GET'])"}),
]
results=[]
for p,name,required in reqs:
    text=(R/p).read_text(encoding='utf-8')
    node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==name)
    dec={ast.unparse(d) for d in node.decorator_list}
    missing=sorted(required-dec)
    results.append({'file':p,'view':name,'decorators':sorted(dec),'mandatory_declared':not missing,'missing':missing})
passed=all(row['mandatory_declared'] for row in results)
report={'scope':'static decorator inventory; not runtime HTTP proof', 'checks':results,'all_declared':passed,
        'actual_http_status':'NOT RUN - Django missing in current container'}
(R/'ROZH-V85-STEP2-ROUTE-AUDIT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print('ROUTE_DECLARATION_AUDIT',len(results),'PASS' if passed else 'FAIL')
for r in results:
  if r['missing']:print(r['view'],'missing:',r['missing'])
if not passed:raise SystemExit(1)

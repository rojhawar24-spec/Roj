"""Rebuild public home CSS from existing proven sources plus v31 refinements.

Run from project root: python scripts/build_home_bundle.py
Unlike changing shared style.css, this keeps account and learning pages untouched.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STATIC = ROOT / 'academy' / 'static' / 'academy'
SOURCES = ('style.css', 'home-v23.css', 'home-v25.css', 'home-v27.css', 'home-v31-overrides.css')
OUT = STATIC / 'home-v31-bundle.css'
body = '/* GENERATED: python scripts/build_home_bundle.py; do not edit directly. */\n'
for source in SOURCES:
    body += '\n/* SOURCE: ' + source + ' */\n' + (STATIC / source).read_text('utf-8') + '\n'
OUT.write_text(body,'utf-8')
print(f'HOME CSS: {len(SOURCES)} sources -> {OUT.name}: {OUT.stat().st_size:,} bytes')

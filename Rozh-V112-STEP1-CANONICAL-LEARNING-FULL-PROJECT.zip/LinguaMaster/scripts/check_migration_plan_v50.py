"""Read-only guard: allow only the historically reviewed additive V35/V36/V46 migrations.
Never marks migrations as applied and never runs migration operations.
"""
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
import django
django.setup()
from django.db import connection
from django.db.migrations.executor import MigrationExecutor

ALLOWED = {
    ('academy', '0009_account_suspension_state'),
    ('academy', '0010_quarantine_legacy_pending_accounts'),
    ('academy', '0011_rozh_editorial_seasons'),
}

executor = MigrationExecutor(connection)
plan = executor.migration_plan(executor.loader.graph.leaf_nodes())
if not plan:
    print('[PASS] No migrations pending.')
else:
    print('[INFO] Pending migrations, ordered:')
    for migration, backwards in plan:
        key = (migration.app_label, migration.name)
        print('  ' + '.'.join(key))
        if backwards or key not in ALLOWED:
            raise SystemExit('[STOP] Unknown, reverse or unreviewed migration. NO database change permitted.')
    print('[PASS] Only approved existing migration files are pending (0009/0010/0011).')
    print('[NOTICE] 0009 and 0010 can mark ambiguous legacy accounts as suspended/quarantined; they never auto-activate users.')

"""Rozh V54 STEP 11 — disposable Django + migration regression rehearsal.

ONLY run from a freshly extracted complete project copy, never the working
installation. Requires Django 6.1.3 and all pinned project dependencies.

From root with manage.py:
    python scripts/Step11-Isolated-Django-Tests.py --migrations
    python scripts/Step11-Isolated-Django-Tests.py
    python scripts/Step11-Isolated-Django-Tests.py --all
    python scripts/Step11-Isolated-Django-Tests.py --aliases

No .env, live database, SMTP or PostgreSQL server is read or modified. This
script deliberately does NOT test an upgrade on real user data.
"""
import os
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
if Path.cwd().resolve() != ROOT.resolve() or not (ROOT / 'manage.py').is_file():
    raise SystemExit('REFUSED: run only from the root of a fresh extracted project COPY.')
if sys.argv[1:] not in ([], ['--all'], ['--migrations'], ['--aliases']):
    raise SystemExit('Supported: no argument, --all, --migrations, or --aliases.')

# Check for real credentials, original database, and SQLite journal files in
# project root. Refuse before importing Django or initializing its settings.
unsafe = [ROOT / '.env', ROOT / 'db.sqlite3', ROOT / 'db.sqlite3-wal',
          ROOT / 'db.sqlite3-shm', ROOT / 'db.sqlite3-journal']
unsafe += list(ROOT.glob('*.sqlite')) + list(ROOT.glob('*.sqlite3'))
if any(path.exists() or path.is_symlink() for path in unsafe):
    raise SystemExit('REFUSED: .env/SQLite file detected in this copy. Never test on a user database.')

# Remove potentially inherited application production settings and secrets.
# The process still retains operating-system variables (PATH, SystemRoot,
# VIRTUAL_ENV) required by Windows/Python, but none of the app service URLs,
# mail credentials or application secret keys inherited from a parent shell.
protected_prefixes = ('DJANGO_', 'POSTGRES_', 'REDIS_', 'CELERY_', 'EMAIL_', 'AI_',
                      'STRIPE_', 'LINGUAMASTER_', 'ROZH_', 'DATABASE_')
protected_exact = {'SECRET_KEY', 'TRUST_PROXY', 'SITE_URL', 'USE_SQLITE',
                   'REQUIRE_EMAIL_VERIFICATION', 'DEFAULT_FROM_EMAIL',
                   'BUILD_STATIC_MANIFEST'}
for key in list(os.environ):
    if key.upper() in protected_exact or key.upper().startswith(protected_prefixes):
        os.environ.pop(key, None)

os.environ.update(
    DJANGO_SETTINGS_MODULE='config.settings', DJANGO_DEBUG='1', USE_SQLITE='1',
    REQUIRE_EMAIL_VERIFICATION='0',
    DJANGO_ALLOWED_HOSTS='localhost,127.0.0.1,testserver',
    SITE_URL='http://testserver',
    DJANGO_SECRET_KEY='ROZH-STEP11-TEST-ONLY-NOT-FOR-DEPLOYMENT-DO-NOT-REUSE',
    EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend',
    DEFAULT_FROM_EMAIL='Rozh Test <noreply@example.test>',
    REDIS_URL='redis://127.0.0.1:0/15',
    AI_API_KEY='',
)

with tempfile.TemporaryDirectory(prefix='rozh_step11_disposable_db_') as directory:
    db_path = (Path(directory) / 'rehearsal.sqlite3').resolve()
    test_db = (Path(directory) / 'django-tests.sqlite3').resolve()
    alias_db = (Path(directory) / 'secondary-alias.sqlite3').resolve()
    try:
        import django
    except ImportError as error:
        raise SystemExit('BLOCKED: Django is not installed in this isolated Python environment.') from error
    if django.get_version() != '6.1.3':
        raise SystemExit(f'BLOCKED: expected Django 6.1.3, got {django.get_version()}')
    from django.conf import settings
    # settings is lazy here; force sandbox database BEFORE django.setup().
    settings.DATABASES['default']['ENGINE'] = 'django.db.backends.sqlite3'
    settings.DATABASES['default']['NAME'] = str(db_path)
    settings.DATABASES['default']['TEST'] = {'NAME': str(test_db)}
    if sys.argv[1:] == ['--aliases']:
        # A second disposable database proves data migrations use
        # schema_editor.connection.alias instead of the implicit default.
        settings.DATABASES['secondary'] = {
            **settings.DATABASES['default'], 'NAME': str(alias_db),
            'TEST': {'NAME': str(Path(directory) / 'secondary-tests.sqlite3')},
        }
    django.setup()
    from django.db import connection, connections
    from django.db.migrations.executor import MigrationExecutor
    from django.core.management import call_command
    if (connection.vendor != 'sqlite' or
            Path(connections['default'].settings_dict['NAME']).resolve() != db_path or
            Path(settings.DATABASES['default']['TEST']['NAME']).resolve() != test_db or
            db_path.parent != Path(directory).resolve()):
        raise SystemExit('REFUSED: the Django DB is not the disposable SQLite target.')
    print('STEP11: Django', django.get_version())
    print('STEP11: temporary SQLite only:', db_path)
    print('STEP11: no live database, SMTP, Redis or AI provider.')
    if sys.argv[1:] == ['--aliases']:
        # The default database remains a canary: it must not be touched even
        # while migrating 0008 MFA encryption and 0009 account suspension.
        from datetime import datetime, timezone
        secondary = connections['secondary']
        if (secondary.vendor != 'sqlite' or
                Path(secondary.settings_dict['NAME']).resolve() != alias_db or
                db_path.exists()):
            raise SystemExit('REFUSED: secondary alias is not isolated.')
        try:
            executor = MigrationExecutor(secondary)
            executor.migrate([('academy', '0007_season_rewards_v14')])
            historic = executor.loader.project_state([('academy', '0007_season_rewards_v14')]).apps
            OldUser = historic.get_model('auth', 'User')
            OldProfile = historic.get_model('academy', 'Profile')
            verified_user = OldUser.objects.using('secondary').create(
                username='step11_test_verified', password='!unusable', is_active=False)
            pending_user = OldUser.objects.using('secondary').create(
                username='step11_test_pending', password='!unusable', is_active=False)
            stamp = datetime(2026, 11, 13, tzinfo=timezone.utc)
            OldProfile.objects.using('secondary').create(
                user_id=verified_user.pk, totp_secret='JBSWY3DPEHPK3PXP',
                email_verified_at=stamp)
            OldProfile.objects.using('secondary').create(
                user_id=pending_user.pk, totp_secret='', email_verified_at=None)

            executor = MigrationExecutor(secondary)
            executor.migrate([('academy', '0008_secure_login_mfa')])
            with secondary.cursor() as cursor:
                cursor.execute('SELECT totp_secret FROM academy_profile WHERE user_id = %s',
                               [verified_user.pk])
                encrypted = cursor.fetchone()[0]
            if not encrypted.startswith('enc:v1:') or 'JBSWY3DPEHPK3PXP' in encrypted:
                raise RuntimeError('FAILED: 0008 did not encrypt the synthetic MFA seed at rest.')
            if db_path.exists():
                raise RuntimeError('FAILED: 0008 touched the default database file.')
            print('PASS: 0008 encrypted a synthetic seed only on secondary SQLite alias.')

            executor = MigrationExecutor(secondary)
            executor.migrate([('academy', '0009_account_suspension_state')])
            historical = executor.loader.project_state([('academy', '0009_account_suspension_state')]).apps
            ProfileV9 = historical.get_model('academy', 'Profile')
            verified = ProfileV9.objects.using('secondary').get(user_id=verified_user.pk)
            pending = ProfileV9.objects.using('secondary').get(user_id=pending_user.pk)
            if not verified.suspended_at or not verified.suspended_was_active:
                raise RuntimeError('FAILED: verified inactive test account was not classified.')
            if pending.suspended_at is not None or pending.suspended_was_active:
                raise RuntimeError('FAILED: pending test account was incorrectly suspended.')
            if db_path.exists():
                raise RuntimeError('FAILED: 0009 touched the default database file.')
            print('PASS: 0009 classified synthetic accounts only on secondary SQLite alias.')
            print('PASS: default SQLite file never created; no production connection configured.')
        finally:
            connections.close_all()
    else:
        call_command('check', verbosity=1)
        call_command('makemigrations', 'academy', check=True, dry_run=True, verbosity=1)

    if sys.argv[1:] != ['--aliases']:
        # Real MigrationExecutor rehearsal, from the previous 0012 schema to
        # STEP11's current 0013 schema and back, with synthetic legacy data only.
        before = ('academy', '0012_onboarding_draft_v52')
        after = ('academy', '0013_onboarding_required_solar')
        try:
            executor = MigrationExecutor(connection)
            executor.migrate([before])
            state_before = executor.loader.project_state([before]).apps
            User = state_before.get_model('auth', 'User')
            Profile = state_before.get_model('academy', 'Profile')
            account = User.objects.using('default').create(
                username='step11_legacy_dummy', password='!unusable-test-password', is_active=True)
            Profile.objects.using('default').create(
                user_id=account.pk, xp=71, streak=9, onboarding_completed=False)

            executor = MigrationExecutor(connection)
            executor.migrate([after])
            state_after = executor.loader.project_state([after]).apps
            updated = state_after.get_model('academy', 'Profile').objects.using('default').get(user_id=account.pk)
            if updated.xp != 71 or updated.streak != 9 or updated.onboarding_required is not False:
                raise RuntimeError('FAILED: STEP11 migration changed legacy progress/flag.')
            print('PASS: 0012 -> 0013 preserved synthetic legacy progress, default onboarding false.')

            executor = MigrationExecutor(connection)
            executor.migrate([before])
            rolled = executor.loader.project_state([before]).apps.get_model('academy', 'Profile').objects.using('default').get(user_id=account.pk)
            if rolled.xp != 71 or rolled.streak != 9 or rolled.onboarding_completed is not False:
                raise RuntimeError('FAILED: STEP11 rollback changed synthetic legacy progress.')
            print('PASS: 0013 -> 0012 preserved synthetic legacy progress.')

            executor = MigrationExecutor(connection)
            executor.migrate([after])
            again = executor.loader.project_state([after]).apps.get_model('academy', 'Profile').objects.using('default').get(user_id=account.pk)
            if again.xp != 71 or again.streak != 9 or again.onboarding_required is not False:
                raise RuntimeError('FAILED: STEP11 reapply changed synthetic legacy progress.')
            print('PASS: 0012 -> 0013 reapply preserved synthetic legacy progress.')
            if sys.argv[1:] == ['--migrations']:
                print('STEP11 isolated SQLite migration rehearsal passed.')
            else:
                focused = [
                    'academy.test_step1_solar_onboarding',
                    'academy.test_auth_v41',
                    'academy.test_password_policy_v31',
                    'academy.test_solar_atlas_step2',
                    'academy.test_solar_atlas_step3',
                    'academy.test_solar_atlas_step4',
                    'academy.test_solar_atlas_step5',
                    'academy.test_solar_atlas_step6',
                    'academy.test_solar_atlas_step7',
                    'academy.test_rozh_v47_manager',
                    'academy.test_rozh_v48_manager_role',
                ]
                labels = ['academy'] if sys.argv[1:] == ['--all'] else focused
                # Django test runner creates a separate empty test SQLite file.
                # It never points at this test's migration-rehearsal DB.
                call_command('test', *labels, verbosity=2, interactive=False, keepdb=False)
                print('PASS: focused/complete isolated Django regression suite.')
        finally:
            connections.close_all()

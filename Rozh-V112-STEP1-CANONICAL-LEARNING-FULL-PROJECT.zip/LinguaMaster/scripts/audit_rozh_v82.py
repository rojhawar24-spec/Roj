"""Dependency-free SOURCE inventory. Does not claim Django, audio, or course QA.

Run: python scripts/audit_rozh_v82.py

This is deliberately a reporting tool, not a publication/approval switch.
"""
import ast
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
APP=ROOT/'academy'


def assignment_literal(path,name):
    module=ast.parse(path.read_text(encoding='utf8'))
    for node in module.body:
        if isinstance(node,(ast.Assign,ast.AnnAssign)):
            names=[n.id for n in node.targets if isinstance(n,ast.Name)] if isinstance(node,ast.Assign) else [node.target.id] if isinstance(node.target,ast.Name) else []
            if name in names:return ast.literal_eval(node.value)
    raise KeyError(f'{name} not found in {path}')


def audit():
    activities=assignment_literal(APP/'lesson_activities_v58.py','KINDS')
    components=assignment_literal(APP/'grammar_components_v57.py','COMPONENT_CATALOG')
    ui=assignment_literal(APP/'ui_languages_v74.py','LANGUAGE_OPTIONS')
    expected_courses=('nl','en','de','fr')
    locales=('nl','en','de','fr','uk','ar','ckb','kmr','ku')
    audio_catalog=json.loads((APP/'static/academy/audio-v78/catalog.json').read_text(encoding='utf8'))
    verified=[];rejected=[]
    for key,entry in audio_catalog.get('clips',{}).items():
        try:
            p=APP/'static'/entry['path']
            if (not p.is_file() or sha256(p.read_bytes()).hexdigest()!=entry['sha256']
                    or not entry.get('reviewed') or entry.get('audio_quality_review_required') is not False):
                raise ValueError('file hash or approval missing')
            verified.append(entry.get('language'))
        except (ValueError,KeyError,OSError,TypeError):rejected.append(key)
    font_files=[str(p.relative_to(ROOT)) for p in (APP/'static').rglob('*') if p.suffix.lower() in {'.woff','.woff2','.ttf','.otf'}]
    script=(APP/'static/academy/rozh-activities-v82.js').read_text(encoding='utf8')
    lessons=(APP/'templates/academy/lesson_activity_v58.html').read_text(encoding='utf8')
    return {
        'scope':'SOURCE-ONLY AUDIT — NOT LIVE RUNTIME OR SCHOOL ACCEPTANCE',
        'activities':{'registered':len(activities),'keys':[k for k,_ in activities],
                      'distinct_v82_interaction_markers':{k:k in lessons and key in script for k,key in [('sentence_builder','data-v82-compose'),('word_order','data-v82-order')]},
                      'published_count':'NOT_MEASURED_NO_DATABASE','pedagogy_review':'NOT_RUN'},
        'grammar':{'registered_component_types':len(components),'layout_families':dict(Counter(row[2] for row in components)),
                   'actual_approved_lessons':'NOT_MEASURED_NO_DATABASE','independent_school_qa':'NOT_RUN'},
        'languages':{'interface_language_keys':[r[0] for r in ui],'course_language_keys':expected_courses,
                     'locale_direction':{r[0]:r[3] for r in ui},'native_speaker_review':'NOT_RUN'},
        'audio':{'expected_locale_keys':locales,'approved_unchanged_audio_clips':len(verified),
                 'approved_clips_by_locale':dict(Counter(verified)),'invalid_catalog_entries':rejected,
                 'native_pronunciation_review':'NOT_VERIFIED','commercial_license_review':'NOT_VERIFIED'},
        'fonts':{'bundled_font_files':font_files,'kurdish_arabic_font_quality':'NOT_VERIFIED'},
        'manager_ai':{'page_source_exists':(APP/'templates/academy/manager_ai_v79.html').exists(),
                      'provider_roundtrip':'NOT_TESTED','MFA_accounts':'NOT_TESTED'},
        'infrastructure':{'django_dependency':'6.1.3 in requirements.txt; NOT INSTALLED IN THIS ENVIRONMENT',
                          'production_ready':False}
    }

if __name__=='__main__':
    print(json.dumps(audit(),ensure_ascii=False,indent=2))

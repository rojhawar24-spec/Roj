"""Run STEP12 Django feature/migration checks ONLY in a fresh disposable copy.

Prerequisites: Python 3.13, Django 6.1.3, all requirements installed inside
an isolated virtual environment, from a freshly extracted project copy.

    python scripts/Step12-Run-Disposable-Feature-Suite.py --full
    python scripts/Step12-Run-Disposable-Feature-Suite.py --features

--full runs an independent alias-migration canary and then the full Django
feature regression suite, both via the STEP11 safe temporary-DB runner.
No real accounts, .env, production database, SMTP, Redis, or AI tokens are read.
"""
from pathlib import Path
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
if len(sys.argv) != 2 or sys.argv[1] not in ('--full', '--features'):
    raise SystemExit('Usage: python scripts/Step12-Run-Disposable-Feature-Suite.py --full|--features')
if Path.cwd().resolve() != ROOT.resolve() or not (ROOT / 'manage.py').is_file():
    raise SystemExit('REFUSED: run from the root of a freshly extracted COPY of LinguaMaster.')
for forbidden in ('.env', 'db.sqlite3', 'db.sqlite3-wal', 'db.sqlite3-shm', 'db.sqlite3-journal'):
    if (ROOT / forbidden).exists() or (ROOT / forbidden).is_symlink():
        raise SystemExit('REFUSED: local credentials or SQLite file detected; do not run against user data.')
if any(ROOT.glob('*.sqlite')) or any(ROOT.glob('*.sqlite3')):
    raise SystemExit('REFUSED: an SQLite file is present at the project root.')
runner = ROOT / 'scripts' / 'Step11-Isolated-Django-Tests.py'
if not runner.is_file():
    raise SystemExit('REFUSED: isolated Django database runner not found.')

# The existing STEP11 runner has an additional independent set of refusal
# checks and erases inherited production app settings in the child process.
commands = ['--aliases', '--all'] if sys.argv[1] == '--full' else ['--all']
for mode in commands:
    cmd = [sys.executable, str(runner), mode]
    print('STEP12 isolated execution:', ' '.join(cmd), flush=True)
    result = subprocess.run(cmd, cwd=str(ROOT), check=False)
    if result.returncode:
        raise SystemExit('FAILED/BLOCKED: ' + mode + ' returned ' + str(result.returncode))
print('STEP12: all requested REAL Django checks succeeded on disposable DBs.')

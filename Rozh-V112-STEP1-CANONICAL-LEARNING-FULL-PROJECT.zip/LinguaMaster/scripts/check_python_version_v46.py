"""Exit 0 only for a supported local Python interpreter; no inline Python code."""
import sys

if not ((3, 12) <= sys.version_info[:2] <= (3, 15)):
    sys.exit(1)

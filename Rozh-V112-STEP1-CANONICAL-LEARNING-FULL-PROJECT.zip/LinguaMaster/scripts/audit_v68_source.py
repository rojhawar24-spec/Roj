#!/usr/bin/env python3
"""Repeatable V68 STATIC inspection. Does not require Django or access private DBs.

These checks cannot certify security, correct role permissions, runtime links,
or production readiness. Source checks are deliberately distinguished from
real HTTP/ORM/browser tests in the published verification document.
"""
import argparse
import ast
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
FORBIDDEN_NAMES = {'.env', 'db.sqlite3', 'qa-secret.key'}
FORBIDDEN_SUFFIXES = {'.p12', '.pfx', '.sqlite3'}
STATIC_RE = re.compile(r'{%\s*static\s+[\'\"]([^\'\"]+)[\'\"]\s*%}')
URL_TAG_RE = re.compile(r'{%\s*url\s+[\'\"]([^\'\"]+)[\'\"]')
ROUTE_RE = re.compile(r'\bname\s*=\s*[\'\"]([^\'\"]+)[\'\"]')


def run():
    files = [p for p in ROOT.rglob('*') if p.is_file()]
    result = {'scope': 'STATIC_SOURCE_ONLY', 'python_ast': 0, 'js_node_syntax': 0,
              'css_tinycss2': 0, 'css_parser_available': False,
              'static_references': 0, 'named_route_references': 0,
              'named_route_definitions': 0, 'errors': [], 'warnings': [],
              'private_data_files': []}
    for p in files:
        rel = p.relative_to(ROOT)
        if ('__pycache__' in rel.parts or p.suffix == '.pyc'):
            continue  # Excluded by ZIP packaging, not a privacy finding.
        if (p.suffix.lower() in FORBIDDEN_SUFFIXES or p.name in FORBIDDEN_NAMES
                or (p.name.startswith('.env') and p.name != '.env.example')):
            result['private_data_files'].append(str(rel))
        if p.suffix == '.py' and '__pycache__' not in rel.parts:
            try:
                ast.parse(p.read_text('utf-8'), filename=str(rel))
                result['python_ast'] += 1
            except (SyntaxError, UnicodeError) as ex:
                result['errors'].append(f'Invalid Python {rel}: {ex}')
    node = shutil.which('node')
    for p in (ROOT/'academy/static').rglob('*.js'):
        if not node:
            result['warnings'].append('Node.js not available: JS syntax NOT VERIFIED')
            break
        proc = subprocess.run([node, '--check', str(p)], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              text=True, timeout=12)
        if proc.returncode:
            result['errors'].append(f'Invalid JS {p.relative_to(ROOT)}: {proc.stderr[-600:]}')
        else:
            result['js_node_syntax'] += 1
    try:
        import tinycss2
    except ImportError:
        result['warnings'].append('tinycss2 missing: CSS syntax NOT VERIFIED')
    else:
        result['css_parser_available'] = True
        for p in (ROOT/'academy/static').rglob('*.css'):
            nodes = tinycss2.parse_stylesheet(p.read_text('utf-8'), skip_whitespace=True, skip_comments=True)
            bad = [n for n in nodes if n.type == 'error']
            if bad:
                result['errors'].append(f'CSS parser errors {p.relative_to(ROOT)}: {len(bad)}')
            else:
                result['css_tinycss2'] += 1
    # Source-only target presence, not URL resolver/runtime permissions.
    routes = set()
    url_root = (ROOT/'academy/urls.py').read_text('utf-8')
    included_modules = set(re.findall(r'\b([a-z][a-z0-9_]+)\.urlpatterns', url_root))
    urls_sources = [ROOT/'academy/urls.py', ROOT/'academy/api_urls.py', ROOT/'config/urls.py']
    urls_sources += [ROOT/'academy'/f'{mod}.py' for mod in sorted(included_modules)]
    for file in urls_sources:
        if file.exists():
            routes.update(ROUTE_RE.findall(file.read_text('utf-8')))
    result['named_route_definitions'] = len(routes)
    for p in (ROOT/'academy/templates').rglob('*.html'):
        text = p.read_text('utf-8')
        for name in STATIC_RE.findall(text):
            result['static_references'] += 1
            if not (ROOT/'academy/static'/name).is_file():
                result['errors'].append(f'Missing static asset {name} in {p.relative_to(ROOT)}')
        for name in URL_TAG_RE.findall(text):
            result['named_route_references'] += 1
            if name not in routes and name not in {'admin:index'}:
                result['errors'].append(f'Missing route name {name} in {p.relative_to(ROOT)}')
    if result['private_data_files']:
        # Caches are local-test artifacts, package builder filters them.
        sensitive = [x for x in result['private_data_files'] if '__pycache__' not in Path(x).parts]
        if sensitive: result['errors'].append('Private files present in working source tree: ' + ', '.join(sensitive))
    return result


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', help='Optional JSON result file')
    opt = ap.parse_args()
    data = run()
    print(json.dumps(data, indent=2, ensure_ascii=False))
    if opt.out:
        Path(opt.out).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
    sys.exit(1 if data['errors'] else 0)

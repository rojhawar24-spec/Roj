#!/usr/bin/env python3
"""Run Debug V7 real Django regressions in a disposable source+SQLite copy."""
from __future__ import annotations
import argparse
from pathlib import Path
try:
    from scripts.phase17_isolated_django import PHASE17_MODULES
    from scripts.phase14_isolated_django import run
except ModuleNotFoundError:
    from phase17_isolated_django import PHASE17_MODULES
    from phase14_isolated_django import run

MODULES = (*PHASE17_MODULES, 'academy.test_debug_v7_missing_profile')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preflight', action='store_true')
    parser.add_argument('--all', action='store_true')
    parser.add_argument('--evidence-dir', type=Path)
    args = parser.parse_args()
    code, report = run(check_only=args.preflight, run_all=args.all,
                       evidence_dir=args.evidence_dir,
                       test_modules=MODULES, phase=20)
    print('Rozh Debug V7:', report['status'], '| Django:', report['django_runtime'])
    print('Evidence:', report['evidence_directory'])
    if report.get('reason'):
        print('Reason:', report['reason'])
    return code


if __name__ == '__main__':
    raise SystemExit(main())

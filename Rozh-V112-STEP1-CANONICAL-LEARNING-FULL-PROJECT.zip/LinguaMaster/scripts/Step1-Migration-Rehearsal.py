"""Run academy 0012 -> 0013 -> 0012 -> 0013 on TEMPORARY SQLite only.

Must be invoked with `python scripts/Step1-Migration-Rehearsal.py` from a
COPY of the project. Does not load .env or open db.sqlite3; forcibly sets a
temporary SQLite file before Django initializes. Always deletes test DB.
"""
import os
import tempfile
from pathlib import Path
from contextlib import contextmanager

os.environ.update(DJANGO_DEBUG='1', USE_SQLITE='1',
                  DJANGO_SETTINGS_MODULE='config.settings',
                  DJANGO_ALLOWED_HOSTS='localhost,127.0.0.1',
                  REQUIRE_EMAIL_VERIFICATION='0')

with tempfile.TemporaryDirectory(prefix='rozh_step1_sqlite_migration_') as folder:
    db_path = Path(folder) / 'rehearsal.sqlite3'
    import django
    from django.conf import settings
    settings.DATABASES['default']['ENGINE'] = 'django.db.backends.sqlite3'
    settings.DATABASES['default']['NAME'] = str(db_path)
    django.setup()
    from django.db import connections
    from django.db.migrations.executor import MigrationExecutor
    from django.contrib.auth.hashers import make_password
    conn = connections['default']
    if Path(conn.settings_dict['NAME']).resolve() != db_path.resolve():
        raise RuntimeError('Unsafe migration database target; refusing to continue')
    before = ('academy', '0012_onboarding_draft_v52')
    after = ('academy', '0013_onboarding_required_solar')
    try:
        executor = MigrationExecutor(conn)
        executor.migrate([before])
        oldapps = executor.loader.project_state([before]).apps
        UserModel = oldapps.get_model('auth', 'User')
        Profile = oldapps.get_model('academy', 'Profile')
        owner = UserModel.objects.using('default').create(
            username='legacy_user_step1', password=make_password('never-used-test'), is_active=True)
        Profile.objects.using('default').create(
            user_id=owner.pk, xp=48, streak=3, onboarding_completed=False)
        executor = MigrationExecutor(conn)
        executor.migrate([after])
        from academy.models import Profile as CurrentProfile
        grown = CurrentProfile.objects.get(user_id=owner.pk)
        assert grown.onboarding_required is False
        assert grown.onboarding_completed is False
        assert grown.xp == 48 and grown.streak == 3
        print('PASSED: SQLite forward 0012->0013, legacy profile and progress preserved')
        executor = MigrationExecutor(conn)
        executor.migrate([before])
        executor = MigrationExecutor(conn)
        after_rollback = executor.loader.project_state([before]).apps.get_model('academy', 'Profile')
        restored = after_rollback.objects.get(user_id=owner.pk)
        assert restored.xp == 48 and restored.streak == 3 and not restored.onboarding_completed
        print('PASSED: SQLite backward 0013->0012, existing profile preserved')
        executor = MigrationExecutor(conn)
        executor.migrate([after])
        print('PASSED: SQLite reapply 0013, no real DB touched')
    finally:
        connections.close_all()

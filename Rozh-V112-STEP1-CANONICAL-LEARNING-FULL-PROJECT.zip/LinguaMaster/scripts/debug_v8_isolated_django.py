#!/usr/bin/env python3
"""Run V8 and earlier Django tests in a disposable database/source copy."""
from __future__ import annotations
import argparse
from pathlib import Path
try:
    from scripts.debug_v7_isolated_django import MODULES as V7_MODULES
    from scripts.phase14_isolated_django import run
except ModuleNotFoundError:
    from debug_v7_isolated_django import MODULES as V7_MODULES
    from phase14_isolated_django import run

MODULES = (*V7_MODULES, 'academy.test_debug_v8_profile_integrity')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preflight', action='store_true')
    parser.add_argument('--all', action='store_true', help='Run ALL academy tests, including V8')
    parser.add_argument('--evidence-dir', type=Path)
    args = parser.parse_args()
    code, report = run(check_only=args.preflight, run_all=args.all,
                       evidence_dir=args.evidence_dir,
                       test_modules=MODULES, phase=21)
    print('Rozh Debug V8:', report['status'], '| Django:', report['django_runtime'])
    if report.get('reason'):
        print('Reason:', report['reason'])
    print('Evidence:', report['evidence_directory'])
    return code


if __name__ == '__main__':
    raise SystemExit(main())

# Rozh Phase 13: actual Django security/readiness regression tests, isolated from the owner's SQLite DB.
# Compatible with Windows PowerShell 5.1 / PowerShell 7.
[CmdletBinding()]
param([switch]$RunAllTests)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$root = Join-Path ([System.IO.Path]::GetTempPath()) ('Rozh-Phase13-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root -Force | Out-Null
$sandboxDb = Join-Path $root 'rozh-v52-sandbox.sqlite3'
[System.IO.File]::WriteAllBytes($sandboxDb, [byte[]]@())
$venv = Join-Path $root '.venv'
$python = Join-Path $venv 'Scripts\python.exe'
Write-Host "Isolated workspace: $root"
Write-Host 'The original project database and accounts are NOT accessed.'

# Select Python >=3.12 explicitly. Django 6.1 cannot run on Python 3.11.
$launcher = Get-Command py -ErrorAction SilentlyContinue
if ($null -eq $launcher) { throw 'Python launcher missing. Install Python 3.12 or newer and rerun.' }
# Resolve a specific supported interpreter; 'py -3' can select Python 3.11.
$versionCheck = Join-Path $projectRoot 'scripts\check_python_version_v46.py'
if (-not (Test-Path -LiteralPath $versionCheck -PathType Leaf)) { throw 'Required Python version checker missing.' }
$selected = $null
foreach ($candidate in @('3.13', '3.14', '3.12', '3.15')) {
    & $launcher.Source ("-" + $candidate) $versionCheck 2>$null
    if ($LASTEXITCODE -eq 0) { $selected = "-" + $candidate; break }
}
if (-not $selected) { throw 'Python 3.12-3.15 required; no supported interpreter found. No tests were executed.' }

# These environment overrides exist only in this child PowerShell process.
$env:DJANGO_DEBUG = '1'
$env:USE_SQLITE = '1'
$env:ROZH_V52_SANDBOX_DB = $sandboxDb
$env:SITE_URL = 'http://127.0.0.1:3000'
$env:DJANGO_ALLOWED_HOSTS = '127.0.0.1,localhost,testserver'
$env:REQUIRE_EMAIL_VERIFICATION = '0'
$env:EMAIL_BACKEND = 'django.core.mail.backends.locmem.EmailBackend'
$env:PYTHONDONTWRITEBYTECODE = '1'

& $launcher.Source $selected -m venv $venv
if ($LASTEXITCODE -ne 0) { throw 'Virtual environment failed. Django tests were NOT run.' }
& $python -m pip install --disable-pip-version-check --no-input -r (Join-Path $projectRoot 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Package installation failed. Django tests were NOT run.' }

Push-Location $projectRoot
try {
    & $python manage.py check --settings=config.settings_sandbox_v52
    if ($LASTEXITCODE -ne 0) { throw 'Django system check FAILED.' }
    & $python manage.py migrate --noinput --settings=config.settings_sandbox_v52
    if ($LASTEXITCODE -ne 0) { throw 'Isolated SQLite migration FAILED.' }
    if ($RunAllTests) {
        & $python manage.py test academy --settings=config.settings_sandbox_v52 --verbosity 2
    } else {
        & $python manage.py test academy.test_phase1_auth_journey academy.test_phase2_progress_integrity academy.test_phase3_manager_navigation academy.test_phase4_vocabulary_navigation academy.test_phase5_learning_pages academy.test_phase6_social academy.test_phase7_ai_onboarding academy.test_phase8_full_journey academy.test_phase9_learning_integrity academy.test_phase10_manager_governance academy.test_phase11_mfa_enrollment academy.test_phase12_public_worker_route academy.test_phase13_health_readiness academy.tests.SiteTests.test_readiness_needs_privacy_contact --settings=config.settings_sandbox_v52 --verbosity 2
    }
    if ($LASTEXITCODE -ne 0) { throw 'One or more Django tests FAILED. Production status: NO-GO.' }
    Write-Host 'PASS: Selected Django tests completed on the isolated SQLite database, including Phase 10/11 governance, Phase 12 PWA and Phase 13 readiness HTTP checks.'
    Write-Host 'This does not validate browser, SMTP, PostgreSQL, MFA, AI or deployment.'
} finally {
    Pop-Location
    Write-Host "Sandbox remains for inspection: $root"
    Write-Host 'Keep your normal db.sqlite3 and original Rozh folder unchanged.'
}

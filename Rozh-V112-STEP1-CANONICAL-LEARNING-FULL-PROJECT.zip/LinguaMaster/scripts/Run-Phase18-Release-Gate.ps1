# Phase 18: read-only static production gate; always returns NO-GO (exit code 2).
# Use separately: .\scripts\Run-Phase17-Isolated-Django.ps1 -RunAllTests
[CmdletBinding()]
param([string]$EvidenceDirectory = '')
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$py = Get-Command py -ErrorAction SilentlyContinue
if ($null -eq $py) { throw 'Python launcher (py.exe) not found' }
$evidence = Join-Path ([System.IO.Path]::GetTempPath()) ('Rozh-Phase18-Audit-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $evidence -Force | Out-Null
$script = Join-Path $projectRoot 'scripts\phase18_release_audit.py'
$output = Join-Path $evidence 'phase18-release-gate.json'
$argsList = @('-3', $script, '--json', $output)
if (-not [string]::IsNullOrWhiteSpace($EvidenceDirectory)) {
    $path = (Resolve-Path -Path $EvidenceDirectory -ErrorAction Stop).Path
    $argsList += @('--evidence-dir', $path)
}
& py @argsList
$exitCode = $LASTEXITCODE
Write-Host "Phase 18 read-only audit JSON: $output"
if ($exitCode -eq 2) {
    Write-Host 'Expected NO-GO: this offline gate does not authorize production publication.'
    exit 2
}
if ($exitCode -ne 0) { throw "Audit process failed: $exitCode" }
throw 'Unsafe audit result: production gate should not exit 0 without external acceptance.'

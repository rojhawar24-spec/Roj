#!/usr/bin/env python3
"""Explicit final listening/release gate for an already generated self-hosted clip."""
import argparse
import json
import os
import shutil
import re
import sys
import tempfile
from pathlib import Path

from rozh_audio_v78 import digest_file, SUPPORTED, clip_key


def approve(root, key, reviewer, listened):
    if not listened or not reviewer or len(reviewer.strip()) < 2:
        raise ValueError('Explicit listen confirmation and a real reviewer name are required.')
    if not re.fullmatch(r'[0-9a-f]{64}', key):
        raise ValueError('Invalid clip key.')
    project = Path(root).resolve()
    base = project / 'academy' / 'static' / 'academy' / 'audio-v78'
    stage = project / '.rozh_audio_review_v78'
    catalog_path = base / 'catalog.json'
    pending_path = stage / 'pending.json'
    public = json.loads(catalog_path.read_text(encoding='utf-8'))
    pending = json.loads(pending_path.read_text(encoding='utf-8'))
    if (public.get('format_version') != 1 or pending.get('format_version') != 1
            or not isinstance(public.get('clips'), dict) or not isinstance(pending.get('clips'), dict)):
        raise ValueError('Malformed public or pending audio catalog.')
    entry = pending['clips'].get(key)
    if not isinstance(entry, dict) or entry.get('key') != key or key in public['clips']:
        raise ValueError('Pending clip key not found, or it is already published.')
    language = entry.get('language')
    ext = entry.get('extension')
    if language not in SUPPORTED or ext not in ('mp3', 'wav'):
        raise ValueError('Unsupported language or extension.')
    if clip_key(language, entry.get('text')) != key:
        raise ValueError('Pending utterance identity does not match its key.')
    source = stage / language / f'{key}.{ext}'
    if source.is_symlink() or not source.is_file() or digest_file(source) != entry.get('sha256'):
        raise ValueError('Pending audio missing or hash mismatches; cannot publish.')
    if entry.get('voice_license') not in {'CC0-1.0', 'CC-BY-4.0', 'MIT', 'Apache-2.0'}:
        raise ValueError('Voice license has not been cleared.')
    relative = f'academy/audio-v78/clips/{language}/{key}.{ext}'
    destination = base / 'clips' / language / f'{key}.{ext}'
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise FileExistsError('Output exists; refusing to overwrite.')
    with tempfile.NamedTemporaryFile(dir=destination.parent, prefix='.audio-reviewed-', suffix='.tmp', delete=False) as tmp:
        with open(source, 'rb') as inp:
            shutil.copyfileobj(inp, tmp)
        tmp_name = tmp.name
    os.replace(tmp_name, destination)
    public['clips'][key] = {
        'key': key, 'language': language, 'path': relative,
        'sha256': entry['sha256'], 'seconds': entry['seconds'],
        'voice_id': entry['voice_id'], 'voice_license': entry['voice_license'],
        'voice_source_url': entry.get('voice_source_url', ''),
        'reviewed': True, 'audio_quality_review_required': False,
        'audio_reviewer': reviewer.strip()[:120],
    }
    from rozh_audio_v78 import write_json_atomic
    write_json_atomic(catalog_path, public)
    del pending['clips'][key]
    write_json_atomic(pending_path, pending)
    source.unlink(missing_ok=True)
    print(f'Published approved {language} clip {key[:12]} after human listening review.')

if __name__ == '__main__':
    p = argparse.ArgumentParser(description='Publish exactly one already generated audio clip after human review.')
    p.add_argument('--root', default='.')
    p.add_argument('--key', required=True, help='64-character clip identity from the catalog')
    p.add_argument('--reviewer', required=True)
    p.add_argument('--listened', action='store_true', help='Confirm actual listening, pronunciation and audio quality check')
    args = p.parse_args()
    try:
        approve(args.root, args.key, args.reviewer, args.listened)
    except (OSError, KeyError, ValueError, json.JSONDecodeError) as e:
        print('BLOCKED: ' + str(e), file=sys.stderr)
        sys.exit(2)

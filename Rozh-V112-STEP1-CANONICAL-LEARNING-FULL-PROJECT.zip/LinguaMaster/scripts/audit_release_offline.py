"""Honest source-only audit for all shipped files. Never claims Django/runtime coverage.

Run: python -m scripts.audit_release_offline
"""
import ast
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
issues = []
paths = sorted(path for path in ROOT.rglob('*') if path.is_file() and not any(
    part in {'.git', '.venv', '__pycache__', 'staticfiles'} for part in path.relative_to(ROOT).parts
) and path.name not in {'.env', 'db.sqlite3'}
  and not path.name.startswith(('db.sqlite3.backup-', '.env.backup-', 'settings.py.backup-'))
)
py_files = [path for path in paths if path.suffix == '.py']
js_files = [path for path in paths if path.suffix == '.js']
html_files = [path for path in paths if path.suffix == '.html' and 'templates' in path.parts]
css_files = [path for path in paths if path.suffix == '.css']

for path in py_files:
    try:
        ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
    except (SyntaxError, UnicodeDecodeError) as exc:
        issues.append(f'Python syntax: {path.relative_to(ROOT)}: {exc}')

node = shutil.which('node')
if node:
    for path in js_files:
        completed = subprocess.run([node, '--check', str(path)], capture_output=True, text=True)
        if completed.returncode:
            issues.append(f'JS syntax: {path.relative_to(ROOT)}: {completed.stderr[:250]}')
else:
    print('[NOT TESTED] Node.js unavailable; JavaScript syntax check skipped.')

urls = (ROOT/'academy/urls.py').read_text(encoding='utf-8')
urls += (ROOT/'config/urls.py').read_text(encoding='utf-8')
for feature in ('social_v9.py', 'grammar_v9.py', 'progress_v9.py', 'billing_v9.py','practice_v9.py','courses_v10.py','heart_v10.py','photo_v10.py','journey_v11.py'):
    urls += (ROOT/'academy'/feature).read_text(encoding='utf-8')
names = set(re.findall(r"\bname\s*=\s*['\"]([^'\"]+)['\"]", urls))
forms_checked = 0
static_refs = 0
for path in html_files:
    contents = path.read_text(encoding='utf-8')
    tags = re.findall(r'{%\s*(.*?)\s*%}', contents, re.S)
    stack = []
    for tag in tags:
        parts = tag.split()
        if not parts: continue
        cmd = parts[0]
        if cmd in ('block', 'if', 'for', 'with', 'autoescape', 'filter'):
            stack.append(cmd)
        elif cmd in ('endblock', 'endif', 'endfor', 'endwith', 'endautoescape', 'endfilter'):
            if not stack or stack.pop() != cmd[3:]:
                issues.append(f'Template closing tag {cmd}: {path.relative_to(ROOT)}')
        elif cmd == 'url':
            m = re.match(r"url\s+['\"]([^'\"]+)['\"]",tag)
            if m and m.group(1) not in names:
                issues.append(f'Missing URL {m.group(1)}: {path.relative_to(ROOT)}')
        elif cmd in ('extends', 'include'):
            m = re.match(r"(?:extends|include)\s+['\"]([^'\"]+)['\"]",tag)
            if m and not (ROOT/'academy/templates'/m.group(1)).is_file():
                issues.append(f'Missing template {m.group(1)}: {path.relative_to(ROOT)}')
        elif cmd == 'static':
            m = re.match(r"static\s+['\"]([^'\"]+)['\"]",tag)
            if m:
                static_refs += 1
                if not (ROOT/'academy/static'/m.group(1)).is_file():
                    issues.append(f'Missing static asset {m.group(1)}: {path.relative_to(ROOT)}')
    if stack:
        issues.append(f'Unclosed template tags {stack}: {path.relative_to(ROOT)}')
    for m in re.finditer(r"<form\b[^>]*method\s*=\s*['\"]post['\"][^>]*>(.*?)</form>", contents, re.I | re.S):
        forms_checked += 1
        if not re.search(r'{%\s*csrf_token\s*%}', m.group(1)):
            issues.append(f'POST form without CSRF tag: {path.relative_to(ROOT)}')

for path in css_files:
    content = path.read_text(encoding='utf-8')
    if content.count('{') != content.count('}'):
        issues.append(f'CSS brace imbalance: {path.relative_to(ROOT)}')

# This verifier also runs in an *installed* developer project containing the
# user's legitimate .env and db.sqlite3. Never fail or scan personal data.
# The ZIP packager checks their absence separately before creating an archive.
if (ROOT/'.env').exists() or (ROOT/'db.sqlite3').exists():
    print('[LOCAL DATA] .env / SQLite files are intentionally excluded from source checks.')
if not (ROOT/'academy/migrations/0004_reconcile_unit_prerequisites_state.py').is_file():
    issues.append('Missing migration 0004')
if not (ROOT/'academy/static/academy/manifest.webmanifest').is_file():
    issues.append('Missing PWA manifest')

print(f'FILES EXAMINED: {len(paths)} | PYTHON: {len(py_files)} | JS: {len(js_files)} | TEMPLATES: {len(html_files)} | CSS: {len(css_files)}')
print(f'NAMED URLS: {len(names)} | POST FORMS WITH CSRF: {forms_checked} | STATIC REFERENCES: {static_refs}')
print(f'RELEASE SOURCE ISSUES: {len(issues)}')
for issue in issues: print('FAIL:', issue)
print('IMPORTANT: Source-only; does not run Django, SMTP, PostgreSQL, browsers, penetration testing or WCAG audit.')
if issues: sys.exit(1)

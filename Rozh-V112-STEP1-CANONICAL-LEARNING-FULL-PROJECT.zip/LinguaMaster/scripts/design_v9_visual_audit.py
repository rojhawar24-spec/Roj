#!/usr/bin/env python3
"""Visual-only source-fragment audit; no Django, database, or authentication."""
from __future__ import annotations
import ast, html, json, mimetypes, re, sys, base64
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
STATIC=ROOT/'academy/static'
TEMPLATES=ROOT/'academy/templates/academy'
CSS_FILES=['rozh2027.css','rozh2027-v53.css','solar-atlas-step2.css','solar-atlas-step7-manager.css','rozh2027-phase16.css','rozh2027-responsive-v6.css']
if (STATIC/'academy/rozh2027-design-clarity-v9.css').exists():
    CSS_FILES.append('rozh2027-design-clarity-v9.css')
CSS='\n'.join((STATIC/'academy'/f).read_text(encoding='utf8') for f in CSS_FILES)
JS=(STATIC/'academy/rozh2027.js').read_text(encoding='utf8')
if (STATIC/'academy/rozh2027-design-clarity-v9.js').exists():
    JS+='\n'+(STATIC/'academy/rozh2027-design-clarity-v9.js').read_text(encoding='utf8')
# Import the existing synthetic template fragment renderer without executing its matrix.
script=(ROOT/'scripts/phase19_responsive_matrix.py').read_text(encoding='utf8').split('ap=argparse.ArgumentParser')[0]
ns={'__file__':str(ROOT/'scripts/phase19_responsive_matrix.py')}
exec(compile(script,'synthetic_renderer', 'exec'),ns)
render=ns['render']; section=ns['section']

def literal_dict(path):
    """Read literal UI dictionaries, including manager STEP7 presentation updates.

    The earlier synthetic screenshot fixture read only COPY and displayed
    raw identifiers such as 'sa7_mfa_verified', even though the real view
    merges those labels. Never treat fixture fallbacks as production UI.
    """
    tree=ast.parse(path.read_text(encoding='utf8'))
    def simple(n):
        if isinstance(n,ast.Dict):return {simple(k):simple(v) for k,v in zip(n.keys,n.values)}
        if isinstance(n,ast.Constant):return n.value
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='dict' and not n.args:
            return {kw.arg:simple(kw.value) for kw in n.keywords}
        raise ValueError(f'Nonliteral translation: {ast.dump(n)[:100]}')
    values={}
    for node in tree.body:
        if isinstance(node,ast.Assign):
            for target in node.targets:
                if isinstance(target,ast.Name) and target.id in ('COPY','SOLAR_ATLAS_STEP7_LABELS','SOLAR_ATLAS_STEP7_FORM_LABELS'):
                    values[target.id]=simple(node.value)
    if 'COPY' not in values:raise ValueError('Missing COPY')
    result=values['COPY']
    if path.name=='manager_i18n_v47.py':
        for lang,labels in values.get('SOLAR_ATLAS_STEP7_LABELS',{}).items():
            result[lang].update(labels)
        for lang,labels in values.get('SOLAR_ATLAS_STEP7_FORM_LABELS',{}).items():
            result[lang].update({'sa7_field_'+k:v for k,v in labels.items()})
    return result
R27=literal_dict(ROOT/'academy/rozh2027.py')
MC=literal_dict(ROOT/'academy/manager_i18n_v47.py')

def localize(raw, lang):
    def subst(m):
        src=R27 if m.group(1)=='R27' else MC
        return html.escape(str(src[lang].get(m.group(2), m.group(2))),quote=True)
    return re.sub(r'{{\s*(R27|MC)\.([a-zA-Z_][\w]*)\s*}}', subst, raw)

def page_html(role,lang,theme):
    raw=(TEMPLATES/('rozh2027_student_shell.html' if role=='student' else 'rozh2027_manager_shell.html')).read_text(encoding='utf8')
    raw=localize(raw,lang)
    top=section(raw,'<header class="'+('r27-topbar' if role=='student' else 'r27-manager-top')+'"','</header>')
    sidebar=section(raw,'<aside class="'+('r27-sidebar' if role=='student' else 'r27-manager-sidebar')+'"','</aside>')
    nav=section(raw,'<nav class="'+('r27-mobile-bottom' if role=='student' else 'r27-manager-bottom')+'"','</nav>')
    route='vocabulary' if role=='student' else 'manager_users'
    cls='r27 r27-student r53-student solar-step2' if role=='student' else 'r27 r27-manager sa7-manager'
    if role=='student':
        # Real shell fragment + representative editorial hero (not Django-rendered content).
        center='''<section class="r53-welcome solar-hero"><div class="r53-welcome-text"><span class="r53-eyebrow">YOUR STUDIO</span><h1>Welkom terug, <bdi>VeryLongUserAccountName2026</bdi></h1><p>Continue learning English</p><div class="r53-course-line"><span class="r53-course-tag">English</span><span class="r53-course-cefr">CEFR A1</span></div></div><a class="r53-avatar-card" href="#"><span class="r53-avatar">👨</span>Profile</a><div class="r53-progress-main"><div class="r53-progress-heading"><strong>My course</strong><span>12 / 30 lessons</span></div><progress value="12" max="30"></progress><p>40% complete</p></div></section><div class="r53-season"><h2>Seizoen 1: De eerste stappen</h2><div class="r53-path r27-path"><a href="#" class="r27-node-button">1</a></div></div>'''
        inner=f'<div class="r27-student-frame">{render(sidebar,route,"",lang)}<div class="r27-workspace">{render(top,route,"",lang)}<div class="r27-columns"><main class="r27-main" id="main">{center}</main><aside class="r27-progress-rail">Progress 12/30</aside></div></div></div>{render(nav,route,"",lang)}'
    else:
        center='''<section class="r27-manager-intro sa7-hero"><h1>Beheer je leerplatform</h1><p>Jouw SaaS manager dashboard</p></section><div class="sa7-metrics"><div class="sa7-metric"><small>Users</small><strong>123456</strong></div><div class="sa7-metric"><small>Lessons</small><strong>987</strong></div></div><form class="r48-search"><label for="search">Search</label><input id="search" type="search"><button type="submit">Search</button></form>'''
        inner=f'<div class="r27-manager-frame">{render(sidebar,route,"",lang)}<div class="r27-manager-workspace">{render(top,route,"",lang)}<main id="main" class="r27-manager-main">{center}</main></div></div>{render(nav,route,"",lang)}'
    direction='rtl' if lang in ('ckb','ar') else 'ltr'
    doc=f'''<!doctype html><html lang="{lang}" dir="{direction}" data-theme="{theme}"><head><meta charset="utf8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><style>{CSS}</style></head><body class="{cls}">{inner}<script>{JS}</script></body></html>'''
    # Preserve the actual Rozh PNG and sprite icons without requiring a network server.
    sprite=(STATIC/'academy/rozh2027-icons.svg').read_text(encoding='utf8').replace('<svg ', '<svg style="position:absolute;width:0;height:0;overflow:hidden" aria-hidden="true" ',1)
    doc=doc.replace('><body class=', '><body class=',1).replace(f'<body class="{cls}">',f'<body class="{cls}">{sprite}',1)
    doc=doc.replace('/static/academy/rozh2027-icons.svg#','#')
    for name in ('rozh-sun-192.png',):
        url='data:image/png;base64,'+base64.b64encode((STATIC/'academy'/name).read_bytes()).decode('ascii')
        doc=doc.replace('/static/academy/'+name,url)
    return doc

JSEVAL='''() => {
const nav=document.querySelector('.r27-mobile-bottom, .r27-manager-bottom');
const visible = nav&&getComputedStyle(nav).display !=='none';
const navItems=visible ? [...nav.querySelectorAll(':scope > a, :scope > details > summary')] : [];
const navMetrics=navItems.map(e=> {let r=e.getBoundingClientRect(), sp=e.querySelector('span'), sr=sp?.getBoundingClientRect();let st=sp?getComputedStyle(sp):null;
return {text:sp?.textContent?.trim(),size:st?.fontSize,hitWidth:r.width,hitHeight:r.height,spanHeight:sr?.height,clipped:!!sp&&getComputedStyle(sp).overflow!=='visible'&&(sp.scrollHeight>sp.clientHeight+1 || sp.scrollWidth>sp.clientWidth+1),focusable:e.tabIndex>=0};});
const hero=document.querySelector('.r53-welcome');
const images=[...document.images].map(i=>({src:i.src.split('/').at(-1),loaded:i.complete&&i.naturalWidth>0}));
const hdr=document.querySelector('header');
return {scrollWidth:document.documentElement.scrollWidth,viewport:innerWidth,navVisible:visible,navMetrics,images,hero:hero?{scrollWidth:hero.scrollWidth,clientWidth:hero.clientWidth}:null,headerWidth:hdr?.getBoundingClientRect().width};
}'''

def main():
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('--output',default=str(ROOT/'DESIGN-V9-VISUAL-RESULTS.json'));ap.add_argument('--screenshots',default=str(ROOT/'DESIGN-V9-SCREENSHOTS'));ap.add_argument('--quick',action='store_true')
    args=ap.parse_args(); shots=Path(args.screenshots);shots.mkdir(parents=True,exist_ok=True)
    cases=[]
    with sync_playwright() as pw:
        b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium')
        for role in ('student','manager'):
            for lang in ('nl','en','ckb','ar'):
                for theme in ('light','dark'):
                    for width in ((320,375,1366) if args.quick else (320,360,375,390,430,760,768,1024,1366)):
                        h=page_html(role,lang,theme)
                        ctx=b.new_context(viewport={'width':width,'height':850},device_scale_factor=1, reduced_motion='reduce')
                        page=ctx.new_page()

                        errors=[];page.on('pageerror',lambda x:errors.append(str(x)[:160]))
                        page.set_content(h,wait_until='load')
                        m=page.evaluate(JSEVAL)
                        row=dict(role=role,lang=lang,theme=theme,width=width,**m,errors=errors)
                        cases.append(row)
                        if (role,lang,theme,width) in [('student','nl','light',375),('student','ckb','light',375),('manager','nl','light',375),('student','nl','dark',1366),('manager','ar','dark',375)]:
                            page.screenshot(path=str(shots/f'{role}-{lang}-{theme}-{width}.png'))
                        ctx.close()
        b.close()
    Path(args.output).write_text(json.dumps({'scope':'source-fragment synthetic Chromium review, not Django/browser E2E','results':cases},ensure_ascii=False,indent=2),encoding='utf8')
    issue=[]
    for row in cases:
        if row['scrollWidth']>row['width']+1 or row['errors'] or any(m.get('clipped') for m in row['navMetrics']) or any(not img['loaded'] for img in row['images']):
            issue.append({k:row[k] for k in ('role','lang','theme','width','scrollWidth','images','navMetrics','errors')})
    print('CASES',len(cases),'ISSUE_CASES',len(issue))
    for i in issue[:12]:print('ISSUE',i['role'],i['lang'],i['theme'],i['width'],'scroll',i['scrollWidth'],'images',i['images'],'navclip',[(n['text'],n['clipped']) for n in i['navMetrics'] if n.get('clipped')])
    for row in cases:
        if row['role']=='student' and row['lang']=='ckb' and row['theme']=='light' and row['width']==375:
            print('MOBILE NAV ckb:',row['navMetrics'])

if __name__=='__main__':main()

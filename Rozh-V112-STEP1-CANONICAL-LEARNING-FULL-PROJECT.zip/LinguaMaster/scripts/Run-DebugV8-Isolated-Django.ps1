# V8 Django integration tests in a disposable SQLite DB; never touch real user data.
[CmdletBinding()]
param([switch]$RunAllTests, [switch]$PreflightOnly)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$evidence = Join-Path ([System.IO.Path]::GetTempPath()) ('Rozh-DebugV8-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $evidence -Force | Out-Null
$checker = Join-Path $PSScriptRoot 'check_python_version_v46.py'
if (-not (Test-Path -LiteralPath $checker)) { throw 'Python version checker missing.' }
$selected = $null
foreach ($version in @('3.13','3.14','3.12','3.15')) {
    & py "-$version" $checker 2>$null
    if ($LASTEXITCODE -eq 0) { $selected = "-$version"; break }
}
if ($null -eq $selected) { throw 'Python 3.12+ not found. No tests executed.' }
$venv = Join-Path $evidence '.venv'
& py $selected -m venv $venv
if ($LASTEXITCODE -ne 0) { throw 'Cannot create isolated virtualenv.' }
$python = Join-Path $venv 'Scripts\python.exe'
$runner = Join-Path $PSScriptRoot 'debug_v8_isolated_django.py'
if ($PreflightOnly) {
    & $python $runner --preflight --evidence-dir $evidence
    if ($LASTEXITCODE -ne 0) { throw 'Preflight FAILED.' }
    Write-Host "PREFLIGHT PASS (Django tests NOT run). Evidence: $evidence"
    return
}
& $python -m pip install --disable-pip-version-check --no-input -r (Join-Path $root 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw "Dependency install BLOCKED; Django not run. Evidence: $evidence" }
$parameters = @($runner, '--evidence-dir', $evidence)
if ($RunAllTests) { $parameters += '--all' }
& $python @parameters
if ($LASTEXITCODE -ne 0) { throw "Django tests FAILED or BLOCKED. Evidence: $evidence" }
Write-Host "Django isolated suite PASS. Evidence: $evidence"
Write-Host 'Production remains NO-GO without live browser, PostgreSQL, SMTP, MFA and accessibility validation.'

"""Verify the local environment without Windows PowerShell -c quoting traps."""
import sys
try:
    import django
except ImportError:
    print('[FAIL] Django is not available in this virtual environment.')
    sys.exit(1)
version = django.get_version()
print('[DJANGO] version:', version)
if django.VERSION[:3] != (6, 1, 3):
    print('[FAIL] V44 expects the tested project Django version 6.1.3.')
    sys.exit(1)
print('[PASS] Required Django version available.')

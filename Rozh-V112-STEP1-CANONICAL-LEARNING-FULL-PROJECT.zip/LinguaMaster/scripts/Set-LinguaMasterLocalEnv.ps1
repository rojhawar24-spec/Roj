# V41: safe local .env reader (PowerShell 5.1+). DOT SOURCE this file.
# No Invoke-Expression, no credential output and no persistent User/Machine changes.
$ErrorActionPreference = 'Stop'
$env:DJANGO_DEBUG = '1'
$env:USE_SQLITE = '1'
$root = Split-Path -Parent $PSScriptRoot
$envFile = Join-Path $root '.env'
$allowed = @(
    'DJANGO_SECRET_KEY', 'LINGUAMASTER_TOTP_KEY', 'EMAIL_BACKEND',
    'EMAIL_HOST', 'EMAIL_PORT', 'EMAIL_HOST_USER', 'EMAIL_HOST_PASSWORD',
    'EMAIL_USE_TLS', 'EMAIL_USE_SSL', 'EMAIL_TIMEOUT', 'DEFAULT_FROM_EMAIL',
    'REQUIRE_EMAIL_VERIFICATION'
)
if (Test-Path -LiteralPath $envFile -PathType Leaf) {
    foreach ($line in (Get-Content -LiteralPath $envFile -Encoding UTF8)) {
        if ($line -notmatch '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$') { continue }
        $name = $Matches[1]
        if ($allowed -notcontains $name) { continue }
        $value = $Matches[2].Trim()
        if ($value.Length -ge 2 -and $value[0] -eq $value[$value.Length - 1] -and
            ($value[0] -eq '"' -or $value[0] -eq "'")) {
            $value = $value.Substring(1, $value.Length - 2)
        }
        # Existing process values, including those from a secret manager, win.
        if ($value -and -not [Environment]::GetEnvironmentVariable($name, 'Process')) {
            [Environment]::SetEnvironmentVariable($name, $value, 'Process')
        }
    }
}
if (-not $env:DJANGO_SECRET_KEY) {
    # Legacy key preserves historical local MFA encryption. Never change it silently.
    $env:DJANGO_SECRET_KEY = 'linguamaster-local-dev-only-not-for-public-deployment-2026'
    Write-Warning 'Local legacy development key in use. Preserve the original key for existing accounts.'
}
$env:SITE_URL = 'http://127.0.0.1:3000'
$env:DJANGO_ALLOWED_HOSTS = 'localhost,127.0.0.1,testserver'
# MAILERS picks SMTP when EMAIL_HOST is configured; otherwise a private file outbox.
# Never print tokens: the local file outbox contains actual private messages.

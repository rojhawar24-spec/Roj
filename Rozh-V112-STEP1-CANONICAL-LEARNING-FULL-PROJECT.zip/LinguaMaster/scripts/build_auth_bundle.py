"""Deterministic login-only stylesheet bundle; no other pages are changed."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'academy' / 'static' / 'academy'
FILES = ('style.css', 'auth-v5.css', 'auth-v26.css', 'auth-v28.css',
         'auth-v31.css', 'auth-flow-v32.css')
output = b''.join((f'/* SOURCE {name} */\n'.encode() + (SOURCE / name).read_bytes() + b'\n')
                  for name in FILES)
(SOURCE / 'auth-v35-bundle.css').write_bytes(output)
print(f'Auth stylesheet bundle: {len(output):,} bytes from {len(FILES)} source files')

# Phase 8: run ACTUAL Django tests in a disposable sandbox, not production.
# Windows PowerShell 5.1 / PowerShell 7. No original db.sqlite3 is opened.
[CmdletBinding()]
param(
    [switch]$RunAllTests
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$root = Join-Path ([System.IO.Path]::GetTempPath()) ("Rozh-Phase8-" + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root -Force | Out-Null
$sandboxDb = Join-Path $root 'rozh-v52-sandbox.sqlite3'
# settings_sandbox_v52 refuses the original DB and requires this unique file.
[System.IO.File]::WriteAllBytes($sandboxDb, [byte[]]@())
$venv = Join-Path $root '.venv'
Write-Host "Isolated workspace: $root"
Write-Host 'The project source remains untouched; all DB work is inside the disposable sandbox.'

$env:DJANGO_DEBUG = '1'
$env:USE_SQLITE = '1'
$env:ROZH_V52_SANDBOX_DB = $sandboxDb
$env:SITE_URL = 'http://127.0.0.1:3000'
$env:DJANGO_ALLOWED_HOSTS = '127.0.0.1,localhost,testserver'
$env:REQUIRE_EMAIL_VERIFICATION = '0'
$env:EMAIL_BACKEND = 'django.core.mail.backends.locmem.EmailBackend'
$env:PYTHONDONTWRITEBYTECODE = '1'

& py -3 -m venv $venv
if ($LASTEXITCODE -ne 0) { throw 'Python virtualenv failed. Install a supported Python 3 version.' }
$python = Join-Path $venv 'Scripts\python.exe'
& $python -m pip install --disable-pip-version-check --no-input -r (Join-Path $projectRoot 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Django tests were NOT executed.' }

Push-Location $projectRoot
try {
    & $python manage.py check --settings=config.settings_sandbox_v52
    if ($LASTEXITCODE -ne 0) { throw 'Django system checks failed.' }
    & $python manage.py migrate --noinput --settings=config.settings_sandbox_v52
    if ($LASTEXITCODE -ne 0) { throw 'Migration failed on the isolated sandbox; original DB unchanged.' }

    if ($RunAllTests) {
        & $python manage.py test academy --settings=config.settings_sandbox_v52 --verbosity 2
    } else {
        & $python manage.py test academy.test_phase1_auth_journey academy.test_step1_solar_onboarding academy.test_phase2_progress_integrity academy.test_phase3_manager_navigation academy.test_phase4_vocabulary_navigation academy.test_phase5_learning_pages academy.test_phase6_social academy.test_phase7_ai_onboarding academy.test_phase8_full_journey --settings=config.settings_sandbox_v52 --verbosity 2
    }
    if ($LASTEXITCODE -ne 0) { throw 'At least one Django integration test FAILED. Production remains NO-GO.' }
    Write-Host 'Selected Django integration tests PASS in this isolated workspace.'
    Write-Host 'This is not production certification: still validate browsers, email, external services and production deployment.'
} finally {
    Pop-Location
    Write-Host "The disposable workspace remains available for inspection: $root"
    Write-Host 'Remove it manually when no longer needed; never delete your normal Rozh folder or db.sqlite3.'
}

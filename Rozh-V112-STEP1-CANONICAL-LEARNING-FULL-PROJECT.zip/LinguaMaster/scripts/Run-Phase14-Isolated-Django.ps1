# Rozh Phase 14: genuine Django tests in an isolated COPY and disposable SQLite.
# Run from LinguaMaster: powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Run-Phase14-Isolated-Django.ps1
[CmdletBinding()]
param([switch]$RunAllTests, [switch]$PreflightOnly)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$evidence = Join-Path ([System.IO.Path]::GetTempPath()) ('Rozh-Phase14-Results-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $evidence -Force | Out-Null
Write-Host "Evidence directory: $evidence"

# Pick a supported Python explicitly. 'py -3' could accidentally select 3.11.
$py = Get-Command py -ErrorAction SilentlyContinue
if ($null -eq $py) { throw 'Python launcher (py.exe) missing. Install Python 3.12+.' }
$selected = $null
$versionCheck = Join-Path $projectRoot 'scripts\check_python_version_v46.py'
if (-not (Test-Path -LiteralPath $versionCheck -PathType Leaf)) { throw 'Required Python version checker missing.' }
foreach ($candidate in @('3.13', '3.14', '3.12', '3.15')) {
    & $py.Source "-$candidate" $versionCheck 2>$null
    if ($LASTEXITCODE -eq 0) { $selected = "-$candidate"; break }
}
if ($null -eq $selected) { throw 'Python 3.12+ not found. Django tests did not run.' }
Write-Host "Python launcher: py $selected"

# Important: no system-wide pip install; use a fresh venv OUTSIDE Rozh.
$venv = Join-Path $evidence '.venv'
& $py.Source $selected -m venv $venv
if ($LASTEXITCODE -ne 0) { throw 'Could not make isolated Python virtualenv.' }
$python = Join-Path $venv 'Scripts\python.exe'
if (-not (Test-Path $python)) { throw 'Isolated virtualenv Python missing.' }

$runner = Join-Path $projectRoot 'scripts\phase14_isolated_django.py'
if ($PreflightOnly) {
    & $python $runner --preflight --evidence-dir $evidence
    if ($LASTEXITCODE -ne 0) { throw 'Phase 14 preflight FAILED.' }
    Write-Host 'PREFLIGHT PASS. Django integration was NOT executed.'
    return
}
# Install pinned project dependencies only in temporary .venv. On failure stop;
# never silently fall back to the global Python or a production database.
& $python -m pip install --disable-pip-version-check --no-input -r (Join-Path $projectRoot 'requirements.txt')
if ($LASTEXITCODE -ne 0) {
    Write-Host 'BLOCKED: Dependency installation failed. Django tests did NOT execute.'
    Write-Host "Evidence location: $evidence"
    throw 'Phase 14: missing Python dependencies.'
}
$arguments = @($runner, '--evidence-dir', $evidence)
if ($RunAllTests) { $arguments += '--all' }
& $python @arguments
if ($LASTEXITCODE -ne 0) {
    Write-Host "Inspect logs: $evidence\phase14-result.json"
    throw 'Phase 14 Django test run failed or was blocked; Production NO-GO.'
}
Write-Host 'PASS: Real Django test suite completed in isolated source and SQLite.'
Write-Host 'This does NOT establish PostgreSQL, browser, SMTP, AI or production acceptance.'
Write-Host "Evidence: $evidence"

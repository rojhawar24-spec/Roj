"""Read-only migration dependency/operation inventory without importing Django.

Static AST graph only. It does not prove that migrations apply to a database.
Run: python scripts/Step11-Migration-Graph-Static.py
"""
import ast
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
folder = root / 'academy' / 'migrations'
files = sorted(folder.glob('[0-9][0-9][0-9][0-9]_*.py'))
errors = []
links = {}
operation_totals = {}
runpython_by_file = {}
for p in files:
    tree = ast.parse(p.read_text(encoding='utf-8'), filename=str(p))
    migrations = [n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'Migration']
    if len(migrations) != 1:
        errors.append(f'{p.name}: missing/duplicate class Migration')
        continue
    assigned = {target.id: value for node in migrations[0].body if isinstance(node, ast.Assign)
                for target in node.targets if isinstance(target, ast.Name) for value in [node.value]}
    deps = assigned.get('dependencies')
    if not isinstance(deps, (ast.List, ast.Tuple)):
        errors.append(f'{p.name}: dependencies not literal list/tuple')
        continue
    predecessors = []
    for item in deps.elts:
        if isinstance(item, ast.Tuple) and len(item.elts) >= 2:
            a, b = item.elts[:2]
            if isinstance(a, ast.Constant) and a.value == 'academy' and isinstance(b, ast.Constant):
                predecessors.append(str(b.value))
    links[p.stem] = predecessors
    operations = assigned.get('operations')
    if not isinstance(operations, (ast.List, ast.Tuple)):
        errors.append(f'{p.name}: operations not literal list/tuple')
        continue
    names = []
    for op in operations.elts:
        if isinstance(op, ast.Call) and isinstance(op.func, ast.Attribute):
            names.append(op.func.attr)
    for name in names:
        operation_totals[name] = operation_totals.get(name, 0) + 1
    if 'RunPython' in names:
        runpython_by_file[p.name] = names.count('RunPython')

for file, deps in links.items():
    for predecessor in deps:
        if predecessor not in links:
            errors.append(f'{file}: missing academy predecessor {predecessor}')
        if predecessor >= file:
            errors.append(f'{file}: non-earlier academy predecessor {predecessor}')

if len(files) != 13:
    errors.append(f'expected 13 migration files; found {len(files)}')
for i, p in enumerate(files, start=1):
    if not p.stem.startswith(f'{i:04d}_'):
        errors.append(f'migration sequence missing {i:04d}')
# The expected linear chain prevents parallel academy leaves from being missed.
for i in range(1, len(files)):
    previous = files[i-1].stem
    current = files[i].stem
    if previous not in links.get(current, []):
        errors.append(f'{current} does not depend on prior academy migration {previous}')

report = {
    'scope': 'static-only: parses migration source, does not run Django/migrate',
    'migration_files': len(files),
    'academy_dependency_links': sum(map(len, links.values())),
    'operation_totals': dict(sorted(operation_totals.items())),
    'data_migrations': runpython_by_file,
    'latest': files[-1].stem if files else None,
    'findings': errors,
}
print(json.dumps(report, ensure_ascii=False, indent=2))
sys.exit(bool(errors))

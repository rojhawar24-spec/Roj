#!/usr/bin/env python3
"""Encrypted backups for SQLite or PostgreSQL. Restore requires explicit confirmation.

Key: 32 random bytes encoded as URL-safe base64 in LINGUAMASTER_BACKUP_KEY.
Never keep the key in the backup destination. No secrets are printed.
"""
import argparse
import base64
import os
import secrets
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from contextlib import closing
from pathlib import Path
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.exceptions import InvalidTag

HEADER = b'LM_BACKUP_V5\x00'
CHUNK = 1024 * 1024


def read_key():
    raw = os.environ.get('LINGUAMASTER_BACKUP_KEY', '')
    try:
        key = base64.urlsafe_b64decode(raw)
    except Exception as exc:
        raise RuntimeError('Backup key is not valid URL-safe base64') from exc
    if len(key) != 32:
        raise RuntimeError('Set LINGUAMASTER_BACKUP_KEY to a random 32-byte URL-safe base64 key')
    return key


def encrypt_file(src, dst, key):
    dst = Path(dst)
    if dst.exists():
        raise FileExistsError('Backup destination already exists; existing backup is not overwritten')
    nonce = secrets.token_bytes(12)
    encryptor = Cipher(algorithms.AES(key), modes.GCM(nonce)).encryptor()
    with open(src, 'rb') as plain, open(dst, 'xb') as encrypted:
        encrypted.write(HEADER + nonce)
        for chunk in iter(lambda: plain.read(CHUNK), b''):
            encrypted.write(encryptor.update(chunk))
        encrypted.write(encryptor.finalize())
        encrypted.write(encryptor.tag)
    try:
        os.chmod(dst, 0o600)
    except OSError:
        pass


def decrypt_file(src, dst, key):
    src = Path(src)
    size = src.stat().st_size
    if size < len(HEADER) + 12 + 16:
        raise ValueError('Encrypted backup is truncated')
    with src.open('rb') as encrypted:
        if encrypted.read(len(HEADER)) != HEADER:
            raise ValueError('Backup format or version does not match')
        nonce = encrypted.read(12)
        encrypted.seek(size - 16)
        tag = encrypted.read(16)
        decryptor = Cipher(algorithms.AES(key), modes.GCM(nonce, tag)).decryptor()
        encrypted.seek(len(HEADER) + 12)
        remaining = size - len(HEADER) - 12 - 16
        try:
            with open(dst, 'xb') as plain:
                while remaining:
                    block = encrypted.read(min(remaining, CHUNK))
                    if not block:
                        raise ValueError('Unexpected end of backup')
                    plain.write(decryptor.update(block))
                    remaining -= len(block)
                plain.write(decryptor.finalize())
        except (InvalidTag, ValueError):
            Path(dst).unlink(missing_ok=True)
            raise ValueError('Backup authentication failed: wrong key or corrupted file') from None


def sqlite_integrity(db):
    conn = sqlite3.connect(f'file:{Path(db).resolve().as_posix()}?mode=ro', uri=True)
    try:
        # A quick_check does not validate foreign key relationships. A restore
        # must not be declared safe when the physical DB or references are bad.
        result = conn.execute('PRAGMA integrity_check').fetchone()[0]
        if result != 'ok':
            raise ValueError(f'SQLite integrity check failed: {result}')
        orphan = conn.execute('PRAGMA foreign_key_check').fetchone()
        if orphan is not None:
            raise ValueError('SQLite foreign key check failed; refusing backup/restore verification')
    finally:
        conn.close()


def refuse_sqlite_live_restore(destination):
    """Do not replace a database that has WAL/SHM sidecars.

    A running SQLite app may hold committed data in the WAL; replacing only
    the main file can silently lose it. Stop the app and checkpoint/close the
    database *before* restoring, then verify absence of sidecars.
    """
    destination = Path(destination)
    for suffix in ('-wal', '-shm', '-journal'):
        sidecar = Path(str(destination) + suffix)
        if sidecar.exists():
            raise RuntimeError(
                f'SQLite restore refused because a journal/sidecar exists: {sidecar.name}. '
                'Stop all app processes, checkpoint and close the database, then retry.'
            )


def pg_tool(name):
    command = shutil.which(name)
    if not command:
        raise RuntimeError(f'{name} not found. Install the matching PostgreSQL client tools.')
    return command


def postgres_check_archive(file):
    subprocess.run([pg_tool('pg_restore'), '--list', str(file)], check=True, stdout=subprocess.DEVNULL)


def safe_db_name(name):
    if not name or any(ch not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for ch in name):
        raise ValueError('Use a simple database name without shell metacharacters')
    return name


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['backup', 'verify', 'restore', 'keygen'])
    p.add_argument('--engine', choices=['sqlite', 'postgres'], default='sqlite')
    p.add_argument('--database', default='db.sqlite3', help='SQLite file or PostgreSQL database name')
    p.add_argument('--file', type=Path, help='Encrypted backup file (or private key output for keygen)')
    p.add_argument('--confirm-db', help='To restore: repeat the target database filename or name exactly')
    args = p.parse_args(argv)
    if args.action == 'keygen':
        # Never print raw encryption secrets to shell history, CI or terminal logs.
        # Create the file atomically, refuse overwrites, and limit permissions.
        target = args.file or Path('.private-backup-key')
        material = base64.urlsafe_b64encode(secrets.token_bytes(32)) + b'\n'
        with target.open('xb') as output:
            output.write(material)
        try:
            os.chmod(target, 0o600)
        except OSError:
            pass
        print('New backup key saved in the selected private file; value not printed. Do not store beside backups.')
        return
    key = read_key()
    if args.action == 'backup':
        if args.engine == 'sqlite':
            source = Path(args.database).resolve()
            if not source.is_file():
                raise FileNotFoundError(f'SQLite database not found: {source}')
        else:
            safe_db_name(args.database)
        output = args.file or Path(f'linguamaster-{args.engine}-{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}.lmb')
        with tempfile.TemporaryDirectory() as tmp:
            dump = Path(tmp) / 'database.dump'
            if args.engine == 'sqlite':
                source_conn = sqlite3.connect(f'file:{source.as_posix()}?mode=ro', uri=True)
                target_conn = sqlite3.connect(str(dump))
                try:
                    source_conn.backup(target_conn)
                finally:
                    target_conn.close()
                    source_conn.close()
                sqlite_integrity(dump)
            else:
                subprocess.run([pg_tool('pg_dump'), '--format=custom', '--no-owner', '--file', str(dump), '--dbname', args.database], check=True)
                postgres_check_archive(dump)
            encrypt_file(dump, output, key)
        # Authenticated readback before declaring success.
        verify_backup(output, args.engine, key)
        print(f'Encrypted backup created and verified: {output}')
    elif args.action == 'verify':
        if not args.file:
            p.error('--file is required for verify')
        verify_backup(args.file, args.engine, key)
        print('Encrypted backup authentication and database format verified.')
    else:
        if not args.file:
            p.error('--file is required for restore')
        if args.confirm_db != args.database:
            raise ValueError('Restore blocked. Repeat the exact --database value in --confirm-db.')
        # SQLite's replacement must be on the destination filesystem so the
        # final os.replace is atomic even when the system TEMP is on another drive.
        destination_parent = Path(args.database).resolve().parent if args.engine == 'sqlite' else None
        if destination_parent is not None:
            destination_parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=destination_parent) as tmp:
            decrypted = Path(tmp) / 'database.dump'
            decrypt_file(args.file, decrypted, key)
            if args.engine == 'sqlite':
                sqlite_integrity(decrypted)
                destination = Path(args.database).resolve()
                destination.parent.mkdir(parents=True, exist_ok=True)
                # This cannot prove zero active readers on every platform.
                # Operators must still restore during a maintenance window.
                refuse_sqlite_live_restore(destination)
                if destination.exists():
                    # The existing database is preserved before the replacement.
                    # Never re-use a backup filename: two restores within one
                    # second must not overwrite a previous recovery snapshot.
                    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
                    fd, snapshot_name = tempfile.mkstemp(
                        prefix=destination.name + '.before-restore-' + stamp + '-',
                        suffix='.sqlite3', dir=destination.parent)
                    os.close(fd)
                    backup_previous = Path(snapshot_name)
                    try:
                        # sqlite Connection.__exit__ commits, but DOES NOT close.
                        # Explicit close is required before os.replace on Windows.
                        with closing(sqlite3.connect(str(destination))) as live, closing(sqlite3.connect(str(backup_previous))) as previous:
                            live.backup(previous)
                        sqlite_integrity(backup_previous)
                    except Exception:
                        backup_previous.unlink(missing_ok=True)
                        raise
                os.replace(decrypted, destination)
                sqlite_integrity(destination)
            else:
                safe_db_name(args.database)
                postgres_check_archive(decrypted)
                # Restore ONLY into an EMPTY, newly created PostgreSQL database.
                check = subprocess.run([pg_tool('psql'), '-X', '-A', '-t', '-d', args.database,
                    '-c', "SELECT count(*) FROM pg_class JOIN pg_namespace ON pg_namespace.oid=pg_class.relnamespace WHERE pg_class.relkind IN ('r','p') AND pg_namespace.nspname NOT IN ('pg_catalog','information_schema') AND pg_namespace.nspname NOT LIKE 'pg_toast%';"], capture_output=True, text=True, check=True)
                if check.stdout.strip() != '0':
                    raise RuntimeError('Restore blocked: PostgreSQL destination is not empty. Create a NEW empty database.')
                subprocess.run([pg_tool('pg_restore'), '--exit-on-error', '--single-transaction', '--no-owner', '--no-privileges', '--dbname', args.database, str(decrypted)], check=True)
        print('Restore completed. Run Django check, migrations, and application tests before starting the server.')


def verify_backup(file, engine, key):
    with tempfile.TemporaryDirectory() as tmp:
        decrypted = Path(tmp) / 'verify.dump'
        decrypt_file(file, decrypted, key)
        if engine == 'sqlite':
            sqlite_integrity(decrypted)
        else:
            postgres_check_archive(decrypted)


if __name__ == '__main__':
    try:
        main()
    except (ValueError, FileNotFoundError, RuntimeError, sqlite3.DatabaseError, subprocess.CalledProcessError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        sys.exit(1)

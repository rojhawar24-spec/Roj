"""Safe, fail-closed launcher of all Django tests incl. STEP13 security tests.

Use ONLY in a newly extracted COPY, never a live or existing project folder.
The STEP11 subprocess owns the disposable SQLite/test database safeguards.
"""
from pathlib import Path
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
if sys.argv[1:] != ['--full']:
    raise SystemExit('Usage: python scripts/Step13-Run-Disposable-Security-Suite.py --full')
if Path.cwd().resolve() != ROOT.resolve() or not (ROOT/'manage.py').is_file():
    raise SystemExit('REFUSED: use the freshly extracted LinguaMaster folder as current directory.')
for name in ('.env', 'db.sqlite3', 'db.sqlite3-wal', 'db.sqlite3-shm', 'db.sqlite3-journal'):
    if (ROOT/name).exists() or (ROOT/name).is_symlink():
        raise SystemExit('REFUSED: detected existing secrets or SQLite database in project directory.')
if any(ROOT.glob('*.sqlite')) or any(ROOT.glob('*.sqlite3')):
    raise SystemExit('REFUSED: SQLite database found. Use a clean disposable folder.')
runner = ROOT/'scripts/Step12-Run-Disposable-Feature-Suite.py'
if not runner.is_file():
    raise SystemExit('REFUSED: safe STEP12 runner is missing.')
print('STEP13: invoking isolated alias migration canary + full Django tests.', flush=True)
result = subprocess.run([sys.executable, str(runner), '--full'], cwd=str(ROOT), check=False)
if result.returncode:
    raise SystemExit('STEP13 BLOCKED/FAILED: real Django tests did not pass (exit %s).' % result.returncode)
print('STEP13: real Django suite completed successfully in disposable databases.')

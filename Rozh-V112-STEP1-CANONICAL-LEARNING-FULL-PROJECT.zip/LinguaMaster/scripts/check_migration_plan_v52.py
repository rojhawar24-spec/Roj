"""Read-only: approve ONLY the new additive account-draft migration 0012."""
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
import django
django.setup()
from django.db import connection
from django.db.migrations.executor import MigrationExecutor

ALLOWED = {('academy', '0012_onboarding_draft_v52')}
executor = MigrationExecutor(connection)
plan = executor.migration_plan(executor.loader.graph.leaf_nodes())
if not plan:
    print('[PASS] V52 migration already applied; nothing pending.')
else:
    print('[CHECK] Pending plan:')
    for migration, backwards in plan:
        label = (migration.app_label, migration.name)
        print('  ' + '.'.join(label))
        if backwards or label not in ALLOWED:
            raise SystemExit('[STOP] Unexpected migration; refused to modify database.')
    print('[PASS] Only reviewed additive 0012 is pending.')

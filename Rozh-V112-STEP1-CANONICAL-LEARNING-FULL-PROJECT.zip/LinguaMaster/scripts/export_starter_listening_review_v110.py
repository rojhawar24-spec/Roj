#!/usr/bin/env python3
"""Export bundled listening tasks for human review; never publish or alter a DB."""
import ast
import json
import sys
from pathlib import Path
from rozh_audio_v78 import clip_key
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from academy.starter_v10 import COURSE as ENGLISH
from academy.starter_de_v10 import COURSE as GERMAN
from academy.starter_fr_v10 import COURSE as FRENCH


def build_inventory(root=ROOT):
    tree=ast.parse((root/'academy/management/commands/seed_curriculum.py').read_text(encoding='utf8'))
    node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CURRICULUM' for t in n.targets))
    clips={}
    def add(language,text,reference,questions):
        key=clip_key(language,text)
        row=clips.setdefault(key,{'key':key,'language':language,'text':text,'source_reference':reference,'educator_reviewed':False,'pronunciation_reviewed':False,'lesson_references':[]})
        row['lesson_references'].append({'source':reference,'questions':questions})
    for level,_,topics in ast.literal_eval(node.value):
        for title,_,examples,_,_,_,_,quiz,_ in topics:
            add('nl',examples[2],f'Dutch/{level}/{title}/listening',[{'prompt':quiz[0],'options':quiz[1],'answer':quiz[2]}])
    for course in (ENGLISH,GERMAN,FRENCH):
        for unit in course['units']:
            for lesson in unit['lessons']:
                if lesson['skill']=='listening':
                    add(course['code'],lesson['audio_text'],f"{course['code']}/{unit['level']}/{unit['slug']}/listening",lesson['exercises'])
    return {'format_version':1,'scope':'Bundled starter listening lessons only; not live database or full CEFR curriculum.', 'clips':list(clips.values())}

if __name__=='__main__':
    print(json.dumps(build_inventory(),ensure_ascii=False,indent=2))

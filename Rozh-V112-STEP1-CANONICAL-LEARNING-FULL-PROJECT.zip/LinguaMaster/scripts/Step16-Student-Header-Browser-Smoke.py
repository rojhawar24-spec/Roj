#!/usr/bin/env python3
"""Offline Chromium *component* QA from actual student template and CSS; not Django runtime.

Run: python scripts/Step16-Student-Header-Browser-Smoke.py --json /tmp/rozh-header-qa.json
"""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
TEMPLATE=ROOT/'academy/templates/academy/rozh2027_student_shell.html'
STATIC=ROOT/'academy/static/academy'

def fragment(class_name):
    text=TEMPLATE.read_text(encoding='utf8')
    start=text.index(f'<form class="{class_name}"')
    end=text.index('</form>',start)+len('</form>')
    return text[start:end]

def render_markup(source,locale):
    # The actual Django form markup is used for sizing, but no server response is simulated.
    source=re.sub(r'{%\s*if R27_LANG == [^%]*%}selected{%\s*endif\s*%}', '', source)
    source=re.sub(r'{%[^%]+%}', '', source)
    source=source.replace('{{ R27.interface_language }}','Interface language')
    source=source.replace('{{ R27.apply }}','Apply')
    return source

def fixture(locale):
    dir_='rtl' if locale in ('ckb','ar') else 'ltr'
    dest=render_markup(fragment('r27-interface-language'),locale)
    mobile=render_markup(fragment('r27-mobile-interface-language'),locale)
    title={'nl':'Leer & Speel','en':'Learn & Play','ckb':'فێربە و یاری بکە','ar':'تعلّم والعب'}[locale]
    css=(STATIC/'rozh2027.css').read_text('utf8')+'\n'+(STATIC/'rozh2027-v53.css').read_text('utf8')
    return f'''<!doctype html><html lang="{locale}" dir="{dir_}"><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style>{css}</style></head><body class="r27 r27-student r53-student">
    <div class="r27-student-frame"><aside class="r27-sidebar"><a class="r27-logo" href="#">Rozh</a></aside>
    <div class="r27-workspace"><header class="r27-topbar">
    <a class="r27-mobile-brand" href="#">Rozh</a>
    <a class="r27-top-course" href="#">Nederlands</a>
    {dest}
    <div class="r27-topstats" aria-label="progress">
      <a class="r27-top-pill" href="#"><strong>180</strong><span>XP</span></a>
      <a class="r27-top-pill" href="#"><strong>5</strong><span>Hearts</span></a>
      <a class="r27-top-pill" href="#"><strong>8</strong><span>Streak</span></a>
      <a class="r27-top-pill" href="#"><strong>22</strong><span>Coins</span></a>
      <a class="r27-top-avatar" href="#">R</a>
    </div><button class="r27-theme-toggle" type="button">theme</button>
    </header><div class="r27-columns"><main class="r27-main"><h1>{title}</h1></main></div></div></div>
    <nav class="r27-mobile-bottom"><details class="r27-mobile-menu"><summary>Menu</summary>
    <div class="r27-mobile-menu-panel">{mobile}</div></details></nav>
    </body></html>'''

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--json',default='/mnt/data/rozh-release16-browser-qa.json');args=ap.parse_args()
    cases=[];fails=[]
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
        for lang in ('nl','en','ckb','ar'):
            for width in (320,360,768,1024,1366):
                for mode in ('light','dark'):
                    page=browser.new_page(viewport={'width':width,'height':800},color_scheme=mode,reduced_motion='reduce')
                    page.set_content(fixture(lang),wait_until='domcontentloaded',timeout=8000)
                    page.evaluate('(mode)=>document.documentElement.setAttribute("data-theme",mode)',mode)
                    measurements=page.evaluate('''() => {
                      const d=document.documentElement; const desk=document.querySelector('.r27-interface-language');
                      const mo=document.querySelector('.r27-mobile-interface-language');
                      const sr=el=>{let b=el.getBoundingClientRect(),s=getComputedStyle(el);return {w:b.width,h:b.height,x:b.x,y:b.y,display:s.display,visibility:s.visibility}};
                      const stats=document.querySelector('.r27-topstats');
                      return {overflow:d.scrollWidth>innerWidth+1,scroll:d.scrollWidth,
                        desktop:sr(desk),mobile:sr(mo),stats:sr(stats)};
                    }''')
                    visible=measurements['desktop'] if width>760 else measurements['mobile']
                    selector=('.r27-interface-language' if width>760 else '.r27-mobile-interface-language')
                    select=page.locator(selector+' select')
                    button=page.locator(selector+' button')
                    errs=[]
                    if measurements['overflow']: errs.append('horizontal overflow')
                    if visible['w']<30:errs.append('language control hidden')
                    if select.count()!=1 or button.count()!=1:errs.append('input/submit missing')
                    else:
                        select_height=select.bounding_box()['height'] if select.bounding_box() else 0
                        button_height=button.bounding_box()['height'] if button.bounding_box() else 0
                        if select_height<40 or button_height<40:errs.append(f'small control: {select_height}/{button_height}')
                    if errs:fails.append({'lang':lang,'width':width,'mode':mode,'errors':errs,'metrics':measurements})
                    cases.append({'lang':lang,'width':width,'mode':mode,'pass':not errs,'metrics':measurements})
                    page.close()
        browser.close()
    payload={'scope':'Local header component fixture built from actual template forms and project styles; NOT Django, full site or WCAG certification',
             'cases':len(cases),'passed':len(cases)-len(fails),'failures':fails}
    Path(args.json).write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps(payload,ensure_ascii=False,indent=2))
    return 1 if fails else 0

if __name__=='__main__':raise SystemExit(main())

"""V84 step 1, evidence-first security baseline. Uses only Python stdlib + Node if present.

Does not establish real authorization/CSRF/DB security; it is not a pentest.
Do not run on production. Produces machine-readable LOCAL static results.
"""
import ast
import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
SKIP_DIRS = {'__pycache__', '.git', '.venv', 'venv', 'node_modules'}


def files_with_suffix(ext):
    return [p for p in ROOT.rglob('*' + ext)
            if p.is_file() and not SKIP_DIRS.intersection(p.relative_to(ROOT).parts)]


def main():
    py_files = files_with_suffix('.py')
    js_files = files_with_suffix('.js')
    py_errors = []
    for p in py_files:
        try:
            ast.parse(p.read_text(encoding='utf-8'), filename=str(p))
        except (SyntaxError, UnicodeError) as exc:
            py_errors.append({'file': str(p.relative_to(ROOT)), 'error':str(exc)[:180]})
    node = shutil.which('node')
    js_errors = []
    if node:
        for p in js_files:
            try:
                result = subprocess.run([node, '--check', str(p)],capture_output=True,text=True,timeout=12)
                if result.returncode:
                    js_errors.append({'file':str(p.relative_to(ROOT)), 'error': (result.stderr or result.stdout)[-300:]})
            except subprocess.TimeoutExpired:
                js_errors.append({'file':str(p.relative_to(ROOT)), 'error':'TIMEOUT'})
    # Exact public DRF serializer contract (does not replace HTTP exploit test).
    api_tree = ast.parse((ROOT/'academy/api.py').read_text(encoding='utf-8'))
    serializer_cls = next(n for n in api_tree.body if isinstance(n,ast.ClassDef) and n.name=='LessonSerializer')
    meta = next(n for n in serializer_cls.body if isinstance(n,ast.ClassDef) and n.name=='Meta')
    public_fields = next(ast.literal_eval(s.value) for s in meta.body if isinstance(s,ast.Assign)
                    and any(isinstance(t,ast.Name) and t.id=='fields' for t in s.targets))
    transcript_exposed = 'audio_text' in public_fields or 'content' in public_fields
    unsafe_filenames = []
    for p in ROOT.rglob('*'):
        if not p.is_file():continue
        rel=p.relative_to(ROOT)
        if SKIP_DIRS.intersection(rel.parts):continue
        name=p.name.lower()
        if name in {'.env','db.sqlite3','id_rsa','id_ed25519'} or name.endswith(('.sqlite3','.pem','.key','.p12','.pfx','.pyc')):
            unsafe_filenames.append(str(rel))
    # Sensitive literal check for strong credential indicators; don't echo values.
    suspicious_literals=[]
    secret_re = re.compile(r'(?<![A-Za-z0-9_])(?:sk_live_[A-Za-z0-9]{12,}|whsec_[A-Za-z0-9]{12,}|ghp_[A-Za-z0-9]{30,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')
    for p in ROOT.rglob('*'):
        if not p.is_file() or p.suffix.lower() not in ('.py','.txt','.md','.json','.html','.js','.sh','.ps1','.yml','.yaml','.env','.example'): continue
        rel=p.relative_to(ROOT)
        if SKIP_DIRS.intersection(rel.parts):continue
        if p.stat().st_size > 2_000_000:continue
        try: raw=p.read_text(encoding='utf-8')
        except (OSError,UnicodeError):continue
        if secret_re.search(raw):suspicious_literals.append(str(rel))
    # Targeted security-control inventory: presence is NOT proof of correct enforcement.
    settings=(ROOT/'config/settings.py').read_text(encoding='utf-8')
    checks={key:(key in settings) for key in ['SecurityMiddleware','CsrfViewMiddleware','AdminMFAMiddleware',
        'SECURE_SSL_REDIRECT','SESSION_COOKIE_SECURE','CSRF_COOKIE_SECURE','ALLOWED_HOSTS','AUTH_PASSWORD_VALIDATORS',
        'SECURE_HSTS_SECONDS','SECURE_PROXY_SSL_HEADER']}
    reqs=[line.strip() for line in (ROOT/'requirements.txt').read_text().splitlines()
          if line.strip() and not line.lstrip().startswith('#')]
    unpinned=[s.split('#')[0].strip() for s in reqs if '==' not in s.split('#')[0]]
    result={
      'scope':'V84 step 1 local source and packaging security baseline, NOT complete penetration test',
      'python_count':len(py_files),'python_syntax_errors':py_errors,
      'javascript_count':len(js_files),'node_available':bool(node),'javascript_syntax_errors':js_errors,
      'public_lesson_api_fields':public_fields,'public_lesson_api_discloses_lesson_body_or_transcript':transcript_exposed,
      'private_artifact_filenames':unsafe_filenames,
      'strong_secret_pattern_candidate_files':suspicious_literals,
      'security_control_names_present':checks,
      'requirements_count':len(reqs),'requirements_without_exact_pin':unpinned,
      'django_import_available':None,
      'not_performed':['Real HTTP anonymous/authenticated API test (Django unavailable)',
                       'Full Django checks and migrations','PostgreSQL/Redis auth and concurrency',
                       'MFA privileged role/browser E2E', 'Actual vulnerability scan of installed packages',
                       'CSP/CSRF/IDOR live request fuzzing','School content and native speaker approval'],
    }
    try:
        import django
        result['django_import_available']=True
    except ImportError:
        result['django_import_available']=False
    (ROOT/'ROZH-V84-STEP1-STATIC-AUDIT.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
    assert not py_errors and not js_errors and not transcript_exposed
    assert not unsafe_filenames and not suspicious_literals
    print(json.dumps({k:result[k] for k in ('python_count','javascript_count','node_available','public_lesson_api_fields','django_import_available','requirements_count','requirements_without_exact_pin')},indent=2,ensure_ascii=False))
    print('PASS: syntax, restricted public serializer, and unsafe-file/strong-secret-pattern checks')

if __name__ == '__main__': main()

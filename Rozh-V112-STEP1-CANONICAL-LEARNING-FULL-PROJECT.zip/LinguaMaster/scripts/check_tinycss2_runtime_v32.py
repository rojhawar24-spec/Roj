"""Check a QA-only CSS parser without fragile PowerShell inline -c quoting."""
try:
    import tinycss2  # noqa: F401
except ImportError:
    raise SystemExit(1)
print('QA CSS parser available')

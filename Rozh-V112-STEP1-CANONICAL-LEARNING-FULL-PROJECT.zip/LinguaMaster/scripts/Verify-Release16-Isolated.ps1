# PowerShell 5.1+; safely tests a THROWAWAY COPY. Never runs migrations on your live DB.
[CmdletBinding()]
param([switch]$SkipDependencyInstall)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$source = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$work = Join-Path $env:TEMP ('Rozh-Release16-Verify-' + [guid]::NewGuid().ToString('N'))
$project = Join-Path $work 'LinguaMaster'
New-Item -ItemType Directory -Path $project -Force | Out-Null
Write-Host 'ROZH: creating isolated throwaway project copy (no .env, SQLite, backups or secrets).'
$excludedDirs = @('.venv', '__pycache__', 'backups', 'staticfiles', '.private-email-outbox', '.git', '.pytest_cache')
$excludeFiles = @('.env','db.sqlite3','*.sqlite3','*.pem','*.key','*.p12','*.pfx','*.zip','postgres-ca.crt')
$copyArgs = @($source, $project, '/E', '/R:1', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/XD') + $excludedDirs + @('/XF') + $excludeFiles
& robocopy.exe @copyArgs | Out-Null
if ($LASTEXITCODE -ge 8) { throw ('Robocopy failed: exit ' + $LASTEXITCODE) }
if (Test-Path (Join-Path $project '.env')) { throw 'Unsafe copied private .env'; }
if (Test-Path (Join-Path $project 'db.sqlite3')) { throw 'Unsafe copied user SQLite database'; }
if (Test-Path (Join-Path $project 'docker/certs/postgres-ca.crt')) { throw 'Unsafe copied deployment certificate'; }
$venv = Join-Path $work '.venv'
if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3.13 -m venv $venv
} else {
    & python -m venv $venv
}
if ($LASTEXITCODE -ne 0) { throw 'Python 3.13 virtual environment creation failed' }
$pythonExe = Join-Path $venv 'Scripts/python.exe'
if (-not (Test-Path $pythonExe)) { throw 'Isolated python.exe not created' }
function Invoke-Check([string[]]$CommandArgs) {
    & $script:pythonExe @CommandArgs
    if ($LASTEXITCODE -ne 0) {
        throw ('Isolated test command failed: python ' + ($CommandArgs -join ' '))
    }
}
$env:DJANGO_DEBUG = '1'
$env:USE_SQLITE = '1'
$env:DJANGO_SECRET_KEY = 'local-disposable-verify-only-no-real-account-data'
$env:REQUIRE_EMAIL_VERIFICATION = '0'
$env:EMAIL_BACKEND = 'django.core.mail.backends.locmem.EmailBackend'
$env:BUILD_STATIC_MANIFEST = '0'
$env:TRUST_PROXY = '0'
$env:ROZH_V50_SANDBOX_DB = (Join-Path $work 'temp-v50.sqlite3')
$env:ROZH_V52_SANDBOX_DB = (Join-Path $work 'temp-v52.sqlite3')
$env:PYTHONDONTWRITEBYTECODE = '1'
Push-Location $project
try {
    Write-Host 'ROZH: isolated Python / Django environment:'
    Invoke-Check @('--version')
    if (-not $SkipDependencyInstall) {
        Write-Host 'ROZH: installing pinned project requirements into temporary virtualenv.'
        Invoke-Check @('-m','pip','install','--disable-pip-version-check','-r','requirements.txt')
    }
    Write-Host 'ROZH: Django system check, migration consistency and isolated DB migration:'
    Invoke-Check @('manage.py','check')
    Invoke-Check @('manage.py','makemigrations','--check','--dry-run')
    Invoke-Check @('manage.py','migrate','--noinput')
    Write-Host 'ROZH: running Django Academy integration tests on disposable test database:'
    Invoke-Check @('manage.py','test','academy','--verbosity','1')
    Write-Host 'ROZH: all disposable Django tests completed successfully.'
} finally {
    Pop-Location
    Write-Host ('ROZH: all test work stayed in temporary copy: ' + $work)
    Write-Host 'Original project, .env and user database were NEVER modified by this script.'
}

"""One explicit LOCAL learner signup with a generated secret copied to Windows clipboard.

No password is printed, logged, passed through shell arguments, or stored in a
file. Not a Manager or Django Admin. Existing accounts are never modified.
"""
import argparse
import ctypes
from ctypes import wintypes
import os
from pathlib import Path
import re
import secrets
import sys
import time
from urllib.parse import urlsplit


_UPPER = 'ABCDEFGHJKLMNPQRSTUVWXYZ'
_LOWER = 'abcdefghijkmnopqrstuvwxyz'
_DIGIT = '23456789'
_SPECIAL = '!@#$%&*-_'
_ALPHABET = _UPPER + _LOWER + _DIGIT + _SPECIAL


def generate_password(length=28):
    """Generate a fresh password guaranteed to meet category requirements."""
    if length < 20:
        raise ValueError('Strong generated passwords must be at least 20 characters.')
    items = [secrets.choice(group) for group in (_UPPER, _LOWER, _DIGIT, _SPECIAL)]
    items.extend(secrets.choice(_ALPHABET) for _ in range(length - 4))
    secrets.SystemRandom().shuffle(items)
    return ''.join(items)


def copy_secret_to_windows_clipboard(value):
    """Clipboard copy via Win32 Unicode APIs, without console/stdout exposure.

    Clipboard is accessible to local applications; use only on a trusted Windows
    PC and paste immediately. On any error fail closed before account creation.
    """
    if sys.platform != 'win32':
        raise OSError('Windows clipboard is required; no account was created.')
    data = (value + '\0').encode('utf-16-le')
    kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
    user32 = ctypes.WinDLL('user32', use_last_error=True)
    kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
    kernel32.GlobalAlloc.restype = ctypes.c_void_p
    kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalUnlock.restype = wintypes.BOOL
    kernel32.GlobalFree.argtypes = [ctypes.c_void_p]
    kernel32.GlobalFree.restype = ctypes.c_void_p
    user32.OpenClipboard.argtypes = [wintypes.HWND]
    user32.OpenClipboard.restype = wintypes.BOOL
    user32.EmptyClipboard.argtypes = []
    user32.EmptyClipboard.restype = wintypes.BOOL
    user32.SetClipboardData.argtypes = [wintypes.UINT, ctypes.c_void_p]
    user32.SetClipboardData.restype = ctypes.c_void_p
    user32.CloseClipboard.argtypes = []
    user32.CloseClipboard.restype = wintypes.BOOL
    handle = kernel32.GlobalAlloc(0x0002, len(data))  # GMEM_MOVEABLE
    if not handle:
        raise OSError('Could not prepare clipboard memory; no account was created.')
    ownership_transferred = False
    try:
        pointer = kernel32.GlobalLock(handle)
        if not pointer:
            raise OSError('Could not lock clipboard memory; no account was created.')
        try:
            ctypes.memmove(pointer, data, len(data))
        finally:
            kernel32.GlobalUnlock(handle)
        opened = False
        for _ in range(12):
            if user32.OpenClipboard(None):
                opened = True
                break
            time.sleep(0.075)
        if not opened:
            raise OSError('Windows clipboard is busy; no account was created.')
        try:
            if not user32.EmptyClipboard():
                raise OSError('Could not clear clipboard; no account was created.')
            if not user32.SetClipboardData(13, handle):  # CF_UNICODETEXT
                raise OSError('Could not copy password; no account was created.')
            ownership_transferred = True
        finally:
            user32.CloseClipboard()
    finally:
        if not ownership_transferred:
            kernel32.GlobalFree(handle)


def create_one_local_learner(username):
    if not re.fullmatch(r'rozh_demo_[a-z0-9_]{2,30}', username):
        raise SystemExit('[STOP] Demo username must use rozh_demo_ followed by 2-30 lowercase letters/numbers/underscores.')
    if sys.platform != 'win32':
        raise SystemExit('[STOP] Only supported on a trusted local Windows computer.')
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
    import django
    django.setup()
    from django.conf import settings
    from django.contrib.auth import get_user_model
    from django.contrib.auth.password_validation import validate_password
    from django.core.exceptions import ValidationError
    from django.db import transaction
    from academy.models import Profile

    url = urlsplit(settings.SITE_URL)
    db = settings.DATABASES['default']
    expected_db = (Path(settings.BASE_DIR) / 'db.sqlite3').resolve()
    if (not settings.DEBUG or url.scheme != 'http'
            or url.hostname not in ('localhost', '127.0.0.1')
            or db['ENGINE'] != 'django.db.backends.sqlite3'
            or Path(db['NAME']).resolve() != expected_db):
        raise SystemExit('[STOP] Refused outside local DEBUG + loopback SQLite project.')
    User = get_user_model()
    if User.objects.filter(username__iexact=username).exists():
        raise SystemExit('[STOP] This username already exists. NO existing account was changed. Use a different -Username.')
    email = username + '@example.invalid'
    if User.objects.filter(email__iexact=email).exists():
        raise SystemExit('[STOP] Example email already exists; use another -Username.')

    candidate = User(username=username, email=email)
    password = generate_password()
    try:
        validate_password(password, user=candidate)
    except ValidationError:
        raise SystemExit('[STOP] Generated password did not meet current Django policy. No account created.') from None

    # IMPORTANT: copy before DB write. If clipboard unavailable, do not create
    # an inaccessible account. Never echo a credential to console or logs.
    try:
        copy_secret_to_windows_clipboard(password)
    except OSError:
        raise SystemExit('[STOP] Clipboard unavailable; no account created.') from None

    with transaction.atomic():
        if User.objects.filter(username__iexact=username).exists():
            raise SystemExit('[STOP] Username already used; no changes made.')
        user = User.objects.create_user(
            username=username, email=email, password=password,
            is_active=True, is_staff=False, is_superuser=False,
        )
        profile, _ = Profile.objects.get_or_create(user=user)
        if profile.email_verified_at or profile.legacy_review_required or profile.suspended_at:
            raise RuntimeError('Unexpected demo account safety status; transaction rolled back.')
        if user.groups.exists() or user.user_permissions.exists():
            raise RuntimeError('Unexpected privilege grant; transaction rolled back.')
    password = None
    print('[PASS] Created ONE ordinary local learner; no Django Admin/Manager privileges.')
    print('Username: ' + username)
    print('[CLIPBOARD] Password copied to Windows clipboard, not printed or written to a file.')
    print('[NEXT] Start Rozh and paste the password into the sign-in field with Ctrl+V.')
    print('[SECURITY] Clipboard content is readable by local apps; clear it after signing in.')
    print('[NOTE] Email is example.invalid; password recovery via email does not work for this demo.')
    print('[PRESERVED] All previous users, credentials and progress remain unchanged.')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--username', default='rozh_demo_2026')
    args = parser.parse_args()
    create_one_local_learner(args.username.strip())


if __name__ == '__main__':
    main()

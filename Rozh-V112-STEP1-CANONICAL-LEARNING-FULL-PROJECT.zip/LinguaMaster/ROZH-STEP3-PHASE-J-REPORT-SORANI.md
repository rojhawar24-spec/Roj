# Rozh — هەنگاوی ٣، بەشی J (QA Filesystem Guard)

**دۆخ: J هێشتا ناتوانرێت دابخرێت.** بەڵگەی Django HTTP/SQLite و PostgreSQL migration/concurrency هێشتا نییە. تاقیکردنەوەی Offline جێگرەوەی ئەوانە نییە.

## چاککردنەوەی سەلمێنراو

لە ڕێکخستنی QA ـی Phase Iدا فۆڵدەری `.rozh-local-test` بە `.resolve()` خوێندراوە؛ پێش ئەوەی دڵنیابین لەوەی symlink یان junction نییە. لە دۆخی symlink بۆ شوێنی تر، ئەمە دەتوانی QA لە سنووری پڕۆژە دەربهێنێت. هەروەها خوێندنەوەی `qa-secret.key` لە ڕێگای path دەیتوانی symlink بۆ فایلێکی تر دوابکەوێت.

- `config/qa_filesystem_safety.py` زیادکرا: symlink/junction بۆ QA root ڕەت دەکات؛ فایلێکی نهێنی لەسەر file descriptor و لە POSIX بە `O_NOFOLLOW` دەخوێنێتەوە؛ فایلەکە دەبێت regular بێت؛ ڕێگەی فراوانی فایل لە POSIX ڕەت دەکرێتەوە.
- `config/settings_local_qa.py` نوێکراوە تا ئەو پاراستنانە بەڕاستی بەکاربهێنێت و داتابەیس لە فۆڵدەری جیاکراوە بمێنێتەوە.
- `scripts/test_step3j_qa_filesystem_safety_offline.py`: ١٠ تاقیکردنەوەی ڕاستەوخۆی فانکشن بۆ دۆخی سەلامەت، symlink و secret زیادکرا.
- `scripts/test_step2_qa_isolation_offline.py` بە شوێنی ڕاستی فایلی نوێ نوێکرایەوە بەبێ لاوازکردنی مەرج. Runner ـی Windows و جۆبی GitHub Actions ـیش تاقیکردنەوەی نوێ ڕادەکەن.

## دۆخی سێ بەشی ماوەی هەنگاوی ٣

- **J (ئێستا):** migration 0019، Django HTTP/SQLite، PostgreSQL Concurrency و پاراستنی QA. پاراستنی QA تاقیکراوە؛ Django و PostgreSQL هێشتا ڕانەکراون. **ناتەواو**.
- **K:** پشکنینی end-to-end بۆ هەموو ١٣ چالاکی لە مۆبایل، RTL، keyboard، screen reader و دەستگەیشتن. **دەستی پێ نەکراوە**.
- **L:** full regression، security audit، پشکنینی زمانی ناوەڕۆک و ڕاپۆرتی کۆتایی. **دەستی پێ نەکراوە**.

**بەشە ماوەکان: ٣ لە ٣ = J، K، L.** ژمارەی بەشەکان لەو ٣ ـە زیاتر ناکەین؛ ئەگەر کارێکی دیکە دەرکەوت، لە ناو هەمان بەش دەپشکنرێت.

## پشکنینی ڕاستەقینە

- ٣١ کۆمەڵەی پێشوو: ٣٦٣/٣٦٣ offline/Chromium سەرکەوتوو؛ ١٠ تاقیکردنەوەی نوێی helper: ١٠/١٠ سەرکەوتوو.
- Django و PostgreSQL: **نەکراوە** — package ـەکانی Django و psycopg لەم ژینگەیەدا نیین.
- Windows runner و GitHub Actions لێرە ڕانەکراون.
- **ئامادەی قوتابخانە/production:** نەخێر.

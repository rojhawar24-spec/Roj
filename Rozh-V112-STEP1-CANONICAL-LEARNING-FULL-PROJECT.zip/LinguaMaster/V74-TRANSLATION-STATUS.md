# Rozh V74 — Zeven interfacetalen (beta voor nieuwe talen)

## Beschikbare talen

| UI-code | Taal | Richting | Script | Status |
|---|---|---|---|---|
| nl | Nederlands | LTR | Latijn | bestaand |
| en | English | LTR | Latijn | bestaand |
| ckb | کوردی سۆرانی | RTL | Arabisch schrift | bestaand |
| kmr | کوردی بادینی | RTL | Arabisch schrift (HTML: `kmr-Arab`) | **BETA** |
| uk | Українська | LTR | Cyrillisch | **BETA** |
| ar | العربية | RTL | Arabisch schrift | bestaand |
| fr | Français | LTR | Latijn | **BETA** |

De *UI-taal* is onafhankelijk van de *leertaal* (cursuscode `nl`, `en`, `de`, `fr`).

### Wat V74 daadwerkelijk doet

- Eén centrale, expliciete whitelist van zeven toegestane UI-talen (`academy/ui_languages_v74.py`) met geschikte richting en codes. Voor Badini gebruiken we de Northern Kurdish code `kmr` in de bestaande 3-karakterdatabasekolom, met Arabisch schrift. Dit is niet hetzelfde als Sorani (`ckb`).
- Taalwissel via officiële POST met CSRF en bestaande sessie-/accountcontrole. Dezelfde zeven opties staan in de student-desktop- en mobiele menu's, Manager, publieke homepage, login en onboarding.
- Nieuwe publiek bereikbare landingspagina's `/kmr/`, `/uk/`, `/fr/`; de selectie wordt in de public session bewaard.
- De 4-staps onboarding toont zeven talen en heeft voor drie nieuwe talen specifiek geschreven kerncopy. De cursussen blijven los hiervan.
- Gelokaliseerde hoofdnavigatie in Student en Manager, centrale UI, basis-URL/SEO-teksten en een deel van login en openbare homepage.
- De bestaande V72 hartjesherstelopdracht en V73 wekelijkse woordenherhaling hebben extra lokale labels gekregen. **De beloningsregels zelf zijn niet veranderd.**
- Ongeveer 44 historische gelokaliseerde dict-modules krijgen veilige Engelse *fallback*-waarden voor ontbrekende sleutels om uitzonderingen te voorkomen. Deze fallback is **geen vertaling**.
- Nieuwe UI-taalopties krijgen daarom expliciet de markering **Beta**. Bij Badini is controle van spelling, stijl en dialect door moedertaalsprekers extra belangrijk.
- CSS voor RTL, Cyrillisch, Arabisch schrift, geschikte lokale lettertypes, en Manager-taalwissel; oorspronkelijke logo- en lesbestanden blijven ongemoeid.
- Additieve migratie `0016_seven_interface_languages_v74.py` wijzigt uitsluitend het choices-schema van het Profiel, niet de bestaande waarden of kolombreedte. Migraties `0001`–`0015` worden byte-identiek behouden.

### Nog NIET af

- **Niet alle UI-zinnen zijn vertaald.** Minder zichtbare pagina's, juridische teksten, geavanceerde Manager-acties, instellingen, formulieren, grammatica, foutmeldingen en lesactiviteiten kunnen nog Engelse fallbacks bevatten. Sommige hoofdstukken bevatten Nederlandstalige originele, door Manager geschreven leerinhoud: deze wordt **niet** automatisch vertaald, want dat is de leerstof.
- Vertaalde nieuw-ingevoerde korte teksten zijn nog niet door onafhankelijke native reviewers gecontroleerd, met name voor Badini. Professionele lokalisatie van alle strings en QA per gebruikersflow is nodig vóór release.
- Geen Django live HTTP/ORM/migratietests en geen daadwerkelijke Edge/Windows-test in deze buildomgeving. Gebruik daarvoor een geïsoleerde projectkopie en `RUN-ROZH-V74-INTEGRATION.cmd` na veilige testomgevinginitialisatie.
- Nieuwe UI-talen in de browser zijn geen nieuwe lesinhoud of cursussen; dat zijn twee verschillende systemen.

### Dataveiligheid

De ZIP bevat géén echte `.env`, gebruikersdatabase, private sleutels of virtuele omgeving. Pak niet uit over de bestaande Rozh-map; test een nieuwe kopie en bewaar persoonlijke accounts en voortgang apart.

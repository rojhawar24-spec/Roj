# Rozh — هەنگاوی ٣، بەشی I — PostgreSQL Concurrency QA

**دۆخی ڕاستەقینە: ٣٦٣ تاقیکردنەوەی Offline/Browser سەرکەوتووە؛ Django HTTP، PostgreSQL و migration ـەکان ڕانەکراون. هەنگاوەکانی ٢ و ٣ هێشتا تەواو نییە.**

## ئامانجی Phase I

Phase H لە Database تۆماری `LessonRoundReceipt` و migration ـی `0019` زیاد کرد، بەڵام پاراستنی داواکارییە هاوکاتەکان لە PostgreSQL بەڕاستی تاقی نەکرابوو. لە Phase Iدا **کۆدی production ـی نمرەدان نەگۆڕاوە**؛ تاقیکردنەوە و ڕێگای جیاکراوەی ڕانکردنی ڕاستەقینەی PostgreSQL زیادکرا.

## گۆڕانکارییەکان

١. `config/settings_postgres_qa.py`: تەنها لە GitHub Actions بە `ROZH_PG_QA_ONLY=1` چالاک دەبێت، سەرەتا ڕێکخستنی QA ـی ناوخۆیی دەخوێنێتەوە و هەر پەیوەندییەکی دەرەکیی inherited ڕەت دەکاتەوە. host ـەکە تەنها `127.0.0.1`، database ـی کاتی `test_rozh_qa_step3` و user ـی تاقیکردنەوە `rozh_qa` ـە. هیچ `.env` یان دیتابەیسی ڕاستەقینەیەک لە release ـدا نییە.
٢. `academy/test_step3i_postgres_concurrency_http.py`: **٥ تاقیکردنەوەی نوێی واقعی PostgreSQL/TransactionTestCase نووسراون، بەڵام هێشتا ڕانەکراون**. دوو داواکاریی هاوکاتی AJAX، AJAX/SSR، دوو تەواوکردنی Round، XP ـی یەکجارە و Heart/Mistake ـی یەکجارە دەپشکنن. ThreadPoolExecutor، DB connection ـی جیا و یەکتاییی تۆماری Round بەکار دەهێنن.
٣. `.github/workflows/rozh-step2-qa.yml`: جۆبێکی دووەمی PostgreSQL 17 بۆ GitHub Actions زیادکرا. تەنها بە `workflow_dispatch` دەست پێ دەکات، PostgreSQL ـی کاتی لە CI دروست دەکات و هەر تاقیکردنەوەیەکی شکستخواردوو ڕاپۆرت دەکات؛ **لێرە نەڕانراوە و هیچ repository ـێکی GitHub نەگۆڕاوە**.
٤. `scripts/test_step3i_postgres_gate_offline.py`: **١٠ تاقیکردنەوەی Offline** بۆ ڕێکخستنی QA، خاڵە سەلامەتییەکان و بوونی تاقیکردنەوەکان. ئەمانە جێگری ڕانکردنی PostgreSQL نین.
٥. Runner ـی Windows و جۆبی SQLite ـی GitHub Actions هەمان پشکنینی Offline زیادکراوەیان هەیە. فرمانی Windows ـی پێشوو بەڕاستی دووجار لە فایلدا نەنووسرابوو؛ هەڵسەنگاندنی سەرەتایی دووجار خوێندنەوەی هەمان دێڕ بوو و بێ گۆڕینی ساختە ڕاستکرایەوە.

## ئەنجامی بەڵگەدار

- ٣١/٣١ کۆمەڵەی Offline/Chromium = **٣٦٣/٣٦٣ تاقیکردنەوەی سەرکەوتوو** لە فۆڵدەری کار؛ لە ZIP ـی تازە دووبارە دەخرێتە پشکنین.
- ٦٣٠ فایلی Python ـی AST syntax و ٤٣ فایلی JavaScript ـی Node syntax: بێ هەڵە.
- GitHub Actions YAML بە parser تاقیکرایەوە و هەردوو جۆبی SQLite و PostgreSQL تێیدا هەن.
- Django HTTP / SQLite: **NOT EXECUTED**.
- PostgreSQL concurrent HTTP/DB: **NOT EXECUTED**.
- `migrate` و `makemigrations --check`: **NOT EXECUTED**.
- **هیچ وەشانێکی بە ١٠٠٪ بێ هەڵە یان ئامادەی قوتابخانە پەسەند نەکراوە.**

## تاقیکردنەوەی داهاتوو

بۆ ڕانکردنی PostgreSQL جۆبەکە، ئەم کۆدە لە GitHub repository ـی **private** دابنرێت و workflow ـی `Rozh Step 2 + 3 - isolated Django/SQLite QA` بە دەستی خاوەن پڕۆژە (`Run workflow`) چالاک بکرێت. GitHub **لەوەشدا هێشتا بە ChatGPT پەیوەست نییە**؛ هیچ push یان CI ڕانکردنێک نەکراوە.

بۆ Windows و SQLite هەمان فرمان لە فۆڵدەری کۆپییەکی پاکی `LinguaMaster` بەکار بهێنە:

```powershell
cmd /c .\RUN-ROZH-V95-STEP2-QA.cmd
```

تاقیکردنەوەی PostgreSQL پێویستی بە ژینگەی CI ـی تایبەت هەیە. دوای ڕانکردنی ڕاستەقینەی ئەو تاقیکردنەوانە، هەر شکستێک پێویستە بە کۆدی production چارەسەر بکرێت و دووبارە تاقی بکرێتەوە. ئەم فایلە گەرەنتی سەرکەوتنی تاقیکردنەوەی نەکراو نادات.

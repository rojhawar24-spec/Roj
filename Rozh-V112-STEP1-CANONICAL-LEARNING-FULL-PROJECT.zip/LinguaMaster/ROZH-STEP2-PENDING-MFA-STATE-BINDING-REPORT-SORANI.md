# Rozh V95 — هەنگاوی ٢: پاراستنی نێوان Login و MFA

**دۆخ: STEP 2 = OPEN، STEP 3/J = OPEN، Production = NOT APPROVED.**

## چاککردنەوەی ئەم قۆناغە

پێشتر، لە نێوان پشتڕاستکردنەوەی وشەی نهێنی و کۆدی MFA دا
داواکارییەکی چاوەڕوان دەتوانی لە سێشنەکەدا بمێنێتەوە.
ئێستا سێشنەکە بە دۆخی ئەو کاتە دەبەسترێتەوە: hash ـی پارێزراوی
وشەی نهێنی، ژمارەی گۆڕانکاری هەژمار و fingerprint ـی مۆڵەتەکان.
ئەگەر یەکێک بگۆڕێت، داواکارییە کۆنەکە ڕەت دەکرێتەوە.

پشکنین دوو جار دەکرێت: لە سەرەتای `mfa_verify` و دووبارە
لە ناو transaction ـی داتابەیسی داواکارییەکە. پاش کۆتایی،
داتای MFA pending لە سێشن دەسڕدرێتەوە. داتای نهێنی TOTP یان
password hash بە شێوەی ئاشکرا لە سێشن ناهێڵدرێت.

**ئەمە پاراستنی زیاترە، نەک بەڵگەی ئەوەی کە هیچ کێشەیەکی ئاسایشی نییە.**

## تاقیکردنەوەی جێبەجێکراو

- **٣٥/٣٥** سکریپتی offline/browser سەرکەوتن.
- **٣٦١** تاقیکردنەوەی ژمێردراو سەرکەوتن، ٠ شکست.
- **١١** تاقیکردنەوەی نوێ بۆ helper ـی pending MFA.
- **٤** تاقیکردنەوەی isolated actual-view بە stubs سەرکەوتن.
- **٦٤٦** فایل Python بە AST و **٤٣** فایل JavaScript بە `node --check` پشکنران.
- GitHub Actions YAML شیکرایەوە؛ ئەمە نیشانەی سەرکەوتنی خودی workflow نییە.

## پشکنینی Django HTTP ـی نوێ

فایلی `academy/test_step2_pending_mfa_binding_http.py` پێنج
تاقیکردنەوەی ڕاستەقینەی Django دەگرێتەوە: MFA ـی دروست،
گۆڕینی وشەی نهێنی، state revision، permission change و سڕینەوەی proof.
بۆ Ubuntu CI و Windows QA زیاد کراوە.
**ئەو پێنج تاقیکردنەوەیە هێشتا بە Django ڕانەکراون.**

## چەند کار ماوە؟

**هەنگاوی ٢: ٥ بەشی پشکنینی واقعی هێشتا کراوەن:**

١. Django check و migration parity.
٢. Login / MFA / Manager و HTTP/SQLite.
٣. Full academy Django regression.
٤. Real-browser responsive، Sorani RTL و accessibility.
٥. Windows / PostgreSQL / security و final release review.

J ـی هەنگاوی ٣ هێشتا ٥ runtime gate ـی خۆی هەیە.
هیچ داتابەیس، مایگرەیشن یان credential ـی واقعی نەگۆڕدراوە.

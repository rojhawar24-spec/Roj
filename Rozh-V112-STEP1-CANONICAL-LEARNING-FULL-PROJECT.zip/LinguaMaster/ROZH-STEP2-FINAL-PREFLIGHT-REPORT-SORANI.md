# Rozh V95 — هەنگاوی ٢: کۆتایی پشکنینی offline و ئامادەکاری تاقیکردنەوەی ڕاستەقینە

**دۆخ: هەنگاوی ٢ هێشتا ١٠٠/١٠٠ پشتڕاست نەکراوەتەوە.** کۆدەکان نوێ کرانەوە، بەڵام بەڵگەی جێبەجێکردنی Django/Windows/PostgreSQL هێشتا نییە؛ Production پەسەند نەکراوە.

## چاکسازییە ڕاستەقینەکان

- دۆخی تێکچووی `mfa_recovery_hashes` لە داتابەیسدا لە ٣ ڕێگای MFA (Login ـی نوێ، Session ـی پێشوو، MFA Setup) چیتر نابێتە هۆی `HTTP 500` بەهۆی `RuntimeError` ـی چاوەڕوانکراو.
- سیستەم بە پارێزراوی ڕەت دەکاتەوە، داواکارییەکە پاک دەکات، و MFA پشتگوێ ناخات. هەڵەی نەناسراو و هەڵەی داتابەیس بە درۆ وەک سەرکەوتن پیشان نادرێن.
- `scripts/test_step2_malformed_mfa_inventory_offline.py`: ٨ تاقیکردنەوەی ڕەفتاری ڕاستەوخۆ سەرکەوتوون.
- `academy/test_step2_malformed_mfa_inventory_http.py`: ٣ تاقیکردنەوەی Django HTTP **نووسراون، بەڵام نەڕاوەن**؛ لە targeted/full academy CI و Windows زیاد کراون.

## پشکنینی ڕاستەقینەی browser لە CI

- `scripts/step2_live_browser_qa.py`: ٣ تاقیکردنەوەی Django `StaticLiveServerTestCase` بە Chromium/Playwright؛ Login بە ٣٦٠px، Sorani RTL/کیبۆرد، و Password→MFA→گۆڕینی Session.
- ئەمانە لە CI ـدا پێش دروستکردنی receipt ـی Linux جێبەجێ دەکرێن. ناکامییەک ڕێگری لە receipt دەکات. ئەمە تاقیکردنەوەی ڕاستەقینەی Django ـە، نەک HTML ـی ساختە؛ **لە ژینگەی ئێستادا هێشتا نەڕاوە**.
- `scripts/test_step2_live_browser_gate_offline.py`: ٥ تاقیکردنەوەی ڕێکخستنی script/workflow سەرکەوتوون. ئەمانە بەڵگەی real-browser PASS نین.

## ئەنجامی جێبەجێکراو لەم ژینگەیە

- **٣٩/٣٩** سکریپتی offline/browser-contract سەرکەوتوو.
- **٤٠٣** تاقیکردنەوەی ژمێردراو سەرکەوتوو.
- کۆدی Python بە AST و JavaScript بە `node --check` پشکنراون.
- ZIP تەواوە؛ فایلەکانی هەنگاوی ٣ و ٤ و لوگۆ و migration ـە پێشووەکان پارێزراون.
- Django/HTTP، migration، PostgreSQL 17، Windows ACL و Browser ـی سەر Django **NOT RUN**.

## ٥ گرووپی پشکنینی ماوە

١. `manage.py check` و `makemigrations --check --dry-run` و migration لە داتابەیسی پاک.
٢. HTTP ـی Login/MFA/Manager، Session و CSRF لە SQLite ـی ڕاستەقینە.
٣. تەواوی Django `academy` regression بە تاقیکردنەوەی skip ـی توند.
٤. Browser ـی ڕاستەقینە بە ٣٦٠px و سۆرانی RTL، کیبۆرد و پشکنینی دەستی Screen Reader/Accessibility.
٥. Windows ACL و PostgreSQL 17 و staging/security review.

### چۆن جێبەجێ بکرێت؟

لە Windows، لە ناو فۆڵدەری `LinguaMaster`:

```powershell
cmd /c .\RUN-ROZH-V95-STEP2-QA.cmd
```

یان لە private GitHub repository ـدا `LinguaMaster` بکە repository-root و لە GitHub Actions ـدا workflow ـی **Rozh Step 2 + 3 - isolated Django/SQLite QA** بە `Run workflow` دەست پێ بکە. لە CI دا هەرسێ کاری Django/SQLite+Chromium، PostgreSQL و Windows دەبێت سەرکەوتوو بن، و `phase-j-gate` بەڵگەکانیان پشتڕاست بکاتەوە. ئەوەش جێگرەوەی پشکنینی دەستی Accessibility و staging نییە.

**هیچ `.env`، داتابەیسی ڕاستەقینە یان زانیارییەکانی خوێندکاران مەخەرە ناو repository.**
